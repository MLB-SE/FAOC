import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(-0.0010120169820558834,1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(-0.0010718602364363384,-1.5707963267948966,72.21867023377183 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(-0.001623765792445355,-1.5707963267948966,15.265947579396503 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark06(0.001695572106188363,1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark06(-0.0016974283809462968,-1.414026435337541,102.4771750937876 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark06(-0.0017893456412727514,-1.5707963267948966,3.266600756275695 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark06(-0.0019595229992036426,1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark06(-0.0020386160161562326,-0.6730451011540525,-66.02362417583666 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark06(-0.002056055196243885,-0.5240600180390083,-1.570796326794897 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark06(-0.002062641516549651,-1.5707963267948948,-41.65546674154134 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark06(-0.0020981009343208515,-95.59924514858983,-45.03441804752876 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark06(-0.00212926654601887,-0.5915918412370862,-58.97101451307986 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark06(-0.002528036558782892,-44.42358722905009,-23.773752664605112 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark06(-0.002600136802242581,-1.4865420009743913,1.5707963264802027 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark06(-0.002634607245528997,-1.5240597305174879,-57.04764019091344 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark06(-0.0027406148042300998,-1.157514149047622,-3.141592653589793 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark06(-0.0027745802489201332,-1.7763568394002505E-15,-10.28886039390514 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark06(-0.002794125034721942,-76.7528229749926,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark06(-0.0028150745094688468,8.271806125530277E-25,5.4275637325016675 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark06(-0.0028414521626343183,-1.5707963267948966,65.8837850880287 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark06(0.003044930463845262,1.5707963267948966,-18.862961328707346 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark06(-0.0033105747714736247,-1.5707963267948966,-39.31210304133481 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark06(-0.003561113104789802,-0.02333246384050563,-16.56418855893571 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark06(-0.003583769820372701,-1.5707963267948966,-50.27375686990268 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark06(-0.003669396180544876,-1.5707963267948963,-1.5707963267948966 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark06(-0.003986138619922777,-88.09668320242355,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark06(-0.004145894626136153,-0.010505087486205433,86.44534934020419 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark06(0.0041964202018708405,1.5707963267948966,-48.620412196124605 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark06(-0.004292148321376544,-1.5707963267948966,1581.5206876315556 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark06(-0.004667431084611795,-1.5707963261251408,29.438403768590632 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark06(-0.004727905378312261,-1.5707421881247592,-216.76685162024435 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark06(-0.005185111905962295,-1.5707963267948966,-97.51764411083349 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark06(-0.00522521527770441,-1.076209394431662,67.55705941545828 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark06(-0.0052262389519600605,-95.68338195700056,0.0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark06(-0.005367954183938405,-0.28849656674272417,53.6639978044131 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark06(-0.00556695939823567,-1.125655967739477,19.349556629892575 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark06(-0.0055734197507002325,-0.6903719023103506,56.49860195469586 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark06(-0.005867346166271291,-0.19287377469891176,62.48545957980446 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark06(-0.0063122662315784235,-32.945580750035376,-25.132741228718345 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark06(-0.0068333020456218954,-3.552713678800501E-15,0.24189297827912765 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark06(-0.007150406068799554,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark06(-0.007160103832879322,-63.77855963277225,35.55172137621648 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark06(-0.007219876000731665,0.0,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark06(-0.007225571306665748,-1.5707963266505052,-166.50384846205696 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark06(-0.007370892951991934,-1.3913622721925538,-58.84091072793854 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark06(-0.007450198457184168,-37.69911184307752,-0.6451863080266942 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark06(-0.007627965282773152,-1.4782824802388899,-67.08167362515907 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark06(-0.007743274742541883,-95.53478630114007,-72.18930368935389 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark06(-0.00785134771497947,6.776263578034403E-21,-0.512648315354269 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark06(-0.008001431604374692,-25.561199707531753,-24.508724628056232 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark06(-0.008199386376384489,-1.5707963267948966,90.51257531262738 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark06(-0.008703999089650694,-95.43975289756843,-70.71464716122864 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark06(-0.00917480023677376,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark06(-0.009543866133035664,-0.11432816125186973,62.22207088000867 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark06(-0.011154443000613412,-0.6794641581479866,-11.725470431168475 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark06(-0.011463934321350368,1.5707963267948966,-72.53231756727114 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark06(-0.011536614802239886,-0.40549285774723964,66.0506629668992 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark06(-0.011566476315075569,-37.80647745237551,4.743638980827186 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark06(-0.011603008867251963,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark06(-0.011638910101950582,-1.5707963267948983,100.0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark06(-0.012685843377403822,-1.5707963267948966,83.49637533653929 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark06(-0.012729160558623633,-1.5707963267948912,69.47140744237271 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark06(-0.012973512915305463,-95.71373928956373,-1.5707963267948983 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark06(0.013245713169497964,-2487.91384724978,0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark06(-0.013372185740156473,6.938893903907228E-18,2.3440062925473377 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark06(-0.013395989349856354,-1.5707963267948966,41.8071404067052 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark06(-0.013708751934636108,-1.570796326794781,-43.54035558807017 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark06(-0.01388393244583347,-1.3772382343971705,-1.5707963267948966 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark06(-0.01393234938023162,-1.5707963267948963,4.714342105384709 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark06(-0.014615410494298587,-44.22305302588148,-0.9842274934558272 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark06(-0.014711949172927577,-8.006934664843591E-18,0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark06(-0.014817289971984641,-1.0083752778076311,84.31569451832326 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark06(-0.014903425720211383,-1.5707963267948966,0.21390995791703799 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark06(-0.015522429728418004,-1.5707963267948966,28.04763118117212 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark06(-0.015774778021459837,-1.5499128293821633,-78.53981935329564 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark06(-0.016261097373223385,-0.16209986511064378,67.19739653269795 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark06(-0.01683191279745262,1.5707963267948966,-73.63108812658488 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark06(-0.0168727611173789,-45.315510850694245,-1.5707963267948966 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark06(-0.017019755939360975,-1.551843049129629,-16.33283795182392 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark06(-0.017176240969224765,1.5707963267948966,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark06(-0.017243969246464208,1.5707963267948966,-62.17865793585334 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark06(-0.01743505887711347,-39.256994492101775,-88.19771820190553 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark06(-0.01770212352212419,-1.5707963267948966,3.1415926535897896 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark06(-0.017898891054111077,-0.061423300576853135,1.5707963267948968 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark06(-0.01851269073663412,-1.5707963267948948,77.79667837870122 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark06(-0.019135492998055614,-19.349555921889433,-37.720520284679246 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark06(-0.019236225231057613,-1.5421663071464953,-97.3893722612836 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark06(-0.01927121989001085,-1.154699190551844,821.4004826041701 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark06(-0.019288335958260162,1.5707963267948966,-69.7180150430609 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark06(-0.02003049882733987,-0.8179324149251341,164.89760230221782 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark06(-0.020214435898949674,-1.5707963267948966,51.91304781259646 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark06(-0.020274931199309263,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark06(-0.02033826435270214,-1.5707963267948957,-1024.7332789964616 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark06(-0.020446025648475842,-1.5707963267948966,50.27700575716486 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark06(-0.020760945048247326,-70.05344781839698,0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark06(-0.020775590797287635,-32.696967979823214,-124.79648980036707 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark06(-0.021183062287299048,-0.8884703014349054,1.5707963267948983 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark06(-0.021612739385312857,-1.57079632627876,71.31968518736963 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark06(-0.02169773602732668,-31.766392278279078,-1.570796326794897 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark06(-0.021812512121355928,-1.5707963267948966,18.84955592153876 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark06(-0.02250341074712881,-1.5707963267948966,99.78719578548507 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark06(-0.023012970246715184,-1.5707963267948966,11.881816835663116 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark06(-0.02396732574127178,-43.98229715028144,-38.07844164996004 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark06(-0.024537220773623976,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark06(-0.024860317517804167,-1.022686640548672,84.46077623441687 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark06(-0.024951968260614573,-1.5707963267948521,45.87915150850185 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark06(-0.025024590336751973,-1.570796326794896,74.15534478591366 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark06(-0.025171388792573874,-4.440892098500626E-16,-9.512999465363865 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark06(-0.025611091739642808,-1.5707963267948966,88.10252313037006 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark06(-0.025631901928410732,-1.5707962950912455,72.45788859774704 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark06(-0.025972773545390737,-0.8221380842449673,3.4787880816411683 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark06(-0.026445735866013478,-0.2276398119668151,-1.1380524797363597E-159 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark06(-0.02681038784627976,-45.32877699622664,-51.43687244142663 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark06(-0.027262718235110457,0,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark06(-0.02743711877796262,1.5707963267948966,-1.5707963267949239 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark06(-0.027794426880660694,-0.4974276936512041,55.11077981734258 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark06(-0.028210733915730982,-1.5707963267948966,-40.13645060701043 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark06(-0.028477845751455177,-100.59139114812176,-1.570796326794893 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark06(-0.028686346123624057,1.5707963267948968,0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark06(-0.028702127213267183,-1.5497466341880635,1.570796326794898 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark06(-0.03018553209325583,1.3877787807814457E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark06(-0.031115135864896882,-1.5707963267948966,-81.68851229923264 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark06(-0.031130346446389012,-163.49083772615364,-1.5707986035974644 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark06(-0.03125043484164891,-1.5707963267948966,-1.6146275403886012 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark06(-0.03148759918352084,-38.98980482029028,-76.24393617618762 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark06(-0.03158383267169995,-8.881784197001252E-16,-73.95840012559965 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark06(-0.03223596125405737,-1.5707963267948966,23.325384839483434 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark06(-0.03231288335920243,-15.977598771431085,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark06(-0.03247480316113676,-1.5707963267948966,-11.945168653370182 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark06(-0.03249336056084928,-39.14807372005273,-83.099472214541 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark06(-0.0328379877460094,-0.13890406299371258,-1.5707963267948966 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark06(-0.03316485214182219,-1.5707963267948966,-12.605021123462794 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark06(-0.033862735742640225,-1.5622634863897158,78.2587126697677 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark06(-0.03400179423574449,-1.3856381980100645,4.313098331361879 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark06(-0.03440363733533138,-0.14222892343469296,1.5707963267948988 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark06(-0.03451184950717756,-1.5707963267948966,1.5686170369084216 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark06(-0.03461884915213731,-3.1415926535900667,66.54681115769736 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark06(-0.03513686019817014,-1.5707963267948966,-1.57079588580445 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark06(-0.03561964117999757,-1.5707963267948966,1.681218273811815E-285 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark06(-0.035640654443421134,-1.5707963267948966,56.08306877979236 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark06(-0.03631346151428525,-1.5707963267948966,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark06(0.03660580590155096,1.5707963267948966,-96.7436558953457 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark06(-0.03764542500177741,-0.32805718862107325,-38.88089273515288 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark06(-0.03778410667106551,-0.9686607679407544,-23.533668218734817 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark06(-0.03829670160582012,-1.5707963267948948,-100.0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark06(-0.03842998953886865,-1.4523707655654172,6.538471638676644 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark06(-0.03873246235210897,-1.468985569107754,1.5707963267948963 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark06(-0.03937255872341394,-31.416532021363764,-109.16582547849312 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark06(-0.039454418486899255,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark06(-0.040278522203091555,-1.502687373926643,100.0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark06(-0.04034224231639527,-1.5707963267948966,7.351643765843079 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark06(-0.04058901172203733,-0.36594024927741764,56.05595151501654 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark06(-0.04073762475147475,-1.5707963267948963,26.022593140852692 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark06(-0.04075372847442793,-1.5707963267948948,-27.33787529042982 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark06(-0.041013461365924,-1.5707963267948966,6.938893903907228E-18 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark06(-0.04122499541635505,-1.5707963267948972,135.58829041983543 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark06(-0.04197774725261655,-44.54991788375665,62.42616054767892 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark06(-0.04216492666706599,-1.570796326582313,-1.5707963267948963 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark06(-0.042582972445207375,-1.5707963267948966,-55.88008446885304 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark06(-0.04291033773170483,-1.5707963267948966,90.86110196664518 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark06(-0.043037055269059155,-163.79121673920412,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark06(-0.04321287182340143,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark06(-0.04336811846066224,-1.5707963267948963,1.9482488404750794E-14 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark06(-0.04342521576649042,-1.554487609450851,-4.743638980674305 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark06(-0.0435793590442287,-50.574114485410625,0.0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark06(-0.043746724496144036,-32.81833247776496,-348.41954483599 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark06(-0.04418584009543886,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark06(-0.04447987217114657,-37.92870048908616,-2.926047721682624E-98 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark06(-0.044575738779194296,-32.521258797717735,-26.78636372122068 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark06(-0.04467747877584749,-1.5707963267948966,-45.63000628671077 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark06(-0.04580461221139942,-100.0,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark06(-0.04596556755028144,-1.5707963267948966,5.457298040374512 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark06(-0.04612542846865116,-44.28734574565412,-1.5707963267948966 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark06(-0.046434963840252474,-3.141592653597825,-0.026929961107965413 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark06(-0.046703803854066805,-0.05582571859008895,-5.376953602629058 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark06(-0.04677604725269525,-38.85476346140047,-1.574702576809839 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark06(-0.04679821906621573,-94.30180227253472,-82.72054426032908 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark06(-0.047150390998977665,-31.841147332026566,-0.6806136090336319 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark06(-0.047159465106884124,-1.5707963267948966,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark06(-0.04736394721883901,-1.5707963267948966,-8.767237396033612E-193 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark06(-0.0474342489936769,-0.4367130806539418,13.98226502431304 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark06(-0.04793223037053451,-1.2768777547706527,66.52887671743005 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark06(-0.049207874705571954,-1.5707963267948966,37.7317427178932 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark06(-0.05050848391971915,-1.5707963267948966,-1.23373028821992 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark06(-0.05092675063536101,-1.2708107067445742,16.137166941160938 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark06(-0.05096273953217406,-1.5707963267948983,-64.18290539939274 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark06(0.051466075391815025,94.44781192056396,18.621311844691064 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark06(-0.05202570516470939,-158.44374574960588,-163.97852287041854 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark06(-0.05299137533619486,-1.4557265454920127,-38.694988757089746 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark06(-0.053031189841284965,-0.7051805772900328,-4.504556067550126 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark06(-0.05325396567424434,-0.2947098970403417,0.0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark06(-0.05356345712765038,-1.5707963267948966,-82.26046350766269 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark06(-0.0539534973123148,-45.36777285390219,-107.69783501541593 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark06(-0.05441657026667884,-1.5707963267949026,33.43148958990483 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark06(-0.0546907003690833,-0.9870274616539647,1.5707963267948966 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark06(-0.05475957997032361,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark06(-0.05484901959691339,-0.28048405059334075,85.12187888386718 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark06(-0.054996015800588216,-1.5707963267948988,-65.97395883174363 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark06(-0.05556998204542675,4.3368086899420177E-19,38.488432417259155 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark06(-0.05594741548496929,-0.3259470144627574,-33.19867453866197 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark06(-0.0563071131231527,-7.105427357601002E-15,-71.80790049236069 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark06(-0.05679409936949542,-1.4271068706351249,51.65557580685955 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark06(-0.05684968685594288,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark06(-0.05729923730001829,-0.9945475397779284,-121.03601201718902 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark06(-0.0573729403349707,-3.8725919148493183E-121,1.5707963267948912 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark06(-0.059700616440077625,-0.2508930289668683,0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark06(-0.05978048565020703,2.465190328815662E-32,90.44251949945215 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark06(-0.060481181502864564,-0.07097056828754127,32.71051139526472 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark06(-0.060594048407167894,-0.10781213017336122,65.1827676240938 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark06(-0.06104997717726717,-1.5707963267948966,817.0579100118508 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark06(-0.06165804701658501,-1.5707963267948966,0.7706530639388331 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark06(-0.061678741029627115,-1.2317920539146878,63.05556501924445 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark06(-0.0618850773029912,-1.2258964621130253,9.424995293657544 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark06(-0.062491162682039914,-0.7428955873818666,-57.05727840846248 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark06(-0.06301691586950142,-55.27899514921742,0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark06(-0.06318725109602497,-1.5707963267948966,-603.5704060261642 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark06(-0.06366206584581846,-31.486564405535468,-65.68673207884164 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark06(-0.06376078794356488,-1.5707963267948961,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark06(-0.06428375887486373,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark06(-0.06477006776858751,1.5707963267948966,-2284.0221728538877 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark06(-0.06692577157072901,-1.16669199484193,53.30835600793293 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark06(-0.06715939861824385,-1.5707963267948966,-44.41493128311963 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark06(-0.0672873781422578,-0.7076554322198376,-65.59151859517867 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark06(-0.06746172814399792,-1.5707963267948966,80.4861827386284 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark06(-0.06778849767880463,-1.5707963267948983,37.06111566156051 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark06(-0.06794144999129177,-0.5402558495038672,-14.775025223417003 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark06(-0.0682461232865913,-1.5707963267948948,-438.7198410902334 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark06(-0.06881233565611827,-45.00848204276359,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark06(-0.06909559014545308,-1.5707963267948966,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark06(-0.06922990590222267,-1.5707963267948966,59.9415097122176 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark06(-0.06923228427620565,-0.6537824705492087,4.686906918145617 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark06(-0.06953808113248919,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark06(-0.07016716570837506,-1.5707963267948966,27.670462676717964 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark06(-0.07095253896747095,-1.5012852612544083,20.95280617431679 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark06(-0.07179780084908685,-0.28830973653534997,-100.0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark06(-0.07296242761272254,-0.9058735736913355,37.699141523591294 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark06(-0.07466483239633703,-1.5707963267948948,-26.895718663393936 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark06(-0.07471638964570104,-1.5707963267948948,-85.48035998058738 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark06(-0.07549364908780276,-1.5707963267948966,1.7882792444867945 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark06(-0.07621765886509792,-1.5707963267948966,-47.59231806302566 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark06(-0.07636962262050417,-44.26741862777747,-20.773706138096784 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark06(-0.07650257039303332,-1.5707963267948966,18.806145404834098 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark06(-0.07676067832332036,-3.606632272572553E-130,-9.268786388881807 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark06(-0.07686420758061108,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark06(-0.0770606311405524,-1.5707963267948966,-55.46552202798365 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark06(-0.0775609235950106,-31.415926535906138,-0.001899830625719659 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark06(-0.0776463493126509,-1.5707963267948966,-5.595426800945958 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark06(-0.07797646377147105,-19.35180411820736,-58.18584045728802 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark06(-0.07853114648942752,-1.5707963267948966,-6.547416431822462 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark06(-0.07889447332004762,-1.5707963267948966,130.06521591150462 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark06(-0.07900491251406003,76.4853965974101,0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark06(-0.07973015157924952,-1.5707963267948948,12.803243242818809 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark06(-0.08002399218253604,-1.5707963267948966,-86.95492583810625 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark06(-0.08040039058252826,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark06(-0.08047242846600092,-0.03297627665607848,-20.81672199854558 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark06(-0.08069176807299917,-1.5707963267779357,53.71257251196273 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark06(-0.08180678554853721,-100.97449359950254,-1.5707963229563364 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark06(-0.08222733139336226,-0.1089125419820014,-9.659914499888387 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark06(-0.0826840571818201,-1.5707963267948966,-96.87007355039584 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark06(-0.08299250230382527,0.0,0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark06(-0.0830053672001888,-0.779631288662429,-2.5707954955943846 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark06(-0.08307782304997675,1.5707963267948966,-21.95884826026334 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark06(-0.08346648730153032,-1.5707962861981881,39.13455814724243 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark06(-0.08477492116153203,-1.5707963267948966,1.5707963217163472 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark06(-0.08508250970974096,-32.675371995261145,-83.77317931783492 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark06(-0.08541561987662681,1.5707963267948966,-84.82300164692441 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark06(-0.08606984942640446,-0.6418981961775052,-17.34394714198604 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark06(-0.08633951586257993,1.3234889800848443E-23,100.0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark06(-0.0864015869768777,-1.5707963231984694,-0.7359573092967686 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark06(-0.08742851969834398,-0.39690318392648116,-68.75845399799151 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark06(-0.087784668860445,-0.34794242468050585,0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark06(-0.08820690199508979,-0.30581962025022563,-4.90615755103034 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark06(-0.08822501679593352,-1.5707963267948966,-2.0707963324324488 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark06(-0.08825971630285157,-0.7130913120301292,31.30631690604711 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark06(-0.08875972894449458,-83.49542527802582,-1.5708269548778453 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark06(-0.08956335855724262,-140.9254626457706,6.712389555973385 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark06(-0.08969662809382051,-1.497210915335691,0.039159825193123665 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark06(-0.09211944673087213,-0.6268277822391208,-1.5707945216151522 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark06(-0.09215749425220729,-30.660942428075046,0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark06(-0.09223269201597664,-1.5707963267948966,72.28176102894035 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark06(-0.09342016813630405,-32.912134486128245,-1.5707963267948983 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark06(-0.09344544427227792,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark06(-0.09350370373562897,-8.282118181036177,-88.11980528796656 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark06(-0.09411070153949572,-1.5707963267948966,3.0878009166640257 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark06(-0.0942466576471416,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark06(-0.09437349083381864,-38.773356163676816,-44.02579302240846 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark06(-0.09446686100230162,1.0842021724855044E-19,4.7675253076655855 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark06(-0.09491499370061818,-1.5707963267948966,-32.72583558096291 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark06(-0.09498509436872109,-1.2072301033322745,-4.758496435999961 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark06(-0.09529391597685732,-1.5707963267948966,24.088875518879156 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark06(-0.09567460773530811,-1.734723475976807E-18,-88.42708558620988 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark06(-0.09598448137430537,-0.8285976852595986,1.5707963267949019 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark06(-0.09660372421096497,-1.4568191871609457,-95.84631755074295 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark06(-0.0968135546675856,-0.29938258012149144,-95.15513069545199 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark06(-0.09699553728921384,1.5707963267948966,-1.5707963267949054 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark06(-0.09771878172504994,-6.6174449004242214E-24,-97.57100022781698 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark06(-0.09775239253523538,1.5707963267948966,-42.41228011358771 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark06(-0.09858432564822428,-1.1269253134558097,0.0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark06(-0.09872163015847213,-31.415926535897942,-2.485868008264802 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark06(-0.09874010582905213,0.07700198575881785,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark06(-0.09899327071589703,109.0595795874568,0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark06(-0.09975302374436623,-1.5707963267948966,-88.35091668327773 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark06(-0.09992766304022371,-88.17995996735269,6.712403513347736 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark06(-0.10028689304305605,-1.5707963267948983,1.5707963267948966 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark06(-0.10041572193209036,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark06(-0.10271460931441245,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark06(-0.1038603333194718,-0.9967311235211515,94.80052058879495 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark06(-0.1041612660651219,-1.5707963267948966,4.440892098500626E-16 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark06(-0.10607897099001151,-1.5707963267948966,-0.08134464424821346 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark06(-0.10675942620964365,-1.3721780610517074,-84.02868176333726 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark06(-0.10680852691383114,-1.5707963266063478,100.0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark06(-0.10729763254261446,-32.51047111519336,-64.61642349554688 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark06(-0.10764419707506424,-163.37721167875864,-1.5707963267948983 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark06(-0.10811191124048847,-1.5707963267948966,62.03808284263053 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark06(-0.10867599961173369,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark06(-0.10935629422411505,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark06(-0.10938184875702191,-1.5707963267948966,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark06(-0.10974258355482605,8.470329472543003E-22,-57.796708370746565 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark06(-0.11021812444669488,-1.5707963267948966,-0.0101936780930509 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark06(-0.11080820911674749,-37.93314691353628,-58.532996590911466 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark06(-0.11106284718963684,-1.5707963267948966,17.28506897213771 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark06(-0.1110679892257962,-1.5707963267948963,88.22077943619192 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark06(-0.11165166758867012,-88.25355705987802,-39.73111203656388 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark06(-0.11299874377077714,-1.5707963267948966,-85.93614863382152 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark06(-0.11317359808068517,-0.4715961191935032,43.715937699508466 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark06(-0.11361848073411307,-1.5707963267948966,1.5707963267948974 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark06(-0.11394869506019956,-0.0013941531060546648,50.41165549798581 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark06(-0.11400736980866177,-1.5707963267948966,-60.00095173905113 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark06(-0.11409278563944798,2.465190328815662E-32,1.5707963267948966 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark06(-0.11498500153614832,-95.5759931469482,-26.94435171706712 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark06(-0.1151248217912604,-32.449188454872086,-1.5707963267948966 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark06(-0.11580108835251696,-1.5707963267948912,59.844302061319155 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark06(-0.11597908770286493,-1.5707963267948966,-16.573111506682533 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark06(-0.11649891301833788,1.5707963267948966,-31.60401636020147 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark06(-0.11687599041671137,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark06(-0.11716597864593915,-1.5707963267948966,-16.403602114295232 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark06(-0.11718027281132681,1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark06(-0.11834780355384489,1.5707963267948966,-4.790961782958064 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark06(-0.11849025250283854,-1.2180270011077485,55.789652890979546 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark06(-0.11869333371957157,1.5707963267948966,-6.604895879289027 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark06(-0.11959005205699874,-1.7763568394002505E-15,92.095932232916 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark06(-0.11963068009324862,-0.00727349022162993,61.753292022884324 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark06(-0.1197108818894711,-0.09533104995859162,-6.549785705028103 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark06(-0.12010022910912035,-1.1145187142413753,-88.18216901232748 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark06(-0.12120974658352517,-0.09470844481566613,1.5707963267948966 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark06(-0.1220746600454159,-1.5707963267948966,65.34600606083481 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark06(-0.12262266682572137,-8.272560132855332,-6.5824121510921 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark06(-0.12292571023892618,1.0555488223182004E-16,-0.5596799659371925 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark06(-0.12313468787697898,-31.920261561611717,-2.3116162990550464 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark06(-0.12342568291267075,-0.19308628025974317,-0.27253537323690347 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark06(-0.12443311454980188,-0.027551827211820423,7.194061762745342 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark06(-0.12476887218350163,-1.2806649395333725,15.724734060978534 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark06(-0.12524163272688,-32.59794326667278,-19.766389107613463 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark06(-0.12600361023596435,-88.45975552182612,-31.415927040780733 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark06(-0.12739625798733245,-1.3668436490725187,95.2665510952262 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark06(-0.12748635845139233,-37.90676463404795,-37.91690538020334 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark06(-0.1279843924129213,-0.21714241630391376,-73.78694333441015 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark06(-0.12801537569399038,-1.1102230246251565E-16,37.633274683626496 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark06(-0.12806440781157846,-1.5707963267948983,-46.831121524101846 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark06(-0.12896298211225604,-1.5707963267948966,-37.69911184307752 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark06(-0.12902108314804117,-0.5153333866219392,51.00084817632741 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark06(-0.12907129760831898,-1.5707963267948966,-35.33580154523919 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark06(-0.12945011342639512,-0.16423249247668012,0.0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark06(-0.12962603613190993,-214.7899675750629,-12.783229211923214 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark06(-0.13032293300501394,2.465190328815662E-32,-4.234138051535609 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark06(-0.13076835093399738,-0.6570929648278182,-1.5707963267948966 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark06(-0.1324601356933236,-0.7374260507332178,35.31162071548603 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark06(-0.13338763861288316,-0.2667920256308802,45.03380679793285 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark06(-0.13424786124939156,-88.16819523256069,-1.5707963267948966 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark06(-0.13461226119792163,-1.3457101336324047,-6.712433417395273 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark06(-0.1351387919300786,-1.1480633972148755,31.364878471201962 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark06(-0.13590870125247534,-1.5707963267948966,-43.2971533090995 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark06(-0.1362868352289084,-0.010953701762720461,1.5707963267948966 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark06(-0.13633067620234587,-1.5707963267948966,-3.2665926579424958 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark06(-0.13854851456459133,-0.13779945394839915,1.5707963267948966 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark06(-0.1396788907771665,-19.40440047331102,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark06(-0.13989571608394336,-1.5707963267948966,1.5707963267948957 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark06(-0.1410805802165925,0.0,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark06(-0.141196038163178,-0.9697811805935174,-1.570794897918746 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark06(-0.14120272880418738,-1.5707963267948966,-9.63944755493359 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark06(-0.1412882191012952,-0.8354098710355392,23.832373036810992 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark06(-0.14131879484271345,2.465190328815662E-32,-11.23644685506501 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark06(-0.14153111549041442,-1.5707963267948966,21.77855204273189 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark06(-0.14273169586061862,-0.947320635791477,-55.012092846062515 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark06(-0.1428468974890895,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark06(-0.14306063283603532,-95.44919500733978,-12.592807566854535 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark06(-0.14335041753077538,-1.5707963267948966,-64.42532209006492 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark06(-0.14376392773353794,-81.82496314845874,2.017598601576389 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark06(-0.14453200966346716,-157.55657369997255,-53.325367157558865 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark06(-0.14467816605244832,-2.002083095183101E-146,67.09033237263307 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark06(-0.14482568641969684,-1.5707963267948966,-1.5707963267951754 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark06(-0.14511258885155254,-1.570796326794896,101.9912875501189 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark06(-0.14575180846661517,-0.6332085318011474,19.398214204970262 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark06(-0.14591593893765253,-19.357300018285862,-157.54797137152354 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark06(-0.14642016412522804,-3.552713678800501E-15,-26.144044522303247 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark06(-0.14688077386197002,-0.14065624260879622,62.02717279276659 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark06(-0.14819994423159166,1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark06(-0.14833394059568974,-1.5707963267948966,84.82300927631937 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark06(0.14852899978459433,1.549918941424332,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark06(-0.14876947024345205,-0.8517184365979702,-0.29694518358013144 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark06(-0.1492865416073741,-1.5707963267948948,-98.30998274159968 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark06(-0.1496934516752991,-1.5156781649221776,84.94480922932942 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark06(-0.15161100876585926,-37.761692387149154,-1.5707963267948966 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark06(-0.15163092753100682,-31.82907590485712,-45.327119141734286 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark06(-0.15172937164518674,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark06(-0.15216370246660738,-32.68149403418929,-6.449418353168953 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark06(-0.1531069180163218,-0.34071919888390934,310.44421031502543 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark06(-0.15336531325559702,-95.6122233882561,-3.130977214913172 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark06(-0.15347534746067445,-1.4778702990990945E-15,-52.24096286861919 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark06(-0.15369599046410798,-1.5707963267948966,-82.48922079130213 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark06(-0.1539663196807872,-31.41592653654261,-1.5707963267948966 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark06(0.15482409599244107,-2.342413409327471,0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark06(-0.154832583139195,5.421010862427522E-20,-53.23465006110722 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark06(-0.15567130692052655,-0.08807119683496861,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark06(-0.15637408719501417,-0.8221635689944362,122.95641896514424 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark06(0.156724282060862,-1.5707963267948966,12.05699246792687 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark06(-0.1570909450538329,-2.7755575615628914E-17,1.5707963267948966 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark06(-0.1570994969345793,-3.1415926535897936,-31.862973295626645 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark06(-0.15712466126921032,-1.5707963267948983,14.137174570728853 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark06(-0.15731691261155592,-31.415926535910742,-113.52454938709073 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark06(0.15777452727634414,-82.10854631434921,25.86635136126217 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark06(-0.1582383161073928,-3.141592653589793,-0.35412228815933844 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark06(-0.15860146399846695,-0.14668387450338363,0.0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark06(-0.15878796812431395,1.5707963267948968,0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark06(-0.15986947331531007,-0.21223745452883228,4.8066626768753995 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark06(-0.15990609789906784,-1.5707963267948966,4.709151570980993 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark06(-0.1599496487393588,-37.9275156135888,-1.5239266414448103 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark06(-0.16005490778981157,-44.53825199087416,0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark06(-0.1605961897339996,-1.2940487107253325,-44.33167356760787 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark06(-0.16152239791861978,-1.5707963267948966,-31.41608381647004 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark06(-0.1626287720540227,-0.7141234055039132,63.187002421482276 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark06(-0.16310634333276652,-1.5707963264284588,-20.62746416876269 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark06(-0.1635303809465651,-38.78493609256515,-100.75099754423317 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark06(-0.16384288847964504,-1.5707963267948912,4.211359950575655 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark06(-0.1638906715039461,-1.570586942394506,-3.1896517722980704 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark06(-0.1640397378575418,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark06(-0.1644979451152444,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark06(-0.1652938178595011,-31.41592653590216,-33.98512285267212 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark06(-0.16543127225560045,-1.5707963254674016,-0.21636190414293482 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark06(-0.1660864408907558,-1.5707963267948966,4.712397238429001 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark06(-0.16763038295784052,-0.8214328665629749,3.141592653589793 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark06(-0.16843869146669935,-39.21459135932053,-56.5605657377868 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark06(-0.16860747232343715,-0.03228670449866597,1.5747036781625137 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark06(-0.16865391650962838,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark06(-0.17049020472023366,-1.5707963267948966,-77.19460140160301 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark06(-0.17275660296668655,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark06(-0.17355009738345692,-1.5707963267948966,1.0232010572010792 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark06(-0.17360856731648655,-1.2122033188130674,498.89529570219014 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark06(-0.17550529819363758,-0.5609950932307707,-71.62990700361269 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark06(-0.17552106983996119,-1.5707963267948966,-17.278759716927404 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark06(-0.17555138847421858,-1.4112092479460978,182.8898594265147 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark06(-0.17592315727066865,-0.9992384317185481,-7.859514053505497 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark06(-0.17647799782787119,-1.259277221315597,58.27502910879346 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark06(-0.17749266835463118,-1.3397262307746798,37.78318627162969 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark06(-0.1779197933608416,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark06(-0.1782493490612513,-3.141592653699373,100.0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark06(-0.17868959335262694,-1.3854014602332474,17.985443311147876 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark06(-0.17884424348144376,0,0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark06(-0.17911153868192137,0.0,0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark06(-0.1792556440820996,-0.6020868440437039,17.98980692689993 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark06(-0.17955429496085173,3.2311742677852644E-27,-62.986908843417346 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark06(-0.18030161714185056,-0.8181238386795109,1.485941488701135 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark06(-0.1804260035928179,-75.9658169072513,0.0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark06(-0.18099158855741693,-0.1636075576861607,119.3834293347119 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark06(-0.18236307205290264,-0.10229321619583454,0.0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark06(-0.1824704750269622,1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark06(-0.18392494398043016,-1.5707963267948963,66.24524111139118 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark06(-0.18400390176397896,-1.5707963267948966,-14.567249846719058 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark06(-0.18435978735113645,-1.5707963267948961,520.3152136745848 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark06(-0.1843818403664057,-2.156210484219044E-15,119.27470818508195 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark06(-0.18445441887302827,-1.5707963267948966,37.09534061981938 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark06(-0.1845153996925449,1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark06(-0.18499865371046095,-72.29415164110723,0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark06(-0.18516212827661838,-26.656023266967537,-88.91848023483422 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark06(-0.18517719289260026,-1.4456620261567932,0.0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark06(-0.18564498053424927,-1.5707963267948966,47.38080098624215 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark06(-0.18673847931689946,7.367562884564881E-9,153.44354341967585 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark06(-0.18707133437447376,-45.021085866942876,-94.25863031962841 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark06(-0.18976171951399579,-1.0997790573707582,-9.741385361375139 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark06(-0.189920513012842,-1.12423826495162,-54.97787144361538 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark06(-0.19138293405341084,-45.15073790067503,-70.89860267844519 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark06(-0.19180265294192722,-84.82113817775863,-1.5707963267948983 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark06(-0.1919942933951812,-0.4415125983319842,47.88441363105542 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark06(-0.19276904616583315,-1.5707963267948966,-64.91901879400478 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark06(-0.1928327263861368,1.5707963267948966,-12.215115365978718 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark06(-0.19302329309117283,-1.5707963267948966,3.2286670031766533 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark06(-0.19330123639713293,-1.5707963267948966,-68.31702632747421 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark06(-0.19342457842313054,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark06(-0.19365697553628736,-95.43307800528655,-2.5995558142908237 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark06(-0.19390013505697823,-0.9492903574055305,-53.60864613422016 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark06(-0.19452653826123423,-1.5707963267948912,-67.37174980423038 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark06(-0.19471079531433944,-1.5707963267948966,-71.61718024632364 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark06(-0.19496514285481448,-0.17321165545595396,-68.4944412609755 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark06(-0.19722171238083305,-0.45503764229500243,3.155257987537713 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark06(-0.1972529686561053,-84.64695514293865,2.220446049250313E-16 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark06(-0.19904097727196407,-2.220446049250313E-16,-60.144759701808596 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark06(-0.1991472294275347,-1.5707963267948966,99.32899586222956 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark06(-0.19991776599383027,-1.4023773936165775,52.783484769329945 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark06(-0.20101414665062317,-88.48855985081826,-32.79209283156261 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark06(-0.2014854650980944,-0.28768873465491396,0.3073417252213546 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark06(-0.20170377129801909,0.0,0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark06(-0.20176094986320667,-44.23217948683048,-1.0199586884363931 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark06(0.20217336358884533,1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark06(-0.20229307216683623,0.0,0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark06(-0.20426680396657915,-1.034522632780076,38.758106003614785 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark06(-0.20450604420433,-44.54856481780685,-82.86231923713086 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark06(-0.2064631453365206,-1.5707963267948966,10.997527412564729 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark06(-0.20703153240143415,-32.47109129000873,-1.5707963267948974 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark06(-0.2072689705727644,-100.6422791647163,-1.5707963199238382 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark06(-0.20734290829921823,-1.5707963267948966,97.5086333511705 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark06(-0.20749285244696958,-1.5707963267948966,-85.60731426026133 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark06(-0.2080545773735878,-39.14277501287438,-0.15197538095353424 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark06(-0.21151804923464046,-1.1906641843918708,-474.1493934140261 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark06(-0.21155901112806563,-0.3220032788833873,0.0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark06(-0.2118836107143149,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark06(-0.2131264939722947,1.3877787807814457E-17,-1.5707963267948963 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark06(-0.21383228261827147,-1.5707963267948966,-41.48489857191002 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark06(-0.2143120519998689,-164.93271816563163,-1.5707963267948966 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark06(-0.21434301521911525,-0.715205625002543,-397.4537907753222 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark06(-0.21551741156579873,-8.103981633976346,-32.47238940163383 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark06(-0.2157338804463515,-1.5707963267948966,85.17953387323936 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark06(-0.21583242651035767,-32.921143362026385,-70.32472137744986 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark06(-0.21789057581132412,-95.70308125791685,-51.10080186509127 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark06(-0.21971558526125445,-1.5707963267948806,32.582984657393844 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark06(-0.22024396551552333,-0.055998228114719995,-4.882235493522978 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark06(-0.22065217595328007,-45.553093476979704,-1.5707963267948983 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark06(-0.22112235792238208,29.539296380419444,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark06(-0.2217924875213549,-45.24219467011507,-69.94967015698728 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark06(-0.22208292434598229,-0.150609553838585,-53.95951791403122 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark06(-0.2226696334796543,-1.5707963267948912,-31.638577454210946 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark06(-0.22322700245862126,-101.05390990998377,6.712389412920831 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark06(-0.2234990765044671,-1.3239746926772538,1.5707963267948966 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark06(-0.22451309973400144,-1.5707963267948966,-99.95051248970125 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark06(-0.22453921435396484,-45.19435853827727,-1.5707963267949054 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark06(-0.2251691055325107,-38.988390707680985,-31.96547027328539 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark06(-0.2256487611211071,-0.5658947380051195,-1.441356396933796 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark06(-0.2262640092983707,-0.9850253666109601,7.8617997448506705 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark06(-0.2262688663821582,-1.5707963267948966,-102.10174563916658 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark06(-0.22646073993964475,-32.74163704694435,-1.8829828552430712 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark06(-0.22765413498001785,-31.50617111775726,-1.5707963267948966 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark06(-0.22766159974381198,-0.03353279012835253,31.683713193489616 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark06(-0.22971595197034747,-44.2134626449268,-1.570796326794897 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark06(-0.22985145666556533,-164.55917230746064,-52.82354048146558 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark06(-0.22986655774554254,-31.415926539083923,-57.488948972134494 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark06(-0.2299058447951836,-1.5323616231582433,4.718458252311052 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark06(-0.23009691446706537,1.5707963267948966,0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark06(-0.23031889841221376,-1.5707963267948961,88.7868740490434 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark06(-0.23033535599769708,-1.3545238344028392,1.5707963267948963 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark06(-0.23183115233057197,-5.169878828456423E-26,91.259018779184 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark06(-0.23238783856667394,-19.34955592154581,-25.819803002913204 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark06(-0.23251054302044366,-1.1876717759045048,-3.141589074851117 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark06(-0.2346098946128783,-0.3778939076688812,95.40404046270802 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark06(-0.23599260224858443,0.3860310204500905,0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark06(-0.2361832592359745,-88.40693370297998,-31.415937732778517 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark06(-0.23910311549561114,-1.4589989532562162,-85.5122418602815 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark06(-0.23980667429324393,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark06(-0.24178230771705012,-1.5707963267948983,417.16526589217284 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark06(-0.24180838784830733,-101.60415911476673,-1.5707963267948983 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark06(-0.24203802901673385,-1.5707963267948966,68.7054241191112 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark06(-0.243060037904504,-0.009879677106984175,15.910563416613684 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark06(-0.24364465219576292,-5.551115123125783E-17,1.5707963267948966 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark06(-0.24507414862719734,-1.5707963267948983,68.53408924693906 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark06(-0.24665387541538963,-0.059135689189809264,-1.5707963267948966 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark06(-0.2468798292974666,-2.7664523314090327E-222,-1.5707963267948966 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark06(-0.24758972875559382,-1.5625418938264575,0.0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark06(-0.24870365854162735,-1.5707963267948966,-27.79673631628573 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark06(-0.24957428633302808,-3.141592654828202,22.382181098643837 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark06(-0.25022015650710877,-1.5707963267948966,-96.52410243996037 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark06(-0.25110537686095835,-1.5707963267948983,80.53210423794046 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark06(-0.25185540993372224,-1.5707963267948966,63.0879653095181 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark06(-0.25266655207162936,-0.6452983172261965,-93.19174804031105 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark06(-0.2532971023122528,-3.8528331613476576E-14,-18.760595187629775 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark06(-0.2535191825176839,-1.5659954815515904,-59.690260418206066 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark06(-0.25428687941655426,-1.0933497731899027,-1.5707963267948966 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark06(-0.25465901182499984,-0.2881730717028326,0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark06(-0.25637520421060533,-1.5707963267948966,6.938893903907228E-18 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark06(-0.2568199321640895,-1.5707963267948966,77.78809586010544 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark06(-0.25684006189594716,2.465190328815662E-32,68.31114813254278 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark06(-0.2569388188467752,-1.5707963267948966,-38.331634329622084 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark06(-0.257078727461439,-0.4071693371333769,8.767237396033612E-193 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark06(-0.25711276984488823,-1.5707963267948966,-61.506136341617534 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark06(-0.25816054171460895,-1.5707963267948966,10.812293126923844 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark06(-0.25892906477151256,-0.3453290242950227,-0.006523632213186045 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark06(-0.2593881573962151,-95.78452339917735,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark06(-0.25946487772273474,-0.15178661069934887,37.00105782559311 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark06(-0.25981521012509734,-0.4642754701902293,-6.452607746795714 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark06(-0.26098561905661066,-1.5707963267948966,10.995465232706676 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark06(-0.2611487076122914,-1.5707963267948966,-45.32488866763052 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark06(-0.26117472721709567,-43.99494592830092,-1.459523705798957 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark06(-0.262540045415121,-1.5707963267948966,-68.24423192581794 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark06(-0.26285744594438665,-32.94975232253512,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark06(-0.26321802109066894,-0.8174298729782199,-30.730349778283184 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark06(-0.2642507388077656,-0.8485767041515065,4.392991174941328 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark06(-0.2642655172531905,-1.5707963267948912,85.69739907573053 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark06(-0.26426675333921207,-1.5707963267948966,-3.266616310184263 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark06(-0.26541693046783443,-1.5707963267948972,42.57391897214093 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark06(-0.2656347439533814,-1.2529290863812204,-105.49229346887067 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark06(-0.2657983332194565,-1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark06(-0.26648868718981555,-1.5707963267948966,658.8208598415205 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark06(-0.26655361222371216,-0.04179444381226549,-36.850316273962655 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark06(-0.26839090076601096,-1.5707963267948966,52.854660244693065 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark06(-0.26939472051936775,-1.5707963267948966,1.1278624374531592 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark06(-0.2696680127417653,-5.332333791316433E-4,1.570796326794897 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark06(-0.2697037751665802,-1.5707963267948966,21.627778580209878 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark06(-0.2697718831228425,-1.4212137819228008,3.833245992152996 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark06(-0.2701960443935363,-1.5707963267948948,-45.52791424715319 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark06(-0.27059096450971354,-4.5082903407156913E-131,72.60664415723329 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark06(-0.2719275481958334,-1.430908376167331,1.778206999588062E-161 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark06(-0.2729545019174023,-0.0018146441957552553,45.13775474794846 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark06(-0.27296841951463224,-1.5707963267948966,-24.73675239924116 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark06(-0.2732291676076375,-1.4210854715202004E-14,-1.5707963267948983 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark06(-0.27346339798883723,-1.5707963267948966,16.955762991347413 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark06(-0.2739008126474378,-0.18297485904040628,-1.5707963267948966 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark06(-0.27478093998553715,-95.66333453253128,-19.943571487806395 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark06(-0.2748074034766989,-0.9278140427383823,-1.4398919582770946 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark06(-0.2750572826309705,-1.5707963267948966,67.49091206546746 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark06(-0.2754972518913621,-1.2979782463014085,-86.52274937716177 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark06(-0.2758341442308172,-44.49407439657091,-1.5707963267948966 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark06(0.2764310747155382,1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark06(-0.2764787678202083,-1.5707963267948948,-87.13137530614206 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark06(-0.2787767042756286,-1.154122327223217E-128,-95.35735050004936 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark06(-0.279227410986265,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark06(-0.27924946386456556,-0.06552590078583498,-67.610601403488 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark06(-0.2794347558854078,-88.13174305531521,-164.6299728553642 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark06(-0.279885838250312,-38.77415861236189,-89.33742804818534 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark06(-0.2824849371284483,-0.698803807978257,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark06(-0.2828065978379035,-1.058168100738168,61.90357635924113 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark06(-0.282822377336985,-1.5707963267948983,-1.5707963267948948 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark06(-0.28346546534017536,-1.2651170839122832,9.776561356381366 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark06(-0.2836358516133953,-1.5707963267948966,3.2665954787561757 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark06(0.2840338413240019,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark06(-0.28415063619804826,-1.5707963267948966,-34.34596967174186 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark06(-0.2846334804087648,-1.5470320555035755,100.0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark06(-0.28593886165792504,-1.5707963267948966,8.103981746426346 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark06(-0.28637849635650287,-1.5707963267948966,16.247740371111448 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark06(-0.28649650267207727,-0.48358913356944194,9.424782657835292 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark06(-0.2865957456833963,-1.5126426234750658,54.191676992634996 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark06(-0.2867058223311304,1.5707963267948966,-70.94968248288565 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark06(-0.2868722095448817,-0.3294212137290913,-11.189963036828956 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark06(-0.28693250998138636,-38.69946155133352,-1.5707963222768744 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark06(-0.2879009038294591,-1.5707963267948966,-16.863089447223306 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark06(-0.28842765943758203,-31.41592653590095,-1.5707963267949054 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark06(-0.28890899740700166,-1.5707963267948966,14.477114933399179 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark06(-0.28916457083980435,-1.5707963267948948,2364.1461236322616 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark06(-0.29126296983024824,-158.24672163274178,-8.838195083909753 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark06(-0.29156518033425183,-1.40909997914916,-100.0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark06(-0.29225787220757077,-19.363805720176416,-1.570796326794896 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark06(-0.29480808220301,66.854299822618,0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark06(-0.2951239616740094,6.776263578034403E-21,-94.26626993844756 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark06(-0.29512804257827163,-1.5707963267948983,1.5707963267948974 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark06(-0.29528410998719234,-1.5707963267948966,70.70528374577273 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark06(-0.29551738185025234,-1.5707963267948966,-1.5707963267948946 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark06(-0.2966040946962809,-38.74981518936409,-15.516052745062055 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark06(-0.29684679611666986,-1.5707963267948966,-3.1415926535897936 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark06(-0.29706240474042644,-52.54036498755791,0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark06(-0.2986921921575931,-32.9865978042326,-94.89078721397493 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark06(-0.29870683039964874,-1.5707963267948966,65.22761513639583 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark06(-0.29942798754132766,-31.415926535911783,-38.80249948525467 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark06(0.2994992864414362,-95.29565446242209,2.651346636230177E-32 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark06(-0.2996432916527616,-0.41451144377530125,21.557633960310568 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark06(-0.29977208492149077,1.5707963267948966,-0.25683193227855583 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark06(-0.3012995483100475,-1.5707963267948966,-84.82300164692441 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark06(-0.30186803378201665,-1.5707963267948966,25.571549161573998 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark06(-0.302491530558872,2.220446049250313E-16,28.66014278566007 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark06(-0.30320555621835554,-1.5707963267948961,58.43249931377875 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark06(-0.30418086395804755,-151.34806749838302,0.0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark06(-0.3043329058701325,-45.40718943172983,-90.92693352582727 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark06(-0.3053232320507647,-1.5707963267947214,429.7248755244996 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark06(-0.3054002089981626,-164.58190293711496,-46.17902935414866 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark06(-0.3058612426850856,-0.5998002102265112,-1.5707963267948966 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark06(-0.30726307069902964,-1.570796326641419,82.86465906661272 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark06(-0.3072758967188881,-31.520390295132117,-1.570796326794898 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark06(-0.3079476708684902,1.5707963267948966,-94.58269459521874 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark06(-0.30879465289509167,-0.6623402532257765,1.5707963267948966 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark06(-0.3107199161859029,-1.5707963267948983,33.97687804369767 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark06(-0.3111492048890767,-1.5707963267948966,-43.02899844797168 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark06(-0.31115646245809625,-19.37293334198481,-38.988191293464226 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark06(-0.31148622077508287,-1.5707963267948966,-3.2665926714237075 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark06(-0.31150554822507937,-1.5707963266223406,-1.5707963267948966 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark06(-0.3129858387856519,-1.5707963267948966,72.47777271618008 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark06(-0.31417553733192183,1.5707963267948966,-47.95210785529635 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark06(-0.31455049872856516,-27.774893301742054,-71.68718320634237 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark06(0.31474144325313735,1.5707963267948963,-1.5707963267948966 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark06(-0.31487376359229885,-1.5707963267948966,0.39847765646684075 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark06(-0.3153014114546986,-5.769401977101488E-16,0.9941601000716983 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark06(-0.3165575211840306,-38.89238750545614,-1.5707963267948977 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark06(-0.31660489981417916,-47.95303275009306,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark06(-0.3167242220217198,-0.5825613698198542,284.3094468732189 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark06(-0.31727268002938147,-44.51745313155216,-13.452096305945894 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark06(-0.31778295659910855,-1.5707963267948966,32.13030756040089 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark06(-0.318180870240411,-100.90008127778788,-19.373755030305407 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark06(-0.3187148558144349,1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark06(-0.31906913771874923,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark06(-0.3197532375828572,-0.9317195004616925,-3.266592668131324 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark06(-0.319803270002887,-1.5707963267948966,-79.3338889049786 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark06(-0.31993714268113094,1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark06(-0.320125297821436,-1.4606251138854336,8.103982242823433 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark06(-0.32165607441558397,-12.888538595498183,11.02708454780596 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark06(-0.3218316349642287,-1.5707963267948966,38.70384742780567 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark06(-0.32188916513236027,-45.50998340300716,-27.40117197949607 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark06(-0.3240880940668491,-44.23968146524514,-44.60075312303254 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark06(-0.32448059604226387,-0.39535617115517435,-55.09834068632495 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark06(-0.3252852818979225,3.1076396502701793,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark06(-0.32879574686492963,-0.20265317149325102,3.2666030972541087 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark06(-0.33004451842903393,-8.881784197001252E-16,20.73226080550519 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark06(-0.33190504842738666,-1.5707963267948966,8.881784197001252E-16 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark06(-0.3322760610293827,-1.5707963267948961,3.3098316388214073 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark06(-0.3328862494162763,-1.5707963267948966,36.796089578479 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark06(-0.33343224549982553,-1.5707963267948963,-1074.2816983846799 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark06(-0.33364555644253635,-66.57739701809517,0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark06(-0.3342486808176939,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark06(-0.33471781236292575,-1.5707963267948966,-21.769754909217156 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark06(-0.33508805675693426,-32.49011848250942,-1.5707963267948966 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark06(-0.3358006913567879,5.024022365952124,0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark06(-0.336133593304308,-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark06(-0.3366558294391343,1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark06(-0.3372225101569322,-44.357041271269594,-1.5707963267948912 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark06(-0.3375889276762013,-1.570796326794895,47.499444885446344 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark06(-0.3382504826398727,-1.5707963267948966,64.95807271364103 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark06(-0.33838865907061655,-0.923829978070113,2.220446049250313E-16 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark06(-0.33862721984969113,-1.058627967162729,182.0605979052575 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark06(-0.33900167061454933,-1.5707963267948983,-60.423145510386455 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark06(-0.33994193533486994,-1.5707963267948966,-1.5707963267948877 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark06(-0.340764258232503,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark06(-0.3413066120981796,-1.5707963267948966,13.158381862991533 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark06(-0.341969769631997,-0.5106738275000307,-40.642809770258935 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark06(-0.3419934402075565,-1.5707963267948966,95.5579791847481 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark06(-0.3423551315575829,-0.1712313936238503,-92.10680463060552 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark06(-0.3425133889796566,-1.3455631806537345,-87.76562841748976 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark06(-0.3428326970964264,-0.856913817882705,-9.510393117361584 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark06(-0.3440570651915884,-1.5707963267948966,11.480070196089834 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark06(-0.3441310180473997,-45.01099357327616,-1.633300837483946 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark06(-0.34435669241832423,-0.17701973223326917,31.364842195255232 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark06(-0.3453392269975364,-1.5707963267948966,4.879054960922581 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark06(-0.34540749079464367,-1.5707963267948966,-23.267529878225133 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark06(-0.34587431202345664,-1.0728987425066303,44.29423477596456 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark06(-0.3465919257722393,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark06(-0.3472614696429754,-1.0236657570524623,53.657154376425154 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark06(-0.34757348433880364,-0.04004189939056254,73.4963739123937 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark06(-0.3487257477666242,-1.5707963267948966,5.836073021208852 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark06(-0.3489689306246141,1.5707963267948966,-16.537080623541357 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark06(-0.3495461469724418,-1.5707963267948961,-3.1538918551089905 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark06(-0.34984507731589376,-31.415926540578855,-46.017464647886904 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark06(-0.35045802695915984,-1.2937191055546151,71.91203680124694 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark06(-0.35148386626458483,-1.5707963267948966,4.374185134897411 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark06(-0.35151996531923824,-1.5707963267948966,31.416903136400403 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark06(-0.35380912852953433,-0.8553722868517992,-6.283185307179586 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark06(-0.354247690153302,-31.592895232014747,-1.57079633426264 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark06(-0.35432064632201277,-1.5707963267948966,1.5748132739214402 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark06(0.35502862551600767,0.0,0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark06(-0.35603030138526626,-81.75407196456386,0.0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark06(-0.35624431152811126,-1.5027337366902365,-85.78023628987643 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark06(-0.3565804546352867,-1.5707963267948966,23.847519483485907 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark06(-0.3566534032223267,-0.07761297764744621,14.137167106844904 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark06(-0.3566690280963738,-0.5023462274394817,-26.0567931121965 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark06(-0.35693274936174,-43.99542057014322,-0.3454170468477413 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark06(-0.35732793119700534,-1.5707963267948966,-1.4342242661830091 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark06(-0.35754117256138374,-1.5707963267948966,13.723083379795368 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark06(-0.3579004267264736,-88.37138068541381,-28.02915299095713 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark06(-0.3582768734729884,-1.570796326794897,-1.5707963267948983 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark06(-0.3589478341523797,-1.521972939450541,3.266592753243125 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark06(-0.3596357285886524,-1.1299194693531547,-52.56326668408254 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark06(-0.3596795362508918,-8.103981677944022,-159.1164108604135 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark06(-0.3604635965968943,-31.69471434762947,-0.28595416771194243 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark06(-0.36071849897638786,-0.6616905467293606,-66.00922475569203 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark06(-0.36074553817213983,-0.652489812804997,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark06(-0.36191615805657307,-1.5707963267948966,62.098008273712374 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark06(-0.36262671707892635,-88.44841046936405,-14.311107691591602 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark06(-0.3643511985120353,-1.5707963267948966,-1.5708001414923123 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark06(-0.36451743950037624,-31.415927086292395,-78.114250316107 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark06(-0.36476178565624284,-1.5707963267948966,94.94683081986182 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark06(-0.36523105786392024,-0.5173821781616958,-16.624913579229883 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark06(-0.3662020748324075,3.469446951953614E-18,-86.85854860865176 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark06(-0.3669163248179701,-1.570796326770287,-1.5707963267949054 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark06(-0.367101792011745,-32.73322027734871,-50.4946324059958 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark06(-0.3675631503056298,-19.349555921538805,-57.14667464811855 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark06(-0.3679530258302911,-1.5707963267948966,8.31208307623821 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark06(-0.3689708158296361,-0.9160243330768589,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark06(-0.36911439807107826,-1.5194161966982815,85.41802151831129 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark06(-0.3701692956771753,-1.5707963267948966,-3.2665926535898624 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark06(-0.3704372292059075,-1.5707963267948966,67.08455255598747 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark06(-0.3709422235386146,-1.5707963267948966,78.28531063907701 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark06(-0.37104844036713086,-1.5707963267948966,1.3417107499799528 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark06(0.37176452997520737,1.5707963267948966,-17.27965340547346 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark06(-0.3734678764349868,-1.5287390775878693,-736.1293985380163 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark06(-0.37375623524451845,-31.41592654097775,-51.05407559650906 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark06(-0.3739128069405808,-31.571140495373946,-83.52629686976793 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark06(-0.3745784929916359,-0.9990108110266437,3.141592653589793 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark06(-0.3759241632196098,-1.570796326517307,100.0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark06(-0.37697659565204106,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark06(-0.3801739265597134,-2.220446049250313E-16,-3.266592658882515 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark06(-0.38020996740997826,4.370897734161512,0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark06(-0.3807444532432128,1.5707963267948966,0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark06(-0.38092397870681793,-0.2839225466834043,-34.25026006781634 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark06(-0.3817715611370567,-0.5842501254615255,-70.28779123208449 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark06(-0.38183094222839414,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark06(-0.38219430331475107,-31.415926535898002,-1.5707963267948966 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark06(-0.3826311692489438,45.514138335117906,0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark06(-0.38294309125740966,-1.5707963267948948,88.46865000056073 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark06(-0.38334884571930017,-1.0700910666281178,3.141592653589794 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark06(-0.3835414049617373,-6.968735265946108,0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark06(-0.38358647606966767,-1.5707963267948963,37.69911184307752 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark06(-0.38450982712283516,-88.52658201153065,-46.076832692997606 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark06(-0.3846213304439205,-1.465988946940448,370.5825495834381 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark06(-0.3854508320041816,-0.9895697990616519,88.35339867360211 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark06(-0.3861994803861858,-1.5707963267948966,1.5707965462651177 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark06(-0.3880346593464784,-1.5707963267948966,4.493846602251519 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark06(-0.38887338375685754,-0.5100819899795418,-58.498713744969756 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark06(-0.390013749883948,-1.269435509509159,-77.12695227138393 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark06(-0.39287012842405566,-1.5707963267948966,-85.65820101995124 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark06(-0.3936492733322557,-1.2845779470061394,-67.03871783839803 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark06(-0.39396804875421176,-0.4058176725918376,-20.424258499252545 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark06(-0.39425478131769237,-88.52808521466878,-58.425704409748064 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark06(0.3957042794714546,-2341.5279026611806,0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark06(-0.39629305283534144,2.220446049250313E-16,-2.5304792112368105E-16 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark06(-0.3969054066870076,1.5707963267948966,-70.36540661912139 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark06(-0.3980880476414012,-1.0959046745042015E-193,4.440892098500626E-16 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark06(-0.39852919987084623,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark06(-0.39921116365635356,-1.3109053557294914,21.964843370653075 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark06(-0.4005182901314468,-0.14813231169004482,-71.41606425310027 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark06(0.40058680915449807,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark06(-0.4008203251697011,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark06(-0.40328957620403383,-1.5707963267948963,327.0018227743223 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark06(-0.40338769389689294,-32.62756168621512,-40.41188382950663 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark06(-0.4033877820156856,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark06(-0.4040276150788452,-1.5707963267944693,1.5707963267949125 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark06(-0.40757879160571187,-0.10633257417706019,0.03159735375153624 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark06(-0.40771822912329864,-0.3479335030109063,-43.488209041038566 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark06(-0.4079870335243022,-0.3551084381924383,-18.854371911009213 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark06(-0.40898299410952443,-1.5707963267948966,39.7161579290428 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark06(0.40929093714956,-100.0,0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark06(-0.40948904226232624,-1.5707963267948966,-40.84070449666731 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark06(-0.410107654178559,2571.128399159825,0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark06(-0.41053357004352153,-1.5707963267948966,48.662496381246235 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark06(-0.41192895375157723,-5.513962814406429E-10,103.4867037777106 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark06(-0.41228092257545845,-1.3751877786907998,8.919372537139367 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark06(-0.4125501085086274,-0.22131391094006114,78.06597711734386 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark06(-0.41265160986274163,-1.5707963267949077,0.0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark06(-0.4132657609387266,-45.422834732965754,-1.5707963267948966 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark06(-0.4144709324484853,-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark06(-0.41609244269705986,-1.5707963267948966,-6.612784079742951 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark06(-0.41686679799855186,2.465190328815662E-32,-86.68955369181306 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark06(-0.417050962787782,-3.3299958654878358E-257,1.5707963267948966 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark06(-0.41832114449185065,-5.651009533827812E-4,2.220446049250313E-16 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark06(-0.41869235020934314,-1.5707963267948966,-5.588953338708663 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark06(-0.419591443998268,-1.5707963267948966,71.40753700127297 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark06(-0.41980672595341706,-0.49231744026233315,15.651312816360345 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark06(-0.4205810029212605,-1.5707963267948966,1.5707953523948714 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark06(-0.4222325392722013,-0.34144056058090655,-24.39915718912313 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark06(-0.42262942253476066,-1.2703961962283756,1.5707963267948966 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark06(-0.4230090402208521,-1.5707963267948966,-31.392455456127106 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark06(-0.4230388246326565,-31.577675983675434,-82.0882431505594 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark06(-0.4232347863001138,-0.8447465996102994,71.54999088988701 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark06(-0.4232972198467139,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark06(-0.4257245511492769,-0.0798622407621532,37.382451213868826 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark06(0.4265693829378886,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark06(-0.42658869848730174,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark06(-0.42675401226207005,-3.141592653630399,-19.71267859418191 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark06(-0.42717290431223187,-0.9113301712437542,-16.1922851752295 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark06(-0.42739260666005346,-3.055492174378105E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark06(-0.4282645831027837,-5.775165882790782E-16,32.73765336472529 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark06(-0.42867346178624466,-1.5707963267948473,-4.836544664223523 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark06(0.43063110757480316,-0.3365251470133782,35.12040368605567 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark06(-0.43241237306464253,-1.0432559988038435,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark06(-0.43417254721723364,-1.5707963267948948,49.227861689638 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark06(-0.43520070004708444,-0.3468834181665531,-3.853362925386719 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark06(-0.4352878277044798,-1.5707963267948966,2371.8963087403 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark06(-0.4360320166919838,-1.5707963267948966,-1.4015771824385799 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark06(-0.43767108680603395,1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark06(-0.4386016961810393,-44.29936359016304,-50.66690308527694 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark06(-0.43898975741011825,-37.83158267748385,-1.5774999478439504 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark06(-0.4391571700927688,-0.23526519552717406,1.3078718426099258 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark06(-0.43958862482966454,-1.5707963267948966,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark06(-0.44028587260345375,4.7042164469966726E-23,-1.5707963267948966 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark06(-0.4404159086454906,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark06(0.44059529566192107,-1.3756713792133641,18.25060200376211 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark06(-0.44104713943777357,-1.5707963267948966,-15.707963267948966 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark06(-0.4415138835470118,-0.1682728215677869,17.96624230257182 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark06(-0.44155217126824076,-1.5707963267948961,34.877677258341016 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark06(-0.4416383424695277,1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark06(-0.44236115800410547,-1.5707963267948966,98.49159050330192 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark06(-0.44280239145601813,-1.5707963267948966,52.12721812554316 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark06(-0.44304986101602806,-1.5707963267948948,1.5707963267948966 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark06(-0.444067385990742,-1.5707963267948966,1.574703519601707 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark06(-0.4445960090260936,-0.9998562633224178,-4.712388982304958 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark06(-0.4459187640915512,-101.60817489504684,-1.1332801968400352 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark06(-0.44677517800884203,-0.37405825522739455,-1.5707963267949 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark06(-0.44751897147209696,-1.734723475976807E-18,-2.998397316817739 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark06(-0.4493974285418393,0.0,0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark06(-0.45005745410126463,2.6469779601696886E-23,31.57414582594026 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark06(-0.45006751963838904,-0.30505720943725684,1.5707963267948983 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark06(-0.4507582027570065,-100.58611735276438,-31.416034504436134 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark06(-0.450795501329565,-1.5707963267948966,-0.007707408227654809 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark06(-0.4511503505186874,-0.5807745925209566,4.7719904628979375 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark06(-0.4515964358240656,-1.5707963267948966,-31.46079319321303 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark06(-0.45209273556349827,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark06(-0.4526109375471137,-1.5707963267948966,-95.01610261406327 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark06(-0.4526949382605636,-1.402045578342047,-288.34562486837524 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark06(-0.45415398461646944,-45.261713641230436,-46.71691863384383 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark06(-0.45503811244858544,-1.5707963267948966,-57.16181228179551 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark06(-0.4552223580935383,-1.5707963267948983,-17.385373888940546 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark06(-0.45604047287579663,0.0,0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark06(-0.4560760756362823,-1.570796326794804,82.17932403095216 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark06(-0.45649814514793585,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark06(-0.4602338418386003,-1.5707963267948966,38.95643228960214 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark06(-0.4605027606700034,-0.290262451915821,17.632217686328488 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark06(0.46324051730981164,1.5707963267948966,-78.71701559539869 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark06(-0.46337701208004833,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark06(-0.46382308148128215,-1.5707963267948966,-0.44981528101570617 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark06(-0.46447068724341256,-1.5707963267948912,0.0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark06(-0.4648985833891756,-1.1357208755654582,3.7151041321485887 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark06(-0.4650394494551268,7.888609052210118E-31,9.530207380948085 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark06(-0.4663052874018856,-1.5707963267948912,-84.21336806173076 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark06(-0.4667789925072314,-0.1485761479851073,-0.014253828190016492 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark06(-0.4669063920411435,-0.010291411263954164,100.0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark06(-0.4674305013415409,-1.5707963267948966,28.124385710987077 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark06(-0.46827736333144454,-6.938893903907228E-18,-99.6734018147207 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark06(-0.4692001768405195,1.5707963267948966,-68.95298157850459 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark06(0.4705301717454814,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark06(-0.47067424196137514,14.576722531743172,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark06(-0.4708876879810866,-0.356045947029326,73.5287662472093 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark06(-0.4725870178394184,-21.505513878629024,-1.5707963267948948 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark06(-0.47303601798078493,1.0842021724855044E-19,-42.28341311311641 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark06(-0.475018283179573,-45.12625177757497,-32.54694697912164 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark06(-0.47534040263874244,-1.5707963267948966,3.1667368164345815 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark06(-0.4754901749540368,-1.570796326794893,-37.55914108516899 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark06(-0.47633950119831603,-1.3827259006847754,-89.29021574935012 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark06(-0.47798795271753086,-37.87293846154797,-3.9265161110789077 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark06(-0.4798762632371343,-0.43002569026105736,-62.025269356656025 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark06(-0.4801248369815081,-1.5707963267948912,46.25710286910558 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark06(-0.4804591583784845,-1.5707963267948966,-10.693714929114634 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark06(-0.4813889933033787,1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark06(-0.4818320310891443,-1.5707963267948966,3.1415926535897953 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark06(-0.48361507709557816,-1.5707963267948966,-39.778818203988735 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark06(-0.483629423835557,-1.5707963267948937,100.0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark06(-0.4844951368573053,-0.7344738030246223,8.250070844130143 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark06(-0.48460737671128756,-1.1091436944892001,26.762273852790678 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark06(-0.4852369589794735,-0.2620532005152292,-14.305196804255502 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark06(-0.4855943461317985,-1.5707963267948966,-2.570796323451645 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark06(-0.48942538117037415,-1.5707963267948966,429.3496044439964 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark06(-0.49048560377522227,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark06(-0.4905222931621956,-1.4818392877098279,-3.1415926521673354 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark06(-0.4907585132510417,-1.5707963267948966,46.043025292979266 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark06(-0.4909616528241752,-0.7203456542815629,19.206367278062686 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark06(-0.49220653447772444,-39.03391280769326,-3.141592653590021 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark06(-0.4924657176189541,-0.9869676633347719,-411.54862922100756 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark06(-0.49282078056767514,-1.1140323026127734,32.14823609176217 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark06(-0.49371452732649973,-1.5707963267948966,177.62731052153845 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark06(-0.4942139496002307,-1.5707963267948966,-41.401976172883614 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark06(-0.49426712152487695,-1.5707963267948966,-5.1253327236687384E-144 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark06(-0.49462939380444915,-1.5707963267948966,-67.81539718075716 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark06(-0.49840118936700833,-38.76258109218586,-77.07759930395727 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark06(-0.4984866876623788,-1.5707963267948966,1.5710668571551134 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark06(-0.4987179710813662,-1.5707963267948966,83.33806324804961 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark06(-0.49964140178394634,-1.5707963267948966,4.3956224147408705 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark06(-0.5000004066811101,-158.255446639735,-33.27671425840404 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark06(-0.5000935492070021,-1.8111358157653425E-71,-2.8208687650093533E-18 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark06(-0.5002361687415975,-0.03247165410001163,344.440509568778 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark06(-0.5005959632840545,-31.85156358044796,0.0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark06(-0.500995601387144,-0.20778905351950971,14.043274911513805 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark06(-0.5024707838479365,-1.570796326794806,-0.11691131673508981 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark06(-0.5048085224836711,-45.239777240285825,-1.5707963267948963 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark06(-0.5058134427273621,-1.5707963267948966,52.37983696886351 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark06(-0.5062254053353661,-1.5707963247029348,-52.889420831402404 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark06(-0.5063716107046699,-1.8033161362862765E-130,-96.71402322843805 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark06(-0.5069027769155513,1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark06(-0.506969238388473,-0.47530092300220517,-4.405420521749352 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark06(-0.5080083688205418,-94.28827121414209,-59.11475637721459 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark06(-0.5094065875763505,-1.5707963267948966,-34.62996199028487 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark06(-0.5103807844821462,-1.5707963267948877,35.66361670947319 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark06(-0.5106821331010832,-56.68344719622998,0.0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark06(-0.5112107727049231,-0.0829171899178281,3.6196764037240388 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark06(-0.5112325912921438,-1.5707963267948877,59.03935143885178 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark06(-0.5113796849208505,-1.5707963267948966,-37.19762203941123 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark06(-0.5115153304365544,1.5707963267948966,-62.25871707139464 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark06(-0.5120653699942932,-158.3916595728704,-108.65843755457398 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark06(-0.5125293389616506,1.5707963267948966,-91.42669814039941 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark06(-0.5149371347009487,-1.5707963267948966,39.03536175577064 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark06(-0.5157793813048854,-1.1734762659760802,-0.20845877779393526 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark06(-0.5158529851353267,-1.5707963267948968,11.34658370699033 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark06(-0.5158547356594724,2.465190328815662E-32,-63.15844867843503 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark06(-0.5162281010958302,-0.6251616067640999,-8.46791185584938 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark06(-0.5163459367656618,-0.4056141943474468,-65.27859997795507 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark06(-0.5167292462109585,-1.0642360937456663,1.5707963267948966 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark06(-0.5170725591557783,-1.5707963267948912,61.867454310381106 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark06(-0.5173845854192791,-1.5707963267948966,43.77287246312494 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark06(-0.5195672660390616,-1.5707963267948963,0.04274519277557223 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark06(-0.5197434329037879,-1.5707963267948966,17.27875959713498 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark06(-0.5203442500674784,-1.5707963267948966,26.252619958299945 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark06(-0.5208413495802178,-0.17074409410925595,-3.266592657234852 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark06(-0.5208420943650935,-1.5707963267948966,-1.5707963267948912 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark06(-0.5208812242681472,-0.4695337652347462,56.146478333365806 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark06(-0.5215900686711943,-157.10055148322613,-3.1415926535897967 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark06(-0.5221143706319296,-31.846222612409818,-15.323496732755387 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark06(-0.5223538818246725,-1.5707963267948966,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark06(-0.5246924031505733,-100.72110426887886,-45.03720160254942 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark06(-0.5247973132866102,-0.7073155922495721,-42.58589068666798 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark06(-0.524834443776329,-157.1632922067127,-40.61741596516052 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark06(-0.5253117637203022,-39.157012245586074,-164.78613357022735 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark06(-0.525590164479045,-2.220446049250313E-16,-36.7227707305674 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark06(-0.5257682274426481,-1.5707963267948966,-90.87765379203661 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark06(-0.5259186478742803,-3.1415926535897967,59.127857654181454 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark06(-0.5261857227914961,-0.8371834119187471,-2.57079162165762 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark06(-0.5270533304678553,-1.5707963267948966,-1.5809850187692929 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark06(-0.5278432937042972,-0.6213021150439904,1.5707963267948966 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark06(-0.5281570602637797,-3.552713678800501E-15,70.54422477717043 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark06(-0.5283207238819152,-1.5707963267948948,-6.469606191723116 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark06(-0.5289455211793423,-1.5707963267948966,-6.754034012229084E-226 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark06(-0.5291936441718046,-1.5707963267948966,3.1415926558326066 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark06(-0.5298469760414866,-43.982297150257104,-46.6330292624271 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark06(-0.5303564595334331,-0.8743470794723918,0.0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark06(-0.5311000273472726,-1.5707963267948966,84.14088979487921 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark06(-0.5312484105011867,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark06(-0.5334107564336451,1256.048762006573,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark06(-0.5339459951149907,-1.5707963267948966,-63.404292402261454 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark06(-0.5345012335465382,-1.5707963267948966,89.64470923322843 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark06(-0.5360980195880689,-1.3168405487598003,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark06(-0.5366431273612404,-1.5707963267948966,-33.273515005747186 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark06(-0.5373851247193668,-1.5707963267948966,-18.73335621764099 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark06(-0.5376646164432951,1.5707963267948966,-85.92272810367908 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark06(-0.5380059114840066,-1.5707963267948963,-77.62886320937244 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark06(-0.5393101657782442,-0.6056201384942893,-34.635654836793044 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark06(-0.5394140261402767,-1.5707963267948954,-69.88134690182972 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark06(-0.5401682969084658,-1.5265956700465213,-40.0629413067327 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark06(-0.5404959706976641,1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark06(-0.5409875604843372,-44.436303599476105,0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark06(-0.5411749815456969,-31.778436269709914,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark06(-0.5418202945557962,-0.6504866631593842,22.23698872714641 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark06(-0.5437440031739785,-1.5707963267948966,4.712634407952576 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark06(-0.5439934008838394,-1.5707963267948966,25.811510421288475 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark06(-0.5443892038738003,-0.3712831558776253,-70.76741637327342 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark06(-0.5445030889212491,-1.5707963267948966,67.5171341366044 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark06(-0.5445310318373231,-1.5707963267948966,47.410379137753054 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark06(-0.5447427737490534,-1.5707963267948966,-74.92438068145756 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark06(-0.546776227202469,-1.5707963267948966,2.710505431213761E-20 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark06(-0.5473850159172458,-95.74233788458231,-38.18864736205081 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark06(-0.5476013760709079,-1.5610899151401398,65.41668929032902 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark06(-0.5476452085844946,-2.2541451703578456E-131,49.7409352680639 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark06(-0.5480107065517082,-0.3553277333031064,0.9722347586579779 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark06(-0.5495825107358931,-1.570796326794883,1.1928927274973944 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark06(-0.5500987550176083,-1.4222879710493737,4.440892098500626E-16 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark06(-0.5501452595156899,-1.5707963267948966,-6.712402279927732 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark06(-0.5541515284320333,-44.291333442806064,-38.12345783040174 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark06(-0.5566244644824232,-31.415926640159483,-1.5707963267948966 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark06(-0.5574999169396193,-0.8266947751908198,8.673617379884035E-19 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark06(-0.5580913195132563,-101.7671540454398,-71.33878034959491 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark06(-0.558908315425775,-88.32033564558652,-7.736475529025638 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark06(-0.5590910284326984,-1.5707963267948966,-10.764744783177367 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark06(-0.5592387996025585,-1.570796326794898,53.89951639376639 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark06(-0.5597481947861179,-1.5707963267948966,1.5707963267948961 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark06(-0.5606005786273225,-0.941014818669119,115.08083789803818 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark06(-0.5606203711434099,-88.24289802038658,-44.42101436559446 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark06(-0.5614505861124153,-1.5707963267948966,4.929405927423375 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark06(-0.5617565599529886,-32.69547190412676,-2392.9660649082175 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark06(-0.5624512265618782,-0.4716560352778143,-84.72732769391615 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark06(-0.5638376420623676,-0.4754198724256524,-28.874454484941836 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark06(-0.5655015937757958,-1.5707963267948966,-2.3372208725905155E-15 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark06(-0.5661724816058565,-88.46201707312636,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark06(-0.566199114421849,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark06(-0.5669531702211592,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark06(-0.5674030861721557,-39.11726011110683,-69.59389499548618 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark06(-0.5685991158817523,-94.28165337242143,-71.61553980267553 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark06(-0.5695056343492684,-0.37466005855455675,49.96814044025285 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark06(-0.5695770494680412,-0.6505979041227141,-34.382646979635155 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark06(-0.5705072179515085,-0.29242407136790377,-53.126644147953115 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark06(-0.5724795578723361,-1.5707963267948966,4.749096587159905 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark06(-0.5745059151240741,-1.253116394749717,-3.266592656937645 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark06(-0.5752883666951037,-1.5707963267948966,-6.8976901766045655 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark06(-0.5757617285357738,-1.5707963267948966,-3.266592653701383 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark06(-0.5791049399914705,-0.8454684748924421,-116.3978217171302 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark06(-0.5795213803069439,-1.5707963267948963,110.84932316346229 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark06(-0.5796528469129116,-1.2232088929413092,16.645561268909663 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark06(-0.5803230524547158,-1.5099022541193392,77.32736609398117 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark06(-0.5806104978694009,-1.5543410766876014,1.570796326794897 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark06(-0.5838631736822069,-1.5707963267948957,-83.54040893616721 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark06(-0.5838726140166269,-0.6261172820115484,30.161059546981647 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark06(-0.5839508889258465,2.465190328815662E-32,-46.610622411784796 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark06(-0.584202577161324,-1.5707963267948966,63.95989451486361 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark06(-0.5847254671580964,-1.5707963267948966,0.158782615601332 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark06(-0.5857373786658787,-1.5707963267948966,-68.77797860902324 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark06(-0.5876425888607956,-1.5707963267948983,-1.5707963267948966 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark06(-0.5879028835575761,-43.98317523952843,-58.40206519686877 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark06(-0.590156142708542,-1.3531259876417279,7.114894967925095 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark06(-0.5920314615502223,-1.5707963267948966,1.5707963267948977 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark06(-0.5930591722104129,-0.6769740736487073,88.5198104959727 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark06(-0.5935148450049639,-1.5707963267948966,32.766055790776846 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark06(-0.5937749478872616,-3.1415926535906067,21.336159314291127 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark06(-0.5945636583033677,-1.57079632679487,-49.37887513224777 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark06(-0.5948121946678702,-0.9527278243895525,-3.9400230570234536 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark06(-0.595866135727178,-0.519236846563418,40.24558686053692 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark06(-0.59621846238729,-0.5152237477299755,7.888609052210118E-31 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark06(-0.5965716095540832,-1.5707963267948966,-39.07450521836271 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark06(-0.5980269686112976,-2.1684043449710089E-19,19.881427412511837 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark06(-0.598152135367031,-1.5707963267948966,-95.57665390035856 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark06(-0.5983557754920031,-3.1415926536114913,31.711837707092666 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark06(-0.5990225762702043,-0.2959269647717031,-6.401706215273257 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark06(-0.6014609914832305,-1.5707963267948966,-1.5777218104420236E-30 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark06(-0.6020661805156913,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark06(-0.6024133654245099,-1.5707963267948963,1.5707963267948912 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark06(-0.6026882854252041,-1.5707963267948966,50.499520874997074 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark06(-0.603159399411922,-1.5707963267948912,-61.76921212725527 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark06(-0.6041039958672949,-1.5707963267944152,-1248.6313540674173 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark06(-0.605601426630497,-1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark06(-0.6057189003526233,-1.2369997809110707,-72.29970579535564 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark06(-0.6062241864498149,-1.5278758520721667,100.0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark06(-0.6066881153592036,4.3368086899420177E-19,75.41514519924061 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark06(-0.6069460426443843,-1.5707963267948966,-61.79146295928498 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark06(-0.6079254033483594,-0.00868439416898596,-1.5753380893588458 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark06(-0.6080534812518349,-1.5707963267948966,-40.82464253604816 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark06(-0.6085277375875409,-163.37963508652766,6.71243842339508 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark06(-0.6088389530253406,-0.08015875132406619,10.55669344678141 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark06(-0.6095023481225466,-31.904581148063116,-3.2944368572595385E-83 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark06(-0.6114702925224709,-38.98015562198296,-88.9670625599289 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark06(-0.611971647518272,-0.19998188237320252,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark06(-0.6123827696188044,-1.5707963267948966,-99.72403686952677 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark06(-0.6134919586160708,2.465190328815662E-32,88.4825841587685 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark06(-0.6140534249231053,-1.5707963267948966,58.52884972458695 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark06(-0.6147577617379799,-45.400769083564704,4.712388980462549 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark06(-0.6150083825251684,-1.5707963267948948,59.41442767120771 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark06(-0.6152212686180242,-1.5707963267948966,-57.49187769151656 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark06(-0.6157237675713672,-1.570796326276603,-1.5707963267948966 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark06(-0.6173904641962884,-1.5707963267947247,-3.3299958654878358E-257 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark06(-0.6205952880695758,-157.5310023388538,2.820483545495239E-5 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark06(-0.6209812904794676,-1.2428589287139555,-108.91188860984411 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark06(-0.623783250377554,-1.5707963236251092,-4.384132627387487 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark06(-0.6238305027352468,-0.13884583100635473,-100.0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark06(-0.6242730303321812,-0.4576786423050056,1.5707963267948968 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark06(-0.6244438899342448,-1.5707963267948966,24.177513583429786 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark06(-0.626913593072601,-1.5707963267948966,-43.723948592838575 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark06(-0.6285592795670856,-0.8492198084236202,94.37427630280577 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark06(-0.6297339790690881,-1.5362930734872162,69.57801383665561 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark06(-0.6302557061837151,-1.4809084819838223,-0.16167820735873623 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark06(-0.6304410913797369,-1.5707963267948966,58.33969293382678 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark06(-0.6306011582446214,-1.5707963267948966,115.01742386360732 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark06(-0.6310779235466129,-1.5707963267948966,-17.66598070620263 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark06(-0.6332019958127155,-0.394029016337591,-56.305652117547545 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark06(-0.6333093141160606,-1.5707963106762053,-9.93763344235596 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark06(-0.6336245021441709,-163.4410671244391,-19.361298413321236 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark06(-0.6362252479246953,-1.058056092805712,15.073694024976021 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark06(-0.636489835936106,-1.5707963267948966,-51.91344024715714 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark06(-0.6371238904348502,-38.75722435670766,-1.1122928342826501 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark06(-0.6402394755767432,-1.3840965999863237,32.359084455081444 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark06(-0.6406482518153265,-1.4210854715202004E-14,-66.52264810193982 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark06(-0.6406632769309857,-1.5707963267948961,39.95032848636393 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark06(-0.6408483555165049,3.469446951953614E-18,0.024407235069546552 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark06(-0.6412727458317733,-1.5707963266267795,39.06089817465134 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark06(-0.6433247970912136,-88.5274627101077,-71.52513786182335 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark06(-0.6452850236434375,-1.4415864409655517,-3.1415927032315025 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark06(-0.646317829619548,-31.4447127168491,-1.8729497682205647 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark06(-0.6470570062665395,-1.5707963267948966,15.723588267957194 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark06(-0.6473532713310661,-43.98229715025837,-83.72138380193695 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark06(-0.6473779542595682,-1.40605356601054,-83.55564537109058 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark06(-0.648359261391745,-3.1415926535897993,72.35910955199822 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark06(-0.650714538673583,-1.5707963267948948,-66.78239530988857 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark06(-0.650865393934674,-1.5707963267948966,3.2665926539106596 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark06(-0.6508765417057383,-1.56753705146861,0.0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark06(-0.6516005282250829,-1.570796326317657,-1.5707963267948983 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark06(-0.6520098367299926,-1.6242827758820155E-114,38.80983589557397 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark06(-0.6522170927215356,-1.5707963267948966,95.10274363797876 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark06(-0.6529431679860059,-1.5707963267948966,-65.28444866585549 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark06(-0.6555722970678698,-1.5707963267948966,-1.5707963267948974 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark06(-0.6575379432724178,-1.5707963267948966,-47.07567783010183 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark06(-0.658314484495842,-0.5984409137072197,329.85628284190676 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark06(-0.6588855114653307,-84.61320195368243,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark06(-0.6589178696429459,-0.5690807334147024,-0.5278326727404016 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark06(-0.661291901744621,-1.5707963267948966,-4.717903226963519 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark06(-0.6613095357140929,-1.5707963267948966,-0.12200029140213381 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark06(-0.6614196201558352,-1.4900918440390438,14.32868636600493 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark06(-0.6620490530537043,-1.5707963267948966,-2.5704611088815073 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark06(-0.662531454420646,-1.5707963263438858,0.0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark06(-0.664062479348164,-2.6246711472061583E-15,-1.570796326794897 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark06(-0.6641233723696672,-1.5707963267948966,-56.75875335041568 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark06(-0.66444446773835,-45.18256748482771,-397.5969090996286 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark06(-0.6653619330938341,-0.9998977668625534,-21.693214677794572 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark06(-0.6686467270267333,-0.3367258986756172,-11.864250112832224 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark06(-0.6690665572581029,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark06(-0.6709677233961067,-1.5707963267948966,99.42353646343037 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark06(-0.6715765823650617,-1.29993079091508,57.68813779780271 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark06(-0.6717127517514451,-1.5707963267948966,-48.380869399333925 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark06(-0.6730668797753854,-0.49964437533015893,-27.145762388649384 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark06(-0.6732608026934148,-1.5707963267948983,51.228628627072666 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark06(-0.6733637435827329,-1.3349318423085528,-70.844941125514 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark06(-0.673976823672945,-0.45776461811510927,-59.77686085904013 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark06(-0.6744619260081437,3.3881317890172014E-21,-20.51166218029283 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark06(-0.6744791278660127,-1.047845561289862,-60.829171792747104 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark06(-0.6749576736750592,-1.5707963267948983,29.8788841327608 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark06(-0.6750405952316569,-1.5707963267948966,-89.52329965764588 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark06(-0.675524583577015,-1.5707963267948966,9.424778147422636 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark06(-0.6767634607378135,-38.810191270524,-21.675459349069506 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark06(-0.6770344330848337,-1.5707963267948966,31.36739214400498 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark06(-0.6772713472064799,-1.5707963267948983,-66.4875385006998 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark06(-0.6780650006828353,-1.5707963267948966,-106.12124279936285 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark06(-0.6787634465840082,-45.475698551806204,-1.570796326794897 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark06(-0.679131028656448,-2499.2498120952964,0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark06(-0.6814618524270319,-1.5707963267948932,-67.71119280298669 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark06(-0.681714597457319,-45.00730475020043,-26.523251356567833 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark06(-0.6835778412331308,-1.5129825921868192,77.12278154093258 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark06(-0.6840465903043815,-1.5707963267948966,51.1095286699221 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark06(-0.6844519293136163,1.734723475976807E-18,1.5707963267948966 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark06(-0.6845154502630891,-1.5707963267948966,70.86930040808952 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark06(-0.6845939258019847,-1.5707963267948966,9.424777965864589 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark06(-0.6846096038539125,-88.15319011197028,-32.715408208199264 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark06(-0.6866994430015545,-0.1365211462517617,-94.98802743735035 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark06(-0.686808003645575,-1.5635321299543357,99.41990472545064 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark06(-0.6871537900617775,-95.32030995960221,-90.21635133674772 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark06(-0.6879298319371401,2.1498281772035683E-9,-227.5088751721362 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark06(-0.6882916543742745,2.465190328815662E-32,1.5707963267948966 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark06(-0.6883263084706153,-37.69911500013443,-0.5491069951314043 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark06(-0.6883700808413278,-0.29615944163061847,-84.60721062990608 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark06(-0.6884318823992349,-1.5707963267344862,-66.30462556439082 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark06(-0.6895301205079271,-0.2228892137353472,-30.615436176581223 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark06(-0.6898103643428413,-1.5707963267948912,-125.11279465726176 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark06(-0.6898687476202969,-1.5707963267948966,-833.8211181878136 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark06(-0.6918047578815357,-0.22907753658995778,45.09758782893287 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark06(-0.6938252545864587,-0.16093641689949745,53.741909288134686 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark06(-0.6945763064736657,-0.9884914814005725,1.5707963267949048 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark06(-0.6952382088851269,-0.25301329714704046,76.0908531989055 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark06(-0.6965965317663507,-31.415926535901484,-2.57543601983042 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark06(-0.6968982150291501,-1.5707963267948966,27.3106802349047 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark06(-0.6969702152253908,-1.5707963267948966,33.337879216107524 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark06(-0.7012032822372681,-1.570796326794895,-229.53520377546855 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark06(-0.7032714782565392,-1.5707963267948966,51.40560800076525 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark06(-0.7045128164589034,-44.536465330634044,-7.934420295470486 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark06(-0.7060078212133789,-1.499044206086684,14.20698350125753 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark06(-0.7069232123744269,-1.4675834992127414,-1.5707963267948966 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark06(-0.7069295891427814,-1.2484804823158573,-4.712633121112979 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark06(-0.7077231353283873,-1.5707963267948966,70.74725041250447 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark06(-0.7078766639485057,-1.5707963267948966,93.60745738252697 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark06(-0.7094029622575988,-7.105427357601002E-15,-44.80359161456686 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark06(-0.7095980381697828,-1.5707963267948966,77.0165452588576 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark06(-0.7110153095899878,-1.5707963267948966,31.780391336235965 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark06(-0.7133727986001945,-1.5707963267948966,-125.36623081012792 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark06(-0.7145076922931173,-1.2170115616364212,53.795271011652794 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark06(-0.7145499840436713,-31.888903332323217,-14.477097187696955 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark06(-0.7147258404793568,-0.44228440229691846,-178.9144748827327 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark06(-0.7155159818212056,-1.5707963267948966,-65.08692070409475 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark06(-0.7155440924199068,-32.85638362960423,-1.9921347414660886 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark06(-0.7156168997042585,-19.37416636714913,-33.44516357341922 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark06(-0.7157995909766015,-1.5707963267948966,-32.55155034567278 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark06(-0.7160806843801,-3.469446951953614E-18,-83.4889108486195 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark06(-0.7167184097235526,-1.5707963267948983,-80.52245294116489 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark06(-0.7170921519616928,-1.570796326703452,56.12682874819091 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark06(-0.7171051728869102,-1.5707963267948966,-37.23487719830254 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark06(-0.7174060434732269,-0.3979576784998653,93.48050591361527 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark06(-0.7176613253219974,-1.5707963267948966,70.71787371550782 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark06(-0.7188945168781816,-0.17383748042607758,-55.59116709251309 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark06(-0.7197415179727896,-27.718855665132917,6.713003322846396 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark06(-0.7200770104012761,-95.75105408160137,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark06(-0.7208094262195459,-44.4489753143382,-3.141592642671493 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark06(-0.7213336837084339,-1.464572473775909,77.60308000916292 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark06(-0.7216151583397972,-7.105427357601002E-15,-160.2376135187509 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark06(-0.7256484937159389,-158.62776115519665,-96.15375351477044 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark06(-0.7256921723913408,-1.5707963267948988,73.72796206360664 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark06(-0.7263118198839307,-0.9636573337781378,-16.33453717340197 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark06(-0.7269258979970528,-1.5707963267948966,71.93409313569093 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark06(-0.7277212454051109,-44.27313246927612,-1.6543612251060553E-24 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark06(-0.7288427592037573,-0.8590334190646909,31.420717849958542 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark06(-0.7294219217915582,-0.7647931815214171,-1.5707963267948966 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark06(-0.7298504360448865,-4.440892098500626E-16,65.94728310666278 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark06(-0.7309458930972834,-31.979029842960383,-1.5707963267948966 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark06(-0.7327139629570828,1.0339757656912846E-25,26.910327641322212 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark06(-0.7332171031339818,-1.3681766864824827,-53.664589376976686 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark06(-0.7332640037266884,-0.5055988044750404,60.162751670570806 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark06(-0.7337133698021936,-1.5707963267948966,-45.96935443922962 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark06(-0.7354042520921951,-1.4391007429456733,17.351126397834978 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark06(-0.7355140568066982,-1.5707963267948977,23.30964170486375 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark06(-0.7356725583326764,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark06(-0.7359141245609331,-101.84111387765705,-2.0708990295202376 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark06(-0.7360855755456147,-1.5707963267948966,1.5866411940588139 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark06(-0.7368645681295611,-1.5707963267948966,16.204516627989467 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark06(-0.7370358721933995,5.421010862427522E-20,0.32257926626657096 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark06(-0.7395978344742346,-1.5234702191097445,-3.1415926633456124 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark06(-0.7400558138174874,1.3877787807814457E-17,-18.17682511293813 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark06(-0.742342354741224,2.465190328815662E-32,88.41857513834077 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark06(-0.742409049095655,-1.5707963267948966,-21.571834680835035 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark06(-0.7426750632987116,-1.3601234838057508,163.7183476754372 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark06(-0.7429564457081974,-1.5707963267948966,41.48818797853582 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark06(-0.7430866277848766,-1.5707963267948966,1.5717852560845165 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark06(-0.7432217554083754,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark06(-0.7471658176946395,-1.5707963267947065,-56.86857673598256 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark06(-0.7490490816229967,-1.5707963267948983,1.5707963267948966 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark06(-0.7494688649580471,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark06(-0.7501668302540239,-7.105427357601002E-15,-34.664411657434385 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark06(-0.7509276899790953,-1.4087599694195452,9.424778703544192 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark06(-0.7510929985704027,-1.5707963267948966,5.389101568551752 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark06(-0.7537266590757499,-1.0699129002904044,91.3754930589738 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark06(-0.7548422523926027,-1.5707963267948912,6.9023953879226525 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark06(-0.7574731123934053,-0.34945934839489773,6.868422117236221 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark06(-0.7589837944848793,-1.3666811928298523,-32.547515016549184 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark06(-0.7589981997968348,-1.5707963267948966,357.99474794956944 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark06(-0.7600935791218258,-37.753795327677906,-46.25650063703013 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark06(-0.7602864625529192,-0.6261474402134195,-6.712388980384834 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark06(-0.7621662496625632,-1.5707963267948948,1.5707963267948983 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark06(-0.7623547402751498,-0.007842821172613576,-1.5747026078982793 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark06(-0.7628287880087177,-0.4358588694053173,88.77737949937631 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark06(-0.7630111673629879,-1.5707963263310705,53.76983803554953 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark06(-0.7630695930858825,-45.35011612740077,-1.5707963267948968 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark06(-0.7644700915549009,-44.5197629867917,-1.574702584494229 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark06(-0.7649329102125608,-1.5707963267948966,-35.560036226118186 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark06(-0.7655431645374067,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark06(-0.765879782854635,-0.45045987737372595,130.15593940906788 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark06(-0.7672516002496447,-1.5707963267948966,58.98190152969427 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark06(-0.76770011769885,-44.507100683042836,-4.2351647362715017E-22 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark06(-0.7678228742970682,-1.5707963267948948,2.2511171869023947 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark06(-0.7681562206683168,-1.5505280308833858,0.0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark06(-0.7697855771476422,-0.500235855046713,45.82568574988919 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark06(-0.7707393332507035,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark06(-0.7714957927294684,-1.5707963267948966,4.714342105388178 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark06(-0.7722659895704156,-1.5707963267948966,68.43558075214372 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark06(-0.7728524252561971,-1.5707963267948966,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark06(-0.7730911415111774,-0.6391289043968407,-3.1415926535898038 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark06(-0.7758538292139482,-1.5686361172300554,-3.141592878241733 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark06(-0.7761806110956504,-1.0004085115410255,-18.429209962238907 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark06(-0.7763665667887665,-1.570796326794896,-0.027408545557126147 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark06(-0.776605808381829,-1.5707963267948966,3.141592653589793 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark06(-0.7772532539125047,-0.19065086464045922,1.5707963267948966 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark06(-0.7782589326925048,-1.5707963267948966,24.681407042373618 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark06(-0.7792839106436873,-1.5707963267948912,-31.650221210424448 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark06(-0.779652228196824,-45.28541239681031,-21.300259320327484 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark06(-0.7805069184003341,-1.5707963267948966,-1.802937312770886 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark06(-0.7815863228036182,-0.14099019489546172,86.0652808803979 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark06(-0.7816479435850477,-89.9355747355882,-59.686027868365535 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark06(-0.7821379387954905,-1.1351665785995664,1.5707963267948966 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark06(-0.7822467696080364,-1.5707963267948966,73.93776946034791 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark06(-0.7823455346010845,-1.5700159427570348,772.3201745154206 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark06(-0.7833559448860462,-1.1270725851789228E-131,0.0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark06(-0.7844099077958866,-88.09542650250991,-0.4942113151461529 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark06(-0.784525739101213,-1.5707963267948966,12.209913549971674 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark06(-0.7845421301265784,-1.5707963267948966,-145.0593154266342 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark06(-0.7851476592662883,-31.62568271356993,-0.38155217342978887 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark06(-0.7853512693265884,-100.90474600077376,1.0317014020641524 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark06(-0.7853981633974483,-0.0014784136959623134,-9.889732765424817 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark06(-0.7853981633974492,-38.97607560509193,1.9721522630525295E-31 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark06(-0.7856598039713486,-0.9029536273561604,5.221939214090795 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark06(-0.7882999932512789,-1.5707963267948966,3.1415926535897967 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark06(-0.7885069562627367,-1.5707963267948966,-4.6941485745527345 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark06(-0.7895696555756294,-1.5707963267948957,-55.72727856718415 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark06(-0.7907704758962893,-1.5707963267948966,-0.16904845121731707 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark06(-0.7908350354396112,-1.5707963267948966,-36.43799300945872 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark06(-0.7930254126814269,-0.022046759588813157,-96.412222989424 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark06(-0.7947962391378596,-45.52668896923564,-1.5707963267948963 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark06(-0.7951568491884,-3.552713678800501E-15,-60.82398399200982 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark06(-0.7960349474596946,-1.5793650827938261E-176,8.719354219264446 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark06(-0.7993914491072669,-1.1722242170961295,-78.53981633974483 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark06(-0.8003183755847442,-45.45585254944682,-2.5737787947340145E-85 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark06(-0.8007164204230053,-88.15050121467132,-34.32072624545741 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark06(-0.8013644702203665,-1.5707963267948966,27.611982995017605 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark06(-0.8028276164726744,-1.3536643868764116,30.245810378403473 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark06(-0.8030783300932647,-95.59059598053113,-95.94950019098502 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark06(-0.8049741074884809,-1.5707963267948966,-58.50619595647476 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark06(-0.8050713945842477,-1.7763568394002505E-15,-1.5707963267948961 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark06(-0.8058196432197121,-0.642111830243376,-97.33625729718005 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark06(-0.8063386070879772,-3.141592653928607,-1.5707963267948966 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark06(-0.8066170614580557,-0.28499585680887246,22.531598702909868 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark06(-0.8069526891909522,-101.64612630707175,-39.755140832412025 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark06(-0.8088547824053114,-1.5707963267661176,-121.74254880824924 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark06(-0.8103750720257084,-1.4999836523718306,1.5707963267948983 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark06(-0.8119685529640774,-45.22393896174559,-19.69445421025662 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark06(-0.8139509321115665,-0.5927367291565024,41.50038048359124 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark06(-0.8145481343009351,-88.49465202063902,-0.705366308013609 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark06(-0.8154960985083761,-1.5707963267948966,-55.49575700847015 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark06(-0.8157181721811891,-44.338132939466696,2.465190328815662E-32 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark06(-0.8157786236611706,-1.5707963267948966,23.74288152889261 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark06(-0.8157852720638399,-1.5707963267948948,44.23634168707063 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark06(-0.8167793537039769,-1.5707963267948966,-88.45470885985992 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark06(-0.8174897520461651,-1.5707963267948966,74.74043988445007 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark06(-0.8177907424561242,-1.5707963267948912,-6.434177918802291 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark06(-0.8182215613017987,-1.5707963267948841,0.0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark06(-0.8205170303382974,-0.4719459049561294,-1.5707963267948983 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark06(-0.8206234291514223,-44.14596138421036,-1.5707963267948968 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark06(-0.8208668041426885,-1.5707963267948912,58.87797660167594 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark06(-0.8213636474502438,5.421010862427522E-20,-55.91339573337579 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark06(-0.8219154563449426,-1.5707963267948966,-3.141592674874407 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark06(-0.8234280007988275,-1.5707963267948961,-65.23893521132092 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark06(-0.8253904482780657,-1.5025424620546883,4.243654737427789 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark06(-0.8254585951707519,-100.8201749722064,-2.114629147988047 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark06(-0.8266265505964137,-1.5707963267948966,6.712389020671903 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark06(-0.8266411791327759,-1.5707963267948966,44.34445770613832 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark06(-0.8272259154221473,-1.5707963267948966,-46.84804240803287 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark06(-0.8277323939757688,-226.4085100373109,-767.5248364225198 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark06(-0.8283842377393325,-158.50773023725992,-70.80235820005649 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark06(-0.8287035909603817,-1.5707963267948912,-0.3349100888659535 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark06(-0.8288779425161489,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark06(-0.8293439766820825,-157.09741246913413,-25.779077855414275 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark06(-0.8301127828069121,-88.2106035841087,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark06(-0.8307017371705001,-31.433857348333138,-39.359574333302696 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark06(-0.8311341037002137,-0.9935315969932645,-4.5719495651291E-100 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark06(-0.8332201760229017,-39.17604944858845,-39.11256091087645 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark06(-0.8351765771894227,-0.6388441291265972,-1.5707963267948966 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark06(-0.8369145440702934,-0.7769493285088466,0.0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark06(-0.8369337683873541,-3.141592653593054,0.0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark06(-0.8373997625736207,-0.0330088889401452,117.97465059213616 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark06(-0.8378479955502688,-1.4368834634025376,434.09570359274437 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark06(-0.838417020117187,-1.339728401987525,-10.995574287580684 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark06(-0.8387761600192324,-1.570796326794897,-123.750054097282 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark06(-0.8410639338613218,-1.5707963267948966,42.51723399648777 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark06(-0.8410722414224236,-0.7387135046006573,52.834415317557735 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark06(-0.8411143444579313,-1.5707963267948983,9.424777962416648 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark06(-0.8434830869741811,-1.308790036553603,13.090021381778683 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark06(-0.8442968479593066,-31.59242950610863,6.776263578034403E-21 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark06(-0.8450838875901205,-44.19738429900753,-635.2035391567717 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark06(-0.8455191162011717,-1.5707963267948966,-36.147155700497564 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark06(-0.8480241187009099,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark06(-0.850298119007121,-1.5707963267948966,-55.01330327720214 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark06(-0.8503698422290127,-88.18569110310031,-7.993119832916719 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark06(-0.851240293412213,1.3877787807814457E-17,49.784218747471755 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark06(-0.8526115951089952,2.220446049250313E-16,-15.105974981681282 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark06(-0.8527630214224631,-0.976570352586984,4.712450019201255 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark06(-0.8552280155951596,-1.0020404964654388,4.712403022025955 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark06(-0.855327797336944,-1.4489965663703661,1.5707963267948966 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark06(-0.8553841406546667,-0.7580322688500916,41.783165803405325 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark06(-0.8555752760258972,-1.135140138323317,86.41334094763043 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark06(-0.8564983143830545,-1.5707963267948966,-2288.2468442963655 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark06(-0.8585941712707097,-0.05655391529799658,-115.55092811454371 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark06(-0.8586157891518704,-157.34020107298426,-1.5707963267948586 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark06(-0.8593778872805393,-1.5707963267948966,-0.29608863037219846 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark06(-0.8595258623454639,-7.498484069478155E-242,1.5707963267948966 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark06(-0.8607366364102944,-1.0170858363302493,-74.64565060704169 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark06(-0.8611744765793534,-88.51902341412072,-84.67549237219227 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark06(-0.8612670519495111,-1.5707963267948912,56.81131364640814 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark06(-0.8623247192242727,-32.78818108522978,-96.4878649853863 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark06(-0.8639765899786549,-1.5237902014092128,-100.0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark06(-0.8640477573852563,-4.440892098500626E-16,15.305984396264904 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark06(-0.8652842082297787,-1.5707963267948966,-60.96182320447549 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark06(-0.8654477323407881,2.465190328815662E-32,-38.73594533339412 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark06(-0.8663029943460074,-1.5707963267948966,1.5707963267948961 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark06(-0.8685253399704612,-1.5707963267947254,1.4460488916144667 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark06(-0.8697158436483454,-1.5707963267948966,-1.570802086663987 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark06(-0.8706151711426593,-1.5707963267948966,-5.278079616384376E-4 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark06(-0.8709601694670202,-1.5707963267948966,3.1415926535897967 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark06(-0.8714808268973294,-1.5707963267948948,423.58258567477776 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark06(-0.8717528626389877,-1.5707963267948966,48.652419784833825 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark06(-0.8738666926336038,-32.52465009385314,-0.6336161851066537 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark06(-0.8741000035654913,-1.5707963267948966,4.2351647362715017E-22 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark06(-0.874362031975167,-1.5707963267948966,60.385939825297875 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark06(-0.8743723806907193,-0.810873272462695,-0.0985917101663699 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark06(-0.8778443947240707,-1.5707963267948948,-1.5707963267948966 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark06(-0.8779500338977321,-1.5137060650258904,-69.53495057809639 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark06(-0.8786690830214529,-32.80619289428883,-31.682046784396107 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark06(-0.8792180788711548,-88.1720613012217,-987.2519046114908 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark06(-0.880098029543642,-1.5707963267948966,34.41305199675128 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark06(-0.8802231588073681,-1.5707963267948966,65.12457789690279 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark06(-0.880611170106661,-1.5707963267948966,72.51258787762333 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark06(-0.881142714650193,-0.23093202677692815,4.714342238800594 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark06(-0.8816895115191329,2.1684043449710089E-19,10.750314148237596 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark06(-0.8819950327938016,-1.5707963267948966,-45.73916617184177 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark06(-0.8822303161123043,-1.5707963267948966,0.8765298487147515 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark06(-0.8822437298795585,-1.5707963267948806,0.0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark06(-0.8823281177540641,-3.1415926535898278,-93.43193812193147 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark06(-0.8827425059049905,-0.0045985264336772256,40.22492891651455 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark06(-0.8836763087429333,-1.5707963267948966,27.08434824866766 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark06(-0.8839686540161307,-0.17053631032731817,-12.462643870767991 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark06(-0.8853248721367049,-1.5707963267948966,0.3266872449516298 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark06(-0.8861155311473007,-1.5707963267948966,71.22989037539912 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark06(-0.8870105213515725,-1.5707963267948966,9.498379942148574 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark06(-0.8887033163378639,-32.56573813502176,-81.80982850180324 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark06(-0.8887922131828236,-44.26023802697063,-0.8578369140395239 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark06(-0.8896788466016784,-1.5707963267948966,623.2682070842872 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark06(-0.8927231039243253,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark06(-0.8930810674643362,-0.16214804543832306,-58.63472916486505 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark06(-0.8931201778344529,-1.5707963267948966,-112.3129303118638 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark06(-0.8940669176329028,-1.5707963267948983,-62.25842314155824 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark06(-0.8945493033882044,-1.5707963267948966,9.1438991302582E-100 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark06(-0.8948318858551865,-31.825649938274502,-0.13894364347832777 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark06(-0.8969386363299123,-1.5707963267948966,-38.932069794870806 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark06(-0.8975990616742293,1.9721522630525295E-31,-22.536052940463517 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark06(-0.8996608779787786,-1.2578707650645145,1.632950887146522 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark06(-0.9004501891993648,-0.8437220348864387,1.6237812329046832 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark06(-0.9010811151340874,-1.5707963262860045,-100.0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark06(-0.9016588212837461,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark06(-0.9019676903424927,-1.5707963267948966,-4.721181372196277 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark06(-0.902318037197503,-39.25403611001668,-190.08578480268815 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark06(-0.9027646370229018,-1.0538410251690304,-7.3057386997438245 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark06(-0.903409612579031,4.3368086899420177E-19,1.1163693592353305 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark06(-0.9043961884441387,-1.553349748371101,10.913363473597684 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark06(-0.9064257555854311,-95.71740288200874,-1.7790040443697697 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark06(-0.9070517763054605,-39.15267946183356,-1.5707963267948972 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark06(-0.9075761034552398,-1.5707963267948966,6.018131832846294 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark06(-0.9078859770880475,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark06(-0.9079703265622321,-95.28152807158968,-94.508930217381 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark06(-0.9086183025910144,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark06(-0.9094199268759064,-1.1780276847553495,23.54297918449054 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark06(-0.9097732106728971,-1.5707963267948966,72.55123864251436 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark06(-0.9111339396054415,-1.5707963267948966,-27.338523876634817 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark06(-0.9115824484680042,-0.8514771973565303,2401.5339468420675 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark06(-0.9128599458091661,-1.1201893361773693E-15,0.0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark06(-0.913343374907506,-1.5707963267948966,52.30113952350264 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark06(-0.9149922617566496,-1.570796326794897,0.8936543601463837 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark06(-0.9155534494720434,-1.5707963267948966,1.3908073701361978 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark06(-0.9158368422390275,-1.5707963267948912,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark06(-0.9160205489088216,-31.664969952006146,-32.79993806739829 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark06(-0.9172379991909168,-1.5707963267948963,50.26548245743669 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark06(-0.9178313853169326,-0.22771240660580522,-72.28741619802983 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark06(-0.9178847445981709,-1.2237249235409544,-100.0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark06(-0.9192815296828263,-88.11705363728804,-114.12649931405922 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark06(-0.9193028541377949,-0.5491062689561569,0.1677890730674001 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark06(-0.9193422222005736,1.5707963267948963,0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark06(-0.9200601354795462,-1.423793895528674,-3.141592653803241 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark06(-0.9203447492090284,-0.7914711087574378,77.71762336483332 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark06(-0.9211961140145009,-0.05524784945239307,32.93503612123038 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark06(-0.9217983338668962,-1.5707963267948966,-44.35740141366575 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark06(-0.923699871602409,-1.4211144483180627,33.4186552183168 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark06(-0.9240584757779008,-95.36161773552912,-0.36187952206045265 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark06(-0.9240762113243441,-1.2678613513344967,-5.00990825802888 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark06(-0.9246701733197619,-1.5707963267948912,-11.961326363920477 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark06(-0.925558808161984,-4.5082903407156913E-131,-28.594260477571858 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark06(-0.9264191558805929,-1.1113793747425387E-162,95.7768126319369 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark06(-0.9270167771415941,-1.5707963267948966,-22.195140901030868 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark06(-0.9271676077396966,-0.4808089963429812,0.0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark06(-0.9274887954800539,-0.9609259978488645,-1.5707963267948966 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark06(-0.9275260262691916,-19.37557362108158,-70.59576325370749 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark06(-0.9299939554603895,-1.5707963267948948,25.954108808129092 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark06(-0.9310021334151397,-32.48320860507246,-1.5207441822099637 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark06(-0.931851643393923,-1.5707963267948983,8.256079623411935 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark06(-0.9332398493896181,-43.982297150257196,-95.56807167829082 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark06(-0.933461531570211,-1.5707963267948966,69.35581933250657 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark06(-0.9352074023313914,-1.5707963267948966,81.77602544889317 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark06(-0.9365602991607593,-215.1057840280581,-77.33547123811186 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark06(-0.9380437841462299,-0.43845076533952015,-77.70405790776684 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark06(-0.9381114513950166,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark06(-0.9387987974243273,-32.70939529805395,-1.5707963267948966 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark06(-0.9388310758080664,4.668958780461048E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark06(-0.9391197002922798,-45.32258545130157,-0.24202561620609764 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark06(-0.9394445759065491,-1.0472054773916994,100.7731542147519 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark06(-0.9401490589720893,-1.5707963267948966,-87.76112045408794 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark06(-0.94165362400314,-1.5707963267948966,2.5707961228657483 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark06(-0.9419045522321434,-139.8201860286173,-14.86571688335265 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark06(-0.9420478941003828,-1.5707963267948966,-61.487909776913376 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark06(-0.9421420424661058,-1.5707963267948948,-39.79887188444542 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark06(-0.9428758089515274,-1.5707963267948966,-91.4380236295712 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark06(-0.9440838374929292,-1.5707963267948966,67.41895199253551 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark06(-0.9465594526024422,-1.5707963267948966,-9.60591182023198 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark06(-0.9474317579289016,-1.5707963267948966,80.55550474589558 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark06(-0.9479875987044619,-8.881784197001252E-16,21.286220504604458 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark06(-0.948369478857721,-0.6826848437550497,66.54885612024785 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark06(-0.9492975236748601,-1.5707963267948966,-2.070796326938556 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark06(-0.9509230073018402,-1.5707963267948966,75.56082611534472 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark06(-0.9531103169916374,-88.22667706825263,-2.9343657058577044 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark06(-0.9534221027227686,-1.5707963267948966,-306.8942445697006 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark06(-0.9535865754344064,-1.5341161804407755,73.85733702560417 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark06(-0.9537631442481214,-1.5707963267948966,59.07895532858013 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark06(-0.9541866326676436,3.469446951953614E-18,-38.47885205104832 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark06(-0.9557597883465927,-45.29757295940844,-1.5707963267949019 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark06(-0.9565999298250384,-1.5707963267948966,-677.3610303898605 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark06(-0.959861314511314,-1.5707963267948983,751.0191732416345 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark06(-0.9602252935483762,-88.48168502583884,-21.91175498257583 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark06(-0.9604327695816514,-1.5707963267948966,-1.8624147298172318 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark06(-0.9612333912879661,-1.5707963267948966,-45.161083891263715 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark06(-0.9627522022835986,-1.5707963267948966,2.5707921309301707 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark06(-0.9628201002926545,-94.28598477696804,-1.0587911840678754E-22 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark06(-0.9632201978904416,-0.2631933623745857,-6.025119324025646 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark06(-0.9640668481227301,-1.5707963267948966,-38.265176035147206 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark06(-0.964292633876699,-1.5707963267948966,-3.1677410821064704 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark06(-0.9646212840548216,-31.59575650815725,-65.49488326091553 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark06(-0.9646884260348128,-45.261451064504456,-90.42892040072975 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark06(-0.9657118992894603,-0.09828844462176198,8.103981920718526 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark06(-0.9657679587710927,-88.14215236326936,-0.8205570581505173 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark06(-0.9661546943974626,-1.5707963267948966,-3.266592653614449 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark06(-0.9662316472065741,-0.10786277680330036,47.1238898038469 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark06(-0.9664482979948239,-83.30097189967505,-72.15198664223225 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark06(-0.9681112608393393,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark06(-0.9681729739444808,-8.103981637262502,-97.12251535794702 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark06(-0.969737297419441,-1.5707963267948966,-1.5723454404551467 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark06(-0.9697569848714221,-0.04909937049862981,-54.14915756659533 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark06(-0.9718649706926077,-0.7745614077726297,23.9751073547531 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark06(-0.9721967510647518,-0.44800893239910505,-6.007713947462996 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark06(-0.9729479450905513,-1.5707963267948966,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark06(-0.9760739876757756,-31.415926536872888,-1.5707963267948966 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark06(-0.9763344959466421,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark06(-0.9791726580054902,-38.89835735218202,-31.954874742682527 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark06(-0.9796798770105525,-1.5707963267948966,13.87939014643998 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark06(-0.979955565333511,-0.027796813557351585,-77.77307023792906 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark06(-0.980368847380575,-1.1604668493544317,-2553.649907337785 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark06(-0.9813247585675466,-1.5707963267948966,3.1415926535897967 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark06(-0.9820330168482627,-0.2673910236564184,-83.3006005823534 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark06(-0.9831321670052577,-1.5707963267948966,-92.00624023603604 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark06(-0.9834719621982564,-1.5707963267948966,-45.03661084863947 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark06(-0.9840375215905267,-0.09209766018752608,73.3683519581254 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark06(-0.9848182890467188,-1.5707963267948957,29.397636686857634 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark06(-0.9852721549698715,-1.5707963267948983,9.40317765559675 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark06(-0.9859548728576265,-0.4119335124336927,-100.0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark06(-0.9860655261459388,-0.8560893813760935,-134.06671898563536 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark06(-0.9868520926832063,-44.09085169675978,-1.5707963267948966 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark06(-0.9868722807341826,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark06(-0.9871214023089587,-1.5707963267948948,-38.016163956997076 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark06(-0.9872211187127746,-1.1243699232440765,-25.88272649595767 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark06(-0.9874597360167237,-1.527217326823921,55.202566139359206 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark06(-0.987860505675932,-1.5707963267948966,10.678142479657069 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark06(-0.9896338471526182,-0.01775612312622018,-14.998065860394732 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark06(-0.9897486905936739,-1.5707963267948966,24.469164628398303 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark06(-0.9912629122631555,-157.49992686498706,-52.037162782841186 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark06(-0.9917905433588685,-1.5707963267948966,35.23695399880904 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark06(-0.9920165279387874,-1.5678594157102852,-57.973615281347776 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark06(-0.9924683304933036,-1.3259671251044591,0.0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark06(-0.9924873046903803,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark06(-0.992965472135717,-1.2989187547730514,0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark06(-0.9934471289337664,-0.996483062193684,-1.5707963267948966 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark06(-0.9940320232933277,-1.5707963267948957,-19.298204063817565 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark06(-0.9941135249459456,-1.5707963267948966,0.5707949977288252 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark06(-0.9942901232728042,-0.8748415820583283,58.27871357333967 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark06(-0.9944039936211323,-1.5707963267948966,10.436848582553523 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark06(-0.9953291248673399,-1.5707963267948966,77.41798264436775 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark06(-0.9955804383633554,-31.520491412679945,-1.570796326794897 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark06(-0.9959255469898134,-0.07522566339490758,68.84469798741833 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark06(-0.9964843754974992,-1.5707963267948966,-28.069153546363104 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark06(-0.9973253208906131,-1.5707963267948966,-62.89461691512768 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark06(-0.9979656614903902,-1.5707963267948966,-95.79413937952327 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark06(-0.9981488795497847,-0.010221551779574511,28.70317062978046 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark06(-0.9987234027197782,-1.5550683837384285,49.00691535406784 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark06(-1.0010415475915505E-146,-94.25800217399733,-20.60642780347375 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark06(-1.003403541720734,-31.765173649169995,-70.7025368183079 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark06(-1.0036738583619658,-0.022562978613492456,16.971326617254448 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark06(-1.0050759101521738,-32.75828991767192,-39.630448818966094 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark06(10.052419567172109,28.153279769714345,4.70370556821949 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark06(-1.0056660404513795,-45.384002549002396,-40.05526983953736 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark06(-1.0063351871048611,-1.5707963261251132,-73.87797852160789 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark06(-1.006354243518633,-0.725486221708759,4.571060857217741 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark06(-10.063590332886534,-70.3971524548889,98.70866609556944 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark06(-1.0070258295171617,-1.5707963267948966,91.0844945327242 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark06(-1.0071527524051282,-5.635362925894614E-132,-66.48621657418548 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark06(-1.007687706571754,-32.70563529535106,-14.03991012032786 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark06(1.0097419586828951E-28,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark06(-1.0098993717677915,-1.5707963267948966,-57.015299717103204 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark06(-1.0102383269540407,-1.5693479751377568,1.5707963187104406 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark06(-1.0104317237437357,-0.9297025835356543,27.883493419012957 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark06(-1.0107936529880487E-174,-0.3709960793926517,44.148964116272396 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark06(-1.011031262577811,-1.5707963267948966,44.270692421763755 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark06(-1.011112577361607,-1.5707963267948966,77.960256695165 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark06(-1.0114321844995247,-1.5180872499428943,-67.3456856229204 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark06(-1.0142694191367927,-1.5707963267948966,32.2719113501386 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark06(-1.0145208471566178,-1.5707963267948912,67.52391447557424 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark06(-1.0145939849368557,-5.770611636116085E-129,0.0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark06(-1.01660206395854,-1.5707963267948966,24.9117020533063 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark06(-1.0187651686911827,-3.1415926535897944,-3.962317595922459 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark06(-1.0188951346247022,-101.05413286173055,-71.86045219868083 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark06(-1.0190926085665775,-0.8623132790913282,-4.7664778471782085 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark06(-1.0192095226106166,-1.5707963267948966,3.1415926540695316 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark06(-1.0197067017612427,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark06(-1.0202829507835265,-88.11227484328148,-56.792452009284 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark06(-1.0205505420801668,-1.5707963267948966,-82.95480516859686 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark06(-1.0207324413890269,-158.31612027452235,-9.169823095013044 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark06(-1.0207390584827298,-1.5707963267948912,-43.27783780624943 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark06(-1.0209215613373461,-1.5707963267948966,30.261662390375577 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark06(-1.0214245271630489,-1.5707963267948466,13.975856712310769 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark06(-1.021791165520189,-1.5707963267948966,-60.28070507693723 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark06(-1.0219549059569122,-100.66057845118783,-95.78924639381948 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark06(-1.0243079248240805,-1.5707963267948966,-47.91323380710558 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark06(-1.0269112811858179,-0.3650539022496583,-1.5707963267948912 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark06(-1.0283757427309084,-1.5707963267948966,4.445517498970155E-162 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark06(-1.0288429752675652,-5.551115123125783E-17,8.51843460518571 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark06(-1.0291181941270227,-1.5707963267948957,-1.5707963267948966 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark06(-1.0292887456925688,1.1102230246251565E-16,-73.42396865415695 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark06(-1.0295115178936058E-84,-1.1586893244685996,-36.91562331538865 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark06(-1.0299339605802895,-1.0692324811285099,67.32884504182137 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark06(-1.0312054584605201,-64.94274422112956,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark06(-1.0313839639953102,-1.5707963267948966,20.196645601796305 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark06(-1.0325811786185204,-1.5707963267948912,-19.393667253175195 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark06(1.0339757656912846E-25,-1.5707963267948966,73.4922827940824 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark06(-1.0345288932046817,-31.805734951747525,-1.5707963267948992 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark06(-1.0361295452855526,-1.5707963267948948,-66.28371034209715 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark06(-1.0377422237294969,-0.17153474207930688,-2.191809349008403E-193 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark06(-1.0377842963006998,-1.5707963267948966,44.448035687713265 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark06(-1.0390731001718017,-1.5707963267948961,0.0 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark06(-1.0395409765644899E-112,-95.61085204961391,-50.37063610400232 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark06(-1.0403492244889372,-1.5707963267948966,-82.18074407820619 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark06(-1.0406035205955917,-1.5707963265273461,-62.34147724917054 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark06(-1.0409483809244096,-1.5707963267949019,15.096449952956824 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark06(-1.0411399841991775,-0.3722499247133555,185.50362037019943 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark06(-1.0412380570213062,-95.26586621512627,2.737115757199992E-6 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark06(-1.0419917689206737,-0.8056355852456574,-45.79771512469068 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark06(-1.042286810257142,-3.141592653590431,1.5707963267948957 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark06(-1.0426402015235823,-2.220446049250313E-16,58.79696411965517 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark06(-1.0433256707825396,2.465190328815662E-32,79.71951863299603 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark06(-1.0458582327663,-1.5707963267948966,-31.54883258871936 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark06(-1.046333768330685,-1.5707963267948966,-58.52492229245723 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark06(-1.0472675614392164,-1.3946741093995296,90.87353646583327 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark06(-1.0474795144423297,-0.7077230906131267,-66.11633681917633 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark06(-1.0478452813274237,-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark06(-1.048561824847219,-88.27982789875671,-1.5707963267948957 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark06(-1.0488246992011379,-1.5707963053459622,249.44607950821427 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark06(-1.0489198914320212,-1.5707963267948966,70.74637986141198 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark06(-1.0497040501529031,-1.5707963267948966,-2.070796333570148 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark06(-1.0499262299422831,-2.1353152994930384E-15,-86.0882204530044 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark06(-1.052085634249356,-32.686687875979985,-1.5707963267948966 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark06(-1.0530447412698107,-38.792914788740575,-45.33461610729804 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark06(-1.0535503409127962,-0.6581536597838475,-33.57974661162017 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark06(-1.0535624627912517,-1.5707963267948966,43.70180495302466 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark06(-1.0536985110570152,-157.61072566858797,-1.5914754528766808 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark06(-1.0541707916257588,-2.7397616862605038E-194,7.9161329490787145 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark06(-1.0565717950565894,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark06(-1.0586694302431154,-1.5707963267948966,-157.14743009418837 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark06(-1.0589964227729718,-1.5707963267948966,25.13441837549834 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark06(-1.0593429375892989,-1.570796326794893,-33.59281672814487 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark06(-1.0600798384271002,-0.8438554819799862,21.389276590857634 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark06(10.610955514682587,0,0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark06(-1.0623065582106719,-1.5707963267948966,0.8632301098015955 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark06(-1.063263176014806,-0.9075449081474275,-9.545601949778248 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark06(-1.064013025314344,-1.5707963267949054,15.13158929870917 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark06(-1.06422684394966,-88.19450274249797,-31.59046560700773 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark06(-1.064549908160884,-1.5707963267948966,-36.73492804584007 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark06(-1.0647525732881746,-1.2785778882555832,-3.141592653589793 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark06(-1.0660720123663987,-1.4700297737680492,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark06(-1.0667866367109913,-9.016580681431383E-131,15.69283582636237 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark06(-1.0673761170397091,-1.5707963267948966,14.267892525679477 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark06(-1.0688427867258383,-0.7227758339034485,34.193472059419975 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark06(-1.0693851653012387,-3.980408932971324E-16,0.0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark06(-1.0694136118010595,-1.065402953411065,94.50019501165951 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark06(-1.0708258748858464,-0.8839610847518059,-1.5707963267948983 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark06(-1.0715079809265262,-101.90697837319043,8.978154588777967E-6 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark06(-1.07158603576778,-1.2631296249219828,-130.66850796215763 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark06(-1.0718188476171802,-1.5707963267948966,-43.04936159026502 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark06(-1.0723061762855788,-1.1448148364050232,9.466347086522584 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark06(-1.0727573308852314,-1.5707963267948966,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark06(-1.0738672550866792,-0.47922207230016056,28.962286434382538 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark06(-1.0739027746685947,-27.045040315674385,-32.96257156328979 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark06(-1.0754099301224387,-0.796849786855883,-1.5707966631767776 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark06(-1.0759586544779278,-1.5707963267948966,-26.32810646076738 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark06(-1.0764518504539042,-1.1699141657071281,39.69067112810431 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark06(-1.078620384420948,-3.1415931732879296,-1.5707963267948961 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark06(-1.0788491707875387,-1.5707963267948943,-4.743638980898108 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark06(-1.078998778206517,-0.030798201162931665,69.63437044144929 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark06(-1.079352936383528,-3.552713678800501E-15,-27.14478910726747 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark06(-1.0799894784050217,-1.5707963267948966,-21.616850319082758 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark06(-1.0807027518734913,-0.2707251500977118,10.884699523911692 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark06(-1.0812532549989684,-31.415926539374066,-1.5707963267948966 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark06(-1.0816663247390421,-1.5707963267948966,3.2665927032153346 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark06(-1.082750023174335,-1.5707963267948966,-70.32043319574899 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark06(-1.0829314472115357,-0.9765585100974831,-58.221235580904775 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark06(-1.0831536530925048,-0.40185034117739493,-1.5707963267948968 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark06(1.0834213498197379E-16,-1.5707963267948966,-26.05848698036175 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark06(-1.0836358149491525,-1.0580042479914968,-96.04849490080798 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark06(-1.0840056403162805,-0.18587506033147924,-76.52107114811463 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark06(1.0842021724855044E-19,-0.5345769903243919,-26.887817067039947 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark06(1.0842021724855044E-19,-1.2442796939633116,0.5867104488097348 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark06(1.0842021724855044E-19,-45.16460573947263,-1.5707963267948966 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark06(-1.0851567719171613,-3.552713678800501E-15,-9.725328862807547 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark06(-1.0854435125804716,-6.938893903907228E-18,-1.2940493703183904 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark06(-1.087501027503011,-1.049794170802655,-1.5707963267948966 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark06(-1.0878532282686781,-0.869698049628975,88.35573368750764 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark06(-1.0879105833552098,-45.29365483593128,-1.5707963267948966 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark06(-1.0884212737681829,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark06(-1.0891317242530683,-1.5707963267947527,0.0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark06(-1.0903343373818235,-1.5707963267948966,9.441728905052088 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark06(-1.0907188483026984,-7.623207490464807E-14,1.5707963267948966 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark06(-10.907476583997095,83.16287341894915,-70.57844763283458 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark06(10.907892391857303,-7.491058825367276,-85.74056853697256 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark06(-1.0908083102917248,-88.29472409218025,0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark06(-1.0918404140321996,-95.44388727405529,-1.5707963267948966 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark06(-1.0919499717612497,2.465190328815662E-32,-60.017037749525144 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark06(-1.092056713562922,-1.570796326794877,53.13086831074864 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark06(-1.0926520915315436,-1.5707963267948966,-4.712450016316838 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark06(-1.0931301451964686,-3.1415926535901955,-1.5707963267948966 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark06(-1.0933709666306588,-1.5707963267948966,-85.81319285404338 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark06(-1.0936244391870193,-1.57079632645832,-73.05621629539503 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark06(-1.0942113518811176,-88.20873420518112,-1.624612129020079 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark06(-1.0946434531895763,-3.141592654026773,23.819040011182206 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark06(-1.0951447922954298,-44.40875560276814,-15.345144401950034 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark06(-1.0959046745042015E-193,-0.18506716347709684,83.77392787091375 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark06(-1.096236120731986,-1.5707963267948966,-71.45953694647973 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark06(-1.0982062493687166,-1.5707963267948966,3.141592653589793 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark06(-1.0999558563664094,-0.013050707019344868,-6.712389270809089 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark06(-1.1013474088515591,-1.5641274181117976E-148,-60.21248909034367 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark06(-1.1021598679313795,-0.10685545272847628,-53.73307666183591 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark06(-1.103223464829938,-27.883643576483053,-1.5707963267948948 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark06(-1.1036924335764478,-1.5707963267948966,86.10766688551007 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark06(-1.1047878852044013,-3.1415926535973,-37.4410284684472 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark06(-1.105427916872273,-1.5707963267948966,88.19937094964632 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark06(-1.1059083593386703,-1.5707963267948912,96.81284502443123 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark06(-1.1077471086421296,-1.5707963267948966,72.64297597518666 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark06(11.086539273815447,-81.07596485866087,99.716557207785 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark06(1.1102230246251565E-16,-0.002554755028053454,1.5707963267948966 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark06(1.1102230246251565E-16,-0.12139007323668541,6.631150953499799 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,-0.8381821934139108,0.0 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark06(1.1102230246251565E-16,-1.1823509486470434,-33.953929961358405 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,-1.570796326794877,0 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,-1.5707963267948966,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,-19.449445724986255,0.0 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,-64.3524495012959,0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark06(-11.103703950608491,73.39744487026366,7.273562839069527 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark06(-1.111240937919789E-6,-1.5707963202085615,-3.141592653589794 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark06(-1.1121860764952505,-0.7869982691767652,-2387.9283770061056 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark06(-1.1132013024562113,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark06(-1.1138533191995976,-227.42411717435624,-157.56433864169 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark06(-1.1141128210948854,-1.5707963267948983,-38.84007712338469 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark06(-1.1161928422858753,-1.5707963267948966,-81.11073828060638 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark06(-1.1168140955221724,-38.82886009805844,-101.83400962396203 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark06(11.168607105997182,45.094973103436246,-26.87828345148759 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark06(-1.1182337624049952,-1.5707963267948273,-43.98532968831472 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark06(-1.120117818539287E-9,-0.07535219596697383,-43.059864678498464 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark06(-1.1203057611977125,-0.823055691456618,2.5707963210141407 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark06(-1.1213704607146933,-0.3006156419373198,33.10715640442257 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark06(11.217357917372368,36.974772237824226,57.73745754365572 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark06(-1.122177970771886,-95.43768720697531,0.0 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark06(-1.122359319030597,-1.4249210226890057,-152.8687119368962 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark06(-1.1227924218769152,-95.3990259429597,-71.85641649363963 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark06(-1.123779394991688,-1.557385843867358,-61.63158661250598 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark06(-1.1241745901067302,-0.6707792678456457,-160.82425163468756 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark06(-1.1249924968374392,-1.5707963267948966,89.19258569367005 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark06(-1.1254334940998092,-0.19472771158338453,90.53882118622181 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark06(-1.1254436099262835,-0.2645028885849712,136.63497143915305 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark06(-1.1256358387068874,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark06(-1.125941993548496,5.170437212024839E-9,123.59930125058821 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark06(-1.1263655733957485,-19.410064169771026,-109.64127073534625 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark06(-1.1264547355568952,-1.389084165193168,-1.5707963267948966 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark06(-1.1269721827856736,-1.5707963267948983,-75.31111301508228 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark06(-1.1270725851789228E-131,-1.5707963267948966,43.79428180247762 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark06(-1.1272016363944537,-1.5707963267948966,-38.9145037577284 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark06(-1.1274831217309425,-0.29887583927469447,544.9450752989043 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark06(-1.1282081871458327,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark06(-1.1289487028571479,0,0 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark06(-1.1290484047085645,-1.4470611524595707,1.5717728897002914 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark06(-1.1293398694514514,-38.747523503565745,6.7123889804636026 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark06(-1.1297401961154805,-1.5707963267948983,80.20315091666555 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark06(-1.1308446779935237,-1.1619300789569778,-89.53545166249032 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark06(-1.131462438590259,-1.5707963267948966,6.7123889919922695 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark06(-1.1326994564720252,-1.5707963267948966,1.571772889666216 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark06(-1.1332843671084376,-1.5707963267948983,-175.62964813031527 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark06(-1.1335712311541606,-39.2693223026764,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark06(-1.1341308620911699,-31.524204585029445,-0.801025905010668 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark06(-1.135000548468873,-1.5707963267948966,1.5707967818586923 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark06(-1.1368706713877699,-1.5707963267949003,119.91724266298161 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark06(-1.1368896691676014,-1.5707963267948912,-16.606643551016482 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark06(-1.1378564053328137,-45.55309347686431,-12.623874404796132 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark06(-1.1378831821444404,-101.01680849168615,-83.25757037584518 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark06(-1.13804519746079,-1.5707963267948966,-83.5813990971451 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark06(-1.1380524797363597E-159,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark06(-1.138269842930225,-1.5707963267948966,-4.743788096213685 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark06(-1.139593801071225,-45.386270462867344,-1.5707963267948966 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark06(-1.1406760188388008,-2504.7627763149635,0 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark06(-1.140710201587412,-20.49950587424209,2.1175823681357508E-22 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark06(-1.1409565712172887,-31.98384838145405,-77.40015297244933 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark06(-1.1414779868907807,-101.05621486154274,-95.03788651801295 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark06(-1.1427743080180057,-1.5163577728491762,-53.62755582983307 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark06(-1.144496730852417,-88.39793834100024,-127.48628497340115 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark06(-1.147320857155886,-0.08178083345111974,-50.23984507904006 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark06(-1.1485169544683496,-0.23340294425820662,-1.5707963267948974 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark06(-1.1497327527068357,-1.3077930297216616,-0.4577685819403471 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark06(-1.1498667677167913,-101.08615938100958,-0.5005805575047915 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark06(-11.50663033201593,-14.299644555451522,69.79767113182857 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark06(-1.1507205216093876,-101.65265748842324,-1.2875075620317773 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark06(-1.1525866010899686,-20.252445366908738,0 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark06(-1.1529416714975298,-215.10992972085342,-100.53164422499962 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark06(-1.1544880356449805,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark06(-1.1553792958824927,-38.925433929735235,-0.3066281342510143 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark06(-1.155760698245146,-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark06(-1.1567650793023732,-1.5707963267948966,-31.755514786613233 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark06(-1.1591269220898192E-69,-31.423574337713802,-34.42625681359459 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark06(-1.159181178675549,-1.5707963267948966,-411.5486347652962 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark06(-1.1596248382959815,-32.55143847422035,-26.453922870307423 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark06(-1.1601132956511222,-1.5707963267948966,9.80477348189196 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark06(-1.160630386148062,-0.695110799862178,0.42026143746427364 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark06(-1.1610122491103227,-0.08166419952395776,-88.29803470499358 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark06(-1.161822184409398,-1.5707963267948954,-71.6723786588725 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark06(-1.1618361345019725,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark06(-1.163160330320016,-1.0010415475915505E-146,-56.96413081514877 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark06(-1.164259836064518,-94.28083525437721,-1.5707963267948966 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark06(-1.1645458855706181,-6.283185307179586,0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark06(-1.1646888776393627,-0.6826635289946394,96.11873792193923 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark06(-1.1650582981991775,-31.900822190841254,-1.5707963267948966 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark06(-1.1661066802597113,-0.1491753901664415,55.985640747708125 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark06(-1.167718830572513,-0.3507253830089645,44.24601570624587 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark06(-1.167840110181746,-1.5707963267948912,73.82678698127798 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark06(-1.1682908356829032,-44.31269567916536,-88.25657930934307 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark06(-1.1684380533083658,-0.5076959298779542,100.0 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark06(-1.1762044248496935,-1.3847496931518206,2.403089249263445 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark06(-1.1785010696831597,-44.17451047502411,-0.009034426761722511 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark06(-1.1791434096538687,-1.5707963267948966,0.4260424736284856 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark06(-1.1799306865439911,-1.014907841567495,52.29390512483128 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark06(-1.1833124118251268,-0.017089173073242887,1.5707963267948966 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark06(-1.1846638357622055,-1.5707963267948912,4.836224326629647 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark06(-1.1850042236143281,-1.5707963267948966,31.224312982799347 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark06(-1.1858266075833221,-1.5707963267948948,69.11503837897546 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark06(-1.1868475579185722,-1.4208421016823238,-9.73549102680088 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark06(-1.1869708140434894,-1.0801866288637854,-64.2432536743208 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark06(-1.186998748471956,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark06(-1.1881987826115736,-1.5707963267948934,-15.09577221816815 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark06(-1.189563038162353,-1.4288327097278666,110.89859463857323 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark06(-1.1908847678423342,-0.9746738661955208,9.433577945506165 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark06(-1.191567816101022,-0.30095585055761004,-1.5698188273492806 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark06(-1.1919056373891972E-4,-1.5707890311213726,-3.141592653589793 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark06(-1.1926071388806758,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark06(-1.1931312438815425,-0.15895561657658103,4.712432182135477 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark06(-1.1934403141076781,-0.6760768843144882,1.5707963267948983 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark06(-1.1970334791319657,-1.5707963267948966,-53.71291964210241 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark06(-1.1972598080128696,-1.5707963267948963,27.806233881120278 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark06(-1.1994404106874177,-45.43591192850921,-25.175759107557802 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark06(-1.199881772693991,-88.21217260633199,-19.35681364104391 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark06(-1.2000933433301806,-1.5707963267948966,-14.548789145757752 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark06(-1.201571218602305,-38.876582634768695,-1.5707963267948966 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark06(-1.2018585842500762,-1.2976221600075033,52.00831647843444 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark06(-1.2021459987682348,-1.5707963267948966,4.743662488394748 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark06(-1.2051396050085166,-38.85635026251847,-37.80589549609796 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark06(-1.205186071149558,-1.5707963267948966,-32.4988805351281 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark06(-1.2062500346395932,-31.415935356768813,-81.72830205543315 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark06(-1.206556310106875,-1.5707963267948966,19.39283715503663 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark06(-1.207507713014215,-1.5707963267948966,2.465190328815662E-32 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark06(-1.2079117318327173,-0.1366116984963062,8.106918828791398 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark06(-1.2080703987074424,-32.52065897458343,4.7123982266970526 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark06(-1.208793120417359,-1.5707963267948966,25.442714829673207 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark06(-1.2100312780779833E-23,-1.5707963267948966,-0.06936314473509267 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark06(-1.2100452587855246,-1.5146178401371262,-84.85270752514948 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark06(-1.210808452127391,-1.5707963267948966,-72.34653704592117 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark06(-1.2109943924736886,-0.994447222971695,67.26405373689776 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark06(-1.212074109732656,-1.5707963267948966,31.969215349839917 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark06(-1.2120763845096116,-0.3249451652849124,-10.651691050566562 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark06(-1.2166234350780143,-0.0392317675091573,3.1415926535897936 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark06(-1.2182261523267592,-1.5707963267948963,-1.5707963242660294 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark06(-1.2185749474806713,-94.28699584151032,-1.5707963267948912 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark06(-1.2190226157076793,-44.12200562369821,-84.77296109949417 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark06(-1.2196537175574105,-0.9697578470381565,-13.356476487817625 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark06(-1.2199232638481345,-19.384596283881123,-72.06040048953386 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark06(-1.2200088670725175,-1.1195888190182544,-82.29200294898078 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark06(-1.2219745453998419E-150,-0.09071299696604151,-83.6065832436148 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark06(-12.229034400591644,45.09137382640941,39.78571594727049 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark06(-1.2229268026722626,-2.220446049250313E-16,-8.505302227422874 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark06(-1.2232618067995316,-1.5707963267948963,-72.75697699330485 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark06(-1.22351340175094,-31.427124137083368,-1.5707963267948961 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark06(-1.2240822964879368,-1.5707963267948948,28.091575979468217 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark06(-1.224429869260942,-1.5707963267948928,1.5707963267948983 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark06(-1.2273615460413474,-1.4120483478384498,-79.10258784908608 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark06(-1.2280241288916478,-1.5707963267948966,75.73960042462834 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark06(-1.2287722952770364,-45.46677860155535,-70.95621209214836 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark06(-1.2292134336130096,-1.5707963240869356,1.5707963267949023 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark06(-1.2295902412481496,-88.2812501797734,-31.45130290859587 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark06(-1.2323620741227368,-1.570796325372194,-71.30362453740177 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark06(-1.2324828440210713,-1.8033161362862765E-130,-1.5707963267948966 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark06(-1.2335691974650649,-0.7349576464150327,22.718164934163212 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark06(1.2347010535327177E-22,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark06(-1.235444184204738,-3.1415926535897976,27.14191777174093 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark06(-1.236025989683127,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark06(-1.2366001657054042,-45.16157333177303,-51.69800784190432 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark06(-1.2367759175863293,-1.5707963267948966,53.64381808335901 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark06(-1.237117672876685,-0.8663075617505758,-63.46741703091635 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark06(-1.2372260408560458,-0.36123454684899226,73.73073356749083 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark06(-1.2385782964251888,-0.6079697776229361,-8.612830953528757 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark06(-1.239176537377464,-88.38031576883753,-37.85183900167293 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark06(-1.2394177609270685,-1.5707963267948966,-37.58294720541853 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark06(-1.240100127779522,-39.223007861648725,-51.278596686163574 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark06(-1.2403656861084909,-1.5707963267948966,0.14668035932742918 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark06(-1.2405750908258777,-1.5707963267948966,1.5707963267947171 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark06(-1.2410832082531935,-1.5086489682464743,3.2665926543028556 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark06(-1.2428692019882648,-37.699111846127835,-96.81677179591895 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark06(-1.2431170653898924,-1.5707963267948966,1.0878647673455597 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark06(-1.2444126882057247,-1.5707963267948966,-79.75529653436519 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark06(-1.2451024026649038,-1.5707963267948966,36.24386057569194 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark06(-1.245841259326515,-0.2992829335633571,33.48014055677548 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark06(-1.2466123245183378,-1.5707963267948912,1.5707963267948966 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark06(-1.2488282741962096,-1.5707963267948966,1.5710404677612422 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark06(-1.2493847963636053,-0.42096272482471325,9.561095669811074 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark06(-1.2495517575767798,-38.99157081539892,-65.88041104186412 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark06(-1.2497301855125416,-0.9771553562443955,-134.78849077837037 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark06(-1.2501499217639114,-32.84482514416553,-561.540892849363 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark06(-1.2507095067506433,-1.5707963267948966,43.59624996624296 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark06(-1.251227717767837,-32.7555195434099,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark06(-1.2517366612879341,-5.551115123125783E-17,-3.2669747135426377 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark06(-1.2538147287376886,-29.73406525853018,0 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark06(-1.2543362166728542,-1.5707963267948983,17.460090859407913 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark06(-1.2550887513670874,-0.8411033308024058,-41.06590006973375 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark06(-1.2551238734785435,-0.5281094677205478,39.05272808313478 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark06(1.2551780153643362,-1.2984836203902614,100.0 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark06(-1.2556686898893432,-1.5707963267948963,97.10000495016993 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark06(-1.2569762022668085,-100.54885176865686,-1.5707963267948974 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark06(-1.2583205497930203,-1.5707963267948966,42.27262154116741 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark06(12.58769001797559,-41.372045802423905,12.737742474133967 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark06(-1.2604181814143316,-1.5707963267948966,0.8392366063342662 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark06(-1.261792529478496,-1.5707963267948963,-69.40974141902701 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark06(-1.2618299400304882,-1.5707963267948957,-3.1415965309910177 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark06(-1.2621774483536189E-29,-1.5707963267948966,-40.840704496667314 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark06(-1.2622107448592388,-0.943496333287413,-1.5707963267948966 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark06(-1.2622169225998097,-0.12567521466243445,1.5707963267948966 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark06(-1.2622178238399933,-1.0028651185459179,0.0 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark06(-1.2624963125780275,-1.0293860944558257,7.278885803434182 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark06(-1.262865790568193E-13,-2.3116225478894198E-14,-3.141592653589793 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark06(-1.2638720243672543,-3.141592654489464,-39.95150564664497 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark06(-1.2640639744145015,-0.7325151534733436,543.3292120977022 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark06(-1.2643346537348543,-1.5707963267948966,-11.519132022714867 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark06(-1.26463560502863,-1.3224627914893032,8.673617379884035E-19 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark06(-1.2649447877772395,-6.586561777303963E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark06(-1.2657918791615588,-0.7303614549808832,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark06(-1.266135018188471,-44.48848055356292,0 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark06(-1.268391366719666,-101.57561794991602,-90.54612030500333 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark06(-1.2689709186578246E-116,-1.5707963267948966,31.96798320365764 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark06(-1.2695873888250224,-3.141592653590212,-73.08698828738851 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark06(-1.2701904307536105,-3.141592653593755,66.5024409038675 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark06(-1.2708824017505544,-3.141592653589828,1.5707963267948966 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark06(-1.2710958740222653,-0.1186808248039577,100.0 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark06(-1.2711519371190896,-31.626588039755404,-52.07794033880803 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark06(-1.272524624921302,-1.0719061273887485,-439.5385358061884 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark06(-1.2734021606699433,-1.5707963267948966,-84.82348993388678 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark06(-1.2758220247880274,-1.3856895622273875,-93.68499479307168 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark06(-1.2772982646478137,-1.5707963267948966,-49.68529095758774 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark06(-1.2785610531801732,-1.5707963267948966,-79.62212144634856 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark06(-1.2790207354690466,-1.5707963267948966,12.137622935165709 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark06(-1.2792220993607288,-95.5100978920342,-3.1415926535897754 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark06(-1.279296151692043,-1.5707963267948966,-85.09466689753704 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark06(-1.2793220887285657,-37.91961503246925,-45.51736246686862 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark06(-1.2796702027830356E-11,-1.5707963267948912,-15.70769339567855 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark06(-1.2797436067950212,-1.0435754757495206,55.505783031990646 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark06(-1.280653550331327,-1.5707963267948963,-11.756755845976251 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark06(-1.281190711748092,-0.9790674228971508,0.5121178300402078 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark06(-1.2812002541790108,-1.5707963267948966,-79.06220698641752 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark06(-1.2820559357807895,-1.5672616300891153,34.11180957598147 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark06(-1.282367562731295,-0.8382103302429851,44.353235358610476 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark06(-1.2828824624905293,-0.015338060457705083,-3.484091515132377 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark06(-1.2839872641285495,-163.37937976761495,-88.28855928213505 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark06(-1.2842605556660263,-1.5707963267948957,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark06(-1.2843403699094595,-1.5707963267948966,1.9721522630525295E-31 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark06(-1.2865145933268565,-1.5372859174600442,57.22950655466627 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark06(-1.2868893973670072E-85,-1.5707963267948966,-2.341248665344121 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark06(-1.2878593361185622,-1.5707963267948966,-14.429251584136978 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark06(-1.2882153405839565,-1.1667909466534767,48.252289470493196 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark06(-1.2888446319221332,-0.5056176156955745,-113.9229846424348 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark06(-1.2891569757411556,2.0699537615324136E-17,56.89366860954305 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark06(-1.2895377949010907,-1.5707963267948983,-10.995574422371181 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark06(-1.2898824186079278,-0.780220819504182,54.67141365760482 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark06(-1.2919507536520491,-45.123788237489485,-480.45945487591337 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark06(1.2924697071141057E-26,-1.5707963267948966,-22.72603691918456 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark06(-1.2929492603395842,-0.7427907653868276,0.0 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark06(-1.2932090936145149,-1.5707963267948966,-42.477762623992255 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark06(-1.2936466812068204,-1.3172446672975893,164.77526957393079 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark06(-1.2939412121548446,-1.1061542262879864,0.0 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark06(-1.2939538284949739,-1.5390104046456223,0.0 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark06(-1.2944394714746308,-1.5707963267948966,-39.77006238809576 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark06(-1.2949725796216305,-88.26843541170699,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark06(-1.295087936904764,5.421010862427522E-20,62.039910053939934 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark06(-1.2954490451347958,-0.6155407513818975,-77.14271310789893 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark06(-1.2962236867110732,-1.3654889859792292,-44.52619640409875 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark06(-1.296324463851979,-1.5707963267948966,33.306188014889145 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark06(-1.2970319735128761,-1.5707963267948966,-68.81157069704669 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark06(-1.2971451218271086,-0.4369955496500291,-100.0 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark06(-1.2972405501697075,-1.5707963267948966,-78.89814208538442 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark06(-1.297733804302445,-3.141592653589794,0.2822802914748306 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark06(-1.2978692626456905,-88.11649624220695,-101.68572578353982 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark06(-1.297905170808301,-32.7685289454311,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark06(-1.2985514732635153,-1.5707963267948966,-71.87543579114626 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark06(-1.299033174877031,-0.5345765845128561,100.0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark06(-1.29997113893819,-3.552713678800501E-15,16.480492553336518 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark06(-1.3002056639212096,-1.5707963267948966,4.141608765384717 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark06(-1.3007532453742545,-0.30942734681502415,-58.815045438526404 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark06(-1.3011173030523118,-1.5707963267948963,-6.923937961329102 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark06(-1.301471503000713,-1.567383935961655,-191.79250283847125 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark06(-1.3016489863932923,-0.9638020642946339,1.5707963267948966 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark06(-1.3021880693394134,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark06(-1.3025370424388727,-1.5707963267948966,51.563864100620705 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark06(-1.3054420604243293,-1.5707963267948948,-83.66727696524856 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark06(-1.3061707946797845,-1.5707963267948966,17.45831885770552 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark06(-1.3068228889012232,-1.5707963267948966,-4.917358106998943 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark06(-1.3068870858501094,-0.3250905108011606,1.5707963267948963 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark06(-1.3076818131187407,-45.073043796630834,-0.9931550921890309 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark06(-1.3088414509890747,-1.5707963267948966,9.424777960842706 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark06(-1.3096832383574701,-45.37882958635642,-20.911956434634124 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark06(-1.310753737358024,-94.2477796076938,-1.5707963267948966 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark06(-1.31201938785042,-1.5707963267948966,-404.99184212753784 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark06(-1.3127085833122805,-1.5707963267948966,-64.45314997758746 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark06(-1.3129460659130432,-1.5707963267948966,-44.31122627969942 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark06(-13.144314832223273,58.68204669367077,-5.3614625314040865 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark06(-1.3177747429038154E-82,-0.5095900255596315,-72.67955635540781 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark06(-1.3178807322674766,-88.40211171587272,-1.5707963267949125 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark06(-1.3182854471428265,-0.7437034248333652,6.142181052639945 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark06(-1.318403563323634,8.673617379884035E-19,-68.82897199051877 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark06(-1.3187178539237923,6.776263578034403E-21,36.08446917109772 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark06(-1.319609184629435,-1.5707963267948966,45.884090147606365 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark06(-1.320510751254674,-1.5707963267948963,-28.166507325825663 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark06(-1.3211130257822594,-0.6758122320320841,-4.714342105482337 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark06(-1.3214874311167772,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark06(-1.3219401975788458,-1.5707963267948948,45.73372757510347 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark06(-1.3231498452554484,-0.8906003732298343,2.1843270415510005 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark06(-1.323473228290773,-84.42691449193441,-21.64368143300578 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark06(-1.3241180080440347,-1.4922723481662383,54.88745153458498 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark06(-1.3248425953786624,-0.21727994184042004,385.83641012099076 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark06(-1.325043003700229,-38.858184363629334,6.712389107646643 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark06(-1.3257899221598304,8.470329472543003E-22,0.0 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark06(-1.3260474057309821,-1.5707963267948966,-65.68681887472005 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark06(-1.3261471587267375,-37.815056977583495,-1.969459740647191E-11 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark06(-1.3261887187024028,-1.4735921314526252,-1.5747174526306735 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark06(-1.3262062954552996,-1.1239840839109307,-81.4091162281901 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark06(-1.326345142100843,-1.5707963267948966,9.424779152261438 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark06(-1.3275228286190635,-0.8857251756489561,4.712389949173796 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark06(-1.3275532398334318,-0.26388706155909136,77.48397557412864 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark06(-1.3276397332484948E-14,-1.5706101047981766,-40.84598442000055 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark06(-1.3293893639462269,-1.5707963267948961,31.957926664026743 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark06(-1.3295580656938424,-1.5707963267948966,-1.5707963267670952 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark06(-1.3304362374608756,-3.141592653589914,26.428182870833126 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark06(-1.3306494145291536,-0.43541778431806,61.82722974691393 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark06(-1.3331858428388415,-0.6409664707653075,99.3711356482018 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark06(-1.3336670407779103,-6.2565096724471904E-148,-4.794623330041086 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark06(-1.3340308201211677,-1.82877982605164E-99,-90.35133182842199 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark06(-1.3344611993981275,-0.4024924939663322,55.0293452725752 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark06(1.3344661685043192E-26,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark06(-1.3347109439100011,-37.871562118795325,-1.5707963267948966 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark06(-1.3352989663660937,-1.956455990313156E-15,-1.5707963267948966 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark06(-13.35699902856058,39.964453357447866,86.3201428952105 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark06(-1.336385890558257,-158.62905870608782,-51.61979158292541 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark06(-1.3368870176152188,-346.61251601434697,-28.24741022693378 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark06(-1.3374236501022136,-227.7638302813293,-95.68724643335325 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark06(-1.337504949689661,-1.5707963267948966,-4.714344946888932 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark06(-1.3392243245553423,-1.5707963267948966,-81.94928736267221 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark06(-1.339367400380309,-37.8784140357116,-1.5707963267948977 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark06(-1.3395788071250172,-1.5707963267948948,2.070796326838984 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark06(-1.3405860520626238,-1.5707963267948966,7.888609052210118E-31 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark06(-1.3424156719904,1.5707963267948963,0 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark06(-1.3433319851447283,-1.5707963267948966,-27.364170952838847 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark06(-1.3439180254706582,-1.5556980141804269,-1.5707963267948948 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark06(-1.3450590542313847,-1.5707963267948948,-7.5473963381076885 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark06(-1.3463511094923084,-164.49899772259747,-7.774147339576729 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark06(-1.3467760921808036,-1.5707963267948961,-112.14913331086512 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark06(-1.3474966125650014,-84.7401690587997,-8.487157809162118E-16 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark06(-1.3496460013651834,-1.5707963267948966,-158.5149825311465 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark06(-1.3508469546194746,-1.5707963267948966,60.013642685398395 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark06(-1.3511052482126231,-1.5707963267948966,-11.643859285738152 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark06(-1.3531772890677207,-102.0051187178685,-44.51338562714686 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark06(-1.3535629855482456,-0.6044919771676538,1.5707963267949054 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark06(-1.353778115728855,-37.89112647967314,-95.35427413311696 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark06(1.3552527156068805E-20,-1.2057894110971723,15.996425180377287 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark06(1.3552527156068805E-20,-1.5707963267948966,-1.2772068326524815 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark06(1.3552527156068805E-20,-1.5707963267948966,95.38661653840379 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark06(-1.3554790465637425,-37.93423902111232,0.21971056821802373 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark06(-1.3560055177565955,-45.046417201661484,-70.05866273796903 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark06(-1.3571019786623417,-1.5707963267948966,-67.66361122190264 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark06(-1.3571562307267488,-1.5707963267948966,68.1764347381264 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark06(-1.3575497066915843,2.1684043449710089E-19,-32.56318292657983 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark06(-1.3576821753350057,-31.921258274070325,-83.21163957110322 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark06(-1.3582535613543667,-83.41451753460107,-78.34907577251454 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark06(-1.3582811755477882,-0.1928154210137632,-59.55245670352153 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark06(-1.3587816588524906,-1.5707963267948963,83.34040551495774 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark06(-1.359023622550392,-0.3794509128174164,107.90733957620445 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark06(-1.3592963189618443,-4.4489683351476086E-5,67.67963102339448 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark06(-1.3615728268071965,-0.23378161106181,-851.9814078333853 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark06(-1.364341906297272,-0.2836385443820723,3.2491301587455723 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark06(-1.3645817475850919,3.944304526105059E-31,0.5661015469257032 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark06(-1.3648598704371224,-0.9266537113896791,92.170841216489 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark06(-1.3657201293981966,-1.5707963267948966,-23.325021343446494 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark06(13.659266946374998,42.05384148118884,83.90448431889442 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark06(-1.3678804290493074,-0.3418744043493976,1.778206999588062E-161 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark06(-1.3684981424147025,-1.5707963267948966,-32.710160796927845 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark06(-1.3690578921918581,-1.5707963267948966,-2.161507586370636E-15 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark06(-1.3695080919126676,-1.5707963267536342,1.5707963267948966 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark06(-1.3695988489400799,-88.11686389045646,-1.5707963267948983 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark06(-1.3696023015147727,-88.1123898404031,-221.2217069161794 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark06(-1.369682544466635,-1.5707963267948966,19.36261949650406 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark06(-1.3698808431302519E-194,-32.478043084145355,-1.5707963267948966 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark06(-1.3703235006367336,-1.5707963267948966,-0.9237185052921677 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark06(-1.3703502401727956,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark06(-1.3706254168083545,-1.5707963267948966,96.48095440248044 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark06(-1.3712324509270595,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark06(-1.3725252295349089,-1.5707963267948966,9.804589533942384 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark06(-1.3725871166342585,-31.980407900012747,-1.2833518811025773 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark06(-1.3731737036971607,-31.41592654427004,-1.5048514259250827 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark06(-1.3739231604049449,-1.5707963267948966,3.141592653589793 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark06(-1.3744697227462874,-4.320965511754594E-16,-42.52468012846447 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark06(-1.3744845577062368,-37.94237208594433,-3.141592847431474 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark06(-1.3748268635285132,-1.570796326362374,-60.0437868662748 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark06(-1.375924271508503,-227.76383917613666,-59.53468131297767 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark06(-1.3779211387829777,-1.5707963267947307,51.1849984324997 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark06(-1.3785452643924494,-1.4542397432621548E-15,54.08602533504295 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark06(-1.3797371630414443,-1.5707963267948966,-3.899751448457451 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark06(-1.3804513225108674,-38.872347762494336,-2.4180624194389764 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark06(-1.3810728787789985,-2.5626663618343692E-144,-6.273101713267489 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark06(-1.382270768628272,-1.5707963267948963,-3.1415926535897953 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark06(-1.3828123313068106,-38.9058977260142,-1.5707959109932783 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark06(-1.3829050049570033,-1.5707963267948966,-49.30646427493199 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark06(-1.3829108632479792,3.944304526105059E-31,-66.59544545885365 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark06(-1.3831864087887453,-1.4655822446549034,3.141592654894212 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark06(-1.3850204843840241,-1.4416803461321515,31.88082314190484 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark06(-1.3855482016018554,-1.5707963267948966,73.27958214169058 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark06(-1.3858697972800433,-1.5707963267948966,1.5707963267948961 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark06(-1.386062848544375,-1.5707963208293831,105.7219829222729 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark06(-1.3865825437779773,-1.5707963267948963,-4.743639618088193 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark06(1.3867975032029276,1.5707963267948966,-1.006337753586074 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark06(-1.3868414934727114,-0.44168840196197356,-6.713367325561534 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark06(-1.387342140792323,-1.5707963267948966,369.6880179899937 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark06(1.3877787807814457E-17,-0.3076228849664251,0.0 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark06(1.3877787807814457E-17,-1.4461049152135708,74.59019483333896 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark06(-1.3877787807814457E-17,-1.570795569788083,72.26837355834641 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark06(1.3877787807814457E-17,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark06(1.3877787807814457E-17,-1.5707963267948966,-18.120895833559487 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark06(1.3877787807814457E-17,-1.5707963267948966,-78.31610277691604 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark06(1.3877787807814457E-17,-44.10383877407784,-1.5707963267948983 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark06(-1.3887347489121142,-2.1267030325708786E-15,0.17043162791969002 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark06(-1.3888494828065325,-1.5707963267948912,17.27876980420301 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark06(-1.3893403475047108,-1.5458829850322684,-84.82300164692441 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark06(-1.3895137292770793E-15,-0.2955300670788985,39.56297187928786 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark06(-1.3901221069889322,-1.5707963267948966,-31.15577800636298 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark06(-1.3912661916156466,-1.5707963267948966,-0.9290248109707837 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark06(-1.3914254726050033,-1.5707963267948961,0.0 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark06(-1.3923743065596028,-0.09682443727223757,32.90705006128894 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark06(-1.393172699118268,-0.899906383880344,-1.5707963267948983 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark06(-1.39320782785986,-31.9451554931417,-1.5707963267948966 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark06(-1.3940579753464735,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark06(-1.3945148823185014,-1.2573980516009589,-120.57610199247175 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark06(-1.3948168634387463,-45.37447979561554,-63.89745067205319 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark06(-1.3960187841755247,-1.5707963267948968,44.346400721688944 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark06(-1.3962269317757916,-1.5707963267948972,119.98057658437942 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark06(-1.396773715884481,-32.79157705734792,-1.1664905254208855 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark06(-1.397346310570664,-1.5707963267948963,61.87431498093582 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark06(-1.3984537639288388,-1.5707963267948966,56.14896090542754 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark06(-1.3993342719612416,-1.0959242701362797,-4.714342123814048 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark06(-1.4000809783140364,-1.5707963267948948,31.42956525753232 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark06(-1.4015643439716008,-0.6011426811818593,-0.8568359776818034 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark06(-1.4025753228532296,-0.7533757184192496,49.14812992446599 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark06(-1.4026136453759845,-2.1684043449710089E-19,-46.00332306325187 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark06(-1.4028221980863265,-32.905311227196606,-56.54867991904814 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark06(-1.4048002062061435,-0.3973361719835946,-38.723019583420296 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark06(-1.4049569745153938,-32.46016118943331,-12.909019469518412 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark06(-1.4058197922027378,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark06(-1.4062822710741785,-1.5707963267947476,77.5014780184409 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark06(-1.4066707965689926,-8.881784197001252E-16,-102.75766013928609 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark06(-1.4075988295586304,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark06(-14.078628577008772,19.02651590196838,-2.5277852775863323 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark06(-1.409972896536773,-1.3880969426445082,4.714342105450979 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark06(-1.4102029638448945,-1.3141493872748472E-16,-2.0095926543672238E-15 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark06(-1.410327324204875,-1.5707963267948966,4.743639248933126 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark06(-1.413439603649827,-95.75768409091808,-1.5707963267948966 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark06(-1.413818476873005,-1.5707963267948983,-67.71019815780477 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark06(-1.4142520907408571,-1.5707963267948966,-57.39704709255858 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark06(-1.4145971188723312,-1.5707963267948923,-99.64479245331293 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark06(-1.4149498560666738E-73,-1.5707963267948966,-48.17910292099701 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark06(-1.4149498560666738E-73,-1.5707963267948966,-58.36430835728784 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark06(-1.4179228564201742,-1.5707963267948966,40.443585094660506 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark06(-1.4181951221594167,-0.610805662421004,-4.837389230842789 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark06(-1.418429375293767,-1.5707963267948966,-17.279436693148515 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark06(-1.418581585114347,-8.89103499794031E-162,-70.13292219343121 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark06(-1.418950727840027,-0.8568145808706373,-4.7436392352373336 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark06(-1.41907987346462,-1.1466276801321922,0.9117981191567948 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark06(-1.4195209106465825,-38.93171842070413,-28.148668662206344 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark06(-1.4204047902514345,-1.5707963267948966,-99.29431005502235 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark06(-1.4207178570975385,-1.5707963267948912,-15.415649006761242 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark06(-1.4210854715202004E-14,-1.0771222473349422,9.588034857158405 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark06(-1.4214803475306277,-1.5707963267948966,-0.015586167539563272 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark06(-1.4219759695919003,-1.5707963267948966,93.32587876663555 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark06(-1.4225655996704496E-160,-1.1343646177746438,-7.395819428478253 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark06(-1.4229139528835932,-1.5707963267940492,-61.77550912883606 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark06(-1.4229495950237632,-1.5707963267948966,-28.47706749873953 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark06(-1.423343414800971,-44.39293763484079,-0.0024007268897486313 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark06(-1.42456968009573,-37.87356131973743,-1.5707963267948966 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark06(-1.4246657520280612,-1.5707963267948966,-25.070547509316626 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark06(-1.4249484986839953,-31.41592653589823,-77.84596270261741 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark06(-1.427041992292537,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark06(-1.4272992229914319,-1.7763568394002505E-15,3.1415926685021964 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark06(-1.4275780679680672,-1.5707963267949019,-0.76813269654755 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark06(-1.4278771732754214,-1.472049698203148,-29.33164167655687 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark06(-1.4279296767593252E-6,-32.98508055308118,-72.25162081955317 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark06(-1.4280397481997058,-1.5707963267948966,-38.687389792643124 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark06(-1.4280965059932433,-1.5707963267948966,-1.5707040924664724 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark06(-1.4287138470255105,-164.54237016873896,-133.79401508294822 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark06(-14.294009282253,99.31905768227932,49.986402580142396 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark06(-1.4294505264315656,-0.07699818862792718,0.0 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark06(-1.4294589054121047,-1.5707963267948912,68.90035036957352 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark06(-1.429873069541662,-1.5707963267948966,0.4650502772135244 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark06(-1.4304302464002492E-16,-1.5640642280231858,2.3153963633381807 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark06(-1.4309781468697698,-0.027531012509462105,-10.76381137912532 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark06(-1.431470153519334,-32.69232400595038,-114.23914476001613 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark06(-14.318530406139885,-34.87298898707812,66.8908092314721 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark06(-1.432045667687352,-1.5707963267948966,1.5707963267948974 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark06(-1.4324885843788457,-1.5707963267948983,85.07399254685919 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark06(-1.4329704591016859,-1.570796324426897,0.7439252032784444 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark06(-1.4330825299095604,-1.5707963267948966,4.743639059475618 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark06(-1.4342903946405763,-1.5707963267948966,-38.735417215879295 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark06(-1.4343851487684778,-31.603249280052744,-0.5722087110206644 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark06(-1.4349422866307346,-32.70736786736852,-1.5707963267948966 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark06(-1.4359116109401644,-31.867162888374665,-1.5707963267949054 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark06(-1.4359213360860013,-0.73577554229207,29.84522044880245 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark06(-1.4359638459415847,-1.5707963267948966,67.61126008917769 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark06(-1.4363869213255178,-1.4355386095439995,-80.70322826593059 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark06(-1.4368531782772036,-1.7763568394002505E-15,76.92996064965014 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark06(-1.4378424220325952,-0.5642685030616601,1.5707963267948966 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark06(-1.4382445207817114,-0.4266850544002588,-2.4410647079556416 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark06(-1.438391631524959,-43.98229744234277,-122.02216885964857 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark06(-1.439420525336243,-1.5707963267948966,10.788680987594162 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark06(-1.439430069668486,-0.3669915150277977,-1.070192074764388 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark06(-1.439815578515784,-1.5707963267948966,62.23283129284923 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark06(-1.4404670660176508,-0.8757649130937445,1.57079632638114 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark06(-1.4407910268449946,-1.3552527156068805E-20,100.0 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark06(-1.4414244219817389E-8,-1.5707963267948966,-78.53901903970667 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark06(-1.4421665500579297,-3.141592653589807,44.52886634667729 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark06(14.429205052234387,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark06(14.429205703849611,1.5707963267948966,-9.102529644902166 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark06(14.429218080717831,-70.11803454135934,-100.0 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark06(14.429337055333754,1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark06(14.429357102285906,-1.5707963267948966,-3.8970405733643493E-16 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark06(14.42935853084532,-3.2181577756586317,0 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark06(14.429496383712916,-1.5707963267948963,74.57934331586077 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark06(14.429515099131187,-0.14769345808933698,100.0 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark06(-1.442974895393882,-1.367961453549956,55.28129179680545 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark06(14.429861538655679,-47.20755319729827,0 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark06(-1.443034869487363,-1.0842021724855044E-19,-76.69737969016504 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark06(14.430451445902207,-1.5707963267948966,81.86208947596941 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark06(14.430509925128256,-1.570796326794898,-0.09488101856050823 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark06(14.43134200283707,-1.5707963267948966,43.22285429603468 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark06(14.434909291064116,-1.0811720083626233,1.1197871590484998 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark06(-1.4436997886258423,-1.5707963267948966,43.88161443600083 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark06(-1.4442154556313975,-1.5707963267948966,-36.83952187309338 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark06(-1.4445298987756683,-1.5707963267948966,34.151138635389444 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark06(14.448977713660604,1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark06(-1.445370933247274,-45.031503462689386,-1.5707963267948966 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark06(-1.446023434258343,-0.2365919878315421,-9.42477797182571 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark06(14.461539199116139,1.5707963267948966,-44.52577051186648 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark06(-1.4471637458688267E-6,-1.5707963267948966,-164.9336141301025 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark06(14.474557280128195,-113.641101849439,-87.86501165193673 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark06(-1.4477035994208136,-1.5707963267948966,-1.5707963267948957 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark06(-1.447910822326064,-1.5707963267948966,-10.332495744271391 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark06(-1.4479558168927809,-1.5707963267948952,22.25569046407061 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark06(-1.4482480530849506,-1.5707963267948966,-74.29192219640167 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark06(-1.4492360613688522,-1.5707963267948966,-2327.9170527499273 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark06(-1.4504413952563617,-1.5707963267948983,17.100213196517956 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark06(-1.4504578252450122,-1.5707963267948966,-87.11056755549431 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark06(-1.4507964202016332,-1.5707963267948912,1.7624706721391714 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark06(-1.4510128476842352,-3.1415926535897967,75.0305983906101 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark06(14.510939956457555,-100.0,0 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark06(-1.451277172512509,-1.298854390992118,87.96462481991924 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark06(-1.451604870831216,-1.5707963267948966,3.141592653589793 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark06(-1.4517817894515683,-1.4802099738633256,-1.5707963267948966 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark06(-1.4521158742823235,-1.5707963267948966,-16.13716694115407 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark06(-1.4525836706791295,-1.5350534081609795,-60.25744677455468 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark06(-1.4529070415991578,-38.75933932356284,-348.7162527259447 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark06(-1.45362271009175,-0.4291873742879162,-128.9167179259324 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark06(14.538237974530013,1.5707963267948966,-25.3581302821964 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark06(-1.4543536637825856,-0.6201563567372268,-39.40424335442931 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark06(-1.454510575642551,-0.7114248058123055,-0.17903491195733925 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark06(-14.546511031685341,-93.31750705418791,-68.86458074834229 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark06(-1.4557086272291917,-1.4273370970954025,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark06(-1.4566011156336784,-0.5692615541172947,-23.211303467568186 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark06(-1.4566186710138445,-1.454259151075343,66.48942816743966 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark06(-1.4573926936090764,-44.41834678360846,2.580421166665188E-9 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark06(-1.4575026360059031,-1.5707963267948966,-108.29251831690438 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark06(-1.4575359550335403,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark06(-1.4578227389168448,-0.20970570706287117,-6.854535905181644 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark06(-1.458531071560066,-94.32083983001675,-1.5707963265011469 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark06(-1.4592501330372727,-1.5707963267948966,1.8866504500612251 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark06(-1.4604384578223542,-31.846963991086504,-39.38527203776525 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark06(-1.4607091874952665,-88.34653941633506,7.888609052210118E-31 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark06(-1.4626517267874233,-1.09603012184291,-1.5707963267948961 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark06(-1.462685576189282,-1.5707963267948983,-93.17221342561994 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark06(-1.4633771163478633,-1.5707963267948948,45.694427228356375 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark06(14.646769625183808,81.50173073317742,-97.6739483386724 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark06(-1.4659132958549057,-1.5707963267948966,21.991148639178085 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark06(-1.465941978363614,-1.5707963267948966,-9.12171648247501E-4 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark06(-1.4662077316499271,-1.5707963267163425,-77.33265002948413 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark06(-1.466464801753325,-0.5882134299432896,68.76155180814642 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark06(-1.4678635890779659,-1.5707963267948966,-4.837422484756144 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark06(-1.4683061961706185,-0.1269171791031205,1.5707963267948966 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark06(-1.4714420183408956,-0.30397864664373486,-793.2301205724282 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark06(-1.4718299188051538,-0.2918383524994918,-34.87041609140968 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark06(-1.4719415558638598,-1.5707963267948966,71.64520499005911 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark06(-1.4723806447567584,-1.5707963267948966,85.68924828683355 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark06(-1.4724408113587546,-38.89772569165584,-15.17189173498684 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark06(-1.4729139981040777,-1.5707963267948963,1.5707963267948966 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark06(-1.4734786448558257,-1.0589468940898705,-43.085485125013975 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark06(-1.473698369587112,-45.001009473592035,1.5706465822313052 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark06(-1.4738584152158525,-1.5707963267948966,76.54628902609281 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark06(-1.4744325257620603,-1.5707963267948966,77.42537504969337 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark06(-1.4749653813580015,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark06(-1.4750122613670598,-1.5707963267948966,-4.743639020935292 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark06(-1.4756415771981932,-1.550659434353404,3.1415926535897967 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark06(-1.4764419976120624,-1.5707963267948966,4.714342142318316 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark06(-1.4764581379100192,-1.3926683021676467,0.050893297815766125 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark06(-1.4764583568647074,-38.86572180566534,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark06(-1.476701615838627,-1.5166300777555357,157.423612779321 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark06(-1.4768344405496847,2.7755575615628914E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark06(-1.4769485471682593,-1.5707963267948966,76.03574436289202 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark06(-1.4786534118521755,-1.5707963267948966,0.2551343288594236 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark06(-1.479010543898271,-101.60692802380302,-51.00317451548001 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark06(-1.4790470486980065,-31.41592654230836,-1.5707963267948966 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark06(-1.48083495935817E-16,-0.8038099361789796,-1.5707963267948966 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark06(-1.4817988777457307,-1.5707963267948963,3.5453837020599632 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark06(-1.482057123429466,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark06(-1.4824411551034449,-1.5707963267936642,-17.22291869316105 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark06(-1.4824892087518646,-1.5707963267948966,13.782087338984159 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark06(-1.4832776407894883E-13,-1.5707963267948966,-78.22883807551746 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark06(-1.4834863358545582,-0.6270028690490376,49.31237903092777 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark06(-1.485568289611095,-1.5707963267948966,84.67281668732943 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark06(-1.486711279081426,-0.053649444177640504,-39.84942823566744 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark06(-1.4870154391105714,-101.7713195082244,5.141592914261233 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark06(-1.4870853247504352,-3.1415926535898357,-100.0 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark06(-1.4871872009089206,-0.8180806267170195,-1.571079434762477 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark06(-1.4872489552926118,-0.02357746997933806,3.141592653589793 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark06(-1.4876613867403305,-32.86233344649208,1.5702152200806616 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark06(-1.4879028661732425,-5.551115123125783E-17,1.1218169574758459 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark06(-1.4879685484320029,-0.6497504237965934,-1.5707963267948983 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark06(-1.488891473369425,-0.5797109939240748,83.19803624009336 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark06(-1.4900956911927343,-28.04835885829176,-88.51994323174344 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark06(-1.490814092567995,-1.5707963267948966,-7.664143827899487 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark06(-1.4908860817838177,-1.570796326794896,-1.3624044858386102 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark06(1.491488372438553,-69.59919236840038,0.0 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark06(-1.4920661464654614,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark06(-1.4923230030922063,-1.570796326795802,-113.26555860816644 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark06(-1.4924624277023306,-1.0427606211981266,898.1700810205001 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark06(-1.4926642372065204,-1.154928616713473,0.0 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark06(-1.4937385860127026,-1.5707963267948983,-35.6493566170755 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark06(-1.494835279382576,-0.724201721333299,0.0 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark06(-1.4951045026674308,5.551115123125783E-17,27.43193341306882 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark06(-1.495137699561297,-3.141592653589945,-73.51277989780766 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark06(-1.4954143320201418,-0.9810520982234027,20.905411209169294 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark06(-1.4959005697251504,-19.349560408611755,-45.38427812510802 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark06(-1.4972179457392951,-0.12325099100557363,71.72592358306343 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark06(-1.4972850301762017,-0.5910540939211817,-0.6932498095290823 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark06(-1.4973718788011334,-32.792138905350626,-736.1075623027589 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark06(-1.4975742914415604,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark06(-14.97575452235111,-72.12877241322937,-26.615223784641117 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark06(-1.4980085839299213,-1.5707963267948966,3.266614987733511 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark06(-1.4994550789442807,2.465190328815662E-32,92.70327596336497 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark06(-1.4996843011771739,-1.570796326530647,43.02469739711977 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark06(-1.499936136560118,-1.5707963267948966,78.10969006878568 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark06(-1.4999814984353028,-1.5707963267948966,98.8616678677626 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark06(-1.5010300611655878,-1.494185509042262,68.82392731135167 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark06(-1.5022827096632867,-1.5707963267948966,1.0952107306136312 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark06(-1.5023150151585944,-1.5707963267948966,67.66098972939231 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark06(-1.50238720179674,-95.69110742801713,-89.76327603702312 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark06(-1.502389525995431,-1.5707963267948912,66.04347174376767 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark06(-1.5029573520164379,-37.93402510236807,-1.5707963267950937 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark06(-1.5039857837274404,-0.10077577010193439,4.712391784749781 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark06(-1.5044899300967287,-0.39169867825084637,1.5707963267948966 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark06(-1.5065614255351303,-88.14375479101481,-71.69235255521542 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark06(-1.507586671017083,-0.4383629971595355,3.141592653589793 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark06(-1.508178414352803,-1.4166874672717606,2.465190328815662E-32 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark06(-1.5089354885621964,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark06(-1.5102968685821594,-44.29423168852636,-1.5707963267948966 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark06(-1.51139727468949,3.3881317890172014E-21,0.0 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark06(-1.5114741711322466,-0.023875514145711887,-1.5707963267948966 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark06(-1.5115576946808584,-1.5707963267948966,-1.4426529090290212E-129 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark06(-1.5118121997052383,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark06(-1.5119448327885632,-1.5707963267948966,6.939487146034661 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark06(-1.5122207172144577,-45.50866218538778,-26.407561847628813 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark06(-1.5130654843275189,-1.5707963267948966,-42.691305282174774 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark06(-1.5137789534329888,-37.71398573623211,-8.903949431371046 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark06(-1.5140702439783986,-94.33101894445329,-71.19391664261654 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark06(-1.5145306719836116,-1.5370658646396276,3.1415926535897953 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark06(-1.5146123812181784,-45.03013686367825,-21.27274906229716 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark06(-1.5153256455828437,-1.2860889814894023,64.11823720936536 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark06(-1.5161333968674707E-19,-1.5707963267948966,4.323233653984259 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark06(-1.5163197244484707,-38.910094013032946,-1.1103753009620694 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark06(-1.5163569223671347,-1.0317992816539867,1.633297570723791 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark06(-1.5174010963665525,-1.5707963267948966,1.2589855567043446 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark06(-1.5176973235231812,-37.90537999823613,-0.021855246290513934 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark06(-1.5183101191192063,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark06(-1.5184233347382612,-2.220446049250313E-16,9.64442909237011 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark06(-1.5186845101623565,-1.57079632679468,-99.64254577981868 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark06(15.190172604605578,-63.4545882079574,-55.21715103302589 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark06(-1.5193113659199584,-0.27641820586802623,-91.88713357516994 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark06(-1.5196881690340502,-37.941825100182555,-1.142311341600065 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark06(-1.520292953541532,-1.0107936529880487E-174,16.25522978286922 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark06(-1.5216363139525577,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark06(-1.5217048019100354,-0.4002319303880198,-87.19646931758172 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark06(-1.5218479285538626,-1.5707963267948966,-80.63530140595348 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark06(-1.5223583742124176,-0.0064172676359536135,44.321257123243186 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark06(-1.5225179505580417,-1.4860248891732077,93.14502998883404 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark06(-1.5226552273285474,-1.5707963267948966,-32.99062951421736 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark06(-1.5227211082832195,-1.5707963267948966,-77.09540009548388 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark06(-1.5239169535753354,-1.5707963267948966,34.48554488518164 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark06(-1.5243504254003888,-0.9116823247585041,-17.152915742091082 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark06(-1.5245126750581297,-31.740627079358944,-119.91667352158062 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark06(-1.5250165870123782,-1.5707963267948966,3.1416026918101214 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark06(-1.5251456550401934,-19.3495559215658,-0.888080634757183 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark06(-1.5257210095075877,-1.5707963267948966,-84.16736005403205 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark06(-1.5263601905436068,-2.7755575615628914E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark06(-1.5270711128790093,-100.56969825080095,-1.5707963267948983 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark06(-1.5272046260149121,-1.5707963267948961,-4.009492951854995 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark06(-1.5277549836659277,-31.415926535898105,-8.52932542438296 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark06(-1.5286541805857412,-1.5707963267948966,-0.3490235095736529 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark06(-1.5289565133404746,-0.850309881152322,56.15023326873063 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark06(-1.5291402356010761,-1.5707963267948966,18.14537194143159 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark06(-1.5295312694940284,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark06(-1.5297270916697243,-31.646913044872278,-1.5707963267948966 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark06(-1.5305541315893993,-284.31368967969144,-7.6284533395355005 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark06(-1.5312416474218475,-1.5707963267948966,1.5707963259482154 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark06(-1.5313204929132949,-1.5707963267948966,4.712388995785811 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark06(-1.5324761027246634,-0.3958795942891562,-7.828196014678063 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark06(-1.5326111892122813,-1.5707963267948966,-73.88343561138853 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark06(-1.5327431160930058,-0.21017252128441086,100.0 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark06(-1.532867032788004,-45.1851168721225,-0.3983409613956746 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark06(-1.5332168850636432,-1.5707963267948966,-97.83313866710944 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark06(-1.5337591491042077,-1.283290484290414,-2.0911698043593745 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark06(-1.5344742016162414,-1.5707963267948966,87.3546613295055 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark06(-1.5345378357679653,-1.5707963267932108,-93.94589260498518 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark06(-1.5364770934829675,-1.5707963267948983,37.383507355953185 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark06(-1.5374224445158522,-1.57079631380664,57.904410339268225 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark06(-1.5376038788085133,-19.362545216566456,-90.2966267971572 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark06(-1.5380102419014041,-1.5707963267948966,1.5707963267901668 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark06(-1.538711615615951,-1.7763568394002505E-15,0.6813116847863984 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark06(-1.5389630232173936,2.1684043449710089E-19,-1.5707963267948934 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark06(-1.5390016357438576,-3.1415926535897936,-20.236748726284006 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark06(-1.5391789633594695,-1.5707963267948966,-18.93483346390702 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark06(-1.5394862500902864,-0.6251480807227495,-1.570796636492535 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark06(-1.5395030777593037,-39.03162662927738,-19.375292625611323 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark06(-1.5396389614955837,-0.7270723920298762,115.26207225976137 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark06(-1.5398744860385944,-88.09016998895376,-2.526929068835114 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark06(-1.5403451577974192,-44.37150935078054,-26.123680284370224 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark06(-1.5404512731127618,-1.1337404250782894,1.0539778166251892 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark06(-1.5414874519237225,-1.5707963267948966,-570.9135647076241 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark06(-1.5417459951673904,-0.3121224129673452,-1.5707963267948966 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark06(-1.5421941856111172,-0.12399873532835981,24.847983114308192 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark06(-1.5424224599349246,-1.1102230246251565E-16,-18.999318070632867 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark06(-1.5424549105365601,-0.35430731037709134,-1.5788571988317903 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark06(-1.5428559842878133,-3.552713678800501E-15,44.24497748681865 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark06(-1.5431434269365254,-94.33907863821838,-31.45295681927516 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark06(-1.5432520596629289,-0.8253044923705395,-1.4251867461218366 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark06(-1.5432606945557625,-1.5707963234768272,77.05971662813255 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark06(-1.5438420072014367,-1.570796326794896,11.18835299726919 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark06(-1.5450566822193226,-100.53210403863987,-1.570879287418649 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark06(-1.5461039527719052,-1.5707963267948966,-88.20850018602573 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark06(-1.5461067355510278,-44.08467752017188,-21.463581586926036 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark06(-1.5465071456409984,-1.2479968444822307,6.712388980556648 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark06(-1.5466145820419697,-1.469257376081373,8.150291395088104 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark06(-1.5470600266489751,-8.103981633979071,-1.5707963267949197 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark06(-1.5474540011332967,-0.06094950998768803,-124.54307514457894 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark06(-1.5483906643482168,-1.1102230246251565E-16,4.440892098500626E-16 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark06(-1.5485997934752342,-1.5707963267948966,1.3250830935170228 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark06(-1.5490736066448836,1.6940658945086007E-21,-66.27222439234693 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark06(-1.5495858388602928,-1.5707963267948966,54.70096469094682 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark06(-1.5501512288506754,-95.76938857757197,6.462348535570529E-27 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark06(-1.5501893672376603,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark06(-1.5506781581873799,-1.5707963267948966,-55.35890219309012 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark06(-1.5509433476412369,-45.165496876145106,-58.87709632937901 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark06(-1.551361783263276,-1.5707963267948966,-4.712478014591128 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark06(-1.5514538287815722,-88.29504001705708,-33.23047786068666 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark06(-1.5519513124941453,-0.9136173085122923,1.5707963267948966 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark06(-1.5522319149993158,-1.5707963267948966,1.5247769763262315 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark06(-1.5522461981873061,-1.5707963267948966,-99.76347649201365 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark06(-1.5523539009534844,-1.4994626541575973,-1.5707963267948966 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark06(-1.5530885574057764,-0.41790762446132135,-86.71252449223581 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark06(-1.5531411323129503,-2.710505431213761E-20,15.680884025235017 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark06(-1.5538459221457168,-1.5707963267948966,-66.07918461662575 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark06(-1.5539906099742855,-1.463023860841312E-98,-4.528094515427949 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark06(-1.5541773993791947,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark06(-1.5547494266859203,-1.1006568214637918E-134,100.0 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark06(-1.5550939581254986,-1.5707963267948966,-0.17980696719299338 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark06(-1.5551815709694576,-38.9622484816416,-1.5707963267948966 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark06(-1.555416360660937,-1.5707963267948966,-10.132773032417404 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark06(-1.5554909604975562,-44.271398615802404,-0.17534823159334606 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark06(-1.5555634605081732,-1.5707963267948966,8.475175671211939E-7 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark06(-1.5556716523477006,-1.5707963267948966,31.581750220082654 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark06(-1.5560113018879158,-1.5707963267948912,4.619306655826193 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark06(-1.5560925086947932,-1.5707963267948966,1.5707963267949019 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark06(-1.5562345715104187,-0.6126307884334499,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark06(-1.557071667564953,-0.02048166843749044,-1.5707963267948963 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark06(-1.5571644013782509,-1.5707963267948966,44.4956224796291 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark06(-1.5575703277382473,-7.105427357601002E-15,-88.83903147153714 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark06(-1.5580803571603616,-1.5707963267948963,-100.0 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark06(-1.5581073202723783,-84.36995279989247,-1.5707963267948912 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark06(-1.5582754796293283,-0.02348915136467477,-9.628066780633347 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark06(-1.5583079281695222,-1.5707963267948966,-695.3719551611287 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark06(-1.5583489531125956,-88.08959430051779,-0.7466855532958523 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark06(-1.5584019067865744,-0.8592478441014252,-1.5719595982367267 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark06(-1.5584981673854588,-1.5707963267948966,-1.5707963267948961 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark06(-1.5585714363738064,-19.365304117983307,-20.04879255984248 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark06(-1.5601023381058146,-1.3860574464431679,-1.5707963267948966 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark06(-1.560202837685256,4.3368086899420177E-19,-74.39136387377472 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark06(-1.560367909569833,-1.1102230246251565E-16,1.5707963267669647 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark06(-1.5604061083528773,-1.475026005915084,24.930069535201007 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark06(-1.5606269064036478,0.013275039128918819,0 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark06(-1.5611477548557025,-1.5707963267948966,-14.807110281220076 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark06(-1.5623156783650323,-1.5707963267948966,66.48171777845049 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark06(-1.5626496793560076,-44.40656692782548,-1.82877982605164E-99 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark06(-1.5626667808325436,-32.92371320485824,-1.0452594398490753 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark06(-1.5629677877823203,-1.5707963267948963,17.672916061740082 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark06(-1.563333533228192,-1.2219745453998419E-150,99.99999906887334 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark06(-1.5637390472780723,-1.5707963267948966,-31.62232610692259 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark06(-1.5644761044527293,-1.5707938305970897,55.79383332818163 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark06(-1.5650258328086832,-1.5081347034073604,-1.5707963243391774 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark06(-1.5650319559171155,-1.1401240322486756,37.55945760153425 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark06(-1.5650917137965534,-39.006024280581016,-32.64393578732604 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark06(-1.5652223251349926,-1.5707963267948912,16.823644692679032 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark06(-1.5653075215575554,-0.5668920287786757,-31.50040576906305 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark06(-1.5654370342445796,-2.2770797632238904E-6,-103.65675331861915 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark06(-1.565555731918294,-1.5707963267948966,1.4903392633554737 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark06(-1.5657809985011488,2.465190328815662E-32,4.590218379959438 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark06(-1.5658945679013996,-1.5707963267948966,-14.081702594607771 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark06(-1.5660375319916764,4.930380657631324E-32,24.738514574516 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark06(-1.5660471834847605,-1.430082796284512,77.06098553323491 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark06(-1.566467816953366,-1.5707963267948966,-31.71046677311817 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark06(-1.5665015411819903,-1.5707963267948966,0.06586054700916671 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark06(-1.5665021000172608,-0.7744892839828205,-20.39527664371704 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark06(-1.567359809660872,-1.5707963267948966,-0.012417646264754341 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark06(-1.567465206681244,-95.64358232283786,-2.5707963267916902 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark06(-1.5674925857547006,-101.98898398368648,-39.19073074299245 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark06(-1.567527508911593,6.938893903907228E-18,58.40871850004645 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark06(-1.5679283924289746,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark06(-1.5681525902656839,-1.5707963267948966,43.413472196352544 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark06(-1.5682320956585432,-1.5707963267948966,-31.415956329032827 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark06(-1.568305179971113,-1.5707963267948966,-4.712633121020344 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark06(-1.5683538039741143,-0.37523731301569774,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark06(-1.568412932967341,-1.5707963267951233,108.4424148681301 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark06(-1.568649978785557,-0.23652049083273835,3.141597443047257 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark06(-1.5686524418557044,-1.5707963267948966,5.694639673427188 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark06(-1.5686570486427334,-100.53119441387712,-7.661542459455427 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark06(-1.5688411001949234,-1.5707963267948966,4.661797706400208 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark06(-1.5688490976079321,-1.5707963267948966,-74.41431988961455 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark06(-1.568913618387303,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark06(-1.5689303432292672,-1.5707963267948966,-56.316217567372945 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark06(-1.569351745342649,-31.631370649429698,-0.5944617804026469 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark06(-1.5693549972478775,-1.5707963267948966,-20.57213626560438 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark06(-1.569363800855663,-1.5707963267948966,-4.712389244003943 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark06(-1.5694333656885489,-0.4314384461390597,-193.17021052225903 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark06(-1.5694396956674241,-0.7651648762585476,0.0 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark06(-1.5695611897495596,-0.43693757408531475,18.02077036278439 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark06(-1.5697182812878512,2.7755575615628914E-17,61.03677254626055 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark06(-1.5697718590225904,-1.570793423250741,-119.36815270111939 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark06(-1.5699238298652833,-1.5707963267948966,1.507199842520779 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark06(-1.569943427718957,-1.2194714766571653,93.17798216209015 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark06(-1.5700641331832728,-0.010936871006464927,16.56725321869917 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark06(-1.5700869246627962E-16,-1.5707963267948966,3.1415926535897922 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark06(-1.5700976605902242,-32.59738097392463,-3.1415926535897967 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark06(-1.5701562220674214,-37.74625844847717,-39.13498122470448 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark06(-1.5701938893041698,-1.2743935288275423,-3.1415926535897967 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark06(-1.5703630971333125,-38.94870493906268,-1.5707963267950582 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark06(-1.5703895730078807,-38.774364019821235,-0.916569030942008 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark06(-1.57042876970337,-1.5707963267948966,67.80135743409724 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark06(-1.570431051760652,-0.17770964055214408,14.429205568865797 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark06(-1.5704329599421674,-1.5691945128330682,144.54313996635074 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark06(-1.5704388048764297,-1.5707754732034223,-75.41302684930523 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark06(-1.5705290621372672,-8.673617379884035E-19,-1.570256279803586 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark06(-1.5705603258034289,-1.5707963267948966,-17.528076797738862 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark06(-1.5705709926592506,-32.577032961171184,-1.5707963267948966 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark06(-1.5705744092787908,-1.5707963267948966,0.9357998277334064 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark06(-1.5705987273154285,-1.5707963267948966,53.06758753501762 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark06(-1.5706207010709474,-1.1113793747425387E-162,32.24988542105067 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark06(-1.570621996237659,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark06(-1.5706612586466389,-1.5707963267948957,18.849556449148956 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark06(-1.5706810435466845,-8.92496807153364E-6,99.46655972204418 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark06(-1.5706827581658458,-2.7649097809500354E-4,110.07840006803593 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707044399265864,-8.684378345329716E-6,-53.399791308646314 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707137455299467,-31.415926535902557,-0.11310212266909803 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark06(-1.570718940398748,-43.982297155345144,-51.95095068000303 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707225711880952,-1.5707963267948966,6.938893903907228E-18 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark06(-1.570722952866959,-1.734723475976807E-18,-77.96822508987724 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707420049724605,-1.5707963267948966,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707433434826286,-1.5707963267948966,-99.96019121340828 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707477570512902,-1.5707963267948966,100.53091629006077 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707542108691888,-0.030534649552366268,-59.395482310397696 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707618761803637,-45.522554095320416,-26.074911945328928 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark06(-1.570765165581771,-1.5707963267948966,3.2665926535901915 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707655766505406,-1.527915079086296,43.196206228094006 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark06(-1.570767193840796,-39.2699033668077,-44.47672394688901 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark06(-1.570773606780796,-1.5707963267948966,55.60576212054827 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707741407951443,-2.4496775193254164E-4,-2.539064801254588 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707767140580113,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707780840645231,-1.5707963267948963,-12.70013301388036 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707828068217715,-1.5707963267948966,100.48114260316211 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707897324979536,-1.2901373017750667E-6,-53.6579164179824 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707902246095962,-2.6507598675444663E-6,-15.753070325478923 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707918767868698,-2.1684043449710089E-19,-3.141592653589793 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707920506399307,-1.5707963267948912,129.9969768227562 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707921552565938,-1.3552527156068805E-20,-3.1330575622097414 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707922427756587,-1.5707956130827934,-43.95744489443618 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707925271234133,-95.8182218197652,-6.294918699390777 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707930471356666,-1.5707963267948966,-62.89513038827612 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707937449103726,-3.964083046040506E-10,-3.1383635262938583 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707951495334767,-31.416004178926624,-59.68808579913014 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707952507730345,-1.5707963267948966,37.69848092383512 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707953143593905,-39.269618758505906,-37.69946226355299 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707953927715312,-2.220446049250313E-16,-40.839382644392586 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707953988776822,-1.5707963267948966,-43.98118490928403 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707954959086512,-44.04595384402227,-197.91989601391035 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707958415944574,-1.5707963267948966,-87.9646192514597 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707958669720918,-88.09087066555531,-1.570787697759541 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707960877412244,-1.5707963267948966,37.699052782435764 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707961606567449,-1.5707963267948963,73.32710123119219 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796186479753,-1.5707963267948966,-1.5707963267948972 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962311511023,-1.0587911840678754E-22,95.62815063122741 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962412246885,-1.5707963267948966,106.82041090543191 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962608356607,-1.0377131598165952,0.0 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962636347212,-32.986721479557865,-56.58194429108578 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796267465153,-1.364474509210963,1.5707963267948966 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962741124437,-1.570647642840783,-25.138167236722488 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962875638084,-5.421010862427522E-20,-3.141820953257801 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962902945323,-1.5707963267948966,117.88190699685137 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962984028028,-1.5707963267948961,-1.5707963267948966 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962989397384,-1.5707963267948966,-46.14831167848712 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963016845632,-4.300180830042315E-8,-1.5707963267948966 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963037784662,-0.03621152871970354,-95.70924095539512 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963043969697,-9.445328308310685E-5,98.97352000896596 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963122719029,-0.15063268584722503,-53.99070407937491 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963123383455,-1.5707963267948966,-66.29409201477301 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963136099254,-0.837430028373994,1.5707963267948963 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963139749235,-4.760776017395883E-10,-78.53981633974483 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963144687762,-0.40832860719851843,-62.00523008922106 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963152418434,-0.023032320846893897,55.08873027090152 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963162998093,-1.5707963267948966,75.36132088137987 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963187540086,-1.5707963267948966,-59.7894922290089 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963188450336,-1.234525908817976,-67.33222507995684 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963188463365,-37.88726547102846,-6.162975822039155E-33 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963214081382,-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963215310652,-8.542089489402974E-18,-2.5707940885538205 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963221127663,-1.5707963267948966,1.8079117873054884 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963228356978,-1.5707963267948966,-33.11138745470139 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796323657653,-1.5707963267918288,0.0 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963243026122,-1.5604145600578783,-1.5695419595843907 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963244910368,-0.9742785439037662,1.5707963267948983 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963244923246,-0.35543940737334545,-0.16195977334103284 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963244930863,-0.052662238248680375,-24.67447229456236 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796324627045,-1.5707963267948983,1.5707963267948966 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963249357986,-1.570796326794893,8.762452970445867 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963249577215,-1.5707962199821106,87.91231548704172 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963250373502,-1.570796321877619,0.0 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796325227339,-0.7632597490326802,-1.5707963267948966 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963254195987,-1.5707963267948966,61.95372166515521 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963254518384,-0.9485377806214602,50.25463768811258 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963254712523,-1.5707963267948983,-100.0 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963254732713,-0.5212669739283622,-72.06888326586893 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796325566872,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963256582664,-0.9119257216038064,1.5707963267948966 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963257369153,-1.5707963267948966,44.581320949087115 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963258168092,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963258819306,-88.51132435038772,-26.721984549949536 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963260418631,-1.5707963267948966,4.511779891232624 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963260524695,-32.86588579238796,-46.280789426982665 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963261675204,-0.6226125548408472,-65.70494785538632 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963262727602,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963262776896,-0.02778802833873787,-0.10989216624771268 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963262858153,-1.5707963267948966,35.80749531342519 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963262909568,-1.5707963267948966,99.99366061156292 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263012308,-1.5707963267948912,-69.62610656865468 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263078386,-1.2569128740066735,74.19263985242284 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263382763,-1.5707963267948966,-38.312816470978085 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263398668,-1.5707963267948961,92.1405818309519 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263609024,-44.37031586280048,-31.640023731170317 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263647324,-95.65021613611736,-0.817468210837352 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263771587,-1.5707963267949019,-31.767418641807694 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263817506,-1.376087673939772,96.43017197423777 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264278646,-1.5707963267948983,-16.493428671931582 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264461198,-3.552713678800501E-15,-30.49816987051436 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264461484,-1.5707963267948966,-44.33917382119799 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264477238,-0.3503483746174231,58.92250250699186 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326453585,-1.5159047328013795,53.76311100622151 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264577698,-32.83898556927878,-1.5707963267949019 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264678138,-101.61328837726883,-44.94343178005189 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264729317,-31.80856374094768,-47.04398954940512 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264804135,-1.5707963267948966,18.86566141370426 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264968638,-31.69922519889195,-52.284829905895265 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265067362,-1.0901743532219506,83.16769446371941 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265097589,-1.063235761415759,88.22774978437059 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265102787,-1.5707963267948966,-5.680744388570297 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326510516,-1.1368532821523427,-6.485709689530296 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265417664,-1.5485983072262182,-56.28686368698207 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265610292,-94.37231473205826,-69.23978279923226 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326565806,-1.5707963267948983,-100.0 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265725005,-1.5707963267948966,1.958471488078878 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265728098,-1.5707963267948966,-59.864479842007036 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265813734,-1.5707963267948966,-53.85113267618811 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326582714,-1.5707963267948966,67.46721846228603 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266221663,-0.9272496393755243,-33.73865574953412 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326633962,-1.5707963267948966,1.5707963267948948 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266402543,-0.28905874603225484,48.40234129768933 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266664733,-0.376337801857781,40.0157737883815 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326669264,-1.5707963267948966,20.3108955205819 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326672092,-31.699003852503267,-1.5707963267948946 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266967528,-0.011708203024326689,0.041518644056947954 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266997074,-1.467523623335023,-1.5707963267948948 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267063325,-1.5707963267948912,6.3344694031248 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267184368,-1.2324330724427348,-11.019303120540258 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267253227,-1.5707963267948966,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267253442,-1.5707963267948966,-7.594762902884138 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326728647,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267418266,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267450806,-1.5707963267948983,-93.62437527213014 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326755151,-1.5707963267948966,-43.96686772495933 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267674316,-1.5707963267948963,-27.155779176809858 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267675993,-0.07658845715377677,0.0 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267704468,-3.560924280119036E-11,-1.5707963267948966 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267759126,-1.5707963267948966,1.6497140404391928 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267767222,-9.24716068321974E-11,122.52211348933685 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267795009,-0.03912261901672913,-157.32743715138034 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267876202,-1.5707963267948966,75.39741387994951 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326787693,-1.5707963267948966,0.19550456554560358 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326788442,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267886136,-1.5707963267948966,6.90990979506604E-14 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267896758,-0.22423205869255014,100.0 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267897813,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267900067,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267910552,-1.2377829781452602E-10,-98.650147921642 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267915441,-0.007509827124621755,62.6742970932717 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267921463,-45.50577427158724,-52.176528424787236 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326792177,-1.5707963267948966,-32.86230944123154 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267926175,-1.5707963267948966,17.29201172722538 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267929286,-8.271900784792613E-25,-28.274333874360046 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326793248,-1.3892242184281734E-163,12.190461998853337 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267932656,-1.5707963267948966,-90.31083442688704 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267932854,-1.5707963267948966,1.2938158758247024E-172 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267935305,-1.5707963267948966,-37.88834122637928 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267938463,-1.5707963267948966,8.708780480303076 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267941858,-1.5707963267948966,-26.6563698657057 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267942378,-38.88256311350335,-21.633464265296915 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267942766,-88.36842526285652,-44.501108539963894 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267943046,-1.5707963267948912,31.617154837647433 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267943585,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267945289,-45.099066799303614,-94.67672603435618 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794546,-1.5707963267948966,3.188231446960459 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794575,-1.5707963267948966,19.107493463055533 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267945977,-1.5636845658469432,1.5707963267948866 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267946552,-1.5707963267948966,0.5784645845544898 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794658,-1.5707963267948966,-56.54866776457858 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267946765,-1.5707963267947858,-56.54866776229554 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947314,1.5707963267948966,5.679575261822791 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947327,-1.5656664909214568,82.17707063407994 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947618,-1.5707963267948966,-94.24693525117682 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947669,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947698,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794781,-1.5707963267948966,0.029187192205338504 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947813,-1.5707963267948966,-95.40654505481703 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794801,-95.46702830665066,-1.5707963267948966 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948066,-1.5707963267948966,-43.52966693361219 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794813,-0.03137407590000929,-4.529933307617412 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794821,-1.4065158599373668,31.436845864672563 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948224,-1.5707963267948966,-19.59902478649687 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948288,-1.5691253807348302,-100.0 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948304,-1.5526059470160674,1.5707963267948963 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948322,-1.5707963267948966,-36.91512134363413 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948344,-31.85944825201645,-1.5707963267948966 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794838,-157.5429521328296,-58.992125772151425 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948408,-1.3869740227293028,66.95948762429802 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948448,-1.5707963267948966,-96.33542484547431 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794845,-1.5707963267948966,-64.93256349159114 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794845,-3.1415926536444254,1.5707963267948981 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948528,-1.3191544329560214,-1.5707963267948966 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948541,-1.5707963267948966,21.991148575128552 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794856,-1.5707963267948863,-5.752090427556917E-22 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948575,-1.5707963267948966,84.0294338052141 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948606,-1.5707963267948966,-0.09578275414128203 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948626,-1.5707963267948966,-99.9601685880787 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948644,-1.5707963267948966,915.7044210322903 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948715,-1.4837335621070697,-13.029192954223035 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948735,-1.5707963267948966,1.5707963267948957 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948735,-1.5707963267948966,3.141592653586402 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark06(-1.57079632679487,-38.9275318752484,-45.24636268534299 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948764,-1.5707963267948983,75.56734505476277 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794877,-1.5707963267948912,-65.76578750412044 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794877,-1.5707963267948966,-89.34589413754182 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794877,-31.661879763337097,-15.619334436476635 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794877,-39.180090867843674,-82.54174075441773 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794877,-7.105427357601002E-15,-1.5707963267948983 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948788,-7.105427357601002E-15,-1.5707963267948966 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948808,-1.4727089013174055,38.08391659593372 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948828,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948841,-1.3004423079203775,88.19238575868445 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948841,-44.23112277488619,-1.3285071857929402 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948841,-8.881784197001252E-16,70.93067643413723 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948852,-1.5707963267948966,91.82016395910098 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794886,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948872,-0.03655798080085458,-0.3908719555502632 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948877,-1.5707963267948912,123.12590082489919 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948877,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948877,-1.9166359265490721E-10,46.33918310553733 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948877,-88.48784743573214,-71.46508179076703 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794888,-45.26926001326555,-1.5707963267948966 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794889,-0.9436069172504958,89.31633474547975 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948892,-1.5707963267948966,-15.707963267948966 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948895,-0.0928329573833594,99.56841610115944 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948895,-1.5707963267948966,97.01539039508921 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948897,-1.5707963267948966,56.125801501686574 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948903,-1.5707963267948966,32.614183242678685 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948903,-1.5707963267948966,61.630850377225386 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948906,-1.5707963267948966,-88.46301030673233 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948908,-1.5707963267948966,51.014951322394744 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948908,-1.5707963267948966,54.95911234562897 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794891,-1.2064264577121961,-35.14324601304237 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794891,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.005930998351491468,18.280504398806286 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.03438686382554399,68.51884225532551 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.040044350840881225,1.6332963388767432 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.09150982954876419,-100.0 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.13960454385134446,-3.024062874254966 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.19092260819358253,6.205065866597076 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.21232429886997295,-73.4917850164462 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.24378534491622394,1.5707963267948983 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.2854619708546988,0.0 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.2991607681128762,112.36357316984086 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.3728093269224573,38.91517708813859 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.37902431027952294,9.425294005363913 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.38392370020785904,-33.84022327236292 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.4363747304276867,58.26323510726411 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.45954558603435913,-31.406973190777784 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.519174641361541,-7.943125862436826 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.5314075865317445,27.904311628714684 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.5490939912731929,-4.714342105386872 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.5932895264138107,-53.94363546316108 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.6000938409765273,44.82947551571024 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.6033560345559827,-9.434943020814856 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.6238303947650299,66.25281819463298 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.6859118004749405,99.30227902533449 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.7006420882908566,-3.141592653589793 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.732874352297773,-3.1415926535897967 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.7764474718745347,49.57196577559239 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.8386775789629457,-68.83997025414783 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.8630350820299506,-59.31598159157432 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.9288474440191901,-43.33108678993045 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-100.66209622756584,-1.493946434366525 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.0107161586211246,-78.35428991790315 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.077908182923851,0.0 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.0877227925105055,9.982483263415025 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.1206424136467545,-32.42956749853721 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.1348346166407333,95.39892614024774 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.159422078619017,3.141592688165445 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.30639276395339,31.474932485358153 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.383646336481721,58.748786218721364 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.416937256278933,-38.86466303088467 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5095586009881337,4.743638980386674 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.563368983431531,55.743873224517785 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.570796322659548,99.96016826433095 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948806,-59.63068765987498 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948821,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948877,3.2018305759539736 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948895,1.5707963267948966 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948912,-106.23431302397337 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948912,64.22604135614677 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948912,72.11575629116867 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948912,73.5440204457847 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948921,-1.44819328829972 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948948,16.739470344580766 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948948,9.100386342615053 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948957,-7.687591887630219 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948961,-1.160053492217827 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948963,-100.0 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,122.06705700977048 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,131.95229321399404 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,15.000689835697193 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-19.533171539768105 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-24.021648693461064 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-27.114020544502324 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-30.10683188379295 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,31.47912618261418 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-31.986722862692826 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-32.309116125705344 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,34.239702088216895 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-37.794147986392275 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-48.97642677539291 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-52.04127435082776 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-52.621438259111 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-54.163126851670924 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,65.93372920822355 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,70.04268625387175 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-70.0570996951246 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-70.57568930122123 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,72.56117438110249 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-7.342349100287635 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,74.65631574511667 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-75.84570569329296 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,83.25220532012952 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-92.31809968812847 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-9.486893221245921 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,9.521681415884 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,99.18905690051173 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948968,-33.09673680310395 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948983,-100.0 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948983,-19.469797017514992 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948983,39.71802385890054 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948983,81.43993867854358 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-164.70839685357612,-40.19669857858679 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.7762518322651872E-5,147.60143658178148 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-19.361512344170517,-2.07079632679498 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-19.823686344722674,0 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,2.465190328815662E-32,-59.42427628651299 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-2.5626663618343692E-144,-68.38289707956655 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-28.00551330229517,-32.25448705931703 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-31.41592653590679,-88.48146700055594 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-31.76214031527824,-1.5707963267948966 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-31.79746942037707,-50.71517597737927 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-31.91171814504827,-31.49404711553586 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-32.43537333657476,-75.6440508307424 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-32.50737736203254,-1.570796326794898 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-32.771460908211694,-1.311144568660528 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-32.8254747347049,-46.03087145429659 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-3.4247021078256297E-195,-26.892392818847696 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-38.734985234730324,-1.5707963267948977 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-38.81690292207202,-8.103985407544418 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-38.92076437818219,-57.88445868260095 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-44.089197725397,-1.5707963267948966 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-44.34235860245062,-69.4799486820022 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-45.10212997674001,-82.25817098595327 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-45.10671978419032,-58.44567459806077 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-45.43065438087079,-0.09319117912784236 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-45.54551445928946,-39.3034807663482 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,6.938893903907228E-18,25.3832651739146 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-8.561755269564074E-196,-100.0 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-88.08986255416774,-1.5707963267948966 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-88.1136713025268,-64.42687010758473 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-88.18430719704087,-214.6543154048548 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-88.28753293246565,-23.41849551509847 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-88.46260604356095,-1.5032070306272414 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-88.5148901534336,-38.99683297353821 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-88.53521968747962,-31.985574642607915 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-90.55264157641321,-63.52292300843847 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-95.78430280949222,-1.5707963267948963 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948915,-3.1415926535897936,17.952705731547134 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948915,-45.13013277632822,-1.5707963267948966 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark06(-1.57079632679489,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark06(-1.57079632679489,-1.5707963267948966,-95.49520364611983 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948915,-95.44818780256958,-1.5707963267948966 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794892,-0.20202136663634263,-1.5707963267948966 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794892,-1.5707963267948966,-69.6393337694331 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948923,-1.5707963267948966,-69.88525225179944 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948926,-100.6594251937223,-0.5814548062822575 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948926,-32.45455700164263,-5.548062114988335 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948928,-1.528660270953593,7.702837618585761 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-0.4949289196526172,-10.949617836922858 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-145.04977617115478,-1.5707963267948855 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-1.5707963267948912,92.86910792410188 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-1.5707963267948963,12.566370614359172 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-1.5707963267948966,-44.18982186799547 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-1.5707963267948966,56.1485278461282 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-1.5707963267948966,-81.12984889412614 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-1.7763568394002505E-15,0.0 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948934,-0.0654485055695238,73.7531631769711 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948937,-95.45807887002414,-89.50214905139381 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794894,-1.5707963267948983,-53.659635413204576 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948943,-1.5707963267948966,73.82621385351788 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948943,-32.875593594257396,-1.5707963267948966 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948946,-0.36629680879178383,0.570224004046216 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948946,-0.778226979101504,1.5707963267948966 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948946,-1.5707963267948966,-4.360498271594176E-39 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.0029478434171438814,34.461896101146976 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.014863669556525044,71.91386880427916 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.022865545517498392,44.412954190916224 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.11090784275598993,93.61575103947976 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.11888852742820899,-0.5460320307137758 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.15440989415920398,135.57343590767115 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.23078380369089985,43.99436701133799 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.24007361397867452,1.5707963267948966 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.24370088163741527,-1.5708613512960392 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.27368983819125825,1.5707963267948966 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.28213093817212953,73.33795363181305 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.295646715675121,19.798498168513184 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.3008483040307598,-98.26488138040665 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.3032932831543729,31.759307304217746 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.4656349800170494,-0.43645665595654803 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.47912451184832605,7.418412301374843E-68 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.7489487609535466,-93.29204085034996 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.7500859933994278,0 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.7777169053526227,-30.64416336797301 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.7796022300622072,67.7848846000008 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.9569754646636,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.006274945541005,-99.18535447983027 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-101.01223553480017,-32.426341015549326 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.040310974592717,-23.883556467707706 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.0445193052218857,5.044205311981447E-15 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.0959046745042015E-193,70.21875069254858 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.1075578343292845,-0.08156636753948732 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.1222867722423935,-85.6920765898439 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.2214725471046801,1.5707963267948957 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.2372419547630227,0.4298565509972576 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.3369103079591556,-0.44396664079812154 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.3440625641104507,-1.6537786123899403 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.400414607598293,28.46322573181331 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.4081358026638453,1.5707963267948966 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.463000925012126,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.4649719685374203,-12.885638896369073 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.4751612676522212,8.082828988692324 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5563539397018857,10.628115197491418 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.564075906099548,-1.5707963267948977 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963021101141,-6.281622995144834 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948173,100.45984223758198 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.570796326794873,-24.526719371101528 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948903,0.0 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948912,-71.64089922215422 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948948,27.729354828669848 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948957,-13.443700991109644 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948961,61.89512111232883 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948961,64.10433582803347 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,13.73374485318171 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,19.697948683249688 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,2.220446049250313E-16 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-28.15874949835703 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,38.60677352076531 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,43.65060544702783 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-45.536049536398146 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-4.714342105629061 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,5.1415927683759595 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-52.036662938738075 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-53.01648872740882 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,66.95826612444549 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,71.6717507146368 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-76.28412195742771 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-7.943811769490978 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-85.44191810291792 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,8.906348957117412E-16 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,96.86399599989339 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,99.88534261448909 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267949019,-70.2324644156476 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,1.5707963267949054,-17.477638208572472 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,1.6543612251060553E-24,59.23379809877125 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-3.1415926535897936,8.179424320519903 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-3.1415926535897944,76.59711624327313 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-3.1415926535915113,0.0 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-3.1415926535976535,-74.17927393074554 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-31.51823471815318,-1.5707963267948966 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-39.01529324731149,-7.644542342659815 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-39.05540740036324,-81.9563781895922 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-3.944304526105059E-31,4.732408241343262 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-45.347716252348036,-58.73051422534466 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-7.105427357601002E-15,19.784770585134723 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-8.380897833101525,-32.14593611950892 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-88.08959430051422,-13.648889552715406 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-88.24581296124364,-411.16654253054594 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-88.27710639013462,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-94.27653257679489,-12.697281826581536 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-95.48889740312524,-77.92601668718514 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794895,-1.5707963267948963,113.01990647411935 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794895,-1.5707963267948966,-45.31201201969753 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794895,-1.5707963267948966,-69.32916225560464 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948952,-0.06357418835435294,1.2842538204371974E-16 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948952,-0.13843434305836233,3.141592653589793 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948952,-1.4851462951051078,-85.43935635774962 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948952,-1.570796326794877,-40.6747101005408 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948952,-1.5707963267948966,4.146359196888736 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948952,-1.5707963267948966,9.35152427548719 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948952,-45.059214646307595,-1.5707963267948966 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794895,-32.55771854611358,-1.5707963267948966 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948954,-1.2989803801483664,-54.78448242309098 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948954,-1.5707963267948966,21.170834103744937 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948954,-1.5707963267948966,29.323857705427514 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948954,-1.5707963267948966,-49.3066550054096 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948954,-2.465190328815662E-32,-90.58259753244596 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,0,0 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.0030297047481110504,-51.77239073433407 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.026925032035387084,-59.19698206213068 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.3329663638713951,21.267139641842704 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.48188776103336894,95.14776494741884 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.7182902211214888,21.024577374874127 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.9397689417778775,36.03932173664998 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.0121717842442512,-65.99054329187392 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.0327817839772326,10.778771607489205 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.0470836753412938E-11,58.11575431171231 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.1897990379155696,-0.38023572384044757 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.232595164407831E-32,81.87004456340556 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.52310249377468,3.266592683872063 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.550479263744191,-71.17939655606456 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948961,0.4454007407084693 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,-0.6146467461098268 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,-11.659535452707646 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,1.2046313942588642 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,1.5707963267948961 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,33.724988018692756 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,3.85067558747339 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,-6.023793464193013 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,-76.68279063169972 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,-7.701669873483695 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,-89.66376487136064 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948983,99.81585050295791 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-36.70354766969319,0 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-43.98246705882037,-0.8405611468303072 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-43.98253343848171,-46.6227826337977 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-44.04699212958221,-78.11713876483839 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-55.86347499170339,0 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-5.861627923302895E-16,-39.24760907739742 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.022155206576494977,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.0460763052097252,39.411832220777455 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.07206835104317189,-13.570313712369213 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.08328757943474807,-1.5707963267948966 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.08857587736473559,52.21353087335291 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.09934675695263383,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.2503293097234076,61.48529086151508 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.32342883752787016,-1.5707963267948963 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.642059770588078,98.16653833300833 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-102.10175937676587,-1.0330099302442135 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.3328085970075911,-9.995574296091057 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.363723223113908,36.096104449730824 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.3870912452527573,1.5708086486534925 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.3877787807814457E-17,-14.864522470746273 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5100900376053128,14.674534309254582 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.570646694589366,-55.97783382404492 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.570649638469038,-56.548665548067746 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948077,-100.0 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948948,9.321331675166945 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948952,100.0 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948963,4.14159270589538 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-0.0971474103787295 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-12.566492684671674 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,24.684136182921563 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-44.14857335776588 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-4.714342105384691 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,5.285632955620031 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,55.33070965154531 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-63.89442615289549 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,66.98133308733199 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,6.712389876076516 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,67.46276523317134 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-78.74443101005728 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,94.40223779392525 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.7763568394002505E-15,-12.561132005855404 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-38.85833103442533,-1.5707963267948966 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-4.334940941141549E-15,40.40735970605988 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.5707963267948963,-24.383272363760298 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.5707963267948966,12.741192612484582 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.5707963267948966,-35.255952535385916 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.5707963267948966,88.12380575284257 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-94.2477796076938,0 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.012301899529726355,90.62267991104318 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.012941521242511484,1.5707963267948966 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.013150916361032227,0.0 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.01377908690293403,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.016613098024142275,-1.5707963267948966 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.04302244501336997,-4.714349796350184 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.10074353619682028,99.2695478748893 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.11872779032867856,17.169357214345347 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.13722163489423478,-0.022707902906080095 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.19444045965935403,-56.29984058613289 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.21682748216569447,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.30051848416086857,1.4242019440417921 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.3043770590302293,0.0 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.32454652270939877,3.2665926750711214 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.4399285995040554,3.141592653589794 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.5402257818178623,-1.5970233966389276 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.603084796441483,-10.500244978087379 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.6063000995274632,-19.718065875040168 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.6385470304311998,-96.68916928163004 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.7951443012552648,26.9415119908341 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.8045116204513438,1.5067118606871488 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.8720304478409655,31.820661055494156 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.939393914770754,72.41007376766302 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.9518408707589466,-1.5707963267948966 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.9559433920506433,3.1415924134116606 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.0477805234065385,38.605879392341045 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.0749467183239907,82.74307374712683 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,1.0842021724855044E-19,-86.89926155067018 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,1.1102230246251565E-16,8.978307763478107 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.1678504364785791,-3.2666290727244705 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.2043693850957282,-3.1415926535897936 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.2140510382383893,10.995574287215566 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.2587349279419455,42.87982282476531 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.2694359076930264,-40.073863224229015 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.3049190572396867,-63.78185862332728 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.3936713352541306,3.2665927425547276 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.441091199101233,52.23742156755862 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.4487002087407637,10.995574287560085 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.4614778677551434,-1.5707963267948966 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5338028352990285,6.013261273320651 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5473321023956657,51.32131632672121 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963246531762,-57.05283040152909 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963266929323,83.28557170455542 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267947698,-100.0 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948948,-1.2397867911122862 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948948,12.778073373969562 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948948,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948952,31.771409729857396 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948957,-36.94259553913519 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948963,-3.141592672282397 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-0.504643809077356 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,0.7494688649580471 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-18.453887526635942 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,2.0707963285944 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-207.32660686850363 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,29.061728227821778 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,30.569582453790733 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-37.699112310399066 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,37.922357467393276 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-43.99821737243985 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-44.06753795914256 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-44.55258803835445 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,4.743638989318411 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,54.017562503227495 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,56.67815880753537 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-6.2831852827624 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-65.21385106519386 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-65.73730344748846 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,9.06155605224293 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,95.4743713830041 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948986,-74.33512665210395 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,1.755566662876569E-12,0.0 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-2.0456175358874216E-16,-1.5707963263945128 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-2.1684043449710089E-19,-1.5707963267948963 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,2.7755575615628914E-17,-27.774627262592492 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-3.1415926535906835,-39.56100100584932 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-3.141592667996831,-15.518470678676207 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-38.83941285324864,-95.59473670603604 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-41.52659327047491,0 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-44.06982074541043,-77.33073284129668 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-4.500310028025629E-15,-157.18885032138 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-45.08059194592467,-15.444350444656255 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-45.37146783174736,2.118246918006325E-9 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-45.55309282638609,-56.548885172854895 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-7.105427357601002E-15,-83.5692017228238 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-88.44489578959372,-13.354601051079747 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-95.52188261184881,-54.97977498254689 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-95.71366791262167,-94.303482855217 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,9.860761315262648E-32,0.0 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark06(-1.5793650827938261E-176,-1.5707963267948966,1.1185331352136756 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark06(-1.596296508575608E-15,-0.7561651635624653,-87.76012814507476 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark06(-1.612640036354866,-44.411662865148394,-2.769313284160237 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark06(-1.6242827758820155E-114,-0.25487225093509647,32.57854144949933 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark06(-1.6325017050683056E-15,1.5707963267948966,-1.857500686295251 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark06(16.41589253837776,-94.42089149647185,12.18494377107615 ) ;
  }

  @Test
  public void test3299() {
    coral.tests.JPFBenchmark.benchmark06(-1.6463886478497822E-10,-1.0555270272721238,-63.320014134460955 ) ;
  }

  @Test
  public void test3300() {
    coral.tests.JPFBenchmark.benchmark06(-1.7209064478262093,98.85718303642949,-2.5118765704874875 ) ;
  }

  @Test
  public void test3301() {
    coral.tests.JPFBenchmark.benchmark06(-17.21303405814308,7.421010196445678,-24.9482723655847 ) ;
  }

  @Test
  public void test3302() {
    coral.tests.JPFBenchmark.benchmark06(-1.7318996436406525E-15,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test3303() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-0.03245214012182805,-88.45600119360041 ) ;
  }

  @Test
  public void test3304() {
    coral.tests.JPFBenchmark.benchmark06(-1.734723475976807E-18,-1.5707585186674113,-92.77885035981467 ) ;
  }

  @Test
  public void test3305() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-1.5707963267948934,-55.760121823603214 ) ;
  }

  @Test
  public void test3306() {
    coral.tests.JPFBenchmark.benchmark06(-1.734723475976807E-18,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3307() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-1.5707963267948966,1.570880921061887 ) ;
  }

  @Test
  public void test3308() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-1.5707963267948966,4.653006434686873 ) ;
  }

  @Test
  public void test3309() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-7.464460063042888E-15,75.70809633649677 ) ;
  }

  @Test
  public void test3310() {
    coral.tests.JPFBenchmark.benchmark06(-1.7435500621373304E-4,-1.5707963267948966,78.42379066912216 ) ;
  }

  @Test
  public void test3311() {
    coral.tests.JPFBenchmark.benchmark06(-1.7522780083209684E-5,-1.570796313233503,97.47026096777934 ) ;
  }

  @Test
  public void test3312() {
    coral.tests.JPFBenchmark.benchmark06(-1.752945394308723E-12,-1.0560861555310765,-16.992415080549495 ) ;
  }

  @Test
  public void test3313() {
    coral.tests.JPFBenchmark.benchmark06(-1.7534474792067224E-192,-1.5707963267948966,-66.22064563764634 ) ;
  }

  @Test
  public void test3314() {
    coral.tests.JPFBenchmark.benchmark06(1.7606005646257322E-4,1.5707963267948966,-67.72256051902951 ) ;
  }

  @Test
  public void test3315() {
    coral.tests.JPFBenchmark.benchmark06(17.614045764822308,76.62840219708485,-34.47616625434753 ) ;
  }

  @Test
  public void test3316() {
    coral.tests.JPFBenchmark.benchmark06(-1.766299530151563E-8,-1.5707963190306446,-14.131387815484166 ) ;
  }

  @Test
  public void test3317() {
    coral.tests.JPFBenchmark.benchmark06(-1.76899992396651E-15,-1.5707963267948966,-1.570796326794895 ) ;
  }

  @Test
  public void test3318() {
    coral.tests.JPFBenchmark.benchmark06(-1.774455060056171E-4,1.5707963267948966,0 ) ;
  }

  @Test
  public void test3319() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-0.11900876749937095,2244.6966220738063 ) ;
  }

  @Test
  public void test3320() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-0.36004253279680315,-24.229693093069145 ) ;
  }

  @Test
  public void test3321() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-0.7525677450329186,-9.817564864334296 ) ;
  }

  @Test
  public void test3322() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.1128752543270766,-1.5707963267948966 ) ;
  }

  @Test
  public void test3323() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948646,-66.97995765463524 ) ;
  }

  @Test
  public void test3324() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948948,66.26800965342255 ) ;
  }

  @Test
  public void test3325() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948957,1.5707963267950105 ) ;
  }

  @Test
  public void test3326() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948966,0.7111073140681361 ) ;
  }

  @Test
  public void test3327() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test3328() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948966,-2.0709851480772383 ) ;
  }

  @Test
  public void test3329() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948966,48.83530388517995 ) ;
  }

  @Test
  public void test3330() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948966,-89.66988174795691 ) ;
  }

  @Test
  public void test3331() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-39.18828990557783,-1.562365153583272 ) ;
  }

  @Test
  public void test3332() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-45.44054219138261,-1.5707963267948961 ) ;
  }

  @Test
  public void test3333() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394004303E-15,-1.5707963267948966,30.657800604983237 ) ;
  }

  @Test
  public void test3334() {
    coral.tests.JPFBenchmark.benchmark06(-1.778206999588062E-161,-0.060490014652081515,-0.5359678514815913 ) ;
  }

  @Test
  public void test3335() {
    coral.tests.JPFBenchmark.benchmark06(-1.778206999588062E-161,-1.5707963267948966,45.21542197729634 ) ;
  }

  @Test
  public void test3336() {
    coral.tests.JPFBenchmark.benchmark06(1.7818325325755084,-0.24619754114576384,100.0 ) ;
  }

  @Test
  public void test3337() {
    coral.tests.JPFBenchmark.benchmark06(-1.7851487177765764E-4,-1.5707963267948966,-34.53507106974983 ) ;
  }

  @Test
  public void test3338() {
    coral.tests.JPFBenchmark.benchmark06(-1.8033161362862765E-130,-0.029946874442459394,-23.376879039675064 ) ;
  }

  @Test
  public void test3339() {
    coral.tests.JPFBenchmark.benchmark06(-1.8033161362862765E-130,-1.5707963267948966,-19.41107825854442 ) ;
  }

  @Test
  public void test3340() {
    coral.tests.JPFBenchmark.benchmark06(-1.811765440884102,58.237984307069354,-28.879210223318324 ) ;
  }

  @Test
  public void test3341() {
    coral.tests.JPFBenchmark.benchmark06(-1.818586015209778E-11,-1.4650799035529956,-136.1145442528138 ) ;
  }

  @Test
  public void test3342() {
    coral.tests.JPFBenchmark.benchmark06(-1.8231775034027893E-4,-1.569191223252511,-117.97893500625962 ) ;
  }

  @Test
  public void test3343() {
    coral.tests.JPFBenchmark.benchmark06(18.344193372841545,-32.3804983231871,62.23747041513826 ) ;
  }

  @Test
  public void test3344() {
    coral.tests.JPFBenchmark.benchmark06(-18.643856088530185,-84.63601816238176,-72.8624114549739 ) ;
  }

  @Test
  public void test3345() {
    coral.tests.JPFBenchmark.benchmark06(-1.9010915662951598E-211,-1.5707963267948966,73.35223665296529 ) ;
  }

  @Test
  public void test3346() {
    coral.tests.JPFBenchmark.benchmark06(-1.909335227187253E-152,-1.5707963267948966,-44.353995811140614 ) ;
  }

  @Test
  public void test3347() {
    coral.tests.JPFBenchmark.benchmark06(19.140681560573313,-35.826245044854204,-83.60741375545852 ) ;
  }

  @Test
  public void test3348() {
    coral.tests.JPFBenchmark.benchmark06(-1.9245031118854756E-15,-95.6572394402063,-39.301374668017466 ) ;
  }

  @Test
  public void test3349() {
    coral.tests.JPFBenchmark.benchmark06(-19.25925331106113,48.48596144997401,43.67839479481469 ) ;
  }

  @Test
  public void test3350() {
    coral.tests.JPFBenchmark.benchmark06(-1.925929944382907E-34,-1.5707963267948966,72.25663103251944 ) ;
  }

  @Test
  public void test3351() {
    coral.tests.JPFBenchmark.benchmark06(-1.9259299444020383E-34,-1.5707963267948934,59.69026029287412 ) ;
  }

  @Test
  public void test3352() {
    coral.tests.JPFBenchmark.benchmark06(-1.929467651778826E-8,-1.5707963267948968,56.0287070518673 ) ;
  }

  @Test
  public void test3353() {
    coral.tests.JPFBenchmark.benchmark06(-1.95090042426176E-16,-1.5707963267948966,-40.84070449577556 ) ;
  }

  @Test
  public void test3354() {
    coral.tests.JPFBenchmark.benchmark06(19.630705811657847,-4.528110504896119,-97.99056542187567 ) ;
  }

  @Test
  public void test3355() {
    coral.tests.JPFBenchmark.benchmark06(19.652958618488128,-70.25176992890603,23.010657183974303 ) ;
  }

  @Test
  public void test3356() {
    coral.tests.JPFBenchmark.benchmark06(-1.969134776462337E-5,-1.5707960804262546,109.90360623986211 ) ;
  }

  @Test
  public void test3357() {
    coral.tests.JPFBenchmark.benchmark06(1.9721522630525295E-31,-0.6202627190768927,7.698554830385973 ) ;
  }

  @Test
  public void test3358() {
    coral.tests.JPFBenchmark.benchmark06(-1.9721522630525295E-31,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test3359() {
    coral.tests.JPFBenchmark.benchmark06(1.9721522630525295E-31,-1.5707963267948966,-39.01670453048867 ) ;
  }

  @Test
  public void test3360() {
    coral.tests.JPFBenchmark.benchmark06(1.9721522630525295E-31,-1.5707963267948966,64.10092987360464 ) ;
  }

  @Test
  public void test3361() {
    coral.tests.JPFBenchmark.benchmark06(1.9721522630525295E-31,-1.8034870630560592E-16,0.6240443800720356 ) ;
  }

  @Test
  public void test3362() {
    coral.tests.JPFBenchmark.benchmark06(-1.9742063534922827E-177,-1.5707963267948966,-1.2608346038479183 ) ;
  }

  @Test
  public void test3363() {
    coral.tests.JPFBenchmark.benchmark06(-1.9801628686276095E-21,-1.5707963267948966,34.557296305903286 ) ;
  }

  @Test
  public void test3364() {
    coral.tests.JPFBenchmark.benchmark06(-1.9850972647073642E-16,-1.5707963267948966,-31.613660574636683 ) ;
  }

  @Test
  public void test3365() {
    coral.tests.JPFBenchmark.benchmark06(-1.9934389902195135E-205,-1.5707963267948966,-9.24826080453377 ) ;
  }

  @Test
  public void test3366() {
    coral.tests.JPFBenchmark.benchmark06(-20.118461617542806,-8.510256990928838,47.38196984136556 ) ;
  }

  @Test
  public void test3367() {
    coral.tests.JPFBenchmark.benchmark06(2.0130391993411826E-11,-4.440892098500626E-16,163.47041743604606 ) ;
  }

  @Test
  public void test3368() {
    coral.tests.JPFBenchmark.benchmark06(-2.0303534698525194E-115,-0.17197688825371427,1.12596121585411 ) ;
  }

  @Test
  public void test3369() {
    coral.tests.JPFBenchmark.benchmark06(-2.0493044804873687E-5,-45.553074909741845,-7.850390215824325 ) ;
  }

  @Test
  public void test3370() {
    coral.tests.JPFBenchmark.benchmark06(-2.0501330894674953E-143,-1.5707963267948966,0.06886514447060782 ) ;
  }

  @Test
  public void test3371() {
    coral.tests.JPFBenchmark.benchmark06(21.02874231563905,59.451190224387574,46.70056953769378 ) ;
  }

  @Test
  public void test3372() {
    coral.tests.JPFBenchmark.benchmark06(2.1175823681357508E-22,-1.3367590779973224,66.28451058253896 ) ;
  }

  @Test
  public void test3373() {
    coral.tests.JPFBenchmark.benchmark06(-2.1175823681357508E-22,-1.5707963267948966,-2.5707962634030888 ) ;
  }

  @Test
  public void test3374() {
    coral.tests.JPFBenchmark.benchmark06(-2.129193236971728E-14,-4.004166190366202E-146,-0.6980501072237694 ) ;
  }

  @Test
  public void test3375() {
    coral.tests.JPFBenchmark.benchmark06(-21.337725840841884,36.17236806119121,-86.61079679735366 ) ;
  }

  @Test
  public void test3376() {
    coral.tests.JPFBenchmark.benchmark06(-2.1404388173910186E-196,-32.97291972716847,-1.5707963267948966 ) ;
  }

  @Test
  public void test3377() {
    coral.tests.JPFBenchmark.benchmark06(-2.152157232563852E-15,-1.5707963267948966,55.848203716865356 ) ;
  }

  @Test
  public void test3378() {
    coral.tests.JPFBenchmark.benchmark06(-2.1612908839133068E-224,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3379() {
    coral.tests.JPFBenchmark.benchmark06(2.1684043449710089E-19,-0.5572328146519061,-1.5707963267948966 ) ;
  }

  @Test
  public void test3380() {
    coral.tests.JPFBenchmark.benchmark06(-2.191809349008403E-193,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3381() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-0.009647732754399528,-99.65343146856759 ) ;
  }

  @Test
  public void test3382() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-0.02531348490669111,4.764853344038503 ) ;
  }

  @Test
  public void test3383() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-0.0764116041566627,-28.387236446734107 ) ;
  }

  @Test
  public void test3384() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-0.13857317728647267,-12.856302860470212 ) ;
  }

  @Test
  public void test3385() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-0.6575134870679098,0.40172363872943784 ) ;
  }

  @Test
  public void test3386() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-0.6674363498847453,-40.87540422950756 ) ;
  }

  @Test
  public void test3387() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-0.7981676136614756,-1.5707963267948966 ) ;
  }

  @Test
  public void test3388() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.3518567743370056,-1.5707963267948966 ) ;
  }

  @Test
  public void test3389() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.3625901093533006,-1.5707963267948983 ) ;
  }

  @Test
  public void test3390() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.4583020110868015,1.5707963267948966 ) ;
  }

  @Test
  public void test3391() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948963,1.5733146880238247 ) ;
  }

  @Test
  public void test3392() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3393() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948966,29.094636262281128 ) ;
  }

  @Test
  public void test3394() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948966,-31.221052951806712 ) ;
  }

  @Test
  public void test3395() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948966,43.21998884096959 ) ;
  }

  @Test
  public void test3396() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948966,-52.78397291729573 ) ;
  }

  @Test
  public void test3397() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948983,-91.32743193061177 ) ;
  }

  @Test
  public void test3398() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,1.734723475976807E-18,-1.6974073858319088 ) ;
  }

  @Test
  public void test3399() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-19.349555951044987,-37.853682590562585 ) ;
  }

  @Test
  public void test3400() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-32.54828638251456,-1.5707963267948966 ) ;
  }

  @Test
  public void test3401() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-3.552713678800501E-15,49.371155974923795 ) ;
  }

  @Test
  public void test3402() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-38.87805952075195,-2410.3907992058257 ) ;
  }

  @Test
  public void test3403() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-43.982297150257104,-95.66574411782162 ) ;
  }

  @Test
  public void test3404() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-95.40643221323866,-69.19738381097288 ) ;
  }

  @Test
  public void test3405() {
    coral.tests.JPFBenchmark.benchmark06(-2.2227587494850775E-162,-0.46081745606771246,-20.95569720256666 ) ;
  }

  @Test
  public void test3406() {
    coral.tests.JPFBenchmark.benchmark06(-2.2227587494850775E-162,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3407() {
    coral.tests.JPFBenchmark.benchmark06(22.293682687428927,-49.73821850344087,-2.3110468054700988 ) ;
  }

  @Test
  public void test3408() {
    coral.tests.JPFBenchmark.benchmark06(22.467193584938627,65.05695024526881,81.16504491890382 ) ;
  }

  @Test
  public void test3409() {
    coral.tests.JPFBenchmark.benchmark06(22.51121700248308,-21.481975625086818,66.87026422685113 ) ;
  }

  @Test
  public void test3410() {
    coral.tests.JPFBenchmark.benchmark06(-2.2541451703578456E-131,-1.1362958267906347,18.68062706554066 ) ;
  }

  @Test
  public void test3411() {
    coral.tests.JPFBenchmark.benchmark06(-2.2541451703578456E-131,-1.5707963267948966,1.5707963267949245 ) ;
  }

  @Test
  public void test3412() {
    coral.tests.JPFBenchmark.benchmark06(-2.2541451703578456E-131,-37.86637549604372,-19.795243155994008 ) ;
  }

  @Test
  public void test3413() {
    coral.tests.JPFBenchmark.benchmark06(2.2542557812354147,3.3159036517150753,-93.09547518644494 ) ;
  }

  @Test
  public void test3414() {
    coral.tests.JPFBenchmark.benchmark06(2.2611558176723457E-16,-1.5707963267948966,-80.60478313297025 ) ;
  }

  @Test
  public void test3415() {
    coral.tests.JPFBenchmark.benchmark06(-2.3012451061727555E-10,-45.40172715051686,-1.5707963267948966 ) ;
  }

  @Test
  public void test3416() {
    coral.tests.JPFBenchmark.benchmark06(-23.149148468153996,-89.01954789227864,-44.27990560217736 ) ;
  }

  @Test
  public void test3417() {
    coral.tests.JPFBenchmark.benchmark06(-2.3182538441796384E-69,-1.5707963267948966,-25.30754589940142 ) ;
  }

  @Test
  public void test3418() {
    coral.tests.JPFBenchmark.benchmark06(-2.319661605160253E-16,-0.6368335061208248,59.05661452420301 ) ;
  }

  @Test
  public void test3419() {
    coral.tests.JPFBenchmark.benchmark06(-2.3384612868885268E-17,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3420() {
    coral.tests.JPFBenchmark.benchmark06(-2.3408381773460992E-97,-0.10725144219036131,20.967520545320227 ) ;
  }

  @Test
  public void test3421() {
    coral.tests.JPFBenchmark.benchmark06(-2.3408381773460992E-97,-45.009971983321265,-20.543782781520367 ) ;
  }

  @Test
  public void test3422() {
    coral.tests.JPFBenchmark.benchmark06(-2.3465456147203816E-16,-1.5707963267948966,27.897630723461077 ) ;
  }

  @Test
  public void test3423() {
    coral.tests.JPFBenchmark.benchmark06(23.53613776791248,83.66521883518837,43.144771903330536 ) ;
  }

  @Test
  public void test3424() {
    coral.tests.JPFBenchmark.benchmark06(2.354940798338049,-66.86630038868695,85.50266281553817 ) ;
  }

  @Test
  public void test3425() {
    coral.tests.JPFBenchmark.benchmark06(-23.650471709488528,1.416138507548908,-90.84127107013869 ) ;
  }

  @Test
  public void test3426() {
    coral.tests.JPFBenchmark.benchmark06(-2.3805279598388665E-15,-1.5707963267948966,26.660416866077227 ) ;
  }

  @Test
  public void test3427() {
    coral.tests.JPFBenchmark.benchmark06(-2.3850750516017224E-5,-2.220446049250313E-16,37.66042132267703 ) ;
  }

  @Test
  public void test3428() {
    coral.tests.JPFBenchmark.benchmark06(-2.3908279233228122E-4,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3429() {
    coral.tests.JPFBenchmark.benchmark06(2.4318555209637878,1.5707963267948966,-11.793995039527212 ) ;
  }

  @Test
  public void test3430() {
    coral.tests.JPFBenchmark.benchmark06(2.432666803859014,87.27651083627899,0 ) ;
  }

  @Test
  public void test3431() {
    coral.tests.JPFBenchmark.benchmark06(24.361174776475522,-86.7082672486195,65.02692260836443 ) ;
  }

  @Test
  public void test3432() {
    coral.tests.JPFBenchmark.benchmark06(2.4394617055729593,-38.995109727706954,0.0 ) ;
  }

  @Test
  public void test3433() {
    coral.tests.JPFBenchmark.benchmark06(-2.465190328815662E-32,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test3434() {
    coral.tests.JPFBenchmark.benchmark06(-2.465190328815662E-32,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3435() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-1.5707963267948966,87.8776708107618 ) ;
  }

  @Test
  public void test3436() {
    coral.tests.JPFBenchmark.benchmark06(-2.4677579418653533E-178,-1.5707963267948748,0.0 ) ;
  }

  @Test
  public void test3437() {
    coral.tests.JPFBenchmark.benchmark06(-24.95667102965831,83.52899648910116,60.443545482017214 ) ;
  }

  @Test
  public void test3438() {
    coral.tests.JPFBenchmark.benchmark06(25.035525823964818,44.48883526871214,34.4368956872911 ) ;
  }

  @Test
  public void test3439() {
    coral.tests.JPFBenchmark.benchmark06(-25.136653816590425,8.202284340689545,-79.85635311117917 ) ;
  }

  @Test
  public void test3440() {
    coral.tests.JPFBenchmark.benchmark06(-25.162881100202995,0,0 ) ;
  }

  @Test
  public void test3441() {
    coral.tests.JPFBenchmark.benchmark06(-2.5243548967072378E-29,-1.5707963267948966,-2.5707757910033244 ) ;
  }

  @Test
  public void test3442() {
    coral.tests.JPFBenchmark.benchmark06(2.5243548967072378E-29,-38.91219953861683,-1.5707963267948966 ) ;
  }

  @Test
  public void test3443() {
    coral.tests.JPFBenchmark.benchmark06(-25.363532409085863,-2.139628424089153,-34.74377396805343 ) ;
  }

  @Test
  public void test3444() {
    coral.tests.JPFBenchmark.benchmark06(-2.5379418373156492E-116,-1.5707963267948912,18.030990187818077 ) ;
  }

  @Test
  public void test3445() {
    coral.tests.JPFBenchmark.benchmark06(-25.444398882712818,-30.649402611733834,-7.695722220995677 ) ;
  }

  @Test
  public void test3446() {
    coral.tests.JPFBenchmark.benchmark06(25.667355699159174,88.91751670226952,62.515966046818306 ) ;
  }

  @Test
  public void test3447() {
    coral.tests.JPFBenchmark.benchmark06(-2.570617437110065E-15,-0.3078991129700819,-28.778720960768663 ) ;
  }

  @Test
  public void test3448() {
    coral.tests.JPFBenchmark.benchmark06(-25.735433291335383,16.609936961934906,63.67191222393666 ) ;
  }

  @Test
  public void test3449() {
    coral.tests.JPFBenchmark.benchmark06(-2.5737787947340145E-85,-1.5707963267948966,42.43870152347242 ) ;
  }

  @Test
  public void test3450() {
    coral.tests.JPFBenchmark.benchmark06(25.760193664137574,-37.57358889943809,-91.06358286061393 ) ;
  }

  @Test
  public void test3451() {
    coral.tests.JPFBenchmark.benchmark06(-25.828225854665703,-6.26075585654209,39.21740547781448 ) ;
  }

  @Test
  public void test3452() {
    coral.tests.JPFBenchmark.benchmark06(-25.86832573076316,50.329949587847125,25.030048214246747 ) ;
  }

  @Test
  public void test3453() {
    coral.tests.JPFBenchmark.benchmark06(-2.5922338475205092E-15,-0.724060080588148,31.809798972872354 ) ;
  }

  @Test
  public void test3454() {
    coral.tests.JPFBenchmark.benchmark06(25.967546316638888,98.31714601659002,81.15348554789739 ) ;
  }

  @Test
  public void test3455() {
    coral.tests.JPFBenchmark.benchmark06(25.99302164916601,-81.95088518739935,-49.714790036622446 ) ;
  }

  @Test
  public void test3456() {
    coral.tests.JPFBenchmark.benchmark06(26.072402890522255,-94.82321628055041,-25.171062512642493 ) ;
  }

  @Test
  public void test3457() {
    coral.tests.JPFBenchmark.benchmark06(-2.6081087658961195,4.16013955649494,27.013858491086438 ) ;
  }

  @Test
  public void test3458() {
    coral.tests.JPFBenchmark.benchmark06(-2621.7320503517344,0,0 ) ;
  }

  @Test
  public void test3459() {
    coral.tests.JPFBenchmark.benchmark06(-26.220616594579667,-17.746983520812336,0 ) ;
  }

  @Test
  public void test3460() {
    coral.tests.JPFBenchmark.benchmark06(-2632.7291764790148,0,0 ) ;
  }

  @Test
  public void test3461() {
    coral.tests.JPFBenchmark.benchmark06(-2.6344138875063484E-161,-88.33822614842602,-1.5707963267948912 ) ;
  }

  @Test
  public void test3462() {
    coral.tests.JPFBenchmark.benchmark06(2.6469779601696886E-23,-0.9687456909547063,-1.5132646399924319 ) ;
  }

  @Test
  public void test3463() {
    coral.tests.JPFBenchmark.benchmark06(2.6469779601696886E-23,-31.836672274717543,-78.47022664217721 ) ;
  }

  @Test
  public void test3464() {
    coral.tests.JPFBenchmark.benchmark06(-2.682625252404188E-7,-95.8184448925263,-59.690128222516186 ) ;
  }

  @Test
  public void test3465() {
    coral.tests.JPFBenchmark.benchmark06(-26.873432771102784,-13.10566066512419,74.68430118236822 ) ;
  }

  @Test
  public void test3466() {
    coral.tests.JPFBenchmark.benchmark06(-26.922764662694902,-99.8519426032255,63.234354665185805 ) ;
  }

  @Test
  public void test3467() {
    coral.tests.JPFBenchmark.benchmark06(-2.7016136048916335E-225,-0.7345065841978584,-0.12912691086831027 ) ;
  }

  @Test
  public void test3468() {
    coral.tests.JPFBenchmark.benchmark06(2.710505431213761E-20,-1.4255110665263269,-9.821081837425025 ) ;
  }

  @Test
  public void test3469() {
    coral.tests.JPFBenchmark.benchmark06(2.710505431213761E-20,-1.5707963267948954,52.50151971606371 ) ;
  }

  @Test
  public void test3470() {
    coral.tests.JPFBenchmark.benchmark06(-27.250153768411906,38.23351195575796,-20.80147041752211 ) ;
  }

  @Test
  public void test3471() {
    coral.tests.JPFBenchmark.benchmark06(-2.7397616862605038E-194,-0.14913871218603442,-95.02201912067633 ) ;
  }

  @Test
  public void test3472() {
    coral.tests.JPFBenchmark.benchmark06(-2.7397616862605038E-194,-1.5707963267948948,86.24034069832089 ) ;
  }

  @Test
  public void test3473() {
    coral.tests.JPFBenchmark.benchmark06(27.444213966076106,-64.00499096251586,-60.54973352020825 ) ;
  }

  @Test
  public void test3474() {
    coral.tests.JPFBenchmark.benchmark06(2.7591941039144845,-18.90847959749625,0.0 ) ;
  }

  @Test
  public void test3475() {
    coral.tests.JPFBenchmark.benchmark06(-2.7620191899129924E-4,-44.06584784119117,-28.223626023928798 ) ;
  }

  @Test
  public void test3476() {
    coral.tests.JPFBenchmark.benchmark06(-27.659339456688656,17.33425220771619,-57.08836172213063 ) ;
  }

  @Test
  public void test3477() {
    coral.tests.JPFBenchmark.benchmark06(2.7755575615628914E-17,-1.4141280542500212,-53.69739137311511 ) ;
  }

  @Test
  public void test3478() {
    coral.tests.JPFBenchmark.benchmark06(2.7755575615628914E-17,-1.5678685334742541,-60.60792236486537 ) ;
  }

  @Test
  public void test3479() {
    coral.tests.JPFBenchmark.benchmark06(2.7755575615628914E-17,-1.5707963267948966,-11.494732396897234 ) ;
  }

  @Test
  public void test3480() {
    coral.tests.JPFBenchmark.benchmark06(-2.7755575615628914E-17,-3.469446951953614E-18,88.2006189827081 ) ;
  }

  @Test
  public void test3481() {
    coral.tests.JPFBenchmark.benchmark06(-2.778448436856347E-163,-0.9171758732520805,1.5707963267948948 ) ;
  }

  @Test
  public void test3482() {
    coral.tests.JPFBenchmark.benchmark06(-2.778448436856347E-163,-1.5707963267948966,67.10449148267969 ) ;
  }

  @Test
  public void test3483() {
    coral.tests.JPFBenchmark.benchmark06(-2.778448436856347E-163,-1.5707963267948966,-73.43425141673151 ) ;
  }

  @Test
  public void test3484() {
    coral.tests.JPFBenchmark.benchmark06(-2.7788206041281995,30.312178269574446,20.328113791212218 ) ;
  }

  @Test
  public void test3485() {
    coral.tests.JPFBenchmark.benchmark06(27.80182794011985,-26.913019556539723,4.72460927323894 ) ;
  }

  @Test
  public void test3486() {
    coral.tests.JPFBenchmark.benchmark06(28.187402020832508,32.95455136479853,-58.08705597924055 ) ;
  }

  @Test
  public void test3487() {
    coral.tests.JPFBenchmark.benchmark06(-28.22771584895945,59.237714766120746,31.533389432323617 ) ;
  }

  @Test
  public void test3488() {
    coral.tests.JPFBenchmark.benchmark06(-2.865974872546586E-16,0.523062419223772,0.0 ) ;
  }

  @Test
  public void test3489() {
    coral.tests.JPFBenchmark.benchmark06(28.663988062263343,-52.63255876677961,-36.20230598160965 ) ;
  }

  @Test
  public void test3490() {
    coral.tests.JPFBenchmark.benchmark06(-2.8721427024762966E-17,-1.198741028241863,67.39274907921987 ) ;
  }

  @Test
  public void test3491() {
    coral.tests.JPFBenchmark.benchmark06(-2.8853058180580424E-129,-0.4566374144993148,-91.42880916306069 ) ;
  }

  @Test
  public void test3492() {
    coral.tests.JPFBenchmark.benchmark06(-28.955379436896038,58.27767024955705,68.20925588734195 ) ;
  }

  @Test
  public void test3493() {
    coral.tests.JPFBenchmark.benchmark06(28.96882317701349,5.759243786952922,51.60195353550449 ) ;
  }

  @Test
  public void test3494() {
    coral.tests.JPFBenchmark.benchmark06(-2.913517551043359E-7,-163.5654518886372,-7.950297683508747 ) ;
  }

  @Test
  public void test3495() {
    coral.tests.JPFBenchmark.benchmark06(-2.926047721682624E-98,-1.5707963267948966,4.001153201849531 ) ;
  }

  @Test
  public void test3496() {
    coral.tests.JPFBenchmark.benchmark06(-2.9360215785729164E-31,-1.5707963267948966,69.32677575151712 ) ;
  }

  @Test
  public void test3497() {
    coral.tests.JPFBenchmark.benchmark06(-2.946522304381716E-11,-1.5707963267948966,-37.89579897627165 ) ;
  }

  @Test
  public void test3498() {
    coral.tests.JPFBenchmark.benchmark06(29.535508244770256,76.36435798748803,81.19022535917429 ) ;
  }

  @Test
  public void test3499() {
    coral.tests.JPFBenchmark.benchmark06(3.0099182915707E-17,-1.5707963267948966,13.334653399229538 ) ;
  }

  @Test
  public void test3500() {
    coral.tests.JPFBenchmark.benchmark06(30.36476273464686,-61.00401643240445,90.04529676335014 ) ;
  }

  @Test
  public void test3501() {
    coral.tests.JPFBenchmark.benchmark06(-30.373875753926598,59.66002155552735,3.2836660373821047 ) ;
  }

  @Test
  public void test3502() {
    coral.tests.JPFBenchmark.benchmark06(30.63025590813956,-1.9355748966779913,63.90354736879428 ) ;
  }

  @Test
  public void test3503() {
    coral.tests.JPFBenchmark.benchmark06(-30.710733818584487,-9.44930694833728,78.08571740019227 ) ;
  }

  @Test
  public void test3504() {
    coral.tests.JPFBenchmark.benchmark06(-30.787877607641562,-75.85558175232305,-78.24092334577193 ) ;
  }

  @Test
  public void test3505() {
    coral.tests.JPFBenchmark.benchmark06(-3.0846974273316917E-179,-1.5707963267948966,-83.58205582326492 ) ;
  }

  @Test
  public void test3506() {
    coral.tests.JPFBenchmark.benchmark06(-3.1122596670126E-10,-1.5707963266367366,61.268432217463946 ) ;
  }

  @Test
  public void test3507() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-0.9320024686121403,-11.23652644905741 ) ;
  }

  @Test
  public void test3508() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.055763174034415,-44.97072058095632 ) ;
  }

  @Test
  public void test3509() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948948,-44.13506995882513 ) ;
  }

  @Test
  public void test3510() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test3511() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,-1.5707963267949125 ) ;
  }

  @Test
  public void test3512() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,33.4624558926059 ) ;
  }

  @Test
  public void test3513() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,-38.91189045735199 ) ;
  }

  @Test
  public void test3514() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,5.2447835080598395 ) ;
  }

  @Test
  public void test3515() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,79.01947605319128 ) ;
  }

  @Test
  public void test3516() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,89.16108711619717 ) ;
  }

  @Test
  public void test3517() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,-94.84540134698891 ) ;
  }

  @Test
  public void test3518() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-158.50750290335836,-44.05689004838965 ) ;
  }

  @Test
  public void test3519() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-88.16889256138306,-0.3237127050293463 ) ;
  }

  @Test
  public void test3520() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589794,-0.7500248440453386,70.07592779909331 ) ;
  }

  @Test
  public void test3521() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589794,-1.5707963267948966,-72.50058442261337 ) ;
  }

  @Test
  public void test3522() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589795,-0.04005913240114012,-60.39488471118026 ) ;
  }

  @Test
  public void test3523() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589797,-1.5707963267948948,-0.2595512438908878 ) ;
  }

  @Test
  public void test3524() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589859,-0.6984049920990902,-5.942294234165377 ) ;
  }

  @Test
  public void test3525() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535898717,-95.36415142010662,-59.495165730827935 ) ;
  }

  @Test
  public void test3526() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589927,-0.6841363473010684,1.5596534338085135 ) ;
  }

  @Test
  public void test3527() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653590124,-1.569972919662374,4.466683837092006 ) ;
  }

  @Test
  public void test3528() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653590359,-1.1136304269291943,39.12840792856442 ) ;
  }

  @Test
  public void test3529() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653590494,-0.14590310790996053,40.90314376691097 ) ;
  }

  @Test
  public void test3530() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653591377,-4.2961035521671913E-4,1.5707963267948966 ) ;
  }

  @Test
  public void test3531() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535925007,-1.5707963267948963,-11.526369568565826 ) ;
  }

  @Test
  public void test3532() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653593156,-1.5707963267948966,-8.229602999165053 ) ;
  }

  @Test
  public void test3533() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535962977,-1.5707963267949019,25.061089624214517 ) ;
  }

  @Test
  public void test3534() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653603008,-1.5707963267948966,67.46585234095443 ) ;
  }

  @Test
  public void test3535() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653611612,-0.9537528628189474,1.5707963268014147 ) ;
  }

  @Test
  public void test3536() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653612325,-0.0016167453535014822,-1.5707963267948966 ) ;
  }

  @Test
  public void test3537() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926536362875,-1.5707963267948966,40.3753475080268 ) ;
  }

  @Test
  public void test3538() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926536402186,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3539() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653645489,-1.570796326784624,49.4373892649088 ) ;
  }

  @Test
  public void test3540() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653674201,-1.5707963267948966,-73.18606731675143 ) ;
  }

  @Test
  public void test3541() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926536813443,-94.2477796076938,-1.5707963267948966 ) ;
  }

  @Test
  public void test3542() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653723017,-0.8910140113755601,6.162975822039155E-33 ) ;
  }

  @Test
  public void test3543() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592654095809,-19.411761341595245,-69.2060438407406 ) ;
  }

  @Test
  public void test3544() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592654629125,-1.5707963267948966,-1.482027055372578 ) ;
  }

  @Test
  public void test3545() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926559705523,-1.5697849666309887,157.08895463147144 ) ;
  }

  @Test
  public void test3546() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926564591117,-1.383314256040602,-1.5707963267948983 ) ;
  }

  @Test
  public void test3547() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926581878226,-0.5105198029837245,-66.21419315635988 ) ;
  }

  @Test
  public void test3548() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926590499383,-94.2750281397452,-2.364654457621299 ) ;
  }

  @Test
  public void test3549() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926625779926,-0.3530003300049171,-78.51459688943415 ) ;
  }

  @Test
  public void test3550() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926642575065,-1.5139195003007224,84.77663772295254 ) ;
  }

  @Test
  public void test3551() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592691052442,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3552() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592795060581,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3553() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415928605565306,-0.11816414238057688,93.41532426442359 ) ;
  }

  @Test
  public void test3554() {
    coral.tests.JPFBenchmark.benchmark06(31.442012855137023,0.9480327641394126,-79.81877887683225 ) ;
  }

  @Test
  public void test3555() {
    coral.tests.JPFBenchmark.benchmark06(3.1554436208840472E-30,-1.1983815030357062E-31,95.34690081906271 ) ;
  }

  @Test
  public void test3556() {
    coral.tests.JPFBenchmark.benchmark06(-3.1554436208840472E-30,-1.5584148383977674,3.141592999769967 ) ;
  }

  @Test
  public void test3557() {
    coral.tests.JPFBenchmark.benchmark06(31.57948760409556,-93.1587612965789,-72.53411729595322 ) ;
  }

  @Test
  public void test3558() {
    coral.tests.JPFBenchmark.benchmark06(-3.1587301655876523E-176,-1.5652436769127467,78.32687763275425 ) ;
  }

  @Test
  public void test3559() {
    coral.tests.JPFBenchmark.benchmark06(3.167487230626522E-10,-32.86641992158039,-101.32635263787189 ) ;
  }

  @Test
  public void test3560() {
    coral.tests.JPFBenchmark.benchmark06(-3.167776930504086E-10,-101.0663559660215,-157.64738076576288 ) ;
  }

  @Test
  public void test3561() {
    coral.tests.JPFBenchmark.benchmark06(-3.214164042442342E-11,-1.5707956514896373,72.25758776583108 ) ;
  }

  @Test
  public void test3562() {
    coral.tests.JPFBenchmark.benchmark06(-3.2293136043977826E-15,-1.4631823694583341,8.307139804936313 ) ;
  }

  @Test
  public void test3563() {
    coral.tests.JPFBenchmark.benchmark06(-32.45360523748673,-47.87019050793309,52.55391157385799 ) ;
  }

  @Test
  public void test3564() {
    coral.tests.JPFBenchmark.benchmark06(-3.261351200557398E-14,-1.5707962867811502,-1.5707963267948966 ) ;
  }

  @Test
  public void test3565() {
    coral.tests.JPFBenchmark.benchmark06(-33.508277091005596,37.49556758371756,14.040391498481284 ) ;
  }

  @Test
  public void test3566() {
    coral.tests.JPFBenchmark.benchmark06(-33.51257328970745,-43.42935816588407,28.974811108094457 ) ;
  }

  @Test
  public void test3567() {
    coral.tests.JPFBenchmark.benchmark06(33.66146545165583,-72.45229961958262,-1.621317481616643 ) ;
  }

  @Test
  public void test3568() {
    coral.tests.JPFBenchmark.benchmark06(-3.3879748002702994E-11,-1.5707963267948966,10.996550867157632 ) ;
  }

  @Test
  public void test3569() {
    coral.tests.JPFBenchmark.benchmark06(3.3881317890172014E-21,-1.5707963267948957,-26.236580606993535 ) ;
  }

  @Test
  public void test3570() {
    coral.tests.JPFBenchmark.benchmark06(-33.899368612876216,-53.85014485795827,-18.384970600689115 ) ;
  }

  @Test
  public void test3571() {
    coral.tests.JPFBenchmark.benchmark06(-33.93690723152069,-1.6703521654860936,4.572591909720501 ) ;
  }

  @Test
  public void test3572() {
    coral.tests.JPFBenchmark.benchmark06(33.94250280122864,78.5186542079089,24.30976930006426 ) ;
  }

  @Test
  public void test3573() {
    coral.tests.JPFBenchmark.benchmark06(-3.414715475673157E-17,-1.011331181074681,3.1415926535897922 ) ;
  }

  @Test
  public void test3574() {
    coral.tests.JPFBenchmark.benchmark06(34.33867219083166,-57.049514815914534,12.090335247168227 ) ;
  }

  @Test
  public void test3575() {
    coral.tests.JPFBenchmark.benchmark06(-3.44246752619716E-7,-1.570796325929564,34.55668560597248 ) ;
  }

  @Test
  public void test3576() {
    coral.tests.JPFBenchmark.benchmark06(34.64837703240528,20.97006520607394,31.24755977663756 ) ;
  }

  @Test
  public void test3577() {
    coral.tests.JPFBenchmark.benchmark06(3.4694469519536134E-18,-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test3578() {
    coral.tests.JPFBenchmark.benchmark06(-3.469446951953614E-18,-1.2020691222303341,5.588789663319208 ) ;
  }

  @Test
  public void test3579() {
    coral.tests.JPFBenchmark.benchmark06(3.469446951953614E-18,-1.4829008151935748,34.14294638622039 ) ;
  }

  @Test
  public void test3580() {
    coral.tests.JPFBenchmark.benchmark06(3.469446951953614E-18,-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test3581() {
    coral.tests.JPFBenchmark.benchmark06(3.469446951953614E-18,-1.5707963267948966,23.214507392696202 ) ;
  }

  @Test
  public void test3582() {
    coral.tests.JPFBenchmark.benchmark06(3.469446951953614E-18,-1.5707963267948966,62.80557649055872 ) ;
  }

  @Test
  public void test3583() {
    coral.tests.JPFBenchmark.benchmark06(3.469446951953614E-18,-32.82931150986013,-3.0591285501515064 ) ;
  }

  @Test
  public void test3584() {
    coral.tests.JPFBenchmark.benchmark06(3.469446951953614E-18,-39.07321850864979,-13.75575301304651 ) ;
  }

  @Test
  public void test3585() {
    coral.tests.JPFBenchmark.benchmark06(3.469446951953614E-18,-45.403643120219684,-38.78807880359222 ) ;
  }

  @Test
  public void test3586() {
    coral.tests.JPFBenchmark.benchmark06(-3.469452857486153E-18,-1.5707963267948963,11.01119929439845 ) ;
  }

  @Test
  public void test3587() {
    coral.tests.JPFBenchmark.benchmark06(-3.4730605460704336E-164,-1.5707963267948966,-99.66073641041521 ) ;
  }

  @Test
  public void test3588() {
    coral.tests.JPFBenchmark.benchmark06(-35.189153668497426,-56.88571009384968,39.62242045712577 ) ;
  }

  @Test
  public void test3589() {
    coral.tests.JPFBenchmark.benchmark06(-3.5203932195889364E-6,-1.5707963267948912,84.82273230834225 ) ;
  }

  @Test
  public void test3590() {
    coral.tests.JPFBenchmark.benchmark06(35.44388764860605,-42.823210643814804,19.81528196308109 ) ;
  }

  @Test
  public void test3591() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-0.06945367803201251,95.48017939974869 ) ;
  }

  @Test
  public void test3592() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-0.5739569768329176,31.913669552001863 ) ;
  }

  @Test
  public void test3593() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-0.5857939084043474,76.22766498755816 ) ;
  }

  @Test
  public void test3594() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-1.5707963267948966,-67.76716195709515 ) ;
  }

  @Test
  public void test3595() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-1.5707963267948966,-67.78212749684111 ) ;
  }

  @Test
  public void test3596() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-1.5707963267948966,-71.11396621477368 ) ;
  }

  @Test
  public void test3597() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-1.5707963267948966,7.393779952379134 ) ;
  }

  @Test
  public void test3598() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-1.5707963267948966,-98.96026855814307 ) ;
  }

  @Test
  public void test3599() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-1.5707963267948983,-29.65966148249821 ) ;
  }

  @Test
  public void test3600() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-1.7763568394002505E-15,4.527243759057782 ) ;
  }

  @Test
  public void test3601() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-19.403420315343624,-0.29270461618941224 ) ;
  }

  @Test
  public void test3602() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-31.61190286311239,-0.10435813249837479 ) ;
  }

  @Test
  public void test3603() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-31.670867622404373,6.938893903907228E-18 ) ;
  }

  @Test
  public void test3604() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-32.65898235729085,-0.024919325482169685 ) ;
  }

  @Test
  public void test3605() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-3.552713678800501E-15,-25.132586556922405 ) ;
  }

  @Test
  public void test3606() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-37.73758104816539,-1.5707963267948912 ) ;
  }

  @Test
  public void test3607() {
    coral.tests.JPFBenchmark.benchmark06(-3.552713678800501E-15,-44.12239031739222,-1.5707963267948966 ) ;
  }

  @Test
  public void test3608() {
    coral.tests.JPFBenchmark.benchmark06(-3.554754250481057E-15,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3609() {
    coral.tests.JPFBenchmark.benchmark06(35.72647736489611,-90.18134127297228,-29.872034338077043 ) ;
  }

  @Test
  public void test3610() {
    coral.tests.JPFBenchmark.benchmark06(35.91310746859685,-31.149766770553214,-20.15672094991723 ) ;
  }

  @Test
  public void test3611() {
    coral.tests.JPFBenchmark.benchmark06(-36.15497525466183,-33.91034450066755,32.97283628043684 ) ;
  }

  @Test
  public void test3612() {
    coral.tests.JPFBenchmark.benchmark06(3.666324829636139,1.629160997108329,71.48921728110562 ) ;
  }

  @Test
  public void test3613() {
    coral.tests.JPFBenchmark.benchmark06(36.67499673344443,34.88751925221351,16.833399958740955 ) ;
  }

  @Test
  public void test3614() {
    coral.tests.JPFBenchmark.benchmark06(-36.93882917563438,-62.76252007419092,0 ) ;
  }

  @Test
  public void test3615() {
    coral.tests.JPFBenchmark.benchmark06(-37.53829901841414,-76.96555375230172,3.5307182700307465 ) ;
  }

  @Test
  public void test3616() {
    coral.tests.JPFBenchmark.benchmark06(-3.768208619190721E-15,-1.5707963267948912,3.141592653589793 ) ;
  }

  @Test
  public void test3617() {
    coral.tests.JPFBenchmark.benchmark06(37.704067803451125,-99.29700096588883,-15.929595881217068 ) ;
  }

  @Test
  public void test3618() {
    coral.tests.JPFBenchmark.benchmark06(-37.783078194432804,-53.04382859069825,82.66459976373491 ) ;
  }

  @Test
  public void test3619() {
    coral.tests.JPFBenchmark.benchmark06(38.110477287022235,7.262185138855855,52.51249964856109 ) ;
  }

  @Test
  public void test3620() {
    coral.tests.JPFBenchmark.benchmark06(-3.8342257075631365E-71,-0.973785938484645,-88.12338265950997 ) ;
  }

  @Test
  public void test3621() {
    coral.tests.JPFBenchmark.benchmark06(-3.8558717841646146E-180,-1.5707963267948966,21.427464540984978 ) ;
  }

  @Test
  public void test3622() {
    coral.tests.JPFBenchmark.benchmark06(-3.8664263352803236E-5,-0.2240158445611421,-17.138832272850983 ) ;
  }

  @Test
  public void test3623() {
    coral.tests.JPFBenchmark.benchmark06(-38.96354224208194,-0.5004858292345631,26.81843477541473 ) ;
  }

  @Test
  public void test3624() {
    coral.tests.JPFBenchmark.benchmark06(38.9773259840556,-27.68206241275186,21.65906270280837 ) ;
  }

  @Test
  public void test3625() {
    coral.tests.JPFBenchmark.benchmark06(-3.910318545279494E-149,-1.5707963267948966,3.141592653589793 ) ;
  }

  @Test
  public void test3626() {
    coral.tests.JPFBenchmark.benchmark06(-3.9261863569497706,60.04003690911645,-19.31745379406067 ) ;
  }

  @Test
  public void test3627() {
    coral.tests.JPFBenchmark.benchmark06(-3.9293465927079865,82.93912488285326,12.464185432744856 ) ;
  }

  @Test
  public void test3628() {
    coral.tests.JPFBenchmark.benchmark06(-3.944304526105059E-31,-1.5707963267948966,3.141592653589793 ) ;
  }

  @Test
  public void test3629() {
    coral.tests.JPFBenchmark.benchmark06(3.944304526105059E-31,-1.5707963267948966,-44.99359524389049 ) ;
  }

  @Test
  public void test3630() {
    coral.tests.JPFBenchmark.benchmark06(3.944304526105059E-31,-1.7763568394002505E-15,100.0 ) ;
  }

  @Test
  public void test3631() {
    coral.tests.JPFBenchmark.benchmark06(-3.9484127069845653E-177,-0.02050654388049558,-25.104432416688486 ) ;
  }

  @Test
  public void test3632() {
    coral.tests.JPFBenchmark.benchmark06(39.53505770863086,-84.01778317989346,97.92007769643868 ) ;
  }

  @Test
  public void test3633() {
    coral.tests.JPFBenchmark.benchmark06(-3.965534120805702E-118,-1.5707963267948966,99.99999999999999 ) ;
  }

  @Test
  public void test3634() {
    coral.tests.JPFBenchmark.benchmark06(3.9710398820320676,-1.5707963267948966,270.7238312824257 ) ;
  }

  @Test
  public void test3635() {
    coral.tests.JPFBenchmark.benchmark06(-39.87374015053054,79.62994662211557,-33.08467095154823 ) ;
  }

  @Test
  public void test3636() {
    coral.tests.JPFBenchmark.benchmark06(-3.9976960600009026E-14,-1.5707963267948966,-42.25340296811415 ) ;
  }

  @Test
  public void test3637() {
    coral.tests.JPFBenchmark.benchmark06(-40.08107392133453,-13.641342040467407,-75.02626543506332 ) ;
  }

  @Test
  public void test3638() {
    coral.tests.JPFBenchmark.benchmark06(40.12026551792488,-62.77446484689293,58.58345614490577 ) ;
  }

  @Test
  public void test3639() {
    coral.tests.JPFBenchmark.benchmark06(-4.0215293667718976E-87,-1.5707963267948966,55.33983570343125 ) ;
  }

  @Test
  public void test3640() {
    coral.tests.JPFBenchmark.benchmark06(-40.53476279564781,-63.3939837017069,41.70789484000065 ) ;
  }

  @Test
  public void test3641() {
    coral.tests.JPFBenchmark.benchmark06(-4.0538599175674466E-5,-0.6293862502338122,-2.324129654667655 ) ;
  }

  @Test
  public void test3642() {
    coral.tests.JPFBenchmark.benchmark06(-4.0607069397050388E-115,-0.38482024097697565,5.238268440240329 ) ;
  }

  @Test
  public void test3643() {
    coral.tests.JPFBenchmark.benchmark06(-4.107075389582554E-16,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test3644() {
    coral.tests.JPFBenchmark.benchmark06(-41.14998030248904,96.94974852492967,-75.95071807956752 ) ;
  }

  @Test
  public void test3645() {
    coral.tests.JPFBenchmark.benchmark06(4.1359030627651384E-25,-1.5707962746949238,66.4248019508692 ) ;
  }

  @Test
  public void test3646() {
    coral.tests.JPFBenchmark.benchmark06(41.58519216207131,-94.76172530766274,-52.66460974832008 ) ;
  }

  @Test
  public void test3647() {
    coral.tests.JPFBenchmark.benchmark06(-4.1737992701863075E-4,-1.5703847173614742,-65.97115922698052 ) ;
  }

  @Test
  public void test3648() {
    coral.tests.JPFBenchmark.benchmark06(42.01070475619889,-4.0433308194725015,-97.79504688620241 ) ;
  }

  @Test
  public void test3649() {
    coral.tests.JPFBenchmark.benchmark06(42.02194937679343,-3.032557787880009,-72.96336442824406 ) ;
  }

  @Test
  public void test3650() {
    coral.tests.JPFBenchmark.benchmark06(4.2351647362715017E-22,-0.18357295101831653,1.5707963267948966 ) ;
  }

  @Test
  public void test3651() {
    coral.tests.JPFBenchmark.benchmark06(4.2351647362715017E-22,-1.0833016339424812,-1.5707963267948966 ) ;
  }

  @Test
  public void test3652() {
    coral.tests.JPFBenchmark.benchmark06(4.2351647362715017E-22,-1.5707963267948948,-56.458883166171454 ) ;
  }

  @Test
  public void test3653() {
    coral.tests.JPFBenchmark.benchmark06(4.2351647362715017E-22,-1.5707963267948966,-1.6072847322005628 ) ;
  }

  @Test
  public void test3654() {
    coral.tests.JPFBenchmark.benchmark06(-42.44989236611527,87.99887974600523,84.79668402662895 ) ;
  }

  @Test
  public void test3655() {
    coral.tests.JPFBenchmark.benchmark06(43.07234289688995,-1.1420813854203118,-26.250388099804795 ) ;
  }

  @Test
  public void test3656() {
    coral.tests.JPFBenchmark.benchmark06(4.3368086899420177E-19,-0.09290662625655711,-3.044738775287101 ) ;
  }

  @Test
  public void test3657() {
    coral.tests.JPFBenchmark.benchmark06(-4.3368086899420177E-19,-1.057313185192963,1.5864213501335789 ) ;
  }

  @Test
  public void test3658() {
    coral.tests.JPFBenchmark.benchmark06(4.3368086899420177E-19,-1.5707963267948966,-13.599365372080433 ) ;
  }

  @Test
  public void test3659() {
    coral.tests.JPFBenchmark.benchmark06(4.3368086899420177E-19,-1.5707963267948966,-1.5707963267948961 ) ;
  }

  @Test
  public void test3660() {
    coral.tests.JPFBenchmark.benchmark06(4.3368086899420177E-19,-32.62573598957172,-0.16237498163537278 ) ;
  }

  @Test
  public void test3661() {
    coral.tests.JPFBenchmark.benchmark06(4.3368086899420177E-19,-45.52546905672247,-45.69687909284836 ) ;
  }

  @Test
  public void test3662() {
    coral.tests.JPFBenchmark.benchmark06(43.405124369456644,71.24040171460183,0 ) ;
  }

  @Test
  public void test3663() {
    coral.tests.JPFBenchmark.benchmark06(-43.64546624516732,-60.29531934194112,98.55271533507053 ) ;
  }

  @Test
  public void test3664() {
    coral.tests.JPFBenchmark.benchmark06(43.72710787007708,-29.82318744851267,71.18069541717651 ) ;
  }

  @Test
  public void test3665() {
    coral.tests.JPFBenchmark.benchmark06(4.3790577010150533E-47,-1.4618671061646005,14.433251784781142 ) ;
  }

  @Test
  public void test3666() {
    coral.tests.JPFBenchmark.benchmark06(-4.383618698016806E-193,-0.6660382452753495,-61.92372596936983 ) ;
  }

  @Test
  public void test3667() {
    coral.tests.JPFBenchmark.benchmark06(-4.427378146102388E-18,-1.5707963267948966,-65.30122645771417 ) ;
  }

  @Test
  public void test3668() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-0.3509298613988534,45.55117024988439 ) ;
  }

  @Test
  public void test3669() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-0.6547082842495815,-0.6707882050093947 ) ;
  }

  @Test
  public void test3670() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-0.9300720496932657,-90.33124022965103 ) ;
  }

  @Test
  public void test3671() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-0.9378902179358646,-96.98974003542197 ) ;
  }

  @Test
  public void test3672() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-1.3876058410529026,-43.819097176381845 ) ;
  }

  @Test
  public void test3673() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-1.5707963267948735,-0.06916797954644925 ) ;
  }

  @Test
  public void test3674() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-1.5707963267948948,-16.094141089833624 ) ;
  }

  @Test
  public void test3675() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-1.5707963267948966,2.1812322467572045 ) ;
  }

  @Test
  public void test3676() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-1.5707963267949019,-0.47531737921026773 ) ;
  }

  @Test
  public void test3677() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,8.673617379884035E-19,88.2408398677454 ) ;
  }

  @Test
  public void test3678() {
    coral.tests.JPFBenchmark.benchmark06(-4.440892098500626E-16,-8.881784197001252E-16,-6.328132846859056 ) ;
  }

  @Test
  public void test3679() {
    coral.tests.JPFBenchmark.benchmark06(-4.4647944971963866E-103,-1.0433900077884142,-27.17293086399887 ) ;
  }

  @Test
  public void test3680() {
    coral.tests.JPFBenchmark.benchmark06(-44.722825837448795,-4.680762582154969,-72.75825099339471 ) ;
  }

  @Test
  public void test3681() {
    coral.tests.JPFBenchmark.benchmark06(44.79751814555323,3.3625823847950045,5.264549075518715 ) ;
  }

  @Test
  public void test3682() {
    coral.tests.JPFBenchmark.benchmark06(-4.5082903407156913E-131,-0.15767623252218702,38.58432888083064 ) ;
  }

  @Test
  public void test3683() {
    coral.tests.JPFBenchmark.benchmark06(-4.5082903407156913E-131,-1.5707963267948966,-56.35194163751677 ) ;
  }

  @Test
  public void test3684() {
    coral.tests.JPFBenchmark.benchmark06(-45.55704816232391,-61.65061428707901,16.02232238222902 ) ;
  }

  @Test
  public void test3685() {
    coral.tests.JPFBenchmark.benchmark06(-4.570944228907862E-17,-95.42109408162618,-1.570796326794898 ) ;
  }

  @Test
  public void test3686() {
    coral.tests.JPFBenchmark.benchmark06(45.79832447094506,-65.92152264540726,32.17167511184866 ) ;
  }

  @Test
  public void test3687() {
    coral.tests.JPFBenchmark.benchmark06(-4.591970839044829E-16,-1.5707963267948966,-41.360896839654714 ) ;
  }

  @Test
  public void test3688() {
    coral.tests.JPFBenchmark.benchmark06(-45.94811307461519,66.3981387416236,-33.829286917700685 ) ;
  }

  @Test
  public void test3689() {
    coral.tests.JPFBenchmark.benchmark06(46.3411335035411,-53.81711199178725,21.74702989840756 ) ;
  }

  @Test
  public void test3690() {
    coral.tests.JPFBenchmark.benchmark06(-4.642217293083044E-15,-1.5707963267948966,72.4072453795407 ) ;
  }

  @Test
  public void test3691() {
    coral.tests.JPFBenchmark.benchmark06(46.54044206073016,68.48773156860145,-15.594479276489935 ) ;
  }

  @Test
  public void test3692() {
    coral.tests.JPFBenchmark.benchmark06(4.6602151762583475,0,0 ) ;
  }

  @Test
  public void test3693() {
    coral.tests.JPFBenchmark.benchmark06(-46.647543294559426,11.30789049151187,44.941572177446005 ) ;
  }

  @Test
  public void test3694() {
    coral.tests.JPFBenchmark.benchmark06(-46.921794896349375,29.134819226521472,-23.753662176787003 ) ;
  }

  @Test
  public void test3695() {
    coral.tests.JPFBenchmark.benchmark06(-47.09047194602329,28.21922706377785,81.72656991205113 ) ;
  }

  @Test
  public void test3696() {
    coral.tests.JPFBenchmark.benchmark06(-47.09106298653223,-59.33582509686861,-2.8154196507297797 ) ;
  }

  @Test
  public void test3697() {
    coral.tests.JPFBenchmark.benchmark06(-47.45933890411904,0,0 ) ;
  }

  @Test
  public void test3698() {
    coral.tests.JPFBenchmark.benchmark06(-47.88366752378317,31.85187657805659,-71.14168373974321 ) ;
  }

  @Test
  public void test3699() {
    coral.tests.JPFBenchmark.benchmark06(47.9387133725221,79.60280888527177,5.399434235981744 ) ;
  }

  @Test
  public void test3700() {
    coral.tests.JPFBenchmark.benchmark06(-4.8148248609680896E-35,-1.5707963267948966,59.690259037027054 ) ;
  }

  @Test
  public void test3701() {
    coral.tests.JPFBenchmark.benchmark06(-48.672424488936116,0,0 ) ;
  }

  @Test
  public void test3702() {
    coral.tests.JPFBenchmark.benchmark06(4.8840779185265514E-17,-1.5707963267948966,74.73967312043318 ) ;
  }

  @Test
  public void test3703() {
    coral.tests.JPFBenchmark.benchmark06(-49.113478930719914,-31.51993356706997,-74.0062503489794 ) ;
  }

  @Test
  public void test3704() {
    coral.tests.JPFBenchmark.benchmark06(49.21748048540337,-14.37937830252956,-91.05279937232584 ) ;
  }

  @Test
  public void test3705() {
    coral.tests.JPFBenchmark.benchmark06(-4.92900136384328E-14,-1.5707963267948966,65.18468091520693 ) ;
  }

  @Test
  public void test3706() {
    coral.tests.JPFBenchmark.benchmark06(4.930380657631324E-32,-1.0093969282977293,-55.70999270633932 ) ;
  }

  @Test
  public void test3707() {
    coral.tests.JPFBenchmark.benchmark06(49.507757834001524,-37.308235457640706,8.339057953909233 ) ;
  }

  @Test
  public void test3708() {
    coral.tests.JPFBenchmark.benchmark06(4.968771067033757,16.89600089690117,0 ) ;
  }

  @Test
  public void test3709() {
    coral.tests.JPFBenchmark.benchmark06(-5.0052077379577523E-147,-0.0018608084906901517,-73.52807556345854 ) ;
  }

  @Test
  public void test3710() {
    coral.tests.JPFBenchmark.benchmark06(-5.0052077379577523E-147,-0.41465936898850947,-28.1027673261852 ) ;
  }

  @Test
  public void test3711() {
    coral.tests.JPFBenchmark.benchmark06(-5.0052077379577523E-147,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3712() {
    coral.tests.JPFBenchmark.benchmark06(-5.0052077379577523E-147,-1.5707963267948966,21.76362805841615 ) ;
  }

  @Test
  public void test3713() {
    coral.tests.JPFBenchmark.benchmark06(-5.0052077379577523E-147,-95.63801449687398,-32.722824449003305 ) ;
  }

  @Test
  public void test3714() {
    coral.tests.JPFBenchmark.benchmark06(-50.237315181234955,99.79205326689586,-94.29369562588428 ) ;
  }

  @Test
  public void test3715() {
    coral.tests.JPFBenchmark.benchmark06(-5.026911708464872E-88,-0.9559135044372798,-100.0 ) ;
  }

  @Test
  public void test3716() {
    coral.tests.JPFBenchmark.benchmark06(-50.450814134918346,90.70978719683362,-88.46074354528383 ) ;
  }

  @Test
  public void test3717() {
    coral.tests.JPFBenchmark.benchmark06(-50.451671854380706,-15.527130498991326,34.28148242523366 ) ;
  }

  @Test
  public void test3718() {
    coral.tests.JPFBenchmark.benchmark06(50.923383677167294,26.860376073539797,-8.381582799211401 ) ;
  }

  @Test
  public void test3719() {
    coral.tests.JPFBenchmark.benchmark06(-5.098048376663267E-8,-3.422565310922083E-10,44.40313247149469 ) ;
  }

  @Test
  public void test3720() {
    coral.tests.JPFBenchmark.benchmark06(-5.123331258638714,98.17450014055476,29.9981841370265 ) ;
  }

  @Test
  public void test3721() {
    coral.tests.JPFBenchmark.benchmark06(51.6583930570751,26.153812802351666,43.882233424766525 ) ;
  }

  @Test
  public void test3722() {
    coral.tests.JPFBenchmark.benchmark06(51.720014836016645,82.00934715178013,-39.33967561791536 ) ;
  }

  @Test
  public void test3723() {
    coral.tests.JPFBenchmark.benchmark06(51.97637892426775,90.12750564596391,0 ) ;
  }

  @Test
  public void test3724() {
    coral.tests.JPFBenchmark.benchmark06(-52.04308506966369,39.68679583302935,79.10285164573486 ) ;
  }

  @Test
  public void test3725() {
    coral.tests.JPFBenchmark.benchmark06(52.47360645253255,-83.61233463701232,-68.33046065393268 ) ;
  }

  @Test
  public void test3726() {
    coral.tests.JPFBenchmark.benchmark06(-5.2483733461356557E-17,-0.4544593584831773,1.5707963267948966 ) ;
  }

  @Test
  public void test3727() {
    coral.tests.JPFBenchmark.benchmark06(-52.806561446715385,8.493425209004116,2.586465647231549 ) ;
  }

  @Test
  public void test3728() {
    coral.tests.JPFBenchmark.benchmark06(5.293955920339377E-23,-88.3004646721357,-88.45447588709057 ) ;
  }

  @Test
  public void test3729() {
    coral.tests.JPFBenchmark.benchmark06(-53.06568854618179,-55.790636274236945,2.446795953847186 ) ;
  }

  @Test
  public void test3730() {
    coral.tests.JPFBenchmark.benchmark06(53.355288133418156,68.11047933021885,-98.32321522170471 ) ;
  }

  @Test
  public void test3731() {
    coral.tests.JPFBenchmark.benchmark06(5.359849612296057E-22,-1.5707963267948966,-33.04557260640977 ) ;
  }

  @Test
  public void test3732() {
    coral.tests.JPFBenchmark.benchmark06(-53.7901033108753,2.3553720595661076,63.226674905993235 ) ;
  }

  @Test
  public void test3733() {
    coral.tests.JPFBenchmark.benchmark06(-5.391567194016458E-17,-0.022438934801653543,0.0 ) ;
  }

  @Test
  public void test3734() {
    coral.tests.JPFBenchmark.benchmark06(-54.18728545775473,15.69640193656707,-0.9195942328925781 ) ;
  }

  @Test
  public void test3735() {
    coral.tests.JPFBenchmark.benchmark06(5.421010862427522E-20,-1.129322812416922,29.414085391242878 ) ;
  }

  @Test
  public void test3736() {
    coral.tests.JPFBenchmark.benchmark06(5.421010862427522E-20,-1.5707963267948966,0.7704570204455813 ) ;
  }

  @Test
  public void test3737() {
    coral.tests.JPFBenchmark.benchmark06(5.421010862427522E-20,-1.5707963267948966,21.561022237484114 ) ;
  }

  @Test
  public void test3738() {
    coral.tests.JPFBenchmark.benchmark06(5.421010862427522E-20,-1.5707963267948966,-2.589628019559878 ) ;
  }

  @Test
  public void test3739() {
    coral.tests.JPFBenchmark.benchmark06(5.421010862427522E-20,-8.881784197001252E-16,18.479679879500402 ) ;
  }

  @Test
  public void test3740() {
    coral.tests.JPFBenchmark.benchmark06(5.4297109568853254E-17,-1.5707963267948966,40.90018840680378 ) ;
  }

  @Test
  public void test3741() {
    coral.tests.JPFBenchmark.benchmark06(-5.451019143950749E-4,-1.5707963267948946,-103.67255756878605 ) ;
  }

  @Test
  public void test3742() {
    coral.tests.JPFBenchmark.benchmark06(-5.493257991039613,-68.91596506090956,5.93741345438626 ) ;
  }

  @Test
  public void test3743() {
    coral.tests.JPFBenchmark.benchmark06(54.98247890534029,-68.37788625672118,-95.32413761582796 ) ;
  }

  @Test
  public void test3744() {
    coral.tests.JPFBenchmark.benchmark06(-5.503284107318959E-135,-0.49307179702902393,25.523235010230778 ) ;
  }

  @Test
  public void test3745() {
    coral.tests.JPFBenchmark.benchmark06(-55.41974344322196,-11.570770777264599,28.12904235638024 ) ;
  }

  @Test
  public void test3746() {
    coral.tests.JPFBenchmark.benchmark06(-55.45473885679861,53.18810415004867,0 ) ;
  }

  @Test
  public void test3747() {
    coral.tests.JPFBenchmark.benchmark06(-5.551115123125783E-17,-0.20036772847377365,-88.69812648132034 ) ;
  }

  @Test
  public void test3748() {
    coral.tests.JPFBenchmark.benchmark06(-5.551115123125783E-17,-0.28887717889946357,305.3044847809851 ) ;
  }

  @Test
  public void test3749() {
    coral.tests.JPFBenchmark.benchmark06(5.551115123125783E-17,-0.9430843453496087,-51.65430215446109 ) ;
  }

  @Test
  public void test3750() {
    coral.tests.JPFBenchmark.benchmark06(5.551115123125783E-17,-1.2057125133427071,-1.5707963267948983 ) ;
  }

  @Test
  public void test3751() {
    coral.tests.JPFBenchmark.benchmark06(-5.551115123125783E-17,-1.5707963267948963,34.96037578532059 ) ;
  }

  @Test
  public void test3752() {
    coral.tests.JPFBenchmark.benchmark06(5.551115123125783E-17,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3753() {
    coral.tests.JPFBenchmark.benchmark06(-5.551115123125783E-17,-32.415926535912256,-27.603148079738308 ) ;
  }

  @Test
  public void test3754() {
    coral.tests.JPFBenchmark.benchmark06(-5.556896873712694E-163,-1.5707963267948966,89.08090676830965 ) ;
  }

  @Test
  public void test3755() {
    coral.tests.JPFBenchmark.benchmark06(55.649122395302385,18.409102122445546,-22.95820746134207 ) ;
  }

  @Test
  public void test3756() {
    coral.tests.JPFBenchmark.benchmark06(-55.82938333478804,-78.29454706294678,-91.5791732979786 ) ;
  }

  @Test
  public void test3757() {
    coral.tests.JPFBenchmark.benchmark06(55.97222466359625,-1.528569943800349,-46.12442376000494 ) ;
  }

  @Test
  public void test3758() {
    coral.tests.JPFBenchmark.benchmark06(56.14021834428479,67.76649852158573,-18.986354621857487 ) ;
  }

  @Test
  public void test3759() {
    coral.tests.JPFBenchmark.benchmark06(-56.68714486025288,63.73895210556404,70.21080230812419 ) ;
  }

  @Test
  public void test3760() {
    coral.tests.JPFBenchmark.benchmark06(-5.6902623986817984E-160,-0.005000456410758636,0.0 ) ;
  }

  @Test
  public void test3761() {
    coral.tests.JPFBenchmark.benchmark06(-56.94136970644521,-63.89666145966988,-0.3097988685283042 ) ;
  }

  @Test
  public void test3762() {
    coral.tests.JPFBenchmark.benchmark06(5.712925657116585,-82.6048957679561,17.80586002865512 ) ;
  }

  @Test
  public void test3763() {
    coral.tests.JPFBenchmark.benchmark06(-57.189364363124675,-15.080690789477046,88.69837719170275 ) ;
  }

  @Test
  public void test3764() {
    coral.tests.JPFBenchmark.benchmark06(-57.24868336326436,-52.185065725570645,22.94063277388119 ) ;
  }

  @Test
  public void test3765() {
    coral.tests.JPFBenchmark.benchmark06(-57.59564642174557,-24.707225428772304,-77.65195043474245 ) ;
  }

  @Test
  public void test3766() {
    coral.tests.JPFBenchmark.benchmark06(-5.770611636116085E-129,-1.5707963267948966,-0.023929448488948957 ) ;
  }

  @Test
  public void test3767() {
    coral.tests.JPFBenchmark.benchmark06(57.76849145354399,-65.56024337242545,85.7391499388923 ) ;
  }

  @Test
  public void test3768() {
    coral.tests.JPFBenchmark.benchmark06(-5.799808240785213E-17,-1.5707963267948966,-29.69648598776142 ) ;
  }

  @Test
  public void test3769() {
    coral.tests.JPFBenchmark.benchmark06(-58.23327436972563,-76.35695716172772,59.939974085705416 ) ;
  }

  @Test
  public void test3770() {
    coral.tests.JPFBenchmark.benchmark06(-5.8268286962501615E-157,-1.5707963267948966,-24.607971351421078 ) ;
  }

  @Test
  public void test3771() {
    coral.tests.JPFBenchmark.benchmark06(-58.77828342767628,53.823622323513604,-69.81303369475125 ) ;
  }

  @Test
  public void test3772() {
    coral.tests.JPFBenchmark.benchmark06(58.78657316827213,47.86312094795096,76.0855641631886 ) ;
  }

  @Test
  public void test3773() {
    coral.tests.JPFBenchmark.benchmark06(59.28920574801168,-42.57542176727058,-31.725644213509582 ) ;
  }

  @Test
  public void test3774() {
    coral.tests.JPFBenchmark.benchmark06(-59.49926905720269,-35.38403624680504,-18.973643670360914 ) ;
  }

  @Test
  public void test3775() {
    coral.tests.JPFBenchmark.benchmark06(5.985322360690209E-17,-1.487768822020038,77.71056957317406 ) ;
  }

  @Test
  public void test3776() {
    coral.tests.JPFBenchmark.benchmark06(60.03584295088484,-28.624667403118423,0.46987807728208963 ) ;
  }

  @Test
  public void test3777() {
    coral.tests.JPFBenchmark.benchmark06(-6.044931147625676E-14,-1.5707963267948966,-25.1687739678598 ) ;
  }

  @Test
  public void test3778() {
    coral.tests.JPFBenchmark.benchmark06(60.68914365192393,-68.46139992647642,-97.82518046269173 ) ;
  }

  @Test
  public void test3779() {
    coral.tests.JPFBenchmark.benchmark06(-6.0834930121445114E-210,-1.5707963267948966,61.07058664514099 ) ;
  }

  @Test
  public void test3780() {
    coral.tests.JPFBenchmark.benchmark06(-61.45716392056308,-36.90029560919601,57.404335154545805 ) ;
  }

  @Test
  public void test3781() {
    coral.tests.JPFBenchmark.benchmark06(62.240515801442314,-87.7554300442412,88.85834327383355 ) ;
  }

  @Test
  public void test3782() {
    coral.tests.JPFBenchmark.benchmark06(-6.236843212700071E-112,-1.5707963267948966,-91.106186954104 ) ;
  }

  @Test
  public void test3783() {
    coral.tests.JPFBenchmark.benchmark06(62.61196193817884,46.381444803293334,4.827531016183556 ) ;
  }

  @Test
  public void test3784() {
    coral.tests.JPFBenchmark.benchmark06(-6.26681352466125E-16,-1.5707963267948966,-99.70545051757637 ) ;
  }

  @Test
  public void test3785() {
    coral.tests.JPFBenchmark.benchmark06(62.87734558751933,-92.02787817136344,-96.96972214738528 ) ;
  }

  @Test
  public void test3786() {
    coral.tests.JPFBenchmark.benchmark06(-63.179184058143335,21.179387011725723,71.32695437495818 ) ;
  }

  @Test
  public void test3787() {
    coral.tests.JPFBenchmark.benchmark06(63.26333908358771,38.65764860372346,-75.73644973387623 ) ;
  }

  @Test
  public void test3788() {
    coral.tests.JPFBenchmark.benchmark06(-6.3342054331664394E-9,-1.5707963267948966,-42.84266925731358 ) ;
  }

  @Test
  public void test3789() {
    coral.tests.JPFBenchmark.benchmark06(-6.344854593289123E-117,-1.5707963267948966,-99.99999999999996 ) ;
  }

  @Test
  public void test3790() {
    coral.tests.JPFBenchmark.benchmark06(-63.945235130757936,-70.1962008854853,-80.03217857857167 ) ;
  }

  @Test
  public void test3791() {
    coral.tests.JPFBenchmark.benchmark06(-64.10696536271156,52.12357935433144,-5.980358390683335 ) ;
  }

  @Test
  public void test3792() {
    coral.tests.JPFBenchmark.benchmark06(6.429313556828327,-1.5090525401336798,0.0 ) ;
  }

  @Test
  public void test3793() {
    coral.tests.JPFBenchmark.benchmark06(6.42937641565888,-0.098921655197454,-100.0 ) ;
  }

  @Test
  public void test3794() {
    coral.tests.JPFBenchmark.benchmark06(6.430267316457901,-53.831219676846196,0 ) ;
  }

  @Test
  public void test3795() {
    coral.tests.JPFBenchmark.benchmark06(6.430353925797442,1.5707963267948966,-38.076071628874914 ) ;
  }

  @Test
  public void test3796() {
    coral.tests.JPFBenchmark.benchmark06(6.431318039218334,0.1890828385942288,0 ) ;
  }

  @Test
  public void test3797() {
    coral.tests.JPFBenchmark.benchmark06(6.432371496364454,-44.172379571802715,-100.0 ) ;
  }

  @Test
  public void test3798() {
    coral.tests.JPFBenchmark.benchmark06(6.43559103772465,-1.0929280806986335,9.874859160283796 ) ;
  }

  @Test
  public void test3799() {
    coral.tests.JPFBenchmark.benchmark06(6.4424403888039246,-1.1790937840165012,-9.863723521238285 ) ;
  }

  @Test
  public void test3800() {
    coral.tests.JPFBenchmark.benchmark06(6.445389969724076,31.855133487449848,-14.478153915265608 ) ;
  }

  @Test
  public void test3801() {
    coral.tests.JPFBenchmark.benchmark06(-64.46026459997,80.86178282797985,-30.847819592158203 ) ;
  }

  @Test
  public void test3802() {
    coral.tests.JPFBenchmark.benchmark06(-6.4553311834394325E-15,-1.5707963267948966,11.461632981869888 ) ;
  }

  @Test
  public void test3803() {
    coral.tests.JPFBenchmark.benchmark06(6.489435037153034,1.5707963267948966,-101.51814983438064 ) ;
  }

  @Test
  public void test3804() {
    coral.tests.JPFBenchmark.benchmark06(-6.497131103528062E-114,-1.5707963267948966,-17.117103924665873 ) ;
  }

  @Test
  public void test3805() {
    coral.tests.JPFBenchmark.benchmark06(-6.501524609974229E-28,-1.5707963267948966,92.49605882896844 ) ;
  }

  @Test
  public void test3806() {
    coral.tests.JPFBenchmark.benchmark06(6.523934366381799,-1.5707963267948912,100.0 ) ;
  }

  @Test
  public void test3807() {
    coral.tests.JPFBenchmark.benchmark06(6.549499173072641,1.0071015097185175E-4,0 ) ;
  }

  @Test
  public void test3808() {
    coral.tests.JPFBenchmark.benchmark06(-6.573863561038464E-4,-1.5686284129868655,-46.03417973608667 ) ;
  }

  @Test
  public void test3809() {
    coral.tests.JPFBenchmark.benchmark06(65.75010375173363,69.89356686049325,46.64939034884159 ) ;
  }

  @Test
  public void test3810() {
    coral.tests.JPFBenchmark.benchmark06(-6.588873714519077E-83,-1.117166870237051,-0.012342534494299895 ) ;
  }

  @Test
  public void test3811() {
    coral.tests.JPFBenchmark.benchmark06(-6.588873714519077E-83,-1.5707963267948966,2.8489430530007898 ) ;
  }

  @Test
  public void test3812() {
    coral.tests.JPFBenchmark.benchmark06(-65.93127845608876,-8.150556597731537,-51.1754496233162 ) ;
  }

  @Test
  public void test3813() {
    coral.tests.JPFBenchmark.benchmark06(66.00880516600881,89.51488184219409,-4.918775467212527 ) ;
  }

  @Test
  public void test3814() {
    coral.tests.JPFBenchmark.benchmark06(6.6174449004242214E-24,-95.74801167527183,-1.5707963267948912 ) ;
  }

  @Test
  public void test3815() {
    coral.tests.JPFBenchmark.benchmark06(-6.651901936453233E-11,-0.144649102126595,70.92146342066133 ) ;
  }

  @Test
  public void test3816() {
    coral.tests.JPFBenchmark.benchmark06(-6.666586587203427E-5,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3817() {
    coral.tests.JPFBenchmark.benchmark06(-66.71484723641981,-94.40030530473524,-81.70989226724359 ) ;
  }

  @Test
  public void test3818() {
    coral.tests.JPFBenchmark.benchmark06(6.711581689683486E-4,1.5707963267948966,0 ) ;
  }

  @Test
  public void test3819() {
    coral.tests.JPFBenchmark.benchmark06(67.167798592732,50.63188029683815,-86.61730594854326 ) ;
  }

  @Test
  public void test3820() {
    coral.tests.JPFBenchmark.benchmark06(-6.7210504113797E-119,-1.5707963267948948,-1.5707963267948966 ) ;
  }

  @Test
  public void test3821() {
    coral.tests.JPFBenchmark.benchmark06(67.2525871421775,-47.4518269967795,7.238662575181593 ) ;
  }

  @Test
  public void test3822() {
    coral.tests.JPFBenchmark.benchmark06(-67.46561543981949,56.09907454976312,57.67302634674115 ) ;
  }

  @Test
  public void test3823() {
    coral.tests.JPFBenchmark.benchmark06(-6.754034012229084E-226,-0.3638230415977285,62.69388943965819 ) ;
  }

  @Test
  public void test3824() {
    coral.tests.JPFBenchmark.benchmark06(-6.754034012229084E-226,-1.3483286227479605,1.5707963267948966 ) ;
  }

  @Test
  public void test3825() {
    coral.tests.JPFBenchmark.benchmark06(6.761516705723701,-1.5574013910081954,15.664556199449438 ) ;
  }

  @Test
  public void test3826() {
    coral.tests.JPFBenchmark.benchmark06(6.776263578034403E-21,-1.1043003966408995,-1.5707963267947185 ) ;
  }

  @Test
  public void test3827() {
    coral.tests.JPFBenchmark.benchmark06(-6.776263578034403E-21,-1.570796290483144,47.124208127737624 ) ;
  }

  @Test
  public void test3828() {
    coral.tests.JPFBenchmark.benchmark06(-6.776263578034403E-21,-1.5707963267948912,47.125861894243336 ) ;
  }

  @Test
  public void test3829() {
    coral.tests.JPFBenchmark.benchmark06(6.776263578034403E-21,-1.5707963267948966,-10.529282268588048 ) ;
  }

  @Test
  public void test3830() {
    coral.tests.JPFBenchmark.benchmark06(-67.77424514847775,68.4849009382803,41.478374922699004 ) ;
  }

  @Test
  public void test3831() {
    coral.tests.JPFBenchmark.benchmark06(-6.780829445844254E-4,-1.570584622409505,97.227361661106 ) ;
  }

  @Test
  public void test3832() {
    coral.tests.JPFBenchmark.benchmark06(-6.8014656830015985E-6,-0.15936434795704732,44.318147293364774 ) ;
  }

  @Test
  public void test3833() {
    coral.tests.JPFBenchmark.benchmark06(6.810123002790147,-45.25552078136527,12.851261187104154 ) ;
  }

  @Test
  public void test3834() {
    coral.tests.JPFBenchmark.benchmark06(-6.833777252000406E-16,-1.5707963267948966,74.33076582890821 ) ;
  }

  @Test
  public void test3835() {
    coral.tests.JPFBenchmark.benchmark06(-68.4576687233756,-76.86243174426836,-69.33459422137851 ) ;
  }

  @Test
  public void test3836() {
    coral.tests.JPFBenchmark.benchmark06(68.60976624714067,-44.84297715687606,-70.74687624831621 ) ;
  }

  @Test
  public void test3837() {
    coral.tests.JPFBenchmark.benchmark06(6.873456935200555,1.5707963267948966,-73.67619734915256 ) ;
  }

  @Test
  public void test3838() {
    coral.tests.JPFBenchmark.benchmark06(-68.86276832962155,62.581502831092195,43.70096391902851 ) ;
  }

  @Test
  public void test3839() {
    coral.tests.JPFBenchmark.benchmark06(68.98451815920092,22.30520533221565,95.51241891294492 ) ;
  }

  @Test
  public void test3840() {
    coral.tests.JPFBenchmark.benchmark06(-6.924122356318013E-8,-1.5707963267948966,72.25719555216367 ) ;
  }

  @Test
  public void test3841() {
    coral.tests.JPFBenchmark.benchmark06(6.938893903907228E-18,-0.0038776917358550322,-1.4885894203823037E-20 ) ;
  }

  @Test
  public void test3842() {
    coral.tests.JPFBenchmark.benchmark06(6.938893903907228E-18,-0.905080294622858,23.960345941491003 ) ;
  }

  @Test
  public void test3843() {
    coral.tests.JPFBenchmark.benchmark06(-6.938893903907228E-18,-1.5707949884815522,59.68994240539122 ) ;
  }

  @Test
  public void test3844() {
    coral.tests.JPFBenchmark.benchmark06(6.938893903907228E-18,-1.5707963267948966,87.07516334319585 ) ;
  }

  @Test
  public void test3845() {
    coral.tests.JPFBenchmark.benchmark06(-6.938893903907228E-18,-39.26990816319693,-1.5707963267948963 ) ;
  }

  @Test
  public void test3846() {
    coral.tests.JPFBenchmark.benchmark06(-69.43712853119222,-87.7205882048594,47.921328774953224 ) ;
  }

  @Test
  public void test3847() {
    coral.tests.JPFBenchmark.benchmark06(-6.955738677643135E-16,-1.5707963267948966,-31.415926558636084 ) ;
  }

  @Test
  public void test3848() {
    coral.tests.JPFBenchmark.benchmark06(69.71977057143815,-33.28602716113815,0 ) ;
  }

  @Test
  public void test3849() {
    coral.tests.JPFBenchmark.benchmark06(-69.87123997905982,-84.01830338037264,-81.5365140385379 ) ;
  }

  @Test
  public void test3850() {
    coral.tests.JPFBenchmark.benchmark06(-69.93003267522353,35.831330407212306,-22.051744586462107 ) ;
  }

  @Test
  public void test3851() {
    coral.tests.JPFBenchmark.benchmark06(-69.9718233221842,-93.18535643558312,-43.45969046496781 ) ;
  }

  @Test
  public void test3852() {
    coral.tests.JPFBenchmark.benchmark06(-70.03293863894986,-79.85958591408469,73.99950486739374 ) ;
  }

  @Test
  public void test3853() {
    coral.tests.JPFBenchmark.benchmark06(70.12346352436342,-16.566399249752735,-7.4329186524834086 ) ;
  }

  @Test
  public void test3854() {
    coral.tests.JPFBenchmark.benchmark06(70.26578226683213,4.1239618148544395,51.71707052233998 ) ;
  }

  @Test
  public void test3855() {
    coral.tests.JPFBenchmark.benchmark06(70.37886512106937,84.47233242200053,73.25902303712598 ) ;
  }

  @Test
  public void test3856() {
    coral.tests.JPFBenchmark.benchmark06(-7.040057801896982E-4,-1.5707963267948966,26.814943907889884 ) ;
  }

  @Test
  public void test3857() {
    coral.tests.JPFBenchmark.benchmark06(-7.044203657368268E-133,-1.5707963267948961,-0.3827924222554522 ) ;
  }

  @Test
  public void test3858() {
    coral.tests.JPFBenchmark.benchmark06(-7.044203657368268E-133,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3859() {
    coral.tests.JPFBenchmark.benchmark06(70.55248924451382,-8.858682614582847,-40.22940259529653 ) ;
  }

  @Test
  public void test3860() {
    coral.tests.JPFBenchmark.benchmark06(70.88089544839659,51.959305894050715,-56.85021793537557 ) ;
  }

  @Test
  public void test3861() {
    coral.tests.JPFBenchmark.benchmark06(-70.98121961472785,-93.07198946271488,-60.40078671691447 ) ;
  }

  @Test
  public void test3862() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-0.05684936432109092,4.648878320625229 ) ;
  }

  @Test
  public void test3863() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-0.11154320376744925,0.9057053859880279 ) ;
  }

  @Test
  public void test3864() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-0.20462855521675197,-1061.2924215918847 ) ;
  }

  @Test
  public void test3865() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-0.5522717568353799,20.426782869472234 ) ;
  }

  @Test
  public void test3866() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-1.014472027997703,4.611995441438481 ) ;
  }

  @Test
  public void test3867() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,1.3877787807814457E-17,-40.565731010078856 ) ;
  }

  @Test
  public void test3868() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-1.5707963267948912,-10.510573781033528 ) ;
  }

  @Test
  public void test3869() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-1.5707963267948912,41.24846563120087 ) ;
  }

  @Test
  public void test3870() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-1.5707963267948966,1.5707963267948977 ) ;
  }

  @Test
  public void test3871() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-1.5707963267948966,-36.422982336609294 ) ;
  }

  @Test
  public void test3872() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-1.5707963267948966,58.05842170592638 ) ;
  }

  @Test
  public void test3873() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-1.5707963267948966,-85.88049203609832 ) ;
  }

  @Test
  public void test3874() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-1.5707963267948983,-44.18303069889162 ) ;
  }

  @Test
  public void test3875() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-1.5707963267948983,85.6589565598569 ) ;
  }

  @Test
  public void test3876() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-39.13750054765251,6.7123945456764575 ) ;
  }

  @Test
  public void test3877() {
    coral.tests.JPFBenchmark.benchmark06(-7.105427357601002E-15,-95.59202338562474,-31.427848830942793 ) ;
  }

  @Test
  public void test3878() {
    coral.tests.JPFBenchmark.benchmark06(-71.22880602772481,-61.55735944450535,68.7264907877506 ) ;
  }

  @Test
  public void test3879() {
    coral.tests.JPFBenchmark.benchmark06(71.2600652300682,31.598042943785202,-16.410598516568726 ) ;
  }

  @Test
  public void test3880() {
    coral.tests.JPFBenchmark.benchmark06(71.30491374576548,-68.18057990674461,40.26048405446235 ) ;
  }

  @Test
  public void test3881() {
    coral.tests.JPFBenchmark.benchmark06(-71.41171563971716,99.89836505951274,52.8331784584025 ) ;
  }

  @Test
  public void test3882() {
    coral.tests.JPFBenchmark.benchmark06(-7.143671195514219E-102,-94.27973506932466,-1.1102231183575782E-16 ) ;
  }

  @Test
  public void test3883() {
    coral.tests.JPFBenchmark.benchmark06(-71.51508524089405,78.657174721276,44.69886339505004 ) ;
  }

  @Test
  public void test3884() {
    coral.tests.JPFBenchmark.benchmark06(71.63388305064697,-2.0336299652310714,72.33133342910943 ) ;
  }

  @Test
  public void test3885() {
    coral.tests.JPFBenchmark.benchmark06(-71.74318328675085,35.85684527355093,-77.85884225055149 ) ;
  }

  @Test
  public void test3886() {
    coral.tests.JPFBenchmark.benchmark06(-7.1954708616414665E-16,-4.930260268135583E-15,66.02275846513648 ) ;
  }

  @Test
  public void test3887() {
    coral.tests.JPFBenchmark.benchmark06(-7.213264545145106E-130,-0.08847693408538622,79.71380454361604 ) ;
  }

  @Test
  public void test3888() {
    coral.tests.JPFBenchmark.benchmark06(-7.222403955817822E-15,-1.5707963267948966,-53.40707511102649 ) ;
  }

  @Test
  public void test3889() {
    coral.tests.JPFBenchmark.benchmark06(-72.23537225533761,-69.1541347894715,-14.710912927907245 ) ;
  }

  @Test
  public void test3890() {
    coral.tests.JPFBenchmark.benchmark06(-72.3139089686601,75.62563495253667,-44.61178119497389 ) ;
  }

  @Test
  public void test3891() {
    coral.tests.JPFBenchmark.benchmark06(-72.49579036436724,-34.550203948797176,-46.169653400425844 ) ;
  }

  @Test
  public void test3892() {
    coral.tests.JPFBenchmark.benchmark06(-7.252196097079351E-16,-0.24477326253278608,37.67575997192533 ) ;
  }

  @Test
  public void test3893() {
    coral.tests.JPFBenchmark.benchmark06(-72.84197191252564,62.03733621020908,-55.5154525541339 ) ;
  }

  @Test
  public void test3894() {
    coral.tests.JPFBenchmark.benchmark06(-7.287088992369036,82.42157736825635,-13.115320388194988 ) ;
  }

  @Test
  public void test3895() {
    coral.tests.JPFBenchmark.benchmark06(-72.97728555929253,-56.67667788423567,-70.99111937340454 ) ;
  }

  @Test
  public void test3896() {
    coral.tests.JPFBenchmark.benchmark06(73.2913560290566,0,0 ) ;
  }

  @Test
  public void test3897() {
    coral.tests.JPFBenchmark.benchmark06(-73.4274017914741,-58.2145531326697,0 ) ;
  }

  @Test
  public void test3898() {
    coral.tests.JPFBenchmark.benchmark06(-73.5334139148251,-91.79194847158254,32.40832079347666 ) ;
  }

  @Test
  public void test3899() {
    coral.tests.JPFBenchmark.benchmark06(73.55642844298174,2.017544490659631,0.5602986550012048 ) ;
  }

  @Test
  public void test3900() {
    coral.tests.JPFBenchmark.benchmark06(-7.377086789088771E-4,-0.4859100730803012,-41.28580845351652 ) ;
  }

  @Test
  public void test3901() {
    coral.tests.JPFBenchmark.benchmark06(-73.9757685894283,5.466120070992162,53.6402337311481 ) ;
  }

  @Test
  public void test3902() {
    coral.tests.JPFBenchmark.benchmark06(-7.409329633682149E-21,-1.5707963267948966,-143.00562353299935 ) ;
  }

  @Test
  public void test3903() {
    coral.tests.JPFBenchmark.benchmark06(74.59313334465466,13.499060179254286,-17.38714334515987 ) ;
  }

  @Test
  public void test3904() {
    coral.tests.JPFBenchmark.benchmark06(-74.6079954310807,0,0 ) ;
  }

  @Test
  public void test3905() {
    coral.tests.JPFBenchmark.benchmark06(-7.52316384526264E-37,-1.5707963267948966,59.69025839089561 ) ;
  }

  @Test
  public void test3906() {
    coral.tests.JPFBenchmark.benchmark06(75.25230009163087,89.54960529231448,43.6911566142976 ) ;
  }

  @Test
  public void test3907() {
    coral.tests.JPFBenchmark.benchmark06(-75.39589324226282,-46.06520052277732,96.96293934041915 ) ;
  }

  @Test
  public void test3908() {
    coral.tests.JPFBenchmark.benchmark06(-7.610108205681776E-22,-1.5707963267948966,-78.53981633969131 ) ;
  }

  @Test
  public void test3909() {
    coral.tests.JPFBenchmark.benchmark06(76.34542708237433,-38.9220163582918,9.710700742098169 ) ;
  }

  @Test
  public void test3910() {
    coral.tests.JPFBenchmark.benchmark06(-76.53132746142417,94.11953343981833,-67.45222555041184 ) ;
  }

  @Test
  public void test3911() {
    coral.tests.JPFBenchmark.benchmark06(-76.60957850530679,66.30256794303213,-56.63999171130178 ) ;
  }

  @Test
  public void test3912() {
    coral.tests.JPFBenchmark.benchmark06(76.7168512494737,-6.780616662882963,80.33480322038903 ) ;
  }

  @Test
  public void test3913() {
    coral.tests.JPFBenchmark.benchmark06(76.89577475950472,-58.28729618599895,-32.39804434057987 ) ;
  }

  @Test
  public void test3914() {
    coral.tests.JPFBenchmark.benchmark06(-77.08170922636185,-68.07528101686916,12.79409595530258 ) ;
  }

  @Test
  public void test3915() {
    coral.tests.JPFBenchmark.benchmark06(77.57067712871324,-61.32913962456288,51.833622266254906 ) ;
  }

  @Test
  public void test3916() {
    coral.tests.JPFBenchmark.benchmark06(77.62367738477306,46.48435185618936,91.87275110233563 ) ;
  }

  @Test
  public void test3917() {
    coral.tests.JPFBenchmark.benchmark06(7.784452680196878,-9.35913854705099,-83.76550085242627 ) ;
  }

  @Test
  public void test3918() {
    coral.tests.JPFBenchmark.benchmark06(-7.786871055544975E-208,-0.9309371761132171,28.10328448401429 ) ;
  }

  @Test
  public void test3919() {
    coral.tests.JPFBenchmark.benchmark06(78.10392587464497,-74.10817474761937,95.60143941998982 ) ;
  }

  @Test
  public void test3920() {
    coral.tests.JPFBenchmark.benchmark06(-7.820637090558988E-149,-1.5707963267948966,-7.293300727064096 ) ;
  }

  @Test
  public void test3921() {
    coral.tests.JPFBenchmark.benchmark06(78.3126283867515,-83.82321688095706,10.894746968332385 ) ;
  }

  @Test
  public void test3922() {
    coral.tests.JPFBenchmark.benchmark06(-78.48775157976988,-50.29519385624288,81.30444226559817 ) ;
  }

  @Test
  public void test3923() {
    coral.tests.JPFBenchmark.benchmark06(78.55604214902664,4.748425184831831,38.51659593053873 ) ;
  }

  @Test
  public void test3924() {
    coral.tests.JPFBenchmark.benchmark06(-78.71082337804312,71.04391724595251,-48.79837371533529 ) ;
  }

  @Test
  public void test3925() {
    coral.tests.JPFBenchmark.benchmark06(7.888609052210118E-31,-1.5707963267948966,34.200853384447484 ) ;
  }

  @Test
  public void test3926() {
    coral.tests.JPFBenchmark.benchmark06(7.888609052210118E-31,-1.5707963267948966,44.27668227460316 ) ;
  }

  @Test
  public void test3927() {
    coral.tests.JPFBenchmark.benchmark06(-79.11414626588723,-66.17047255789382,28.35859813145612 ) ;
  }

  @Test
  public void test3928() {
    coral.tests.JPFBenchmark.benchmark06(79.14520822693217,73.84771421348219,9.413346993903076 ) ;
  }

  @Test
  public void test3929() {
    coral.tests.JPFBenchmark.benchmark06(-7.962242073503717,36.78025915493399,-85.23126926903343 ) ;
  }

  @Test
  public void test3930() {
    coral.tests.JPFBenchmark.benchmark06(-79.7292850885515,70.75362370131043,68.938488973382 ) ;
  }

  @Test
  public void test3931() {
    coral.tests.JPFBenchmark.benchmark06(-8.002568196825986E-15,-1.5707963267948966,30.985868949889834 ) ;
  }

  @Test
  public void test3932() {
    coral.tests.JPFBenchmark.benchmark06(-8.008332380732404E-146,-0.06316624809872623,66.39639828217489 ) ;
  }

  @Test
  public void test3933() {
    coral.tests.JPFBenchmark.benchmark06(-80.23398343872701,0,0 ) ;
  }

  @Test
  public void test3934() {
    coral.tests.JPFBenchmark.benchmark06(80.33164349268614,-64.46487188594554,-18.720400842391285 ) ;
  }

  @Test
  public void test3935() {
    coral.tests.JPFBenchmark.benchmark06(80.55722445770712,-82.23478183290753,-51.45123580260549 ) ;
  }

  @Test
  public void test3936() {
    coral.tests.JPFBenchmark.benchmark06(-80.91832906140455,4.2757288810374945,-86.73555520502809 ) ;
  }

  @Test
  public void test3937() {
    coral.tests.JPFBenchmark.benchmark06(81.0034122807397,76.27339288386347,55.175992523062035 ) ;
  }

  @Test
  public void test3938() {
    coral.tests.JPFBenchmark.benchmark06(81.18650722954743,45.2405932075597,63.79311183413134 ) ;
  }

  @Test
  public void test3939() {
    coral.tests.JPFBenchmark.benchmark06(-8.1214138794100775E-115,-1.2753130148206024,-88.1342142064822 ) ;
  }

  @Test
  public void test3940() {
    coral.tests.JPFBenchmark.benchmark06(-81.61393080828137,49.392078701194976,31.19970240349133 ) ;
  }

  @Test
  public void test3941() {
    coral.tests.JPFBenchmark.benchmark06(82.29095945019728,61.3958179187764,-71.66783421925369 ) ;
  }

  @Test
  public void test3942() {
    coral.tests.JPFBenchmark.benchmark06(82.48653248155335,9.50597367799773,-83.14454037872392 ) ;
  }

  @Test
  public void test3943() {
    coral.tests.JPFBenchmark.benchmark06(8.271806125530277E-25,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3944() {
    coral.tests.JPFBenchmark.benchmark06(82.9751550661905,57.50703243298065,3.371296544607489 ) ;
  }

  @Test
  public void test3945() {
    coral.tests.JPFBenchmark.benchmark06(83.03482882505656,85.95204448930818,-81.70900622773158 ) ;
  }

  @Test
  public void test3946() {
    coral.tests.JPFBenchmark.benchmark06(-83.32242047130799,0,0 ) ;
  }

  @Test
  public void test3947() {
    coral.tests.JPFBenchmark.benchmark06(-8.364716053063342E-15,-1.5707963267948966,1.5707963267948977 ) ;
  }

  @Test
  public void test3948() {
    coral.tests.JPFBenchmark.benchmark06(-8.37086757716321E-4,-1.5707963267948966,58.68118519622834 ) ;
  }

  @Test
  public void test3949() {
    coral.tests.JPFBenchmark.benchmark06(83.91291033975483,-55.73917792893648,78.23135698308735 ) ;
  }

  @Test
  public void test3950() {
    coral.tests.JPFBenchmark.benchmark06(8.470329472543003E-22,-1.5707963267948966,-35.35613513807287 ) ;
  }

  @Test
  public void test3951() {
    coral.tests.JPFBenchmark.benchmark06(-84.88614590795818,-82.39425609985994,34.87073841900357 ) ;
  }

  @Test
  public void test3952() {
    coral.tests.JPFBenchmark.benchmark06(85.08461234763936,-28.45853292437282,-86.00030868006603 ) ;
  }

  @Test
  public void test3953() {
    coral.tests.JPFBenchmark.benchmark06(-8.515689590638767E-14,-1.5707963267948966,93.52677373498044 ) ;
  }

  @Test
  public void test3954() {
    coral.tests.JPFBenchmark.benchmark06(-85.7100229359797,-89.15380503882466,83.11126503013048 ) ;
  }

  @Test
  public void test3955() {
    coral.tests.JPFBenchmark.benchmark06(-85.90230897080464,43.57260430239492,-32.240681699575035 ) ;
  }

  @Test
  public void test3956() {
    coral.tests.JPFBenchmark.benchmark06(86.15654574480541,-44.21857988527857,3.5402254160932927 ) ;
  }

  @Test
  public void test3957() {
    coral.tests.JPFBenchmark.benchmark06(86.46004864621156,69.17220526998838,-39.96016979941659 ) ;
  }

  @Test
  public void test3958() {
    coral.tests.JPFBenchmark.benchmark06(-86.55694104158664,-17.9157150761462,41.61139725191879 ) ;
  }

  @Test
  public void test3959() {
    coral.tests.JPFBenchmark.benchmark06(-86.57912608289891,-57.30117426506005,-14.782261196194185 ) ;
  }

  @Test
  public void test3960() {
    coral.tests.JPFBenchmark.benchmark06(8.673617379884035E-19,-1.4357432244885662,-17.24056859357757 ) ;
  }

  @Test
  public void test3961() {
    coral.tests.JPFBenchmark.benchmark06(8.673617379884035E-19,-1.5707963267948966,15.571791183183139 ) ;
  }

  @Test
  public void test3962() {
    coral.tests.JPFBenchmark.benchmark06(8.673617379884035E-19,-1.5707963267948966,-4.4250987686762215 ) ;
  }

  @Test
  public void test3963() {
    coral.tests.JPFBenchmark.benchmark06(8.673617379884035E-19,-1.5707963267948966,-56.20831461852892 ) ;
  }

  @Test
  public void test3964() {
    coral.tests.JPFBenchmark.benchmark06(87.01844662875419,-67.13344570157003,41.470492018353895 ) ;
  }

  @Test
  public void test3965() {
    coral.tests.JPFBenchmark.benchmark06(-8.713360025975561,8.73978217484084,31.947623654087778 ) ;
  }

  @Test
  public void test3966() {
    coral.tests.JPFBenchmark.benchmark06(-87.22147267377005,14.670859237506079,26.49489634355615 ) ;
  }

  @Test
  public void test3967() {
    coral.tests.JPFBenchmark.benchmark06(87.85453117642732,41.42645289261736,47.054459816384764 ) ;
  }

  @Test
  public void test3968() {
    coral.tests.JPFBenchmark.benchmark06(-88.03712830715105,7.1123167853502025,9.203984613777621 ) ;
  }

  @Test
  public void test3969() {
    coral.tests.JPFBenchmark.benchmark06(-8.842084854491156E-16,-1.5707963267948966,-80.20434636615141 ) ;
  }

  @Test
  public void test3970() {
    coral.tests.JPFBenchmark.benchmark06(88.50250561859471,81.44088898626015,-21.74600863449254 ) ;
  }

  @Test
  public void test3971() {
    coral.tests.JPFBenchmark.benchmark06(-88.53164668267839,90.86910515801617,-17.398242978325413 ) ;
  }

  @Test
  public void test3972() {
    coral.tests.JPFBenchmark.benchmark06(-88.54783658855668,-79.0199835345546,-60.28526102602383 ) ;
  }

  @Test
  public void test3973() {
    coral.tests.JPFBenchmark.benchmark06(8.868757369894266E-17,-1.1261727781712834,-62.49639962075313 ) ;
  }

  @Test
  public void test3974() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-0.009277541086438763,1.5707963267948966 ) ;
  }

  @Test
  public void test3975() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-0.6638584707767884,-49.93581209431956 ) ;
  }

  @Test
  public void test3976() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-0.9482836006701432,0.0 ) ;
  }

  @Test
  public void test3977() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.0871134162336349,-7.080198919177462 ) ;
  }

  @Test
  public void test3978() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.2698209758421957,1.5707963267948966 ) ;
  }

  @Test
  public void test3979() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.2801954237595576,-523.5675224714537 ) ;
  }

  @Test
  public void test3980() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.5707963247518217,45.566888563720475 ) ;
  }

  @Test
  public void test3981() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.5707963267948912,-5.359156842694776 ) ;
  }

  @Test
  public void test3982() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.5707963267948948,-21.97190802375179 ) ;
  }

  @Test
  public void test3983() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.5707963267948966,15.26349359505781 ) ;
  }

  @Test
  public void test3984() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.5707963267948966,15.700908103102298 ) ;
  }

  @Test
  public void test3985() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3986() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3987() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-1.5707963267948966,-60.60337811355843 ) ;
  }

  @Test
  public void test3988() {
    coral.tests.JPFBenchmark.benchmark06(-8.881784197001252E-16,-95.77990369277676,0 ) ;
  }

  @Test
  public void test3989() {
    coral.tests.JPFBenchmark.benchmark06(-88.97523253816266,-62.78061763964033,85.41349301452868 ) ;
  }

  @Test
  public void test3990() {
    coral.tests.JPFBenchmark.benchmark06(89.02202787741598,73.62437795287192,78.83237746785639 ) ;
  }

  @Test
  public void test3991() {
    coral.tests.JPFBenchmark.benchmark06(-89.04188634815857,-80.8997140789433,32.773031193067396 ) ;
  }

  @Test
  public void test3992() {
    coral.tests.JPFBenchmark.benchmark06(-89.42061639335839,82.39414308791041,19.51069821360774 ) ;
  }

  @Test
  public void test3993() {
    coral.tests.JPFBenchmark.benchmark06(89.43013822171244,-54.713753010534894,-88.30299463724252 ) ;
  }

  @Test
  public void test3994() {
    coral.tests.JPFBenchmark.benchmark06(-89.51677005517622,12.003377584849176,51.52985615586846 ) ;
  }

  @Test
  public void test3995() {
    coral.tests.JPFBenchmark.benchmark06(-89.74234288228422,74.10764403847037,-85.1773057018539 ) ;
  }

  @Test
  public void test3996() {
    coral.tests.JPFBenchmark.benchmark06(90.02363257770801,70.41505758140428,-21.385379386664 ) ;
  }

  @Test
  public void test3997() {
    coral.tests.JPFBenchmark.benchmark06(90.2592245554238,-38.76878321950041,59.28607364449482 ) ;
  }

  @Test
  public void test3998() {
    coral.tests.JPFBenchmark.benchmark06(90.29604054373027,-98.49656689264093,19.837343061648014 ) ;
  }

  @Test
  public void test3999() {
    coral.tests.JPFBenchmark.benchmark06(90.30748958200024,-32.64125850345803,-7.275685091705782 ) ;
  }

  @Test
  public void test4000() {
    coral.tests.JPFBenchmark.benchmark06(90.4048524030303,12.199584387617307,47.46673969915503 ) ;
  }

  @Test
  public void test4001() {
    coral.tests.JPFBenchmark.benchmark06(-91.62960961522073,55.055363102019584,97.94206266737453 ) ;
  }

  @Test
  public void test4002() {
    coral.tests.JPFBenchmark.benchmark06(91.88937262500775,88.63571011996402,82.1046663974385 ) ;
  }

  @Test
  public void test4003() {
    coral.tests.JPFBenchmark.benchmark06(-92.05520311603908,79.01798365058028,-92.3186740056386 ) ;
  }

  @Test
  public void test4004() {
    coral.tests.JPFBenchmark.benchmark06(92.08348934025395,80.71326686598397,-21.9957591306802 ) ;
  }

  @Test
  public void test4005() {
    coral.tests.JPFBenchmark.benchmark06(-92.26230763475142,33.05208592708297,59.70708584662262 ) ;
  }

  @Test
  public void test4006() {
    coral.tests.JPFBenchmark.benchmark06(-9.232978617785736E-128,-0.668222222979716,1.5707963267948966 ) ;
  }

  @Test
  public void test4007() {
    coral.tests.JPFBenchmark.benchmark06(92.58006283990818,-32.09067559728709,46.48667814191231 ) ;
  }

  @Test
  public void test4008() {
    coral.tests.JPFBenchmark.benchmark06(92.65566451034016,-90.86045317767173,-90.34376743219266 ) ;
  }

  @Test
  public void test4009() {
    coral.tests.JPFBenchmark.benchmark06(-92.71965069649804,29.197268759514373,96.20568222176175 ) ;
  }

  @Test
  public void test4010() {
    coral.tests.JPFBenchmark.benchmark06(-9.273015376718553E-69,-1.5707963267948966,20.209522818705103 ) ;
  }

  @Test
  public void test4011() {
    coral.tests.JPFBenchmark.benchmark06(-9.281763512990881E-8,-1.5707963267948966,34.55742526264176 ) ;
  }

  @Test
  public void test4012() {
    coral.tests.JPFBenchmark.benchmark06(93.11090177892521,-90.21251474267528,69.704811340747 ) ;
  }

  @Test
  public void test4013() {
    coral.tests.JPFBenchmark.benchmark06(9.315325089403913,-73.11484046953333,-93.50099477612414 ) ;
  }

  @Test
  public void test4014() {
    coral.tests.JPFBenchmark.benchmark06(-9.339387749502424E-16,-0.012191066742734291,18.41021151585163 ) ;
  }

  @Test
  public void test4015() {
    coral.tests.JPFBenchmark.benchmark06(93.49793951216245,96.3193739971249,19.39843228016889 ) ;
  }

  @Test
  public void test4016() {
    coral.tests.JPFBenchmark.benchmark06(93.58395022571437,11.773021822933444,38.77177658147755 ) ;
  }

  @Test
  public void test4017() {
    coral.tests.JPFBenchmark.benchmark06(93.68444379791953,27.714237415038994,-62.60330376776453 ) ;
  }

  @Test
  public void test4018() {
    coral.tests.JPFBenchmark.benchmark06(-93.75493109894775,19.693046224488214,-28.68274359254903 ) ;
  }

  @Test
  public void test4019() {
    coral.tests.JPFBenchmark.benchmark06(-9.407896562574862,0,0 ) ;
  }

  @Test
  public void test4020() {
    coral.tests.JPFBenchmark.benchmark06(-94.66059646951035,54.78461896790276,-30.885794540625582 ) ;
  }

  @Test
  public void test4021() {
    coral.tests.JPFBenchmark.benchmark06(-9.491997134274906E-16,-1.5707963267948966,-97.59926179897106 ) ;
  }

  @Test
  public void test4022() {
    coral.tests.JPFBenchmark.benchmark06(-94.92481205683856,-83.93554229731777,24.124802645217855 ) ;
  }

  @Test
  public void test4023() {
    coral.tests.JPFBenchmark.benchmark06(-95.14386271259372,95.6669172464724,-70.6336381562318 ) ;
  }

  @Test
  public void test4024() {
    coral.tests.JPFBenchmark.benchmark06(9.52074623069792E-17,-1.4236129186410877,-95.32460004576191 ) ;
  }

  @Test
  public void test4025() {
    coral.tests.JPFBenchmark.benchmark06(-9.537405572240361E-13,-1.3595543732363065,3.958289018386793 ) ;
  }

  @Test
  public void test4026() {
    coral.tests.JPFBenchmark.benchmark06(-9.538542568931803,-70.74277568514431,2.283383497419493 ) ;
  }

  @Test
  public void test4027() {
    coral.tests.JPFBenchmark.benchmark06(95.39148542458307,-13.08307642113526,-61.588062097037025 ) ;
  }

  @Test
  public void test4028() {
    coral.tests.JPFBenchmark.benchmark06(-9.574343402281238E-18,-1.5598222823412686,49.67734493572068 ) ;
  }

  @Test
  public void test4029() {
    coral.tests.JPFBenchmark.benchmark06(-9.604444602644364,-67.81731460813967,77.43302783138785 ) ;
  }

  @Test
  public void test4030() {
    coral.tests.JPFBenchmark.benchmark06(-96.31276920349575,-7.295835225112214,-1.8101025963484147 ) ;
  }

  @Test
  public void test4031() {
    coral.tests.JPFBenchmark.benchmark06(96.39982860812256,91.9134381343334,-54.759020301382755 ) ;
  }

  @Test
  public void test4032() {
    coral.tests.JPFBenchmark.benchmark06(-96.76194837033488,84.54579163364008,-2.5616858637028486 ) ;
  }

  @Test
  public void test4033() {
    coral.tests.JPFBenchmark.benchmark06(97.48570270684874,2.6545916555332383,-66.85167463167264 ) ;
  }

  @Test
  public void test4034() {
    coral.tests.JPFBenchmark.benchmark06(-97.87439242223223,-95.86762690344403,98.4938397317344 ) ;
  }

  @Test
  public void test4035() {
    coral.tests.JPFBenchmark.benchmark06(-97.94050267159895,-82.14911202353292,43.56724546055068 ) ;
  }

  @Test
  public void test4036() {
    coral.tests.JPFBenchmark.benchmark06(-9.812715581668709E-100,-0.1249467158351528,-1.5707963267948966 ) ;
  }

  @Test
  public void test4037() {
    coral.tests.JPFBenchmark.benchmark06(-98.23461494779463,-84.89482683193393,-62.84745301062067 ) ;
  }

  @Test
  public void test4038() {
    coral.tests.JPFBenchmark.benchmark06(-9.830939444713295,-37.28627913730449,-73.89437019248417 ) ;
  }

  @Test
  public void test4039() {
    coral.tests.JPFBenchmark.benchmark06(9.860761315262648E-32,-0.8945554472024574,34.18056532474699 ) ;
  }

  @Test
  public void test4040() {
    coral.tests.JPFBenchmark.benchmark06(-9.860761315262648E-32,-1.570796326794889,-49.09180918671613 ) ;
  }

  @Test
  public void test4041() {
    coral.tests.JPFBenchmark.benchmark06(-98.80966011952627,-18.850340124905628,-9.420240912232074 ) ;
  }

  @Test
  public void test4042() {
    coral.tests.JPFBenchmark.benchmark06(-9.897772222545468E-5,-1.5707816273073032,7.85336966945122 ) ;
  }

  @Test
  public void test4043() {
    coral.tests.JPFBenchmark.benchmark06(-99.33580459960667,-63.28404500099347,33.74812911559951 ) ;
  }

  @Test
  public void test4044() {
    coral.tests.JPFBenchmark.benchmark06(9.953079020678615,-17.396269847833935,43.838012441668525 ) ;
  }

  @Test
  public void test4045() {
    coral.tests.JPFBenchmark.benchmark06(-99.69933487331527,0,0 ) ;
  }

  @Test
  public void test4046() {
    coral.tests.JPFBenchmark.benchmark06(99.72247215247816,20.050560552977274,44.62962061457836 ) ;
  }

  @Test
  public void test4047() {
    coral.tests.JPFBenchmark.benchmark06(-99.74478803598936,-47.9501564970547,75.70534840384971 ) ;
  }

  @Test
  public void test4048() {
    coral.tests.JPFBenchmark.benchmark06(-9.99009086274232,65.95650127340511,98.53005837761705 ) ;
  }
}
