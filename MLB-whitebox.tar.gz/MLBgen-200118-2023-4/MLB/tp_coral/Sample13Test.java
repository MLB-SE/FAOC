import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(0,-10.26240564492089,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(0,-15.118759160471257,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(0,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark13(0,2.1842308118452394,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark13(0,-22.715311578125366,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark13(0,-23.49618732610614,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark13(0,2.465190328815662E-32,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark13(0,-2639.4604386751234,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark13(0,-2646.15333617405,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark13(0,-29.86830568232952,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark13(0,-46.55744746652206,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark13(0,5.160022684444641,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark13(0,-52.49365552350784,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark13(0,-59.69781523138351,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark13(0,-87.08323583206996,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark13(0,88.06334547930473,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark13(0,-88.16120296425913,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark13(0.8982116465067869,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark13(0,-97.85549817987913,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000004,-1.5707963267948966,-43.34058800251406,1.0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark13(-1.000000000000007,-1.5707963267948966,-60.12339379584415,-1.0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark13(-1.000000000000007,-1.5707963267948983,-37.923728249585544,87.109427731957 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000089,-1.5707963267948966,-33.42289887163551,-2.4158169363188875E-16 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000142,-1.5707963267948983,0.24532919884294618,0.7520100921608583 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000213,-1.5707963267948966,-27.092807312678673,30.803281894413686 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.2900464005014087E-15,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.570796326794886,-37.45901265103079,-1.0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948912,-1.5707963267949019,-34.84700278342957 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948921,-80.84613562567401,-0.22174065225441253 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948946,-81.0433610307935,0.554526074626557 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,-1.5707963267948966,-0.36208927206009034 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,-1.5707963267949054,-0.03411968699433254 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,-48.2332358337082,-1.0000002376698633 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,-67.3780176682544,0.009338739363713433 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.570796326794895,0.0,0.34120511587050684 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948957,-1.7763568394002505E-15,-1.0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948963,-52.1281802491159,-0.9999999999999997 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.0,0.04164487363580943 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.0,-0.05575969820572358 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.004482848123940499,-2.4988948268662878E-5 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.0,-0.5560718902528049 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.0,0.7056868297947534 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.0,-1.0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.0,1.0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.0,1.000000000000007 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.0,1.000000000029017 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.0,-1.0000000303599583 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.0,1.000002560344517 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.0,20.89103661535505 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-0.021068271200760665,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.0,2.310446700342366 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.026014932840419634,1.0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.040188656869801775,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.05438615350580062,2.220446049250313E-16 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.0,-62.61374767001297 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.0,-70.1145787948109 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.0,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-0.07165228846713839,82.75650081104975 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.08320229520335298,4.929151156471633 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.0,-84.15483062576119 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-0.10395015173164203,99.4504405515716 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.15515797188241776,-4.6816763546921983E-97 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-0.16119528152919393,-0.06255259928565278 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.19531382733354985,-0.21483949054325585 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-0.24594269458010815,-1.0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-0.4127952745125111,1.4772765788457177E-126 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-0.553201410365277,-2.169610516259067 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-0.5843169536360644,0.6484673218842287 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.6197881870380079,0.7395727732985051 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-0.712215703262898,51.783252106943515 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.7579133495330336,0.006698808054606764 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-0.8300796753215168,0.8882012315689527 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.8344488521328337,-1.0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,0.8403923943323122,0.6212981015722294 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-0.9663067524941734,-0.983123191297203 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-100.0,0.21443690695148032 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-100.0,-1.0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-100.0,1.0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-100.0,1.0000001606617561 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-100.0,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,1.0429352955348277,-1.0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,1.0467487991264162,-1.0000494047900188 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-1.0744992000142422,8.794174919484803 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,1.1102230246251565E-16,-48.963473149609726 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-11.18082264765863,0.6742788234985537 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-12.251092553141433,7.105427357601002E-15 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-1.234569566131067,0.9999999999999996 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-12.721799219459657,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-1.290757276579144,35.695607308204515 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,1.3072156831221389,14.696175569973715 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-1.38499028422054,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-14.614220139878498,1.0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,1.4738279151701477,-1.0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-14.998066011409126,39.44364975749312 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,1.5113606472356997,-1.0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,1.5496622719847113,17.462876507941896 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,1.5707963267906124,0.06255904236104688 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,1.570796326794854,-9.29521746741257 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-1.5707963267948912,0.9807069056826304 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,1.5707963267948948,1.0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-1.5707963267948961,0.06255359748980595 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-1.5707963267948966,0.045152102070689315 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-1.5707963267948966,-0.0625658421868411 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-1.5707963267948966,-0.832176525360152 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-1.5707963267948966,-1.0023682427685965 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-1.5707963267948966,11.004314241391597 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-1.5707963267948966,-1.4225655996704496E-160 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,1.5707963267948966,-26.21013803775221 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,1.5707963267948966,-5.169878828456423E-26 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,1.5707963267948966,-80.3854964647573 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,1.5707963267949054,-1.0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,1.570796326795039,0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-15.806730955284877,1.0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-1.6467390163799376,0.0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,1.724762489005496E-16,1.0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-17.278759594743864,0.0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-20.51129737178077,-1.0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-22.80555954484499,-0.8835687448892482 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,2445.075289049355,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-2.7888439711272284,-1.0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-28.64551285819732,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-30.14122117181737,0.014978929436719015 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-33.64278190212521,30.061711596196915 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-34.15154788135214,-0.3622523898662045 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-35.9035242033985,47.86582474785328 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-36.263596028812316,0.7175923402270137 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-36.43063129027428,-1.0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-38.25763728555465,-1.0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-41.028456940286496,0.5478471728985381 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-43.08762334623467,-0.12585893145589133 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-43.847850797630386,-0.9857931792307316 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-44.35070507123915,-100.0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-45.294260003565626,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-45.588782509098614,-1.0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-46.13233111215222,0.028408492171017624 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-46.98513796348536,-1.0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-48.817897668801955,1.0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-49.205827604902424,-25.194950077026036 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-49.60600803117392,-28.250374176804854 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-49.619854044703764,-13.978845863843663 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-49.92660975588734,-1.0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-50.22103065683594,80.51146019527067 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-50.225613458918204,-0.031196800279471915 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-51.9137564184774,1.0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-53.91570355724369,0.0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-54.49498718696982,-0.06255456086289334 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-54.86672319245959,-1.0440487148797639E-53 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-54.86772817769876,1.0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-56.4852274743545,-0.6580386944138219 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-61.26105674500097,-1.0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-61.479131325850275,0.025525312307730974 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-62.82562188726181,-0.9999999999999989 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-63.10987023383807,2.6469779601696886E-23 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-64.35167439841923,0.3621138324400474 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-66.0743142225995,0.9999999999999999 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-66.12710467297013,-1.0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-66.26290095685297,0.9763482536045273 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-66.68329256355341,-0.7816245111044372 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-67.48288194824195,0.9543952571068655 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-68.03063364784273,-1.0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-68.08410607274438,1.0000000355710437 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-68.53029110411252,6.6704233332533205 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-68.7395663958476,1.0000000878736606 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-71.05899214431923,-4.2351647362715017E-22 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-71.52129920100899,-0.06256189116407625 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-72.58726497918444,0.7522049438852653 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-74.69939618166089,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-78.08595936750825,44.90602246634677 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-78.27776669736161,1.0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-78.37490117089517,29.346548923076057 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-78.71611402444194,74.04317610780369 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-79.33531186470152,-1.0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-82.95361275959137,-0.30040541569675727 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-86.01609315982986,1.0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-86.0803885119609,22.384218248308628 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-86.39379797371932,-5.350035764308624 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-86.39536061849492,-7.192721357244597E-8 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-86.75855159667223,35.18086995498595 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-90.82122348039779,-13.289711433114178 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-91.30401540580634,1.0000251224619647 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-94.02601040346421,1.0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-94.13101836043248,0.031541857839696874 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-9.467078774951034,-1.0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-9.479059741615046,-1.0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-94.82959962614405,-1.9939506485150966E-7 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-96.89323810199689,-1.0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-9.815523784635579,-0.14125891574081828 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-9.883917755787834,0.06255466227567695 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948966,-99.68934652989097,0.06059281364912461 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948968,-1.5707963267948983,0.40567101524104343 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948968,-62.77179384490512,1.0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948972,-1.4164352144311163,79.35345543294314 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948983,0.0,0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948983,0.0,-0.22354859182931408 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948983,-0.17509025546657875,0.9999999999999991 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948983,-0.8717562514016817,-31.062586261742496 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948983,-100.0,100.0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948983,-10.324310904639418,25.389882169032944 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948983,-136.53447350469776,0.0027835093552170237 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948983,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948983,-1.620151442989768,145.16653657701963 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948983,-2501.013947894201,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948983,-52.20067649366968,-1.0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948983,-57.40703681884015,-1.0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948983,-59.46644636105961,-0.9773703120632405 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267949019,-0.2503523969114406,-2.2459466615417716 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267949019,-100.0,-1.0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267949052,-99.83061589795761,1.0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267949192,-0.013689247083021105,436.27256332676353 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark13(-1.0002026903828454,-1.5707963267948966,-100.0,-0.5818873249552539 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,2.465190328815662E-32,0,0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark13(-10.068969819873558,-1.5707963267949054,-55.87307965922617,-31.49054193415695 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark13(-100.73152772776604,-1.5707963267906435,-157.7792045874331,48.10909408488573 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark13(-1.0103974867404892,-1.5707963267948966,-53.29929305491832,-0.28379038207923596 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark13(-101.14140687512338,-1.5707963267948983,-26.666251344670172,-2010.5895458458701 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark13(-10.12723518466996,-1.5707963267948966,-46.19501034385887,-0.879819412743818 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark13(-10.1411741267969,-1.5707963267948966,-61.26827740617695,8.470329472543003E-22 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark13(-1.0,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark13(1.0,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark13(-10.15883524706201,-1.5707963267948983,-7.501335353320734,-0.3690995791343177 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark13(-1.0195842195818148,-1.5707963267948966,-21.28678724173952,-34.50899566812226 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark13(-102.41894576947811,-1.5707963267948983,1.1102230246251565E-16,2052.398860761284 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark13(-10.248576211225817,-1.5707963267948966,-23.800747050569978,-0.037591888588593414 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark13(-1.0300465579460099,-1.5707963267948966,1.1102230246251565E-16,1.0000132090935723 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark13(-10.32922319375492,-1.5707963267948966,-56.39498243560884,1.0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark13(-103.59693772158087,-1.5707963267948966,0.10748626431836729,1195.3060461262792 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark13(-10.374540759434533,-1.5707963267948966,3.085022898306006E-15,-18.483485777550758 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark13(-103.83770260088505,-1.5707963267948966,-35.03033173190502,0.6358953292626801 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark13(-10.409641276822754,-1.5707963267948966,-66.95240269439643,0.20540180117634232 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark13(-10.410655093123651,-1.5707964547513895,-101.77744266904138,-0.7760840341888766 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark13(-10.429646245940818,-1.5707963267948966,-5.072351805162551,1.9690480384193447E-18 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark13(-10.44649138424802,-1.5707963267948974,-84.66581241932536,-48.51041117745558 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark13(-10.50261586848419,-1.5707963267948966,1.1102230246251565E-16,32.5681555317562 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark13(-10.555761446505501,-1.5707963267948966,-12.902190907634127,-1.0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark13(-10.55703162363288,-1.5707963267948966,-33.84949739258471,-67.19789943997021 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark13(-1.0578585339507651,-1.5707963267948966,-83.86574426297426,-1.0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark13(-10.585328801547165,-1.5707963267948966,-67.14917960557833,87.12041441293634 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark13(-10.602470375894509,-1.5707963267948966,1.019340535306145,-49.35119090306137 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark13(-10.613380238173734,-1.5707963267948966,-66.05379226211237,1.0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark13(-107.2020240809712,-1.5707963267948966,-0.4644496262149216,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark13(-107.34812282104899,-1.5707963267949048,-127.35178647949218,-1.0000000000000009 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark13(-10.815046620400974,-1.5707963267948966,1.5707963267948966,-78.68053615725402 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark13(-10.834871423294581,-1.5707963267948966,-83.34901650159405,0.0904603412924805 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark13(-1.0861341223589136,-1.5707963267948983,-38.1143853837441,-0.08474305455402675 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark13(-1.0861886781107697,-1.5707963267948966,-2.4021795797687595,45.196055611560205 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark13(-10.867756292183191,-1.5707963267948966,-1.5707963267948968,0.5509199733122775 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark13(-10.893963648160707,-1.5707963267948966,-71.08723742083326,0.2034966829846847 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark13(-10.953444582905977,-1.5707963267948966,-29.845130209103036,0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark13(-109.72220897161759,-1.5707963267948966,-136.472311297976,0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark13(-11.000305597780194,-1.5707963267948966,1.570796326794881,0.30288583791453816 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark13(-110.01458448933555,-1.5707963267948966,-3.3146193299441062,2126.4108995233873 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark13(-11.003516085529789,-1.5707963267948966,-14.737186476471933,-81.74622814183695 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark13(-1.105003806967403,-1.5707963267948966,-86.43356601954484,0.36925285009812714 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark13(-11.14595546207941,-1.5707963267948966,-55.95553895379396,1.0561244620724224 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark13(-111.95644813200472,-1.5707963267949054,-136.28405476229267,8.958801870120662E-8 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark13(-112.08985378465411,-1.5707963267948966,0.14863309358449517,-1820.2877885915702 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark13(-11.215503469599042,-1.5707963267948966,-37.66594084559667,-2069.4826488833473 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark13(-112.99748272804125,-1.5707963267948966,-0.02402148099429884,-2122.384023039074 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark13(-11.32317307406148,-1.5707963267948966,-1.5707963267948966,-64.31258159695096 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark13(-1.147523431461746,-1.5707963267948966,-16.273212963463493,0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark13(-11.536692622756291,-1.5707963267948966,-93.68760188320641,1.0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark13(-11.549453143745831,-1.5707963267948966,-1.5707963267948948,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark13(-11.572587190251246,-1.5707963267948966,-4.943073279030919,3.186869567957171 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark13(-11.57691100548963,-1.5707963267948966,-0.5532132287561803,-5.770611636116085E-129 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark13(-1.166429933800307,-1.5707963267948966,14.429261861846278,0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark13(-11.685433824015327,-1.5707963267948983,-31.169852431220974,15.10890882894747 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark13(-11.69138333778703,-1.5707963267948948,-57.2325291184641,1.0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark13(-117.3138581189991,-1.5707963264926765,-135.29129802570844,0.3070010303351837 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark13(-117.68930403666005,-1.5707939188111562,-169.15164961681307,-1.027825501695159 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark13(-11.825360565495739,-1.5707963267948966,1.5707963267948966,-0.6775885832559476 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark13(-11.930277296911047,-1.5707963267948966,-16.157392731949297,0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark13(-11.97305754984739,-1.5707963267948966,-1.5707963267948966,-0.07890151892544983 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark13(-11.974499424952048,-1.5707963267948966,-15.844731991797076,0.8930389946480437 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark13(-12.034730394144251,-1.5707963267948966,-0.5009008282206215,-1.0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark13(-12.165187484216217,-1.5707963267948966,-37.20172963817815,-1.778206999588062E-161 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark13(-122.14342123309001,-1.570796326795073,-124.92192820414687,-0.9024374977185492 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark13(-12.21523087491496,-1.5707963267948983,-100.0,-0.04881533616351032 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark13(-12.266348442409093,-1.5707963267949,-6.633057147068632E-15,-89.34044223906261 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark13(-1.2337928803737843,-1.5707963267948966,-68.76593546829243,0.009449427717701048 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark13(-12.36641456747472,-1.5707963267948966,-42.091778189804565,0.06217700420212856 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark13(-12.392088829112916,-1.5707963267948966,-0.5701475814886213,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark13(-12.426313978421359,-1.5707963267948966,0.37714603298410715,0.05394169517755906 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark13(-12.458731093203042,-1.570796326794893,-14.522023369571773,-1.0000000179418926 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark13(-12.463076996532106,-1.5702140837933904,-142.54662095531606,-1.7609671391353775E-10 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark13(-1.2519337804060058,-1.5707963267948983,-1.5707963267948903,-3.5257150932347656 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark13(-12.566065493533836,-1.5707963267948966,0.0,0.8311238057251169 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark13(-12.599365369044506,-1.5707963267948966,-11.98643650741316,70.80355395016545 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark13(-12.603259996569545,-1.5707963267948948,-65.26182254633193,0.6177528092289872 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark13(-1.2635002738000516,-1.5707963267948966,0.7173534844489304,-1.277709663386068 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark13(-12.664245575630694,-1.5707963267948966,-60.68756434516709,-32.97938322618705 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark13(-1.2678238377549764,-1.5707963267948966,-72.86415440762828,-1.0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark13(-12.752777783813203,-1.5707963267948966,-95.84660585503454,-24.12042539305612 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark13(-127.616537973699,-1.5707948738563162,-122.85776721237666,-0.00949513697561366 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark13(-129.06241760680777,-1.5707963267948966,-90.23004518080694,-2388.144742228484 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark13(-12.96610747790642,-1.5707963267948966,-86.76106663333971,0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark13(-13.100146243186275,-1.5707963267948957,-99.00958216782664,-0.05216970392502007 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark13(-13.332183435391569,-1.5707963267948966,-22.096592789775343,-1.0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark13(-13.437223955879935,-1.5707963267948946,-1.5707963267948966,0.7055960359757492 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark13(-13.437456556629417,-1.5707963267948966,-5.980997270372906,1.0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark13(-13.457733222337758,-1.5707963267948966,-28.919529693260344,38.364652391580265 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark13(-13.527526466156878,-1.5707963267948966,0.0,0.0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark13(-13.538008391801945,-1.5707963267948966,-62.811186928471066,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark13(-13.553744107071722,-1.5707963267948966,-6.429900619629696,1.0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark13(-136.6235191858385,-1.5707963267948974,3.552713678800501E-15,-2294.6795643471396 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark13(-13.671495101576465,-1.5707963267948966,-61.8375909087148,5.5911723137417575E-6 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark13(-13.68806400777877,-1.5707963267948966,-87.71947197041891,-0.277704203836335 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark13(-13.6917088246224,-1.5707963267948966,-1.5707963267948966,-0.9999999999999996 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark13(-13.898899075374757,-1.5707963267948966,-53.62992454592818,-1.0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark13(-13.942860634787515,-1.5707963267948966,-1.5707963267948966,63.84669700411341 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark13(-13.994617745008249,-1.5707963267948912,-73.82742735936014,-100.0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark13(-1.3995696688876098,-1.5707963267948966,1.5707963267948912,-1.0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark13(-140.04150544491804,-1.5707963267948966,-3.9995590818939806,100.0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark13(-14.034711967892077,-1.5707963267948966,1.5707963267948966,-0.9981355697350437 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark13(-14.039085796333623,-1.5707963267948966,0.0,0.0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark13(-14.10842443665675,-1.5707963267948966,-100.0,-0.004229511080629704 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark13(-14.110125709596495,-1.5707963267948966,-17.635744981362077,-53.25904563300524 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark13(-1.4140887250229786,-1.5707963267948966,-73.6845384144026,0.36388707746655946 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark13(-1.4205827899853576,-1.5707963267948966,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark13(-14.207622320567499,-1.5707963267948966,-89.94342313393103,0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark13(-14.256596058275683,-1.5707963267948966,-9.467962330794176,-0.3778596194082565 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark13(-14.28069832772552,-1.5707963267948966,0.0,-0.034894666667566465 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark13(-14.281282762091932,-1.5707963267948961,-9.670511471910267,100.0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark13(-14.307194390627728,-1.5707963267948966,-4.269513755000546,-1.0000032070318958 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark13(-14.341778141914503,-1.5707963267948966,1.5707963267948966,-2185.160096596918 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark13(-14.416033613445634,-1.5707963267948966,-72.53215008603692,77.28729003223845 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark13(-144.18959958294857,-1.5707963267948983,-111.50425680599358,0.0023603414021464318 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark13(-14.447956701705719,-1.5707963267948966,-1.5707963267948983,-2060.1116677352884 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark13(-14.476272251618784,-1.5707963267948966,0.9738367863821971,1.0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark13(-14.56338097683468,-1.5707963267948963,1.5707963267948963,-1.0002166807309738 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark13(-14.60347673981272,-1.5707963267948966,-69.00001903447941,-1.0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark13(-14.665535823051433,-1.5707963267948966,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark13(-1.4727170353449517,-1.5707963267948966,1.1102230246251565E-16,-1.0000000000000004 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark13(-14.734737942378443,-1.5707963267948966,-39.45541036075155,-0.2816794932176252 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark13(-14.79450027587697,-1.5707963267948912,-66.28966250107864,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark13(-1.4831395353969543,-1.5707963267948966,-36.13761074406884,0.0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark13(-14.837624103442579,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark13(-149.49891067654394,-1.5707963267948966,-1.5707963267948961,2308.4716873179796 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark13(-14.991938994588546,-1.5707963267948966,-1.5172283530069026,-20.887535258827636 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark13(-14.992140862250992,-1.5707963267948948,-7.855344882123937,62.86066597079294 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark13(-15.127011833665762,-1.5707963267948983,-58.27135709928114,1.0000000000000009 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark13(-15.149612047989702,-1.5707963267948983,0.0,0.6261893355005592 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark13(-15.192237038312896,-1.5707963267948966,-5.678245538451506,-1.0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark13(-1.5193488273890268,-1.5707963267948966,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark13(-15.265697754809906,-1.5707963267948966,-34.969253889845625,24.751611408684212 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark13(-15.358764023026845,-1.5707963267948966,-39.7966017478321,1.000000107054895 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark13(-15.422895757530894,-1.5707963267948966,0.0,1.0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark13(-15.531931509370779,-1.5707963267948966,0.0,-1.0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark13(-15.562725070217265,-1.5707963267948966,0.0,-81.48249266736609 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark13(-15.618431081110035,-1.5707963267948983,-76.67744061205785,-1.0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark13(-15.628153860400232,-1.5707963267948966,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark13(-15.668900598587783,-1.5707963267948966,-58.08678393849345,-0.035253829356233515 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark13(-15.679676596824606,-1.5707963267948966,1.1812038839748342,-1.0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark13(-157.5866373445933,-1.5707963267948983,-1.5707963267948948,2245.8311263473165 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark13(-15.763401981321474,-1.5707963267948966,-72.54788314591927,0.5690337681971078 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark13(-15.858429864817746,-1.5707963267948966,0.48859848051875565,1.232595164407831E-32 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark13(-15.861934571829904,-1.5707963267948966,-1.5482696091801242,0.8312937686927193 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark13(-15.928043765190086,-1.5707963267948966,-26.414051113228716,-1.0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark13(-16.025771807397817,-1.5707963267948948,0.0,0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark13(-16.05432882978073,-0.5707074566795473,0,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark13(-16.06204592900849,-1.5707963267948966,-0.0011390578388422615,96.21186902398706 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark13(-16.12359013673921,-1.5707963267948966,-1.9599843957286396,-0.9999999999999996 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark13(-16.14735161492668,-1.5707963267948966,-7.115920058781319,6.938893903907228E-18 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark13(-16.253022475016845,-1.5707963267948966,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark13(-1.6271609898051143,-1.5707963267948966,-75.99921340149064,-0.16015600194847224 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark13(-16.31341720727577,-1.5707963267948966,0.4371774027958906,0.06168263762369701 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark13(-16.33380395916175,-1.5707963267948966,-33.80492746331318,-0.4350875532410118 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark13(-16.446308293119216,-1.5707963267948966,-1.5707963267948966,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark13(-16.452486790512996,-1.5707963267948966,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark13(-16.538216087688863,-1.5707963267948966,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark13(-16.5427691393462,-1.5707963267948966,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark13(-16.713650096981368,-1.5707963267948966,0.0,-93.72060658525699 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark13(-16.754540039898245,-1.5707963267948966,-57.58457311416589,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark13(-16.758352661394923,-1.5707963267948966,-0.13382232607760536,0.0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark13(-16.775351845076884,-1.5707963267948966,-71.5395796074344,-2353.197370923077 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark13(-16.82454684871648,-1.5707963267948966,-36.44483611029339,0.2605596604424085 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark13(-16.87400085699046,-1.5707963267948966,-20.08199178750395,0.0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark13(-16.8831906097796,-1.5707963267948966,-58.29563819936337,-77.6369830885466 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark13(-16.8925921951665,-1.5707963267948966,-66.35824385803986,1.734723475976807E-18 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark13(-16.938046687204846,-1.5707963267948966,-54.62174137732766,-1.0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark13(-169.56943917169497,-1.5707963267948966,0.7448903458900604,-97.05656572337773 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark13(-170.58176974488111,-1.5707963267948966,-78.0840250093244,2136.2529934228987 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark13(-17.078307724433213,-1.5707963267948966,-12.087411996287447,1.0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark13(-1.7091081652095588,-1.5707963267948966,-0.03364004102372775,-34.646241307467065 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark13(-17.097066022906546,-1.5707963267948966,-1.5707963267948966,-16.221238848243978 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark13(-17.158535812357112,-1.5707963267948966,-95.09565479297125,-0.978447490194873 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark13(-17.18473726031159,-1.5707963267948966,-29.0776645711827,28.679652513491074 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark13(-17.235426398690986,-1.5707963267949059,0.0,1.0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark13(-1.7310008462639233,-1.5707963267948966,0.06871024710410578,-0.4628800138935075 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark13(-175.1173505519143,-1.5707963267948948,-129.83000713800996,98.70801321086483 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark13(-17.558434365769926,-1.5707963267948966,-1.5707963267948968,0.05724589095719651 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark13(-1.757403111581696,-1.5707963267948966,-24.041111433400992,-0.9999999999999991 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark13(-17.650091415188612,-1.5707963267948966,-85.66790239003979,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark13(-17.67634769659246,-1.5707963267948966,-78.13540363897002,-19.070376382240482 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark13(-17.691314931342262,-1.5707963267948966,0.0,-43.89860322527098 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark13(-17.74097173985063,-1.5707963267948966,-61.83867360777659,-0.980678728056927 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark13(-17.761496043954374,-1.5707963267948966,1.5707963267948966,-0.10887221508193372 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark13(-177.78171232804658,-1.5707963267948983,-33.808141394888864,-2309.2888848333682 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark13(-17.79282682689877,-1.5707963267948983,-4.440892098500626E-16,5.201033613905576 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark13(-17.890858854668313,-1.5707963267948966,-28.112719311682028,1.0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark13(-17.95871680085847,-1.5707963267948966,0.0,-0.0519978830693229 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark13(-18.00941373429083,-1.5707963267948966,-83.22023495807949,-1.0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark13(-1.80771997670186,-1.5707963267948966,-0.12852807632158889,-14.865364621038811 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark13(-18.093138330623287,-1.5707963267948966,-62.07231693583395,-0.06255358562579004 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark13(-18.09564449798843,-1.5707963267948966,-10.948575371057638,-1.0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark13(-18.125163312410624,-1.5707963267948966,0.0,-1.0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark13(-1.8176048566333236,-1.5707963267948974,-49.57476537795653,-0.3568295422077212 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark13(-18.177682893007624,-1.5707963267948983,-14.575577614567933,0.02663289017627843 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark13(-18.249386335182777,-1.5707963267948966,-20.717606549549636,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark13(-1.827853591227408,-1.5707963267948966,-49.360085395111234,1.0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark13(-18.357082056819294,-1.5707963267948966,-65.2899778036213,1.0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark13(-18.51328362447737,-1.5707963267948966,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark13(-18.78333219739676,-1.5707963267948966,-46.643857029399,-0.9888273509145619 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark13(-188.39218159459278,-1.57079632684902,-188.02465742594225,-55.01860248821441 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark13(-18.849088618516348,-1.5707963267948966,-1.5707963267948966,-5.2238033488281275 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark13(-18.86315952402137,-1.5707963267948966,-0.010400174858674019,-2.2120569916088293 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark13(-18.870829286319292,-1.5707963267948966,-0.5120646972544055,-20.121141157301274 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark13(-18.89680859814544,-1.5707963267948966,-61.47955057189216,-1.0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark13(-18.920876473277552,-1.5707963267948966,-1.5707963267948966,-0.02773618712587439 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark13(-19.061779390469965,-1.5707963267948966,-1.5707963267948966,0.9999999999999991 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark13(-1.915187680691496,-1.5707963267948966,-87.40989526840768,0.5144183811571904 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark13(-19.243089181320045,-1.5707963267948966,-48.71078811745514,-0.23990609950702435 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark13(-19.26857952971976,-1.5707963267948966,0.0,-0.23534197931539286 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark13(-19.271183892999534,-1.5707963267948983,0.0,-0.9999999999999964 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark13(-1.929490129527963,-1.5707963267948966,-37.30767514346114,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark13(-19.304352618927332,-1.5707963267948966,-18.584893541065938,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark13(-19.353406988153555,-1.5707963267948966,-58.238095058216125,-0.8843848532637505 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark13(-1.9413284386255438,-1.5707963267948912,-73.47935005699742,1.0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark13(-1.94708244987159,-1.5707963267948895,-1.5707963267948966,-5.583966518942301E-15 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark13(-19.541262446186813,-1.5707963267948966,-58.41970462870837,-0.5478906917646968 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark13(-19.60547629866238,-1.5707963267948966,-32.225134101321316,1.0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark13(-19.608040469842432,-1.5707963267948966,-1.5707963267948983,-0.4772896824816136 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark13(-19.668650196306483,-1.5707963267948966,-14.003550861451501,0.05163803568533165 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark13(-19.67742080461367,-1.5707963267948966,-14.429827951805564,-0.2698658958651379 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark13(-19.678772041736153,-1.5707963267948966,-0.2169613672617362,-2.1521484275529117 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark13(-19.743219986194887,-1.5707963267948966,-88.01218054546999,-1.0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark13(-19.819505670500067,-1.5707963267948966,-94.80562742062303,82.38433869519463 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark13(-19.85415680801929,-1.5707963267948966,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark13(-19.877350286167527,-1.5707963267949023,-136.38068639031707,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark13(-199.48729834060092,-1.5707963267948966,1.5707963267948966,0.3622939763171924 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark13(-20.000179147423367,-1.5707963267948983,-45.665372357593604,-38.51016179631526 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark13(-20.009371738199633,-1.5707963267948966,-1.5707963267949197,-66.735588779135 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark13(-20.03599793363189,-1.5707963267948966,-51.892745205273,0.0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark13(-20.082208457408157,-1.5707963267948966,-1.5707963267948966,89.60965936347358 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark13(-20.196405815779364,-1.5707963267948966,0.7357225939581629,-2095.1663287646343 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark13(-20.204150382418543,-1.5707963267948966,-15.525286779814023,-44.90730239335037 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark13(-20.22399832224714,-1.5707963267948966,-0.5726363321019232,5.551115123125783E-17 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark13(-20.269805902869024,-1.5707963267948966,0.0,1.0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark13(-20.353527984389967,-1.5707963267948966,0.0,-1.0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark13(-20.36839276011855,-1.5707963267948966,1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark13(-20.389424505809075,-1.5707963267948966,-71.5263095661365,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark13(-2.0418749904704434,-1.5707963267948966,-17.330074172483556,-0.026293771727816495 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark13(-20.449549668368395,-1.5707963267948983,-19.256780367487323,-14.657944812683567 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark13(-20.46128778721453,-1.5707963267948966,1.5707963267948948,-0.9999999999999993 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark13(-20.534644322008642,-1.5707963267948966,-4.88993973450367,-0.0124886322351839 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark13(-2.0592725769468982,-1.5707963267948966,-0.5911038669158956,18.93460529224931 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark13(-2.06037389512678,-1.5707963267948966,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark13(-20.617397722135674,-1.5707963267948966,-0.832232335301966,0.9989316626722154 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark13(-20.661890374228648,-1.5707963267948966,-23.868209992049728,-2194.4395786696714 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark13(-20.66949550603436,-1.5707963267949054,0.6192567089209365,-0.6428742616051035 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark13(-20.67119176278365,-1.5707963267948966,-78.2615401375691,0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark13(-2.067699455060441,-1.5707963267948966,0.8866851828670962,3.2033329522929615E-145 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark13(-20.691592641322615,-1.5707963267948983,-8.906680173737207,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark13(-20.782839812879814,-1.5707963267948966,9.013186587367147E-4,0.006723562715823972 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark13(-20.800895521525053,-1.5707963267948966,0.0,71.58336400074444 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark13(-20.917870888515296,-1.5707963267948966,-35.97130272082342,0.2843112926783474 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark13(21.044496540642015,-57.817186275012176,85.20365424442946,0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark13(-21.049191199070265,-1.5707963267948966,-100.0,-33.327868547005394 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark13(-21.181013876490802,-1.5707963267948966,1.2371867807921152E-15,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark13(-21.217331467235322,-1.5707963267948966,-1.5707963267948963,-1.0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark13(-21.297748480594404,-1.5707963267948983,-92.18824937932872,-1.0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark13(-21.391116833980103,-1.5707963267948983,-23.56194490192345,0.0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark13(-21.458949259169408,-1.5707963267948966,-58.3212802968136,37.135147866008154 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark13(-2.155281668448275,-1.5707963267948966,-55.07136594016739,-0.6762111898936034 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark13(-21.604464478133213,-1.5707963267948966,-1.5707963267948966,0.05683925496097129 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark13(-21.68594036407188,-1.5707963267948966,-82.68108642670111,1.0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark13(-21.78530039452994,-1.5707963267948966,-9.802877273787626,-27.816024243729075 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark13(-21.81912223310432,-1.5707963267948966,-49.66562877668038,1.0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark13(-2.1829593345382037,-1.5707963267948966,-0.4773430873404242,-100.0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark13(-21.831406317632712,-1.5707963267948966,-0.22551319176060375,17.535480788314345 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark13(-21.91696100101306,-1.5707963267948966,0.0,-45.548560934014795 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark13(-21.931829616076442,-1.5707963267948966,-4.598816932495593,-1.0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark13(-21.990323671973563,-1.5707963267948966,-1.5707963267948966,46.64777787989494 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark13(-21.99904612678994,-1.5707963267948966,0.5915902908445713,0.780809896544999 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark13(-22.006032124939367,-1.5707963267948966,-9.605403277180613,40.168449166883164 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark13(-22.21220464150112,-1.5707963267948966,-67.40455671720382,-11.288031954495413 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark13(-22.21346501041231,-1.5707963267948966,0.39167511685638245,48.734477521631405 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark13(-22.24468780044899,-1.5707963267948983,-88.02314489436324,-55.302323856779545 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark13(-22.275962579520385,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark13(-22.290316818630203,-1.5707963267948966,0.36716498884434046,1.0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark13(-22.31755308705844,-1.5707963267948966,-9.98583758677249,-1.0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark13(-22.35941901323561,-1.5707963267948966,-91.71548607251916,-2289.3423220857517 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark13(-22.414419685683136,-1.5707963267948966,-0.10850385304739578,0.18299770163426987 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark13(-22.46942836295333,-1.5707963267948966,-29.878266233387237,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark13(-22.600324865792416,-1.5707963267948966,-60.77001500366365,-6.795989681990349 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark13(-22.620037603218684,-1.5707963267948966,-64.80531231023953,-1.000000002030618 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark13(-2.2623432953832747,-1.5707963267948966,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark13(-22.683637744746733,-1.5707963267948966,-15.134850447842979,-0.9999999999999988 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark13(-22.804561691844377,-1.5707963267948948,-1.5707963267948968,-54.47212512549288 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark13(2.281214114644058,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark13(-2.2851626247741867,-1.5707963267948966,0.0,-0.0051148657987610535 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark13(-22.854730989130275,-1.5707963267948966,-1.2517837275892356,1.3177747429038154E-82 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark13(-22.89545360819047,-1.5707963267948983,-0.23947905029429528,-2.188400451283086 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark13(-23.12084025151515,-1.5707963267948966,-100.0,-1.0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark13(-23.16151397814901,-1.5707963267948966,-67.46425375441181,-31.85994094353707 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark13(-23.324467635882883,-1.5707963267948966,-1.5707963267948966,71.49271948300847 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark13(-23.335145929350425,-1.5707963267948966,0.0,-0.3226968893090695 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark13(-2.351217301377236,-1.5707963267948966,1.5707963267948966,58.24051487718589 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark13(-23.594910552520325,-1.5707963267948966,0.1678237478875061,-30.38115103158157 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark13(-23.61619162510513,-1.5707963267948966,-33.593151573112536,0.0407434391063152 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark13(-23.64020596713496,-1.5707963267948966,-15.755272548532389,-1.5904349130553375E-14 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark13(-23.65121078409453,-1.5707963267948983,-107.50571210286755,0.8680251939244314 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark13(-23.6964783819062,-1.5707963267948966,0.0,-49.34355956771351 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark13(-2.374018525580259,-1.5707963267948968,-54.171884676481355,-1.0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark13(-23.79907211589647,-1.5707963267948966,-58.519558890592265,1.0000000000000018 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark13(-23.84384626841954,-1.5707963267948966,-1.5707963267948966,-0.06172734507867686 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark13(-23.89354851093892,-1.5707963267948966,0.0,1.0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark13(-23.901536140671624,-1.5707963267948966,-9.275961589735193,-0.028365149492224864 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark13(-23.92344991968823,-1.5707963267948966,-20.989905941306695,-6.681911775230489E-52 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark13(-24.052666896188146,-1.5707963267948966,-73.5473356788489,1.0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark13(-24.06684801865664,-1.5707963267948966,-1.0011047164352573,0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark13(-24.133313300019076,-1.5707963267948966,-1.5707963267948966,6.834078261859208 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark13(-24.17172811649489,-1.5707963267948966,-18.52347550834768,-23.08053320428742 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark13(-24.20027061233678,-1.5707963267948983,0.0,0.04431235504364234 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark13(-24.31952012434501,-1.5707963267948983,-21.619541369163294,0.9079595296222861 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark13(-24.344385338443026,-1.5707963267948966,1.1548026221663301,-2.8161239569133176 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark13(-24.485281208777053,-1.5707963267948966,-66.38695070996074,1.0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark13(-24.5212899468929,-1.5707963267948966,-53.72711860393382,-0.529631551800839 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark13(-2.4575770986255576,-1.5707963267948966,-1.2518735954590725,0.7136406868860558 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark13(-24.65341345806935,-1.5707963267948966,-37.00371280990701,1.0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark13(-24.698975578973066,-1.5707963267948966,0.0,68.30135478928875 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark13(-2.4750554169426957,-1.5707963267948966,-1.5707963267948966,5.551115123125783E-17 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark13(-24.76209259355366,-1.5707963267948966,1.5707963267948948,51.42128523904242 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark13(-24.7831950747975,-1.5707963267948966,1.5707963267948966,-0.42677808158919406 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark13(-24.84760674381838,-1.5707963267948966,-45.577935519156355,0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark13(-24.87529485346152,-1.5707963267948966,-1.5707963267948966,-0.4823403487788138 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark13(-24.932250780555748,-1.5707963267948966,-17.29890123449178,1.0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark13(-25.07648058268326,-1.5707963267948966,-1.4527356487037006,-1.0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark13(-2.5129159492838626,-1.5707963267948966,-98.96016858807849,2.5988524414112248E-113 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark13(-25.13501498892658,-1.5707963267948966,-51.54527941016797,-31.372809424552774 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark13(-25.439688736052215,-1.5707963267948966,-14.915113846763717,-0.9482328350797944 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark13(-25.46873428450181,-1.5707963267949019,-64.10802513165274,-44.53095953446359 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark13(-25.51545154007729,-1.5707963267948966,0.0,79.21235445827476 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark13(-25.578186494486665,-1.5707963267948966,0.0,1.0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark13(-2.5617018923961776,-1.5707963267948966,1.1663016958524455,-51.851944760317025 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark13(-25.627798635036115,-1.5707963267948966,-21.628046453575905,88.56523634523955 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark13(-25.658533593368798,-1.5707963267948912,1.1490129307559065,1.0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark13(-26.01886898385313,-1.5707963267948966,0.3148884853779608,-1.0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark13(-26.03052950254805,-1.5707963267948966,0.27819689019678207,-0.01564582500486225 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark13(-26.050742705636935,-1.5707963267948912,-93.60948948735854,-0.8335862150147095 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark13(-26.10091877264437,-1.5707963267948966,-10.839532791725038,-4.135243853578991 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark13(-26.136892583023876,-1.5707963267948966,1.5707963267948961,100.0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark13(-2.623112149493621,-1.5707963267948966,-41.31881031179736,0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark13(-26.23244065015656,-1.5707963267948966,-1.5707963267948966,-1733.6482192320814 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark13(-26.25844168718836,-1.5707963267948966,0.0,11.248727213364536 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark13(-26.26463071896577,-1.5707963267948983,-89.12511515972653,-0.5301107219471106 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark13(-2.6299036397872824,-1.5707963267948966,-68.60138043337206,-1.0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark13(-26.432664682592534,-1.5707963267948966,-46.56235790813607,-0.8133200611807364 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark13(-26.467950170466878,-1.5707963267948966,-1.5707963267948961,1.0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark13(-26.47063526938276,-1.5707963267948974,-29.461558125478298,-1.0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark13(-2.657134947596349,-1.5707963267948966,1.2521695964518011,1.8926601708496396E-18 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark13(-2.6633068138969787,-1.5707963267948966,0.09298451593054935,-8.236092143148846E-84 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark13(-26.71033440625408,-1.5707963267948966,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark13(-26.806189237926034,-1.5707963267948966,0.0,67.3652041962939 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark13(-26.830324371795168,-1.5707963267948966,-65.41272799659416,-0.5027394317227714 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark13(-26.866211816859,-1.5707963267948966,-82.72635457906658,0.04751949487653199 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark13(-26.970558447506292,-1.5707963267948983,-41.47828601455279,77.41872642698414 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark13(-27.001188438589253,-1.5707963267948966,-89.24665544918065,-0.9842033388840956 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark13(-27.00689227989367,-1.5707963267948966,-1.5480236834323553,-2.509451847070626 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark13(-2.7018951438379477,-1.5707963267948966,0.3375165694859711,-0.06268977650111979 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark13(-27.13413922099124,-1.5707963267948966,-22.69639139082969,-0.9927944077004676 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark13(-27.229763947059183,-1.5707963267948966,-21.180014282888237,-96.60406554979323 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark13(-27.263332008971528,-1.5707963267948966,-46.59055679051269,-0.05120680255760738 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark13(-27.311395521393386,-1.5707963267948966,-38.01974867791984,-6.017469605035252E-17 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark13(-27.318110266971743,-1.5707963267948966,-66.28337660206785,5.852095443365248E-98 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark13(-27.332118575354443,-1.5707963267948966,-169.06938088573594,-0.3080483458119776 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark13(-2.734167110767021,-1.5707963267948966,-58.29377463441662,-51.24532797880356 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark13(-27.353365254994372,-1.5707963267948966,0.3318027651119419,66.67470941221457 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark13(-27.357711892155294,-1.5707963267948966,-91.57483754308981,1.0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark13(-27.3991416651391,-1.5707963267948983,-72.43891027223546,0.0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark13(-27.402422242790024,-1.5707963267948966,-71.54778149001723,0.0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark13(-27.414631694799482,-1.5707963267948966,-83.07248913316306,-1.0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark13(-27.416637735862167,-1.5707963267948966,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark13(-27.467015559101554,-1.5707963267948966,1.5707963267948966,0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark13(-27.47987395949618,-1.5707963267948966,-76.33524198888165,1.0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark13(-27.498814627301464,-1.5707963267948966,-50.15383739125906,78.75112781412976 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark13(-2.759610594611299,-1.5707963267948966,-1.5707963267948966,-0.5953146773638882 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark13(-27.631333572109174,-1.5707963267948966,1.3122694096028331,1.0000000000000013 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark13(-2.7646178622158377,-1.5707963267948966,-89.46934935380153,-0.7553299814308629 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark13(-27.899676484330485,-1.5707963267948966,-155.511142278325,-9.174492925094311 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark13(-27.906962418881687,-1.5707963267948966,0.0,-1.0000000000000002 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark13(-27.919120596291403,-1.5707963267948966,-14.614157111538482,-1.0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark13(-27.957965666904926,-1.5707963267948966,-65.60569373435467,0.36209904216661326 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark13(-27.971311553916003,-1.5707963267948966,-3.231568757421426,-1.0110678482279605 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark13(-28.01613451546748,-1.5707963267949,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark13(-28.070099105560963,-1.5707963267948966,-5.938112822724335,0.9038392883658771 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark13(-28.138756789217826,-1.5707963267948966,-83.29325063020079,6.776263578034403E-21 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark13(-28.144841611104,-1.5707963267948966,-0.45301990256248253,-72.64202612034116 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark13(-28.187562485143076,-1.5707963267948966,-52.979931321694984,-43.676614922675405 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark13(-28.27561682656689,-1.5707963267948966,-57.463514387376776,0.08180400575921434 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark13(-28.293209553871232,-1.5707963267948966,0.3567120468053192,0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark13(-28.302258833513665,-1.5707963267948966,0.0,-0.327374896684816 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark13(-28.497363529098507,-1.5707963267948966,-59.30178851152921,0.0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark13(-28.678491324187508,-1.5707963267948966,-72.3466613183474,-80.50727593900619 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark13(-28.687601610777232,-1.5707963267948966,-68.37922106885136,-0.1967516596671215 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark13(-28.75755105860027,-1.5707963267948966,1.9366539226519924E-17,-1.0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark13(-287.79509951636135,-1.57079632710815,-129.0413875396254,-79.04765432987988 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark13(-2.8821282164803055,-1.5707963267948966,-6.814074301136941,1.0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark13(-28.876823898381385,-1.5707963267948966,-1.5707963267948966,1.3234889800848443E-23 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark13(-28.877958699227015,-1.5707963267948966,0.0,0.06255259446254387 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark13(-28.87833042904255,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark13(-28.923598134443715,-1.5707963267948966,-1.5707963267948966,-1.9617970446523572E-16 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark13(-28.93735704077243,-1.5707963267948966,-1.5707963267948966,15.497100840269457 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark13(-28.96348275575278,-1.5707963267948966,1.7763568394002505E-15,0.6510776410533385 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark13(-28.99752718259448,-1.5707963267948966,-50.017422820242516,0.9999999999999996 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark13(-29.023851002195528,-1.5707963267948966,-31.294408832538622,0.8073601857155821 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark13(-29.062443592491416,-1.5707963267948966,0.0,1.0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark13(-29.149856184272707,-1.5707963267948966,0.0,0.9999999999999999 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark13(-29.23449027127036,-1.5707963267948966,-122.75749413388337,-1.882519474696382E-14 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark13(-29.25905468645193,-1.5707963267948966,-73.26856570981917,-0.031022673510576092 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark13(-29.33290792171493,-1.5707963267948966,-10.468638431155464,0.8685893496124102 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark13(-29.380454194144576,-1.5707963267948966,-22.334507103554905,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark13(-29.421301118532565,-1.5707963267948966,-84.80016425668786,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark13(-2.946080068133184,-1.5707963267948966,1.017441110526038,1.0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark13(-29.50201429086382,-1.5707963267948966,0.0,0.4099559128561481 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark13(-29.53254419345007,-1.5707963267948966,-61.632505661829555,0.4599875488960832 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark13(-29.55336072437095,-1.5707963267948966,-51.40035503105578,-22.0831940023854 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark13(-29.708909123989283,-1.5707963267948966,-55.567634276115925,48.9478550361103 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark13(-29.753809064543237,-1.5707963267948966,-0.9019357706442427,1.0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark13(-29.76358898296029,-1.5707963267948966,-18.689691225734975,36.39115938135197 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark13(-29.79166485419229,-1.5707963267948966,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark13(-29.80100658111334,-1.5707963267948966,-37.26592015916241,0.9730999652069041 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark13(-29.882157105267265,-1.5707963267948966,-81.71733549150453,1.0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark13(-2.9936757581256175,-1.5707963267948966,-58.259598496539276,1.0172232671827637 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark13(-30.038374295918775,-1.5707963267948966,0.002306602905381566,1.0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark13(-3.009884821084336,-1.5707963267948966,-68.16050274583773,95.26837805511582 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark13(-30.162873787230534,-1.5707963267948966,-15.820624924253337,0.05012732076246862 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark13(-30.198696921745203,-1.5707963267948966,-100.0,0.7161826311954756 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark13(-30.203198060714172,-1.570796326794897,-72.60175767655505,0.5176869004782507 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark13(-30.216123437396774,-1.5707963267948966,-1.5707963267948966,5.28777696945419 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark13(-30.248080763183182,-1.5707963267948966,-27.35681467379932,-86.72512268007418 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark13(-30.255712823110798,-1.5707963267948966,-43.19377558667844,0.36533910404875036 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark13(-30.262273042282885,-1.5707963267948966,-2.3830707221740363E-14,-2.1175823681357508E-22 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark13(-30.31475630958525,-1.5707963267948966,0.6850443153476107,-0.9833030484584605 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark13(-30.32466322908238,-1.5707963267948966,-61.72944741249714,-18.765991133879417 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark13(-30.331533223141065,-1.5707963267948966,-33.092329072189266,-1.0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark13(-3.0350475107180683,-1.5707963267948966,-2.80817293159381,-1.0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark13(-30.50975713856147,-1.5707963267948966,-79.4134074685014,0.0403825600120582 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark13(-30.557113616100864,-1.5707963267948966,-98.20984229258202,0.05016092833120526 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark13(-30.57470236166796,-1.5707963267948966,0.07667845098139892,-0.04745702263600693 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark13(-30.668312420031015,-1.5707963267948966,-56.59912923047784,-12.524334355420152 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark13(-30.81999174489666,-1.5707963267948966,0.006428732524435987,1.0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark13(-30.825123826206024,-1.5707963267948966,0.23865614851186445,75.07894168179143 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark13(-30.84317605250636,-1.5707963267948966,-57.93076776502757,0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark13(-30.900438413116575,-1.5707963267948966,-2.772960600262625,-9.984756524940428 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark13(-30.942474377981824,-1.5707963267948966,0.3357523708824413,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark13(-31.052843943906787,-1.5707963267948966,-53.928551858278624,-31.34663563818512 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark13(-31.074033974952975,-1.5707963267948966,-10.621586719458008,1.0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark13(-3.113380460797857,-1.5707963267948966,-60.996542142031494,1.0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark13(-31.18317799756716,-1.5707963267948966,-1.5707963267948983,-47.47241519984344 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark13(-31.19156588631694,-1.5707963267948966,-78.34509095611996,0.9380070717426895 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark13(-31.212320304428474,-1.5707963267948966,-77.98410838611636,49.178290702704814 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark13(-31.223349945066218,-1.5707963267948966,-84.72314859477596,0.0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark13(-31.23931860473054,-1.5707963267948966,0.0,-1.0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark13(-31.28165304585395,-1.5707963267948966,0.06354807760966712,-1.0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark13(-31.30178320116788,-1.5707963267948966,-60.71362785352791,-0.7833971005307797 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark13(-31.340401306593368,-1.5707963267948966,-100.0,-1.0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark13(-31.37010306981421,-1.570796326794897,-70.67672047266421,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark13(-3.1426715425625202,-1.5707963267948966,1.570796326791198,0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark13(-31.435000874662627,-1.5707963267948966,0.5329009282597088,-17.290704322911118 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark13(-31.561910940949723,-1.5707963267948966,-17.474373586007324,-69.73262716410665 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark13(-31.617940375901217,-1.5707963267948966,-42.41153445248418,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark13(-31.638379657289352,-1.5707963267948966,0.0,-0.8339840587994879 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark13(-31.63865196493575,-1.5707963267948966,-72.55629606319992,1.0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark13(-3.1684990052034476,-1.5707963267948966,1.0315870857226572,94.5153172054351 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark13(-3.1776640491646986,-1.5707963267948963,-80.4477843149751,0.0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark13(-31.802539383440177,-1.5707963267948966,1.5707963267948966,0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark13(-31.805514124978643,-1.5707963267948983,-1.089838173627868,-1.0000000000000009 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark13(-31.97510964983558,-1.5707963267948966,-0.4879119146093934,-95.89122882033239 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark13(-32.10481483502792,-1.5707963267948966,-74.15566877735246,-1.0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark13(-32.18170190134498,-1.5707963267948966,-7.853981633974483,0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark13(-32.233771450457354,-1.5707963267948983,-9.697434449898022,-22.940288309997726 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark13(-32.2844962817348,-1.5707963267948966,-0.20538381878091666,-19.778154720087514 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark13(-32.31552881470957,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark13(-32.33135102004441,-1.5707963267948966,0.4545903503764162,0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark13(-3.2339317236773084,-1.5707963267948966,0.0,-2.7251202771283687 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark13(-32.34402368342216,-1.5707963267948966,-6.21337883251806,0.06255341315101652 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark13(-32.35080614957978,-1.5707963267948966,-100.0,-4.2351647362715017E-22 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark13(-32.37294841521521,-1.5707963267948966,-100.0,0.06255279150917498 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark13(-32.41132752305744,-1.5707963267948963,-73.7803748628184,0.0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark13(-32.44323017770226,-1.5707963267948966,-82.1390928238817,-1.0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark13(-32.444414473806276,-1.5707963267948966,-2.265968648885813,5.551115123125783E-17 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark13(-32.48019792366121,-1.5707963267948966,-97.82631303133853,-1.0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark13(-32.520523237309206,-1.5707963267948966,0.3615638716734697,26.401264687289455 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark13(-32.549991426781546,-1.5707963267948966,-70.10806091376891,2043.9322509628003 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark13(-32.598410190037434,-1.5707963267948966,-67.26231292598345,-1.0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark13(-32.6036053316129,-1.5707963267948966,-1.5707963267948966,-0.03533831600367132 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark13(-32.63782815756825,-1.5707963267948966,1.5707963267948966,-44.85969588642258 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark13(-32.645744834268,-1.5707963267948966,-46.365494699701934,-1.0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark13(-32.71103927945511,-1.5707963267948966,-41.235537551034994,4.0171105538951934 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark13(-32.746641460604536,-1.5707963267948966,-58.32259113168689,-31.847370835400618 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark13(-32.80667477978458,-1.5707963267948966,-48.3956187701446,1.7691144903341454E-13 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark13(-32.83018145487282,-1.5707963267948966,-0.43619570500580324,-60.26761270872563 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark13(-32.85236124597586,-1.5707963267948966,-92.74855824900736,1.0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark13(-32.8989047199218,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark13(-32.97571274886217,-1.5707963267948983,1.5707963267948968,-1.0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark13(-3.2983463835050912,-1.5707963267948966,-6.5540008965241805,4.307569304404977 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark13(33.17812038879856,-41.12779296062901,-92.87302853995125,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark13(-33.19481597714038,-1.5707963267948966,-43.747940604249756,0.19724915019803713 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark13(-33.23034402432807,-1.5707963267948966,-1.986677155905923,-1.0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark13(-33.35867371256191,-1.5707963267948966,0.0,91.16089269951576 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark13(-33.38079318160902,-1.5707963267948966,-54.59481611423636,0.5914604786323079 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark13(-33.400212246790915,-1.5707963267948966,-96.34179219676801,-1.0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark13(-33.41436138206132,-1.5707963267948966,0.4651985826314641,-2064.8128951715125 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark13(-3.3440899427696635,-1.5707963267948966,-10.949667602462798,2.0679515313825692E-25 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark13(-33.509349949637325,-1.5707963267948966,-9.777104811587122,-0.05398396916308057 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark13(-33.603023089078505,-1.5707963267948966,1.4643450283746058,-1.0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark13(-33.70482694215643,-1.5707963267948966,-20.536219411212247,-46.470642051260384 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark13(-33.711527288149085,-1.5707963267948966,-0.8403200627121148,24.25790316723476 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark13(-33.74421630284215,-1.5707963267948966,100.0,0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark13(-33.808090100064746,-1.5707963267948966,0.6316724536121587,78.37113637128854 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark13(-33.86721438123874,-1.5707963267948966,-0.8229332020931732,1.0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark13(-33.951162959226764,-1.5707963267948966,-0.3450051934344147,0.7506261091629439 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark13(-33.97748646843398,-1.5707963267948966,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark13(-33.981904226850695,-1.5707963267948966,0.0,100.0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark13(-33.98333839913028,-1.5707963267948934,-1.5707963267948966,-1.917070238790858E-15 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark13(-34.06890266664174,-1.5707963267948966,-72.39183229338354,-79.5264171851135 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark13(-34.17219991068764,-1.5707963267948966,-10.954558984853485,1940.837738502946 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark13(-34.205704521640975,-1.5707963267948966,-0.32903746438155773,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark13(-34.22201243713072,-1.5707963267948966,-3.1915081559842995,-0.0051538929436759084 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark13(-34.26625320496224,-1.5707963267948966,-5.274455530233742,-55.66619228272452 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark13(-34.30048385631311,-1.5707963267948966,0.0,-72.66162844554711 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark13(-3.4328106051012544,-1.5707963267948966,-3.801173611662432,-9.318272995006746 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark13(-3.434917700400705,-1.5707963267948966,-67.96400284298947,-0.6730116615556065 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark13(-34.37871722474361,-1.5707963267948966,0.1947122624299169,0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark13(-34.3844836493048,-1.5707963267948966,-1.5707963267948961,46.602864312753795 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark13(-3.4405838175299293,-1.5707963267948966,-30.581280613593073,-1.8183792357914186 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark13(-34.667488532372396,-1.5707963267948966,0.0,2.5026038689788762E-147 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark13(-34.690316800164126,-1.5707963267949054,0.19680940287356918,53.62962549844258 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark13(-34.72358777246178,-1.5707963267948966,-24.09650017938516,1993.9445408742 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark13(-34.723875580514694,-1.5707963267948966,-100.0,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark13(-34.753089697776154,-1.5707963267948966,-67.91078090352622,1.0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark13(-34.77801477031588,-1.5707963267948966,-50.74888015242123,-7.618788491029061 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark13(-35.07765192431939,-1.5707963267948966,-64.02354165271139,-1.0670765283638353 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark13(-35.08422026577771,-1.5707963267948963,-67.10797747158725,0.46774508883211874 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark13(-35.12374022013392,-1.5707963267948966,-66.04460764517114,16.65997441563067 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark13(-35.12673184424585,-1.5707963267948954,-82.81961415200936,1.0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark13(-35.15182853083003,-1.5707963267948966,1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark13(-35.1890393575824,-1.5707963267948966,0.0,1.0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark13(-35.238677863896854,-1.5707963267948966,-58.52785333606248,1.0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark13(-35.25004284859264,-1.5707963267948966,-41.10190534323727,-18.167505001589753 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark13(-35.278814286554734,-1.5707963267948966,-1.5707963267948912,-1.0000000057179224 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark13(-35.30982214885265,-1.5707963267948966,-10.794485320849908,-1.000000007887781 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark13(-35.32837516120312,-1.5707963267948966,-1.5707963267948966,-0.9999999999999998 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark13(-35.37849763703901,-1.5707963267948966,2500.010857497421,0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark13(-35.48230158206316,-1.5707963267948966,1.3810930516158333,-97.86951426869271 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark13(-3.5491679920616033,-1.5707963267948983,-76.28275426352289,1.0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark13(-3.550975484940666,-1.5707963267948966,-1.5707963267948966,-18.237719775308374 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark13(-35.56104330431287,-1.5707963267948983,-73.44271025250941,-1.0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark13(-35.65462485158749,-1.5707963267948968,0.0,16.74087873623554 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark13(-35.78654871797977,-1.5707963267948966,-46.16114071279158,0.6442594977884042 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark13(-35.79114985292484,-1.570796326794886,0.16873191809711216,0.0024696212775902615 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark13(-35.81182003030662,-1.5708416637118379,-2.817651704559418,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark13(-35.83930816150745,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark13(-35.91202040538557,-1.5707963267948966,-0.032334335308520826,-17.469389262924384 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark13(-3.593596077836774,-1.5707963267948966,-100.0,-0.06357928121712308 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark13(-3.5956971878052126,-1.5707963267948966,-1.5707963267948966,20.730903694177577 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark13(-36.066285620856355,-1.5707963267948966,-0.012960006057336132,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark13(-36.0948645103297,-1.5707963267948966,-13.105148278326688,-1.0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark13(-36.243703358553056,-1.5707963267948966,1.3741972980504964,-0.007983306797209433 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark13(-36.25101236393928,-1.5707963267948966,-34.88076121907136,-0.7843818580215083 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark13(-36.27353647334351,-1.5707963267948948,-53.80871303829389,-89.82738714217695 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark13(-36.30009237962768,-1.5707963267948966,-35.69359579012462,-0.030781065715063144 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark13(-36.337317218644955,-1.5707963267948966,-64.44266069134699,0.5794800295809889 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark13(-36.540650024136944,-1.5707963267948966,0.241702610857237,1.0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark13(-36.88280966002884,-1.5707963267948966,-1.4904527932580445,1.0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark13(-3.6927268874662253,-1.5707963267948966,0.0,1.0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark13(-36.98530264136464,-1.5707963267948966,0.0,69.2848089673608 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark13(-37.054793971331904,-1.5707963267948966,-32.37699294523834,1.0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark13(-37.06919513231622,-1.5707963267948966,-1.5707963267948966,-54.30145763084013 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark13(-37.08444998772548,-1.5707963267948966,0.9180428486477906,-0.9999999999999999 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark13(-37.14238072808201,-1.5707963267948966,0.0,-1.0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark13(-37.25411736164677,-1.5707963267948963,-73.61523419450067,0.36210062678795224 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark13(-3.726692922260606,-1.5707963267948966,-1.5707963267948966,1.0205438929413688E-16 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark13(-3.7278102995830706,-1.5707963267948966,-78.07800720866528,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark13(-37.355387623560816,-1.5707963267948966,-82.1713083482191,-0.4272873699042572 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark13(-37.4263809304294,-1.5707963267948966,-23.56194490192345,0.0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark13(-37.510192692875684,-1.5707963267948966,-46.664752041579966,-1.0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark13(-37.54056327776793,-1.5707963267948966,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark13(-37.582262280937016,-1.570796267179695,-122.90356085811932,-0.06067699764204758 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark13(-37.67975466291264,-1.5707963267948966,-1.5707963267948948,0.013789223688487479 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark13(-37.742203054071204,-1.5707963267948966,-71.53678559024158,43.223491729740836 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark13(-37.75991436902808,-1.5707963267948966,-28.121828298417256,-78.93507603565853 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark13(-37.800801727712454,-1.5707963267948966,-0.07178933794959533,-84.92966977762416 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark13(-37.835444907406426,-1.5707963267948966,-1.5707963267948966,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark13(-37.8373210009433,-1.5707963267948968,-50.674776629589914,-0.7206747686583063 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark13(-37.87432670440432,-1.5707963267948966,-35.02285405681989,0.9999999999999999 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark13(-37.94196284346002,-1.5707963267948966,-47.78071877993331,-48.53398434669751 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark13(-3.8009984527850267,-1.5707963267948966,-1.5707963267948966,0.7213170444306305 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark13(-38.064441220261735,-1.5707963267948966,-1.7763568394002505E-15,1.0000000016446322 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark13(-38.11004023259841,-1.5707963267948966,-40.601234030504514,-1.0000000000000426 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark13(-38.28825745611705,-1.5707963267948966,-8.524346372994394,0.02752185882159386 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark13(-38.3706607169795,-1.5707963267948961,0.0,-2286.574457806252 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark13(-38.37351347641576,-1.5707963267948966,0.0,-0.8851877408299712 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark13(-38.377944263019906,-1.5702088328392434,-123.94581042684999,1.0323824814185532 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark13(-38.40594158833998,-1.5707963267948966,-59.73394176394839,-0.7357026025821062 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark13(-38.428765577796796,-1.5707963267948966,-56.60563616534482,0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark13(-38.73448551372986,-1.5707963267948912,-5.262735593073258,-2248.817667043143 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark13(-38.95061114651182,-1.5707963267948966,-91.3090641415342,-81.17643727144959 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark13(-38.967772737795976,-1.5707963267948966,0.0,0.5645794634238355 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark13(-3.9059966201058893,-1.5707963267948966,-1.042631085308015,-0.9081267490615991 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark13(-39.08775640035858,-1.5707963267948912,-37.100071106547354,1.0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark13(-39.127486488977034,-1.5707963267948966,-99.39022506323647,5.59841922086445 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark13(-39.16126703229388,-1.5707963267948966,0.17125800765035337,1.000000106621363 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark13(-39.17692127497739,-1.5707963267948966,-29.634840565279276,1.0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark13(-39.24384272044743,-1.5707963267948966,-1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark13(-3.924503758993057,-1.5707963267948966,0.13011384585449548,1.0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark13(-39.30960174034305,-1.5707963267948966,-0.2707135887272341,-1.0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark13(-39.368549380145964,-1.5707963267948983,-1.5707963267948966,0.2085021142889718 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark13(-39.40616916024924,-1.5707963267948966,1.5412786103707177,-0.9999999999999996 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark13(-3.950857043254266,-1.5707963267948966,-19.42851391130604,-0.2918338419076929 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark13(-39.59035592746416,-1.5707963267948966,-99.99999999999997,1.0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark13(-3.9602773513499074,-1.5707963267948966,-84.4299778749536,-1.0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark13(-39.61067848086415,-1.5707963267948966,1.5707963267948966,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark13(-39.63571605821901,-1.5707963267948966,-0.9394956214598352,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark13(-39.74313334484444,-1.5707963267948966,-1.5707963267949054,-0.2582035564532811 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark13(-39.747679592170115,-1.5707963267948966,-48.368111118190065,-20.483811418007413 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark13(-39.780111275580836,-1.5707963267948966,-39.91943710969981,31.474255630157977 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark13(-39.8107359838851,-1.5707963267948966,-62.195340635407526,20.268322234100978 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark13(-39.90043662421901,-1.5707963267948966,0.0,44.80216662498265 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark13(-39.90269264750287,-1.5707963267948966,-49.52087459631099,-68.12664685885724 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark13(-40.127669266389866,-1.5707963267948966,0.0,0.9999999999999982 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark13(-40.129096114570864,-1.5707963570559236,-155.28369054233124,-1.0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark13(-40.167845417450096,-1.5707963267948966,-1.5707963267948966,58.45125287160869 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark13(-40.18379085100298,-1.5707963267948966,-15.728730223981756,-0.7099182541331235 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark13(-40.24322246076706,-1.5707963267948966,-0.4865462113954617,-2150.5470793304485 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark13(-40.25666913607193,-1.5707963267948966,-97.10662529365462,0.9972876314632151 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark13(-40.26594750525071,-1.5707963267948966,-1.5707963267948966,-0.9999999999999992 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark13(-40.483210998518395,-1.5707963267948966,0.12110067977683414,-1.0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark13(-4.058492970100426,-1.5707963267948966,0.0,0.0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark13(-40.58692792137407,-1.5707963267948966,1.5707963267948966,-3.6011740125029164 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark13(-40.60051731713222,-1.5707963267948966,1.5707963267948963,-0.9803857213518654 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark13(-40.61766118891462,-1.5707963267948966,-30.9624717836077,-0.4524536636787526 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark13(-40.633111445541324,-1.5707963267948966,-1.5707963267948966,0.999999999999998 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark13(-40.71987598697659,-1.5707963267948966,-14.13952997752881,-0.04275711045715169 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark13(-40.7640005395271,-1.5707963267948966,-1.5707963267948966,31.256435115505596 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark13(-40.996744576630554,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark13(-41.04621687943508,-1.5707963267948983,-101.83759008910948,55.174552128833994 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark13(-41.07721417774354,-1.5707963267949,0.0,-1.0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark13(-41.18795360429415,-1.5707963267948912,-7.105427357601002E-15,49.97713371392817 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark13(-41.20737741658926,-1.5707963267948966,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark13(-41.44460785654625,-1.5707963267948966,-0.8838525014975005,1.0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark13(-41.496110996797846,-1.5707963267948966,-83.7008821356934,0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark13(-41.534056831343854,-1.5707963267948966,-3.2813140663250616E-15,1.0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark13(-41.54773430005014,-1.5707963267948966,-36.125516835441005,-11.718331750867437 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark13(-4.181978186329427,-1.5707963267948966,-5.389471308419577,-2.1175823681357508E-22 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark13(-41.82203734138296,-1.5707963267948966,-0.9086992045331467,-61.117750815887064 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark13(-41.860247267964176,-1.5707963267948966,-38.4594907818952,-71.75461545332762 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark13(-42.11497766386201,-1.5707963267948966,0.4908085864895232,69.78760118781989 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark13(-42.11637562041257,-1.5707963267948966,-77.05959681219792,0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark13(-42.30118737059234,-1.5707963267948983,0.0,-0.050030191444146555 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark13(-42.303244033947166,-1.5707963267948966,-14.783535322496325,-25.9012293076818 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark13(-42.36792164611176,-1.5707963267948966,-70.97115773456737,1.0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark13(-42.52441946598112,-1.5707963267948966,-8.686454464259953,64.02179317215229 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark13(-42.571563672080586,-1.5707963267948963,-0.10903171810618605,0.0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark13(-4.26799602362433,-1.5707963267948966,-89.77709421326419,-1.0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark13(-4.270396484231838,-1.5707963267948966,-100.0,60.27317023806605 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark13(-42.70545937667376,-1.5707963267949019,-16.072052077289293,77.9394481828671 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark13(-42.81729568736142,-1.5707963267948966,-69.92082342288663,1.0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark13(-42.88802136489218,-1.5707963267948966,0.0,0.42654036969566633 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark13(-4.291445922104392,-1.5707963267948966,-36.44269931916265,14.675651747010384 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark13(-4.308209253803174,-1.5707963267948966,-1.5707963267948983,-24.555577163380946 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark13(-43.22724195166031,-1.5707963267948966,-0.463628323131827,1.0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark13(-43.300044960177615,-1.5707963267948983,0.0,-29.070182940260544 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark13(-43.329269851427966,-1.5707963267948983,0.0,-0.6103618961622139 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark13(-43.38682157442478,-1.5707963267948966,-57.84276912155704,-0.142528984860544 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark13(-43.58633505253594,-1.5707963267948966,1.5707963267948966,-44.37868411020409 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark13(-43.652894898200145,-1.5707963267948983,0.5082083840671228,-64.21775511030405 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark13(-43.69148430468773,-1.5707963267948966,-7.84905474639652,-1.0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark13(-4.3737440898196525,-1.5707963267948966,-14.905607563074202,61.50454928655892 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark13(-43.74025592604758,-1.5707963267948966,0.03818641779653794,34.30505152511988 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark13(-43.743131325731206,-1.5707963267948966,-40.37657079903526,-1.1094021877204474 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark13(-43.75573830223788,-1.5707963267948966,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark13(-43.76956813819522,-1.5707963267948966,-1.5707963267948966,-0.055500596891817154 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark13(-43.777694341161975,-1.5707963267948966,-1.5212719624998217,0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark13(-43.80338711745435,-1.5707963267948966,-14.443220527761614,-74.37951888230528 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark13(-43.909424190685854,-1.5707963267948966,-72.4529105527996,-0.8729137918007579 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark13(-43.93390208613722,-1.5707963267948966,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark13(-43.970225765777585,-1.5707963267948966,1.4971597488138473,1.0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark13(-44.01824230898407,-1.5707963267948966,1.5707963267948966,-7.6173080912797815 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark13(-44.23116344278342,-1.5707963267948983,-1.0649415601137588,79.33512756805905 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark13(-44.239115656635775,-1.5707963267948966,-5.638878405883794,-0.7013044921502543 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark13(-4.428917759166848,-1.5707963267948966,-12.202774322818556,-0.106351829653766 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark13(-44.301505217203655,-1.5707963267948966,-50.2752457550346,1.0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark13(-4.431565190002942,-1.5707963267948966,1.3545364123395847,-1.0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark13(-44.66753310322381,-1.5707963267948966,0.0,1.0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark13(-44.68862661501168,-1.5707963267948966,-6.850758154948153,-1.0959046745042015E-193 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark13(-44.72589204830184,-1.5707963267948966,-61.308687347837534,-7.8243565873829475 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark13(-44.98475239013958,-1.5707963267948966,-23.371363766425034,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark13(-45.11772519361028,-1.5707963267948966,-41.49632178395312,1.0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark13(-45.13712733046939,-1.5707963267948966,-28.123049123488418,-76.93401449349761 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark13(-45.21390755996177,-1.5707963267948966,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark13(-45.23214058061056,-1.5707963267948966,-0.24663159401893864,73.18109091778251 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark13(-45.447627381564445,-1.5707963267948966,-0.4497809622330389,-32.52443034688448 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark13(-45.469522949401444,-1.5707963267948966,0.5560968639766043,-3.944304526105059E-31 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark13(-4.558503984995367,-1.5707963267948966,-29.845130209103036,45.5179806349952 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark13(-45.646870505973666,-1.5707963267948966,-35.259734667873445,24.819896634190563 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark13(-45.71354671068863,-1.5707963267948983,-40.16741198073086,-0.6445360984857751 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark13(-45.757102487665165,-1.5707963267948983,-1.797846337557362,-61.38263083118081 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark13(-45.76695916561546,-1.5707963267948966,-14.591260443758031,1.0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark13(-4.577723035617529,-1.5707963267948966,-80.8726743051771,66.32343416686084 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark13(-4.578571031934971,-1.5707963267948966,1.2251382057101248,1.0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark13(-4.587921002777055,-1.5707963267948966,-12.586283181629554,-0.001031892700482171 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark13(-46.00580252815248,-1.5707963267948966,-60.85668298622282,-1.0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark13(-46.080807600729585,-1.5707963267948966,0.5788975244164944,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark13(-46.089454853415845,-1.5707963267948966,-1.948798084192596E-15,-1.0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark13(-46.26958659997469,-1.5707963267948966,0.9827597882209513,-0.9999999999999964 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark13(-46.30535594212614,-1.5707963267948966,-0.06888057124612444,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark13(-46.351222167015514,-1.5707963267948966,-1.5707963267948948,-1.0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark13(-46.382570753787206,-1.5707963267948957,-1.5707963267948966,0.9747766268809709 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark13(-46.48063502856634,-1.5707963267948966,0.0,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark13(-46.52795730404728,-1.5707963267948966,0.0,-1.0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark13(-46.533404912426505,-1.5707963267948966,0.46973180422950805,0.6232759281918824 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark13(-46.53707963724035,-1.5707963267948966,-80.69753114732269,-100.0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark13(-46.557706645032205,-1.5707963267948966,1.5707963267948966,-0.1818655932685017 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark13(-46.57756231343132,-1.5707963267948966,0.0,7.1974929715325855 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark13(-46.667970487322,-1.5707963267948966,-3.1622184759605823,0.774795080840782 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark13(-46.6831454291639,-1.5707963267948966,-34.20186864985598,1.8991135491519597E-65 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark13(-46.75683926044932,-1.5707963267948966,-36.02113455565835,1.0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark13(-46.78949226271569,-1.5707963267948966,-10.878135790890655,83.0342364972405 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark13(-46.79011590374343,-1.5707963267948966,1.5707963267948983,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark13(-4.6841086607166345,-1.5707963267948966,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark13(-46.849835526845375,-1.5707963267948966,-72.71517706895574,27.21558260449308 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark13(-47.001486287724504,-1.5707963267948966,1.5707963267948961,37.03310415075259 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark13(-47.03440897938562,-1.5707963267948966,-0.19551052600790222,-0.5720220535410707 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark13(-47.15767526570065,-1.5707963267948966,-14.200786326071103,1.0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark13(-4.720841654751988,-1.5707963267948966,-72.49021766482723,54.027108672793226 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark13(-47.20947384962693,-1.5707963267948966,0.062675250690026,-1.0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark13(-47.27584395081757,-1.5707963267948966,-9.593280296877765,-1.0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark13(-47.31462185852284,-1.5707963267948966,-18.313480435584324,1.0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark13(-47.45470376505714,-1.5707963267948966,0.0,88.59808233853963 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark13(-47.482587716513706,-1.5707963267948966,0.0,0.8614721796895779 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark13(-47.571032558272194,-1.5707963267948966,-0.9984466486822594,1.0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark13(-47.60159839661948,-1.5707963267949019,-66.42418488383677,-50.5526085536991 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark13(-47.62748237161778,-1.5707963267948966,0.0,-57.51010211652056 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark13(-47.80234447576211,-1.5707963267948966,-0.4048213607480588,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark13(-47.812937417308326,-1.5707963267948966,-40.88832897270578,0.0077459976602897995 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark13(-47.87349776255379,-1.5707963267948966,7.105427357601002E-15,74.51520973011496 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark13(-47.92030231220213,-1.5707963267948966,-9.674576685158158,0.0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark13(-47.95084316258273,-1.5707963267948966,-29.975055360287257,1.0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark13(-48.02545509804298,-1.5707963267948966,-1.5707963267948966,1.0000014784406341 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark13(-4.811108777968997,-1.5707963267948966,-98.3951530175917,-1.0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark13(-48.11979141831523,-1.5707963267948966,-21.61778578896599,-0.940116855982337 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark13(-48.13456319065786,-1.5707963267948966,1.5707963267948943,1.0587911840678754E-22 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark13(-48.13665781928702,-1.5707963267948966,0.0,10.931610008097694 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark13(-48.139348787207666,-1.5707963267948966,-76.21496569790915,-87.66093142663698 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark13(-48.19093025808308,-1.5707963267948966,-7.453698368375971,1.0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark13(-48.192277905078015,-1.5707963267948966,-55.888208988049215,-0.9999525990520601 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark13(-48.26526828417299,-1.5707963267948966,-1.0742327356082595,0.7229522478092241 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark13(-48.39823238410567,-1.5707963267948966,-1.5707963267948966,-53.46245572170629 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark13(-48.42117539529922,-1.5707963267948966,-59.483887773817884,-0.1279402619479324 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark13(-48.47037486939289,-1.5707963267948966,0.031887310560149464,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark13(-48.475635507003034,-1.5707963267948983,-1.5707963267948974,-1.0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark13(-48.50231576205709,-1.5707963267948966,0.0,0.1785355691909347 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark13(-48.51309242713133,-1.5707963267948966,-57.3859449657256,-34.284374548585376 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark13(-4.863974117887978,-1.5707963267948966,0.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark13(-48.689690631975324,-1.5707963267948972,-1.3008655615711888,-1.0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark13(-4.876981411177685,-1.5707963267948966,-49.071003963288696,-1.0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark13(-48.777845365310256,-1.5707963267948966,-38.13260489360785,8.881784197001252E-16 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark13(-48.798371522734456,-1.5707963267948966,-64.28593396150623,-0.05676148501072187 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark13(-48.80731490021137,-1.5707963267948966,-1.5707963267948921,0.0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark13(-4.885013370875584,-1.5707963267948966,-78.85830562655804,2201.9774948959116 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark13(-48.868249158395194,-1.5707963267948966,1.5707963267948966,-0.11559291135550868 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark13(-48.869921212594505,-1.5707963267948966,-0.2958466604838763,-1.0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark13(-4.891967447100673,-1.5707963267948966,-0.5173991146190007,3.101411940750019E-4 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark13(-48.933851082356085,-1.5707963267948966,-54.63369772087036,78.77081049188686 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark13(-49.01215871386081,-1.5707963267948966,0.8229418975994203,-49.31233879089265 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark13(-49.09334723170958,-1.5707963267948912,-57.709769480374405,-70.39147536284806 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark13(-49.10578118939355,-1.5707963267948966,-66.2694869096926,-0.9999999999999998 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark13(-49.11740314525415,-1.5707963267948966,-2.048489415961107E-15,-0.9999999999999981 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark13(-49.18297526906599,-1.5707963267948966,-1.055049661022432,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark13(-49.234172120474454,-1.5707963267948966,1.5707963267948983,-1958.4473451434196 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark13(-49.23429045429373,-1.5707963267948966,-43.027215834999204,1.0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark13(-49.32379806905331,-1.5707963267948968,-77.76992287092,-0.5265101817231508 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark13(-49.47560310934541,-1.570796326794897,-67.68224864948377,0.5385224333972933 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark13(-49.68635982103866,-1.5707963267948966,-3.855818383639246,98.13886439646379 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark13(-49.68809262489422,-1.5707963267948966,-77.67913118218118,-59.08473757372581 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark13(-49.69951626202958,-1.5707963267948966,1.5707963267948957,-0.8457783344562699 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark13(-49.73693309572219,-1.5707963267948966,-41.023904299361845,-5.907052044883599 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark13(-49.74998368926385,-1.5707963267948966,0.0,0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark13(-49.803710566118774,-1.5707963267948966,0.0,2.4004909372401574E-4 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark13(-49.90252339435932,-1.5707963267948966,-88.72180366226236,-1.0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark13(-50.297658450548504,-1.5707963267948966,0.0,-1.0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark13(-50.331176637290206,-1.5707963267948966,-21.67979432666327,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark13(-50.44538012350306,-1.5707963267948983,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark13(-50.45404345212449,-1.5707963267948966,-3.763177416432896E-16,81.1438644910162 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark13(-5.047339341904376,-1.5707963267948966,-1.196559890411215,1.0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark13(-50.4747095479823,-1.5707963267948966,-10.849321594303674,-18.925197635890655 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark13(-50.49613919773766,-1.5707963267948983,-36.21048751765034,1.0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark13(-50.55883708282467,-1.5707963267948966,-65.59732922785629,-12.07918616335092 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark13(-50.67542683539648,-1.5707963267948966,-38.00989660943181,0.0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark13(-50.687596126770764,-1.5707963267948966,-1.305943778116415,-23.715793830590457 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark13(-50.72490140975228,-1.5707963267948966,-1.5707963267948966,0.781356275001595 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark13(-51.046723086013536,-1.5707963267948966,-0.6516272871619195,-0.9999999999999523 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark13(-51.051948609245855,-1.5707963267948966,0.0,1.0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark13(-51.226866306527384,-1.5707963267948966,0.0,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark13(-51.24255995060414,-1.5707963267948966,-11.25962460490951,-27.356824503860288 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark13(-51.39031437828903,-1.5707963267948966,-1.837992955133947,-1.0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark13(-51.40190072092996,-1.5707963267948966,-84.49140620681075,6.938893903907228E-18 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark13(-51.41057599036476,-1.5707963267948966,-86.78466489468565,-0.9555610335468606 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark13(-51.445639079871746,-1.5707963267948961,-3.3108082122230003,1.0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark13(-5.145071443634556,-1.5707963267948966,-1.5707963267948966,0.17376705072542276 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark13(-51.496941911967745,-1.5707963267948966,1.5707963267948948,-51.71278517133206 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark13(-5.150196559184143,-1.5707963267948966,-14.388436209669118,-0.7740030683289566 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark13(-51.53713732833424,-1.5707963267948966,-1.5672555136233903,-0.0606289195218441 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark13(-51.561749925891775,-1.5707963267948966,-2.6012454055131293,-1.0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark13(-51.56773782846952,-1.5707963267948966,0.25609380614103294,-78.96986667119289 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark13(-51.69255286060367,-1.5707963267948966,-14.433070172840953,-0.05042431574812593 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark13(-51.69523446501516,-1.5707963267948966,-91.72636422873558,0.6751825983769706 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark13(-51.82741349583877,-1.5707963267948966,0.0,-1.0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark13(-5.191170056874262,-1.5707963267948966,-70.91845926748132,-27.879040881741005 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark13(-51.98857395096623,-1.5707963267948966,0.0,0.9999999999999964 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark13(-52.10689894073589,-1.5707963267948966,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark13(-52.14618776166803,-1.5707963267948966,0.0,-2.0303534698525194E-115 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark13(-52.15329777273177,-1.5707963267948966,-36.68800630468219,80.99952634759931 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark13(-52.22190526054821,-1.5707963267948966,-9.483716424613375,1.0000004885220084 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark13(-52.265590741746344,-1.5707963267948966,-67.31661077745356,-1.0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark13(-52.29571794851261,-1.5707963267948966,-24.78986015803531,21.396462946711225 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark13(-5.2313811541787665,-1.5707963267948966,0.7525164227724493,2198.0433696834307 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark13(-5.2318013660219895,-1.5707963267948966,0.0,0.0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark13(-52.38628128434829,-1.5707963267948966,-1.5707963267948966,0.06292000992420425 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark13(-52.43873282069571,-1.5707963267948966,0.20046786643561873,65.88296481782719 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark13(-5.248556875924528,-1.5707963267948966,-0.0961827999512271,-100.0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark13(-52.65752011976073,-1.5707963267949019,0.6277618485511491,-0.030416329739843984 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark13(-52.853625371083446,-1.5707963267948966,-67.63058472074486,13.747803973424508 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark13(-52.937501625914585,-1.5707963267948966,0.008136668788142195,1.0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark13(-52.99252458391049,-1.5707963267948966,-34.75327338735968,-31.50370086307799 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark13(-53.022803303839616,-1.5707963267948966,-0.20033419786436182,-1.0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark13(-5.303386546227229,-1.5707963267948966,1.5707963267948966,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark13(-53.06267124266864,-1.5707963267948966,-67.31013978959614,1.0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark13(-53.155498955654004,-1.5707963267948966,-1.724521308462302,0.0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark13(-53.22405548031397,-1.5707963267948966,2.6032823290186956E-16,0.8935648207591972 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark13(-53.289512135724486,-1.5707963267948966,-42.42629658245257,47.71432832241748 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark13(-53.54546083886308,-1.5707963267948966,0.27641198522875865,0.9407286097041699 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark13(-53.610517286762594,-1.5707963267948966,-50.24669393422094,1.0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark13(-53.61166762929726,-1.5707963267948966,0.0,48.72789353329998 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark13(-53.663736531813576,-1.5707963267948966,1.5507832579125893,0.6459935256705414 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark13(-53.69035717519967,-1.5707963267948966,-0.5627971547514226,-0.3772853952622458 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark13(-53.70766445380759,-1.5707963267948966,-100.0,-43.32206234250623 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark13(-53.7630329480485,-1.5707963267948966,-1.570796326789008,35.48284575853987 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark13(-53.83060764698413,-1.5707963267948966,1.570796326794895,-57.07671044484097 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark13(-53.898385171433006,-1.5707963267948966,-8.583138466441241,1598.0957730476484 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark13(-53.901739080218434,-1.5707963267948966,-10.444501034809662,-1.0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark13(-53.9711773638993,-1.5707963267948966,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark13(-53.98608761956317,-1.5707963267948966,-4.120855487757865,-0.9037354303110927 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark13(-54.04162734623322,-1.5707963267948966,0.5010378334022171,0.7911481641898348 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark13(-54.07914258134234,-1.5707963267948966,-7.014373097794576,-5.524466463435412 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark13(-5.4109395682328625,-1.5707963267949019,-72.55597002163793,89.37525281081648 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark13(-54.12705622836473,-1.5707963267948966,-73.75028551898714,62.68193618131351 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark13(-54.19359647112649,-1.5707963267948966,0.002246301072887133,-1.007598777559953E-15 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark13(-54.23359990325612,-1.5707963267948966,-3.2949923241555155,2.3091142759676477E-15 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark13(-54.34249313031865,-1.5707963267948966,0.0,0.36209563917353654 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark13(-54.396919356500405,-1.5707963267948966,0.23315794645065274,-0.03459322461091721 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark13(-54.415072974638626,-1.5707965779704205,-135.14069250609276,0.8733547357018239 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark13(-54.418357752961086,-1.5707963267948966,-67.52255922535136,1.0 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark13(-54.4487441582763,-1.5707963267948966,-67.65357521097107,0.8061138211201345 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark13(-5.447368599617285,-1.5707963267948966,0.0,-0.49269492187207986 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark13(-54.69067156489687,-1.5707963267948966,0.0,-0.013553192206587938 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark13(-54.8073201857449,-1.5707963267948966,0.5566507440739343,-0.10007449638044974 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark13(-54.89074802689737,-1.5707963267948966,1.5707963267948948,0.02309869268778897 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark13(-54.963339789186094,-1.5707963267948966,-3.226297952347636,0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark13(-55.000053411590564,-1.5707963267948966,-72.71014627579173,0.16201717196776855 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark13(-55.100350781199744,-1.5707963267948966,1.5707963267948966,0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark13(-55.13021921711505,-1.5707963267948912,-82.03184919642081,-10.843023732543273 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark13(-55.1730791547396,-1.5707963267948983,-86.08386501349754,15.065822701850177 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark13(-55.286479588204365,-1.5707963267948966,-100.0,1.0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark13(-55.3084737294248,-1.5707963267948966,-0.6669199446530767,69.45244125762908 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark13(-55.331967935076676,-1.5707963267948963,1.5707963267948966,-0.8542270839252027 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark13(-55.467920388366295,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark13(-55.49896891024781,-1.5707963267948966,1.5707963267948966,-0.9064135397128452 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark13(-55.509149319316364,-1.5707963267948966,-1.5679968913022417,1.0000021279505167 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark13(-55.540766358886856,-1.5707963267948966,-52.2605391182989,-1.0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark13(-55.55194106215267,-1.5707963267948966,-1.1102230246251565E-16,-87.72798985877017 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark13(-55.594430288857446,-1.5707963267948966,-1.5707963267948966,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark13(-55.61896586313591,-1.5707963267948966,6.938893903907228E-18,-54.363624601314406 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark13(-55.6884913695968,-1.5707963267948966,1.5707963267948966,-0.02395159921704465 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark13(-55.703541673662215,-1.5707963267948966,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark13(-55.70397492883041,-1.5707963267948983,-14.432117267747945,92.34164741251945 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark13(-55.83740692310363,-1.5707963267948966,-1.234975003857333,-46.56307780722483 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark13(-55.892945504342364,-1.5707963267948966,-41.88215943112596,-14.555583497365404 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark13(-55.99762249653962,-1.5707963267948966,-1.5707963267948957,-0.7339450549958377 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark13(-56.03501081305423,-1.5707963267948966,-85.46701207341708,-1.0000020265388467 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark13(-56.204989024258346,-1.5707963267948966,-89.11682989770483,-94.26508544859496 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark13(-56.238423161217284,-1.5707963267948966,1.5707963267948966,-1.0000000000000118 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark13(-56.31898655208292,-1.5707963267948983,-2510.4846836640004,0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark13(-5.6366247529422076,-1.5707963267948966,-0.6139495502707248,-1.0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark13(-56.393708751424015,-1.5707963267948966,-0.19054321697865306,0.8482165257193197 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark13(-56.421527385962435,-1.5707963267948966,20.147685539293146,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark13(-56.42579106304924,-1.5707963267948966,-20.3883271282212,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark13(-56.49775404912844,-1.5707963267948912,-1.5707963267948966,62.5283070353771 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark13(-56.535384754796056,-1.5707963267948966,-48.5039146533756,0.8224287819151309 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark13(-5.657644020292981,-1.5707963267948966,2.220446049250313E-16,0.893236807139516 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark13(-56.57701734998896,-1.5707963267948966,-37.10131586511276,1.0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark13(-5.657859947704253,-1.5707963267948966,1.5707963267948966,-0.018580277741102866 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark13(-56.610162545160705,-1.5707963267948966,-1.1601422043180813,0.9999999999999922 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark13(-56.66784959203865,-1.5707963267948966,-0.14584939169052066,-4.49318879643819 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark13(-56.701319256245355,-1.5707963267948966,-61.26105674500097,-100.0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark13(-56.79043422263096,-1.5707963267948968,-77.81527763871824,-1.0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark13(-56.87986685634729,-1.5707963267948966,-83.97297301130497,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark13(-57.07295273131359,-1.5707963267948963,-3.9535940900107107,-79.04021725288828 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark13(-57.199858124330824,-1.5707963267948966,-46.97452286866181,1.734723475976807E-18 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark13(-57.38931504574113,-1.5707963267948966,3.1415925787604273,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark13(-57.40728236302023,-1.5707963267948966,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark13(-57.54263124446683,-1.5707963267948966,-37.47584662008594,58.87200330209725 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark13(-5.763199026215017,-1.5707963267948966,1.0191842297415645,-27.73755347011256 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark13(-57.81673654294625,-1.5707963267948966,-42.26852882594145,12.078347085198928 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark13(-57.90919899872646,-1.5707963267948966,-18.455969595839974,-0.9999999999999929 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark13(-58.03950272424916,-1.5707963267948966,-1.5707963267948966,-1.0000036714543152 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark13(-58.04956822449123,-1.5707963267948966,-37.46868268830048,0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark13(-58.06030001047528,-1.5707963267948966,-0.6900191571043002,-93.421616735751 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark13(-58.19482698830579,-1.5707963267948966,-1.8219862113062675,-1.0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark13(-58.24306904422045,-1.5707963267948966,0.4050504074033917,-0.244181801837434 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark13(-58.31254600079822,-1.5707963267948966,-25.66555360976383,0.12647729016582332 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark13(-58.33512767780242,-1.5707963267948966,-57.16775045584741,0.006876626417413732 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark13(-58.33918571607265,-1.5707963267948966,-83.05661797254619,1.0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark13(-58.53842853078751,-1.5707963267948966,-72.0201112769687,-0.5411630257411133 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark13(-58.6227452058676,-1.5707963267948966,-42.299014078521544,55.2768641189946 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark13(-58.70552072980761,-2.220446049250313E-16,-3.447727587645344,-86.91563255042968 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark13(-58.76625372555916,-1.5707963267948912,-18.316811988372265,-1.0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark13(-58.853301263750375,-1.5707963267948966,1.5707963267948966,-0.9850811094614385 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark13(-58.943770648001504,-1.5707963267948966,0.09512835925493768,0.018907663909040525 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark13(-5.903630470378766,-1.5707963267948966,-0.2834028710174259,-0.9999999999999987 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark13(-5.918876497102815,-1.5707963267948966,-0.4993642736413406,0.9999999999999982 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark13(-59.218638610079594,-1.5707963267948966,-14.429553127816213,-0.019241157461621583 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark13(-59.3526247117666,-1.5707963267948966,0.6203858631294825,-0.9990471300236836 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark13(-59.38459173878014,-1.5707963267948966,-0.05571893027675401,1.0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark13(-59.39790999962037,-1.5707963267948966,-1.5707963267948966,0.6744089055238397 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark13(-5.949656302180362,-1.5707963267948966,1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark13(-59.5215929869328,-1.5707963267948966,-54.8529483740712,-0.013360014856445078 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark13(-59.620405128456994,-1.5707963267948966,-29.036973788592576,-64.17241504795885 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark13(-59.64473616140245,-1.5707963267948966,-59.55060712349992,-2245.2714627959876 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark13(-59.84818943499466,-1.5707963267948966,-80.11149961952913,-26.451927267733907 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark13(-59.882987594340285,-1.5707963267948966,-13.15005292415329,0.05143880690166409 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark13(-59.89705554911558,-1.5707963267948966,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark13(-59.92046951641087,-1.5707963267948966,0.8574443591886569,-1.0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark13(-59.98401693154147,-1.570796326793661,0,0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark13(-59.98874974965423,-1.5707963267948966,-36.98196268083768,-1.0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark13(-6.003308973337399,-1.5707963267948966,-4.252527265753955,-34.721771086408026 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark13(-60.066337003112764,-1.5707963267948983,-5.591737233608741,0.9999999999999929 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark13(-60.092808615871846,-1.5707963267948966,0.0,-0.6768718028893081 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark13(-60.176335695373226,-1.5707963267948966,-1.5707963267948966,0.13583267475820548 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark13(-60.19973440085394,-1.5707963267948966,-1.1102230246251565E-16,2.1175823681357508E-22 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark13(-60.22186837542123,-1.5707963267948966,-1.5707963267948966,-94.8946773016797 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark13(-60.4060233361405,-1.5707963267948966,1.2368335262327737E-16,-30.47010635544205 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark13(-60.41374365299031,-1.5707963267948966,-75.11413899544658,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark13(-60.41851366295221,-1.5707963267948966,1.5707963267948966,-22.59995284950453 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark13(-60.515493279337356,-1.5707963267948966,49.38101152310271,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark13(-60.611670134971185,-1.5707963267948966,-85.14529601077992,1.0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark13(-60.67851406964939,-1.5707963267948966,1.2814433691722333,-0.004091900795625325 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark13(-60.882245880534875,-1.5707963267948966,-49.04915321452613,0.8225553830430348 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark13(-60.933859245302955,-1.5707963267948966,-44.56537969307948,-1.0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark13(-60.96324132705712,-1.5707963267948966,-1.5707963267948966,0.9173491715737488 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark13(-61.07934756388688,-1.5707963267948966,-0.3037422488854008,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark13(-61.12012096671117,-1.5707963267948983,-0.03227437357789374,-100.0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark13(-61.1385241124719,-1.5707963267948983,-24.991880113224553,0.6193768433523732 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark13(-61.142032669866005,-1.5707963267948983,-79.13749677399281,-2195.428399756895 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark13(-61.205539231520646,-1.5707963267948966,-87.33404101015219,-1.0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark13(-61.235768593074816,-1.5707963267948966,-4.644775020630902,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark13(-61.32313954713795,-1.5707963267948966,-65.18000688822694,1.0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark13(-61.359802780351615,-1.5707963267948966,-56.0253302233219,96.35200942118053 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark13(-61.36632191497848,-1.5707963267948966,-0.006068178074323555,0.28705634770433086 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark13(-61.46092180993216,-1.5707963267948966,0.0,-0.746025304894351 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark13(-61.52945105085779,-1.5707963267948966,1.0352807290295387,-91.37416489941637 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark13(-61.60291195301939,-1.5707963267948966,-52.43877072638708,-83.6525255103269 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark13(-61.61478033236563,-1.5707963267948966,-73.18603003094947,1.0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark13(-61.71398461606502,-1.5707963267948966,-1.4347208858559304,-1.0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark13(-6.179903663171285,-1.5707963267948966,-1.497710856437515,0.9844603402533739 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark13(-6.184842139028072,-1.5707963267948966,-75.04623748296846,1.0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark13(-61.8808461652934,-1.5707963267948966,-1.5707963267948912,-57.083426114320744 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark13(-61.88303835930502,-1.5707963267948966,-0.06075527159481116,-42.40271871273407 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark13(-61.908697918422504,-1.5707963267948966,-13.225262770553563,1.0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark13(-61.95088848126092,-1.5707963267948963,-0.40741851927885,1.0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark13(-61.989054447228334,-1.5707963267948966,-1.5707963267948966,-0.22357300376777112 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark13(-62.06029661566497,-1.5707963267948966,-56.8387944258067,17.8671566520949 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark13(-62.13321260961773,-1.5707963267948966,-27.944337939469385,1.5815719223199132 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark13(-6.2139259244683975,-1.5707963267948966,0.0,-1.0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark13(-62.15898797167771,-1.5707963267948966,-1.5707963267948961,-0.0027251269485096584 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark13(-62.197726772311164,-1.5707963267948966,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark13(-6.220050700001536,-1.5707963267948968,-1.3547380142925203,2183.218184699505 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark13(-62.27129679485216,-1.5707963267948966,-16.876233294939098,-0.2204826161818758 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark13(-62.284188296749754,-1.5707963267948966,-98.15718891103427,-0.024241588916774415 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark13(-62.41995220958593,-1.5707963267948966,-14.812819973365333,1.0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark13(-62.55604288601211,-1.5707963267948966,-1.131903923411247,1.0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark13(-62.708884175639746,-1.5707963267948966,1.3705890359450923,1.0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark13(-6.27507900543862,-1.5707963267948966,-0.8339821353382675,18.48790295812246 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark13(-62.83359442719625,-1.5707963267948966,-0.1268317746884598,-1.0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark13(-62.92180098911761,-1.5707963267948966,-1.5707963267948966,81.0569181609554 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark13(-62.97063937914511,-1.5707963267948983,-23.17283396240211,-63.664290871482265 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark13(-63.040697496940034,-1.5707963267948957,-6.239756627395067,1.0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark13(-63.04378236166069,-1.5707963267948966,1.7763568394002505E-15,1.0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark13(-63.137856157187876,-1.5707963267948966,-0.453821653470747,-0.009501828916671388 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark13(-63.252301917702376,-1.5707963267948966,0.6326252854968553,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark13(-63.2579739124788,-1.5707963267948966,-14.879458715842773,-1.0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark13(-63.29552139128242,-1.5707963267948966,-0.3496535391632052,-1.0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark13(-6.329687792213494,-1.5707963267948966,-4.9214915522428555,1.0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark13(-63.40552621023234,-1.5707963267948966,-48.79646396608577,-0.8954385672114663 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark13(-63.49641754871016,-1.5707963267948966,0.8121257039164851,0.0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark13(-63.572079570994255,-1.5707963267948983,-1.5707963267948966,77.13104611228746 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark13(-63.74119068329662,-1.5707963267948966,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark13(-63.7888300242834,-1.5707963267948966,-9.556177761860592,-85.14116437948196 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark13(-63.88272786350533,-1.5707963267948966,-135.52350501820789,-47.714300437848635 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark13(-63.89455295085029,-1.5707963267948966,-81.5954503057065,-1.0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark13(-6.395395881440191,-1.5707963267948966,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark13(-63.9951469142451,-1.5707963267948966,-13.097538226351634,-45.48093278790043 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark13(-64.03556381065899,-1.5707963267948974,-100.0,-0.6154455769777298 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark13(-64.07283201500839,-1.5707963267948974,-16.07883932517577,1.0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark13(-64.17956922725251,-1.5707963267948966,-1.5646386710161895,-1.0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark13(-64.19040357513258,-1.5707963267948966,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark13(-64.38166502557657,-1.5707963267948966,-1.5707963267948966,18.913601464106208 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark13(-64.52650119522755,-1.5707963267948966,-0.19756853317374995,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark13(-64.54327614552327,-1.5707963267948966,-36.947327958632,-10.6539459528111 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark13(-64.57266893106764,-1.5707963267948966,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark13(-64.57347889920467,-1.5707963267948966,0.0,-0.9158783387757526 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark13(-64.63723069417755,-1.5707963267948966,0.0,0.7107396482549895 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark13(-64.6762035572231,-1.5707963267948966,-1.5707963267948983,-0.8094251935746044 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark13(64.69710290862767,-33.413315498397395,64.4448504436493,0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark13(-64.71075332112835,-1.5707963267948966,0.0,-1.0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark13(-6.484804613061868,-1.5707963267948966,-5.958806017615117,0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark13(-64.86714529714249,-1.5707963267948966,-66.23283354748153,-3.174928092174368 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark13(-65.14855422287367,-1.5707963267948966,-22.56742972521527,-56.76026920668542 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark13(-65.26509587242012,-1.5707963267948966,-12.551931742009824,-0.9174920856363572 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark13(-65.37782319846605,-1.5707963267948966,-34.43460365101669,4.2351647362715017E-22 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark13(-65.50525782265804,-1.5707963267948966,-42.54720264330463,0.6408278577609547 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark13(-6.556198545693751,-1.5707963267948966,-55.86533074177755,0.0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark13(-65.64106190280148,-1.5707963267948966,-100.0,31.325424862348136 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark13(-65.6817711067489,-1.5707963267948963,-100.0,-0.7537381379598282 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark13(-6.576360772239318,-1.5707963267948966,0.0,-0.9999999999999997 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark13(-65.91911994203089,-1.5707963267948966,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark13(-65.9262013783438,-1.5707963267948966,-1.0415445582733385,0.0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark13(-66.01858854078186,-1.5707963267948966,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark13(-66.02420281755813,-1.5707963267948966,0.0,0.19089596988111268 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark13(-66.02436229298573,-1.5707963267948966,-1.5709402511293453,-1.3426074951820196E-4 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark13(-66.07600695632983,-1.5707963267948966,-1.5707963267948966,1.0000001739070536 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark13(-66.0821089520868,-1.5707963267949054,-101.56543351752237,31.46673757029148 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark13(-66.11686342017322,-1.5707963267948957,-1.5707963267948966,-0.12182732808473051 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark13(-66.18121795894497,-1.5707963267948966,-39.893857440565455,1.0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark13(-66.22449555804768,-1.5707963267948966,-20.51114637899617,-0.9999999999999996 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark13(-66.28665952479813,-1.5707963267948966,-100.0,0.04549276628049348 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark13(-6.630429306859641,-1.5707963267948966,-90.01022112195027,-1.0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark13(-66.32656698021017,-1.5707963267948966,-1.5707963267948966,0.9999999999999964 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark13(-66.3857690196415,-1.5707963267948966,0.9891988032213175,1.0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark13(-66.8048448379154,-1.5707963267948966,-23.57553368811945,0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark13(-66.84532713937615,-1.5707963267948966,0.5773234329869057,17.62539430044492 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark13(-66.86420728574073,-1.5707963267948966,-95.30810327351493,0.0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark13(-67.0399221411829,-1.5707963267948957,-53.96477441427259,2117.1944641808404 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark13(-67.33994948190566,-1.5707963267948968,-1.5707963267948966,-0.8626988464823677 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark13(-67.34663738691243,-1.5707963267948966,-50.55024126182946,-1.0000000521353802 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark13(-67.49360899864305,-1.5707963267948966,0.0,0.9739082516914211 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark13(-67.66221795878661,-1.5707963267948966,1.565866298685982,-50.77428729484267 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark13(-67.74444285247544,-1.5707963267948912,0.0,1.0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark13(-67.96254179613325,-1.5707963267948966,-46.17030946501992,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark13(-67.96477506604253,-1.5707963267948966,-36.35347627850407,3.327486479457782E-17 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark13(-68.035340825029,-1.5707963267948966,-0.08703653804522576,-1.000000025877519 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark13(-68.07805489564711,-1.5707963267948966,-24.301143863856748,-0.9994712714262242 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark13(-68.1005069346359,-1.5707963267948966,-7.153012519119162E-16,-0.9223792658968146 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark13(-68.13750125732119,-1.5707963267948966,0.22074495024745952,-77.26815083018428 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark13(-68.2990704139356,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark13(-68.32307521348012,-1.5707963267948966,-74.8112080414653,-0.9555273231717702 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark13(-68.34529763259152,-1.5707963267948966,-5.105315395918495,1.0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark13(-68.37992206235333,-1.5707963267948983,-28.139643376238666,0.293404085673429 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark13(-68.6325795300708,-1.5707963267948966,-1.5707963267948983,-0.44687875098644336 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark13(-68.87690443499642,-1.5707963267948966,-80.8047331727392,57.800715476412364 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark13(-68.91511143710548,-1.5707963267948966,-24.10069526471162,3.944304526105059E-31 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark13(-6.895756035436223,-1.5707963267948966,-36.3353588875777,3.7982270983039195E-65 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark13(-68.9879889728909,-1.5707963267948966,-1.5707963267948966,1.0112253356986804 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark13(-6.903110825659073,-1.5707963267948983,-107.77706312243436,-0.03775268598847681 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark13(-69.03269027712129,-1.5707963267948966,66.62808255625909,0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark13(-6.913506382747736,-1.5707963267948966,-29.42406719877611,51.63417649001863 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark13(-6.913518500572732,-1.5707963267948981,0.0,-1.0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark13(-69.14685753377108,-1.5707963267948966,-10.761154541467473,-1.0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark13(-69.15973192861907,-1.5707963267948966,0.0,2075.2959830845025 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark13(-69.24350667491736,-1.5707963267948983,1.7763568394002505E-15,1.0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark13(-6.934853646163642,-1.5707963267948966,0.0,-0.06256105102649732 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark13(-69.45747287952378,-1.5707963267948966,-4.572443585844748,0.04606511451883115 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark13(-69.45883062212813,-1.5707963267948966,-68.49220941477925,-1.1985091468012028E-94 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark13(-69.49811837338447,-1.5707963267948966,1.5625738213587872,1.0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark13(-69.5046042190279,-1.5707963267948966,-75.33281151158162,0.9973651281980087 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark13(-69.5837293221469,-1.5707963267948912,-80.22196856577669,31.20831641739349 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark13(-69.61522734826296,-1.5707963267948966,-1.664720742998725E-16,-1.0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark13(-69.62805737606168,-1.5707963267948966,-43.85795822765677,0.0 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark13(-69.68604584412641,-1.5707963267948966,-12.659564844988012,0.031196865530889684 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark13(-69.8594271988409,-1.5707963267948966,0.9795719019538098,32.69761787257061 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark13(-69.89095237597189,-1.5707963267948966,-86.39379797371932,-100.0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark13(-70.00028920152666,-1.5707963267948966,0.0,1.0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark13(-70.00680078307494,-1.5707963267948966,-79.53653796628723,0.2416272229890042 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark13(-70.03380199817916,-1.5707963267948966,-1.4411163880507865,-0.789500708940158 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark13(-7.006133334583096,-1.5707963267948966,-78.373906544291,-1.0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark13(-70.08059440120726,-1.5707963267948966,-25.476370775382673,0.0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark13(-70.1137646047582,-1.5707963267948966,-50.41406539796394,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark13(-70.15157367540915,-1.5707963267948966,-93.88926510450982,1.0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark13(-70.18782697217101,-1.5707963267948966,-20.302068347521722,0.046596952616017207 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark13(-7.0252469821425745,-1.5707963267948966,-6.9705819084453875,-1.0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark13(-70.38665931151952,-1.5707963267948966,-3.552713678800501E-15,-0.06046554940630905 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark13(-70.40142733380469,-1.5707963267948983,-5.03774269864391,1.0000000000000036 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark13(-70.45808948884574,-1.5707963267948948,0.0,-0.02489146856004258 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark13(-70.48018784519141,-1.5707963267948966,-73.31508728004209,-1.0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark13(-70.50522373224463,-1.5707963267948966,-4.910387703036328,67.99194622088675 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark13(-70.58899785908947,-1.5707963267948966,-16.32217749707308,-0.9837238319716416 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark13(-70.59511625356343,-1.5707963267948966,-49.93992886106649,-0.026455032933473177 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark13(-70.60174611523827,-1.5707963267948966,0.0,-100.0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark13(-70.60284978877185,-1.5707963267948966,0.0797208440353883,-0.9999999999999879 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark13(-70.67629295667047,-1.5707963267948966,-1.5707963267948966,-0.008367459911769452 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark13(-7.0775549841017735,-1.5707963267948966,-30.04923164716048,25.45081450089629 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark13(-70.78891655592084,-1.5707963267948983,-78.37692345705887,-90.44832348569658 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark13(-70.8007753619134,-1.5707963267948966,-97.95292572008134,-1.0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark13(-70.85536255645432,-1.5707963267948966,-28.17880706241373,-0.4668001641416282 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark13(-70.87072233955531,-1.5707963267948966,-13.084702244754364,16.1775771612648 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark13(-70.93886659916117,-1.5707963267948966,0.0,-0.29454428294518126 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark13(-71.01190125660197,-1.5707963267948966,-1.5707963267948966,-0.999999999999981 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark13(-71.06469045849693,-1.5707963267948983,-38.25787132967591,0.0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark13(-71.07235563986306,-1.5707963267948966,-70.43524868951803,3.3087224502121107E-24 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark13(-71.17884712981655,-1.5707963267948966,-24.343751409763726,-41.67587216180649 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark13(-71.38770354640641,-1.5707963267948966,-41.84280664291305,0.9999999999988695 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark13(-7.140472277379288,-1.5707963267948966,0.0,5.736331838915255E-15 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark13(-71.55881244167743,-1.5707963267948966,-6.409319322682871E-13,46.64987114139731 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark13(-71.57317507447256,-1.5707963267948966,0.9118853126904743,0.8147778187628125 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark13(-71.60082941699517,-1.5707963267948966,-1.5707963267948948,-1.0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark13(-71.65734644098775,-1.5707963267948966,-38.46051949747085,-17.616936048075218 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark13(-71.71549255958621,-1.5707963267948966,-83.31387324120767,-1.0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark13(-71.79439315123149,-1.5707963267948963,-69.73141030765483,-0.9999999999999982 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark13(-71.82124157431141,-1.5707963267948966,-1.5174980253038315,-0.11039322469322 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark13(-71.84458250972243,-1.5707963267948966,-0.2754211327373497,-1.0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark13(-71.94407054801816,-1.5707963267948966,-79.53000178731172,-2.700662528181195 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark13(-71.94728194279186,-1.5707963267948912,-36.57570198950998,45.24479070096328 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark13(-71.98305076458318,-1.5707963267948966,-1.5707963267948957,-0.19850218789949015 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark13(-72.04044355037219,-1.5707963267948948,-84.16480473226933,0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark13(-7.20676551253546,-1.5707963267948966,-1.4957245513213588,-3.606632272572553E-130 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark13(-72.11335385405734,-1.5707963267948966,-0.24056983829527212,0.020130461639745488 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark13(-72.13334624478045,-1.5707963267948966,-8.157287152708102,-1.0000201856159328 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark13(-72.19852551409761,-1.5707963267948983,-49.59606168370212,2251.8175456891813 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark13(-72.25289240801781,-1.5707963267948966,-84.96586031305836,5.421010862427522E-20 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark13(-72.26694649746528,-1.5707963267948963,-1.537519514474564,1.0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark13(-72.39776551415505,-1.5707963267948966,-35.131568090912324,1.0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark13(-72.40000925454362,-1.5707963267948966,-50.37701917284,-1.0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark13(-72.4491843993933,-1.5707963267948966,-33.6135436386775,-0.2457695787732872 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark13(-72.52555649628385,-1.5707963267948966,-72.40286454882404,0.9592028297991797 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark13(-72.53079476129294,-1.5707963267949054,-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark13(-72.54355332238075,-1.5707963267948966,-10.337145719029689,1.0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark13(-72.58262085879336,-1.5707963267948966,-100.0,-1.0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark13(-72.7050856238547,-1.5707963267948966,-78.95738673419876,84.79805504561331 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark13(-72.74297470065943,-1.5707963267948966,-7.188840369912723,1.0141091614692814 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark13(-72.74520096005816,-1.5707963267948966,-83.97492640573572,-1.0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark13(-7.27907650926114,-1.5707963267948966,0.8521921482417564,1.0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark13(-72.89921166224477,-1.5707963267948966,-45.61916340690493,-1.0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark13(-72.92463781255792,-1.5707963267948966,-87.57473479225611,-1.0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark13(-7.304993062514089,-1.5707963267948966,-61.357460511258665,-0.05592079039949657 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark13(-73.05839032572884,-1.5707963267948966,1.5707963267948912,74.63526526974651 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark13(-73.07112854250559,-1.5707963267948966,0.14911716713960932,-100.0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark13(-73.07427383686661,-1.5707963267948966,0.0,-1.0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark13(-73.11453595173302,-1.5707963267948966,-10.688347037340678,0.8416624265782622 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark13(-73.14673679981988,-1.5707963267948966,-59.00754365306423,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark13(-7.3150313200752946,-1.5707963267948963,0.0,-11.263619998464831 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark13(-73.2009832274975,-1.5707963267948983,-53.79736005071382,-18.421769052223752 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark13(-7.335626907191076,-1.5707963267948966,0.11779273111370864,-46.06025718306419 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark13(-73.3715893682162,-1.5707963267948966,0.9059951047627594,-1455.617660509132 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark13(-7.349540844026302,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark13(-73.61455396645394,-1.5707963267948966,1.5707963267948966,-0.9999999999999997 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark13(-73.66096051091554,-1.5707963267948966,-52.0495424772107,1.0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark13(-73.66221317647599,-1.5707963267948966,-80.34529742676895,95.88887719662861 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark13(-73.66491568245439,-1.5707963267948966,-21.63581952129778,1.0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark13(-73.71154577643641,-1.5707963267948966,-17.695251034447402,1.000000027089264 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark13(-73.77367486464343,-1.5707963267948966,0.09042218871203742,1.0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark13(-73.82164058632569,-1.5707963267948966,0.0,2.0117102273765323E-15 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark13(-73.87220118842312,-1.5707963267948966,0.32777373174811975,0.0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark13(-73.87824087155589,-1.5707963267948966,1.5707963267948966,-73.81651688714341 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark13(-74.0087765367885,-1.5707963267948963,-6.937712289299341,-78.57584562052185 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark13(-74.0302805200364,-1.5707963267948966,1.5707963267948968,-1.0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark13(-74.07959032348673,-1.5707963267948966,-9.810140786119081,-1.0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark13(-74.10221409060215,-1.5707963267948966,-54.37388891999145,-1.0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark13(-74.2016639993824,-1.5707963267948966,-1.5707963267948983,-1.0000000020235011 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark13(-74.27760256936516,-1.5707963267948966,-1.5707963267948966,-71.51605860269898 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark13(-74.32596255430624,-1.5707963267949019,-82.608541716306,-0.5408436456813261 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark13(-7.445144112927877,-1.5707963267948966,-1.5707963267948966,-58.23248960569282 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark13(-74.45837914863706,-1.5707963267948948,-3.5290914567840304,-60.746935765308265 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark13(-74.57584461201975,-1.5707963267948966,-33.448048278843636,-6.6174449004242214E-24 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark13(-74.59373943732795,-1.5707963267948966,1.5707963267948966,-1.144959515559797E-17 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark13(-74.69272743423987,-1.5707963267948966,-1.5707963267948966,-38.15422044366071 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark13(-74.69506039542597,-1.5707963267948966,-6.576118849577516,-1.0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark13(-74.76969629125628,-1.5707963267948912,-1.5707963267948966,-77.89162532899114 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark13(-74.80666216555136,-1.5707963267948948,0.07158303551636958,-0.2405802838725748 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark13(-74.8145354818835,-1.570796326794897,-28.459203544150615,-0.2072071389256227 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark13(-7.486224352774127,-1.5707963267948966,-1.5707963267948966,-0.9932041900492036 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark13(-74.8739550935395,-1.5707963267948966,-61.551031575306766,99.25291806579611 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark13(-74.94899575316663,-1.5707963267948966,0.0,-78.64520531103352 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark13(-75.01857960267262,-1.5707963267948983,-69.94930386138202,2373.461055172197 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark13(-7.501991796771804,-1.5707963267948966,-37.067896068603744,0.9927946983419301 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark13(-75.03957740566713,-1.5707963267948966,-73.78862765010558,1.0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark13(-75.04090507968093,-1.5707963267948966,-80.79216128399642,20.57280460806767 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark13(-75.05564413870451,-1.5707963267948966,-1.1102230246251565E-16,-1183.481068171283 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark13(-75.09173041952128,-1.5707963267948966,1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark13(-75.14908740674016,-1.5707963267948948,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark13(-75.29469517235245,-1.5707963267948966,-22.240637150571033,0.9784142603750707 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark13(-75.3292736527132,-1.5707963267948966,-62.814096032738625,0.0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark13(-75.38454795542522,-1.5707963267948966,-4.4158223382051975,-2053.3078513085097 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark13(-75.41263766089146,-1.5707963267948966,0.0,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark13(-75.44722283427616,-1.5707963267948966,-48.890904219042554,0.240990759587568 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark13(-75.44920224091554,-1.5707963267948948,-10.819576266349713,0.24872438769045713 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark13(-75.54148522705871,-1.5707963267948966,0.1520487524858466,-6.174667654359745 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark13(-75.59474409644795,-1.5707963267948966,-68.51132903715416,4.018905036155488 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark13(-75.6510865847747,-1.5707963267948966,-22.784739291861705,1.0458188051563035 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark13(-75.67605141956497,-1.5707963267948966,-1.5707963267948966,4.5522099189454387E-159 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark13(-75.7457101116072,-1.5707963267948983,-1.570796326794897,0.9652103986611956 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark13(-75.82655184352762,-1.5707963267948966,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark13(-75.84766839646714,-1.5707963267948966,-1.5707963267948966,4.5079840692350475 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark13(-75.89931266805878,-18.16258831242088,0,0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark13(-75.98510460535712,-1.5707963267948966,0.0,0.01601026321285558 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark13(-75.99179869662423,-1.5707963267948966,-89.76979829557371,-47.49207343105129 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark13(-76.0174090695215,-1.5707963267948966,-50.05959857568581,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark13(-7.605400423220489,-1.5707963267948966,-1.0136388675772992,-0.8379712847308299 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark13(-76.20404279355496,-1.5707963267948966,-0.04453938150239499,-51.61788435369843 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark13(-76.2429066375425,-1.5707963267948966,0.0,-1.0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark13(-76.34195198777077,-1.5707963267948966,-34.86375364676553,1.0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark13(-76.66762625962542,-1.5707963267948966,-0.5619389164077488,-1.0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark13(-76.69677362886003,-1.5707963267948966,-68.19817441620555,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark13(-7.690954562343681,-1.5707963267948966,-12.262532333432347,-0.05312004208999834 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark13(-77.14568644013036,-1.5707963267948966,-1.5707963267948961,-98.44893805324932 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark13(-7.71543519011675,-1.5707963267949003,-93.61666045839453,1.0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark13(-7.7365243819439184,-1.5707963267948966,-1.5633690358255081,26.342417649395635 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark13(-77.36841882748965,-1.5707963267948966,0.0,5.293955920339377E-23 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark13(-77.54942372905613,-1.5707963267948966,1.5707963267948966,-0.9999999999999997 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark13(-77.5591882435988,-1.5707963267948966,-9.830781633077827,73.02143044176435 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark13(-77.58315329032408,-1.5707963267948966,-46.780813146803105,-1.0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark13(-7.764734903589791,-1.5707963267948966,-83.26195801685762,-0.3969544731775917 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark13(-77.68594525508693,-1.5707963267948966,-0.47199887924158107,0.35814453743638575 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark13(-77.71377458519328,-1.5707963267948966,1.5707963267948948,0.35747685061989243 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark13(-77.71621139572943,-1.5707963267948966,-78.56935772144875,-33.14491644082473 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark13(-77.75320509290678,-1.5707963267948966,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark13(-77.79231643958772,-1.5707963267948966,-99.76377426993804,31.954342079826517 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark13(-77.98797762418106,-1.5707963267948968,0.3987551792643376,0.0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark13(-7.801451709109994,-1.5707963267948966,1.5707963267948966,-0.033736500618458495 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark13(-78.02093890880347,-1.5707963267948966,-100.0,0.42792702624655143 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark13(-78.10780955314195,-1.5707963267948983,-78.08362610949746,-1.0098000942883816 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark13(-7.813716380754617,-1.5707963267948966,-2.365053581917099E-15,-44.20100993081859 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark13(-78.17216229762013,-1.5707963267948966,1.5399646209765971,-0.050172805667736256 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark13(-78.23347341485717,-1.5707963267948966,59.58638652579805,0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark13(-78.29471282756882,-1.5707963267948966,-1.5707963267949028,-0.7866295597836112 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark13(-78.30703223300017,-1.5707963267948966,-1.1341543376845808,-1.0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark13(-78.3165389942764,-1.5707963267948966,-15.25505723401615,-25.67769088161451 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark13(-78.34366650970473,-1.5707963267948966,-61.26105674500097,-0.8872017211142689 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark13(-78.35997402109865,-1.5707963267948966,0.13373531115864892,-1.0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark13(-78.45849839540756,-1.5707963267948966,0.47769284706100523,-42.227888417085 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark13(-78.55071290581303,-1.5707963267948966,-98.57885781202583,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark13(-78.55969684159308,-1.5707963267948966,-32.080998001172325,1.0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark13(-78.60662500467055,-1.5707963267948966,-1.5648613669740556,0.04959422188938256 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark13(-78.60835626268269,-1.5707963267948966,-1.5707963267948966,-0.88600602235744 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark13(-78.63172251557538,-1.5707963267948966,-31.29470025462026,31.422726771451273 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark13(-78.94287687551673,-1.5707963267948966,-4.884362459019528,-0.3665237831557868 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark13(-79.19151096908544,-1.5707963267948966,-0.3003938732573346,-0.5592524341424084 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark13(-79.24302525923731,-1.5707963267948966,-1.1540604991450687,0.0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark13(-79.2697115352176,-1.5707963267948966,-21.465209395404912,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark13(-79.28617776610649,-1.5707963267948966,1.5707963267948983,-0.12209212446150985 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark13(-79.32722401502127,-1.5707963267948948,-61.65253085248168,-0.9999999999999929 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark13(-79.3834807341179,-1.5707963267948966,-1.5707963267948966,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark13(-79.39971661618398,-1.5707963267948966,-17.765096497777492,1.6704779438076223E-52 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark13(-79.4410653561925,-1.5707963267948966,-0.9982552611050782,-1.0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark13(-79.46786447201137,-1.5707963267948912,-100.0,0.036502821494100585 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark13(-79.59325494347092,-1.5707963267948968,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark13(-79.67838918267834,-1.5707963267948966,-34.5675869177804,82.91333658112406 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark13(-79.6902764906665,-1.5707963267948966,-1.2814417208079458,0.03748501894670167 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark13(-7.971826783807931,-1.5707963267948966,-3.8945081504425616,0.358503455701494 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark13(-79.80142401563997,-1.5707963267948966,1.570796326794893,-0.8204158420156578 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark13(-79.91025012571359,-1.5707963267948966,-18.9740587373988,-1.0 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark13(-79.9827556075055,-1.5707963267948966,2.955261575115855,-100.0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark13(-8.006831344632127,-1.5707963267948966,-1.5725504905253216,-0.9398218119622468 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark13(-80.11064064668588,-1.5707963267948966,-58.55756370558907,1.0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark13(-80.1133094538211,-1.5707963267948983,-68.22628787879577,78.12848606179476 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark13(-80.18527734591544,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark13(-80.24068188094408,-1.5707963267948983,-54.78254091629753,0.8507345421569783 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark13(-80.26943035967193,-1.5707963267948983,-30.99882328631965,1.0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark13(-8.054079026952792,-1.5707963267948966,-76.27619762674364,0.7384067906326721 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark13(-80.59517534801411,-1.5707963267948966,-29.696239547413903,-0.9639757542470275 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark13(-80.62907756713619,-1.5707963267948966,-100.0,85.30408041476406 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark13(-80.676672966882,-1.5707963267948966,-97.86034419057599,0.06255326762932756 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark13(-80.6962536647776,-1.5707963267948966,0.6149659630616086,1.0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark13(-80.72693107054553,-1.5707963267948966,-9.555404194685636,87.27529139017562 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark13(-8.073750768323093,-1.5707963267948966,-0.2699865876969562,0.2723255661341071 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark13(-80.89407642525771,-1.5707963267948983,-91.89050903497315,-71.56933786099808 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark13(-80.98604370286773,-1.5707963267948966,-40.96070816822697,-0.7333756863735368 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark13(-81.13169751578097,-1.5707963267948966,-42.84380666235725,3.1554436208840472E-30 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark13(-81.13592351300886,-1.5707963267948966,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark13(-81.3094658088281,-1.5707963267948966,-90.88252290372162,-33.39156356103378 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark13(-81.35684556311595,-1.5707963270265577,-120.96140493281212,0.36238379733111636 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark13(-81.37551825564528,-1.5707963267743046,-176.96093430548774,-0.38790917112429835 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark13(-8.139667501208262,-1.5707963267948966,-19.087109100546627,-1.0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark13(-8.14612743813387,-1.5707963267948966,-11.001028905360815,0.03210086146864953 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark13(-81.54324453682165,-1.5707963267948957,1.5707963267948966,-0.1535221770704851 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark13(-8.159193536163675,-1.5707963267948966,-57.93694812262084,-91.75927974661874 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark13(-81.59290906778872,-1.5707963267948966,0.45475878743994974,3.451338067507834 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark13(-81.62038297209153,-1.5707963267948966,-100.0,-1.0000000040345407 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark13(-81.70194202953729,-1.5707963267948966,-67.42487006059656,-1.0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark13(-81.84912194764175,-1.5707963267948966,-0.48095018429133163,-0.93265424564043 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark13(-81.85983659549274,-1.5707963267948966,-1.3877787807814457E-17,84.01137444914632 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark13(-81.89889247867295,-1.5707963267948966,-1.5707963267948948,-0.1855534458210227 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark13(-8.191858146789713,-1.5707963267948966,-55.211227581457635,-1.0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark13(-81.96422071880865,79.44216890006953,-80.23117763400056,0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark13(-82.03637755815197,-1.5707963267948966,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark13(-82.06835746994436,-1.5707963267948966,0.0,1.0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark13(-82.12447233070756,-1.5707963267948966,1.449420480713302,1.0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark13(-82.14240646319615,-1.5707963267948966,-67.48054076212719,-1.361286982135885E-16 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark13(-82.24388237637025,-1.5707963267948966,0.4973743712800518,-0.011762073825241462 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark13(-82.26793099119043,-1.5707963267948966,-1.5707963267949197,-100.0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark13(-82.3336692629197,-1.5707963267948966,1.5707963267948966,-0.8588215464756166 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark13(-82.37981663372575,-1.5707963267948966,0.9279408533972623,63.16936648496714 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark13(-82.53671800951695,-1.5707963267948966,-48.05578850256441,-1.0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark13(-82.53766624014915,-1.5707963267948966,-3.5150719571768443,1.0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark13(-82.57100438346563,-1.5707963267948966,-1.5707963267949054,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark13(-82.69871698392767,-1.5707963267948966,1.5707963267948966,-47.769539754855295 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark13(-82.75452301178905,-1.5707963267948966,-53.45058129089289,-0.9999999999999997 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark13(-82.7673105261195,-1.5707963267948966,0.06830127726552092,-0.1323814697419683 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark13(-82.9456101244948,-1.5707963267948966,-66.9276269416469,0.8643860659369668 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark13(-82.96614225744499,-1.5707963267948966,1.5707963267948966,-0.03971929815699615 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark13(-82.96992103302621,-1.5707963267948966,-89.90672891907859,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark13(-83.11121613554349,-1.5707963267948966,-0.19220742495966664,0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark13(-83.22639911590714,-1.5707963267948966,-46.82275761510464,30.91146798156069 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark13(-83.28858562931616,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark13(-83.42992061223079,-1.5707963267948966,-98.96016858807849,-99.97464271477261 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark13(-83.6125764280015,-1.5707963267948966,-53.033612114074586,-1.018241932586453 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark13(-83.68164113602748,-1.5707963267948966,0.4423760522892158,0.9681860410112069 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark13(-83.74302609212246,-1.5707963267948948,-73.65941005016207,-2021.5781325202245 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark13(-8.381920828861084,-1.5707963267948966,-9.696570017728416,0.021672973001144662 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark13(-83.81939143349906,-1.5707963267948966,-10.997214171766652,-552.907152972107 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark13(-83.90283595841069,-1.5707963267948966,-100.0,100.0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark13(-83.90653695508732,-1.5707963267948966,1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark13(-8.399308473632331,-1.5707963267948912,-68.81021117646091,-1.0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark13(-8.40123319647672,-1.5707963267948966,0.0,-76.09319906241053 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark13(-84.12788972917613,-1.5707963267948966,-20.87340600645634,-80.1660190130307 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark13(-84.2180215602584,-1.5707963267948966,-47.036563035666525,5.92463560278631 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark13(-84.22615525372888,-1.5707963267948966,-18.12504016858602,-33.58388024132233 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark13(-84.23688471502611,-1.5707963267948966,0.16462548154894888,63.630241346400744 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark13(-84.29469998224674,-1.5707963267949054,-40.15142596945465,-0.9999999999999982 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark13(-84.33023235858465,-1.5707963267948966,-53.87489680945945,-1.0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark13(-84.41173169000895,-1.5707963267948966,-43.540013898381694,-0.023290967301928867 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark13(-84.46943408802647,-1.5707963267948948,-100.0,48.35666582223549 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark13(-84.56850002739893,-1.5707963267948966,-84.07491157204554,-95.18610107040497 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark13(-84.57860210262965,-1.5707963267948966,-1.5707963267948966,3.36208364506183 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark13(-84.60445011404096,-1.5707963267948963,-36.69876933671266,1.0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark13(-84.78161618084786,-1.5707963267948966,-1.5707963267948966,-1.0000005186331145 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark13(-84.83383623681839,-1.5707963267948966,-100.0,-1.0000002912121726 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark13(-8.489383365482892,-1.5707963267948966,-71.26681105642297,0.559660426552159 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark13(-84.92514000255777,-1.5707963267948966,-52.0073515434611,0.979011387133758 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark13(-8.498395378718016,-1.5707963267948983,-1.7763568394002505E-15,11.62590532079802 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark13(-85.06771094295955,-1.5707963267948966,-66.13547892918248,-1.0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark13(-85.10254463314756,-1.5707963267948966,-36.285126095884266,1.0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark13(-85.14613142340067,-1.5707963267948966,-1.5707963267948983,-0.06255258182625784 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark13(-85.19715284059572,-1.5707963267948966,-97.9152007254597,-0.9999999999999969 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark13(-8.521480521458086,-1.5707963267948966,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark13(-8.531706576452851,-1.5707963267949019,-122.67918778751401,42.298591069142034 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark13(-85.39386118410906,-1.5707963267948966,-1.5707963267948966,1922.29615505531 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark13(-8.546414935945819,-1.5707963267948966,0.0,0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark13(-85.49798431481204,-1.5707963267948966,14.429827756746462,-1.0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark13(-85.63870701079007,-1.5707963267948966,0.0,1.0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark13(-8.566078376216113,-1.5707963267948966,-1.4429777248211892,1.0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark13(-8.570513345822315,-1.5707963267948912,-61.917677800508244,2021.6848026667087 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark13(-86.04789168985455,-1.5707963267948966,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark13(-8.608131741795614,-1.5707963267948966,-86.19803725978129,-1.0 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark13(-8.611682409469518,-1.5707963267948966,-87.07309593637278,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark13(-86.12591015983809,-1.5707963267948983,-24.115255296219445,-5.601606338056598 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark13(-86.12599530011093,-1.5707963267948966,-29.561394564702116,-1.0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark13(-86.14856660573133,-1.5707963267948966,-89.9994673775596,-1.0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark13(-86.19360582835576,-1.5707963267948983,-134.79430763550073,22.736729357206215 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark13(-86.32469651614886,-1.5707963267948966,1.407346957722447,1.0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark13(-8.662852596247038,-1.5707963267948966,-81.49396882036154,-11.216627139400279 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark13(-86.73053920110844,-1.5707963267948966,-100.0,-1.0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark13(-8.683312949952114,-1.5707963267948966,0.0,-0.3580050152680401 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark13(-86.88007827028605,-1.5707963267948966,-83.36780595047638,60.405557984144565 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark13(-8.698408509922615,-1.5707963267948966,-48.93365968396851,1.0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark13(87.17326272554294,-11.842956823161387,-96.23177160627672,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark13(-87.2190531576297,-1.5707963267948966,-1.5707963267949019,-0.4263383940527724 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark13(-87.32406489185928,-1.5707963267948966,-3.1364738529741203,-0.05080354192645578 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark13(-8.740607788527326,-1.5707963267948966,0.1281621792650147,-1.0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark13(-87.43060952401255,-1.5707963267948966,1.5707963267948966,-76.61046310052342 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark13(-87.52960384110372,-1.5707963267948912,-43.488376976052656,0.0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark13(-87.73110678660652,-1.570875746699069,-137.08385214329383,-0.5825414034321476 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark13(-87.84479605297969,-1.5707963267948983,-12.682479475743065,1.0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark13(-87.90290947735315,-1.5707963267948948,-97.0449217531149,5.329070518200751E-15 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark13(-8.796268638758445,-1.5707963267948966,-37.04683755177916,0.0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark13(-87.99704683474586,-1.5707963267948966,1.5707963267948966,-0.06307888162981237 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark13(-88.17196762697287,-1.5707963267948966,-9.78158337234726,0.6157818348841744 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark13(-88.2494422407536,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark13(-88.30044633814686,-1.5707963267948966,0.0,-0.35700265285012767 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark13(-88.33184772582102,-1.5707963267948983,0.0,21.24374359470076 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark13(-88.34156049383967,-1.5707963267948966,-7.702470384065205,-1.0 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark13(-88.40648154911915,-1.5707963267948966,-68.76121402395555,40.723131977800435 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark13(-88.4398572150627,-1.5707963267948963,-1.5707963267948966,-23.518212378860667 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark13(-8.844154130392484,-1.5707963267948966,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark13(-88.53562385637518,-1.5707963267948983,-1.5707963267948983,-69.71820636095713 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark13(-88.58369093910173,-1.5707963267948966,-8.587052707667592,-0.9095894001644912 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark13(-88.82694880460325,-1.5707963267948966,-65.35075389893491,1.0 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark13(-88.96951806092699,-24.385025244449764,0,0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark13(-88.99946292832536,-1.5707963267948966,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark13(-89.09034565680135,-1.5707963267948966,-1.2038882493945202,1.0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark13(-8.924559238741178,-1.5707963267948968,-1.152577490463422,1.0 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark13(-89.33638466377376,-1.5707963267948966,0.0,1.0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark13(-89.34639308710325,-1.5707963267948966,0.37230541846768406,-19.516855232772798 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark13(-8.93647458057709,-1.5707963267948966,0.14327043482110824,-1.0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark13(-89.36758216603009,-1.5707963267948966,-15.574555746263716,-1.0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark13(-89.68493444906271,-1.5707963267948966,1.0082692389848136,0.0124781397899582 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark13(-89.72132617603673,-1.5707963267948966,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark13(-89.72833820220359,-1.5707963267948966,-14.44983023207211,0.17397609397895294 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark13(-89.76256265075403,-1.5707963267948983,-83.47041823222943,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark13(-89.78212162138166,-1.5707963267948966,-36.196550250804556,0.09471912099679747 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark13(-89.93133091328104,-1.5707963267948966,0.017214153692205164,-0.3437915543122161 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark13(-90.2852394251739,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark13(-90.34631304680028,-1.5707963267948966,-53.56798742638567,-1.0000000000000004 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark13(-90.51655643392351,-1.5707963267948966,-45.64957662014406,-1.0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark13(-90.53424307908342,-1.5707963267948912,-0.2970258992954082,0.0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark13(-90.58313430833383,-1.5707963267948966,-0.012406256350282762,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark13(-90.60107096181466,-1.5707963267948966,-22.23741042991921,0.9373558058305946 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark13(-90.6327205281012,-1.5707963267948966,-10.308974458512978,-1.0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark13(-90.70696054439001,-1.5707963267948966,1.4290634003477034,-75.41847870255616 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark13(-90.75360693766851,-1.5707963267948966,-44.801119885850476,-0.06255501507002911 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark13(-90.83859616352893,-1.5707963267948983,-68.18523104775124,2388.023800371224 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark13(-9.101359606617994,-1.5707963267948966,-97.93585673895808,-16.62670316860347 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark13(-91.06621094000437,-1.5707963267948966,-54.977871437821385,0.0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark13(-91.12475236257445,-1.5707963267948912,-44.76999696599456,1.0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark13(-91.1461355148489,-1.5707963267949054,0.4860058251843533,2173.0374311146684 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark13(-91.25410662601661,-1.5707963267948966,-74.12968635379507,0.634894770880833 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark13(-91.25499106896366,-1.5707963267948966,-54.21687212560703,-0.012878187834586274 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark13(-9.134793692276943,-1.5707963267948966,63.234641374005434,0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark13(-91.43184709576417,-1.5707963267948968,0,0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark13(-91.46828535356418,-1.5707963267948966,-100.0,5.065515623725497E-9 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark13(-91.48440413588123,-1.5707963267948983,-1.5707963267949054,0.9999999999999999 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark13(-91.64493552950884,-1.5707963267949054,-100.0,-47.26418274310777 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark13(-91.76744535956283,-1.5707963267948966,-1.5707963267948966,0.11586261410096677 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark13(-91.79898041854904,-1.5707963267948966,0.18136760424996012,91.77571227652932 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark13(-91.84801630040215,-1.5707963267948966,39.06176869428403,0 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark13(-91.92908343975921,-1.5707963267948966,-82.70234403421887,1.0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark13(-92.04239374056874,-1.5707963267948966,4.440892098500626E-16,0.0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark13(-92.12745628398926,-1.5707963267948966,3.552713678800501E-15,-1.0000000000000004 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark13(-92.35416919323858,-1.5707963267948966,0.0,-100.0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark13(-92.42842741944027,-1.5707963267948966,-14.436584404948036,3.807361680841684E-5 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark13(-92.43136573293144,-1.5707963267948966,-4.192714186301245,-14.64822694829644 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark13(-92.44438071922903,-1.5707963267948966,0.0,-1.0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark13(-92.44534117279852,-1.5707963267948966,-82.87265805941739,-1.0000000000000022 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark13(-9.246209422518742,-1.5707963267948966,0.0,88.05423193301009 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark13(-9.25275903750662,-1.5707963267948966,-2.1117425682373465,-3.6189418592859544 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark13(-92.69480372443672,-1.5707963267948912,-43.87531150325212,-2371.8218401124827 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark13(-92.71076838921876,-1.5707963267948963,-19.28559179447681,-2265.0005713488245 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark13(-92.76435279639645,-1.5707963267948966,1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark13(-9.276450451191607,-1.5707963267948966,-44.225590849982865,0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark13(-92.7678257975397,-1.5707963267948966,-17.352826194184672,-0.11520908188006729 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark13(-93.04027094944612,-1.5707963267948966,-86.65080664042759,0.7294057481278697 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark13(-93.17605695012672,-1.5707963267948966,0.0,-1.0 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark13(-9.325742565807637,-1.5707963267948966,-64.84352217713472,-0.8068086763497424 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark13(-93.27310207083113,-1.5707963267948966,0.0,1.0 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark13(-93.34452896210806,-1.5707963267948966,0.0,0.046208918155568254 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark13(-93.50054290174401,-1.5707963267948966,-27.147595182867192,-3.009265538105056E-36 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark13(-93.53291173017502,-1.5707963267948966,-4.712388981519928,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark13(-93.57806156723508,-1.5707963267948966,-100.0,-1.0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark13(-9.366656221514177,-1.5707963267948966,0.0,0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark13(-93.76973236824182,-1.5707963267948966,-86.06832757378058,12.8493031758167 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark13(-93.80396735400689,-1.5707963267948966,-1.4744320743294848,-8.001596523802323 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark13(-93.81643639380664,-1.5707963267948966,-35.62515033163672,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark13(-93.90861210590089,-1.5707963267948966,-0.5279899507413391,-0.02887658387338765 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark13(-93.981161020179,-1.570796326794893,-56.17888074987795,1.2898881437904495E-16 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark13(-94.04838308942215,-1.5707963267948966,-0.01663583448742905,0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark13(-94.19173119230139,-1.5707963267948966,-52.964415768986306,-1.0000000000000018 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark13(-94.30657402570452,-1.5707963267948966,0.8312478110615504,-1.0 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark13(-9.439886797465494,-1.5707963267948966,-62.88519201765115,-29.129815990785534 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark13(-94.54004283610584,-1.5707963267948966,-4.188722748344479,-8.933523644823724 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark13(-94.57301529649189,-1.5707963267948966,-48.31378192787025,1.0000037153202666 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark13(-9.468505316226299,-1.5707963267948966,1.529009992924339,-73.36680551823298 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark13(-94.78364990777254,-1.5707963267948966,-49.078168238565276,-1.0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark13(-9.482724300757424,-1.5707963267948966,-10.095448169823213,1.0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark13(-94.83843768670877,-1.5707963267948966,-69.70100551244292,1.0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark13(-9.495680994271549,-1.5707963267948966,-30.27707189020109,0.0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark13(-94.9674212653833,-1.5707963267948966,0.726503732900777,-12.801461251224593 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark13(-94.99977752351577,-1.5707963267948966,-40.68617882653842,-1.608611746708759E-86 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark13(-95.14809673455893,-1.5707963267948968,-0.563150176505897,1.0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark13(-95.22486867892107,-1.5707963267948966,0.0,-100.0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark13(-95.62203005859057,-1.5707963267948966,-67.5465145790904,-1629.2503238544587 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark13(-95.82920545589457,-1.5707963267948966,-64.07206870274415,-0.5445659452045145 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark13(-95.85155894440395,-1.5707963267948966,-36.31912304800136,0.33035649737603867 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark13(-95.8659724210037,-1.5707963267948966,-84.60559363624219,1.0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark13(-95.91137548464116,-1.5707963267948966,-1.0900990776301873,0.02712450971378133 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark13(-9.596174810638553,-1.5707963267948966,-0.3668347224534233,-71.17169477517047 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark13(-95.97387617284572,-1.5707963267948983,-100.0,-29.983539827225584 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark13(-96.09441052227609,-1.5707963267948983,-0.645413745952041,-0.3665408576951612 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark13(-96.16921105790253,-1.5707963267948966,-30.031975422524905,0.26230403460300644 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark13(-96.24481370016724,-1.5707963267948948,-172.8723395624322,1.0 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark13(-96.28028777377844,-1.5707963267948966,-80.22031895624511,0 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark13(-9.629893830935622,-1.5707963267948966,-12.027628879272653,98.62973815155826 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark13(-96.34930322272044,-1.5707963267948966,-93.70826411880165,1.0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark13(-96.35784533311053,-1.5707963267948968,-4.633261928707114,-0.7716609894045872 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark13(-96.4374109963886,-1.5707963267948966,-48.20535064617462,1.0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark13(-96.7008484911383,-1.5707963267948966,-14.440455505924149,0.6060819615506623 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark13(-96.71023067320475,-1.5707963267948966,-71.81744447369209,-1.0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark13(-96.77442048866199,-1.5707963267948966,0.5332025565063995,27.55691303814875 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark13(-96.78198921734594,-1.5707963267948966,-40.07145769175386,-0.22968890205771175 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark13(-97.12089850954379,-1.5707963267948966,-60.16124743612994,0.00566996664516195 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark13(-97.16290541382135,-1.5707963267948877,-1.5707963267948912,0.013663311543202956 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark13(-97.34395527644088,-1.5707963267948966,-80.14632624151378,2.3881070538074834E-6 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark13(-97.38574293868503,-1.5707963267948966,3.552713678800501E-15,2212.7313768447916 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark13(-97.67728473507283,-1.5707963267948966,-14.73771336045418,-100.0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark13(97.79334617506095,58.88096748955735,-53.90886502657861,0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark13(-97.81838370304823,-1.5707963267948966,0.4603615071973911,-0.6920106053263444 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark13(-97.96913430365903,-1.5707963267948966,-5.855827973449792,15.504989307580281 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark13(-97.96997715045939,-1.5707963267948966,-7.081054717560134,-33.3196530486445 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark13(-98.00027271111561,-1.5707963267948966,-67.41640431101949,0.22786834347186424 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark13(-98.05970150871954,-1.5707963267948966,0.2450996373485156,-0.7486529647105826 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark13(-98.26389093158348,-1.5707963267948966,-96.67126525675464,0.36209443700947114 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark13(-98.49981173805611,-1.5707963267948966,-1.5707963267948983,84.48443813049609 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark13(-98.60456232440184,-1.5707963267948966,-1.4895339241207335,11.415496941632748 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark13(-98.72870330649889,-1.5707963267948966,-100.0,1.0 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark13(-98.75191612066556,-1.5707963267948966,0.0,-30.310754034429237 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark13(-98.76189348225257,-1.5707963267948966,-0.009897914934229778,-8.470329472543003E-22 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark13(-98.81048731186048,-1.5707963267948966,-53.765232410042074,-60.17615418869846 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark13(-98.8611067052337,-1.5707963267948994,-72.32167018013874,-1.0 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark13(-98.87146188669684,-1.5707963267948966,-1.866392256862598,0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark13(-9.89938672389618,-1.5707963267948966,8.881784197001252E-16,-0.9605402997653298 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark13(-99.04117732983104,-1.5707963267948966,-1.1553440927872032,1.0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark13(-99.1618078381747,-1.5707963267948966,-0.02331635953776888,0.0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark13(-99.20772789226726,-1.5707963267948966,1.5707963267948966,-0.898241958709497 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark13(-99.21696169653599,-1.5707963267948966,-4.248140067954552,-1.0 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark13(-99.43984642906858,-1.5707963267948966,1.0836749102862313,0.883168592526675 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark13(-99.49143611514694,-1.5707963267948966,0.0,0.9573136957511259 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark13(-99.52050387924702,-1.5707963267948966,-14.437905761717325,-0.4280538355035332 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark13(-99.63111142667226,-1.5707963267948966,-1.0208087793984746,-1.001234841663975 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark13(-9.963187904737552,-1.5707963267948983,1.4774990259987844,73.40363651715822 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark13(-99.67587852268565,-1.5707963267948966,-30.842274012981136,0.36208943532033167 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark13(99.69557348167686,-1.5707963267948983,0,0 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark13(-99.7328744916018,-1.5707963267948966,-61.26105674500097,-0.7906278194988889 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark13(-99.83081881078083,-1.5707963267948966,-12.474384153167193,0.5373642795109334 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark13(-99.85805322715044,-1.5707963267948966,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark13(-99.86130283029283,-1.5707963267948966,-61.76519534271874,0.6103385885607768 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark13(-99.90108397241957,-1.5707963267948966,1.2720464781221756,1.0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark13(-99.9058838260553,-1.5707963267948966,0.35444624172643163,1.0232735720171888 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark13(-99.9059382816914,-1.5707963267948966,-89.32033783006072,2.1084395886461046E-81 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark13(-99.93249130121552,-1.5707963267948966,-34.56292190970535,0.9998597067258473 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark13(-99.93281440965238,-1.5707963267948983,1.5707963267948966,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark13(-99.94473956298599,-1.5707963267948966,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark13(-99.98060616527977,-1.5707963267948966,-1.5707963267948966,-0.2763043530204623 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark13(-99.99247869030889,-1.5707963267948966,1.1114141546126237E-23,-0.9936862800345134 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark13(-99.9999642258412,-1.5707963267948966,0.8860625058439444,6.776263578034403E-21 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark13(-99.99999999999335,-1.5707963267948966,-99.99999999998616,-0.9999999999987229 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark13(-99.99999999999787,-1.5707963267948966,-1.5379138927898803,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark13(-99.99999999999999,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark13(-99.99999999999999,-1.5707963267948966,-100.0,-1.0000000000000047 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark13(-99.99999999999999,-1.5707963267948966,-1.5707963267948908,-77.70451968682035 ) ;
  }
}
