import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.0014758015107640935,1.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.007612722641103575,71.39137851634183 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.008197019879822132,-1.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.013573513849345142,1.0000000057986531 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.02902755337459194,-22.703488935543064 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.036011594017934065,1.0000000000000018 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.036532904986077544,-0.81956818330218 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.0380412904823067,-25.420219724618057 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.04881115908033129,1.0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.05867733872271581,2.220446049250313E-16 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.07076539160447748,-5.6231949959025584 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.07595601791231003,0.06255252780862608 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.0981317966812076,1.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.10058429955338655,-0.9361893199233423 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.11545027079496983,1.0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.12023544725711588,55.678757455471384 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.12148674322932632,-1.0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.1239601934238177,-0.4651449620192629 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.12682938585508358,-0.025267307835644764 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.12935009075669554,0.7431243285019185 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.1463459315800089,8.89103499794031E-162 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.14678404824102784,1.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.1523695595407497,-37.25597198546533 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.15898237225952414,82.54831417170925 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.16466143137888878,-1.0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.16848942717181536,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.18482531190804252,18.157152477923887 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.19432166833566433,72.53061106040457 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.21450753387704252,0.0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.24141179691797987,0.01613913113714977 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.24175849887644457,1.734723475976807E-18 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.2447021596446754,-0.998950314191598 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark55(0,-0.02575394778015974,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.2618537559795657,1.0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.3124998479959616,-0.28577311428196706 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.3178573071852721,46.379110792220985 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.3226006632999656,0.33990681032948056 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.3656286130181442,0.09445782583353868 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.3753908302520408,-10.973722809421332 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.3805069070044311,-0.5391544828247703 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark55(0.003838073557659527,-0.3320607266218115,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.40033765854926706,45.77262174845248 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.42987099128703893,-1.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.4419777622566134,1.0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.4435648226464364,-1.062820071782205 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.4683971431728815,-0.05547810555427647 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.4826403231318102,-0.042144564133356655 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.499343811213381,-1.0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.524544138175894,-9.141999611126082 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.5364515404779509,69.57591178510049 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.553610720981881,-74.49826702239939 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.5599884026532221,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.5629271981233087,2.8061622379768068 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.5900933706929871,-1.0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.6122429570186938,-0.9999999999999982 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.618908332662662,1.0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.6346581945794934,1.0118999719796948 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.6607986043977899,-1.0000000000000002 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.6740828067747071,-51.51561694727586 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.6763429502000989,96.12412581179716 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.682062410617638,-1.0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.6957056525445555,57.93273254393615 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.7117957728172694,-2229.909803119388 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.7441790161441608,-0.985977657015668 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.7469884442536463,-24.281493198506034 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.7696237479719962,58.769867003431585 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.7821571834437022,-0.14572541618947332 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.7991296716042132,-0.06255429319492506 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.804635696886208,60.947512140042576 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.8098575064116846,0.9999999999999999 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.8258314943707125,0.0014728455985305589 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.8584841328826108,-1.0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.8596654282027841,-92.79277909574132 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.8695047664515622,0.9999999999999999 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.8791189957340108,-1.0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.8793601705383545,-2291.754024437859 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.9308870042253945,0.9112421310990423 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.9382826291543107,0.9999702834928584 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.9409166271054533,-1.0000000000000007 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.98585005544553,-41.22667268157015 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.9946921617255238,1.0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.0101432211103365,-0.3645075570700913 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.0140656743956382,29.666956635952847 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.032621214739847,0.9283844470273063 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.0390623714669296,0.17684369899222574 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.1460740213171294,0.15509996494056677 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.1488134950469586,13.722633943655936 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.1884814629944693,1.734723475976807E-18 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.1975476110285745,-1.0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.2029546947678822,17.094528394449206 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.2174413170383076,1.0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.2237177390058989,-42.81319645532142 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark55(0.01262010251870227,-1.499991564200607,0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.2659321653603448,-0.46023399796547704 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.2725578861104905,1.0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.2894091718935166,1.0000000016518409 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.301282703384682,23.898635622971494 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.3019580758595608,-16.506574861201727 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.3217353945364028,1.0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.3349512907569179,-0.04875939694812678 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.3418945459470635,0.6953123566076727 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark55(0.0,1.3552527156068805E-20,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.3570685756907048,-58.951940685436476 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4105117007132986,-1.0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.422445648164972,1.0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4261479001680613,-0.6357509332462281 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.445241978190676,1.0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4533394516945606,-2.4677579418653533E-178 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4774999664962467,-1.0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4808306891961993,0.26220557597982386 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.485321144835276,-1.0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4886827727643548,1.0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4900016118395585,-1.0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4909622077269657,-4.0389678347315804E-28 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.491021737868607,1505.648276540698 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4998643435306638,-0.033770169576079895 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999449758626393,-35.33928461862497 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999974705762955,-0.35330689696741685 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999999850536767,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.499999997230821,-0.9999999990533153 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.499999999930847,-77.88236998708172 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999999999999882,-1.0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999999999999936,-95.50416515303925 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.499999999999996,-1.0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.499999999999996,1.0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999999999999991,2223.538589258767 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.7763568394002505E-15,0.03420799054179802 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.7877779172606837E-248,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-2.220446049250313E-16,0.4128682878873518 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-2.220446049250313E-16,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-2.649279453781459E-16,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-2.7653640327674303E-16,0.0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark55(0,-0.33859502261708485,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-3.552713678800501E-15,-1.0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-3.563367286326769E-15,76.30761327041621 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-3.842269542739505E-10,-1.00000000071575 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark55(0,-0.43015659421746877,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-4.67766446739278E-18,0.4849571843023289 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark55(0,-0.5758607695681225,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark55(0.06647397022200185,-0.12097442584666585,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark55(0.07351700444534409,-0.08283136070101753,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark55(0.08569412389812214,-1.2172102186519957,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-9.520656052619707E-7,-19.878234552936 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.0590526617536744,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark55(0,-11.982843220567062,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.2617462701465432,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark55(0,1.3877787807814457E-17,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.476106944002125,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.4999999999999858,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.5,0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.5126596348264596,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.5E-323,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark55(0.16235039175992874,-0.5986531425126351,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark55(0.17136708470760212,-1.1394880782802201,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark55(0,18.554414666581053,0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark55(0.20077281872296737,-0.2258989028229944,0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark55(0,-21.744471970237782,0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark55(0.22209221789173944,-0.9425310877602111,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark55(0,-2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark55(0,-2638.9575399849036,0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark55(0,-2727.756770645344,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark55(0.29219856469433125,-1.3297359972403648,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark55(0.3016567995390851,-0.3211615810737318,0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark55(0.30589832097108705,-0.7234310871806997,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark55(0,3.1459535849623848,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark55(0.33253137493933327,-0.8379496825946404,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark55(0.3507558950516625,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark55(0.36607928089293296,-1.166415787305481,0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark55(0,-37.2051287544124,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark55(0.4021072106104826,-0.7366454441948904,0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark55(0.4121960279156773,-1.499999786430234,0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark55(0.4150546971742847,-2.4148586349323666E-7,0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark55(0.4189545691048727,-0.17463708814504222,0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark55(0,-41.931992304111155,0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark55(0,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark55(0.44978062677469816,-1.50527721864099E-9,0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark55(0.518721996853575,-0.18543925262727834,0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark55(0.5409116430306791,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark55(0.5876613151158194,-1.0202958999131795,0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark55(0,-59.16130498671357,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark55(0.6006846637834622,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark55(0.6017232174998384,-1.2776925354841833,0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark55(0.6077641753685015,-1.4269640932540568,0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark55(0.6245809313543731,-0.15210595686019968,0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark55(0.6433610537614811,-1.3751562003763524,0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark55(0,-64.38999006322086,0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark55(0.6824320393886731,-0.1323321392324316,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark55(0.7223327335702692,-0.7220577016138474,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark55(0,76.21054376318929,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark55(0.774939572755116,-1.27366576330309,0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark55(0.7804061701666427,-1.1914016451745149,0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark55(0.7813973157524146,-0.6623130545137599,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark55(0.7921661178427399,-0.12550127649103615,0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark55(0.8043693065125979,-1.4999999999999574,0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark55(0,-80.4621030584178,0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark55(-0.8375069892695294,-4.984456680707185E-9,-0.008952355647029828 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark55(0.8422306394341206,-1.4735806424346407,0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark55(0.8586905168461101,-0.26504597067470925,0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark55(0,86.263131675289,0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark55(0,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark55(0.9178774965018501,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark55(0.9491937629055085,-1.4999999956432943,0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark55(0,-98.30677579549692,0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark55(0,-9.860761315262648E-32,0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark55(0.9960011040083685,-1.3773423728609957,0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-0.0016406845670644899,0.0023815624843936496 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.0029112434856061187,0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.004193771834795967,0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.004475329730671593,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.023067495172579333,0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.0252788873863799,0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.03083149192415474,0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.0372898359353363,0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.03766452004340193,0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.057641727645593666,0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.07932107798007304,0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.08816060350469472,0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.08906316948353221,0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.09224113676203227,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.10324381004918042,0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.10431880357340223,0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.1191407485348418,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-0.14457547099784565,1.0000000000000002 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.15769334904572752,0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-0.1851873365852299,1.0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.20602904403705213,0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.21559691633247108,0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.2358587841292391,0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.25403266138751057,0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.25643315867380156,0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.27555594166216824,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.2941260502409655,0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.3043979618332573,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.3285389417152449,0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.33736949746109035,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.3813892799020957,0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.38803912141789465,0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.4091859858507645,0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.41975789960998944,0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.43655474980872483,0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.4429230108698603,0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.4759602713629846,0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.48118489518863305,0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.49513338245366456,0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.49575291206295724,0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.5031711738988545,0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.5042086271399879,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.5367146892905149,0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.5525359315287403,0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.5540854351550538,0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-0.5591193794420697,-1.0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.5943373597047702,0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-0.6084509984414914,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.6159188669969788,0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.6698378109317006,0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.6716450308193892,0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.7005488968672643,0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.7437267605173812,0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.755261131296252,0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.7815922016407324,0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-0.7920253077426025,-0.42096324051777856 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.7969369215008076,0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.8024713034776991,0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.8179529331214173,0 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.8439821122281903,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.8451932725143814,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.8572782983367643,0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.8618032218458976,0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.866647257158537,0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-0.8706038202978784,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.9090323086218819,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-0.919757178764282,-0.06255252524251322 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.920557706951254,0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.9329966639057741,0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.9379251701163598,0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.9430495148056954,0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.9585076591264258,0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-0.9707255005589488,0.2969278866090491 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.984587743300908,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-0.9971607396202402,1.0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.003682341710122E-9,0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.039882974902492,100.0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.0437585297684278,0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.055595333146405,0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.076591927515797,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.080179785872306,0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.0973485540919907,0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.1023882685128878,0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.1088161275377884,0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.1308992909116196,0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.1769884078225466E-8,0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.2109751201642251,1.0000001194909482 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.2258040993057626,0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.227147860197775,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.251469888526192,0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.2700335156372162,0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.2772823876573551,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.3071678117834198,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.3194307129239564,0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.336779510003571,0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.3596021214470404,0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.3716854598938264,0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.388585882404966,0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4439860592383489,0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.4536407438720942,-100.0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.4757030651059273,0.9596092054338954 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.483731316309376,0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999309646368473,0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999946357855507,0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999996527484,0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.4999999999548146,-1.0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999651512,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999805,0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999858,0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999896,0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999902,0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.4999999999999916,1.0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.499999999999992,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999978,0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.645935159322832E-4,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.8149007234783505E-8,0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.834117295160436E-9,0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-2.3180871566850882E-8,0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-2.4227577604086336E-7,0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-2.5224165732291288E-8,0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-2.561608636086514E-9,0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-3.513454232138135E-8,0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-4.0552712922893566E-10,0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-4.255608527955532E-10,0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-5.025630928356431E-7,0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-5.551115123125783E-17,1.000000000000788 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-6.748843841334859E-9,0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-7.099528525978654E-7,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-7.105427357601002E-15,0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-9.080961936377112E-6,0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-9.369580647182575E-7,0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark55(10.013404575406113,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark55(10.017057782524901,-0.2630515855600759,0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark55(10.017209850836608,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark55(10.030446213304671,-7.105427357601002E-15,0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark55(10.042994638637452,-0.11660511112340533,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark55(10.098684949965232,-0.9756715935107954,0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark55(10.114646303345527,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark55(10.170328340455654,-1.2701552470215196,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark55(10.199608397830072,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark55(10.21054221890654,-1.184047181185484,0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark55(10.302181764246683,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark55(10.356681227783195,-1.499999999838232,0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark55(10.361904835748945,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark55(1.03626724658664,-0.10336550242552447,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark55(10.386320469841989,-7.372462623108972E-10,0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark55(10.42581967675919,-0.3465579939374732,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark55(10.543532927956365,-0.5353404893463938,0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark55(10.591913329000093,-0.47470458288629214,0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark55(10.619229754798216,-3.734684707833334E-9,0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark55(10.672193005477087,-1.0468408939580751,0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark55(10.682421586385352,-1.119440227043559,0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark55(10.685167102360769,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark55(1.069120793429576,-0.864568653214234,0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark55(10.697389689999468,-0.346294701384533,0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark55(10.702434738503209,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark55(10.728662803339667,-1.0964524987428303E-5,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark55(1.0752653790789748,-1.2627289263826729,0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark55(1.0769889128787096,-0.6870785441138154,0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark55(10.789919083351492,-0.5052152081349428,0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark55(10.864663175503447,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark55(10.869051418101307,-0.5445590603431265,0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark55(10.891777073390841,-0.34314501367251987,0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark55(1.0902397891333209,-1.31570393142046,0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark55(10.955813498008723,-0.9598687507166347,0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark55(10.987670902958442,-0.31747815175744165,0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark55(1.099128684349643,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark55(11.002494377602275,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark55(1.1044110669324763,-1.1142604527279425E-16,0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark55(11.07810945840002,-0.4156314675325143,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark55(11.093767140353428,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark55(11.105932908330768,-0.07446905044591656,0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark55(11.129158705603004,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark55(11.132801195246678,-2.7017249701478716E-8,0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark55(11.153134065671455,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark55(11.194920774557513,-0.7450018651267825,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark55(11.208449382168286,-4.095746107432796E-4,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark55(11.238225395058954,-1.2458616561413494,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark55(11.242907280571785,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark55(1.1253561570790112,-0.7025678737961885,0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark55(11.274152934873303,-9.958683699837305E-9,0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark55(11.291684989220538,-0.260243967528063,0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark55(11.302059056331956,-1.3653899921608372,0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark55(1.130660918842775,-1.4999999971721925,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark55(1.1350371532004164,-0.26492342679301295,0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark55(11.357596992847178,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark55(11.381559837807403,-0.24417637902658285,0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark55(11.38568044655726,-1.1051233922328976,0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark55(-11.39207786316912,-1.4999999999999982,37.12167213282498 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark55(11.398165652518628,-0.6426136197499375,0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark55(11.462068518134998,-0.3975893618115123,0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark55(11.494775493637107,-0.6300935054525747,0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark55(11.544276071371034,-7.855715247797105E-10,0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark55(11.5935490420636,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark55(1.1628147631141144,-1.7355034136454883E-9,0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark55(11.672386211179273,-0.025541673486316085,0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark55(11.697335264312105,-0.8887744538871998,0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark55(11.698183738943108,-1.2790150655272452,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark55(11.732812453590753,-0.20008355582004356,0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark55(11.738382606986875,-1.084657379670102,0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark55(11.831108793385198,-0.20182548849673765,0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark55(11.858216073618301,-7.118923614938018E-10,0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark55(11.866917761102322,-1.165261732207252,0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark55(11.873661802133071,-0.21455257182346316,0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark55(11.87930358518935,-1.4999999998861033,0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark55(11.8886968395296,-0.5100681987162754,0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark55(11.908191056336825,-1.9090970334347884E-7,0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark55(1.1911426667246872,-0.9028885521720129,0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark55(-11.918132200013517,-82.30703535873147,0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark55(11.983655686527129,-0.3311418020054244,0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark55(12.000800944377872,-0.34084343639643055,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark55(12.010783116421635,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark55(12.039623759574653,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark55(1.2058085588234917,-0.04707841743770713,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark55(12.081748875225813,-0.5733681345194128,0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark55(12.109409055706019,-0.2562821914325393,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark55(12.135898991589627,-1.4572071241016133,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark55(12.214402471925418,-0.21877335154483601,0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark55(12.228715958978235,-4.2937847483200206E-8,0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark55(12.266815101630765,-1.0106486658951965,0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark55(12.299131805027457,-0.3102014383334777,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark55(12.321544566221391,-0.0709543011728555,0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark55(1.2339576431866814,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark55(12.339940362992152,-0.7276274720426543,0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark55(12.36359494739332,-0.7458117993268205,0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark55(12.367468575929372,-0.44852370648754825,0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark55(12.387387425710145,-1.4160583091350247,0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark55(12.394362308951852,-1.1827021271627265,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark55(12.444590926429726,-0.24562808358945443,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark55(12.452325221749888,-0.9163131930171957,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark55(12.452394379426735,-1.2424465024702744,0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark55(12.467110564450422,-0.8180906208632089,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark55(12.487424830467214,-1.0599282972444357,0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark55(12.508566152299167,-1.3151293697270982E-7,0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark55(12.530955087865124,-0.4325178331720849,0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark55(12.576930977602856,-0.2692363973620502,0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark55(12.57898331020959,-3.345712609225918E-4,0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark55(12.62512784446757,-0.05625247512116127,0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark55(12.74790861382509,-0.03587583775947678,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark55(12.769454963741111,-0.5949729782582978,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark55(-12.77339162743077,-1.2449375817530088,-0.01456397322702202 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark55(12.784107740423423,-6.414953770927425E-5,0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark55(12.865262884647656,-0.16007649289180392,0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark55(12.8672927920054,-0.047703562647319675,0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark55(12.871997260754261,-4.3549258175984734E-5,0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark55(12.947077144757031,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark55(12.964587352538985,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark55(13.037566199952096,-0.8564975228476515,0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark55(13.052696648423392,-1.7036305243892214E-8,0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark55(13.055936500334212,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark55(13.095505494538926,-1.2518201877433066,0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark55(13.110985255932263,-0.5303324820053241,0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark55(13.166798648984287,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark55(13.19075481654075,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark55(13.254252895753442,-0.6899798965418746,0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark55(13.277296784357809,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark55(13.277718884566397,-0.27880573593408803,0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark55(13.294630590928591,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark55(13.30735179303813,-1.4999996238161728,0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark55(13.31449679301933,-0.21035338732214726,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark55(13.345145390908229,-0.5449502187439768,0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark55(13.347618572960513,-0.19474548727239593,0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark55(13.453021823431605,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark55(13.462515864847944,-0.7291079795774331,0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark55(13.464512167579443,-1.205320763302598,0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark55(13.480877351948749,-1.4576007402229152,0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark55(13.503369020246662,-1.2373885242930251,0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark55(13.528098913131643,-1.4999999999999858,0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark55(13.582104824021826,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark55(13.586422260634535,-0.35405826810363694,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark55(13.590008614940714,-0.3721640684032792,0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark55(13.608677085081098,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark55(13.629269423027822,-0.2778505821221131,0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark55(13.631842047451629,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark55(13.644921006102422,-0.5947912375737303,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark55(1.3652624477451916,-0.03856577109404391,0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark55(13.655536889636892,-0.3358121330248309,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark55(13.724582511473088,-1.2764255619547669,0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark55(13.745627272499888,-1.4764609479299367,0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark55(13.760241333909335,-1.2943380033618936,0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark55(13.76759234088778,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark55(13.838911129666172,-0.8495852546349063,0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark55(13.873687649057203,-0.15558551866050943,0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark55(14.025932887736133,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark55(14.067178882968335,-0.32043305841466463,0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark55(14.07734851292335,-0.6329269550773937,0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark55(14.088657128944988,-0.9678897250519247,0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark55(-14.133894113575623,-0.8586087585516337,-0.9667774485727181 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark55(14.171683078796676,-1.2928422394806347,0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark55(14.185490658502317,-0.7981106378186751,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark55(14.232498624529512,-1.0334625351439684,0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark55(14.271132153949523,-0.24854191683448446,0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark55(14.311225427541572,-0.06290068091874446,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark55(14.319477835524026,-1.499999999999993,0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark55(14.418284452493754,-0.707400575553248,0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark55(14.429174032277174,-0.5368044546565329,0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark55(14.46894837652588,-0.9221342682884615,0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark55(14.472079563131098,-1.0983594525627387,0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark55(14.473050057753838,-0.527467490570757,0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark55(14.484746827866374,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark55(14.498335577315979,-0.8007407947890613,0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark55(1.4597775578431786,-0.08638979393371926,0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark55(14.609512182446437,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark55(14.609535370721943,-0.8348001183524252,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark55(14.665055874568719,-0.40297037911139455,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark55(14.680724784117501,-1.2742987352335433,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark55(14.689985368599594,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark55(14.699887283578207,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark55(14.765008096689968,-0.5487444873664262,0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark55(14.768456980679062,-0.8276566439256996,0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark55(1.4788152327084684E-272,-1.4999999999999842,0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark55(14.835385263742992,-0.9802164579193775,0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark55(14.838363114382332,-0.45049792275002964,0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark55(14.869162383455503,-0.17591886153483313,0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark55(14.896985377307937,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark55(14.903159050864431,-0.46474198710393466,0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark55(14.905168544979267,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark55(14.919799569410127,-1.0766489756108175,0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark55(14.939110284710182,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark55(14.977143980319113,-1.4046461494004063,0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark55(14.984667402817422,-1.0961902219696782,0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark55(15.0412976113657,-2.6891274827606265E-9,0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark55(1.5048584643778509,-1.3011321948708058E-9,0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark55(15.115417711279449,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark55(15.129320156229696,-1.144030112295443,0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark55(15.152912571576277,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark55(15.154785904726051,-0.17754568903196982,0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark55(15.219628595440971,-0.6957005224793475,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark55(15.320783680403636,-0.1690517545368948,0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark55(15.335364839697029,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark55(15.361914495773451,-0.2765174050137128,0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark55(15.400015137482924,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark55(15.435021172688877,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark55(15.458184094827402,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark55(15.519618173504998,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark55(1.5536571280840374,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark55(15.557408411266971,-0.309390839638227,0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark55(15.562528782563419,-0.4109123509871492,0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark55(15.57557827916244,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark55(15.585870996842502,-1.0133527918625132E-9,0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark55(15.60601293299306,-1.2230123101826602,0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark55(15.733818042511373,-1.2152554745901851,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark55(15.754925719599157,-0.1889861693101551,0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark55(15.764783010009893,-1.6325187114445246E-7,0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark55(1.5765383380390574,-0.16990694604437284,0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark55(15.775116215138505,-3.985241444229308E-4,0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark55(1.5780782933967763,-1.4999999958044616,0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark55(15.811414448733643,-0.7713629462210605,0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark55(1.582538023790212,-1.4999175075891602,0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark55(15.832770886639144,-0.5033954036354459,0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark55(15.897986401872075,-0.7802699562447799,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark55(15.939398313709006,-1.4999999999999076,0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark55(15.963921300260724,-0.3154069242944407,0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark55(1.5965261331447387,-0.06817725742092612,0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark55(15.966629990348324,-0.9466170721780562,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark55(15.97448098523158,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark55(15.97840481568874,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark55(16.039300503191495,-0.5558619138038883,0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark55(16.051523838768105,-0.2280249989061076,0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark55(16.07021146457556,-0.7025093681368668,0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark55(1.6074019039962189,-1.028680628982541,0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark55(1.6078322541567456,-1.4348259897975708,0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark55(16.108116107027186,-0.6642804729068246,0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark55(1.612910597234034,-2.2006405641974888E-4,0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark55(16.142107302251347,-1.258813742226812,0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark55(1.620372669380841E-8,-0.06983620912680102,0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark55(16.22254811411881,-0.17486000532510104,0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark55(-16.22438578806687,-1.3624709588224886,8.673617379884035E-19 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark55(-16.26734362988071,-0.09371653274140879,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark55(16.28065308988036,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark55(16.291178928179477,-0.3954066050030274,0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark55(16.314557446164073,-0.7994766533622117,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark55(16.344697156524404,-0.04775712229172768,0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark55(16.387265102244413,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark55(16.40777280576786,-1.4999972029840951,0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark55(16.430861037969752,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark55(16.45059196444201,-0.5391004223342488,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark55(-16.58806785906291,-0.3642760280372004,0.7344227032002806 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark55(16.600117855842644,-5.719287888296338E-5,0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark55(16.635481333097633,-0.0027424819537557356,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark55(16.705484902603814,-2.755039210274004E-6,0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark55(16.72468385492148,-1.3661241402304114,0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark55(16.73160452995515,-0.638009989665207,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark55(1.6775648908092897,-0.6894566007842986,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark55(16.902133995943448,-1.2483900371976318E-7,0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark55(16.98916264673396,-0.32158508569939837,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark55(1.704077302873019,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark55(17.071999020341458,-1.4350999696049076,0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark55(17.093983058057333,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark55(17.110010558090167,-0.6780888288986664,0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark55(17.128489210646578,-0.012665666412573717,0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark55(17.160099521890615,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark55(17.177096147970914,-0.7914590577682067,0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark55(17.288110706993137,-0.18411329200931495,0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark55(17.289011808718072,-0.8888128192324529,0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark55(17.314347687539794,-1.4570495951872777,0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark55(17.50752785582894,-1.15055504679232,0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark55(17.538558061927205,-0.8242302170697595,0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark55(17.557404934530044,-1.043764263190524E-4,0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark55(17.56889989153582,-1.1153530170542,0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark55(17.577469640164452,-0.3854802647348565,0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark55(-17.607112803838945,-1.449172587168382,-0.7745907691921416 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark55(17.624772063151312,-0.7719720723195178,0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark55(17.640601554643045,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark55(-1.7709795780844786,-0.08043590275593071,0.7142237620641876 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark55(17.726371351979765,-1.093213453903875,0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark55(1.7763568394002505E-15,-0.1308011612361497,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark55(1.7763568394002505E-15,-1.0676179596248119,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark55(1.7763568394002505E-15,-1.2602497184455173,0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark55(1.7763568394002505E-15,-1.3462643954583133,0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark55(1.7763568394002505E-15,-3.001453876576981E-16,0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark55(17.7882604090807,-0.7173395534403539,0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark55(-17.852787630419126,-0.015682169408254808,1.8211442005702136E-10 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark55(17.864409393562603,-4.636567209803786E-10,0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark55(17.868301853471294,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark55(17.87852824711605,-5.789335371556282E-10,0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark55(17.891406988781366,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark55(-17.932856029235154,-1.316928331707723,-0.9943982773629788 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark55(17.97024908752624,-0.6037430742658216,0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark55(17.978132892178223,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark55(17.993537313337796,-1.4999999999459945,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark55(17.995717013051802,-1.4999999999999751,0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark55(18.135893804424356,-0.25125246737189616,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark55(18.207214268098394,-1.2454500308976026,0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark55(18.228915674996387,-0.35000608180956405,0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark55(18.238621135079526,-0.13240650331505677,0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark55(18.238759072911165,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark55(18.261567770231633,-0.2847898112702959,0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark55(18.273881767940054,-1.267229701855868,0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark55(18.27876266510171,-0.3866995089407884,0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark55(18.315243448556313,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark55(18.323066285162554,-0.8200721993151983,0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark55(18.337072531891977,-1.4999999998881388,0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark55(18.381005337709126,-1.1705637029085558,0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark55(18.38308609131427,-0.22399948800382674,0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark55(1.8390872332740509,-1.4505447854482212,0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark55(18.395656512436958,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark55(18.402991720124653,-0.3955768144158611,0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark55(18.49011245478603,-0.9630258867706114,0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark55(18.49389667429699,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark55(18.526467945563567,-0.8493880641519524,0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark55(18.569057721998547,-1.1806531009311279,0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark55(18.584160624022104,-0.34031345493556664,0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark55(18.58444098027445,-0.4405425219041845,0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark55(18.60951650875471,-1.1097912423607994,0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark55(18.62921435234604,-0.4066930663221995,0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark55(18.636109850902557,-0.6227874869422808,0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark55(18.691047871759793,-0.9698939539039675,0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark55(18.776550165941977,-1.2001918047024949,0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark55(18.874918937774407,-0.6543636277556069,0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark55(18.932789445657022,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark55(19.038764672778058,-0.11359583720289819,0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark55(19.042738279685437,-0.15752315567238773,0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark55(19.056118975532023,-7.114856601119571E-7,0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark55(19.080156206657193,-0.5185628661331663,0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark55(19.119495309661684,-0.6058860789354947,0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark55(19.121904319598592,-0.8821543499362329,0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark55(19.17628567177504,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark55(19.22608805963601,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark55(19.2739918989245,-1.499999571085093,0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark55(19.29593113159696,-1.0133515481221451,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark55(19.296659562537478,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark55(19.345653488045045,-1.164031768611025,0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark55(-19.35422050790576,-0.22548510043901906,1.0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark55(19.544515974368533,-1.2891134182208273,0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark55(19.545485204305507,-1.4353871362534463,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark55(19.593798927498483,-0.3350200315564017,0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark55(1.9760751376932006,-1.4999999970896096,0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark55(19.761120255494845,-0.9215088226883197,0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark55(19.764055731842618,-0.9485691027123213,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark55(-197.78139895902015,-0.792199261322489,-0.017096064823960627 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark55(19.780371406376645,-0.1959254444813041,0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark55(19.847814804363935,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark55(19.867793954735816,-0.6489139799828738,0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark55(19.869685071725357,-1.0990699473285428,0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark55(1.9888739812226959,-0.9235401589026506,0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark55(19.927388752049936,-0.1264423962602681,0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark55(19.973291357105367,-1.419703859686301,0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark55(19.98994075666603,-0.6635444148416241,0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark55(19.994072835976496,-0.6646451612771411,0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark55(-20.002952899257807,-1.2932499604377554,1.0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark55(20.061256829511308,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark55(20.062073174416128,-0.24854008088893131,0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark55(-20.063163108205103,-0.31681082927364945,-1.0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark55(20.139523125403947,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark55(20.167622616783817,-1.0043084518183942,0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark55(20.174011774811262,-1.1404369136641446,0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark55(2.0190914876594164,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark55(20.199105473810988,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark55(20.21202410220944,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark55(20.24533800554964,-0.5109601468627574,0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark55(20.26375017351623,-1.1532649415434406,0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark55(20.2727442954312,-2.933929079881539E-7,0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark55(20.363029503384112,-1.4783237076654516,0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark55(20.378830744660117,-0.13212046215630724,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark55(20.424363573931032,-0.5834800164418903,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark55(20.45309599356493,-0.10715142586302595,0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark55(20.461495215121843,-0.21338995647906617,0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark55(20.481522567475196,-0.24358815351914131,0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark55(20.499285584646927,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark55(20.507825506591015,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark55(20.518607795638154,-5.749985414646587E-7,0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark55(20.531827860325812,-2.041171142937915E-9,0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark55(-20.5473441689508,-0.27941773333272085,0.02038355339619201 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark55(20.551082818757877,-0.05420635398198259,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark55(20.562870696765728,-0.24471442131485333,0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark55(20.588229184273814,-0.7929518401247151,0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark55(2.0596196953413255,-0.06282249984234789,0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark55(2.065083439039711,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark55(20.677891694047148,-0.4407546800160044,0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark55(20.704254423111692,-1.0304206982549147,0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark55(-20.736374894444793,-0.3696591023565824,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark55(20.818360465591084,-0.8757157918449678,0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark55(-20.84364644780503,-1.0788363772786091,-2405.993194545711 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark55(20.93950028617553,-0.5833883216694771,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark55(20.963678611422196,-0.10424862077380163,0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark55(20.966665117337534,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark55(-21.042061150301656,-0.3375794946036862,-0.8702325339823437 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark55(21.044877614275777,-0.29467935082831787,0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark55(21.111281265419393,-0.9758764753614741,0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark55(-2.1117399545973967,-0.7175254046845017,-93.50076583746699 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark55(-21.196643007860764,-5.614031680325802E-10,-0.9999999999999991 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark55(21.205095778715425,-0.010700786509434457,0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark55(21.21707842207489,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark55(21.264905378737183,-1.3099194765844135,0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark55(21.28026189388335,-0.5538273607436475,0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark55(21.288613040934152,-0.24540132870355613,0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark55(21.296290842982902,-0.1475749618184834,0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark55(21.30836572393079,-1.4999999601497225,0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark55(21.318822839010828,-0.07911755740101256,0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark55(21.33481394968679,-1.0763559740346604,0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark55(21.356807310206705,-0.9952570215950834,0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark55(21.368793386589125,-0.0011025132883819566,0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark55(21.427042212851536,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark55(21.463979885235602,-1.1494206716920072,0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark55(2.149669967552888,-1.2082701135265415,0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark55(21.503166674221433,-0.7485476101104211,0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark55(21.57396601514627,-1.2303030776454307,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark55(21.651608081933958,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark55(2.1684043449710089E-19,-0.7258153974510333,0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark55(21.719739745512577,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark55(21.76889586073831,-0.6399920935773666,0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark55(21.774973594886248,-0.46190212669515507,0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark55(21.80569458944315,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark55(21.81278523766504,-1.3778996679360855,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark55(21.84171357256845,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark55(21.84832040395304,-0.5952633405964859,0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark55(21.849176276632654,-0.20410371608564093,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark55(21.85539005207817,-0.026597767877273637,0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark55(21.869831483665156,-1.4352855529249267,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark55(21.87701496596742,-0.11351688923931968,0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark55(21.877924617837607,-0.5633894716534763,0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark55(21.887623063053546,-0.3997962137495232,0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark55(21.90444211086526,-0.3028612106109755,0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark55(-21.904576739744844,-1.3902922557137825,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark55(21.986455546147376,-0.10281377285566384,0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark55(21.99226468942157,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark55(22.025860875769368,-1.4723338927723595,0 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark55(22.121337391646833,-0.6010143605422797,0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark55(22.122805479662684,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark55(22.147501154993662,-0.9573800805102337,0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark55(22.148183889384825,-0.6077549482521727,0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark55(2.219016390591392,-0.0021024363080741626,0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark55(2.220446049250313E-16,-0.02620349639491172,0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark55(2.220446049250313E-16,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark55(22.208300066475164,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark55(22.211737963247995,-2.3452903118844374E-7,0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark55(2.229603876821912,-1.3307681494550163,0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark55(22.371863072577632,-0.9881785047141778,0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark55(22.398366117967996,-0.9688691419213806,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark55(22.439824045726844,-0.7759380595024841,0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark55(2.25537173669386,-1.1859837664978263,0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark55(22.561481689361955,-1.0420708120096709,0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark55(22.634953302513114,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark55(-22.64967833534854,61.71107004441515,83.54423885054766 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark55(22.653669676841986,-0.010128134130795274,0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark55(22.697693068215514,-0.8419847441234509,0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark55(22.709830746539435,-0.8914207621183496,0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark55(22.72683818803995,-0.27806080742504946,0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark55(22.815816050694693,-1.3020238032909504,0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark55(22.81735678786973,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark55(22.850732066129343,-4.1278974591033736E-8,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark55(2.2940054758032176,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark55(23.031358331059977,-1.4183656742895332,0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark55(23.033270351905387,-0.38224094723251767,0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark55(23.073858143124674,-0.8224688561908489,0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark55(23.076496458266103,-1.4999997221639858,0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark55(23.102029908973677,-0.7060096672080363,0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark55(23.16687316137285,-0.7991689909243576,0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark55(23.177867311316945,-0.27541099887757453,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark55(23.181025477393273,-0.13674907712835224,0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark55(23.182504237925144,-0.27764722388811214,0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark55(23.214474777416868,-0.5261527335404717,0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark55(23.253875694963742,-0.17488553526164874,0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark55(23.262268054291795,-0.6124580787885803,0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark55(23.292177921737505,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark55(23.30538941491433,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark55(23.305480472848657,-0.6744101746989738,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark55(-23.338330279762403,-0.9999566573664751,1.7902710473387344 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark55(23.34941748585797,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark55(23.385139886582834,-0.22311220619823757,0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark55(23.41966441879389,-1.4715100313872016,0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark55(23.427205475280473,-0.6903536483257469,0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark55(23.4478256417127,-1.208781948213129,0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark55(23.448278027797166,-1.499999999173768,0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark55(23.462422768602202,-1.4643860107450557,0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark55(23.525521366502495,-0.8690193975529521,0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark55(23.60456801546585,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark55(23.633127037194697,-1.0374270623915862,0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark55(23.636392977130555,-1.1472934232367114,0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark55(23.65726297483303,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark55(23.694318344232904,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark55(23.774790858691052,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark55(23.775849444228697,-0.8298986866379732,0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark55(23.803687735110586,-0.15470992606864797,0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark55(23.818448934393675,-0.813475796103851,0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark55(23.8601176510586,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark55(23.88037320948672,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark55(23.90572530459456,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark55(23.93396491934522,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark55(2.401349898041869,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark55(24.03196392620805,-0.9146438434636925,0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark55(24.049318653678412,-1.4999999999999905,0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark55(24.138994808334104,-0.20273663053265523,0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark55(24.151110892174387,-1.491949862923012,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark55(24.219777276723754,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark55(24.26392174406557,-1.4606266853645886,0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark55(24.265577348868856,-2.1190036700461782E-8,0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark55(24.363830314775598,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark55(24.407130425671824,-0.3908652813717204,0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark55(24.411866752563455,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark55(24.54044570862341,-1.1894109825494041,0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark55(24.544737553359745,-0.3052448933257354,0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark55(24.575448081147712,-0.10449614510336902,0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark55(24.58300474988772,-1.0868693486060375,0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark55(24.592057353717692,-0.35190518020907113,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark55(24.66872757121112,-0.9379230229849469,0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark55(2.471943617927195,-0.17703122629593793,0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark55(24.731108472992528,-1.4109534119157263,0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark55(24.750398352329753,-0.9832258688148698,0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark55(-24.814710790879882,-1.2688062074888684,74.47168725303197 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark55(24.83257086784112,-0.717578854802023,0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark55(24.923576670528693,-0.4988778618548455,0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark55(24.957616407751942,-0.7546632598584919,0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark55(2.4957731959256293,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark55(24.962723713957487,-0.3071975283563393,0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark55(24.995347662211103,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark55(25.05562462936814,-1.413664720719307,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark55(25.06150400483618,-1.327742502408642,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark55(25.082736336055916,-1.0916020908380295,0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark55(25.091338638271395,-0.16437929542188812,0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark55(25.093738860284162,-0.5241169172806414,0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark55(25.209764158712723,-1.2328620846228944,0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark55(25.223798717826895,-0.4255156687535653,0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark55(25.24394252491433,-0.48598522746802164,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark55(-25.273073310361127,-1.196478767835842,-50.865539402743785 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark55(25.28195309531536,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark55(25.413591483983595,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark55(25.422883247252187,-0.5267531425816382,0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark55(25.42572167933511,-6.255988762108437E-9,0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark55(25.42635747928837,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark55(25.468533715982588,-0.9645778835685661,0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark55(25.53188317582709,-0.29049075524655743,0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark55(25.589938922355298,-0.44502573305316706,0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark55(25.59146581998462,-1.0543988476471782,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark55(25.639527102315057,-1.3666533259625595,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark55(25.650526411876385,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark55(25.6609824558289,-1.2823304859029179,0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark55(25.684609475637153,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark55(25.735812799913475,-0.513462025717544,0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark55(25.75288267850374,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark55(2.5754895860508213,-0.1827519338631447,0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark55(25.782356646519915,-1.44868881639341,0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark55(25.807571272337082,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark55(25.811962391818994,-1.1713627023839912,0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark55(25.841355750211367,-0.05864685627933852,0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark55(2.5857307729618952,-0.8305293263039175,0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark55(25.858714097638895,-0.8143281570482088,0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark55(25.8891541328381,-0.7027138597080702,0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark55(25.959135581427645,-0.09974625877077237,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark55(25.981954080179996,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark55(26.033563552138467,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark55(-26.045441583094338,-1.3964623030712304,0.05842326431940126 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark55(26.06458860163203,-1.468775383796146,0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark55(-26.136490361304723,-0.09706746785192788,-2372.1293480220647 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark55(26.145096196007906,-1.4263840246546509,0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark55(26.146211108866833,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark55(26.147654867424606,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark55(26.172858402953192,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark55(26.188200058810153,-0.27318284282741656,0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark55(26.1979703373931,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark55(26.286900673838232,-1.3388729990202535,0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark55(26.345386915636823,-1.244149368403938,0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark55(26.375688302157368,-0.8407328043982689,0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark55(26.41676093264043,-0.1301127216375637,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark55(26.45118235609304,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark55(26.46816360192024,-0.9737756664798667,0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark55(26.547341845200968,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark55(26.55695195540062,-0.3673045437746021,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark55(26.57239903894113,-0.1005508775291446,0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark55(26.59867561025251,-0.1325315075949507,0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark55(26.617174574089304,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark55(2.6625188674365603,-1.4515213336234591,0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark55(26.63352649495703,-1.0486405209175595,0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark55(26.633875502910698,-0.791566916385932,0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark55(26.668428296286145,-0.8015769007738638,0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark55(26.68652881773985,-0.510531429875428,0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark55(26.787452624185832,-0.361929751048649,0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark55(26.80563026733624,-0.1487834877657659,0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark55(26.80677151089136,-1.4999818368703537,0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark55(26.8073404250577,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark55(26.808283687923407,-1.1013517495486127,0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark55(26.830421285197502,-0.8142572971721336,0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark55(26.836342319887322,-1.1090247756551577,0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark55(26.862878706946418,-0.49097305813823766,0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark55(26.884765737228506,-0.29473940304451673,0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark55(26.91626073695108,-0.9326987778655411,0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark55(26.926657103053955,-0.7084187109077611,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark55(2.694750240978396E-5,-0.07351465869792023,0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark55(26.98761789680013,-1.249916844927771,0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark55(27.0068058692859,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark55(27.032618274738375,-1.4999999947022913,0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark55(2.7040171467269545,-1.2418910216852677,0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark55(27.080862211993576,-1.499999999999999,0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark55(27.094789531590052,-1.4832793299931204,0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark55(27.09943963547015,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark55(27.11466823267665,-0.7792994951651437,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark55(27.118841486198605,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark55(27.13288640737737,-0.9396676435315972,0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark55(2.715679486363868,-1.0014018537151381,0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark55(27.166921682702736,-1.4999999685177772,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark55(27.183507496536706,-1.4999999999999698,0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark55(27.21125754325696,-1.4999999997423896,0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark55(27.29905369057468,-0.32757464256494695,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark55(27.358220983624392,-1.067656506860355,0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark55(2.739455804818334,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark55(27.5425199996302,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark55(27.56286736971037,-0.5889626385622292,0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark55(27.565493875978035,-1.0827220575504832,0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark55(27.601094874813526,-1.099559104589673,0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark55(27.647446500532837,-0.8377919858772604,0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark55(27.75125357087927,-0.7188317097000265,0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark55(2.7755575615628914E-17,-1.562687047950318E-9,0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark55(27.826459359455892,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark55(2.787637013464405,-1.0139202181676241,0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark55(-27.939982334185103,-0.3652423511360714,-1.0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark55(2.797131154143301,-1.2117678331458273,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark55(28.031271883814924,-0.327462115476834,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark55(28.071804232545105,-1.4562647580885884,0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark55(28.07450171995697,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark55(28.089408717924343,-7.467354416310852E-9,0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark55(28.091227666957792,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark55(28.121913314178812,-0.3871323570166233,0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark55(28.125630021415105,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark55(28.134879825662384,-0.279773996603614,0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark55(2.8157756760385366,-1.499999936200055,0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark55(28.17938341810742,-0.6794286262510134,0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark55(2.819139108691786,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark55(28.20016200981157,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark55(28.202070336387646,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark55(28.223327102850114,-0.8427354324466592,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark55(28.258162369332553,-0.020188852692811565,0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark55(28.26451772855124,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark55(28.300257830259174,-0.0016186148265437345,0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark55(28.310897313134262,-1.4928215352806689,0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark55(28.32337672276722,-1.0794034877476797,0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark55(2.833907065998169,-2.402359638872444E-8,0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark55(2.834602729158405,-0.7982324687785176,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark55(28.354126932756998,-0.02881034633373066,0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark55(2.8363404117016415,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark55(28.370400883341425,-0.9918117331518117,0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark55(28.38131052500286,-1.224363605719336,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark55(28.39988910176004,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark55(2.8478990073355988,-1.040038544603488,0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark55(28.4983081887419,-0.46876321313864366,0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark55(28.540212975273022,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark55(28.571864024353374,-0.9785933362341384,0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark55(28.574401461168613,-0.5469051469485815,0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark55(28.58294350147264,-0.6725461039435492,0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark55(28.611846198055957,-0.08987411602504176,0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark55(28.72204930387698,-1.1388224087769955E-5,0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark55(28.725902388138252,-1.0490317313470774,0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark55(28.731177976727764,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark55(28.769590600919514,-0.5479587084827355,0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark55(28.844916614328014,-0.6261343687769454,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark55(28.86451151804357,-0.07487583977460277,0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark55(28.88490379586267,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark55(28.89001505785734,-0.014610182031737473,0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark55(-28.906588598879864,-0.1177617567409627,-1.0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark55(28.92140627162254,-0.6355975399655618,0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark55(28.922589190556522,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark55(28.956636376590012,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark55(2.896210876564396,-1.095312257605344,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark55(-28.976562934334567,-0.6592513821642232,-44.6900599613214 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark55(-2.8977940440741747,50.91004757829185,0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark55(-29.017015275448955,-1.0516385175671985,48.10062923229148 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark55(29.053438365947414,-3.237813745148463E-4,0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark55(29.1349994202576,-1.118699124395718,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark55(29.150420708617617,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark55(29.161452743886557,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark55(29.306210837461634,-0.9895548063963597,0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark55(29.312716814488002,-0.7236753407086667,0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark55(29.342952327886465,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark55(29.41999323233145,-0.0699189247924803,0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark55(29.438275337468667,-0.8826193602324839,0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark55(2.9462481749073035,-0.14711322305652175,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark55(29.503260055857766,-0.07770542176718198,0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark55(29.50463788264733,-0.10439860870094719,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark55(-29.51272917353225,-1.495358114080581,3.765683075318776 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark55(29.55642270799285,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark55(29.592064902610176,-5.740465773175295E-4,0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark55(29.61404755409289,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark55(29.668338586888297,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark55(-29.679755948687657,-1.1752293688746516,-72.0301723914554 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark55(29.713078428076074,-0.9947054776755095,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark55(29.721820214272668,-0.6397075007905902,0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark55(29.722001829492566,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark55(29.744727025569006,-0.6918125001285595,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark55(29.804157752607267,-0.33573890950108654,0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark55(29.84324516181198,-0.5886280735930143,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark55(29.844915610303726,-0.6565675846901375,0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark55(29.864230345706563,-1.3484293012409732,0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark55(29.880965603842608,-7.771075932161762E-6,0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark55(29.934504250969866,-1.4999999999999574,0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark55(29.95218475786868,-0.1131106227526999,0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark55(2.9959999898840977,-0.5347640079443181,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark55(3.004285136983057,-0.4726499847130954,0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark55(3.006401003207028,-0.052757941473538426,0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark55(30.127419181827943,-0.16231550412656226,0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark55(30.13838944567246,-0.05252454329202377,0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark55(3.0145266193196694,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark55(30.177950291788523,-0.347438929380276,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark55(30.211042336452284,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark55(30.212668152458985,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark55(30.216978993896785,-0.03726617334920057,0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark55(30.220371353386156,-1.4907023296093485,0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark55(30.22207574140709,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark55(3.0280034082583,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark55(30.284038235869694,-1.2074676057513765,0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark55(30.287380510119306,-1.488746354149158,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark55(30.29477022718085,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark55(30.3053775535289,-0.8417558318282437,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark55(30.370465530763216,-1.4999998401469625,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark55(30.37377707366326,-2.8758401339562153E-9,0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark55(30.425780993455895,-1.2547458730053471,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark55(30.46978379011793,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark55(30.47529828508908,-1.2871531324462993,0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark55(30.664251340863416,-0.07546416358264718,0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark55(30.69730642492179,-1.4098879096937114,0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark55(-30.70271665953304,-0.5089493054607981,-0.7878919643567377 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark55(30.715576478136217,-0.21346171377446743,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark55(30.800834687703777,-6.926042316066028E-10,0 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark55(30.810170833893732,-0.5400479238560436,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark55(30.817311790318087,-1.2661416986213068,0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark55(30.8342968104046,-0.06585361697875691,0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark55(30.86005202609842,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark55(30.922428295522593,-6.901361480855111E-9,0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark55(30.966360478322848,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark55(31.19811755034482,-0.48088751660608864,0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark55(31.201431004823633,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark55(31.24497829695983,-0.8670186225452854,0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark55(31.26670507425041,-1.0590526901429058,0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark55(31.291882636174023,-0.03533190160953836,0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark55(31.36367882759537,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark55(31.395716699110952,-2.1695216044135477E-9,0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark55(31.4125517793712,-9.50414972505087E-9,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark55(31.4159855755031,-1.3825525846557913,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark55(31.49167545104413,-0.3641939814163777,0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark55(3.1517999542821795,-7.538465609086352E-8,0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark55(31.53177292770397,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark55(31.57671379285233,-0.2156209191311799,0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark55(31.582041361504526,-0.2375511758094666,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark55(-31.655650140397526,-1.095195483301578,0.0017187120552327184 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark55(31.656441937931476,-0.16946867002610555,0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark55(31.67040590161386,-1.0656745331357111,0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark55(31.67871671120693,-0.3242483451606004,0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark55(31.706384264285674,-0.740250597928584,0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark55(31.708988991481817,-0.04489449141122748,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark55(3.171264758649926,-0.4599021674760735,0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark55(31.739072800206248,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark55(3.1762379756292063,-1.4057803722119022,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark55(31.77403146151085,-0.18139397810738328,0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark55(31.77586064005615,-0.9055290388341471,0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark55(31.791533449433263,-1.494026478465507,0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark55(31.907711705880303,-1.027990066154544,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark55(31.933722245136344,-0.3976050890241286,0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark55(31.95713392599928,-0.0016584572408498205,0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark55(31.961331996418693,-1.157685661085111,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark55(32.00308074737475,-0.7229334987567737,0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark55(32.01332432272321,-0.5603835427915573,0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark55(-32.05622478385122,-2.220446049250313E-16,-0.6058551764227946 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark55(32.06195757814524,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark55(32.06588976711922,-0.8653200621076431,0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark55(3.211364489801838,-0.06110179659162736,0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark55(32.15629628070397,-0.6283050176425391,0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark55(32.20648597195182,-0.7439404616063143,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark55(32.275270509741404,-0.41851543264009905,0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark55(32.34412177012538,-1.438433663303897,0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark55(32.38032469185379,-0.6310020698350498,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark55(32.38540123076305,-1.0934708397097452,0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark55(32.42408729690024,-0.8128458831310847,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark55(32.426969738595574,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark55(32.4486944144916,-0.8640952332967329,0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark55(32.453294998126694,-0.9176778046947134,0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark55(32.4641493908728,-1.3952743755759809,0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark55(32.478723298954435,-0.784956491083058,0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark55(32.501618400808894,-1.2756922978037284,0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark55(32.546861529048755,-1.2395500241694464,0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark55(32.574623912819725,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark55(-32.59579259022768,-1.2537771660494575E-8,27.320685469692854 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark55(32.61470728542133,-1.3288033242482409E-6,0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark55(32.617505396392175,-0.6555303579520739,0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark55(32.674657245860715,-0.056745226069022825,0 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark55(32.68494812776405,-0.5694714201755681,0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark55(32.729500531812505,-0.4177191595418037,0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark55(32.77135588346573,-0.4170169946796666,0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark55(32.795804720953235,-0.5075300533422726,0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark55(32.797926056902774,-6.964054397096932E-8,0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark55(32.86461681378972,-0.701695157049572,0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark55(32.8770922640843,-0.11074580788501343,0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark55(-32.89719465014196,-1.4999999999999982,0.7116354167629826 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark55(32.942214875614894,-0.04326535353225669,0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark55(3.3010023783155873,-1.2671812687067572,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark55(33.082911432442835,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark55(33.086244060925395,-1.102766918149455,0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark55(33.091510177615945,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark55(3.3109987230939586,-1.3850212673500568,0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark55(33.173917455405736,-0.5449896381636739,0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark55(33.196883858865505,-0.9411440196166438,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark55(3.3251056823973926,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark55(33.26297829361622,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark55(33.39989595022041,-0.30122227552500425,0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark55(33.40512159909181,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark55(33.40990603898669,-0.25595404318828785,0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark55(3.3418975450474235,-0.426779074315916,0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark55(33.45962834892944,-1.05148409026351,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark55(33.50245715711054,-0.7902320858353887,0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark55(33.56350826892695,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark55(33.60749721345212,-5.90228141640697E-8,0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark55(33.64232743137145,-1.2742950452984058E-9,0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark55(33.65629276871826,-0.44363397719699993,0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark55(33.74972746828439,-1.1942970559664063,0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark55(33.787112374059234,-1.1003744795020958,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark55(33.826965559967704,-0.6115730997010189,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark55(3.3859260432129474,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark55(33.913405417547374,-0.47319493931659135,0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark55(33.93686152315914,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark55(33.970727085591506,-1.6576794069861677E-8,0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark55(-33.986996975829875,-0.35832595863747524,4.189933953326798 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark55(33.99809879023575,-1.062644903637539E-4,0 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark55(34.0147299579665,-0.06406003504038443,0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark55(34.030090778128276,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark55(3.4067226832383906,-0.5410585977029854,0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark55(34.095731195557555,-1.371221264322865,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark55(34.20484607598627,-0.15176187704277178,0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark55(34.22530126112941,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark55(34.24490428022716,-0.0657614323735074,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark55(34.276890288202054,-0.5312452592045451,0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark55(34.30213881035715,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark55(34.31399676321098,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark55(34.32321386098321,-6.976262255160702E-4,0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark55(34.39188173622861,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark55(34.42098705427486,-1.2774805902242585,0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark55(34.439078646621496,-0.8537706681379897,0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark55(34.44287101944087,-0.1524121262744984,0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark55(34.471105700174036,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark55(34.47818952715485,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark55(34.51684085014719,-0.40870788505886735,0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark55(34.55909989921565,-1.132286489414568,0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark55(3.456207620764388,-6.42436386947462E-5,0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark55(34.56847278143717,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark55(34.62587085526738,-0.19843184987281393,0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark55(34.634081982423936,-0.7425317222692325,0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark55(34.63481495789071,-0.8893509245086761,0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark55(3.463544263534061,-1.4999999999732123,0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark55(34.64216221174175,-1.4862083934470878,0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark55(34.683495255871236,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark55(34.75996371963571,-0.05365194912328164,0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark55(34.83280357744036,-0.21272295884540515,0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark55(34.88595039678063,-1.2855391959734703,0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark55(34.90462166674803,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark55(34.98881036259256,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark55(35.08749770006097,-1.4496536968210034,0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark55(35.137398051530525,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark55(35.15747858067847,-1.291821101977538,0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark55(35.189285594975814,-0.1750652896630669,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark55(3.5189469434418257,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark55(35.19130194762039,-1.3515194279106737,0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark55(35.201897812787564,-1.2927941535655747,0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark55(35.22366751962102,-1.245902239715079,0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark55(3.5243083615363253,-0.330859723705766,0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark55(35.255280058669655,-0.8641371305018559,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark55(35.291637029446775,-0.38980570443394846,0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark55(35.3401606304894,-0.06282306699542003,0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark55(3.534632378829097,-0.515256358443728,0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark55(35.37169642921694,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark55(35.396252999826146,-1.0493967307779055,0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark55(35.41743963228541,-1.1580479673404984,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark55(35.428043728148594,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark55(35.44630961779319,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark55(35.46430161578406,-2.5571180906990817E-9,0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark55(35.46656324409878,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark55(-35.5143873430534,-8.718940240880797E-10,-39.10633573376309 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark55(3.552713678800501E-15,-0.5726810133909597,0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark55(3.552713678800501E-15,-0.9700374592838886,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark55(3.552713678800501E-15,-1.1790827309776661,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark55(3.552713678800501E-15,-1.4937471084595781,0 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark55(35.553662191064234,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark55(35.55769911967637,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark55(35.60676832391989,-0.33495271186946596,0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark55(35.675224158331474,-0.9318384992764521,0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark55(3.5686988017857857E-4,-0.5190550774458451,0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark55(35.703978662554704,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark55(35.74171102370468,-0.3400605449880501,0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark55(35.79409182212376,-0.1963239139805495,0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark55(3.5840346164766004,-0.3064262718389017,0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark55(35.84797416790724,-0.2395748761033304,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark55(35.87476604516385,-0.35396907732468275,0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark55(-35.9119252658747,-3.639685638660973E-9,-38.54827889039801 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark55(35.932822486055755,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark55(36.05944425080288,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark55(36.12587377555204,-1.470815861135538,0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark55(3.613248718507748,-0.6979454600653519,0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark55(36.20148007905087,-0.5475095214838035,0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark55(36.20789682783695,-0.8627923563048268,0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark55(36.24270489201464,-0.4859792254865867,0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark55(36.25656852090837,-2.417847686056898E-8,0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark55(36.263467195282914,-1.4999999999999432,0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark55(-36.35559207133379,-1.4999999999999991,-1.0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark55(36.3838646596746,-0.02052016973786408,0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark55(36.42605484242159,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark55(36.47837394444383,-0.5058864618227208,0 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark55(36.49297981485395,-7.687107222940517E-10,0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark55(36.50159577205551,-0.5781153600309117,0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark55(36.5231650300702,-0.5676154687823498,0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark55(36.523172636073156,-0.587696699770131,0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark55(36.67373413783113,-4.230217472489328E-9,0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark55(36.7401320826138,-0.2407182242131105,0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark55(36.79784518393711,-2.2264364071736594E-5,0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark55(36.80187033132208,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark55(36.81704623101817,-1.4999999999999751,0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark55(36.8243475096879,-0.8888049448993058,0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark55(36.844682462288205,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark55(36.86024419320335,-1.2491001909953917E-6,0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark55(36.870260941990324,-0.8815158606965614,0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark55(-36.8804639206478,-7.50595903272123E-10,1.0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark55(3.6921379185984193,-0.07592422738935606,0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark55(3.6931070030934166,-0.7651415771614722,0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark55(36.940260130772124,-0.8379839502137258,0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark55(36.97135154343698,-0.9238542297528358,0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark55(-37.009716562978355,-94.59519343898263,50.74106148163341 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark55(-37.031106203914945,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark55(37.03225510006777,-1.4999999999999813,0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark55(37.08339037495258,-4.177809798141239E-9,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark55(37.099639761024605,-0.2359517210424446,0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark55(3.713751030550142,-1.009202032532258,0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark55(37.15120038503338,-0.4376465973555141,0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark55(3.7170808680536425,-1.1273183090197318,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark55(3.721147010520113,-0.38704154861924867,0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark55(37.247861240956624,-7.757282378303537E-7,0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark55(37.25530234907083,-1.4861302971669357,0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark55(37.31666482939886,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark55(37.326365833440825,-0.5204195978524302,0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark55(37.37685187606239,-0.9640955677797729,0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark55(3.738500798104738,-0.5868519619809405,0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark55(37.399594863599475,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark55(37.435994913012735,-0.4292803691471465,0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark55(37.47722806577386,-1.4999999999999183,0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark55(37.47897862418111,-1.2381239926727514,0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark55(37.51594026548561,-4.803226387322759E-9,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark55(37.55324864449932,-1.057870222267951,0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark55(37.645978326184235,-1.126239349934937,0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark55(37.70354313796909,-3.0521837965630026E-7,0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark55(37.73427344756326,-1.3829672670631226,0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark55(37.740122106285355,-0.575358604666051,0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark55(37.74732251574752,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark55(3.777362292115484,-0.5482004607389968,0 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark55(37.78085756008708,-7.518187240139085E-4,0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark55(37.79204691247034,-0.044500383836878044,0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark55(37.84536152389967,-0.11933207378547017,0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark55(-37.88095491907631,-4.3679317476936506E-10,30.53347934476169 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark55(37.91118830787181,-0.06157433817407826,0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark55(37.95004477242981,-1.46324470267645,0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark55(38.00856731674739,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark55(38.05741498711103,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark55(38.17142938117573,-1.4999999999998117,0 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark55(38.2140929338478,-0.051054324580772636,0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark55(38.23743416493434,-0.44248490153487263,0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark55(38.325542004745664,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark55(38.39876682981066,-0.9726096944185372,0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark55(38.408598277510656,-0.6518658582460463,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark55(38.443335867052056,-1.3881122716849301,0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark55(3.845660463134401,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark55(38.473156062082666,-0.5295895631003447,0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark55(38.488223428127014,-1.14552045051542,0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark55(38.50519747180485,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark55(38.54301039544421,-0.3445758997196628,0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark55(38.54635605851146,-1.1841568678205903,0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark55(38.58355286469751,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark55(38.6066129850994,-0.903561161548937,0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark55(38.62179760791785,-1.0053334838274486,0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark55(38.68748396803946,-1.1287601055043126,0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark55(3.8722018943261296,-1.0252663741485453,0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark55(38.73501753008705,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark55(38.73578665071941,-1.4999999949330607,0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark55(3.8768496807868136,-1.3615571119532426,0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark55(38.79383591400554,-0.5087300330718504,0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark55(3.8810903231360663,-1.2102883698668297E-8,0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark55(38.85398917040894,-0.32820102861944345,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark55(38.88906639989554,-0.6303296982957818,0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark55(3.890629475849576,-8.125089303653194E-10,0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark55(38.954515473765966,-1.499999999921207,0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark55(39.02833482870449,-1.1657257588911454,0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark55(39.0306195678041,-1.4999999999569638,0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark55(39.0611462815441,-9.53943375117435E-9,0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark55(39.13316338089342,-0.12715870749799105,0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark55(39.140528406727036,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark55(39.20246567525611,-0.21141544982630223,0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark55(39.20702709440639,-5.053084793203735E-6,0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark55(3.92258480686373,-0.2756568906638517,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark55(-39.26861880973087,-0.7552820845696132,1.0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark55(39.30614672792024,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark55(3.9341051856171703,-1.3040805104837006,0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark55(39.342635102467284,-0.903427469735222,0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark55(39.41502245985379,-0.3561784428933841,0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark55(39.422473502614615,-5.171074653050855E-7,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark55(39.51275969990813,-0.33605607710107854,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark55(39.51750057684819,-0.5506328565748704,0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark55(39.56893178463582,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark55(-39.60144530934906,1.6230314941093553,-25.0896328064875 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark55(39.6556267516454,-0.8316642342977918,0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark55(3.9673764649866996,-1.069559063096643,0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark55(39.76421148089263,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark55(-39.820697640969414,-1.1113315156812829,-1.0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark55(39.867108964685535,-0.7492583893906393,0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark55(39.98245245859903,-0.8651076755983986,0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark55(39.99802224329434,-1.3554184294777647,0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark55(40.02463642319657,-0.04769248254137626,0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark55(40.06528239418793,-0.42588552415125136,0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark55(40.105436195229714,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark55(40.14530377481046,-1.3499768066707363,0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark55(40.25304112350827,-0.9485488775780921,0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark55(40.311857410791184,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark55(-40.334754379560955,-0.19621481844179467,-1.0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark55(40.34831904948516,-0.9798093860896456,0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark55(40.371704078082246,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark55(40.391925041945825,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark55(40.39251938163896,-0.6334115545207308,0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark55(4.039927565570551,-1.465357551352305,0 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark55(40.440825488045284,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark55(40.47327337147334,-0.17962583601163676,0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark55(40.50319507786725,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark55(40.56002270147482,-0.13627315125372963,0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark55(4.05711800998813,-1.2583777365538964,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark55(40.57844772685835,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark55(40.64048425924611,-0.010626660398969534,0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark55(40.653574760771136,-0.3828594723208702,0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark55(40.66185273037735,-0.1946586545298239,0 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark55(40.70383562709628,-0.6603298722064608,0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark55(40.78367350797433,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark55(40.791992412274524,-0.7440296674336331,0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark55(40.81196223829539,-0.5414551545927191,0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark55(40.863329606169685,-0.038257176253257974,0 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark55(40.871431266193895,-1.1416396865427922,0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark55(40.9074791924925,-0.4587666608795615,0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark55(-40.910374509574694,-1.4891055252038468,0.0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark55(41.010817412172116,-1.192352462473728,0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark55(4.10646472122413,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark55(4.109555082159972,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark55(4.111688793884982,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark55(41.139410693509205,-1.058220565289452,0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark55(41.15599124486874,-1.8720289702302304E-9,0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark55(4.1175533838168565,-1.487712631489173,0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark55(41.31785759928839,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark55(41.34225613326147,-0.04437589728094702,0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark55(41.34677274514863,-0.07776607122631995,0 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark55(41.381596201638786,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark55(41.38919890990559,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark55(41.42249667002643,-0.011875079105139186,0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark55(41.44274154185041,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark55(4.150533583920455,-1.499999999999993,0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark55(41.548874649281885,-1.4999999999997797,0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark55(41.55081985453347,-0.8192361556082295,0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark55(4.155956069958304,-0.2698673676926553,0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark55(41.59884970336641,-0.023761965082960454,0 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark55(-41.62142971363812,-1.0190039189053768,-0.9999999989429169 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark55(41.63476604275843,-0.9846937339398176,0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark55(41.68880807278511,-0.852620484965378,0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark55(-41.69338251307894,-0.2526058581803892,0.989634450330759 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark55(4.182468783669435,-1.217847497958684,0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark55(-41.825631019898104,-8.881784197001252E-16,1.0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark55(41.85306003716863,-1.2889154016154691,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark55(41.86978329097098,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark55(41.93279459837211,-0.835778471753784,0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark55(41.937687256984304,-0.9140177082335059,0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark55(41.94414757284065,-1.1363630348924293E-9,0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark55(42.00952713194894,-1.4361064699817476,0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark55(42.085188041697506,-0.3277308288595564,0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark55(42.09931789221122,-1.1508360527007486,0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark55(4.210602874399585,-0.22054867351414775,0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark55(42.124504999829696,-0.2589356693617617,0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark55(42.18771044124051,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark55(42.192251884603024,-1.0518502867126303,0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark55(42.36813685022719,-0.8726911858619069,0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark55(42.40842903390589,-1.4448468948575874,0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark55(42.4919512841021,-0.5056460105627139,0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark55(42.49210808864428,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark55(42.535978211712155,-3.687162551737153E-7,0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark55(-4.26239470782443E-255,-0.003964771009896586,0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark55(42.62941398387966,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark55(42.64614928858458,-0.19178225153738993,0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark55(42.665593314775805,-1.3587956110272381,0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark55(-42.785809890383234,-71.02736386768922,-84.028960113623 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark55(42.789458734932616,-0.14949848325900283,0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark55(42.795824700451135,-0.6026266463536238,0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark55(4.281695687586558,-1.4999999997506088,0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark55(4.28258748901564,-1.4826319531712508,0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark55(42.83024640880339,-5.389774332132523E-8,0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark55(4.290250132238938,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark55(42.97347130876375,-1.0820208544247743E-8,0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark55(42.974799019592155,-0.06252769321405793,0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark55(43.002639456794526,-0.06551554558073659,0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark55(43.01427604745403,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark55(43.02411473264931,-0.6173716904455344,0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark55(43.06161470997591,-0.807444216239773,0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark55(43.16235618294154,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark55(43.20799510445258,-0.7285995935158747,0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark55(43.226044903336685,-0.3875028472596944,0 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark55(4.3271407286270716,-54.1424576114558,65.29328520518953 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark55(43.32509476653601,-0.21177437493877038,0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark55(43.36612017295866,-1.1931591848921252,0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark55(-4.3368086899420177E-19,-1.1951632514015849,0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark55(43.41973400888478,-1.1936834138281576,0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark55(43.44667051259953,-0.225170464370001,0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark55(43.49781175202452,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark55(43.506363398394114,-0.2378023461934234,0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark55(43.51816603115162,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark55(43.53236070961307,-0.5434476278478044,0 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark55(43.54102012870345,-0.44957094619340365,0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark55(43.57229486205793,-0.23528755918340494,0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark55(43.59234422117821,-1.0551611221066395,0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark55(43.59819360983237,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark55(43.68288358199926,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark55(43.69884448217212,-0.9648292066981643,0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark55(43.700396044480954,-0.8092706592921941,0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark55(-43.770444851671535,-1.4999999999999991,0.0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark55(-43.78921226909607,-0.23731509429808179,-1.0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark55(43.81145309954534,-0.33114535187781136,0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark55(4.381957896486924,-0.4570385071870732,0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark55(43.82222362809354,-0.8607967953277159,0 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark55(43.82406625428911,-1.499999999999993,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark55(4.382575646970366,-0.8023350667592828,0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark55(43.842828195666236,-0.15394727050047763,0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark55(43.879963085164746,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark55(43.89654563355785,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark55(-43.99770050573002,-0.6087462896797932,97.82614528339596 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark55(-44.00835354514861,-1.4999999999999998,-0.9999999999999998 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark55(44.04557541368541,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark55(44.09023198798195,-1.4810669457238337,0 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark55(44.101106867315906,-0.507901306318369,0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark55(44.12733379568141,-0.8475228277370981,0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark55(44.15282626344478,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark55(44.15349902841191,-0.21721803483734012,0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark55(44.23223723652498,-0.997429684963645,0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark55(44.247353176746344,-0.9529580150678472,0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark55(44.27313097269171,-0.02030546218963536,0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark55(44.297707503175445,-0.5433390576197832,0 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark55(44.298101878214354,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark55(44.30989244393215,-1.2090485277298528,0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark55(44.33551634387055,-0.003433062996884173,0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark55(44.3493240435122,-0.8345367737416751,0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark55(44.39632491727815,-0.6029482608216625,0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark55(4.440892098500626E-16,-0.19264410546549293,0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark55(4.440892098500626E-16,-0.7576684081398497,0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark55(4.443747178325489,-0.22945929265822634,0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark55(44.474079496211544,-0.9727648376280156,0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark55(44.48849083137889,-4.097244530606445E-16,0 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark55(44.49751323621942,-0.6009677430628494,0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark55(44.525779163506385,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark55(44.55411553647585,-5.2475169809148406E-5,0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark55(44.64040686720742,-1.4121062199032153,0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark55(44.655583924260426,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark55(44.679746414846306,51.03684029574546,41.773762815784494 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark55(44.680408761129456,-1.172891998891499,0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark55(-4.473326030835861,-0.9937110654346377,1.0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark55(44.73933820264773,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark55(44.75849620496048,-3.193043893445814E-7,0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark55(44.75903890028121,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark55(-44.82413317260694,-1.3386983764744134,0.0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark55(44.84692505456559,-0.8633758667118911,0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark55(44.8947078382855,-1.1561282586413462,0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark55(44.92325835016345,-0.21037567755717945,0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark55(44.94341773381271,-0.5836551833532457,0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark55(44.972239516769385,-0.1464597672324941,0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark55(44.99815142101738,-0.7713472783571973,0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark55(45.036534026953206,-0.14142656475185333,0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark55(-45.090550595354706,-1.0046939357670133,0.9999643362156382 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark55(-45.1210748779155,-1.3482226040008953,-1.0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark55(45.171644373321925,-1.2831723745021648,0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark55(45.22692909625985,-1.3979297958310983,0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark55(4.525113434297371,-1.4999999948844027,0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark55(45.456904380323806,-0.22856908615864224,0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark55(45.50156146008257,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark55(45.51656009300126,-0.8475725067778832,0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark55(45.63600453905016,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark55(-45.73302162259196,-0.15474974060009644,71.77942778079623 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark55(45.7939224521445,-0.2678344917800713,0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark55(45.893991592785454,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark55(45.92865193582537,-0.20372350629583993,0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark55(45.94998409727157,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark55(45.98163970113768,-0.3470761269129179,0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark55(45.98737288823068,-1.4080217259027488,0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark55(45.98945178334258,-1.6840203898144843E-8,0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark55(-46.02478631501514,-1.4436719359099914,-0.5062421786585372 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark55(46.057449775033085,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark55(46.111910876235385,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark55(46.11418934741383,-1.3839698395913924,0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark55(-46.31319216072259,-0.42852811735723395,-1.0000000006340382 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark55(46.317035283417056,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark55(46.34387743801753,-0.5048345945663613,0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark55(46.35765071430788,-0.6300017974558578,0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark55(46.40428881233893,-5.329172642292174E-9,0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark55(46.44468958664268,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark55(46.54580782384012,-0.17893100170228105,0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark55(46.57984097820366,-0.5579834155351726,0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark55(46.70562373940314,-0.9388019589482113,0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark55(46.73553119156449,-0.3617029115898731,0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark55(46.774315121832046,-1.3497167437270097,0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark55(46.78040681573842,-0.0981213421206113,0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark55(4.68344795737465,-1.3814101030221366,0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark55(4.684399955987772,-1.197068670113154,0 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark55(46.88085022305032,-0.3562639625120423,0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark55(46.88182598004326,-0.7583459337080711,0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark55(46.882207297826426,-1.001567012732707,0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark55(-46.882913352551505,-0.9470808382976443,-24.70375797139323 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark55(46.900145552072644,-0.5698124154438995,0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark55(46.92301082514331,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark55(46.926146059418954,-0.7221076860682736,0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark55(46.93987521869552,-1.44169482387601,0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark55(46.9630526958516,-0.1726965757053205,0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark55(46.99585205303882,-0.14377661597008462,0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark55(47.00249990571035,-1.2779725923615501,0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark55(47.03820895531979,-0.11970855543317782,0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark55(47.11229881404762,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark55(47.130719154734436,-0.11258379320497376,0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark55(4.714694941411482,-1.9647105210779443E-4,0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark55(47.19034783576839,-0.7099540073403516,0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark55(47.196778301294984,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark55(47.23109287447781,-0.6886195124050971,0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark55(47.302150122364026,-1.3788599573369535,0 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark55(47.34028859002026,-0.8097943834439381,0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark55(47.37635271710538,-0.03960627916420201,0 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark55(4.748489575959567,-0.30796723876178783,0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark55(47.52867556826678,-1.0466021813193223,0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark55(47.537187645102065,-0.5828467137529113,0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark55(47.54380460751361,-0.7097997763810664,0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark55(47.55157498474321,-0.655370947317824,0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark55(47.565030202128966,-0.07840024423614489,0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark55(4.757851992117619,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark55(47.676263252638364,-0.08872877162687082,0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark55(47.78230947463456,-0.5691511808168901,0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark55(47.78571059231973,-1.3821713657065002,0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark55(47.80779637832228,-1.2604423539609217,0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark55(4.78290650143941,-0.6948836434237273,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark55(47.885684708756486,-0.6185421047716246,0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark55(47.92992304166674,-0.007202975211725138,0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark55(47.953195027188286,-1.310615869391009,0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark55(47.97353257493832,-0.36014319132990824,0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark55(47.97542781966593,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark55(47.978272389422365,-0.0013560670920096385,0 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark55(4.798720553739216,-0.3212723425102588,0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark55(48.00716438952291,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark55(48.01095017921014,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark55(48.05454425220907,-0.9697793663850183,0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark55(4.80878797246416,-1.1036896820205016,0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark55(48.115314052502214,-0.8213214390599575,0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark55(4.81919450720452,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark55(48.24243663344397,-4.310783076015144E-9,0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark55(48.29331715459438,-1.0087662418341603,0 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark55(48.370164949435065,-0.23774458366707324,0 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark55(48.38589658464063,-0.4267951127144398,0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark55(48.420544719001214,-0.3675410274407349,0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark55(48.43581476408869,-0.5383416102304492,0 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark55(48.44340782145801,-0.8121257225434395,0 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark55(48.504635174559816,-2.6769850621417255E-9,0 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark55(48.508248800080366,-0.3578514742861074,0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark55(48.52159647702872,-1.19185439654427,0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark55(48.53293347269012,-0.16886817467748338,0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark55(48.53818366273225,-1.4603371356465225,0 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark55(48.60355414260784,-1.2054275302216209,0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark55(48.61089713712056,-1.4489055931592223,0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark55(48.68737174226258,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark55(4.872499139876634E-17,-5.651630971780078E-10,0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark55(48.72918054882303,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark55(4.874848140757734,-1.2119238746525838,0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark55(4.879107411160426,-0.5294481055143612,0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark55(48.80576974487491,-0.809732295495877,0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark55(48.85399963054874,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark55(48.86157572903758,-1.4999999999999858,0 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark55(48.87823597620584,-0.367180015450008,0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark55(4.895641029268997,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark55(49.01756706269771,-1.0028549921429182,0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark55(49.04286509428667,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark55(49.04384549506648,-7.970275018460103E-10,0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark55(49.06203883824948,-1.4999999979640828,0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark55(49.15833001157452,-0.32688718266882133,0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark55(49.26034202900844,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark55(49.267768979929556,-1.4811312516066244,0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark55(49.2877059201262,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark55(49.29184734163643,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark55(49.298572013291235,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark55(49.29876207251292,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark55(49.31335548746267,-0.48343126917660584,0 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark55(49.3296197188651,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark55(49.33853298013881,-1.0115197928379143,0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark55(49.342488611144546,-4.353929217997066E-9,0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark55(49.36224177545633,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark55(49.408038856246066,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark55(49.48740636407766,-1.0776977097116855,0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark55(49.52902498836011,-4.608334633037868E-5,0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark55(49.552043783456526,-1.3633748792605962,0 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark55(49.59615306951366,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark55(49.66773825709049,-0.2378723247959783,0 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark55(-49.715557244979706,-1.3863399573646493,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark55(49.771319518425514,-1.0923168374514511,0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark55(49.79476572735044,-0.599059850929379,0 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark55(49.81856757733853,-6.938893903907228E-18,0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark55(49.88874346761048,-0.49893956446803367,0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark55(49.894364216744066,-0.6591950559053874,0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark55(49.90063822807812,-0.0063993917425175795,0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark55(49.90244276528989,-1.1542285487311333E-5,0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark55(-49.9278104946937,-0.19736899977267786,-0.6374677569809322 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark55(49.94083872626004,-0.5761435542730862,0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark55(50.01089511545969,-0.7929467362994429,0 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark55(50.02662368018724,-0.7338309176952991,0 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark55(50.06283097929233,-0.11909493464180287,0 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark55(50.08675666185939,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark55(5.016844982135263,-0.22745334230792444,0 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark55(50.248111041400236,-1.3072123444288954,0 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark55(50.34031124251752,-0.27747192429781986,0 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark55(50.36380776523569,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark55(50.441355915971116,-1.172265329315918,0 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark55(50.463521257762196,-4.273111793683196E-9,0 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark55(50.4652259231312,-2.2749252051099277E-4,0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark55(50.49435306653717,-0.13874060420545842,0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark55(50.49939038239364,-1.444408576255963,0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark55(-50.505125225710465,49.058925872227775,88.30541818683301 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark55(50.51166359872161,-0.29359571932616413,0 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark55(50.51323782399962,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark55(5.051934817874454,-0.23184374312480682,0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark55(50.52623661346652,-3.3070563585608035E-8,0 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark55(50.607573653516255,-0.5534749320979755,0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark55(50.637324937050764,-0.9531181970852676,0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark55(50.64839798442952,-1.1272737833186572,0 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark55(50.64906943716278,-1.499999999999984,0 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark55(50.69222191665843,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark55(50.83174028663301,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark55(50.84361490507959,-0.7562825535450344,0 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark55(50.90934671293493,-0.2214645228491463,0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark55(50.91771894876061,-1.4999999999999905,0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark55(50.94524808836488,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark55(51.038134767000884,-9.258301141444868E-10,0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark55(51.06268177681011,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark55(51.09098514111611,-0.3218147673037686,0 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark55(51.12910627513622,-0.9228596227833208,0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark55(51.226245169628136,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark55(51.25537485609263,-0.15594678345073384,0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark55(51.26082134203881,-0.08442737728702365,0 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark55(51.324434980299884,-1.1297150433896208,0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark55(51.400185984870376,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark55(51.4397288364294,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark55(5.146180384414752,-1.1633797728324602,0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark55(51.47146394318628,-0.7023267448640254,0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark55(51.47698081946166,-0.9193259620031947,0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark55(51.50573448258143,-1.2824851456816027,0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark55(51.63053460007313,-0.12123489446630131,0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark55(51.63218904461605,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark55(51.667544085273164,-0.48993920699963484,0 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark55(5.16694231838018,-1.0627017211758947,0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark55(5.170616337312509,-0.7917230818656265,0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark55(51.71740336669643,-0.9427119541759055,0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark55(5.17419435697191,-1.3372838275074042,0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark55(51.80796886992795,-0.4097393621710861,0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark55(51.809324819984234,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark55(-51.84429720982111,-0.2711490434714252,2194.2064436980363 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark55(51.84492859472388,-0.34530392491853057,0 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark55(51.89373148027266,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark55(51.902792468472796,-1.4999999377211497,0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark55(51.92842075201142,-1.4999999999999734,0 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark55(51.94895493976566,-1.086596218528178,0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark55(51.98763353722225,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark55(52.00148011691322,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark55(52.04180079795938,-1.4371407580527062,0 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark55(52.044978459737706,-0.13004028295777914,0 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark55(52.05515567226898,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark55(52.10688942839297,-0.21475970035972547,0 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark55(-52.10788211268071,-1.4999999999999787,38.214168018848255 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark55(52.1084373518064,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark55(52.12951048828113,-1.0607231233537018,0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark55(52.136421611370906,-1.1621203774740567,0 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark55(52.143270753609414,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark55(52.162738354684194,-0.9458799623187675,0 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark55(52.2384440393065,-0.39519854907294505,0 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark55(5.2256954518415455,-1.382329282352046,0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark55(52.30440227550012,-1.2406168537640838,0 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark55(52.37914806901307,-1.2692249456695062,0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark55(52.3923947850252,-1.499999999999976,0 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark55(52.40758809414437,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark55(52.43310388424512,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark55(52.433415101906434,-0.3305693494328879,0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark55(52.494160654573705,-0.1879427604227637,0 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark55(52.51709787581372,-1.3911111048414189,0 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark55(52.57288905538735,-0.4557134992469197,0 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark55(52.600307756380204,-0.447814167492002,0 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark55(52.62799290094665,-0.04413998191075974,0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark55(-52.644274741898684,-4.460635144202363E-10,-12.964770892244044 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark55(52.665621481016444,-0.789942394018567,0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark55(5.267101097576756,-0.5945133648970434,0 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark55(52.70124696234012,-0.5843559661376403,0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark55(52.71160555955191,-1.3619061859379258,0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark55(52.80817884971003,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark55(52.808564416412054,-0.917940803965072,0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark55(52.82028898221432,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark55(52.828002595532425,-0.32733550891539676,0 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark55(52.84889919454826,-1.3025431225837427,0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark55(52.902307921866736,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark55(52.94470589650086,-0.6475474705456312,0 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark55(52.998594936347274,-0.24088902663976342,0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark55(5.315795868705877,-1.1744056962384684,0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark55(53.16844154416108,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark55(53.21455655652201,-0.6117498339006886,0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark55(53.23746654235464,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark55(53.25339858452662,-89.02116709336502,-78.69579844859757 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark55(53.30484760084488,-1.4239362212224744,0 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark55(53.3227425687559,-1.0625922331999251,0 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark55(53.323430289665,-0.42764352749177625,0 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark55(53.36544266797708,-4.745960315537638E-8,0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark55(53.396436396604614,-0.3017595883938071,0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark55(-53.411915149822065,-2.220446049250313E-16,-12.665607050513046 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark55(53.43350572141692,-0.5449071863390578,0 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark55(53.486353128477155,-0.7244978612196202,0 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark55(5.348774527645077,-0.09444257720677385,0 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark55(53.48839333884729,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark55(53.55324060740065,-0.6149767060580844,0 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark55(53.558926021938106,-0.09727959010005736,0 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark55(53.56590708041128,-0.18827546938596829,0 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark55(53.62202084235782,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark55(53.653019625947834,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark55(53.72947188031341,-1.4278543785588518,0 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark55(53.7399872767636,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark55(53.74038222295859,-0.3723153201956449,0 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark55(53.769347476506255,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark55(53.8455954089803,-0.8050129891452258,0 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark55(53.9333603006348,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark55(53.94388153525392,-1.311218861742261,0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark55(53.95824522676139,-0.4933731549888023,0 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark55(54.05563985140761,-1.2687225276223617,0 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark55(-54.06814485513651,-0.03316791038091438,91.9572338341791 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark55(54.07300465318644,-0.49213073211281344,0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark55(54.08549031486868,-0.3169512733031625,0 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark55(54.11663995579447,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark55(54.133864496942294,-0.6938158249605735,0 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark55(54.16767151966868,-1.3876411385589877,0 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark55(54.20505154989169,-0.9433148358816084,0 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark55(-54.23304140158427,83.34514951538358,-42.107686314336746 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark55(54.2401598635918,-1.3069837467115872,0 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark55(54.26145937491401,-0.2554979482949653,0 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark55(-5.429764128493275,-0.05424308590091295,1.0 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark55(54.36872413606403,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark55(-54.396419927403386,-0.30649711089484644,1.0 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark55(54.459033968273786,-0.9636585131320414,0 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark55(54.507737212059226,-0.5389011536011341,0 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark55(5.45391279153327,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark55(54.56708400315932,-0.7197505984456938,0 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark55(-54.59439703567129,-1.0034916672540328,-6.201037725418073E-9 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark55(54.61170510666287,-0.9936138548524411,0 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark55(54.646468595430036,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark55(54.68043144237794,-0.10965231192987693,0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark55(54.71770219714324,-1.3103860518517423,0 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark55(54.73920562549631,-1.2102208818216007,0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark55(54.74795800272753,-0.05396366537713035,0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark55(54.7914656105975,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark55(54.89738233879829,-1.2160877481831385,0 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark55(55.03113993043104,-0.4203620309697089,0 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark55(55.05654234031314,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark55(55.10822037765335,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark55(55.11067407654747,-1.1631870643270332,0 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark55(55.11477571641689,-1.3104126162999137,0 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark55(55.13733197565787,-0.39434992166032146,0 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark55(55.13897369539066,-1.4878888353908246,0 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark55(5.516175080937842,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark55(55.17847352515872,-0.4632235956307227,0 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark55(55.18249281169787,-0.8070632780642626,0 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark55(55.25751543845425,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark55(55.32152421213095,-0.424724787983326,0 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark55(55.33701892414112,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark55(55.34781977114292,-0.79241878482544,0 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark55(55.43495706786345,-1.328604144688093,0 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark55(55.463007395691506,-42.36919108820694,84.91070562188122 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark55(-5.551115123125783E-17,-0.08765331974463553,0 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark55(55.53869206861975,-1.499999999999993,0 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark55(55.634411262629435,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark55(55.68469365463932,-0.6538569733824469,0 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark55(55.720547354961866,-0.40146514276813505,0 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark55(55.73065227139293,-0.5712576518077932,0 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark55(55.745321910042634,-0.07951818792717802,0 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark55(55.76464651900727,-0.8910397048855518,0 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark55(55.836246250411534,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark55(55.87205012140506,-0.4669125611875111,0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark55(55.91473173729804,-0.5354314349784488,0 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark55(55.92237288991498,-0.7165386340419104,0 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark55(55.998802362750496,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark55(56.016349149150955,-1.3280267556600904,0 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark55(56.044134978781756,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark55(56.08101456780065,-1.161986906365393,0 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark55(56.10381448133691,-0.7437149385233042,0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark55(56.109116227986206,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark55(56.116407666548575,-0.003419514216166165,0 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark55(5.612339069500706,-1.316573410207738,0 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark55(56.16945918633603,-0.42015956482528244,0 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark55(5.618144742714755,-0.3482752448153578,0 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark55(56.229383336678126,-0.5927234205161671,0 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark55(56.3057010390531,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark55(5.635927867740236,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark55(56.36489586144503,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark55(56.392658896537654,-1.2581053197548435,0 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark55(56.41477065020522,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark55(56.48068205170202,-0.9785339748445665,0 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark55(56.50277084350972,-1.499999999958094,0 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark55(56.51002437178505,-0.43894207358489723,0 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark55(56.52255572896408,-0.2479751840498929,0 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark55(5.654671573549878,-0.4224998335273471,0 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark55(56.57809697115715,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark55(56.62448323716143,-1.197734690711755,0 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark55(5.6628732095207095,-0.057801758202785436,0 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark55(5.663059592047603,-1.4911367253508456,0 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark55(56.703060180530684,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark55(56.72156357591817,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark55(56.76067116255382,-0.7917401383649403,0 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark55(56.827736095176476,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark55(56.885804469228816,-1.2601704360277903,0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark55(56.88835186663462,-0.9928780424320962,0 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark55(56.923246995157086,-0.36038291999363103,0 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark55(57.01207229575945,-1.155088357355627,0 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark55(57.01764823312692,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark55(57.101114170716556,-0.9488510367525316,0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark55(57.13085419295004,-0.353804748922243,0 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark55(57.14854652435187,-0.15685458464449908,0 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark55(5.7203977897427105,-1.1637843586062833,0 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark55(57.24095139342796,-0.30937662424496093,0 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark55(57.24297278431716,-0.5650062484680992,0 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark55(57.28813640322633,-1.211590910166482,0 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark55(5.738731136925821,-0.6530555726950813,0 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark55(57.39709858195167,-0.005110633621324412,0 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark55(57.43197405648229,-1.097052853066046,0 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark55(57.45860401977076,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark55(57.48517529019213,-0.6485785163286789,0 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark55(57.48921958061922,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark55(57.52676119162275,-1.321802265287472,0 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark55(57.52817501360726,-1.1551631121224275,0 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark55(57.566933065379295,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark55(-5.7582885209459524,-1.499999999678771,0.40398065973943464 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark55(57.65555465164991,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark55(57.6635023220003,-0.15431858061663442,0 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark55(5.767222194328809,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark55(57.72015879079328,-0.25967338289359654,0 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark55(57.794110032685296,-0.2724866194426028,0 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark55(57.797888610760594,-0.9968542096792135,0 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark55(57.82176449181216,-0.2866026769352872,0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark55(57.89868995842474,-0.16880529908436515,0 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark55(57.909847775600156,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark55(57.935345198586305,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark55(57.953687393399875,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark55(57.99445437962328,-0.10030346617647012,0 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark55(58.05211717744184,-0.10846480850886664,0 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark55(58.092826401501384,-1.2299325677209918,0 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark55(5.820413253123476,-1.3872886463459062,0 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark55(58.21515838998323,-0.3817555406340887,0 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark55(58.32184300369187,-1.1722479537669648,0 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark55(58.35517002700791,-9.877086431614599E-9,0 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark55(58.38373540696625,-1.4571986904493173,0 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark55(58.39130125949299,-1.1736451355630635,0 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark55(58.41140740030417,-1.2031003639394005,0 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark55(58.489436981559514,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark55(5.851601086412089,-0.6401049464158977,0 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark55(58.5405375036724,-0.38687254783734204,0 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark55(-58.55479540915809,-1.3728474925058123,47.21513223085856 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark55(-58.57939241076719,-0.4689181784660268,-12.800073164008872 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark55(58.59293303208607,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark55(58.66302239631668,-1.41369968272204,0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark55(58.66814911438176,-0.9475931001643021,0 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark55(58.71474200192756,-0.7944897449536015,0 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark55(58.763026531696994,-0.06765364945037788,0 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark55(58.78644285746452,-0.4954673531245728,0 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark55(58.836206044596594,-0.5979647353475492,0 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark55(-58.84229879326519,-7.074025335957025E-10,-0.9977799831566125 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark55(58.93493894302388,-0.6816868777517021,0 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark55(58.986026160350235,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark55(58.99729020229546,-0.9644653128404865,0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark55(59.02842609780032,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark55(59.08913303151914,-0.1481071070688018,0 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark55(5.918154651443118,-1.2559736763937224,0 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark55(59.18474480844142,-1.4722889712473375,0 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark55(59.22804587590363,-0.22502456555029382,0 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark55(59.24379320011698,-0.15542475651833776,0 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark55(5.925626600091522,-7.908063295034696E-7,0 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark55(59.311414628260934,-0.9696439486945967,0 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark55(5.931751856289864,-1.0517118505993237,0 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark55(59.329179609921994,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark55(59.3842306793139,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark55(59.48332675385075,-0.9414063196388298,0 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark55(5.951508156984261,-1.1131118999762064,0 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark55(59.52722713276316,-1.419362168224449,0 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark55(59.57422058955177,-1.4999999467803067,0 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark55(59.594113538541734,-1.499999999999936,0 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark55(59.62192006018856,-0.9976231847798527,0 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark55(59.72649195829417,-0.7644436646507388,0 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark55(59.75574770848178,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark55(5.976476641109613,-5.400578591894889E-9,0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark55(-59.78688472962912,-0.10694335515166914,-0.9999999999999964 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark55(59.790237760568516,-1.1115688740656386,0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark55(59.81173421604308,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark55(5.984893287560098,-0.29508717610689494,0 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark55(59.86034789457499,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark55(59.88512361324383,-1.3912445015585634E-9,0 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark55(59.90019649482578,-0.0764079353645748,0 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark55(59.90483416160064,-1.2843575037737984,0 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark55(60.024553363177716,-0.03822189351931993,0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark55(60.03349158156439,-0.221416286395683,0 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark55(60.05041996535323,-1.2748664054026987E-8,0 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark55(60.077977778560836,-0.19580372438308302,0 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark55(60.095237502914735,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark55(60.115357621710544,-0.297548276372829,0 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark55(60.18963659248547,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark55(60.21928394782563,-1.1574063721278043,0 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark55(60.290859800330054,-0.7915786773946394,0 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark55(60.29292084199426,-0.6231480288088718,0 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark55(60.30001675380633,-0.2086343237160615,0 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark55(60.30305822155918,-0.1117977495962208,0 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark55(60.3277111425663,-0.37020461838537955,0 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark55(60.47356652450838,-2.364210962386994E-8,0 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark55(60.57236215708767,-0.42303806605242117,0 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark55(60.586863868887605,-0.2055633999298907,0 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark55(60.591432255883376,-0.29739040874035444,0 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark55(60.60604527473164,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark55(60.68603667108289,-1.2917256058901927,0 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark55(60.77799541107177,-0.17086624961881547,0 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark55(60.7897090514951,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark55(60.86175377342086,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark55(60.89551287879436,-3.240718064493219E-8,0 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark55(60.92880875662479,-0.7588116796423021,0 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark55(60.9553503803416,-0.9838073657845741,0 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark55(61.026947529782824,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark55(61.03138726105186,-0.06669616722089364,0 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark55(-61.09488243329278,-1.322080138869766,9.860761315262648E-32 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark55(61.113043379922125,-1.032382013267366,0 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark55(61.16181022044728,-0.7256697023645415,0 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark55(6.128990377514786,-0.541315805602326,0 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark55(61.36781767907641,-1.3811863366499821,0 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark55(61.37143427485029,-0.25623266585829674,0 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark55(61.40271580577223,-0.6068944397738596,0 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark55(61.40649992194963,-0.7874983704167227,0 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark55(61.42185069101834,-0.4912344624854459,0 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark55(6.147093781732224,-0.10263214920922364,0 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark55(61.49952351292035,-1.4826018947683082,0 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark55(61.50061986055252,-1.1111800998887,0 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark55(61.60315019185899,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark55(61.63642580486177,-0.953037358102705,0 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark55(6.16912077202952,-0.9960963646099303,0 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark55(61.71946895121755,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark55(61.73935831119897,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark55(-61.753768662675526,-0.15551575221000746,0.0 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark55(61.81129719848302,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark55(61.8258245599097,-2.2957864374345437E-7,0 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark55(61.88830006151446,-0.21869538056906368,0 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark55(6.190225806801436,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark55(61.932012629216565,-0.2693032299056269,0 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark55(61.959622296283726,-1.142439005693575,0 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark55(62.022028035182345,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark55(62.083182085079926,-0.35554071377674745,0 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark55(62.090720276137745,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark55(62.13185836910151,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark55(6.214909077220042,-1.052503886283382,0 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark55(-62.16495431903424,-0.64908089121616,0.9999999999999991 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark55(62.17698181748833,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark55(62.19673723432712,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark55(62.328026887966956,-0.8690358019788418,0 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark55(62.48010268827835,-0.6084045596200696,0 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark55(62.48172334810431,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark55(6.249600730997205,-0.6853242729102789,0 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark55(62.5112681202437,-0.7181505751766697,0 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark55(62.53505385459056,-0.15365374087501138,0 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark55(62.553219135778306,-0.6532031609381694,0 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark55(62.64268930182527,-1.082440182031533,0 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark55(62.65411940006106,-0.029193853472733622,0 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark55(62.73412913944975,-1.4608783337623805,0 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark55(62.84309931210714,-0.6493042055924683,0 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark55(62.90086392899107,-1.4432634374767217,0 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark55(6.290204892582537,-0.7232469169494227,0 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark55(62.95561314153448,-1.1115891496375396,0 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark55(62.966553562394544,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark55(63.02111558359144,-0.023737278049002608,0 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark55(63.05406837611772,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark55(63.0949896996528,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark55(-6.3133328833630085,-1.1542666208154175,-14.666125711923257 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark55(63.15605709498519,-0.8221537708909114,0 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark55(63.17409194189777,-1.1447714260111699,0 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark55(63.211490013190115,-0.21061665889577857,0 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark55(6.323920593591637,-1.499999999999876,0 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark55(6.326368690456432,-0.9429046486277741,0 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark55(63.35266865334725,-0.48127367882493366,0 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark55(63.39378459141005,-1.2794327740877556,0 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark55(63.413346238044255,-1.129444751058017,0 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark55(-63.415777596265045,34.16106230428588,44.77576653296015 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark55(63.428470153875715,-5.695053476400691E-10,0 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark55(63.48146757241298,-1.237259308838773,0 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark55(6.359396126322857,-0.04619821185979012,0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark55(63.623147806968575,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark55(63.68641160219656,-0.2441373455687641,0 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark55(63.687242989983446,-0.7428926482070168,0 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark55(-63.75173279148216,-3.438555644460338E-8,-29.66708368834922 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark55(63.79641370469852,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark55(63.86097227056921,-0.9667798891700147,0 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark55(63.87390472367243,-0.1180057516020251,0 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark55(63.877569673477666,-0.21517377534833493,0 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark55(63.88438359910246,-6.219112955315002E-8,0 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark55(63.894587768160875,-1.259269795063865,0 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark55(63.942713732363075,-0.2328965331486419,0 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark55(63.94683658605297,-0.8969670275111847,0 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark55(63.99348719070116,-0.548133031216537,0 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark55(64.01763931275411,-1.4666430355265518,0 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark55(6.405488654614544,-0.5501744580065022,0 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark55(64.16980447096518,-0.20290114816900484,0 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark55(64.18361631141926,-0.3499821713371425,0 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark55(64.20244283041973,-0.18905005082130066,0 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark55(64.20810599323687,-0.7931416222708267,0 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark55(64.22271797815665,-1.0310870851966358,0 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark55(64.2253541933996,-1.0348542820593902,0 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark55(64.22841959881649,-1.3685845236533227,0 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark55(64.22952849415276,-0.294486941985145,0 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark55(64.23735402556353,-1.397104446932563,0 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark55(64.25646334399536,-1.1263781218291715,0 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark55(-64.28003069525822,-0.42262983419245137,9.622990730379394 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark55(64.28766419799516,-0.510415515864409,0 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark55(64.35194166833361,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark55(64.36171210190567,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark55(-64.36524145930514,-4.440892098500626E-16,11.364079769568505 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark55(64.37326994235221,-0.41419098533559406,0 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark55(64.41235183696497,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark55(64.45344168259183,-0.8473326859958326,0 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark55(64.58283536155146,-1.4789147857088991,0 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark55(64.62548157891976,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark55(64.67325127746797,-0.7294860351067456,0 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark55(64.71749577267886,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark55(64.76304168481758,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark55(64.82717271619919,-0.8816335701028493,0 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark55(64.83376232930826,-1.4888044107577962,0 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark55(64.88157647502155,-1.1283924335721842,0 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark55(-64.888021649689,38.91480177105959,-15.977857864665296 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark55(64.92363052806286,-0.8365536457967901,0 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark55(64.97718595724294,-0.5187712220975111,0 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark55(64.98758630899059,-1.0186977423725523,0 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark55(64.99528630976741,-1.1469472832878636,0 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark55(65.06200616950782,-1.4999999999135722,0 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark55(65.06297462909899,-0.6999561025410515,0 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark55(65.08438773151698,-7.687444003943681E-8,0 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark55(6.513713973635534,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark55(-65.14531329540611,-0.8947772476802667,0.9728543312406718 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark55(65.26094709039981,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark55(65.31263457933775,-1.1360500222525278,0 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark55(65.32778449569986,-0.8244475722937379,0 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark55(65.3944343056316,-0.1287986662010916,0 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark55(65.54375956491742,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark55(-65.5656199644348,-1.2572376187756125,44.65454024590085 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark55(65.58011099810531,-1.3809012251488042,0 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark55(65.65320683375965,-1.2704426547869225,0 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark55(65.73358132582305,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark55(65.75522022215813,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark55(65.81963123565302,-1.3817301142721892,0 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark55(65.8227013223905,-1.223189587681523,0 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark55(65.84741328782708,-0.11289250015171254,0 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark55(65.87389408855411,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark55(65.92203329391975,-0.9074591793728981,0 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark55(65.94571862182994,-0.9576382175804463,0 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark55(65.96640090070485,-0.27276831155911907,0 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark55(66.12869955931613,-0.1801653353007442,0 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark55(66.14332942232562,-0.486641035801739,0 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark55(66.15492749693587,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark55(66.15807613249206,-0.12918578294789107,0 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark55(66.19620382915303,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark55(66.1995541578546,-0.6377280705673329,0 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark55(66.23482437184492,-0.5695222632397976,0 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark55(66.28046379512992,-0.6159064741171312,0 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark55(66.31376300196024,-1.1000378871312033,0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark55(6.633894556199849,-1.499999999999993,0 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark55(66.3834272247399,-0.5268773279331613,0 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark55(66.41635314716768,-0.5523308497756638,0 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark55(66.42566179719955,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark55(6.644446519414032,-0.6327781322026764,0 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark55(66.4823440302221,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark55(66.54886531062479,-0.9499267467666819,0 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark55(-66.58941475680177,-2.220446049250313E-16,-4.213539818545399 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark55(66.59258123549543,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark55(66.60412607591832,-0.730306034910285,0 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark55(66.61738248353478,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark55(66.66342108480848,-1.3224874488404006,0 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark55(66.74513316407473,-0.5808558980702583,0 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark55(66.79909204292461,-1.088979056395595E-6,0 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark55(66.80268649530564,-0.1467982165791152,0 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark55(66.8112932394724,-0.48899172627285203,0 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark55(66.8681852997394,-1.0825659004042607,0 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark55(66.87360350370187,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark55(67.0111262902787,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark55(67.01505563508013,-0.475500240076452,0 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark55(67.02138621668529,-1.4969905241413368,0 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark55(67.0638223810866,-0.10155082011060301,0 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark55(67.09609135120297,-0.43461303989708,0 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark55(67.1016505682918,-1.4999999999999938,0 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark55(-67.1089422838941,-0.47421659158559115,1.0 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark55(67.12672259552895,-0.858686873053145,0 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark55(67.16273500432797,-0.17428767064646422,0 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark55(67.18739277139186,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark55(6.723381709851901,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark55(67.26955459714284,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark55(67.29096643234271,-0.5537584062237866,0 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark55(67.34911517867423,-0.27597361434711587,0 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark55(67.37069978157263,-0.1197226161977274,0 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark55(67.42036622198391,-0.20366412656997343,0 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark55(67.42946255229324,-0.7223544148171607,0 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark55(6.750425192003614,-1.0132113200655213,0 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark55(67.5157956378443,-0.1080375023935673,0 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark55(67.52910438901185,-0.8163656092663292,0 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark55(67.59560575503113,-0.4597576427492811,0 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark55(67.65267417606009,-0.6881851054400105,0 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark55(67.6542453263348,-0.9136445078341378,0 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark55(67.6600486024123,-1.060407092342004,0 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark55(67.68989960819853,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark55(67.69156983292808,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark55(67.70337606917366,-1.4555491573699086,0 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark55(67.71198371924666,-0.6978056077390031,0 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark55(67.76230882707347,-0.425142649277646,0 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark55(-67.77733430081825,-0.7460680496839687,1.0 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark55(67.83429894455796,-1.406828031658419,0 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark55(67.89684422687407,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark55(67.98302690424208,-0.4730150544663445,0 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark55(67.98736268904645,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark55(6.80430887780296,-0.8778425831467702,0 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark55(68.05339714631529,-0.9864265838971562,0 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark55(68.15212215257077,-1.388352650110678,0 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark55(68.17525985575625,-0.4006544087641437,0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark55(68.29017642926792,-0.488309830270353,0 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark55(6.830627320412091,-0.7033533035331168,0 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark55(68.33163496640859,-1.387040655533352,0 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark55(68.34088953507745,-0.8508387591875985,0 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark55(6.835474142443857,-0.5317693938694994,0 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark55(68.37693805718544,-1.3541163769889906,0 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark55(68.54104778133362,-0.6399111622958308,0 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark55(6.857498479486632E-17,-0.0792961477634413,0 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark55(68.63865021992274,-0.021077992016344638,0 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark55(68.66591971491283,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark55(68.70336896177662,-0.6784237892801315,0 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark55(68.81269320621138,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark55(68.82314117241759,-0.392624827164785,0 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark55(68.90673328038216,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark55(68.95493622136786,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark55(69.0253894158858,-0.6225936337692062,0 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark55(69.03130330111159,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark55(69.06819115141062,-0.8340629066588634,0 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark55(69.09861350834979,-0.46270071211975505,0 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark55(69.15524140905212,-1.4999999999999805,0 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark55(69.16796524158929,-5.15828945209318E-10,0 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark55(69.31041120641984,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark55(69.33745374048371,-41.945196375696355,61.11624087345538 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark55(69.37463431360769,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark55(6.938893903907228E-18,-0.0072693365813840186,0 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark55(69.42287744152887,-0.17099441312822705,0 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark55(69.47616163326867,-8.369962225122434E-10,0 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark55(69.48331550256205,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark55(69.49184799312732,-0.2961592738006451,0 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark55(69.58387567691747,-0.8244548868209458,0 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark55(6.960447867103795,-0.7094155446228001,0 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark55(69.65693215588585,-1.1312752453743549,0 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark55(69.68191103345416,-0.12327932449264978,0 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark55(69.75538366646242,-1.382033394907046,0 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark55(6.975770211122453,-0.16892186690055894,0 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark55(69.78693857757315,-37.77942133539616,-22.305234991269046 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark55(69.79667561236228,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark55(-69.80336895403865,-0.13619793725750018,0.8692118037445762 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark55(69.84354281991904,-0.6071102395855945,0 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark55(69.84467870337137,-3.291476535256069E-8,0 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark55(69.84821856278417,-1.092378196883935,0 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark55(69.85420810590892,-1.3185180929325755,0 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark55(6.989145061161935,-0.5362722061641358,0 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark55(69.92599530974024,-0.1617409452783945,0 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark55(70.00499520460463,-0.20026010511102754,0 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark55(70.02650383376846,-0.7282445606074303,0 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark55(-70.04269039310489,-0.2824986633357508,-0.7421180281851314 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark55(70.05816284738785,-1.333931812160765,0 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark55(70.09277655870847,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark55(70.23813114159799,-0.6484864596477853,0 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark55(70.35726408141065,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark55(70.37883258169703,-0.5821030777687355,0 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark55(70.38342243955904,-0.2121116487902718,0 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark55(7.039586921980132,-1.7429294288603106E-9,0 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark55(7.045318268620203,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark55(70.46890058886768,-0.5726767391865906,0 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark55(70.47379618054907,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark55(70.52669859957794,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark55(70.53378897615971,-0.7971824237468041,0 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark55(70.54355141987344,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark55(70.57081018921298,-0.6088000240430674,0 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark55(70.57218515395513,-1.4428895217053506,0 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark55(70.60347822183539,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark55(70.6599840454198,-0.5291642705062622,0 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark55(70.66101359693471,-0.7252002552249621,0 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark55(7.068552629595487,-0.6216145917317599,0 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark55(70.7058322619348,-1.1108130850474094,0 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark55(7.074062855438644,-1.3627811952243742,0 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark55(70.7552708837912,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark55(70.75791394700934,-0.12147770179920148,0 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark55(-70.85630619530563,-0.08390832248365206,0.029784761235534647 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark55(7.086433082802046,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark55(7.087091729203195,-0.3932846306231088,0 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark55(70.89618286395938,-0.8269181451270535,0 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark55(70.92250087671954,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark55(70.92965962117955,-0.9060842599904362,0 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark55(70.99923151916997,-1.4095554925477227,0 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark55(7.102580915580404,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark55(71.0477794171751,-0.05679772338078237,0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark55(7.105427357601002E-15,-0.42151528403700356,0 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark55(71.09239259618568,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark55(71.09361449129497,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark55(71.12838806508344,-0.4750796347999673,0 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark55(71.12953550010516,-1.406541055948317,0 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark55(-71.17932520508757,-0.829021347332366,-1.0000000000000002 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark55(71.27717816396662,-0.7098790776139339,0 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark55(71.33497699861086,-0.3946289542467964,0 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark55(71.43135496436504,-0.19851517611799663,0 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark55(-71.45852494055178,-1.4900638885397222,-1.0 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark55(-71.46560016285096,-1.2971647301430496,-1.0 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark55(71.50888337179441,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark55(71.51286207529407,-1.4999999999997788,0 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark55(-71.53116431040851,-0.8834869152026115,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark55(7.153987334571838,-0.12847908855590795,0 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark55(71.55642525309528,-1.4250179630335538,0 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark55(7.156025494880238,-0.6142490968110934,0 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark55(71.57836335901831,-1.1689607217298317,0 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark55(71.58606669968057,-1.347172426433474,0 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark55(71.62251697383778,-0.27786982474217803,0 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark55(71.70300228225454,-0.7103458940588752,0 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark55(71.71346645363224,-0.07517766609099219,0 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark55(71.74637560934069,-0.2690502081757167,0 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark55(7.175915235732879,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark55(71.85194439874408,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark55(71.89365511670516,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark55(71.9264125264909,-1.4350542440261513,0 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark55(71.97656271374282,-9.948103024440247E-7,0 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark55(72.02819340788409,-1.3360855299065995,0 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark55(72.04204034857159,-0.11247766771809609,0 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark55(72.06927513216087,-1.4275838449870335,0 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark55(72.10368846109048,-0.35260441981808466,0 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark55(-72.12692711644705,-1.2285211168004912E-6,-1.2595566970526214E-7 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark55(72.1410680558671,-1.4695737121687,0 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark55(72.14831230418105,-0.2253122860290045,0 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark55(72.22612093799285,-0.01548755872192098,0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark55(72.25226129830168,-0.49987893927476046,0 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark55(72.3113614541366,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark55(72.39353503611613,-0.12528923604063635,0 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark55(72.51267554117507,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark55(72.61195802468222,-0.48750402837182916,0 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark55(72.62533408964231,-0.20358228851385718,0 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark55(-72.63385048811517,-0.2013502677324947,0.03783025201955165 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark55(72.68265668993729,-1.2575652648069617,0 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark55(7.272117066113776,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark55(72.7303347557382,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark55(72.78632303725277,-1.2858634672848424,0 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark55(72.79038373615961,-0.13041430250056885,0 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark55(7.281439761544021,-0.8213488817866619,0 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark55(72.8236582654796,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark55(72.89485899023947,-0.20465996713341816,0 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark55(72.920098612907,-0.031588595050507706,0 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark55(72.9819829752702,-0.24471917172270707,0 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark55(72.99277340778926,-1.1625946869193395,0 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark55(73.01387252717868,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark55(73.03086560442759,-0.3892337202872147,0 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark55(73.06896409038492,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark55(73.13599950164148,-1.204334131889881,0 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark55(73.13612111283351,-0.4197674846465205,0 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark55(73.14830142085842,-1.4243742178759788,0 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark55(73.18099722543941,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark55(73.18398872793796,-1.1117683308525628,0 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark55(73.23665943470252,-1.379653733084396,0 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark55(73.29919301396842,-0.943832650590255,0 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark55(73.40363723301184,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark55(73.46998500547154,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark55(73.47638254072034,-0.03885437121993607,0 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark55(73.52056972513621,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark55(73.5777528028029,-0.6996511953038151,0 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark55(73.59130018068453,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark55(73.61689546451697,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark55(-73.67874888914646,-8.881784197001252E-16,0.9846446537330129 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark55(73.71126817567824,-0.6245763123614372,0 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark55(73.74526610234341,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark55(73.772553390116,-0.36096664378483767,0 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark55(73.79966877678194,-5.566066262114406E-5,0 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark55(-73.84038704404189,-0.3634602029920674,1.0 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark55(73.90574428551092,-0.18117969415010116,0 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark55(73.95425724322752,-0.02646933550949271,0 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark55(74.04335359322114,-0.05268621271983953,0 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark55(74.08777674817388,-0.3419882251078741,0 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark55(74.12298455398775,-0.08647695242546227,0 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark55(74.17116893258643,-0.5067783117762303,0 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark55(74.23207465465305,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark55(74.2540025267322,-0.7929478400553052,0 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark55(74.2550937828313,-1.073589940300149,0 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark55(74.28456206731354,-0.49371181154209864,0 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark55(74.36411810918653,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark55(74.39576026032464,-1.2119908359090466E-9,0 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark55(74.435312162786,-1.000360412533258,0 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark55(74.50370724248116,-0.2582112024827895,0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark55(74.50428218672738,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark55(74.51845737408419,-1.4888568868961922,0 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark55(74.54458399153322,-0.9263126893272677,0 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark55(74.58022977807559,-1.0431399417550218,0 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark55(7.4583327963051005,-0.8807045161901612,0 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark55(74.59741421072243,-1.2989356159043624,0 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark55(7.459778394014776,-0.27146524912076453,0 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark55(74.60926086240468,-0.8280026229005806,0 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark55(74.62594642972643,-2.6918479209528327E-8,0 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark55(74.63479770417865,-0.011060725209795333,0 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark55(-74.63916566616696,-1.499999999999993,-1.0238158649401738 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark55(7.464361952412688,-0.5124885234446455,0 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark55(74.65303116870047,-1.4034166846745464,0 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark55(74.65534263571314,-0.7309887321669146,0 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark55(74.66432924108835,-0.855400298530792,0 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark55(74.69956708334223,-0.18178779670707168,0 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark55(74.72845566445548,-0.3520763137109766,0 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark55(74.7546661588276,-0.24263709072210204,0 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark55(74.76687657473644,-0.1923929477187727,0 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark55(74.7755786440083,-0.13129472294503852,0 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark55(74.80408858765722,-0.927769755092072,0 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark55(74.80678055738319,-0.9502044301411183,0 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark55(74.81612608738627,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark55(74.8346383266185,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark55(74.84149460805715,-1.3604565288197024,0 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark55(74.9152485692223,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark55(74.96619372150477,-0.028286530841879376,0 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark55(7.496673960331448,-0.30056340227423417,0 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark55(75.02864623754286,-0.3683891027747279,0 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark55(75.0497078756238,-0.6731981782413206,0 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark55(75.06426688462591,-0.6861154698950997,0 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark55(75.06905581507408,-0.8341546218120692,0 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark55(7.507628833569697,-0.8018360232898574,0 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark55(7.514992946978295,-1.4999999376119282,0 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark55(75.22509221389205,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark55(75.27189458304892,-1.0480862533272206,0 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark55(75.27275574308561,-1.1844088527047547,0 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark55(75.28007518367762,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark55(75.33290825803235,-0.43632578305542813,0 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark55(75.34131921262578,-0.8893123806704,0 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark55(75.34744994149344,-0.7011626437812266,0 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark55(75.34986830162663,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark55(75.39467964173059,-1.3070104305297567,0 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark55(75.39534608276563,-0.15134236174627347,0 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark55(75.40017128546253,-0.3620346721803003,0 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark55(75.45211947798862,-0.8438729898175836,0 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark55(75.47810793985578,-1.25710432250516,0 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark55(7.548379942742458,-1.412621054437535,0 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark55(7.54921119387275,-1.4340267207674435,0 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark55(75.49766836973885,-1.3549472893369023,0 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark55(75.58676556842516,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark55(75.59266130866517,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark55(75.62279395469363,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark55(75.62923068897474,-0.826018950074149,0 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark55(-75.80011795282175,-0.05683158031267421,-0.36208927224364845 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark55(75.83257801665775,-0.09204724751301128,0 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark55(75.99152117003268,-1.2214189138962936,0 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark55(75.99402548778565,-0.9274482316273575,0 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark55(76.01533102710482,-1.203353210434559,0 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark55(76.08528434232039,-0.8544087377459006,0 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark55(76.17369400890118,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark55(76.18171990785157,-1.352267507629107,0 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark55(76.20685770184824,-0.628236683183319,0 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark55(76.21395299270338,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark55(7.625407057008985,-0.6138463372147847,0 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark55(76.28332059529771,-0.26655234671774974,0 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark55(76.33567182675856,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark55(76.34345976931547,-0.8779358855573292,0 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark55(76.36403921525269,-1.23517950743623,0 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark55(76.36997309034989,-0.2108629548427341,0 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark55(76.37766014887231,-1.021804186681635,0 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark55(76.40203753109813,-0.9976790872549159,0 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark55(76.40318738240296,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark55(76.4520353577017,-1.499999999999992,0 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark55(76.45609872526828,-1.24360535920826,0 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark55(76.48249350386524,-0.3126449609041635,0 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark55(76.58095772836413,-0.14477951951364965,0 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark55(7.658290558903593,-1.4999999999470695,0 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark55(76.60577830771354,-0.930691411000879,0 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark55(7.662751246265032,-0.6128869707147828,0 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark55(76.62768461285748,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark55(76.63392277570708,-0.6871779794991038,0 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark55(76.64065112931038,-0.9855181155791524,0 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark55(76.67296947525736,-0.5227317191752441,0 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark55(76.69697199758647,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark55(76.70367731144518,-0.800190867811045,0 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark55(76.78664606678801,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark55(76.78815304633622,-0.7176640562835637,0 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark55(76.78827044365146,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark55(76.83250265394199,-0.9170412849885675,0 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark55(-76.83700485773997,-1.0561855129087832,10.92988580838417 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark55(76.87834436173853,-1.0446090388568092,0 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark55(76.96033467847826,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark55(77.02116790189274,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark55(7.7041645201240385,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark55(77.04521912549515,-1.4048658586856009,0 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark55(77.05548440117468,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark55(77.05769354019353,-1.4755500880154049,0 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark55(77.14728557880765,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark55(77.17174218744677,-0.13779611480719622,0 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark55(77.24007510981798,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark55(77.26524600885162,-1.0028240875683991,0 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark55(77.27954363324129,-1.120940854119534E-9,0 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark55(77.29627717398824,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark55(77.33632846001939,-0.33578916680239096,0 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark55(77.40605380905978,-0.3627249343224719,0 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark55(77.42804084618118,-0.24775515139818327,0 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark55(77.42973503004288,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark55(77.45733267629299,-1.4999999999999876,0 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark55(77.46254178353053,-0.8964602631626519,0 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark55(77.47296121917293,-1.4957054105208099,0 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark55(77.51611325276133,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark55(77.53694142157238,-1.108339092501616,0 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark55(77.5389221521607,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark55(77.57367077287154,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark55(77.58528996283712,-0.8981345364720239,0 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark55(77.62695948563046,-0.9274093504321591,0 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark55(7.7667923357551985,-5.881592864517291E-7,0 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark55(77.68601693690047,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark55(77.72461056859842,-1.3701800379135416,0 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark55(7.786871055544975E-208,-7.105427357601002E-15,0 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark55(-77.8962051519617,-0.8340103761430719,0 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark55(77.90003082517575,-1.1905926124369302,0 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark55(77.91300349089298,-0.008337249952631964,0 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark55(77.92805392860109,-1.1935768829909184,0 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark55(78.07085082524874,-0.9541454457725786,0 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark55(78.07446259491815,-0.9341983910062442,0 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark55(78.07735951995517,-1.1696437159197899,0 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark55(78.1008480200642,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark55(78.12721367540752,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark55(78.15181559066036,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark55(78.17225240171649,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark55(78.18340847832793,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark55(78.20867302267774,-1.0420217353476784,0 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark55(-78.23518902725847,-0.668027877806395,-0.5235776551165543 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark55(78.25583902660273,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark55(78.33077444030167,-0.3861285456169701,0 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark55(78.36523058738346,-0.15760798237474938,0 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark55(78.36586753855799,-7.330016730781355E-6,0 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark55(78.4015261469884,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark55(78.40355476967682,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark55(78.53518817937444,-0.700947925335732,0 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark55(78.5366674659951,-0.5005466894236674,0 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark55(78.53989324915065,-0.09673865584657904,0 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark55(7.855839286403594,-0.23545997362628412,0 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark55(78.56097318762153,-1.2047458355332943,0 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark55(78.57112169107032,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark55(78.57996772886321,-0.4595126851501954,0 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark55(78.64528915998076,-0.07016397715468736,0 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark55(78.66571359116699,-1.0017363390343377,0 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark55(78.68613575269755,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark55(7.868749787839533,-1.270067809156373,0 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark55(78.69009114635725,-0.4189977699297742,0 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark55(78.75065229410737,-0.040534440852867754,0 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark55(78.759578967445,-0.2905401109709089,0 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark55(-78.79083624786665,-1.7763568394002505E-15,2464.6467599241614 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark55(7.8881402810126815,-1.4800700409651029,0 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark55(7.890580825679663,-0.9431434662989187,0 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark55(78.94690983344904,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark55(78.95032427997495,-1.1027302071198574E-7,0 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark55(78.96239518320252,-1.499999999999993,0 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark55(79.09537712319877,-1.0520047027153367,0 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark55(-79.12108209492877,-0.5408613275468309,0.9447113937186096 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark55(79.2348578342667,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark55(79.24138972224873,-1.4513219304739522,0 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark55(79.24674078343565,-0.7011322953522745,0 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark55(79.32458911200267,-0.8308836772514687,0 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark55(79.3292682061365,-6.298878894463431E-9,0 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark55(7.937611780013796,-1.1495678586418316,0 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark55(79.40248794162139,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark55(79.43034673426484,-1.491177830098744,0 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark55(79.44779295786367,-1.4999999999999698,0 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark55(79.45939838999452,-0.0033763325406068745,0 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark55(7.9486442084106645,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark55(7.964305857256292,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark55(7.965974158174617,-0.44155906081849405,0 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark55(79.71672741042454,-0.058360979385849276,0 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark55(7.9736082631063105,-0.5822767660993282,0 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark55(79.79712001446597,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark55(7.980132235994176,-0.7897269643728188,0 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark55(79.81735328020002,-1.0806115272958152,0 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark55(79.82735050966133,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark55(79.88083265224034,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark55(79.92449694160875,-0.9243808441057535,0 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark55(79.95980271054015,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark55(79.98338654294481,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark55(79.98726877564366,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark55(79.99348354970121,-0.4430525627222104,0 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark55(80.03019096017059,-0.18711389868068462,0 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark55(80.03989480713074,-0.041320004076890626,0 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark55(80.08336235670345,-1.286737428289804,0 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark55(80.10989688207431,-1.499999999843733,0 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark55(80.11621513376676,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark55(80.15736208056175,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark55(80.178720529815,-0.5041101380438,0 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark55(80.17887944177845,-5.692350390996163E-8,0 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark55(8.018910580214817,-7.178006412697954E-8,0 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark55(80.19975421916581,-0.6246841286714946,0 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark55(80.19997762391392,-0.04105076163361554,0 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark55(80.2134614419684,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark55(80.23357662852773,-1.177068626842697,0 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark55(80.26316318744162,-0.045031499109382256,0 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark55(80.30446957338117,-1.190986496155137,0 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark55(80.3237499466342,-0.19265562599190034,0 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark55(-80.33247808237319,-95.68522432570671,-59.41318669947686 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark55(80.36629901908432,-0.8840228357826663,0 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark55(80.39832851740712,-0.9835515080334929,0 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark55(80.40038092803229,-0.7591724139214833,0 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark55(80.51337668180363,-0.48953213709306453,0 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark55(80.52125273768769,-1.3378652318144333,0 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark55(80.5218730116036,-0.5059218362667727,0 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark55(80.5753375109673,-0.7628829095376304,0 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark55(8.063505006724242,-0.431846987375458,0 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark55(80.64577207332547,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark55(80.69106476018493,-1.376934825853688,0 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark55(80.70107206755112,-0.40626957891929644,0 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark55(80.7293962556129,-1.448289163264812,0 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark55(80.77385631086912,-0.14885138335918602,0 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark55(80.77694236031222,-0.25887741254269536,0 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark55(80.7867789061848,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark55(8.086904462792077,-1.4319939172489677,0 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark55(80.87849604891747,-1.4870286299294113,0 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark55(80.92327272187055,-0.03412686712096402,0 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark55(80.93994610084314,-0.5429833241257,0 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark55(80.97385358724003,-0.6088142358432398,0 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark55(80.97846097802314,-0.9569594658073157,0 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark55(81.01668877546501,-1.1006248908859533,0 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark55(81.03814871049339,-0.06847267378487004,0 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark55(8.112065599742863,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark55(81.16965083623589,-0.8566679102675856,0 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark55(81.18346867782785,-1.1027519837233153,0 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark55(-81.24726506488486,-0.9479543243444084,1.0 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark55(8.137681322186396,-1.4999999999999911,0 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark55(81.38078574805405,-1.396591493070484,0 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark55(81.39403111493141,-1.393470877462243,0 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark55(81.39748144649658,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark55(81.40970898537608,-0.11619561739190942,0 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark55(81.4106445992662,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark55(81.42126281114906,-0.5246201979236806,0 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark55(81.50741368914183,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark55(81.5128689067021,-0.23589543859007733,0 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark55(81.51497599613064,-0.7703263776440279,0 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark55(81.58026396179459,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark55(81.59127174142833,-0.3844954489990981,0 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark55(81.67974114607871,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark55(81.71939258185316,-1.3149498910572248,0 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark55(-81.750127036111,-0.4510009370993089,45.60415161299201 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark55(-81.7813397999269,-0.2762343490542792,-1.0 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark55(81.78482600770099,-1.1888478596594672,0 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark55(81.83957490020317,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark55(81.92346338116457,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark55(81.9576705115253,-0.7175431667349506,0 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark55(81.96343662668158,-1.3104755135787372,0 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark55(81.97260140708875,-1.4999999999999911,0 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark55(8.197849919615123,-1.3341543744363893,0 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark55(81.99232730137388,-0.7838275935464196,0 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark55(82.02438577494556,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark55(82.03597668595984,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark55(8.204157660121552,-1.436996221274942,0 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark55(82.06811384551162,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark55(82.06874646219322,-0.556408785753391,0 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark55(82.07474004685514,-0.8703702443535365,0 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark55(82.09395952541612,-0.5303014353085302,0 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark55(82.11587535029511,-1.3500065743932834,0 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark55(82.17387970420535,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark55(82.20188444837146,-0.9674950335243704,0 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark55(82.24692184490088,-0.7778116904491545,0 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark55(8.22550982715957,-0.5497515492536316,0 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark55(82.31329920954687,-0.5534286138933489,0 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark55(82.32784613671646,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark55(82.37553400923792,-0.09234289952390001,0 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark55(82.3994588142063,-0.1395368758234916,0 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark55(82.48914890154981,-0.622363026081203,0 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark55(82.49780152240126,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark55(82.55610605720628,-0.937672483094687,0 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark55(82.560601316933,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark55(-82.56693901109335,-1.4999999266830844,-14.775329801381684 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark55(8.259676390027764,-1.0675644418436665,0 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark55(82.6191677341969,-0.7288344167888301,0 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark55(-8.26249943192785,20.46754742247137,48.44157457996039 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark55(82.62755206814774,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark55(82.77628224723725,-56.67154274378665,-37.97766054345857 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark55(82.79183057787415,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark55(82.80014595709645,-0.4894488109431965,0 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark55(82.87590721331301,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark55(82.89862821594065,-0.5176052739493235,0 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark55(82.92518813683577,-1.1025121707204173,0 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark55(82.97578503712083,-0.8653532356126528,0 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark55(83.03797176931909,-0.39704755373736145,0 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark55(83.09070311897898,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark55(8.3113210525337,-0.610905140443653,0 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark55(83.16948436089783,-0.08101597127065574,0 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark55(83.18813575145728,-1.206904442393989,0 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark55(83.24922686106675,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark55(8.327853332799101,-1.4999999998931937,0 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark55(8.329683599361692,-1.871689076834299E-9,0 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark55(83.33201060545858,-0.3472462576362846,0 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark55(83.42913685105535,-0.45969519533731784,0 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark55(83.46143276253076,-0.6551507747001324,0 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark55(83.4688590235177,-0.7942147035648883,0 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark55(83.4794306915534,-0.9227448446154369,0 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark55(83.51595968577965,-0.687093222998266,0 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark55(83.53176421398587,-1.2619085212720842,0 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark55(83.53482554874893,-1.86457285673921E-8,0 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark55(83.53852991192184,-1.483767479019101,0 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark55(83.54079975176444,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark55(83.57875253144985,-1.331709555703939,0 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark55(83.58608163854166,-1.0259172476650633,0 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark55(83.71710489556529,-1.1828694763254077,0 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark55(83.719891129954,-0.6356680864113997,0 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark55(-83.72976168250213,-0.4860842061834951,0.6931861434857467 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark55(83.78464410299384,-0.3109499795333335,0 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark55(83.89293291957273,-0.2233690199572942,0 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark55(83.91629187104243,-1.1629215028948046,0 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark55(83.94388918117805,-0.1841983840992205,0 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark55(83.9558386381427,-1.4999999999999933,0 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark55(8.398318529679772,-1.1430715068326425,0 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark55(8.399786487881158,-0.29308936896026694,0 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark55(84.07433350532914,-0.7675362683439886,0 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark55(84.10426209381058,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark55(84.14456049594513,-0.4381865790417632,0 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark55(84.17752024348403,-1.0426728060383077,0 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark55(-84.19660932503002,-6.833958073646528E-8,-52.101030993828864 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark55(84.20807482277439,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark55(8.422375825735486,-0.061283022267495324,0 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark55(8.423425088252731,-0.021292849658431492,0 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark55(84.26699615169693,-1.1388283055941972,0 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark55(84.27727392456808,-1.4206552315410086,0 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark55(84.34429896645693,-0.7949245479382121,0 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark55(84.37647658312183,-0.62604273196136,0 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark55(84.38114180341036,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark55(8.441200036018742,-1.2678073330895674,0 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark55(84.42711920540106,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark55(84.44711712590603,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark55(84.49604179941197,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark55(84.513928176805,-0.022690615248142088,0 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark55(84.55203535738161,-0.3873429123134131,0 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark55(84.6207733233295,-1.47289544695323,0 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark55(84.62600829142823,-0.06141465813817326,0 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark55(8.4890932497084,-0.7838617142567728,0 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark55(-84.9377559396804,-0.6944238227105766,-48.88712503440824 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark55(84.95749700537104,-2.252202962580535E-5,0 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark55(85.02441147311981,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark55(85.03288319124681,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark55(85.07705881452063,-0.48635087534059096,0 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark55(85.1141100571692,-0.25101630818784504,0 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark55(85.13284920722845,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark55(85.16602439096667,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark55(85.26507485866429,-1.3248515554692795,0 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark55(85.31090661847463,-0.9990937022146582,0 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark55(8.531437167809585,-1.462324350120591,0 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark55(85.3265597063889,-1.3707852829189875,0 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark55(85.33983452437528,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark55(85.3399972016459,-0.571045018319364,0 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark55(85.38994648322341,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark55(85.4246730658704,-0.503171926161361,0 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark55(85.47571790570558,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark55(85.48589300719689,-1.3651400377797227,0 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark55(85.49019776931729,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark55(85.52441108399273,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark55(85.56830907717188,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark55(85.61940556459336,-0.5073167390961046,0 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark55(85.6375356763588,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark55(85.7091720068336,-0.9561969356726179,0 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark55(85.73283798689769,-1.1486691598306251,0 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark55(85.78013902240548,-1.3576253808125216,0 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark55(85.87002739985203,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark55(85.87509268713154,-0.25759607917050864,0 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark55(8.601239560417117,-0.37171688819815607,0 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark55(86.04548439246523,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark55(8.605175722115959,-1.0091470727824117,0 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark55(86.07952706210747,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark55(86.1142758380532,-0.4890803090351006,0 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark55(86.26441801686676,-0.539232455904127,0 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark55(-86.27196111746035,-0.877779860877313,-1.0 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark55(86.31563411452595,-0.7301240772464513,0 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark55(86.33567891664124,-4.221362772661505E-7,0 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark55(86.34809082621996,-1.0980270489304331,0 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark55(86.40480863129974,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark55(86.47661966751761,-0.2352700021780857,0 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark55(86.4969451813252,-0.11614829466077967,0 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark55(86.56677232949716,-0.005455210488552353,0 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark55(86.60445352890986,-1.262297871189233,0 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark55(86.64084598354299,-0.11273538333657918,0 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark55(86.64662800080514,-0.700366147375393,0 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark55(86.73941943936916,-1.4991084692400203,0 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark55(86.7481393197793,-2.6986717195544288E-5,0 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark55(86.78512359402998,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark55(86.9306741544066,-0.1123616600832622,0 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark55(86.93471674982743,-0.2570506267726147,0 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark55(86.94826097969616,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark55(86.98106806311898,-1.4202640110440368,0 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark55(87.01643575545467,-0.3687235395605448,0 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark55(87.03809660831486,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark55(87.06876312282996,-0.4192652124298877,0 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark55(87.10013583546558,-0.021274758436319985,0 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark55(87.10668467203321,-0.2038331756054692,0 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark55(8.712466397425585,-0.1723872805782899,0 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark55(87.1806121154753,-0.29306724486531266,0 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark55(87.18947762848066,-1.3453674708841121,0 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark55(87.19451367208234,-0.7521969339534591,0 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark55(87.2552080783756,-0.09341114265652095,0 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark55(87.2695545146901,-0.8051065495495067,0 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark55(87.31107885736176,-0.5491816503685265,0 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark55(87.35954056344266,-1.3072441542383604,0 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark55(87.4103516615977,-1.48462414490083,0 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark55(8.742583952062645,-0.3069458277641792,0 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark55(87.43095896276407,-0.5420009476643612,0 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark55(87.54717724971857,-0.4730815682009233,0 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark55(8.757923670604288,-0.9076484930967011,0 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark55(87.62423430604136,-0.06133334616387387,0 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark55(87.64112324177083,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark55(87.67906921461906,-0.6786105631775707,0 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark55(87.7775317278518,-0.6300327880695348,0 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark55(87.78821475848312,-0.05917385564077272,0 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark55(87.79568342153047,-8.714110676406019E-4,0 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark55(-87.83838474871692,-0.7539112671217936,-1.0 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark55(87.90084558246932,-1.0225236422452042,0 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark55(88.00606068611509,-0.6233430038611409,0 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark55(88.03111790215931,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark55(88.05235226365517,-1.2495302936626007,0 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark55(88.136170271899,-0.7850122708143603,0 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark55(88.13708935126044,-1.3356090154731959,0 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark55(88.19636525374986,-1.0655373826455445,0 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark55(88.21077741968674,-1.3239756881593978,0 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark55(88.23189129300565,-0.40267856571005156,0 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark55(88.35051666555341,-0.7454416943420057,0 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark55(88.36878358169153,-0.9921986649438708,0 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark55(88.44131116967756,-1.0518529381211223,0 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark55(88.46871800977951,-0.17328389365032137,0 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark55(88.47360994794101,-0.049406677440963165,0 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark55(88.47575700221955,-0.12636033073969277,0 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark55(8.851187570407786,-1.4999999974551415,0 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark55(88.5206198355496,-0.5862183876491827,0 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark55(88.52067997513817,-0.25534500708009666,0 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark55(88.58074140972448,-1.1160130415090777,0 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark55(88.61536286209775,-0.2558459243246327,0 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark55(88.69106553298278,-1.060281984979639,0 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark55(-8.874130681968062,-0.9637757890134823,-1.0 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark55(8.874133270120753,-1.4999999982019758,0 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark55(88.74242627500425,-0.29874783331440824,0 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark55(8.877131676503456,-3.13301416916756E-8,0 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark55(88.77395461609098,-0.2967023103816757,0 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark55(8.881784197001252E-16,-0.4849046572145501,0 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark55(88.82704294189563,-0.804276766403575,0 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark55(88.83022234085593,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark55(88.8735113579489,-0.8716166125818363,0 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark55(88.89830815564477,-0.5148118256230427,0 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark55(88.92120298343772,-0.7888666930884336,0 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark55(88.93033880035881,-0.4471176798778913,0 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark55(88.93503619958904,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark55(8.90388684556794,-0.46989625731291973,0 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark55(89.07066866943404,-1.4999999999999805,0 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark55(89.09793821797913,-0.2869929750320068,0 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark55(89.10533613477891,-1.465433081761212,0 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark55(89.14922420791478,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark55(89.30840915445086,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark55(89.41213838833173,-0.868263932029862,0 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark55(89.48207720004764,-0.0734077468081118,0 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark55(89.48380808666701,-0.890300914551517,0 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark55(89.50514767728744,-0.7911107386406842,0 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark55(-89.50949149243314,-0.32194352170616813,-3.4572687313138033 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark55(89.73706907988844,-0.9212565074519432,0 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark55(89.76102270459512,-0.6452264361002307,0 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark55(8.976114308293507,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark55(89.7636092684063,-1.4999831288939254,0 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark55(89.87493199078202,-1.4722913484532871,0 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark55(89.88654155918107,-0.16557052421844531,0 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark55(89.89842754598905,-1.4999999999868816,0 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark55(89.91568720546582,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark55(89.94918848571061,-1.4999999999999876,0 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark55(-90.00609040134306,-0.5193280488741072,1.0 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark55(9.006649678197848,-1.7665517858656758E-6,0 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark55(9.018442854735142,-1.4839139247218092,0 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark55(90.19668621352417,-0.28749041345822235,0 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark55(90.25752096992755,-1.499999999996069,0 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark55(9.026011725483068,-2.8328281517806157E-9,0 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark55(90.2851425642877,-1.1345724719924846,0 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark55(90.33120547307774,-0.8147105895153962,0 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark55(90.34050474612744,-1.063295959671784,0 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark55(90.35052733187953,-1.2753342072944474,0 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark55(90.3520887827433,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark55(90.38791065184036,-0.8312262249348454,0 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark55(90.39446123517499,-0.37593393514782747,0 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark55(90.4100707807182,-0.06000976889144116,0 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark55(90.44720219963881,-0.08838412030465892,0 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark55(90.45940887321149,-1.0814398614788778,0 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark55(90.46882098031827,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark55(9.047332016041969,-0.11960920467083458,0 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark55(9.04769700782392,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark55(90.57117533797819,-0.3207872303559194,0 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark55(90.57737295086437,-0.004747009988897766,0 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark55(90.6014432085203,-1.4905261108987125,0 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark55(90.67891914401204,-6.243172198353506,-49.268907775339365 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark55(90.6887836814694,-0.6025909380632584,0 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark55(90.69812940886027,-0.32566998229026467,0 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark55(90.7277588308101,-0.2788742336626957,0 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark55(90.75386423751735,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark55(90.82414030761527,-0.06629763572149727,0 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark55(90.92867020064438,-1.2541730662616022,0 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark55(9.098537979999554,-1.2778255068848534,0 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark55(9.099434482631464,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark55(91.01191914847732,-0.022634189219260747,0 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark55(91.08431433666581,-0.035352959668781374,0 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark55(91.10542660087734,-0.6765447545565948,0 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark55(9.113902524445497E-305,-0.22357191856971248,0 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark55(91.16403797748657,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark55(91.18435124802281,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark55(91.20139408043262,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark55(91.21923545222258,-0.5239472761807831,0 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark55(9.124042033131246,-0.4195509484712474,0 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark55(91.31566527646794,-1.1893491341207576,0 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark55(91.3458143376802,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark55(91.35386874498877,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark55(91.41120560432253,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark55(91.47552138491076,-0.5253722197299453,0 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark55(91.64126321828957,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark55(91.65191621515453,-0.591914659304809,0 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark55(9.175626479484649,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark55(91.82267177811349,-0.5658736254533443,0 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark55(91.82673200581763,-0.7845636697634273,0 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark55(-91.90836143388577,-1.3960547170229374,72.1261980392709 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark55(91.93987154931932,-7.450258308049774E-10,0 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark55(-92.0310598190628,-0.03341316453045724,0.2046474247990413 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark55(92.06389370704122,-0.022980607665061825,0 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark55(92.26938018259864,-0.319337165531147,0 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark55(92.30902052539705,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark55(92.31569367423657,-0.7496462463235538,0 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark55(92.34976656552806,-0.25319220658492725,0 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark55(92.35982423791128,-0.3488218650860233,0 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark55(92.3622091081065,-1.08964951576636,0 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark55(92.44899809531417,-1.727092153017037E-9,0 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark55(92.46168830160778,-0.7630444048503335,0 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark55(92.55884391185641,-2.5037494794279663E-5,0 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark55(92.57574935355956,-1.1937771801004429,0 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark55(92.57838753464375,-0.01111998980466744,0 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark55(92.60529715443144,-0.3682070797067629,0 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark55(92.60804535734883,-1.239915363952576,0 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark55(92.74162775422909,-0.24487745359562374,0 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark55(92.80453406051527,-1.150962989982313,0 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark55(92.85116386195345,-0.37802827771267467,0 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark55(92.85338319075116,-0.04834107187158407,0 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark55(92.88200276860294,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark55(92.99490642581974,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark55(93.0014426190425,-1.4999999999281306,0 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark55(93.00590526107294,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark55(93.04094598850969,-0.4659143406592754,0 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark55(93.04343330491525,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark55(93.05267296501714,-1.4999999999999911,0 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark55(93.05967468081761,-0.19029584475343597,0 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark55(9.306796275044931,-0.6635850151044409,0 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark55(9.309081608375209,-0.013965494763155561,0 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark55(93.12399758419531,-1.1106594130500582,0 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark55(-93.1432629891006,-0.2020748043920484,-1.0 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark55(93.1433771463171,-1.3695629250606984,0 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark55(93.14663880851242,-1.158983314258918,0 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark55(93.20944987616218,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark55(93.28519941511635,-1.4917117438461094,0 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark55(93.37275115864213,-0.18631900463712725,0 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark55(93.38780204380984,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark55(93.397711770972,-0.6591130733281574,0 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark55(93.40858395474686,-0.21258055700485556,0 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark55(-93.4125795900606,-0.3718673602289835,-1.7290327071306454E-223 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark55(9.34347862440488,-0.3061264636608807,0 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark55(93.43565509602851,-1.4285352768778221,0 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark55(93.44676174514944,-1.2359164342505546,0 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark55(93.54159910469376,-0.9741553215113496,0 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark55(93.55535175612346,-0.6056949120158204,0 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark55(93.57230610476509,-0.8303127613641004,0 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark55(93.5873423130339,-0.0749886391777892,0 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark55(93.59665395913983,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark55(93.60440772698641,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark55(93.61027028004004,-0.008414088128579689,0 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark55(93.66244997861597,-0.8631486660446654,0 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark55(93.75651355071759,-0.13586945045549775,0 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark55(93.79144226903301,-0.13922780067827034,0 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark55(93.79406218531821,-0.12871551891465471,0 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark55(93.79933878084933,-0.4460714517745572,0 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark55(93.80115514596233,-0.08466066996213328,0 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark55(93.92120358587368,-0.6811127939719199,0 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark55(9.395370086425885,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark55(94.03774490413727,-0.20845146555335914,0 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark55(94.04195344774152,-0.21160251310526235,0 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark55(94.06491343759966,-0.8510230209477392,0 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark55(94.08958201626098,-0.0035896984396142084,0 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark55(94.09198738751388,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark55(9.415343928209051,-1.3216005354860556,0 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark55(94.27121969149609,-0.0760187299766577,0 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark55(94.28474184447632,-1.3897436830866141,0 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark55(94.34630506500099,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark55(94.38315852276116,-0.1002623351221903,0 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark55(94.45239792611818,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark55(94.68035977952636,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark55(94.69564263466691,-1.1124095835338466,0 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark55(94.74454258680552,-1.097878984192269,0 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark55(94.78094301740998,-1.3828012372548977,0 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark55(9.4793477351487,-0.9843619935361172,0 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark55(94.80061631206357,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark55(94.80855036157848,-0.3811434776037146,0 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark55(94.81703372848699,-0.8045061752963871,0 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark55(94.84758163786012,-1.0999260780770372,0 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark55(94.88233169753676,-1.4959421148518233,0 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark55(94.910123417063,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark55(-94.93338520247626,-1.3242130844201326E-6,-100.0 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark55(94.9538985652828,-1.4372461428556136,0 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark55(94.9669508553441,-0.8628740182041668,0 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark55(95.02645176918125,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark55(95.08206324103926,-1.4628139879577945E-9,0 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark55(95.14629621630172,-0.975357124343482,0 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark55(-95.15008493870593,-1.471384061862802,0.5544651264342869 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark55(-95.19203031742695,-1.4999999999999991,-0.5608259581380997 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark55(95.26281120433558,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark55(95.26502459171542,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark55(95.27118625138502,-1.4060148083364599,0 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark55(95.32833190288255,-2.0042310879499436E-9,0 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark55(95.32923245159313,-0.0366476094840136,0 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark55(95.33924635882178,-0.05377227413675989,0 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark55(95.3778865425108,-0.4305110914699838,0 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark55(95.38322514371222,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark55(95.39089489849991,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark55(95.41839042228304,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark55(95.48011227212874,-0.8688298801897645,0 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark55(95.5949099298175,-0.3873553692710132,0 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark55(95.60913402105518,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark55(95.64568521616623,-0.8656451688473928,0 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark55(95.71940792040056,-0.4157947439315133,0 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark55(9.575754439517098,-0.24552016445782954,0 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark55(95.92998608925058,-0.5921322559707782,0 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark55(95.94603071256697,-0.7869899016368418,0 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark55(95.96002314005506,-1.487673630841197,0 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark55(95.97019826718949,-0.8535117724418801,0 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark55(96.00065404184431,-0.5584431954446412,0 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark55(96.04630096050673,-0.8908866152507926,0 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark55(96.04734646713229,-0.3837252071317807,0 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark55(96.08268797848615,-0.2948465368077535,0 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark55(96.13460285863977,-0.7415411637509348,0 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark55(96.2500834389727,-0.341932968510885,0 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark55(96.25831278811148,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark55(9.625839623193206,-1.4077326308365987E-9,0 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark55(96.35253375162279,-0.05249804127322477,0 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark55(96.37881500373999,-0.245389388339033,0 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark55(96.41776652471606,-1.4357079618886077,0 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark55(96.43022147309031,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark55(96.45697419135874,-1.0973610063323294,0 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark55(9.653462158315705,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark55(96.73860035296141,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark55(96.74379216770609,-0.3844519054513098,0 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark55(96.76547344577531,-0.9084081693233657,0 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark55(96.89413054699449,-0.13402626404138118,0 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark55(96.89541498718242,-1.2804227208606846,0 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark55(96.99576482671964,-1.075807590147045,0 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark55(96.99744666977267,-0.11429947457465595,0 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark55(97.00416528825858,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark55(9.716538044425945,-0.6327183903009194,0 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark55(97.23781176070804,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark55(97.3758523767579,-1.1686919726937859,0 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark55(97.37850146299365,-0.32989672539543413,0 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark55(97.4034189754658,-0.5639527804090783,0 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark55(97.41340658873543,-0.5870576824404871,0 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark55(97.43361411038882,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark55(97.45520663282512,-6.594080124634561E-5,0 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark55(97.47149982151115,-0.023077762680174363,0 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark55(97.50690946961585,-8.63655742070846E-10,0 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark55(97.50770636838246,-1.4999999997221891,0 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark55(97.57031392676492,-1.4339889699742336,0 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark55(9.758985895079554,-1.239024994499495E-7,0 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark55(97.62922303879003,-0.8555927033324071,0 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark55(9.764979813513985,-1.1057503437965748,0 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark55(97.66950372695248,-1.4999999999998934,0 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark55(97.69416542732677,-1.061387041057431,0 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark55(97.73883108899204,-0.8331016973349534,0 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark55(97.89072678338022,-0.5355376947790615,0 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark55(-9.7905169673349,-1.4999997451984834,-63.30965337022639 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark55(97.90653698092066,-1.233384108912988,0 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark55(97.91233145175474,-0.4289030738045314,0 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark55(98.10136956152314,-1.4228907764351004,0 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark55(98.18162890403069,-1.0116253877417703E-9,0 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark55(98.25249815312421,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark55(98.27284102716442,-0.39712326667035414,0 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark55(98.30117030214058,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark55(98.30580710912676,-1.2538838102689027,0 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark55(98.40145268675556,-0.4085861578070906,0 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark55(98.62368522088784,-1.4720409866124697,0 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark55(98.63022462919363,-0.9908332603554344,0 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark55(98.63249972692745,-0.4205822416401306,0 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark55(98.64707622165446,-1.1232551954775403,0 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark55(98.65084840300332,-1.4999999999999254,0 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark55(98.66102782627101,-1.3863522406423496,0 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark55(98.72521083135639,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark55(98.84276652656635,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark55(98.91208354214936,-0.4529125170990569,0 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark55(99.00323500803756,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark55(99.02561348706485,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark55(99.0849261073231,-1.3974064306290144,0 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark55(99.10448128367156,-0.45756086192096745,0 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark55(99.11505467151244,-0.37683118540141436,0 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark55(99.20973384851692,-1.3188181091787357,0 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark55(99.21529696828847,-1.1078812747332307,0 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark55(99.31207344831657,-0.0035803670287037903,0 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark55(-99.41300779423055,-1.4999996654212402,1.9742063534922827E-177 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark55(-99.41477952499582,-1.3989312363148996,1.0 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark55(99.44502001869662,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark55(-99.46202989695185,-0.0585656705229546,-1.0000000000000036 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark55(99.46564328376141,-1.3146470831316739,0 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark55(99.47664095011143,-1.175679519591256,0 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark55(-99.60671804485308,-1.4256127126593168,0 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark55(99.61801081797063,-0.7765793439683506,0 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark55(99.62895883843586,-0.6769909837693717,0 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark55(99.65363075576644,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark55(99.76128155252505,-0.8721323991404972,0 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark55(9.978428274027552,-0.5427051908867071,0 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark55(99.88259456284621,-1.4999999999999147,0 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark55(99.88975793469997,-1.3450838819799382,0 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark55(9.99089986297119,-0.19303316223878042,0 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark55(99.91032134687481,-0.9023673106372188,0 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark55(99.92558369638346,-1.1278030248297413,0 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark55(-99.98694554143896,-1.4999999999999964,0.0625525252429831 ) ;
  }
}
