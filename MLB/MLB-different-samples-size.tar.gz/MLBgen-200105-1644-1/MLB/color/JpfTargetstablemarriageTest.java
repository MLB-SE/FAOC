import org.junit.Test;

public class JpfTargetstablemarriageTest {

  @Test
  public void test0() {
    color.stablemarriage.solve(1,915 ) ;
  }

  @Test
  public void test1() {
    color.stablemarriage.solve(-216,0 ) ;
  }

  @Test
  public void test2() {
    color.stablemarriage.solve(3,0 ) ;
  }

  @Test
  public void test3() {
    color.stablemarriage.solve(4,-366 ) ;
  }

  @Test
  public void test4() {
    color.stablemarriage.solve(486,0 ) ;
  }

  @Test
  public void test5() {
    color.stablemarriage.solve(5,1 ) ;
  }

  @Test
  public void test6() {
    color.stablemarriage.solve(535,0 ) ;
  }

  @Test
  public void test7() {
    color.stablemarriage.solve(5,814 ) ;
  }
}
