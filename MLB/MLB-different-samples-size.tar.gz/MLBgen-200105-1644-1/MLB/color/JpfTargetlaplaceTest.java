import org.junit.Test;

public class JpfTargetlaplaceTest {

  @Test
  public void test0() {
    color.laplace.solve(0.07419951f,-40.89004f,79.3599f,-58.813164f,-44.78414f,0f,-25.296515f,-42.3729f,45.395447f ) ;
  }

  @Test
  public void test1() {
    color.laplace.solve(-0.3281605f,-9.395689f,58.54561f,-0.64692813f,-0.989267f,10.519761f,-1.270285f,-4.434212f,-15.477296f ) ;
  }

  @Test
  public void test2() {
    color.laplace.solve(100.0f,-33.322f,0f,84.873146f,-54.57014f,0f,95.71562f,-45.409832f,0f ) ;
  }

  @Test
  public void test3() {
    color.laplace.solve(100.0f,6.9240623f,0f,17.893305f,-57.90011f,-93.80521f,29.473326f,100.0f,-35.22126f ) ;
  }

  @Test
  public void test4() {
    color.laplace.solve(1.0256736f,4.1026945f,15.385104f,-100.0f,-100.0f,-100.0f,-8.054361f,67.782555f,60.335564f ) ;
  }

  @Test
  public void test5() {
    color.laplace.solve(10.492969f,-36.01653f,23.049786f,-22.011593f,-28.911694f,8.928962f,-69.62765f,-66.54761f,41.577755f ) ;
  }

  @Test
  public void test6() {
    color.laplace.solve(110.275734f,83.24652f,0f,6.8980746f,-77.27979f,-177.74f,-5.4038157f,-28.528572f,-31.452341f ) ;
  }

  @Test
  public void test7() {
    color.laplace.solve(111.63943f,-100.0f,-284.20657f,30.525583f,-4.5530367f,21.516304f,15.012545f,29.544998f,207.6875f ) ;
  }

  @Test
  public void test8() {
    color.laplace.solve(11.172593f,-77.57944f,21.751125f,4.675885f,2.1464698f,64.627396f,5.3844786f,16.86203f,16.819687f ) ;
  }

  @Test
  public void test9() {
    color.laplace.solve(11.439047f,-57.627754f,89.518394f,-29.634796f,-55.53298f,-83.26291f,-74.44525f,-51.60646f,-100.0f ) ;
  }

  @Test
  public void test10() {
    color.laplace.solve(11.554367f,-24.926062f,-5.36781f,-28.85647f,-100.0f,81.282074f,-26.980246f,-81.495476f,0f ) ;
  }

  @Test
  public void test11() {
    color.laplace.solve(116.09557f,90.14073f,0f,-122.01415f,-71.17652f,0f,-34.757435f,-17.015516f,37.87189f ) ;
  }

  @Test
  public void test12() {
    color.laplace.solve(-1.1914943f,-99.54733f,-99.99987f,-5.2186427f,-17.67357f,36.44158f,-2.0095065f,-2.8193817f,8.40555f ) ;
  }

  @Test
  public void test13() {
    color.laplace.solve(12.306442f,-31.214533f,-157.89752f,-19.5597f,-79.26429f,144.77936f,-200.00087f,0f,0f ) ;
  }

  @Test
  public void test14() {
    color.laplace.solve(12.334011f,-29.967138f,60.624058f,-20.696817f,35.948902f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test15() {
    color.laplace.solve(13.308559f,-144.76582f,-106.15586f,-6.7359104f,-36.29221f,17.974913f,-4.2613893f,-11.816153f,1.5384685f ) ;
  }

  @Test
  public void test16() {
    color.laplace.solve(-14.099228f,55.683323f,75.50998f,-13.312073f,28.441267f,23.32748f,-67.59033f,48.066334f,-10.724242f ) ;
  }

  @Test
  public void test17() {
    color.laplace.solve(14.333109f,-73.798676f,0f,-5.8751183f,-32.330025f,-100.0f,-5.5035567f,-16.139109f,-26.722855f ) ;
  }

  @Test
  public void test18() {
    color.laplace.solve(14.561736f,-47.61756f,32.04512f,5.864506f,14.310427f,8.176656f,-5.4141383f,90.81811f,-13.648923f ) ;
  }

  @Test
  public void test19() {
    color.laplace.solve(14.748594f,-41.553314f,4.393275f,0.5476937f,-11.096078f,-45.688618f,-1.4617416f,-6.39466f,-13.02082f ) ;
  }

  @Test
  public void test20() {
    color.laplace.solve(15.035685f,95.96792f,0f,59.970615f,35.26072f,0f,14.774404f,-0.8730005f,0f ) ;
  }

  @Test
  public void test21() {
    color.laplace.solve(-15.103701f,-88.01813f,-27.665316f,-72.396675f,55.389847f,0f,2.630633f,82.91921f,-76.178375f ) ;
  }

  @Test
  public void test22() {
    color.laplace.solve(-15.17355f,80.01553f,37.185936f,-0.17302781f,31.238066f,41.3073f,-16.756628f,3.8024554f,96.80521f ) ;
  }

  @Test
  public void test23() {
    color.laplace.solve(-1.5225592f,-82.41319f,0f,-3.7490623f,-52.163677f,0f,-7.609956f,0f,0f ) ;
  }

  @Test
  public void test24() {
    color.laplace.solve(15.431531f,-17.106556f,-99.99994f,-21.167322f,-83.85781f,-30.714245f,-16.243006f,-43.8047f,-75.11798f ) ;
  }

  @Test
  public void test25() {
    color.laplace.solve(15.594033f,-42.995296f,-61.558506f,5.3714314f,11.55463f,-6.736413f,-5.6629386f,11.466324f,0f ) ;
  }

  @Test
  public void test26() {
    color.laplace.solve(15.701379f,-98.36415f,72.35217f,-0.74594194f,-46.997982f,-6.011511f,28.312836f,-82.87033f,-7.983021f ) ;
  }

  @Test
  public void test27() {
    color.laplace.solve(16.059898f,33.077747f,-72.66809f,-68.83816f,88.919174f,100.0f,-13.436461f,15.092312f,-15.113467f ) ;
  }

  @Test
  public void test28() {
    color.laplace.solve(1.6196746f,-69.62137f,72.49351f,-23.899933f,-93.511826f,-100.0f,-3.7075765f,100.0f,0f ) ;
  }

  @Test
  public void test29() {
    color.laplace.solve(16.876373f,-50.453735f,-57.98076f,17.95923f,39.687057f,-39.095566f,15.273492f,43.13474f,-5.732345f ) ;
  }

  @Test
  public void test30() {
    color.laplace.solve(17.342787f,24.02388f,16.737085f,-54.652737f,-37.984352f,-57.07554f,-21.323555f,24.633482f,0f ) ;
  }

  @Test
  public void test31() {
    color.laplace.solve(17.429146f,-14.406597f,-53.702557f,-15.876819f,21.216108f,-12.942632f,-8.28356f,-17.257421f,-81.962234f ) ;
  }

  @Test
  public void test32() {
    color.laplace.solve(17.534689f,1.3323884f,3.485944f,15.451137f,18.684824f,72.35601f,25.585033f,-14.400234f,7.0618014f ) ;
  }

  @Test
  public void test33() {
    color.laplace.solve(17.619125f,99.99933f,81.85036f,18.158333f,44.584568f,36.620407f,10.429634f,23.560205f,26.82399f ) ;
  }

  @Test
  public void test34() {
    color.laplace.solve(17.641876f,-26.540396f,-57.838512f,-2.8921008f,-12.820238f,40.819603f,-16.390041f,-62.66806f,0.2028794f ) ;
  }

  @Test
  public void test35() {
    color.laplace.solve(-178.91008f,-0.5822991f,0f,-14.821168f,140.20111f,-24.443804f,5.6079144f,37.252827f,3.2022555f ) ;
  }

  @Test
  public void test36() {
    color.laplace.solve(17.92718f,-37.399536f,-14.896261f,9.10825f,-3.9571626f,-52.86557f,22.462982f,80.74368f,0f ) ;
  }

  @Test
  public void test37() {
    color.laplace.solve(-18.237482f,-40.87964f,75.014244f,-15.137085f,-17.874208f,67.129395f,-24.436647f,-82.609505f,-29.214113f ) ;
  }

  @Test
  public void test38() {
    color.laplace.solve(18.428255f,51.368866f,27.084583f,-77.655846f,59.96263f,18.594307f,-44.413963f,-100.0f,-9.459762f ) ;
  }

  @Test
  public void test39() {
    color.laplace.solve(18.61963f,84.77184f,99.64677f,16.18359f,38.3662f,37.698853f,7.7485266f,14.810517f,13.127342f ) ;
  }

  @Test
  public void test40() {
    color.laplace.solve(18.636833f,-7.8066144f,0f,-14.74437f,-38.720455f,0f,37.379375f,0f,0f ) ;
  }

  @Test
  public void test41() {
    color.laplace.solve(18.943893f,-9.613572f,-123.19657f,-14.610117f,-39.38543f,68.82857f,-37.994904f,-231.16107f,0f ) ;
  }

  @Test
  public void test42() {
    color.laplace.solve(18.962933f,-13.897321f,0f,4.7457647f,11.390737f,5.5441723f,-11.370611f,55.171608f,0f ) ;
  }

  @Test
  public void test43() {
    color.laplace.solve(1.925527f,-81.80811f,-68.908966f,-10.489776f,-33.21595f,-8.380959f,-10.668681f,-32.184948f,68.60109f ) ;
  }

  @Test
  public void test44() {
    color.laplace.solve(19.686039f,64.49289f,-95.945244f,8.912233f,13.694208f,-18.790808f,2.2686877f,0.16251746f,-4.57435f ) ;
  }

  @Test
  public void test45() {
    color.laplace.solve(19.764915f,-1.8419254f,-461.5092f,-19.136808f,-59.905666f,-90.12129f,-36.444126f,-127.174484f,141.4994f ) ;
  }

  @Test
  public void test46() {
    color.laplace.solve(19.840857f,-31.488928f,-64.36499f,10.948184f,-59.80881f,-213.26604f,83.75093f,-5.421686f,120.27751f ) ;
  }

  @Test
  public void test47() {
    color.laplace.solve(20.225986f,-34.57069f,-7.223248f,15.47463f,-11.054392f,0f,-75.92783f,63.11691f,0f ) ;
  }

  @Test
  public void test48() {
    color.laplace.solve(20.308865f,18.54517f,0f,-37.309715f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test49() {
    color.laplace.solve(20.35974f,3.4324427f,-22.489132f,-21.993483f,-28.242321f,-40.340347f,-80.091354f,-54.067894f,1.250153f ) ;
  }

  @Test
  public void test50() {
    color.laplace.solve(20.373596f,30.549994f,-14.835431f,-49.05561f,-32.67247f,0f,-3.4654746f,35.19371f,-8.408667f ) ;
  }

  @Test
  public void test51() {
    color.laplace.solve(-20.845102f,54.81756f,0f,-2.200716f,47.148746f,0f,-12.809302f,-49.036495f,-95.32885f ) ;
  }

  @Test
  public void test52() {
    color.laplace.solve(20.910467f,70.47466f,100.0f,-86.832794f,-4.831742f,0f,-28.59065f,-27.52981f,0f ) ;
  }

  @Test
  public void test53() {
    color.laplace.solve(20.95332f,-8.75668f,27.830246f,-7.430041f,-16.730553f,45.614456f,-33.942932f,-96.349945f,-35.480225f ) ;
  }

  @Test
  public void test54() {
    color.laplace.solve(21.23191f,-15.386865f,34.037212f,0.8636174f,-17.436905f,-52.99861f,-0.3405366f,-2.2257638f,8.874387f ) ;
  }

  @Test
  public void test55() {
    color.laplace.solve(21.34706f,-19.474247f,0f,7.4225883f,8.128956f,60.555202f,0.21433961f,-6.56523f,-34.604218f ) ;
  }

  @Test
  public void test56() {
    color.laplace.solve(-21.722277f,-54.61982f,0f,27.94362f,-33.178677f,-12.886941f,4.8848686f,-8.404145f,-5.3227715f ) ;
  }

  @Test
  public void test57() {
    color.laplace.solve(22.167099f,-40.377525f,-99.874504f,29.045918f,44.78973f,99.96407f,49.226837f,90.52646f,100.0f ) ;
  }

  @Test
  public void test58() {
    color.laplace.solve(22.631649f,-2.446451f,-89.30573f,-7.0137286f,-43.257896f,-208.893f,-5.2038608f,-12.818618f,-48.914234f ) ;
  }

  @Test
  public void test59() {
    color.laplace.solve(-22.84147f,86.51867f,0f,14.747358f,55.341827f,-70.85478f,26.489075f,91.20894f,14.561272f ) ;
  }

  @Test
  public void test60() {
    color.laplace.solve(23.219803f,-12.207517f,7.3267045f,5.0867267f,-7.034558f,98.68721f,4.161661f,11.559918f,35.85532f ) ;
  }

  @Test
  public void test61() {
    color.laplace.solve(23.56947f,-10.416134f,-35.580986f,4.694013f,-4.44522f,-42.008884f,-0.3481967f,-6.0868f,-19.553783f ) ;
  }

  @Test
  public void test62() {
    color.laplace.solve(23.808807f,-10.142476f,24.212406f,5.377708f,42.828262f,1.5727394f,-45.126236f,-84.063515f,0f ) ;
  }

  @Test
  public void test63() {
    color.laplace.solve(24.331873f,16.029797f,90.19725f,-18.702301f,-5.229787f,0f,5.5115924f,41.758686f,0f ) ;
  }

  @Test
  public void test64() {
    color.laplace.solve(24.46988f,-29.747911f,100.0f,27.627426f,70.54184f,-98.62779f,15.497984f,34.364513f,51.41822f ) ;
  }

  @Test
  public void test65() {
    color.laplace.solve(24.480278f,5.1400156f,-73.40807f,-7.218901f,-30.616383f,-20.386644f,-22.7395f,-100.0f,22.47787f ) ;
  }

  @Test
  public void test66() {
    color.laplace.solve(24.544535f,38.25621f,-27.331726f,-40.07807f,55.812027f,-7.752549f,100.0f,-18.735395f,0f ) ;
  }

  @Test
  public void test67() {
    color.laplace.solve(24.597296f,47.17542f,60.069794f,-48.786236f,4.0345826f,93.10375f,-12.736818f,-2.1610374f,0.05808533f ) ;
  }

  @Test
  public void test68() {
    color.laplace.solve(24.620754f,-22.69709f,-42.9466f,21.18011f,-27.762142f,-39.571304f,87.86183f,-69.96028f,-87.57647f ) ;
  }

  @Test
  public void test69() {
    color.laplace.solve(24.673527f,49.10602f,70.24145f,-50.41192f,1.5091108f,-61.10511f,-26.955248f,0f,0f ) ;
  }

  @Test
  public void test70() {
    color.laplace.solve(24.88881f,-97.062706f,-6.889297f,96.61795f,-84.90831f,-14.402594f,19.516836f,-18.550604f,-8.810943f ) ;
  }

  @Test
  public void test71() {
    color.laplace.solve(25.13791f,57.583492f,29.97571f,-57.03185f,75.22035f,-95.388f,-11.606864f,10.604396f,-21.195902f ) ;
  }

  @Test
  public void test72() {
    color.laplace.solve(25.35758f,7.1506815f,-85.941536f,-5.7456737f,42.595936f,76.207214f,-90.93621f,92.771515f,42.561153f ) ;
  }

  @Test
  public void test73() {
    color.laplace.solve(25.62066f,-1.7701305f,57.417362f,4.2527723f,-33.010635f,0f,20.147434f,76.33696f,0f ) ;
  }

  @Test
  public void test74() {
    color.laplace.solve(25.640175f,-13.128054f,5.1258693f,15.688756f,90.72081f,0f,13.106014f,36.735302f,43.114384f ) ;
  }

  @Test
  public void test75() {
    color.laplace.solve(25.708992f,47.27168f,81.674194f,-44.435135f,-18.307888f,-152.83768f,-185.13722f,0f,0f ) ;
  }

  @Test
  public void test76() {
    color.laplace.solve(25.946035f,43.014595f,-110.39771f,-39.23144f,-17.062761f,-50.44699f,-165.82735f,-21.579838f,-67.48109f ) ;
  }

  @Test
  public void test77() {
    color.laplace.solve(26.849398f,24.2218f,56.055443f,-16.824213f,-86.01764f,99.99997f,-10.265524f,-24.237885f,-15.811547f ) ;
  }

  @Test
  public void test78() {
    color.laplace.solve(26.850792f,-77.00562f,0f,28.285744f,66.24216f,83.9992f,20.050024f,32.572533f,0f ) ;
  }

  @Test
  public void test79() {
    color.laplace.solve(2.7058978f,-82.49306f,0f,9.21637f,50.782093f,-11.788429f,-16.622513f,-76.09313f,0f ) ;
  }

  @Test
  public void test80() {
    color.laplace.solve(27.260286f,-21.319633f,89.063515f,30.360783f,37.896755f,65.32702f,56.28609f,77.21884f,38.862446f ) ;
  }

  @Test
  public void test81() {
    color.laplace.solve(27.279673f,15.190637f,-30.586706f,-6.0719485f,-35.930424f,35.7061f,-15.637044f,-56.476227f,0f ) ;
  }

  @Test
  public void test82() {
    color.laplace.solve(2.7525303f,30.536493f,-51.18689f,-12.570287f,-14.860633f,-41.87666f,-38.173042f,-35.53208f,-52.781765f ) ;
  }

  @Test
  public void test83() {
    color.laplace.solve(27.541294f,31.72369f,41.46623f,-21.558512f,-42.11276f,32.228752f,-64.873024f,-41.287895f,0f ) ;
  }

  @Test
  public void test84() {
    color.laplace.solve(27.844452f,-0.2736705f,-41.56485f,11.651482f,7.9270735f,-11.355631f,10.834398f,31.686113f,-64.88413f ) ;
  }

  @Test
  public void test85() {
    color.laplace.solve(28.120497f,41.879677f,-23.176239f,15.313043f,28.310234f,52.075497f,4.821441f,3.972721f,-60.033005f ) ;
  }

  @Test
  public void test86() {
    color.laplace.solve(28.194857f,28.030163f,66.359665f,-15.250733f,-82.43387f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test87() {
    color.laplace.solve(28.258167f,-142.46434f,-63.01467f,-4.7554383f,-53.481163f,-96.62796f,6.2000494f,29.931911f,330.36417f ) ;
  }

  @Test
  public void test88() {
    color.laplace.solve(28.421326f,67.01389f,91.421364f,-53.32859f,48.212883f,-100.0f,-4.631126f,34.80409f,95.63459f ) ;
  }

  @Test
  public void test89() {
    color.laplace.solve(28.462116f,20.120316f,-12.191007f,-6.271849f,-35.789852f,-92.24107f,-17.759663f,-64.7668f,-11.053064f ) ;
  }

  @Test
  public void test90() {
    color.laplace.solve(28.505047f,9.947612f,-82.20067f,4.072573f,-6.5139275f,14.575004f,-5.700827f,-26.875881f,40.242924f ) ;
  }

  @Test
  public void test91() {
    color.laplace.solve(28.728157f,-70.40465f,0f,-8.064687f,-53.0488f,65.54806f,-7.9381013f,-23.68772f,0f ) ;
  }

  @Test
  public void test92() {
    color.laplace.solve(28.979736f,22.213266f,5.923666f,-6.2943196f,-46.050335f,-98.5186f,-8.106682f,-89.25153f,0f ) ;
  }

  @Test
  public void test93() {
    color.laplace.solve(29.012724f,21.693956f,15.547206f,-5.643061f,-57.784103f,-59.50513f,10.501473f,47.648952f,100.0f ) ;
  }

  @Test
  public void test94() {
    color.laplace.solve(29.195097f,8.547846f,-41.667107f,8.232542f,-53.336605f,50.495644f,57.07168f,98.69667f,0f ) ;
  }

  @Test
  public void test95() {
    color.laplace.solve(2.9234517f,11.686474f,43.822445f,-99.99267f,-100.0f,-70.260574f,47.66021f,-50.06145f,0f ) ;
  }

  @Test
  public void test96() {
    color.laplace.solve(29.34946f,21.110962f,-13.79175f,-3.7131195f,-31.113865f,-43.368244f,5.6614256f,26.358822f,0f ) ;
  }

  @Test
  public void test97() {
    color.laplace.solve(29.447098f,58.764164f,40.083176f,-40.975773f,72.04187f,0f,-22.311813f,-66.792564f,0f ) ;
  }

  @Test
  public void test98() {
    color.laplace.solve(29.49103f,20.687319f,0f,31.017046f,82.574104f,20.442001f,12.00305f,16.995153f,-26.59654f ) ;
  }

  @Test
  public void test99() {
    color.laplace.solve(29.53607f,8.738573f,-96.67552f,9.405706f,0.73948574f,-35.169712f,7.34727f,19.983374f,-44.742805f ) ;
  }

  @Test
  public void test100() {
    color.laplace.solve(29.834112f,49.09871f,-9.77235f,-29.762262f,-58.677353f,79.130394f,-90.20581f,74.21632f,0f ) ;
  }

  @Test
  public void test101() {
    color.laplace.solve(29.900293f,12.709793f,-98.094246f,6.891381f,19.033123f,-73.38908f,-19.8374f,40.09172f,0f ) ;
  }

  @Test
  public void test102() {
    color.laplace.solve(29.932068f,65.82749f,-99.89151f,-46.09922f,48.16883f,-100.0f,-10.692535f,3.329082f,-24.15997f ) ;
  }

  @Test
  public void test103() {
    color.laplace.solve(30.19145f,22.553291f,-7.2398806f,-1.7874917f,-33.25008f,-55.96877f,-4.0913363f,-14.577852f,-20.969994f ) ;
  }

  @Test
  public void test104() {
    color.laplace.solve(-30.340958f,-47.91476f,0f,-30.732244f,-45.876015f,0f,-15.682299f,-31.99695f,0f ) ;
  }

  @Test
  public void test105() {
    color.laplace.solve(30.64959f,-47.538857f,0f,64.34469f,-57.84944f,0f,67.09757f,0f,0f ) ;
  }

  @Test
  public void test106() {
    color.laplace.solve(30.721067f,19.599745f,98.81098f,3.2845244f,-16.566706f,-39.91179f,-1.0162634f,-7.349578f,-11.815341f ) ;
  }

  @Test
  public void test107() {
    color.laplace.solve(30.78976f,22.785465f,-18.28094f,0.37618992f,-21.30678f,-195.71983f,-1.1570255f,-5.1153502f,66.38944f ) ;
  }

  @Test
  public void test108() {
    color.laplace.solve(-30.843601f,-22.849125f,0f,-7.5872645f,-0.6771755f,-41.82024f,1.1717194f,12.274142f,0f ) ;
  }

  @Test
  public void test109() {
    color.laplace.solve(31.051016f,42.27725f,39.98091f,-18.07318f,-99.299835f,-72.135796f,-4.043897f,1.8975917f,0f ) ;
  }

  @Test
  public void test110() {
    color.laplace.solve(31.206244f,25.889893f,29.567274f,-1.0649191f,-57.213947f,14.287289f,21.748026f,88.05702f,99.997925f ) ;
  }

  @Test
  public void test111() {
    color.laplace.solve(-31.233345f,196.06357f,-96.0816f,8.0987215f,54.026318f,-19.969452f,9.782936f,31.417852f,-38.406044f ) ;
  }

  @Test
  public void test112() {
    color.laplace.solve(31.253695f,42.27707f,45.708786f,-17.262295f,-7.8541965f,40.558067f,-16.429213f,-48.45456f,0f ) ;
  }

  @Test
  public void test113() {
    color.laplace.solve(-31.260946f,100.0f,90.273254f,-11.933254f,29.048723f,40.649666f,-45.520794f,-12.521522f,43.27669f ) ;
  }

  @Test
  public void test114() {
    color.laplace.solve(31.483454f,21.839573f,6.4466724f,4.094243f,-50.571835f,-100.0f,27.904232f,-92.36824f,0f ) ;
  }

  @Test
  public void test115() {
    color.laplace.solve(31.56675f,1.1590134f,0f,2.7471578f,21.53426f,76.662865f,-42.112377f,5.5680017f,0f ) ;
  }

  @Test
  public void test116() {
    color.laplace.solve(32.07357f,55.748783f,51.54442f,-27.454502f,39.377144f,9.978741f,-11.114615f,-17.00396f,-96.278366f ) ;
  }

  @Test
  public void test117() {
    color.laplace.solve(32.096962f,40.07735f,46.49602f,-11.6895075f,-18.283585f,45.906734f,-60.571404f,-28.27413f,0f ) ;
  }

  @Test
  public void test118() {
    color.laplace.solve(32.15434f,46.08887f,-82.15165f,-17.471523f,90.347046f,0f,-12.22981f,0f,0f ) ;
  }

  @Test
  public void test119() {
    color.laplace.solve(32.40106f,28.17965f,39.52677f,1.4245846f,-29.26106f,-46.43874f,2.5583403f,8.808777f,61.937828f ) ;
  }

  @Test
  public void test120() {
    color.laplace.solve(-32.409016f,38.59894f,0f,-95.701485f,87.92636f,0f,12.371206f,37.578827f,0f ) ;
  }

  @Test
  public void test121() {
    color.laplace.solve(32.557335f,24.660301f,-33.679504f,5.5690413f,-0.23663098f,-100.0f,-10.044539f,100.0f,0f ) ;
  }

  @Test
  public void test122() {
    color.laplace.solve(32.59275f,51.193665f,-9.396421f,-1.409133f,-16.712608f,-31.977411f,-21.516672f,-84.657555f,-18.796064f ) ;
  }

  @Test
  public void test123() {
    color.laplace.solve(32.67564f,23.383383f,-100.0f,7.319175f,3.8626456f,-72.148544f,-7.261586f,-36.36552f,41.05105f ) ;
  }

  @Test
  public void test124() {
    color.laplace.solve(33.070625f,-0.10475581f,0f,-15.8047495f,-87.259735f,80.4365f,-9.029887f,-20.314798f,15.030426f ) ;
  }

  @Test
  public void test125() {
    color.laplace.solve(-33.10897f,-16.945919f,17.037022f,-16.027397f,-29.687931f,-96.55507f,-1.3126853f,10.776656f,74.10724f ) ;
  }

  @Test
  public void test126() {
    color.laplace.solve(33.34301f,31.391598f,33.428406f,1.9804376f,-41.205025f,21.045864f,15.8567915f,61.446728f,-98.73012f ) ;
  }

  @Test
  public void test127() {
    color.laplace.solve(33.351063f,41.977165f,20.487318f,-8.572923f,14.070286f,-60.027893f,-81.713036f,82.90479f,0f ) ;
  }

  @Test
  public void test128() {
    color.laplace.solve(33.35665f,32.17052f,-30.29672f,1.2560835f,25.62215f,-13.009947f,-53.954468f,66.761635f,0f ) ;
  }

  @Test
  public void test129() {
    color.laplace.solve(33.477406f,27.276861f,-30.48898f,6.632756f,6.119016f,-14.333128f,-13.065395f,4.899576f,-14.10262f ) ;
  }

  @Test
  public void test130() {
    color.laplace.solve(33.67218f,70.80485f,67.697815f,-36.116123f,81.8494f,99.98641f,91.61755f,-100.0f,0f ) ;
  }

  @Test
  public void test131() {
    color.laplace.solve(33.689373f,19.626646f,-50.957336f,15.130844f,-4.5359764f,-63.440872f,31.369982f,10.539477f,0f ) ;
  }

  @Test
  public void test132() {
    color.laplace.solve(33.695763f,47.355965f,-76.843285f,-12.57291f,-71.3048f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test133() {
    color.laplace.solve(33.978046f,27.274544f,-61.642555f,8.637641f,-4.948824f,100.0f,5.5213423f,13.447727f,53.21839f ) ;
  }

  @Test
  public void test134() {
    color.laplace.solve(34.06436f,36.73828f,58.926453f,-0.48083624f,-33.776722f,-99.87956f,-2.2109833f,-8.363097f,2.535317f ) ;
  }

  @Test
  public void test135() {
    color.laplace.solve(-34.218304f,-41.404087f,0f,-91.416084f,-88.48123f,0f,-25.03967f,-8.7425995f,78.5505f ) ;
  }

  @Test
  public void test136() {
    color.laplace.solve(34.263412f,22.458757f,-17.942152f,14.594887f,-26.486227f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test137() {
    color.laplace.solve(34.30284f,20.332895f,-26.357313f,16.878477f,23.678625f,74.323044f,9.532441f,-16.819914f,0f ) ;
  }

  @Test
  public void test138() {
    color.laplace.solve(34.734745f,86.69114f,-26.50197f,-47.75216f,-89.329414f,0f,-37.208645f,93.22616f,0f ) ;
  }

  @Test
  public void test139() {
    color.laplace.solve(34.838345f,96.88946f,0f,-0.12755884f,-26.696613f,46.731613f,-8.651966f,-68.15214f,0f ) ;
  }

  @Test
  public void test140() {
    color.laplace.solve(35.20806f,11.333394f,0f,-2.6941645f,-41.711575f,-29.790531f,-4.273145f,-14.398416f,-11.608942f ) ;
  }

  @Test
  public void test141() {
    color.laplace.solve(35.32434f,37.665787f,51.563236f,3.631579f,-36.224434f,68.58715f,15.426411f,58.074062f,0f ) ;
  }

  @Test
  public void test142() {
    color.laplace.solve(35.39951f,28.886087f,-39.31602f,12.711957f,19.46086f,25.087221f,-4.0125413f,-28.762121f,-99.585625f ) ;
  }

  @Test
  public void test143() {
    color.laplace.solve(35.429695f,27.935211f,-35.598972f,13.783569f,11.910126f,-18.73865f,7.7944584f,24.66037f,-100.0f ) ;
  }

  @Test
  public void test144() {
    color.laplace.solve(3.5466456f,15.60659f,0f,27.343996f,93.22561f,-77.2536f,12.603727f,23.070915f,-13.545671f ) ;
  }

  @Test
  public void test145() {
    color.laplace.solve(35.746365f,-52.396397f,-37.015045f,95.38185f,28.90042f,-94.40685f,33.01394f,36.67391f,84.78128f ) ;
  }

  @Test
  public void test146() {
    color.laplace.solve(3.5773113f,-82.33985f,19.830124f,-3.350905f,-11.625442f,6.0602226f,-5.3554897f,-18.071053f,-55.303284f ) ;
  }

  @Test
  public void test147() {
    color.laplace.solve(35.90136f,37.523594f,26.39785f,6.0818405f,-12.258311f,55.496445f,0.68431383f,-3.3445852f,-1.8043436f ) ;
  }

  @Test
  public void test148() {
    color.laplace.solve(35.94791f,13.666459f,-93.04072f,30.125177f,7.926765f,8.576821f,76.62604f,-20.661396f,-38.49228f ) ;
  }

  @Test
  public void test149() {
    color.laplace.solve(35.974304f,39.888336f,17.811289f,4.0088835f,5.7677474f,-38.772022f,-25.706518f,17.945795f,-23.960302f ) ;
  }

  @Test
  public void test150() {
    color.laplace.solve(36.296543f,20.317503f,0f,-27.648727f,-66.76493f,-24.468801f,-80.126526f,-77.66194f,0f ) ;
  }

  @Test
  public void test151() {
    color.laplace.solve(36.32222f,26.074068f,18.318562f,19.214817f,-97.71171f,0f,-15.713567f,-82.069084f,-32.343887f ) ;
  }

  @Test
  public void test152() {
    color.laplace.solve(36.547703f,23.753199f,-37.296852f,22.43761f,-4.238053f,26.231876f,57.440792f,-89.37489f,99.99994f ) ;
  }

  @Test
  public void test153() {
    color.laplace.solve(36.84708f,58.591476f,63.208736f,-11.20315f,34.310085f,40.35315f,-0.64547133f,8.621264f,100.0f ) ;
  }

  @Test
  public void test154() {
    color.laplace.solve(36.87145f,26.109385f,22.057442f,21.376406f,-54.491352f,-37.879616f,-93.777534f,42.45018f,0f ) ;
  }

  @Test
  public void test155() {
    color.laplace.solve(36.95554f,29.218815f,-50.398148f,18.603338f,30.31787f,12.613081f,7.139947f,9.9564495f,2.3679836f ) ;
  }

  @Test
  public void test156() {
    color.laplace.solve(37.00582f,29.824162f,24.986422f,18.199123f,37.40175f,43.39545f,-1.6110758f,-24.643427f,33.142918f ) ;
  }

  @Test
  public void test157() {
    color.laplace.solve(37.263588f,18.655111f,-93.4184f,30.399242f,24.866833f,0f,16.880928f,37.12447f,0f ) ;
  }

  @Test
  public void test158() {
    color.laplace.solve(37.592445f,40.275475f,21.658573f,10.094312f,1.8508711f,-53.64118f,0.93392944f,-7.072068f,0f ) ;
  }

  @Test
  public void test159() {
    color.laplace.solve(37.72281f,4.3351994f,0f,84.46835f,57.431652f,76.54205f,26.004732f,19.55058f,-5.2340693f ) ;
  }

  @Test
  public void test160() {
    color.laplace.solve(38.059273f,41.767624f,-11.9517565f,10.469475f,40.58718f,0f,-22.382631f,-100.0f,-66.679016f ) ;
  }

  @Test
  public void test161() {
    color.laplace.solve(-38.284718f,-67.0413f,-9.177347f,-5.983911f,-10.086103f,16.558764f,24.435177f,16.12203f,9.228396f ) ;
  }

  @Test
  public void test162() {
    color.laplace.solve(38.304443f,20.696968f,100.0f,4.9016175f,0.55362874f,29.480593f,-19.251602f,-52.864662f,17.36874f ) ;
  }

  @Test
  public void test163() {
    color.laplace.solve(38.335167f,35.136883f,-44.153988f,18.203785f,24.53992f,17.028698f,9.940054f,27.790321f,87.72886f ) ;
  }

  @Test
  public void test164() {
    color.laplace.solve(-38.37187f,-38.53239f,14.959364f,-22.819542f,-15.491418f,-99.39901f,-37.414883f,98.78528f,-12.061083f ) ;
  }

  @Test
  public void test165() {
    color.laplace.solve(38.44559f,48.63588f,71.61076f,5.1464863f,4.9709244f,0f,-22.830572f,0f,0f ) ;
  }

  @Test
  public void test166() {
    color.laplace.solve(38.469772f,50.19445f,-65.84885f,3.6846344f,-16.934887f,-95.791336f,-6.796345f,-30.870016f,-99.748825f ) ;
  }

  @Test
  public void test167() {
    color.laplace.solve(38.536724f,-12.7181835f,0f,37.729984f,27.412132f,0f,2.450512f,-27.927937f,61.986313f ) ;
  }

  @Test
  public void test168() {
    color.laplace.solve(38.57833f,40.46134f,-46.718975f,13.851983f,69.98601f,-23.843853f,-53.15641f,72.95089f,0f ) ;
  }

  @Test
  public void test169() {
    color.laplace.solve(38.84001f,52.48439f,84.335754f,2.8756578f,-25.275896f,-57.47438f,-2.0614839f,-11.121593f,-17.148994f ) ;
  }

  @Test
  public void test170() {
    color.laplace.solve(38.86054f,43.773727f,50.454197f,11.668432f,-14.219826f,58.043053f,22.033016f,0f,0f ) ;
  }

  @Test
  public void test171() {
    color.laplace.solve(39.04518f,43.670506f,-99.80291f,12.510226f,7.585858f,-27.044418f,3.4098644f,1.1292313f,-6.478797f ) ;
  }

  @Test
  public void test172() {
    color.laplace.solve(39.399387f,-67.099655f,-22.280964f,-1.1993499f,-35.23367f,-37.98257f,-8.963114f,-34.653107f,-94.41564f ) ;
  }

  @Test
  public void test173() {
    color.laplace.solve(39.445965f,13.25365f,-99.931854f,45.32691f,15.336373f,8.11771f,127.099556f,-4.558642f,116.99719f ) ;
  }

  @Test
  public void test174() {
    color.laplace.solve(39.475937f,49.356956f,48.382126f,8.54679f,9.569759f,48.35623f,-14.858538f,-67.98094f,-41.36573f ) ;
  }

  @Test
  public void test175() {
    color.laplace.solve(39.50903f,33.94286f,-4.8385835f,24.09326f,55.56491f,32.917164f,1.2990987f,-32.497143f,0f ) ;
  }

  @Test
  public void test176() {
    color.laplace.solve(39.902195f,41.772984f,-80.14327f,17.835804f,-91.11533f,0f,16.066376f,46.429695f,100.0f ) ;
  }

  @Test
  public void test177() {
    color.laplace.solve(40.172874f,20.33307f,-35.488472f,20.733759f,24.076967f,27.285217f,18.685196f,27.95582f,-44.78585f ) ;
  }

  @Test
  public void test178() {
    color.laplace.solve(-4.0222254f,-65.008f,20.035686f,-51.0809f,58.067688f,0f,-63.81989f,0f,0f ) ;
  }

  @Test
  public void test179() {
    color.laplace.solve(40.301453f,40.279858f,-7.987811f,20.925959f,32.60418f,46.94404f,10.798204f,22.26686f,42.7932f ) ;
  }

  @Test
  public void test180() {
    color.laplace.solve(40.64203f,48.659008f,45.70346f,13.909114f,8.290542f,39.10863f,6.7193313f,12.968211f,36.862972f ) ;
  }

  @Test
  public void test181() {
    color.laplace.solve(40.84117f,32.158165f,-29.550518f,31.206518f,73.23244f,-60.212673f,10.752463f,11.803333f,0f ) ;
  }

  @Test
  public void test182() {
    color.laplace.solve(40.953606f,57.64512f,10.350293f,6.169306f,-41.891228f,25.158827f,0.7391317f,-3.2127788f,28.300982f ) ;
  }

  @Test
  public void test183() {
    color.laplace.solve(41.017315f,47.4155f,26.431086f,16.653757f,22.2136f,-135.9769f,10.956937f,27.17399f,0f ) ;
  }

  @Test
  public void test184() {
    color.laplace.solve(41.49577f,-81.54227f,-17.6255f,1.4151328f,-30.312017f,-17.612923f,-5.5232205f,-23.508015f,-22.514172f ) ;
  }

  @Test
  public void test185() {
    color.laplace.solve(-41.499203f,12.031664f,0f,-17.200708f,-28.362043f,18.336977f,1.0584152f,21.434368f,53.112972f ) ;
  }

  @Test
  public void test186() {
    color.laplace.solve(41.6406f,-29.049015f,40.21133f,95.611404f,-22.981073f,0f,7.491501f,-65.6454f,86.15223f ) ;
  }

  @Test
  public void test187() {
    color.laplace.solve(41.85115f,31.676916f,0f,13.022518f,27.548147f,66.29566f,-17.309229f,-82.25943f,0f ) ;
  }

  @Test
  public void test188() {
    color.laplace.solve(41.895588f,32.40898f,-25.245686f,23.060843f,30.54417f,10.55327f,19.803608f,56.15359f,36.914597f ) ;
  }

  @Test
  public void test189() {
    color.laplace.solve(42.104847f,49.065964f,-99.99675f,19.353422f,29.506636f,99.957245f,5.802203f,3.8553917f,-11.298619f ) ;
  }

  @Test
  public void test190() {
    color.laplace.solve(42.175888f,49.288506f,52.077007f,19.415047f,31.110525f,81.64025f,4.37377f,-1.9199656f,-43.164158f ) ;
  }

  @Test
  public void test191() {
    color.laplace.solve(42.511814f,42.135345f,2.022803f,27.911903f,24.006771f,14.364476f,45.12903f,51.93902f,0f ) ;
  }

  @Test
  public void test192() {
    color.laplace.solve(-42.562424f,16.111002f,0f,-1.0970627f,-50.3169f,36.787395f,88.49107f,-38.20081f,0f ) ;
  }

  @Test
  public void test193() {
    color.laplace.solve(42.663315f,52.058525f,0.2088957f,18.594732f,25.247349f,6.210563f,6.468263f,7.2783213f,-47.512478f ) ;
  }

  @Test
  public void test194() {
    color.laplace.solve(42.87383f,47.615154f,20.909986f,23.880161f,26.676802f,-3.776439f,25.970018f,38.988327f,-26.938738f ) ;
  }

  @Test
  public void test195() {
    color.laplace.solve(42.896362f,68.81217f,-26.038816f,2.77328f,16.68481f,-35.077785f,-48.488052f,29.246954f,0f ) ;
  }

  @Test
  public void test196() {
    color.laplace.solve(43.3106f,1.7279155f,100.0f,71.51448f,-66.63889f,0f,22.51769f,18.556278f,50.93665f ) ;
  }

  @Test
  public void test197() {
    color.laplace.solve(43.495983f,58.17984f,-31.638836f,15.804096f,17.55418f,6.3930387f,2.1662197f,-10.160251f,39.656807f ) ;
  }

  @Test
  public void test198() {
    color.laplace.solve(43.612995f,82.62778f,-87.88378f,-8.175793f,-53.629025f,0f,64.46336f,89.392815f,0f ) ;
  }

  @Test
  public void test199() {
    color.laplace.solve(43.841846f,56.18336f,34.81302f,19.184021f,46.078587f,-27.467985f,7.933309f,12.549216f,-3.81503f ) ;
  }

  @Test
  public void test200() {
    color.laplace.solve(44.119774f,49.479332f,68.91102f,26.999767f,21.268307f,0f,2.594165f,0f,0f ) ;
  }

  @Test
  public void test201() {
    color.laplace.solve(44.481274f,30.049744f,-74.59709f,47.87535f,50.314793f,23.334223f,96.705345f,99.99985f,0f ) ;
  }

  @Test
  public void test202() {
    color.laplace.solve(44.613197f,-45.02205f,0f,12.796707f,-0.585032f,-54.35135f,7.1586647f,15.837952f,8.777826f ) ;
  }

  @Test
  public void test203() {
    color.laplace.solve(44.639412f,80.84456f,20.470173f,-2.2869112f,-75.22886f,94.19609f,21.441803f,88.05412f,0f ) ;
  }

  @Test
  public void test204() {
    color.laplace.solve(44.952717f,-6.50102f,-97.204544f,86.31189f,-74.634094f,0f,24.509209f,11.724945f,97.024666f ) ;
  }

  @Test
  public void test205() {
    color.laplace.solve(45.223892f,40.945637f,3.9550805f,39.94993f,14.603579f,47.098026f,99.972244f,-69.57928f,100.0f ) ;
  }

  @Test
  public void test206() {
    color.laplace.solve(45.273464f,61.19638f,35.756336f,19.897476f,63.755722f,93.12447f,10.858221f,23.535408f,19.527693f ) ;
  }

  @Test
  public void test207() {
    color.laplace.solve(45.294617f,70.85032f,0f,-85.0115f,-16.992714f,0f,76.97748f,-97.9124f,0f ) ;
  }

  @Test
  public void test208() {
    color.laplace.solve(45.36864f,92.18943f,77.321335f,-10.714872f,-97.87348f,-73.72f,9.6453495f,49.296272f,58.874233f ) ;
  }

  @Test
  public void test209() {
    color.laplace.solve(45.38842f,58.902252f,-46.039673f,22.65142f,37.1144f,0f,9.0733595f,13.642017f,8.380309f ) ;
  }

  @Test
  public void test210() {
    color.laplace.solve(4.5409856f,1.5577555f,-14.074648f,-83.393814f,-84.23531f,25.539175f,-36.269703f,0f,0f ) ;
  }

  @Test
  public void test211() {
    color.laplace.solve(45.62181f,20.185274f,22.85167f,62.30197f,-87.73238f,-52.503914f,-3.2023473f,-20.443096f,0f ) ;
  }

  @Test
  public void test212() {
    color.laplace.solve(-45.934036f,-98.90511f,0f,-98.585304f,64.3236f,20.063602f,-17.983316f,26.652037f,60.267864f ) ;
  }

  @Test
  public void test213() {
    color.laplace.solve(46.018623f,46.551727f,36.11586f,37.522762f,4.0724235f,-2.0882843f,100.0f,99.49654f,0f ) ;
  }

  @Test
  public void test214() {
    color.laplace.solve(46.09126f,72.59104f,6.5284824f,11.773984f,22.412697f,10.731843f,-21.408016f,-5.4460845f,13.74461f ) ;
  }

  @Test
  public void test215() {
    color.laplace.solve(46.586807f,54.33417f,28.8621f,32.013058f,41.88778f,57.380104f,39.577644f,-85.85311f,0f ) ;
  }

  @Test
  public void test216() {
    color.laplace.solve(46.630913f,30.920498f,-98.73062f,55.603153f,75.7817f,-73.277214f,100.0f,0f,0f ) ;
  }

  @Test
  public void test217() {
    color.laplace.solve(46.67387f,75.287155f,9.584952f,11.408326f,2.5918531f,-35.28084f,-3.632419f,-25.938002f,0f ) ;
  }

  @Test
  public void test218() {
    color.laplace.solve(46.816578f,44.95775f,3.1607242f,42.308563f,29.853697f,-55.37805f,0f,0f,0f ) ;
  }

  @Test
  public void test219() {
    color.laplace.solve(46.820328f,16.334492f,0f,12.843228f,1.6931621f,-39.293404f,2.8594227f,-1.4055377f,-10.174735f ) ;
  }

  @Test
  public void test220() {
    color.laplace.solve(47.57153f,63.013306f,36.538353f,27.272804f,67.943344f,-16.859896f,-73.73209f,0f,0f ) ;
  }

  @Test
  public void test221() {
    color.laplace.solve(47.718708f,57.677097f,66.06385f,33.19773f,15.922999f,0f,11.58055f,28.67202f,0f ) ;
  }

  @Test
  public void test222() {
    color.laplace.solve(47.957848f,68.59583f,37.682877f,23.235561f,36.949844f,-100.0f,8.034553f,8.902648f,-9.373806f ) ;
  }

  @Test
  public void test223() {
    color.laplace.solve(48.02256f,66.52863f,51.11f,25.561604f,66.98198f,37.91137f,-12.758126f,-76.59411f,0f ) ;
  }

  @Test
  public void test224() {
    color.laplace.solve(48.064976f,79.1933f,-60.224167f,24.439283f,45.336147f,84.72725f,4.35601f,-7.0152445f,-77.753136f ) ;
  }

  @Test
  public void test225() {
    color.laplace.solve(-48.208946f,-63.550613f,0f,-25.928537f,-49.359875f,-9.490015f,-6.145331f,1.347214f,0f ) ;
  }

  @Test
  public void test226() {
    color.laplace.solve(48.299347f,-48.147133f,0f,-26.186396f,44.005653f,0f,-15.648136f,-36.406147f,-11.567304f ) ;
  }

  @Test
  public void test227() {
    color.laplace.solve(48.413612f,54.025837f,21.768742f,39.628605f,45.921f,-66.950874f,64.17981f,100.0f,0f ) ;
  }

  @Test
  public void test228() {
    color.laplace.solve(48.82316f,55.604935f,-63.774117f,39.687706f,72.15775f,-41.156612f,37.7699f,11.512142f,0f ) ;
  }

  @Test
  public void test229() {
    color.laplace.solve(49.712593f,5.064787f,68.94086f,93.78559f,27.18033f,0f,22.62692f,-3.277908f,-62.918884f ) ;
  }

  @Test
  public void test230() {
    color.laplace.solve(49.90674f,61.432434f,0.8591126f,6.128037f,-1.9266002f,24.733128f,-23.46799f,-100.0f,100.0f ) ;
  }

  @Test
  public void test231() {
    color.laplace.solve(-49.97596f,-95.86018f,0f,4.1094384f,100.0f,0.23490626f,6.0644774f,20.148472f,-25.470589f ) ;
  }

  @Test
  public void test232() {
    color.laplace.solve(-5.0146184f,-93.31576f,-17.575024f,-26.742714f,-83.38795f,-39.10663f,-18.568295f,-47.530464f,-35.567127f ) ;
  }

  @Test
  public void test233() {
    color.laplace.solve(50.569946f,82.28685f,28.351418f,19.992933f,15.93151f,-81.63222f,13.470276f,33.88817f,0f ) ;
  }

  @Test
  public void test234() {
    color.laplace.solve(50.65052f,27.96907f,47.313385f,74.633f,-86.08762f,61.284473f,2.0213747f,-66.54751f,0f ) ;
  }

  @Test
  public void test235() {
    color.laplace.solve(51.172646f,14.367215f,9.040014f,24.264814f,31.836737f,56.780247f,14.0498705f,31.93467f,81.85207f ) ;
  }

  @Test
  public void test236() {
    color.laplace.solve(51.20727f,93.698074f,-48.12861f,11.131021f,-38.733772f,0f,32.050583f,0f,0f ) ;
  }

  @Test
  public void test237() {
    color.laplace.solve(-51.4566f,-56.73389f,0f,17.514734f,9.883796f,0f,2.6104112f,-7.07309f,-48.669365f ) ;
  }

  @Test
  public void test238() {
    color.laplace.solve(51.48252f,25.466087f,30.359936f,80.464f,-79.9781f,-4.026344f,0f,0f,0f ) ;
  }

  @Test
  public void test239() {
    color.laplace.solve(51.648067f,80.582954f,-23.623877f,26.009317f,99.96547f,47.165833f,13.227891f,26.902248f,-5.5843616f ) ;
  }

  @Test
  public void test240() {
    color.laplace.solve(-51.688515f,-43.4666f,19.453758f,-10.751695f,-33.203526f,-54.806248f,41.885265f,-23.78957f,-10.716647f ) ;
  }

  @Test
  public void test241() {
    color.laplace.solve(51.990826f,68.77254f,59.32938f,39.19076f,63.769943f,68.54498f,11.388816f,6.364503f,-49.70075f ) ;
  }

  @Test
  public void test242() {
    color.laplace.solve(52.162197f,66.72025f,27.600555f,41.92853f,87.11827f,100.0f,28.433668f,71.80614f,0f ) ;
  }

  @Test
  public void test243() {
    color.laplace.solve(52.20655f,43.8263f,-71.2815f,64.99991f,-20.880507f,0f,-32.546906f,0f,0f ) ;
  }

  @Test
  public void test244() {
    color.laplace.solve(52.55907f,40.964542f,78.12933f,69.27174f,-66.83023f,92.16611f,31.999428f,0f,0f ) ;
  }

  @Test
  public void test245() {
    color.laplace.solve(52.659634f,73.31247f,62.628212f,37.32606f,77.96203f,77.20038f,18.68258f,39.26412f,0f ) ;
  }

  @Test
  public void test246() {
    color.laplace.solve(52.77797f,8.313677f,0f,-28.534393f,-88.00752f,0f,-78.90802f,0f,0f ) ;
  }

  @Test
  public void test247() {
    color.laplace.solve(5.321837f,-63.770023f,82.27656f,-14.94263f,-59.391617f,-19.938639f,-8.600796f,-19.460552f,-9.849797f ) ;
  }

  @Test
  public void test248() {
    color.laplace.solve(53.222164f,84.90068f,48.591f,27.98797f,42.119568f,14.040084f,16.610153f,38.45264f,95.08085f ) ;
  }

  @Test
  public void test249() {
    color.laplace.solve(53.80838f,97.494194f,-23.852812f,17.739323f,50.74249f,97.4917f,10.116991f,22.728642f,30.055084f ) ;
  }

  @Test
  public void test250() {
    color.laplace.solve(53.90075f,100.0f,0f,-8.618471f,-85.869125f,94.09775f,-2.5055106f,-1.4035707f,82.76035f ) ;
  }

  @Test
  public void test251() {
    color.laplace.solve(5.528962f,-69.85146f,60.012154f,-8.351657f,-28.439543f,-1.9225131f,-10.496049f,-33.632538f,-95.59456f ) ;
  }

  @Test
  public void test252() {
    color.laplace.solve(56.251812f,87.61778f,166.21689f,37.38946f,28.002394f,-47.760216f,-12.772088f,-88.47781f,0f ) ;
  }

  @Test
  public void test253() {
    color.laplace.solve(56.682575f,37.170406f,29.802835f,89.55989f,-37.80378f,-17.959066f,27.670803f,21.123322f,100.0f ) ;
  }

  @Test
  public void test254() {
    color.laplace.solve(57.14638f,65.51135f,0f,15.805436f,8.422443f,89.400986f,-2.347082f,-86.85924f,0f ) ;
  }

  @Test
  public void test255() {
    color.laplace.solve(57.185097f,99.99995f,0f,42.09723f,99.9792f,-100.0f,11.224618f,2.8012419f,-99.998856f ) ;
  }

  @Test
  public void test256() {
    color.laplace.solve(-57.810276f,-83.70984f,0f,-82.39309f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test257() {
    color.laplace.solve(57.99664f,89.76572f,1.5612774f,42.22083f,70.75992f,72.87041f,40.126762f,78.18273f,28.793625f ) ;
  }

  @Test
  public void test258() {
    color.laplace.solve(58.380215f,-57.40646f,0f,43.84055f,61.11772f,76.3509f,55.86426f,-79.50657f,0f ) ;
  }

  @Test
  public void test259() {
    color.laplace.solve(58.55637f,23.601086f,0f,0.22553869f,-160.00845f,0f,-13.564686f,-54.48428f,-44.364292f ) ;
  }

  @Test
  public void test260() {
    color.laplace.solve(60.381832f,-86.85784f,-20.393492f,33.422855f,5.5564017f,86.516846f,67.75318f,-10.856252f,-13.061968f ) ;
  }

  @Test
  public void test261() {
    color.laplace.solve(60.960297f,95.20707f,0f,32.82846f,61.756115f,99.93601f,8.597438f,1.5612905f,-64.10839f ) ;
  }

  @Test
  public void test262() {
    color.laplace.solve(-61.158978f,-23.90537f,0f,-27.48768f,-1.5492163f,65.17555f,-47.242523f,-19.97937f,0f ) ;
  }

  @Test
  public void test263() {
    color.laplace.solve(-6.151302f,2.6886477f,0f,-7.1412525f,-18.375668f,-45.50873f,-4.038039f,-9.010904f,-13.6299095f ) ;
  }

  @Test
  public void test264() {
    color.laplace.solve(62.993324f,-112.06974f,33.142765f,11.699752f,-24.667952f,-40.247578f,8.473634f,41.945892f,-58.896927f ) ;
  }

  @Test
  public void test265() {
    color.laplace.solve(63.53325f,-95.033714f,-69.93723f,20.129845f,-4.793047f,-11.255174f,21.779175f,66.986855f,27.801332f ) ;
  }

  @Test
  public void test266() {
    color.laplace.solve(-63.877743f,100.0f,82.68828f,-10.057635f,30.998745f,53.40115f,-7.3515434f,-19.348537f,99.91758f ) ;
  }

  @Test
  public void test267() {
    color.laplace.solve(64.26231f,79.96233f,74.462456f,77.086876f,45.204803f,0f,43.460697f,37.727802f,0f ) ;
  }

  @Test
  public void test268() {
    color.laplace.solve(64.61969f,65.49466f,24.861008f,92.98411f,72.49795f,-66.05064f,16.196987f,-31.383732f,0f ) ;
  }

  @Test
  public void test269() {
    color.laplace.solve(-66.109924f,36.158165f,0f,-17.242596f,0.66278386f,73.3742f,-3.5232387f,3.1496408f,15.459018f ) ;
  }

  @Test
  public void test270() {
    color.laplace.solve(-66.198975f,-41.878498f,37.2442f,-9.136354f,-0.8638925f,25.732738f,30.517452f,21.826544f,66.550644f ) ;
  }

  @Test
  public void test271() {
    color.laplace.solve(66.84771f,97.41668f,-38.17784f,69.974144f,85.237625f,-56.413845f,23.824085f,25.322199f,-7.772912f ) ;
  }

  @Test
  public void test272() {
    color.laplace.solve(6.703505f,-97.409f,0f,-12.196897f,-78.9103f,0f,-5.45665f,-9.6297035f,30.651377f ) ;
  }

  @Test
  public void test273() {
    color.laplace.solve(67.326706f,32.655907f,0f,-25.642357f,-80.54912f,-3.9312017f,-89.347015f,16.645638f,0f ) ;
  }

  @Test
  public void test274() {
    color.laplace.solve(69.0849f,100.0f,-100.0f,76.33961f,97.50703f,-30.126251f,20.19103f,4.4245133f,-100.0f ) ;
  }

  @Test
  public void test275() {
    color.laplace.solve(-69.15635f,23.818342f,0f,-15.198614f,14.4333f,36.340126f,-6.0714097f,-9.087025f,43.20105f ) ;
  }

  @Test
  public void test276() {
    color.laplace.solve(69.65129f,66.37885f,0f,17.114172f,24.211353f,-28.246351f,-25.405954f,-78.556015f,0f ) ;
  }

  @Test
  public void test277() {
    color.laplace.solve(70.072174f,59.921673f,0f,80.66603f,-82.57606f,0f,-9.128901f,87.806595f,0f ) ;
  }

  @Test
  public void test278() {
    color.laplace.solve(-72.704956f,54.32481f,0f,0.63139164f,-33.076557f,0f,-1.7320532f,-7.559604f,4.570193f ) ;
  }

  @Test
  public void test279() {
    color.laplace.solve(-73.19941f,36.038162f,55.238792f,-16.317873f,11.656043f,25.49851f,-3.728125f,1.4053737f,35.099205f ) ;
  }

  @Test
  public void test280() {
    color.laplace.solve(-73.42215f,-100.0f,0f,5.436353f,-95.88578f,-37.208767f,-4.2267957f,-22.343536f,10.73843f ) ;
  }

  @Test
  public void test281() {
    color.laplace.solve(-73.659096f,84.10604f,0f,-20.560902f,-2.9518397f,55.559986f,-5.632671f,-1.9697808f,4.734705f ) ;
  }

  @Test
  public void test282() {
    color.laplace.solve(73.80122f,-79.182594f,-21.4198f,29.648447f,-22.207016f,-16.01303f,66.99958f,-23.280893f,-20.425295f ) ;
  }

  @Test
  public void test283() {
    color.laplace.solve(-74.13043f,70.3514f,0f,-46.677593f,-96.34229f,15.075572f,-16.237642f,-18.272976f,39.488033f ) ;
  }

  @Test
  public void test284() {
    color.laplace.solve(7.4273286f,-60.055695f,-4.7198563f,-10.23499f,-5.352274f,37.223434f,-43.015015f,36.54807f,0f ) ;
  }

  @Test
  public void test285() {
    color.laplace.solve(-75.38068f,65.76378f,0f,-22.911684f,25.257221f,-49.38272f,-41.523285f,-6.455855f,0f ) ;
  }

  @Test
  public void test286() {
    color.laplace.solve(-7.5915112f,-30.366045f,-29.369934f,-100.0f,-16.99048f,36.70895f,-24.71617f,1.1353257f,46.24795f ) ;
  }

  @Test
  public void test287() {
    color.laplace.solve(75.938354f,50.03924f,0f,30.817186f,-26.040525f,0f,4.240681f,-13.854461f,0f ) ;
  }

  @Test
  public void test288() {
    color.laplace.solve(76.46054f,74.325584f,0f,37.99029f,60.703102f,0f,14.998307f,22.002934f,12.03619f ) ;
  }

  @Test
  public void test289() {
    color.laplace.solve(7.8966236f,31.512665f,-35.095707f,-99.92617f,53.249737f,-91.2037f,-24.591022f,1.5620776f,-22.410404f ) ;
  }

  @Test
  public void test290() {
    color.laplace.solve(8.097731f,29.631737f,25.982483f,-97.240814f,-15.553265f,-25.701805f,43.495754f,0f,0f ) ;
  }

  @Test
  public void test291() {
    color.laplace.solve(-81.90863f,-89.09573f,0f,-23.688711f,-7.5971103f,-48.684414f,-5.249107f,2.6922843f,23.615355f ) ;
  }

  @Test
  public void test292() {
    color.laplace.solve(8.254973f,-81.05195f,-39.035366f,-1.5981498f,-13.760445f,29.558678f,-0.8871276f,-1.9503605f,6.8461304f ) ;
  }

  @Test
  public void test293() {
    color.laplace.solve(-83.33361f,50.575794f,-16.892548f,-28.507984f,-18.274612f,-73.97939f,-12.423713f,-21.186869f,-54.04915f ) ;
  }

  @Test
  public void test294() {
    color.laplace.solve(83.73291f,-73.65379f,0f,-12.127002f,-49.50902f,0f,-67.97993f,0f,0f ) ;
  }

  @Test
  public void test295() {
    color.laplace.solve(84.12683f,-51.409683f,0f,-10.544249f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test296() {
    color.laplace.solve(-84.13525f,-80.40156f,0f,82.02754f,56.198994f,0f,25.455313f,-71.91989f,0f ) ;
  }

  @Test
  public void test297() {
    color.laplace.solve(-8.430126f,-88.64373f,0f,1.3138614f,90.388084f,0f,5.5112815f,20.731264f,-55.62754f ) ;
  }

  @Test
  public void test298() {
    color.laplace.solve(84.306496f,8.80988f,0f,-43.723255f,72.24023f,0f,-20.591318f,-38.642017f,0f ) ;
  }

  @Test
  public void test299() {
    color.laplace.solve(-85.85144f,100.0f,0f,-53.015846f,-100.0f,0f,-26.211946f,0f,0f ) ;
  }

  @Test
  public void test300() {
    color.laplace.solve(-86.71779f,51.92186f,0f,-9.308078f,-85.45751f,0f,-75.45941f,94.17257f,0f ) ;
  }

  @Test
  public void test301() {
    color.laplace.solve(87.12179f,-58.109344f,0f,-17.682089f,9.898845f,0f,-90.48438f,-87.92237f,0f ) ;
  }

  @Test
  public void test302() {
    color.laplace.solve(8.762999f,-54.55163f,61.79229f,-10.39638f,-32.137928f,-1.1577077f,-18.210592f,-62.44599f,-31.232668f ) ;
  }

  @Test
  public void test303() {
    color.laplace.solve(-89.2493f,73.13574f,0f,7.335027f,80.544716f,1.6838052f,38.044693f,68.01035f,0f ) ;
  }

  @Test
  public void test304() {
    color.laplace.solve(8.964948f,-62.24518f,9.139364f,-1.8950312f,-10.404523f,-14.894639f,-6.140549f,37.416756f,78.43965f ) ;
  }

  @Test
  public void test305() {
    color.laplace.solve(-90.5864f,43.854958f,0f,-74.471725f,70.9753f,0f,-45.730053f,50.159f,0f ) ;
  }

  @Test
  public void test306() {
    color.laplace.solve(9.172812f,-53.93563f,46.460613f,-9.373117f,35.571342f,0f,-5.279967f,-11.74675f,0f ) ;
  }

  @Test
  public void test307() {
    color.laplace.solve(-9.286324f,89.75748f,0f,29.716213f,-28.063534f,0f,-10.55039f,-71.91778f,-94.196335f ) ;
  }

  @Test
  public void test308() {
    color.laplace.solve(-9.388886f,-170.21841f,0f,-17.13364f,-49.563473f,178.5797f,-9.5822f,-21.195162f,-20.061356f ) ;
  }

  @Test
  public void test309() {
    color.laplace.solve(9.559294f,-90.364456f,-47.09497f,-3.353916f,-25.850233f,-39.85591f,2.8752744f,30.173351f,-86.47844f ) ;
  }

  @Test
  public void test310() {
    color.laplace.solve(9.577908f,-52.61649f,-99.99999f,-9.071881f,-35.149273f,-45.11594f,-10.716166f,-33.792778f,-89.30568f ) ;
  }

  @Test
  public void test311() {
    color.laplace.solve(9.663766f,-100.0f,22.01369f,38.655064f,-90.85487f,0f,-14.487226f,-100.0f,0f ) ;
  }

  @Test
  public void test312() {
    color.laplace.solve(9.810505f,-44.74173f,-21.05747f,-3.908387f,-19.601286f,-10.292352f,-5.8427663f,-19.462677f,28.45753f ) ;
  }

  @Test
  public void test313() {
    color.laplace.solve(99.437126f,-19.102417f,0f,28.802446f,23.347008f,5.125648f,-7.574346f,-59.09983f,28.158194f ) ;
  }

  @Test
  public void test314() {
    color.laplace.solve(99.94368f,-100.0f,0f,37.369976f,34.05643f,-5.198235f,15.479789f,24.54918f,48.660496f ) ;
  }
}
