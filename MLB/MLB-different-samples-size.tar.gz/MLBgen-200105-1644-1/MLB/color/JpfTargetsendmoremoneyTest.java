import org.junit.Test;

public class JpfTargetsendmoremoneyTest {

  @Test
  public void test0() {
    color.sendmoremoney.solve(1,0,7,348,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    color.sendmoremoney.solve(12,7,0,9,7,5,1,-631 ) ;
  }

  @Test
  public void test2() {
    color.sendmoremoney.solve(1,323,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    color.sendmoremoney.solve(1,4,3,7,-1,5,9,2466 ) ;
  }

  @Test
  public void test4() {
    color.sendmoremoney.solve(1,6,9,8,3,4,9,90 ) ;
  }

  @Test
  public void test5() {
    color.sendmoremoney.solve(1,9,4,0,0,0,0,0 ) ;
  }

  @Test
  public void test6() {
    color.sendmoremoney.solve(1,9,4,3,7,-179,0,0 ) ;
  }

  @Test
  public void test7() {
    color.sendmoremoney.solve(1,9,5,2,7,6,0,-367 ) ;
  }

  @Test
  public void test8() {
    color.sendmoremoney.solve(2,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test9() {
    color.sendmoremoney.solve(2,1,6,0,7,346,0,0 ) ;
  }

  @Test
  public void test10() {
    color.sendmoremoney.solve(2,2,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test11() {
    color.sendmoremoney.solve(2,8,0,274,0,0,0,0 ) ;
  }

  @Test
  public void test12() {
    color.sendmoremoney.solve(3,0,3,1,9,8,5,0 ) ;
  }

  @Test
  public void test13() {
    color.sendmoremoney.solve(308,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test14() {
    color.sendmoremoney.solve(312,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test15() {
    color.sendmoremoney.solve(3,1,681,0,0,0,0,0 ) ;
  }

  @Test
  public void test16() {
    color.sendmoremoney.solve(3,9,5,7,7,1359,0,0 ) ;
  }

  @Test
  public void test17() {
    color.sendmoremoney.solve(3,-985,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test18() {
    color.sendmoremoney.solve(4,0,0,4,1,0,0,0 ) ;
  }

  @Test
  public void test19() {
    color.sendmoremoney.solve(4,-1,0,3,3,1,8,1242 ) ;
  }

  @Test
  public void test20() {
    color.sendmoremoney.solve(4,9,1,8,1,3,6,-1416 ) ;
  }

  @Test
  public void test21() {
    color.sendmoremoney.solve(5,1,9,2,2,5,-1124,0 ) ;
  }

  @Test
  public void test22() {
    color.sendmoremoney.solve(5,3,7,1,-1069,0,0,0 ) ;
  }

  @Test
  public void test23() {
    color.sendmoremoney.solve(5,5,4,4,4,7,0,0 ) ;
  }

  @Test
  public void test24() {
    color.sendmoremoney.solve(5,735,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test25() {
    color.sendmoremoney.solve(5,7,4,3,1003,0,0,0 ) ;
  }

  @Test
  public void test26() {
    color.sendmoremoney.solve(-592,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test27() {
    color.sendmoremoney.solve(6,7,1,7,0,0,0,0 ) ;
  }

  @Test
  public void test28() {
    color.sendmoremoney.solve(6,8,4,-375,0,0,0,0 ) ;
  }

  @Test
  public void test29() {
    color.sendmoremoney.solve(7,1,-56,0,0,0,0,0 ) ;
  }

  @Test
  public void test30() {
    color.sendmoremoney.solve(7,4,6,4,9,8,773,0 ) ;
  }

  @Test
  public void test31() {
    color.sendmoremoney.solve(8,0,0,1,898,0,0,0 ) ;
  }

  @Test
  public void test32() {
    color.sendmoremoney.solve(8,0,4,1,7,0,1495,0 ) ;
  }

  @Test
  public void test33() {
    color.sendmoremoney.solve(9,3,855,0,0,0,0,0 ) ;
  }
}
