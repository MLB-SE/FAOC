import org.junit.Test;

public class JpfTargetloanTest {

  @Test
  public void test0() {
    color.loan.solve(-25.646263f ) ;
  }

  @Test
  public void test1() {
    color.loan.solve(65.65497f ) ;
  }

  @Test
  public void test2() {
    color.loan.solve(80.83998f ) ;
  }
}
