import org.junit.Test;

public class ConflictTest {

  @Test
  public void test0() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,0.0 ) ;
  }

  @Test
  public void test2() {
    tsafe.Conflict.snippet(0.0,0.0,0,0,0,0,-87.46315357052234 ) ;
  }

  @Test
  public void test3() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,100.0 ) ;
  }

  @Test
  public void test4() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,1.166E-321 ) ;
  }

  @Test
  public void test5() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,25.36318503556687 ) ;
  }

  @Test
  public void test6() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,91.7660841624862 ) ;
  }

  @Test
  public void test7() {
    tsafe.Conflict.snippet(0.0,-14.837139965449225,-35.92893627820462,-89.67375692033846,-20.764723662379776,-24.129987100892073,12.118622227616221 ) ;
  }

  @Test
  public void test8() {
    tsafe.Conflict.snippet(0.0,3.4849273473693354,2.8015384689689973E-28,0,0,0,-90.0 ) ;
  }

  @Test
  public void test9() {
    tsafe.Conflict.snippet(0.0,-35.77084104242098,-60.49868668541508,-1.914603120513518,-0.5781824028106518,-17.972988685992693,-100.0 ) ;
  }

  @Test
  public void test10() {
    tsafe.Conflict.snippet(0.0,45.741907845151275,56.978652788516484,1026.6497459304696,-239.13076367214785,85.89958199088385,-85.42717286579536 ) ;
  }

  @Test
  public void test11() {
    tsafe.Conflict.snippet(0.0,-55.360215807826975,-104.50112169521283,-77.98769339711579,995.9511275336763,73.19947613110688,-122.61217850423286 ) ;
  }

  @Test
  public void test12() {
    tsafe.Conflict.snippet(0.0,-6.2130420859555215,98.85958963916929,0,0,0,33.50523108242044 ) ;
  }

  @Test
  public void test13() {
    tsafe.Conflict.snippet(0.0,75.41408478125418,45.84837668908669,-1.7063771807693158,-1.0056669490758217,100.0,57.1334366801212 ) ;
  }

  @Test
  public void test14() {
    tsafe.Conflict.snippet(0.0,-76.56193047596213,0,0,0,0,-72.8304492536767 ) ;
  }

  @Test
  public void test15() {
    tsafe.Conflict.snippet(0.0,87.89626562344313,46.070715163469316,-81.93900628763615,100.0,-78.93243689087375,100.0 ) ;
  }

  @Test
  public void test16() {
    tsafe.Conflict.snippet(0.5388905079007031,0,0,0,0,0,63.48748451036454 ) ;
  }

  @Test
  public void test17() {
    tsafe.Conflict.snippet(100.0,100.0,-46.41909200797238,85.11419928649036,-93.78102356095185,15.173106248584018,2.962872406725055E-4 ) ;
  }

  @Test
  public void test18() {
    tsafe.Conflict.snippet(100.0,76.62189628244155,-6.347468682101509E-28,0,0,0,90.0 ) ;
  }

  @Test
  public void test19() {
    tsafe.Conflict.snippet(-12.579465292766761,87.72745615175788,20.704660304673126,343.02605572518974,-981.9880542047288,28.89446465850486,82.09453632963866 ) ;
  }

  @Test
  public void test20() {
    tsafe.Conflict.snippet(128.59559360921068,-357.3203432221217,26.90863278277304,-962.3940579443685,262.77829656435046,143.72425729185642,61.59440701584367 ) ;
  }

  @Test
  public void test21() {
    tsafe.Conflict.snippet(12.963938704013144,64.91132289094452,-130.6579172138924,1.7316365916993597,-1.121674311202319,-85.79820749435342,9.940319840816567 ) ;
  }

  @Test
  public void test22() {
    tsafe.Conflict.snippet(1.53E-322,0,0,0,0,0,-67.08316214242339 ) ;
  }

  @Test
  public void test23() {
    tsafe.Conflict.snippet(1.7E-322,0,0,0,0,0,-90.5990661554602 ) ;
  }

  @Test
  public void test24() {
    tsafe.Conflict.snippet(-180.2772062906036,-104.579535608345,10.86036388527914,969.3646270047515,238.73027311450744,-5.329447441747817,24.944547414570394 ) ;
  }

  @Test
  public void test25() {
    tsafe.Conflict.snippet(-19.01665324842152,-67.09900725854305,-37.29064501698284,-0.7996380253331179,1.5135370780478468,51.741927519628774,15.82210680508993 ) ;
  }

  @Test
  public void test26() {
    tsafe.Conflict.snippet(-2.08E-322,0,0,0,0,0,-33.05357524262233 ) ;
  }

  @Test
  public void test27() {
    tsafe.Conflict.snippet(-2.0E-322,0,0,0,0,0,-96.82661444200363 ) ;
  }

  @Test
  public void test28() {
    tsafe.Conflict.snippet(-21.26399973710633,0,0,0,0,0,-31.34640425268458 ) ;
  }

  @Test
  public void test29() {
    tsafe.Conflict.snippet(-24.385550701802543,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test30() {
    tsafe.Conflict.snippet(-25.6230352384337,0,0,0,0,0,-54.90281609042631 ) ;
  }

  @Test
  public void test31() {
    tsafe.Conflict.snippet(-28.69037240669236,8.933354674764061,0,0,0,0,-78.7909728679163 ) ;
  }

  @Test
  public void test32() {
    tsafe.Conflict.snippet(32.58854656162889,0,0,0,0,0,-1.22E-320 ) ;
  }

  @Test
  public void test33() {
    tsafe.Conflict.snippet(34.799012107014676,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test34() {
    tsafe.Conflict.snippet(44.08437010224765,-52.90051031946674,-80.47466610332472,-15.04438790209872,-5.21495014785576,53.194510912340434,82.22475530085578 ) ;
  }

  @Test
  public void test35() {
    tsafe.Conflict.snippet(-4.440892098500626E-16,0,0,0,0,0,-47.01855249170544 ) ;
  }

  @Test
  public void test36() {
    tsafe.Conflict.snippet(45.11043027913238,-25.05085767774546,59.085362385076,1.5443334454842157,0.38918628059773397,-59.03958387369555,1.090181704250881 ) ;
  }

  @Test
  public void test37() {
    tsafe.Conflict.snippet(48.60501975322657,0,0,0,0,0,-52.9151213149748 ) ;
  }

  @Test
  public void test38() {
    tsafe.Conflict.snippet(-5.36573476504677,-75.55360118740198,13.274763046699727,-0.8798895709864223,1.785997359813533,-15.225383385647387,-34.062591787534785 ) ;
  }

  @Test
  public void test39() {
    tsafe.Conflict.snippet(-54.36434250119,-34.60006922870109,-56.6198789802993,67.10301495041713,-84.7394805514116,-96.03736073225629,-84.1453882082634 ) ;
  }

  @Test
  public void test40() {
    tsafe.Conflict.snippet(56.309915357927,0,0,0,0,0,-41.048496533032086 ) ;
  }

  @Test
  public void test41() {
    tsafe.Conflict.snippet(56.66273463264672,0.0,0,0,0,0,1.1113875557112252 ) ;
  }

  @Test
  public void test42() {
    tsafe.Conflict.snippet(-61.1838670336805,0,0,0,0,0,-2.8E-322 ) ;
  }

  @Test
  public void test43() {
    tsafe.Conflict.snippet(63.89936349253867,64.4592039811443,0,0,0,0,-7.123159416688523 ) ;
  }

  @Test
  public void test44() {
    tsafe.Conflict.snippet(-72.47174835212115,-79.64829599991398,-81.57176363900925,-2.334130828012235,1.5432079246599244,16.498040725285264,13.574258719931649 ) ;
  }

  @Test
  public void test45() {
    tsafe.Conflict.snippet(-84.84174383222376,0.0,0,0,0,0,65.80380298683403 ) ;
  }

  @Test
  public void test46() {
    tsafe.Conflict.snippet(8.83213844235099,0,0,0,0,0,0.0 ) ;
  }

  @Test
  public void test47() {
    tsafe.Conflict.snippet(8.881784197001252E-16,0,0,0,0,0,-27.439352787694787 ) ;
  }

  @Test
  public void test48() {
    tsafe.Conflict.snippet(-91.88403209600781,0,0,0,0,0,-74.52337685973134 ) ;
  }

  @Test
  public void test49() {
    tsafe.Conflict.snippet(-93.15615980009503,15.22458601016848,-1.653161803831374E-26,0,0,0,-90.0 ) ;
  }

  @Test
  public void test50() {
    tsafe.Conflict.snippet(94.56511018887076,-12.925533071451639,-38.91880448640737,78.22645307313877,23.760194055692963,-5.5538541500223175,-87.0703220058825 ) ;
  }

  @Test
  public void test51() {
    tsafe.Conflict.snippet(-98.16500241825064,-30.878468206121298,59.73069297431027,0,0,0,-36.99003784795627 ) ;
  }

  @Test
  public void test52() {
    tsafe.Conflict.snippet(98.87647152197937,45.21278500318752,61.53653277348374,0,0,0,79.03540010915066 ) ;
  }

  @Test
  public void test53() {
    tsafe.Conflict.snippet(-99.999998839049,0,0,0,0,0,0.0 ) ;
  }
}
