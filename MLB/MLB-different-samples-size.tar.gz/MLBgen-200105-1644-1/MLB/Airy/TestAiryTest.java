import org.junit.Test;

public class TestAiryTest {

  @Test
  public void test0() {
    airy.main_airy(-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1() {
    airy.main_airy(1.232595164407831E-32 ) ;
  }

  @Test
  public void test2() {
    airy.main_airy(1.2634920662350609E-175 ) ;
  }

  @Test
  public void test3() {
    airy.main_airy(-1.5573736782940697E-207 ) ;
  }

  @Test
  public void test4() {
    airy.main_airy(1.557374211108995E-207 ) ;
  }

  @Test
  public void test5() {
    airy.main_airy(-1.7290327071306454E-223 ) ;
  }

  @Test
  public void test6() {
    airy.main_airy(1.7763568394002505E-15 ) ;
  }

  @Test
  public void test7() {
    airy.main_airy(-2.080083823051904 ) ;
  }

  @Test
  public void test8() {
    airy.main_airy(-2.0800838230519045 ) ;
  }

  @Test
  public void test9() {
    airy.main_airy(-2.1488662440474826 ) ;
  }

  @Test
  public void test10() {
    airy.main_airy(22.51425750449532 ) ;
  }

  @Test
  public void test11() {
    airy.main_airy(-2.259987633919328 ) ;
  }

  @Test
  public void test12() {
    airy.main_airy(-2.3928040910824695 ) ;
  }

  @Test
  public void test13() {
    airy.main_airy(-2.465190328815662E-32 ) ;
  }

  @Test
  public void test14() {
    airy.main_airy(-2.5626663618343692E-144 ) ;
  }

  @Test
  public void test15() {
    airy.main_airy(25.866421394946997 ) ;
  }

  @Test
  public void test16() {
    airy.main_airy(-3.273679913771872 ) ;
  }

  @Test
  public void test17() {
    airy.main_airy(33.50604683295691 ) ;
  }

  @Test
  public void test18() {
    airy.main_airy(-3.552713678800501E-15 ) ;
  }

  @Test
  public void test19() {
    airy.main_airy(3735.735178960625 ) ;
  }

  @Test
  public void test20() {
    airy.main_airy(3737.901768948549 ) ;
  }

  @Test
  public void test21() {
    airy.main_airy(-40.01138662403119 ) ;
  }

  @Test
  public void test22() {
    airy.main_airy(4.3225817678266135E-224 ) ;
  }

  @Test
  public void test23() {
    airy.main_airy(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test24() {
    airy.main_airy(-4.793828356390591 ) ;
  }

  @Test
  public void test25() {
    airy.main_airy(-4.9659625265829845 ) ;
  }

  @Test
  public void test26() {
    airy.main_airy(6.229495527855635E-207 ) ;
  }

  @Test
  public void test27() {
    airy.main_airy(-74.69026994397913 ) ;
  }

  @Test
  public void test28() {
    airy.main_airy(74.91959786068031 ) ;
  }

  @Test
  public void test29() {
    airy.main_airy(85.9111429315845 ) ;
  }

  @Test
  public void test30() {
    airy.main_airy(-87.0002851744436 ) ;
  }

  @Test
  public void test31() {
    airy.main_airy(-87.46128622867913 ) ;
  }

  @Test
  public void test32() {
    airy.main_airy(-93.9547513706577 ) ;
  }
}
