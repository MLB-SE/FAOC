import org.junit.Test;

public class TestsphbesTest {

  @Test
  public void test0() {
    airy.sphbes(0,0.8977811610587025 ) ;
  }

  @Test
  public void test1() {
    airy.sphbes(0,2.0 ) ;
  }

  @Test
  public void test2() {
    airy.sphbes(0,-3322.7313829904065 ) ;
  }

  @Test
  public void test3() {
    airy.sphbes(0,-3381.54109507751 ) ;
  }

  @Test
  public void test4() {
    airy.sphbes(0,-3389.7822210175254 ) ;
  }

  @Test
  public void test5() {
    airy.sphbes(0,-3398.701017259201 ) ;
  }

  @Test
  public void test6() {
    airy.sphbes(0,-3431.1824600135533 ) ;
  }

  @Test
  public void test7() {
    airy.sphbes(0,-3493.317709959243 ) ;
  }

  @Test
  public void test8() {
    airy.sphbes(0,40.84435110707045 ) ;
  }

  @Test
  public void test9() {
    airy.sphbes(0,-51.96812400427731 ) ;
  }

  @Test
  public void test10() {
    airy.sphbes(0,53.50686325774092 ) ;
  }

  @Test
  public void test11() {
    airy.sphbes(117,1.9999999999999956 ) ;
  }

  @Test
  public void test12() {
    airy.sphbes(119,-82.70747905034446 ) ;
  }

  @Test
  public void test13() {
    airy.sphbes(-1,1.9999999999999996 ) ;
  }

  @Test
  public void test14() {
    airy.sphbes(-1,2.081472793284135 ) ;
  }

  @Test
  public void test15() {
    airy.sphbes(1,24.981324968541855 ) ;
  }

  @Test
  public void test16() {
    airy.sphbes(-1,2.828417344715031 ) ;
  }

  @Test
  public void test17() {
    airy.sphbes(-1,-3539.196029720162 ) ;
  }

  @Test
  public void test18() {
    airy.sphbes(-14,0 ) ;
  }

  @Test
  public void test19() {
    airy.sphbes(1471,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test20() {
    airy.sphbes(156,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test21() {
    airy.sphbes(-1,-67.011471363785 ) ;
  }

  @Test
  public void test22() {
    airy.sphbes(-1,85.28628777991486 ) ;
  }

  @Test
  public void test23() {
    airy.sphbes(189,-2.0E-323 ) ;
  }

  @Test
  public void test24() {
    airy.sphbes(-193,1.379545173819931E-16 ) ;
  }

  @Test
  public void test25() {
    airy.sphbes(-193,21.300331307835336 ) ;
  }

  @Test
  public void test26() {
    airy.sphbes(-216,-57.344759392332215 ) ;
  }

  @Test
  public void test27() {
    airy.sphbes(218,0.0 ) ;
  }

  @Test
  public void test28() {
    airy.sphbes(23,-29.21599176774454 ) ;
  }

  @Test
  public void test29() {
    airy.sphbes(-2,-3489.185113271729 ) ;
  }

  @Test
  public void test30() {
    airy.sphbes(264,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test31() {
    airy.sphbes(-267,-25.116815699813344 ) ;
  }

  @Test
  public void test32() {
    airy.sphbes(268,66.74964585858882 ) ;
  }

  @Test
  public void test33() {
    airy.sphbes(-270,-1.6940658945086007E-21 ) ;
  }

  @Test
  public void test34() {
    airy.sphbes(271,-7.47756861767499 ) ;
  }

  @Test
  public void test35() {
    airy.sphbes(-274,-64.26943655982015 ) ;
  }

  @Test
  public void test36() {
    airy.sphbes(-28,2.0 ) ;
  }

  @Test
  public void test37() {
    airy.sphbes(-28,76.64223829125771 ) ;
  }

  @Test
  public void test38() {
    airy.sphbes(-300,-1.4952511871429266 ) ;
  }

  @Test
  public void test39() {
    airy.sphbes(307,4.546226871004876 ) ;
  }

  @Test
  public void test40() {
    airy.sphbes(310,-1.5E-323 ) ;
  }

  @Test
  public void test41() {
    airy.sphbes(339,1.5E-323 ) ;
  }

  @Test
  public void test42() {
    airy.sphbes(340,-7.537382092472072 ) ;
  }

  @Test
  public void test43() {
    airy.sphbes(342,0.0 ) ;
  }

  @Test
  public void test44() {
    airy.sphbes(-368,-95.59845049533978 ) ;
  }

  @Test
  public void test45() {
    airy.sphbes(372,-3.684408580530544 ) ;
  }

  @Test
  public void test46() {
    airy.sphbes(377,-38.70669109480325 ) ;
  }

  @Test
  public void test47() {
    airy.sphbes(391,-47.663992691436974 ) ;
  }

  @Test
  public void test48() {
    airy.sphbes(447,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test49() {
    airy.sphbes(-466,40.89398840858402 ) ;
  }

  @Test
  public void test50() {
    airy.sphbes(472,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test51() {
    airy.sphbes(499,43.61574414982877 ) ;
  }

  @Test
  public void test52() {
    airy.sphbes(564,8.4E-323 ) ;
  }

  @Test
  public void test53() {
    airy.sphbes(564,97.79489008340704 ) ;
  }

  @Test
  public void test54() {
    airy.sphbes(568,-56.66102077360782 ) ;
  }

  @Test
  public void test55() {
    airy.sphbes(-573,5.4E-323 ) ;
  }

  @Test
  public void test56() {
    airy.sphbes(579,0.0 ) ;
  }

  @Test
  public void test57() {
    airy.sphbes(596,-7.4E-323 ) ;
  }

  @Test
  public void test58() {
    airy.sphbes(-603,-2.0E-323 ) ;
  }

  @Test
  public void test59() {
    airy.sphbes(608,45.386497870655035 ) ;
  }

  @Test
  public void test60() {
    airy.sphbes(-622,92.50582509862699 ) ;
  }

  @Test
  public void test61() {
    airy.sphbes(-62,-54.34369565936541 ) ;
  }

  @Test
  public void test62() {
    airy.sphbes(62,63.27859600282292 ) ;
  }

  @Test
  public void test63() {
    airy.sphbes(657,57.394126769999275 ) ;
  }

  @Test
  public void test64() {
    airy.sphbes(670,2.4E-322 ) ;
  }

  @Test
  public void test65() {
    airy.sphbes(-672,2.0000000000000004 ) ;
  }

  @Test
  public void test66() {
    airy.sphbes(687,0.0 ) ;
  }

  @Test
  public void test67() {
    airy.sphbes(-718,0.0 ) ;
  }

  @Test
  public void test68() {
    airy.sphbes(718,-88.57398357613435 ) ;
  }

  @Test
  public void test69() {
    airy.sphbes(-802,0.0 ) ;
  }

  @Test
  public void test70() {
    airy.sphbes(-81,0.0 ) ;
  }

  @Test
  public void test71() {
    airy.sphbes(826,-35.7799391402299 ) ;
  }

  @Test
  public void test72() {
    airy.sphbes(892,2.0 ) ;
  }

  @Test
  public void test73() {
    airy.sphbes(-897,2.0 ) ;
  }

  @Test
  public void test74() {
    airy.sphbes(933,2.0 ) ;
  }

  @Test
  public void test75() {
    airy.sphbes(-934,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test76() {
    airy.sphbes(955,-18.54361983103385 ) ;
  }

  @Test
  public void test77() {
    airy.sphbes(-959,1.8108299538867243 ) ;
  }

  @Test
  public void test78() {
    airy.sphbes(977,2.0000000000000004 ) ;
  }

  @Test
  public void test79() {
    airy.sphbes(991,0 ) ;
  }
}
