import org.junit.Test;

public class TestpythagTest {

  @Test
  public void test0() {
    dawson.pythag(0.005920495147289036,0.006707673923187612 ) ;
  }

  @Test
  public void test1() {
    dawson.pythag(0.008911473518810564,0.008909213618908495 ) ;
  }

  @Test
  public void test2() {
    dawson.pythag(-0.06828848488769981,-0.0682885408265336 ) ;
  }

  @Test
  public void test3() {
    dawson.pythag(-0.8137644050877384,7.278803947923336 ) ;
  }

  @Test
  public void test4() {
    dawson.pythag(100.0,-100.0 ) ;
  }

  @Test
  public void test5() {
    dawson.pythag(-10.155217977440458,0 ) ;
  }

  @Test
  public void test6() {
    dawson.pythag(-1.1102230246251565E-16,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test7() {
    dawson.pythag(1.203025530992211E-16,1.203077332898916E-16 ) ;
  }

  @Test
  public void test8() {
    dawson.pythag(13.011898684528578,0.0 ) ;
  }

  @Test
  public void test9() {
    dawson.pythag(1.3343870160631013E-110,-1.3306124500025471E-110 ) ;
  }

  @Test
  public void test10() {
    dawson.pythag(-1.4788152327084684E-272,-1.6418147205193505E-288 ) ;
  }

  @Test
  public void test11() {
    dawson.pythag(-1.4981364335015035E-95,1.5075647117458465E-95 ) ;
  }

  @Test
  public void test12() {
    dawson.pythag(1.4E-322,0.0 ) ;
  }

  @Test
  public void test13() {
    dawson.pythag(15.02380959458182,-49.88397925531416 ) ;
  }

  @Test
  public void test14() {
    dawson.pythag(-1.6419741169364659E-31,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test15() {
    dawson.pythag(17.64221199996348,0 ) ;
  }

  @Test
  public void test16() {
    dawson.pythag(-2.0812474159298974E-258,-2.0812474159298974E-258 ) ;
  }

  @Test
  public void test17() {
    dawson.pythag(2.0812474159298974E-258,2.0812474159298974E-258 ) ;
  }

  @Test
  public void test18() {
    dawson.pythag(24.687030240758574,-28.239829087803045 ) ;
  }

  @Test
  public void test19() {
    dawson.pythag(25.426011831611262,63.05501794481262 ) ;
  }

  @Test
  public void test20() {
    dawson.pythag(25.94929306848141,0.0 ) ;
  }

  @Test
  public void test21() {
    dawson.pythag(2.5988524414112248E-113,2.534503086084008E-98 ) ;
  }

  @Test
  public void test22() {
    dawson.pythag(-2.753308285752965E-82,2.752764823488632E-82 ) ;
  }

  @Test
  public void test23() {
    dawson.pythag(2.76795987383818,0 ) ;
  }

  @Test
  public void test24() {
    dawson.pythag(2.7755575615628914E-17,4.565926491519047E-19 ) ;
  }

  @Test
  public void test25() {
    dawson.pythag(-28.306957299951534,23.378213314274788 ) ;
  }

  @Test
  public void test26() {
    dawson.pythag(2.96E-322,1.83E-322 ) ;
  }

  @Test
  public void test27() {
    dawson.pythag(-3.0385816786431356E-64,3.100009056490118E-64 ) ;
  }

  @Test
  public void test28() {
    dawson.pythag(31.162049619831436,-31.162049619831436 ) ;
  }

  @Test
  public void test29() {
    dawson.pythag(3.206051606228578E-33,-3.206324796597291E-33 ) ;
  }

  @Test
  public void test30() {
    dawson.pythag(-32.15495638293818,32.15495638293818 ) ;
  }

  @Test
  public void test31() {
    dawson.pythag(-32.181064039372885,-32.181064039372885 ) ;
  }

  @Test
  public void test32() {
    dawson.pythag(-3.3087224502121107E-24,6.6174449004242214E-24 ) ;
  }

  @Test
  public void test33() {
    dawson.pythag(-34.84528162976494,64.63552429318526 ) ;
  }

  @Test
  public void test34() {
    dawson.pythag(-3.697038081771171E-273,4.1045368012983762E-289 ) ;
  }

  @Test
  public void test35() {
    dawson.pythag(37.12348871225058,82.51642549228151 ) ;
  }

  @Test
  public void test36() {
    dawson.pythag(38.18734531990245,38.18734531990245 ) ;
  }

  @Test
  public void test37() {
    dawson.pythag(-38.228661246575804,-72.5551757005727 ) ;
  }

  @Test
  public void test38() {
    dawson.pythag(-39.9765913697228,-39.9765913697228 ) ;
  }

  @Test
  public void test39() {
    dawson.pythag(-43.0540399263256,-43.0540399263256 ) ;
  }

  @Test
  public void test40() {
    dawson.pythag(4.3368086899420177E-19,-5.421010862427522E-19 ) ;
  }

  @Test
  public void test41() {
    dawson.pythag(4.6212976022139637E-274,-5.1306710016229703E-290 ) ;
  }

  @Test
  public void test42() {
    dawson.pythag(-4.9E-324,0.0 ) ;
  }

  @Test
  public void test43() {
    dawson.pythag(-5.345529420184391E-51,-3.159724091282757E-36 ) ;
  }

  @Test
  public void test44() {
    dawson.pythag(5.421010862427522E-20,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test45() {
    dawson.pythag(55.53353057267018,0.0 ) ;
  }

  @Test
  public void test46() {
    dawson.pythag(-56.71590539320328,-57.74797230542994 ) ;
  }

  @Test
  public void test47() {
    dawson.pythag(-5.7766220027674546E-275,5.7766220027674546E-275 ) ;
  }

  @Test
  public void test48() {
    dawson.pythag(-64.99918915953509,-55.24945860277586 ) ;
  }

  @Test
  public void test49() {
    dawson.pythag(-65.90487321109265,77.6597675546389 ) ;
  }

  @Test
  public void test50() {
    dawson.pythag(-66.72823829184136,66.72823829184136 ) ;
  }

  @Test
  public void test51() {
    dawson.pythag(66.91949779395802,-39.11785290971312 ) ;
  }

  @Test
  public void test52() {
    dawson.pythag(-67.15485143297104,53.314178081112175 ) ;
  }

  @Test
  public void test53() {
    dawson.pythag(67.70750635533847,52.47158287971675 ) ;
  }

  @Test
  public void test54() {
    dawson.pythag(6.776263578034403E-21,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test55() {
    dawson.pythag(-68.29425160377282,0.0 ) ;
  }

  @Test
  public void test56() {
    dawson.pythag(-68.75456254538683,26.25643736892151 ) ;
  }

  @Test
  public void test57() {
    dawson.pythag(68.94403264091372,38.29368474946054 ) ;
  }

  @Test
  public void test58() {
    dawson.pythag(-70.88861923188483,0.0 ) ;
  }

  @Test
  public void test59() {
    dawson.pythag(73.10324491002643,73.10324491002643 ) ;
  }

  @Test
  public void test60() {
    dawson.pythag(7.394076163542342E-273,8.2090736025967525E-289 ) ;
  }

  @Test
  public void test61() {
    dawson.pythag(73.94755980732324,-30.873057593968127 ) ;
  }

  @Test
  public void test62() {
    dawson.pythag(-73.97697046761982,0.0 ) ;
  }

  @Test
  public void test63() {
    dawson.pythag(-76.17610986547834,-97.3444868286627 ) ;
  }

  @Test
  public void test64() {
    dawson.pythag(8.139331608333222,-21.356385012079897 ) ;
  }

  @Test
  public void test65() {
    dawson.pythag(85.65581221207165,85.65581221207165 ) ;
  }

  @Test
  public void test66() {
    dawson.pythag(8.758115402030107E-47,-1.0947644252537633E-46 ) ;
  }

  @Test
  public void test67() {
    dawson.pythag(-88.53819624580782,-12.323174494305803 ) ;
  }

  @Test
  public void test68() {
    dawson.pythag(-8.883434782635782E-65,-8.88341511320951E-65 ) ;
  }

  @Test
  public void test69() {
    dawson.pythag(-8.9E-323,0.0 ) ;
  }

  @Test
  public void test70() {
    dawson.pythag(90.60531660213383,-68.21395455530413 ) ;
  }

  @Test
  public void test71() {
    dawson.pythag(-91.43652872469539,91.43652872469539 ) ;
  }

  @Test
  public void test72() {
    dawson.pythag(9.373105086847693E-243,-1.0406237079649487E-258 ) ;
  }

  @Test
  public void test73() {
    dawson.pythag(97.11307522983711,-97.11307522983711 ) ;
  }

  @Test
  public void test74() {
    dawson.pythag(-9.822958716577924E-34,9.82314501013631E-34 ) ;
  }

  @Test
  public void test75() {
    dawson.pythag(98.43101624033147,65.21611315124571 ) ;
  }

  @Test
  public void test76() {
    dawson.pythag(9.843527470490372,73.09113667811445 ) ;
  }

  @Test
  public void test77() {
    dawson.pythag(-9.860761315262648E-32,6.776263578034403E-21 ) ;
  }

  @Test
  public void test78() {
    dawson.pythag(-99.18785173462499,-89.86454978430156 ) ;
  }
}
