import org.junit.Test;

public class TestbessjTest {

  @Test
  public void test0() {
    bess.bessj(0,3.5E-323 ) ;
  }

  @Test
  public void test1() {
    bess.bessj(102,0.0 ) ;
  }

  @Test
  public void test2() {
    bess.bessj(1,0.6139723509917574 ) ;
  }

  @Test
  public void test3() {
    bess.bessj(1,-1.0 ) ;
  }

  @Test
  public void test4() {
    bess.bessj(1131,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test5() {
    bess.bessj(-125,0.0 ) ;
  }

  @Test
  public void test6() {
    bess.bessj(1363,3.556413999176124E-161 ) ;
  }

  @Test
  public void test7() {
    bess.bessj(14,14.00000000000001 ) ;
  }

  @Test
  public void test8() {
    bess.bessj(1,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test9() {
    bess.bessj(191,0.0 ) ;
  }

  @Test
  public void test10() {
    bess.bessj(-258,0.0 ) ;
  }

  @Test
  public void test11() {
    bess.bessj(-347,3.556413999176124E-161 ) ;
  }

  @Test
  public void test12() {
    bess.bessj(377,-1.778206999588062E-161 ) ;
  }

  @Test
  public void test13() {
    bess.bessj(384,-86.1470537803142 ) ;
  }

  @Test
  public void test14() {
    bess.bessj(395,53.14094321497399 ) ;
  }

  @Test
  public void test15() {
    bess.bessj(429,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test16() {
    bess.bessj(-448,-93.00786634260201 ) ;
  }

  @Test
  public void test17() {
    bess.bessj(-47,0 ) ;
  }

  @Test
  public void test18() {
    bess.bessj(-485,17.713502016266673 ) ;
  }

  @Test
  public void test19() {
    bess.bessj(-517,-57.1696154279177 ) ;
  }

  @Test
  public void test20() {
    bess.bessj(537,-88.86601159264617 ) ;
  }

  @Test
  public void test21() {
    bess.bessj(565,73.43318048671927 ) ;
  }

  @Test
  public void test22() {
    bess.bessj(-576,0.0 ) ;
  }

  @Test
  public void test23() {
    bess.bessj(-616,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test24() {
    bess.bessj(699,26.260700648826656 ) ;
  }

  @Test
  public void test25() {
    bess.bessj(-704,-79.10825430189206 ) ;
  }

  @Test
  public void test26() {
    bess.bessj(705,-6.480399724081163E-162 ) ;
  }

  @Test
  public void test27() {
    bess.bessj(-752,-1.2634920662350609E-175 ) ;
  }

  @Test
  public void test28() {
    bess.bessj(-780,-6.2565096724471904E-148 ) ;
  }

  @Test
  public void test29() {
    bess.bessj(-822,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test30() {
    bess.bessj(861,0 ) ;
  }

  @Test
  public void test31() {
    bess.bessj(861,-40.526123959999836 ) ;
  }

  @Test
  public void test32() {
    bess.bessj(8,8.0 ) ;
  }

  @Test
  public void test33() {
    bess.bessj(-890,34.70730578365553 ) ;
  }

  @Test
  public void test34() {
    bess.bessj(-90,68.33454240721849 ) ;
  }

  @Test
  public void test35() {
    bess.bessj(9,-11.71703643542719 ) ;
  }

  @Test
  public void test36() {
    bess.bessj(919,0.0 ) ;
  }

  @Test
  public void test37() {
    bess.bessj(99,-99.0 ) ;
  }
}
