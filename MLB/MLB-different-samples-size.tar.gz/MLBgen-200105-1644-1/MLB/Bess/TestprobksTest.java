import org.junit.Test;

public class TestprobksTest {

  @Test
  public void test0() {
    dawson.probks(-0.2666605724557911 ) ;
  }

  @Test
  public void test1() {
    dawson.probks(-0.5864506180057987 ) ;
  }

  @Test
  public void test2() {
    dawson.probks(-0.6039737089543888 ) ;
  }

  @Test
  public void test3() {
    dawson.probks(-0.6162580215865319 ) ;
  }

  @Test
  public void test4() {
    dawson.probks(0.7606251302371305 ) ;
  }

  @Test
  public void test5() {
    dawson.probks(0.97748733554333 ) ;
  }

  @Test
  public void test6() {
    dawson.probks(10.420285292182001 ) ;
  }

  @Test
  public void test7() {
    dawson.probks(11.346440928712468 ) ;
  }

  @Test
  public void test8() {
    dawson.probks(1.21959151945919 ) ;
  }

  @Test
  public void test9() {
    dawson.probks(-1.3482485160451319 ) ;
  }

  @Test
  public void test10() {
    dawson.probks(14.218327971162665 ) ;
  }

  @Test
  public void test11() {
    dawson.probks(1.4453496954147416 ) ;
  }

  @Test
  public void test12() {
    dawson.probks(14.875018776300905 ) ;
  }

  @Test
  public void test13() {
    dawson.probks(14.98335618853119 ) ;
  }

  @Test
  public void test14() {
    dawson.probks(-1.5174271293771966 ) ;
  }

  @Test
  public void test15() {
    dawson.probks(-1.5174271293851358 ) ;
  }

  @Test
  public void test16() {
    dawson.probks(-1.517427129385146 ) ;
  }

  @Test
  public void test17() {
    dawson.probks(-1.5174271293851462 ) ;
  }

  @Test
  public void test18() {
    dawson.probks(1.5174271293851462 ) ;
  }

  @Test
  public void test19() {
    dawson.probks(-16.341397926705213 ) ;
  }

  @Test
  public void test20() {
    dawson.probks(-19.013040208835633 ) ;
  }

  @Test
  public void test21() {
    dawson.probks(19.193896200267062 ) ;
  }

  @Test
  public void test22() {
    dawson.probks(-19.209174499967354 ) ;
  }

  @Test
  public void test23() {
    dawson.probks(-19.289822733941577 ) ;
  }

  @Test
  public void test24() {
    dawson.probks(19.290629746058624 ) ;
  }

  @Test
  public void test25() {
    dawson.probks(19.291945047394446 ) ;
  }

  @Test
  public void test26() {
    dawson.probks(19.29730417069212 ) ;
  }

  @Test
  public void test27() {
    dawson.probks(-19.29905673657267 ) ;
  }

  @Test
  public void test28() {
    dawson.probks(-32.630588138899924 ) ;
  }

  @Test
  public void test29() {
    dawson.probks(-3.2758171680269186 ) ;
  }

  @Test
  public void test30() {
    dawson.probks(-54.92371837415764 ) ;
  }

  @Test
  public void test31() {
    dawson.probks(-5.881735815236681 ) ;
  }

  @Test
  public void test32() {
    dawson.probks(-6.019456485880852 ) ;
  }

  @Test
  public void test33() {
    dawson.probks(69.48622998623327 ) ;
  }

  @Test
  public void test34() {
    dawson.probks(-71.20423400738767 ) ;
  }

  @Test
  public void test35() {
    dawson.probks(-7.34075472611562 ) ;
  }

  @Test
  public void test36() {
    dawson.probks(7.753286786803898 ) ;
  }

  @Test
  public void test37() {
    dawson.probks(9.6279135071414 ) ;
  }

  @Test
  public void test38() {
    dawson.probks(9.650992300677823 ) ;
  }

  @Test
  public void test39() {
    dawson.probks(9.752048046954044 ) ;
  }
}
