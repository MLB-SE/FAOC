import org.junit.Test;

public class TestbessyTest {

  @Test
  public void test0() {
    bess.bessy(-192,0.0 ) ;
  }

  @Test
  public void test1() {
    bess.bessy(284,0.0 ) ;
  }

  @Test
  public void test2() {
    bess.bessy(321,-25.977029721608403 ) ;
  }

  @Test
  public void test3() {
    bess.bessy(-371,8.0 ) ;
  }

  @Test
  public void test4() {
    bess.bessy(412,0 ) ;
  }

  @Test
  public void test5() {
    bess.bessy(46,8.0 ) ;
  }

  @Test
  public void test6() {
    bess.bessy(596,74.60321561393448 ) ;
  }

  @Test
  public void test7() {
    bess.bessy(-640,95.07563923757303 ) ;
  }

  @Test
  public void test8() {
    bess.bessy(650,68.22767076985201 ) ;
  }

  @Test
  public void test9() {
    bess.bessy(-69,-44.07828143806729 ) ;
  }

  @Test
  public void test10() {
    bess.bessy(-710,0 ) ;
  }

  @Test
  public void test11() {
    bess.bessy(-828,59.88567094702469 ) ;
  }
}
