import org.junit.Test;

public class TestdawsonTest {

  @Test
  public void test0() {
    dawson.dawson(0.08900652508640583 ) ;
  }

  @Test
  public void test1() {
    dawson.dawson(0.132496877377406 ) ;
  }

  @Test
  public void test2() {
    dawson.dawson(-0.19999999999999984 ) ;
  }

  @Test
  public void test3() {
    dawson.dawson(-0.19999999999999996 ) ;
  }

  @Test
  public void test4() {
    dawson.dawson(-0.20000000000000007 ) ;
  }

  @Test
  public void test5() {
    dawson.dawson(-0.20000000000000018 ) ;
  }

  @Test
  public void test6() {
    dawson.dawson(-0.3966675634443533 ) ;
  }

  @Test
  public void test7() {
    dawson.dawson(-0.39999999999999997 ) ;
  }

  @Test
  public void test8() {
    dawson.dawson(0.39999999999999997 ) ;
  }

  @Test
  public void test9() {
    dawson.dawson(0.436518386018633 ) ;
  }

  @Test
  public void test10() {
    dawson.dawson(-0.4828445558168539 ) ;
  }

  @Test
  public void test11() {
    dawson.dawson(-0.5976098177274585 ) ;
  }

  @Test
  public void test12() {
    dawson.dawson(0.6165357295512206 ) ;
  }

  @Test
  public void test13() {
    dawson.dawson(0.6210564218628241 ) ;
  }

  @Test
  public void test14() {
    dawson.dawson(-0.6345452035502845 ) ;
  }

  @Test
  public void test15() {
    dawson.dawson(0.6547294426984802 ) ;
  }

  @Test
  public void test16() {
    dawson.dawson(-0.6784117665497416 ) ;
  }

  @Test
  public void test17() {
    dawson.dawson(0.6859673348371302 ) ;
  }

  @Test
  public void test18() {
    dawson.dawson(-0.688190544198737 ) ;
  }

  @Test
  public void test19() {
    dawson.dawson(0.7680635927575565 ) ;
  }

  @Test
  public void test20() {
    dawson.dawson(0.7999999999999996 ) ;
  }

  @Test
  public void test21() {
    dawson.dawson(-0.7999999999999999 ) ;
  }

  @Test
  public void test22() {
    dawson.dawson(0.7999999999999999 ) ;
  }

  @Test
  public void test23() {
    dawson.dawson(-0.8808808745429931 ) ;
  }

  @Test
  public void test24() {
    dawson.dawson(11.227495395584867 ) ;
  }

  @Test
  public void test25() {
    dawson.dawson(1.1846079789735597 ) ;
  }

  @Test
  public void test26() {
    dawson.dawson(14.525572995347062 ) ;
  }

  @Test
  public void test27() {
    dawson.dawson(1.5146894278757657 ) ;
  }

  @Test
  public void test28() {
    dawson.dawson(-1.5999999999999996 ) ;
  }

  @Test
  public void test29() {
    dawson.dawson(-1.614856253700911 ) ;
  }

  @Test
  public void test30() {
    dawson.dawson(1.814716888897447 ) ;
  }

  @Test
  public void test31() {
    dawson.dawson(-1.8219445911980898 ) ;
  }

  @Test
  public void test32() {
    dawson.dawson(18.56769565755782 ) ;
  }

  @Test
  public void test33() {
    dawson.dawson(19.680051271213685 ) ;
  }

  @Test
  public void test34() {
    dawson.dawson(-2.239991170141465 ) ;
  }

  @Test
  public void test35() {
    dawson.dawson(2.5976198057630002 ) ;
  }

  @Test
  public void test36() {
    dawson.dawson(-2.6652857085705364 ) ;
  }

  @Test
  public void test37() {
    dawson.dawson(26.812566286729208 ) ;
  }

  @Test
  public void test38() {
    dawson.dawson(-2.7756526165556856 ) ;
  }

  @Test
  public void test39() {
    dawson.dawson(-27.987042224756138 ) ;
  }

  @Test
  public void test40() {
    dawson.dawson(2.8688749716712323 ) ;
  }

  @Test
  public void test41() {
    dawson.dawson(-3.2314607561311526 ) ;
  }

  @Test
  public void test42() {
    dawson.dawson(-32.72756754996648 ) ;
  }

  @Test
  public void test43() {
    dawson.dawson(3.3060106506554847 ) ;
  }

  @Test
  public void test44() {
    dawson.dawson(-35.79534112287688 ) ;
  }

  @Test
  public void test45() {
    dawson.dawson(-4.050065923501194 ) ;
  }

  @Test
  public void test46() {
    dawson.dawson(4.0627881140542526 ) ;
  }

  @Test
  public void test47() {
    dawson.dawson(-41.33425824199142 ) ;
  }

  @Test
  public void test48() {
    dawson.dawson(42.2460401248255 ) ;
  }

  @Test
  public void test49() {
    dawson.dawson(-42.445798035766515 ) ;
  }

  @Test
  public void test50() {
    dawson.dawson(46.30268093959427 ) ;
  }

  @Test
  public void test51() {
    dawson.dawson(4.930380657631324E-32 ) ;
  }

  @Test
  public void test52() {
    dawson.dawson(-5.345417591471719E-17 ) ;
  }

  @Test
  public void test53() {
    dawson.dawson(-54.97528496018216 ) ;
  }

  @Test
  public void test54() {
    dawson.dawson(58.37670631002561 ) ;
  }

  @Test
  public void test55() {
    dawson.dawson(60.98796937826532 ) ;
  }

  @Test
  public void test56() {
    dawson.dawson(64.1011729933544 ) ;
  }

  @Test
  public void test57() {
    dawson.dawson(-71.55320126161122 ) ;
  }

  @Test
  public void test58() {
    dawson.dawson(73.45628041199939 ) ;
  }

  @Test
  public void test59() {
    dawson.dawson(76.89547541905753 ) ;
  }

  @Test
  public void test60() {
    dawson.dawson(78.76502864639718 ) ;
  }

  @Test
  public void test61() {
    dawson.dawson(78.96031986005897 ) ;
  }

  @Test
  public void test62() {
    dawson.dawson(-7.937135122876128 ) ;
  }

  @Test
  public void test63() {
    dawson.dawson(7.95953265781128 ) ;
  }

  @Test
  public void test64() {
    dawson.dawson(-80.19751715056105 ) ;
  }

  @Test
  public void test65() {
    dawson.dawson(-80.47475005893162 ) ;
  }

  @Test
  public void test66() {
    dawson.dawson(82.67700432672876 ) ;
  }

  @Test
  public void test67() {
    dawson.dawson(-8.547386075279434 ) ;
  }

  @Test
  public void test68() {
    dawson.dawson(-87.4239541329315 ) ;
  }

  @Test
  public void test69() {
    dawson.dawson(-88.93945313165719 ) ;
  }

  @Test
  public void test70() {
    dawson.dawson(-90.45672264844234 ) ;
  }

  @Test
  public void test71() {
    dawson.dawson(91.24945592851722 ) ;
  }

  @Test
  public void test72() {
    dawson.dawson(-95.07457620890052 ) ;
  }

  @Test
  public void test73() {
    dawson.dawson(-98.23871435320069 ) ;
  }
}
