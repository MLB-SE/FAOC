import org.junit.Test;

public class TestbessiTest {

  @Test
  public void test0() {
    bess.bessi(0,-22.567892531275156 ) ;
  }

  @Test
  public void test1() {
    bess.bessi(0,39.00499303317133 ) ;
  }

  @Test
  public void test2() {
    bess.bessi(-105,20.633176626595514 ) ;
  }

  @Test
  public void test3() {
    bess.bessi(-112,-0.26591363205375274 ) ;
  }

  @Test
  public void test4() {
    bess.bessi(-1150,-7.4E-323 ) ;
  }

  @Test
  public void test5() {
    bess.bessi(-117,-1.24E-322 ) ;
  }

  @Test
  public void test6() {
    bess.bessi(139,23.857672389351507 ) ;
  }

  @Test
  public void test7() {
    bess.bessi(1,63.717229749277635 ) ;
  }

  @Test
  public void test8() {
    bess.bessi(1,-64.03040888129885 ) ;
  }

  @Test
  public void test9() {
    bess.bessi(-345,0 ) ;
  }

  @Test
  public void test10() {
    bess.bessi(380,0 ) ;
  }

  @Test
  public void test11() {
    bess.bessi(395,0.0 ) ;
  }

  @Test
  public void test12() {
    bess.bessi(-472,70.31513439167455 ) ;
  }

  @Test
  public void test13() {
    bess.bessi(-513,-56.077112280023364 ) ;
  }

  @Test
  public void test14() {
    bess.bessi(-538,-35.680407570873 ) ;
  }

  @Test
  public void test15() {
    bess.bessi(-563,7.9E-323 ) ;
  }

  @Test
  public void test16() {
    bess.bessi(568,-25.986215186392855 ) ;
  }

  @Test
  public void test17() {
    bess.bessi(-639,-70.38410368833546 ) ;
  }

  @Test
  public void test18() {
    bess.bessi(-649,0.0 ) ;
  }

  @Test
  public void test19() {
    bess.bessi(748,6.008948800923682E-54 ) ;
  }

  @Test
  public void test20() {
    bess.bessi(75,-37.626135826633785 ) ;
  }

  @Test
  public void test21() {
    bess.bessi(760,-1.53E-322 ) ;
  }

  @Test
  public void test22() {
    bess.bessi(-778,70.31445913931725 ) ;
  }

  @Test
  public void test23() {
    bess.bessi(788,-1.5E-322 ) ;
  }

  @Test
  public void test24() {
    bess.bessi(82,53.12634271021014 ) ;
  }

  @Test
  public void test25() {
    bess.bessi(840,86.88612144803975 ) ;
  }

  @Test
  public void test26() {
    bess.bessi(879,4.9E-324 ) ;
  }

  @Test
  public void test27() {
    bess.bessi(-882,0.0 ) ;
  }

  @Test
  public void test28() {
    bess.bessi(-891,-5.502070417119746E-55 ) ;
  }

  @Test
  public void test29() {
    bess.bessi(904,-1.816374334873127E-9 ) ;
  }

  @Test
  public void test30() {
    bess.bessi(-926,7.94639200043993E-9 ) ;
  }

  @Test
  public void test31() {
    bess.bessi(949,0.0 ) ;
  }

  @Test
  public void test32() {
    bess.bessi(974,90.57265744717799 ) ;
  }

  @Test
  public void test33() {
    bess.bessi(995,-71.94198640333973 ) ;
  }
}
