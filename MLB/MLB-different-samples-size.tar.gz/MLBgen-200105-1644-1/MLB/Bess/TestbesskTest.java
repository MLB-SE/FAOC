import org.junit.Test;

public class TestbesskTest {

  @Test
  public void test0() {
    bess.bessk(-105,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1() {
    bess.bessk(-11,2.0 ) ;
  }

  @Test
  public void test2() {
    bess.bessk(123,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test3() {
    bess.bessk(1523,1.9999999999999998 ) ;
  }

  @Test
  public void test4() {
    bess.bessk(-1635,3.7500000000000004 ) ;
  }

  @Test
  public void test5() {
    bess.bessk(1657,2.0000000000000004 ) ;
  }

  @Test
  public void test6() {
    bess.bessk(-1666,1.9999999999999998 ) ;
  }

  @Test
  public void test7() {
    bess.bessk(175,1.9999999999999964 ) ;
  }

  @Test
  public void test8() {
    bess.bessk(179,1.501762202648325E-15 ) ;
  }

  @Test
  public void test9() {
    bess.bessk(184,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test10() {
    bess.bessk(-2255,2.0000000000000004 ) ;
  }

  @Test
  public void test11() {
    bess.bessk(226,2.0 ) ;
  }

  @Test
  public void test12() {
    bess.bessk(235,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test13() {
    bess.bessk(-243,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test14() {
    bess.bessk(-2451,3.7500000000000004 ) ;
  }

  @Test
  public void test15() {
    bess.bessk(257,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test16() {
    bess.bessk(-267,-11.965006155869972 ) ;
  }

  @Test
  public void test17() {
    bess.bessk(315,1.5E-323 ) ;
  }

  @Test
  public void test18() {
    bess.bessk(321,2.0 ) ;
  }

  @Test
  public void test19() {
    bess.bessk(3379,3.7500000000000013 ) ;
  }

  @Test
  public void test20() {
    bess.bessk(-353,2.0000000000000004 ) ;
  }

  @Test
  public void test21() {
    bess.bessk(370,-80.04718937405748 ) ;
  }

  @Test
  public void test22() {
    bess.bessk(375,2.000000000000004 ) ;
  }

  @Test
  public void test23() {
    bess.bessk(-389,2.0 ) ;
  }

  @Test
  public void test24() {
    bess.bessk(396,2.0 ) ;
  }

  @Test
  public void test25() {
    bess.bessk(40,82.99561056124378 ) ;
  }

  @Test
  public void test26() {
    bess.bessk(-412,-16.32780352890822 ) ;
  }

  @Test
  public void test27() {
    bess.bessk(-454,-23.833641019309255 ) ;
  }

  @Test
  public void test28() {
    bess.bessk(-484,2.0 ) ;
  }

  @Test
  public void test29() {
    bess.bessk(-546,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test30() {
    bess.bessk(-550,0 ) ;
  }

  @Test
  public void test31() {
    bess.bessk(-593,2.0 ) ;
  }

  @Test
  public void test32() {
    bess.bessk(-616,2.0 ) ;
  }

  @Test
  public void test33() {
    bess.bessk(-625,2.465190328815662E-32 ) ;
  }

  @Test
  public void test34() {
    bess.bessk(640,3.7500000000000004 ) ;
  }

  @Test
  public void test35() {
    bess.bessk(678,1.9999999999999996 ) ;
  }

  @Test
  public void test36() {
    bess.bessk(-705,2.0 ) ;
  }

  @Test
  public void test37() {
    bess.bessk(708,2.0 ) ;
  }

  @Test
  public void test38() {
    bess.bessk(-721,0.0 ) ;
  }

  @Test
  public void test39() {
    bess.bessk(731,2.0 ) ;
  }

  @Test
  public void test40() {
    bess.bessk(-812,2.0 ) ;
  }

  @Test
  public void test41() {
    bess.bessk(-854,2.0 ) ;
  }

  @Test
  public void test42() {
    bess.bessk(-862,1.906882448480887E-15 ) ;
  }

  @Test
  public void test43() {
    bess.bessk(9,0 ) ;
  }

  @Test
  public void test44() {
    bess.bessk(-907,7.9E-323 ) ;
  }

  @Test
  public void test45() {
    bess.bessk(936,2.0 ) ;
  }

  @Test
  public void test46() {
    bess.bessk(-936,66.47686960173371 ) ;
  }

  @Test
  public void test47() {
    bess.bessk(965,0.0 ) ;
  }

  @Test
  public void test48() {
    bess.bessk(966,-40.93870266451163 ) ;
  }

  @Test
  public void test49() {
    bess.bessk(967,2.0 ) ;
  }

  @Test
  public void test50() {
    bess.bessk(982,-92.09370148677736 ) ;
  }

  @Test
  public void test51() {
    bess.bessk(-983,1.597689398652471E-16 ) ;
  }

  @Test
  public void test52() {
    bess.bessk(986,2.0 ) ;
  }

  @Test
  public void test53() {
    bess.bessk(-994,8.881784197001252E-16 ) ;
  }
}
