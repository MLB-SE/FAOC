import org.junit.Test;

public class JpfTargetMysinTest {

  @Test
  public void test0() {
    JpfTargetMysin.static_mysin(-0.19999513880336828 ) ;
  }

  @Test
  public void test1() {
    JpfTargetMysin.static_mysin(-0.20596997617166224 ) ;
  }

  @Test
  public void test2() {
    JpfTargetMysin.static_mysin(0.976823386928718 ) ;
  }

  @Test
  public void test3() {
    JpfTargetMysin.static_mysin(0.9845142227233756 ) ;
  }

  @Test
  public void test4() {
    JpfTargetMysin.static_mysin(-1.0879275754865757E-17 ) ;
  }

  @Test
  public void test5() {
    JpfTargetMysin.static_mysin(140.44840348384125 ) ;
  }

  @Test
  public void test6() {
    JpfTargetMysin.static_mysin(-19.634954084936208 ) ;
  }

  @Test
  public void test7() {
    JpfTargetMysin.static_mysin(-2.1374629493499972E-4 ) ;
  }

  @Test
  public void test8() {
    JpfTargetMysin.static_mysin(-21.60163540572742 ) ;
  }

  @Test
  public void test9() {
    JpfTargetMysin.static_mysin(-2.4414062499998612E-4 ) ;
  }

  @Test
  public void test10() {
    JpfTargetMysin.static_mysin(2.4414062499999306E-4 ) ;
  }

  @Test
  public void test11() {
    JpfTargetMysin.static_mysin(2.44140625000024E-4 ) ;
  }

  @Test
  public void test12() {
    JpfTargetMysin.static_mysin(-2.4414062500009855E-4 ) ;
  }

  @Test
  public void test13() {
    JpfTargetMysin.static_mysin(-260.3641321060466 ) ;
  }

  @Test
  public void test14() {
    JpfTargetMysin.static_mysin(-261.6560584453042 ) ;
  }

  @Test
  public void test15() {
    JpfTargetMysin.static_mysin(29.157060259532074 ) ;
  }

  @Test
  public void test16() {
    JpfTargetMysin.static_mysin(30.630528372500482 ) ;
  }

  @Test
  public void test17() {
    JpfTargetMysin.static_mysin(38.48451000647496 ) ;
  }

  @Test
  public void test18() {
    JpfTargetMysin.static_mysin(45.089690952782234 ) ;
  }

  @Test
  public void test19() {
    JpfTargetMysin.static_mysin(-5.497787143782138 ) ;
  }

  @Test
  public void test20() {
    JpfTargetMysin.static_mysin(-57.21786342975559 ) ;
  }

  @Test
  public void test21() {
    JpfTargetMysin.static_mysin(57.89852626668588 ) ;
  }

  @Test
  public void test22() {
    JpfTargetMysin.static_mysin(63.83297027167461 ) ;
  }

  @Test
  public void test23() {
    JpfTargetMysin.static_mysin(74.70500601994382 ) ;
  }

  @Test
  public void test24() {
    JpfTargetMysin.static_mysin(-74.75194064156338 ) ;
  }

  @Test
  public void test25() {
    JpfTargetMysin.static_mysin(-86.1323961465417 ) ;
  }

  @Test
  public void test26() {
    JpfTargetMysin.static_mysin(-86.38181824973367 ) ;
  }

  @Test
  public void test27() {
    JpfTargetMysin.static_mysin(-86.96025231857416 ) ;
  }

  @Test
  public void test28() {
    JpfTargetMysin.static_mysin(9.058049500368625E-57 ) ;
  }

  @Test
  public void test29() {
    JpfTargetMysin.static_mysin(99.70881616205855 ) ;
  }
}
