import org.junit.Test;

public class JpfTargetWoodTest {

  @Test
  public void test0() {
    Optimization.wood(0.4102684621431818,0.1683202110293314,0,0 ) ;
  }

  @Test
  public void test1() {
    Optimization.wood(1.0,0.9999999999999998,1.0,1.0 ) ;
  }

  @Test
  public void test2() {
    Optimization.wood(1.0,0.9999999999999999,1.0,1.0 ) ;
  }

  @Test
  public void test3() {
    Optimization.wood(1.0,1.0,0,0 ) ;
  }

  @Test
  public void test4() {
    Optimization.wood(1.0,1.0000000000000004,1.0,1.0 ) ;
  }

  @Test
  public void test5() {
    Optimization.wood(1.0,1.0,1.0,0.9999999999999999 ) ;
  }

  @Test
  public void test6() {
    Optimization.wood(1.0,1.0,1.0,1.0 ) ;
  }

  @Test
  public void test7() {
    Optimization.wood(1.0,1.0,-5.974142465225441,35.69037819480991 ) ;
  }

  @Test
  public void test8() {
    Optimization.wood(1.0,1.0,63.28015086890785,23.025237919737187 ) ;
  }

  @Test
  public void test9() {
    Optimization.wood(1.0,1.0,6.743482366785873,45.474554431152 ) ;
  }

  @Test
  public void test10() {
    Optimization.wood(1.0,1.0,-8.011368608998493,64.18202698924645 ) ;
  }

  @Test
  public void test11() {
    Optimization.wood(1.0,1.0,-8.061036304939273,100.0 ) ;
  }

  @Test
  public void test12() {
    Optimization.wood(3.593606526277081,12.914007865701228,0,0 ) ;
  }

  @Test
  public void test13() {
    Optimization.wood(5.3385957428185415,28.500604505240254,0,0 ) ;
  }

  @Test
  public void test14() {
    Optimization.wood(-8.107060147763818,78.68273777091744,0,0 ) ;
  }

  @Test
  public void test15() {
    Optimization.wood(-83.07918714045526,46.1034435747093,0,0 ) ;
  }
}
