import org.junit.Test;

public class JpfTargetBealeTest {

  @Test
  public void test0() {
    Optimization.beale(0.8902996501000187,-0.684826001932592 ) ;
  }

  @Test
  public void test1() {
    Optimization.beale(-19.071943846697877,43.73045767317154 ) ;
  }

  @Test
  public void test2() {
    Optimization.beale(-41.9241345147251,-22.151418997181892 ) ;
  }
}
