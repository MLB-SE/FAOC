import org.junit.Test;

public class JpfTargetRosenbrockTest {

  @Test
  public void test0() {
    Optimization.rosenbrock(-31.08452717447952,-70.0343123823409 ) ;
  }

  @Test
  public void test1() {
    Optimization.rosenbrock(5.577999248541535,31.1143573886231 ) ;
  }

  @Test
  public void test2() {
    Optimization.rosenbrock(9.997603625229477,99.94799404564375 ) ;
  }
}
