import org.junit.Test;

public class JpfTargetHelicalValleyTest {

  @Test
  public void test0() {
    Optimization.theta(-0.01732498493462175,1625.6809524548285 ) ;
  }

  @Test
  public void test1() {
    Optimization.theta(-0.6338417717780742,100.0 ) ;
  }

  @Test
  public void test2() {
    Optimization.theta(-0.8888891994515831,0 ) ;
  }

  @Test
  public void test3() {
    Optimization.theta(100.0,0.0 ) ;
  }

  @Test
  public void test4() {
    Optimization.theta(-14.402911091487525,0 ) ;
  }

  @Test
  public void test5() {
    Optimization.theta(2.0575626797553923,0 ) ;
  }

  @Test
  public void test6() {
    Optimization.theta(21.11152492281176,-60.80931660107389 ) ;
  }

  @Test
  public void test7() {
    Optimization.theta(-2.2016496428673094,0 ) ;
  }

  @Test
  public void test8() {
    Optimization.theta(2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test9() {
    Optimization.theta(26.400719944995394,-9.159122623371061 ) ;
  }

  @Test
  public void test10() {
    Optimization.theta(28.641055225822015,70.76611779673897 ) ;
  }

  @Test
  public void test11() {
    Optimization.theta(31.700094581051218,-50.97251409969525 ) ;
  }

  @Test
  public void test12() {
    Optimization.theta(-36.239306965255345,-96.82584742050267 ) ;
  }

  @Test
  public void test13() {
    Optimization.theta(-41.24822713440944,-61.19470548591864 ) ;
  }

  @Test
  public void test14() {
    Optimization.theta(-44.2972531483357,97.12294328555288 ) ;
  }

  @Test
  public void test15() {
    Optimization.theta(-45.37820578666201,82.48161670543644 ) ;
  }

  @Test
  public void test16() {
    Optimization.theta(58.519601023439165,54.0341611556857 ) ;
  }

  @Test
  public void test17() {
    Optimization.theta(62.336691916863025,99.99982078348201 ) ;
  }

  @Test
  public void test18() {
    Optimization.theta(-67.18709479766486,-22.662544610964176 ) ;
  }

  @Test
  public void test19() {
    Optimization.theta(-6.938893903907228E-18,100.0 ) ;
  }

  @Test
  public void test20() {
    Optimization.theta(-74.51656153933368,0 ) ;
  }

  @Test
  public void test21() {
    Optimization.theta(7.872202053410831,25.263368327506 ) ;
  }

  @Test
  public void test22() {
    Optimization.theta(79.55464047231231,0 ) ;
  }

  @Test
  public void test23() {
    Optimization.theta(-89.50178733684947,0 ) ;
  }

  @Test
  public void test24() {
    Optimization.theta(-93.66520272619428,44.836103845316444 ) ;
  }

  @Test
  public void test25() {
    Optimization.theta(-9.4804349292545,0 ) ;
  }

  @Test
  public void test26() {
    Optimization.theta(-98.21318919211217,0 ) ;
  }

  @Test
  public void test27() {
    Optimization.theta(99.99769940156013,-7.659936287368554E-8 ) ;
  }
}
