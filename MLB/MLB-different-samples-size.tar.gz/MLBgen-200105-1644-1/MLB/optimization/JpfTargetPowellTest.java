import org.junit.Test;

public class JpfTargetPowellTest {

  @Test
  public void test0() {
    Optimization.powell(1.0060240805742637E-5,9.940119916703932 ) ;
  }

  @Test
  public void test1() {
    Optimization.powell(-13.957185754223062,-7.164768153188957E-6 ) ;
  }

  @Test
  public void test2() {
    Optimization.powell(3.4474352741398206E-6,29.007071068201935 ) ;
  }

  @Test
  public void test3() {
    Optimization.powell(-3.6899298123775884E-6,-27.100786487742294 ) ;
  }

  @Test
  public void test4() {
    Optimization.powell(-74.9940879897676,-58.40989988942873 ) ;
  }

  @Test
  public void test5() {
    Optimization.powell(79.50638341464838,-58.92884841223975 ) ;
  }
}
