import org.junit.Test;

public class JpfTargetFreudensteinRothTest {

  @Test
  public void test0() {
    Optimization.freudensteinRoth(-3.2554202281677043,-1.807194942902001 ) ;
  }

  @Test
  public void test1() {
    Optimization.freudensteinRoth(-50.986933615300444,-3.686679294558189 ) ;
  }

  @Test
  public void test2() {
    Optimization.freudensteinRoth(62.39824158770347,44.386839777895574 ) ;
  }
}
