import org.junit.Test;

public class Sample91Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark91(-54.47428192757526,-67.78777004201586 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark91(-63.861770397940056,-97.66563862117208 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark91(6.902061043932803,22.61002431188177 ) ;
  }
}
