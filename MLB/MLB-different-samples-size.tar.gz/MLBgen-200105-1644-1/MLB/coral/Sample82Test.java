import org.junit.Test;

public class Sample82Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark82(-0.06510086314305852,-0.0015360779438553828 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark82(14.378867338204458,6.954650713989227E-6 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark82(1.7032005381508886,5.87129922519675E-5 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark82(-27.219640190671868,-84.51065437358578 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark82(-7.411847602245558E-5,-1.3491912592712123 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark82(-98.99511886276899,1.8596773390858914 ) ;
  }
}
