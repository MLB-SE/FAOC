import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,-2.0016528125215984,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0,-93.21123241159184,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(1.7595973460781131,10.99919692432706,16.639457879841586,54.23456124249964,47.127688853189056 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(3.557287650322664,16.755489727414144,-48.50725251088714,-93.47609149170897,31.18244606792851 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(-92.39301271866054,13.13513226082577,-91.10259466399633,-76.51857951288954,50.45255922936849 ) ;
  }
}
