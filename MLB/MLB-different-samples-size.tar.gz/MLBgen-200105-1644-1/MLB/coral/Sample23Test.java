import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(12.045573134011576,-6.764651641796722,-50.5165299082155,91.3140527639078 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(13.000079327831898,2.7208113851747555,55.83492109542374,26.077872927289718 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(13.967520810458154,-46.25366857573484,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(175.93954452730452,14.718813522858916,0,-3.4324159485662293 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(22.880272418953652,-11.445518810636756,0,19.457790225183686 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(4.1656886920107326,90.96697359913904,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(-45.265049931123635,51.019990073094846,-81.77232883433302,34.23544762896759 ) ;
  }
}
