import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(-0.12680221601029018,0.047583265510752426,-39.40055872926938,2.6016735499110966 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(-0.2335385088779276,0.1934660613693353,16.386371566705378,-82.20659165356368 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(-0.8798826337899044,0.589452830808483,96.81874337918183,19.02481325116348 ) ;
  }
}
