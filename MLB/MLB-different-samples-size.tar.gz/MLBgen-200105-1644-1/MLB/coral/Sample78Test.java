import org.junit.Test;

public class Sample78Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,0.0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0.0,3.8504425022718785,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-0.32640893200243376,3.06E-322,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-36.09982515959918,0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,3.754652905345665,0,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,90.0,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,14.796187456061787,72.67199129005539,0,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,19.904753373470715,-90.0,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,50.49182441602886,-37.02898260563272,0,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-95.9701421994281,-85.48700786404018,0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark78(-100.0,100.0,100.0,-100.0,-100.0,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark78(100.0,100.0,100.0,100.0,100.0,0,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark78(102.0,821.0,821.0,102.0,111.0,0,0,642 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark78(128.0,-29.0,-569.0,-128.0,-1205.0,-825,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark78(-19.45082682196262,0,0,97.8553961625054,66.26801317308306,0,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark78(27.6629063699815,0,0,76.05731140100156,42.21764717470151,0,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark78(-27.919911308938694,0,0,-9.395281024068638,94.12058873510227,0,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark78(-38.92041049177953,0,0,-41.664910664345385,-1.73E-322,0,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark78(44.16341244391036,0,0,1.0655986769561075E-255,-3.4444365599978997,0,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark78(-4.601126455233521E-44,0,0,-55.52637573535321,-90.0,0,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark78(54.0,-798.0,-3138.0,-54.0,1047.0,0,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark78(-57.420339385649925,-22.307523493912782,37.78944864939746,46.2499899043911,70.40184280309967,0,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark78(57.58871118713412,0,0,-68.80016968258626,-90.0,0,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark78(-5.984054802335967E-44,0,0,14.40160740424945,90.0,0,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark78(-65.08471151299051,0,0,-65.11571681498233,-14.683575589691685,0,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark78(67.92389174866096,0,0,15.551180378467322,-3.16E-322,0,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark78(-82.4842288785172,0,0,-6.448537470736994,-24.111109275648374,0,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark78(-85.0,198.0,918.0,-85.0,-160.0,0,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark78(-87.36831037982584,0,0,100.0,-90.0,0,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark78(-92.2076315642266,0,0,22.162516879268424,-99.98493758682203,0,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark78(-97.36285585520388,0,0,35.19194394737033,4.537261128871023,0,0,0 ) ;
  }
}
