import org.junit.Test;

public class Sample28Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark28(14.08620797118732 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark28(2.2148947763136704 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark28(7.389056098930651 ) ;
  }
}
