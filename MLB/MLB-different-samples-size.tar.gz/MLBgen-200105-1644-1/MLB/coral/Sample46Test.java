import org.junit.Test;

public class Sample46Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark46(0.0,0,-0.7620987460787632,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark46(100.0,45.42130157839217,-57.24728393841602,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark46(1.1102230246251565E-16,2.8263319802982316,1.0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark46(20.396116624059758,1.0,39.91668119700763,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark46(23.87086656966953,0,47.74143577823236,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark46(34.50929224917767,1.0000000000000002,53.1252955399425,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark46(36.339197686094366,-50.7655150715562,56.776321338208106,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark46(-37.17275834311196,0,48.40232528314655,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark46(42.54367377296603,90.51361804772807,29.584967335668523,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark46(-700.9973600265575,0,23.982449189898375,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark46(74.74679621236956,0,90.1589810635964,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark46(7.984313141538678,67.65018010805653,3.8343439206540495,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark46(81.82603964805878,4.938491783696833,90.54568188271179,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark46(-98.476417710575,0,0.6827635395624672,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark46(99.84282560103267,0.9999999999999999,72.5208427768332,0 ) ;
  }
}
