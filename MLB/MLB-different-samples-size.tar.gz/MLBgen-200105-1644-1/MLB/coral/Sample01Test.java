import org.junit.Test;

public class Sample01Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark01(-23.688431088904792,-66.72538271732907 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark01(-48.23947335460638,89.43338130362551 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark01(57.03555593983717,19.266460930860617 ) ;
  }
}
