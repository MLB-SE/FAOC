import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(-0.4315713437079438 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(2.7003803401916713 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark31(3.0040502399166513 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark31(-47.413735994826325 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark31(4.7654482028883365 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark31(51.12391437301031 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark31(-62.24472416893776 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark31(94.39910586324726 ) ;
  }
}
