import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(-29.323575741875665,1.0511533795606625 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(-73.77200026556218,-76.1374745187791 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(81.31288066514566,-31.18752264035072 ) ;
  }
}
