import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(0.8611046386969687,13.80604019362733 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(14.23110726969881,99.07578458371734 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(36.892711527335564,59.796056200268964 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(5.010288126902855E-15,7.078338877803105E-8 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(50.920711384034746,80.02151012813493 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(6.682414343344983,43.31758565665502 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(8.388083623341842,36.7011447648853 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(94.60656799384316,44.86976031418493 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(9.842383509757834E-12,2.279324880962738E-6 ) ;
  }
}
