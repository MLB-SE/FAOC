import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(-0.20689166468517642,32.57614753954702,83.41798126652607,0.12587108158454896 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(0.23824061098709137,4.698557697840869,83.69113156311573,25.38393155298391 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(-0.5008196735290227,-62.2439853494964,-45.314927300554906,-4.504607253126096 ) ;
  }
}
