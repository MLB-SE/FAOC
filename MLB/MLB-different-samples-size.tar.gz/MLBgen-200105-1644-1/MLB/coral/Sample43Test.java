import org.junit.Test;

public class Sample43Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark43(0.12314908829220245,0.015165697947200674 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark43(18.75232542418061,95.93761009192727 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark43(2.357821105898539,2.357821105898539 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark43(32.76874467164214,63.099906838173496 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark43(42.168386895387414,85.61248414279729 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark43(4.5205242827056225,31.186498579347756 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark43(5.50113649688612,5.50113649688612 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark43(91.02254879084393,30.314917711970025 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark43(9.950970940480829,0.7040510802181217 ) ;
  }
}
