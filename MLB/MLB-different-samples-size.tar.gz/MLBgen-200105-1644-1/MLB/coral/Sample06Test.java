import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(-3.6807291735640177,-93.24094472988556,-79.02776312247555 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(37.494168153608406,-27.462400966962875,73.14538529337953 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(-38.91123205543623,-83.76933676447618,-42.3646094426438 ) ;
  }
}
