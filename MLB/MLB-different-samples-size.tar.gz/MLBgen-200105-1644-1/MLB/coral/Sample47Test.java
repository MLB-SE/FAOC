import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(-63.66023357020505,-71.74055735667065,-135.4007909268757 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(-79.79960082615342,-55.21375219100955,82.58496811704484 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(84.88047692158096,66.77416546187541,-12.288686907904761 ) ;
  }
}
