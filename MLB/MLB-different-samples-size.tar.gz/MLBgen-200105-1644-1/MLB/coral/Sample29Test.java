import org.junit.Test;

public class Sample29Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark29(1.6094379124341005 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark29(-33.44497715858314 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark29(77.4399513271193 ) ;
  }
}
