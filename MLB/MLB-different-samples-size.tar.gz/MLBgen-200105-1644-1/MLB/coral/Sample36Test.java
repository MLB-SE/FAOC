import org.junit.Test;

public class Sample36Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark36(-3.141606836302865,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark36(-49.77838420154968,50.88649150022343,3.6522538868691106 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark36(-54.72000095284648,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark36(83.89831774947362,-0.18983299726814096,83.27703742427275 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark36(8.447227368163858,-86.51963933058093,2.960269884703564 ) ;
  }
}
