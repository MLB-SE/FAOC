import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,2.0804022461568366 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,64.48923896798294 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(0.336765461867671,124.9469478945445,72.50858404574093,-71.95182267022531 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(11.99885777514065,-8.515266220202676,100.0,-42.95143918669972 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(1.434042592217267,-6.754034012229084E-226,54.685064506812914,-51.814923849440035 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(15.467878492317723,68.07368743617863,-42.68995845877708,-77.67147865728631 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(25.28051464590997,1.2154326714572542E-63,-55.9585278890713,-21.682182247742404 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(27.750961029372625,-3.552713678800501E-15,-41.91888114897499,-7.84527536837907 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(33.46521410320992,-33.94369249748764,45.907252774863025,-95.94425437779988 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(33.93838549364568,88.52869247242697,10.572019042166431,38.0828166683653 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(39.57575258431843,-0.43054407346234314,35.217467342171304,59.35947923837457 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(57.178843188237266,-36.212978333394204,66.33281013619953,23.242848661643436 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(63.47406678781968,85.60653826519183,93.03958819285396,79.297895279053 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(66.30823070782219,0.0,34.426186375143345,-95.04480931953725 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(66.90450639139112,-40.39754970101487,63.61561234315863,-37.108655652782375 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(76.21849092491979,11.301095191514008,81.96323924102242,6.744345537603492 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(77.02364618131867,-31.588832782358693,-78.42789578728005,-61.44144165187973 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(-81.5166372001247,40.34526426936631,-24.34377353353625,-81.24870809660558 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(88.32964115791026,2.081992798558005,-34.676287420769796,44.34614078725264 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(91.15094687658814,-30.621615706625363,0.7244551304319486,76.24298042618813 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(99.80310607641692,35.976703902022194,51.10980396248004,76.96842331254592 ) ;
  }
}
