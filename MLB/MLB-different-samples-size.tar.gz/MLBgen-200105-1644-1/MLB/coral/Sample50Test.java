import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(0.9834838426986307,11.185315141675318 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(10.298561776054735,23.298561776054736 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(19.963641472135365,68.74989325840443 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(20.251165243948073,26.620850039283823 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(3.63800650845722E-19,4.095841453505193E-11 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(37.788422126311644,45.202317422940155 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(46.32178854427406,4.256356290169208 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(49.05308471139415,72.94809860990333 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(6.812639686659775,19.812639686659775 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(7.088034745310162,42.91196525468983 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(8.94322596574553E-16,2.9905226910601315E-8 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(9.715730297267891,40.28426970273211 ) ;
  }
}
