import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(2.493602125787646,-71.39778990189755,89.5238859816551 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(-25.425907290175545,-75.23730239906745,58.80778789764855 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(28.61164177144886,68.69310034403455,2.7680944847581657 ) ;
  }
}
