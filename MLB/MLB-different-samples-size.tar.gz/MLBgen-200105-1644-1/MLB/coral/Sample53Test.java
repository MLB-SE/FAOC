import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark53(24.268152134106376,-50.12095723994397,35.852956588959366 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(5.473863409609621,-30.63242338414929,66.9352655894433 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(54.899438141860685,53.21495017807078,-48.99864712784665 ) ;
  }
}
