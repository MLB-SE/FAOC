import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(-44.08491928077191,7.181855073246666 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(-52.043481036220584,5.500967265823391 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(-64.5289895261618,-39.191227799332125 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(-64.540818168313,-28.258380186141395 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(68.96510300741622,74.27476503772235 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(89.93426054670311,-15.521925780505399 ) ;
  }
}
