import org.junit.Test;

public class Sample42Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark42(1.0,-9.06729059216847 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark42(14.406761488651458,1.2525060781955801 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark42(18.67174995302014,86.77098578039383 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark42(2.218806305749737,2.2188063057497374 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark42(-2.6555507867911756,100.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark42(35.28558059631891,61.49535332543036 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark42(43.30845129821677,68.39215532225433 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark42(7.487741044234113,10.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark42(96.91981586248698,42.54439353573446 ) ;
  }
}
