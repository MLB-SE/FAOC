import org.junit.Test;

public class Sample16Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,-0.3787921988247689 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,-28.461480932860724 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark16(20.96726965433902,15.121551130381924,-64.81972721348997,-35.78040421164697,54.580922238517104 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark16(76.42970285782104,14.07585748030364,-69.15176374112221,-70.07104261162036,-58.14994350832152 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark16(-89.72132591571582,14.41157157144994,-25.773627009399803,64.127765760292,-30.224636124065057 ) ;
  }
}
