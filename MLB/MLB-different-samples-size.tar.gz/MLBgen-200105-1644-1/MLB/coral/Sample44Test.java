import org.junit.Test;

public class Sample44Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark44(0.6135870837877953,0.6135870837877953 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark44(1.6963666995318638,1.6963666995318638 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark44(19.887160393000542,0.47744980253564506 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark44(32.835607029260615,75.3607708729206 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark44(79.86370339406011,98.03191396931055 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark44(87.85120637470379,63.44334110655123 ) ;
  }
}
