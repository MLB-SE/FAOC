import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(1.9050679600103604,3.6328880585501926 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(2.445893676715697,5.982465180073286 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(-81.81256661342829,38.76995494357928 ) ;
  }
}
