import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-3.1451782957163203 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,47.28506614331965 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(0.7717870153602598,13.633426157896594,11.97715704476724,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(0.9738251412522735,1.9954962233879863,-47.41538808173262,50.384709544674145 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(1.0208239055584625,98.6083050667373,99.62968146771094,-5.524954151685717E-4 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(13.80814625709914,-9.697816621474814,98.142141150568,31.76996893392166 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(18.577074387403684,21.556468915130836,92.91081769200372,-61.02840970372569 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(2.37440999582123,-2.4308653429145085E-63,21.469563073433303,-19.85333203920507 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(36.81412328358745,-38.252666912320834,-46.20395777643708,32.11856550858937 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(38.132607584273565,13.554620063081583,77.88743949746343,2.813255362880624 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(3.860403075613986,0.0,53.42528759606722,23.70435179040364 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(4.312098448448225,4.0526956383567665,-64.09327808950162,-42.1703050570809 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(48.66602406545314,56.23442211911055,-54.90030532101464,-75.28696507526769 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(52.229481232573164,-30.71827578652406,65.93061889028914,-38.438211435559566 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(54.988468145591696,-22.75595880657491,79.69863414325093,-46.30571164806903 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(71.2320236363316,49.593766134513885,-1.4308832177346744,-45.59000971007465 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(7.388365355180682,28.219218334342656,76.70420292898723,-52.85474368674683 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(-74.60728970267888,89.3239617808741,-52.93971694637083,-57.034217752877446 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(77.21135204017898,54.48573734139336,-90.22950799767,-6.925526532313768 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(7.794622593205318,53.76533690328705,48.3910881155706,23.5722687467715 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(81.00239665903173,-39.11963581298588,27.317684204247904,14.565076641797951 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(-86.78523365421218,65.99767303689708,-49.256588149911295,-88.46334861802873 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(98.02219820970771,-1.6080575641284813,48.200555251410265,-30.33744937571565 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(99.89782844176042,-82.3557107174855,-31.817735838301587,61.673877886501884 ) ;
  }
}
