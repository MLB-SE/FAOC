import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(0.164082406997764,51.14960333835279,-25.347744114569082,-78.64357185140977 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(-0.4567498888721673,-60.484930988842756,-12.720461979218456,65.89137637235507 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(0.6679134238064819,56.339503159309885,-79.10048480466014,-91.29309043411948 ) ;
  }
}
