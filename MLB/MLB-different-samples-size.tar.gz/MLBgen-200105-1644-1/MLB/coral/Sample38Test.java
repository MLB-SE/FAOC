import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(10.509533016313384,58.78881569048892 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(32.397829876507956,-44.052634324651166 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(87.63107226847501,56.2672644299955 ) ;
  }
}
