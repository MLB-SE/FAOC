import org.junit.Test;

public class Sample04Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark04(48.40615955995153 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark04(-659.8993001793439 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark04(-81.89980655857386 ) ;
  }
}
