import org.junit.Test;

public class Sample41Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark41(0.5763574912095653,-0.24416953353618115 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark41(-1.0000000000000009,2.0000000000000027 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark41(10.08874628632432,91.69405534349842 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,1.9999999999999998 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0000000000000004 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark41(10.429398432003367,98.34295322147092 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark41(2.5806829123676636,4.079241381819045 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark41(9.01645995653,51.70311383805054 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark41(9.92977553938953,88.67066672326911 ) ;
  }
}
