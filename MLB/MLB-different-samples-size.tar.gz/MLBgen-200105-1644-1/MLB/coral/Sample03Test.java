import org.junit.Test;

public class Sample03Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark03(-32.69425610579222,78.83228309664544 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark03(41.78765304513297,84.8526508416385 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark03(50.955893100156146,-94.40412941635255 ) ;
  }
}
