import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark07(0,-10.059781512283934,0,93.75793717867055 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(0,-10.98463404810366,0,43.97682702934762 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(0,-90.63263270579812,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(0,99.48376736176385,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(12.654054819937485,23.33069023145589,76.61631314094018,-91.03063670837308 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(-23.159327831664783,-56.50237183051408,70.18383308397523,-53.26987628851501 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(-25.134337677978074,18.363083405165916,-92.29679137725145,-97.55912575727577 ) ;
  }
}
