import org.junit.Test;

public class Sample72Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark72(-100.0,100.0,100.0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark72(108.6519964247725,128.24826909969963,28.021479260650977,87.72414740113886,37.38255641793059,-83.23475365223489,-89.54995234950218 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark72(10.878292958991722,-42.16689613628994,0,0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark72(-16.6058632691729,96.92715997537994,-25.5754169800513,-21.945450786956243,0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark72(25.43523504942584,87.4032680470828,-19.430673782673495,79.77496860979042,-62.894852080589736,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark72(27.543026429526464,-72.2400589027407,-50.88931911996928,0,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark72(-29.06747551189926,-37.110059664953646,0,0,0,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark72(39.484067749213835,-100.0,100.0,-71.2252186027606,74.24988807144604,-100.0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark72(44.83429365249446,71.4955799644523,-100.0,-100.0,0,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark72(45.99633914411055,-55.655325484628435,78.54998908055381,93.97679019384705,0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark72(-47.237659438486396,-94.14147488961311,55.98303960509984,-19.88397570389385,29.712533665954254,35.99571897313384,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark72(59.114171760244545,100.0,47.858608362759725,-2.31758167764705,49.44147148149395,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark72(-60.14208510248198,0.4518246842759067,0,0,0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark72(69.75955404386082,189.04628086184542,-84.08232900718389,80.84766361486737,-64.93842518655444,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark72(-74.0472516863657,-100.0,-85.00216187653389,-70.877882785613,-95.9234756892273,-45.50649592713039,38.70507290126264 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark72(7.626259236109938,51.57210150965348,-17.67018827162732,-92.03568128580278,12.966135462113648,15.757035078725927,74.26788312272542 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark72(-8.6347741974065,80.83803536483228,-99.32847033459605,0,0,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark72(-92.56097839412165,21.635408137830687,-43.697409709586935,-94.57844753102434,-6.885591768521621,68.03882292407388,0 ) ;
  }
}
