import org.junit.Test;

public class Sample51Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark51(11.386487996103284,12.310923857697789 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark51(11.632018115079063,27.748153969104862 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark51(1.1722641890799774,48.485995636664285 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark51(1.296752637887615,25.159881823775084 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark51(21.40264157713709,28.59735842286291 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark51(21.92277596466603,86.48632922453325 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark51(22.64789139380909,91.61888508771528 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark51(-33.49184838092434,18.34897749854754 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark51(5.047992417175976,8.373075682917158 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark51(66.90897457426189,70.9930318617348 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark51(7.705687758881308E-14,2.775911698027446E-7 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark51(9.153448887985123E-16,3.0254667223397335E-8 ) ;
  }
}
