import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(35.89164768237154,14.534955671352392,-63.677600031744696 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(39.845310662617806,61.06892366559998,56.70707697888281 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(47.49485507032896,-72.71928641697967,48.44215998831572 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark52(49.7118740566421,-55.570935037660064,75.18961943647318 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark52(88.41536961960875,19.057501429449147,76.89074814725097 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark52(96.50405272808379,17.86578280341378,10.683578428189037 ) ;
  }
}
