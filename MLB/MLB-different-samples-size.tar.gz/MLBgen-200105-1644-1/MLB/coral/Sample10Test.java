import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(57.11641223021908,19.25306720669309,23.551893902649468 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(-83.68873648391033,38.84987956470462,-86.56485113562489 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(94.35488207341574,72.4220011212835,79.11439498088774 ) ;
  }
}
