import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(-49.606424421610285,62.343946666498965 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(5.191821659575496,29.770577850357398 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(59.884518691463484,-32.645983866028814 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(67.81664977970237,10.453350883476446 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(84.9581497991432,97.4003679354958 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(89.71342724118236,-82.26962132319767 ) ;
  }
}
