import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(30.65215877433093,88.32441158647612,-2.2100184463433408 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(-40.67387481446731,-56.37314440623076,13.04551992840193 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(-97.63595333004555,29.199112196976685,-68.43684113306887 ) ;
  }
}
