import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(0.676302108056845,-160.96283828462586,-49.833141593734595,24.37298455798711 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(0.7833072609204663,-91.82088952744508,-6.3529999802190815,48.47163113440641 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(0.9285425257754554,24.368094679757377,-22.416901712947364,99.90590757385493 ) ;
  }
}
