import org.junit.Test;

public class Sample26Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark26(100.0,-16.967231651585998,100.0,0,-13.189426501471054 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark26(20.094535053051708,36.05275980455819,39.81586604345745,61.95162838610534,44.90875696871169 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark26(-23.04326512883688,-84.0514588694472,-76.29310612739422,0,19.68404966474793 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark26(28.007823482289346,-15.595507491509657,10.075380824469155,-23.31992038730834,-43.06107234340156 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark26(30.17729189646242,50.13226850151811,-55.58368560832665,-69.61619839249308,-75.56970192715569 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark26(-3.457815914285439,-44.58024411768868,100.0,-83.77212103100337,100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark26(-61.1953816661545,20.940178431127237,-7.563769949952587,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark26(-67.24414885594555,20.41924705803828,-11.390837499337565,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark26(69.49710511528819,84.07810141354791,-77.6977829743087,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark26(-73.86625670566468,-32.090737714705256,18.898022919552318,94.1575622383682,-68.85891413533773 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark26(79.66664443412168,68.94379391419676,41.46487317259971,-11.309092136964068,71.24785697744073 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark26(-85.60221721689442,-34.23052605441307,78.88129545710824,-88.55128884639772,99.98846419781347 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark26(93.83041493421408,72.16474998118693,-10.751677343453679,-55.57762258340988,29.81471662124983 ) ;
  }
}
