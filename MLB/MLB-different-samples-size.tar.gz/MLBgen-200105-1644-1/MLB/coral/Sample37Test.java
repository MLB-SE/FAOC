import org.junit.Test;

public class Sample37Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark37(20.622471747289083,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark37(57.42245782053984,3.5876204968923573,-68.19019233303672 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark37(-62.83185024127317,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark37(-68.97811187957731,23.712252840622597,-5.227930674569464 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark37(-87.65051385907347,92.64618515686186,31.705586831166187 ) ;
  }
}
