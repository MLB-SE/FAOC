import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(29.509991479612808,28.298513383017422,-23.963613084794005 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(-34.412912859076904,86.88899686882493,-100.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(-55.84125146280537,0.7618292276781862,-93.97220258786 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(60.65765222485056,54.80755740007697,43.47885690968678 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(-86.0610183951078,13.87982245649988,86.11493128445812 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(-9.16086796149149,-96.91388755092474,95.53880657692909 ) ;
  }
}
