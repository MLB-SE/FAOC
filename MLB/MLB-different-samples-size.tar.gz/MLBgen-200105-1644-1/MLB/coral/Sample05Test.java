import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark05(-59.8133567230235,-79.49469800394306,26.610447759536427 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(-62.663796574928796,92.62431579676644,-28.53798308270126 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(-78.52333287332041,25.73104286800345,55.11268376978182 ) ;
  }
}
