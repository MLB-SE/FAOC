import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(-0.2446601481526045,-94.63052815984511,-11.188087530531803,97.13100659140918 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(-0.4825592130842775,91.34691699192369,64.83270435122633,0.9147062767552896 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(0.778203820082112,-15.935313480516115,54.36154575647453,56.59244027489336 ) ;
  }
}
