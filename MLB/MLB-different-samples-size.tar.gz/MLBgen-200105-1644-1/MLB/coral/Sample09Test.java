import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(100.0,-78.98656659704416 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(-35.81776236358492,25.455375711775687 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(88.7696053841679,33.11120505034671 ) ;
  }
}
