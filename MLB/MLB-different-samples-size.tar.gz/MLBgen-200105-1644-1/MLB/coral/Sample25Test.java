import org.junit.Test;

public class Sample25Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark25(100.0,-24.961091064901083,49.23100001498509,0,46.780589471056956 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark25(-43.85623806523594,61.304533512358745,20.821478912580147,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark25(44.6334385967329,-69.99049956278293,88.94724359134923,-85.02163376958045,-47.38369818243584 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark25(-52.62012468486823,78.04548588079331,2.11432558202506,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark25(-57.11634848536469,73.7597491919098,-30.865647419951543,0,97.95948334594746 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark25(57.858268330917156,-63.46412623880153,-38.70094956823096,-78.43716853757283,20.821493735738585 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark25(76.44955534143232,25.862643982669063,-63.91800522354799,-66.84083004119307,24.067472542828746 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark25(94.0637793955133,-66.03464827748348,100.0,23.466150775752944,99.15175683954656 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark25(94.08558847039467,98.67288064960533,-16.297045890490722,-56.79275085399582,42.95407353471779 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark25(94.74090213702168,60.40810172893212,10.12611159185665,0,0 ) ;
  }
}
