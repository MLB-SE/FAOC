import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(-2.0114872416416383E-10,100.0,-100.0,-100.0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(-7.33089746619496E-9,100.0,100.0,100.0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(-78.11946322944368,86.38334565468625,-14.101784121686151,-11.734173699451844,0 ) ;
  }
}
