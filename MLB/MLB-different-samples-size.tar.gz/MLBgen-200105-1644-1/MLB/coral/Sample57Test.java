import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0,-1.5018038718868496,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(0,-15.787212150851587,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(0.7568950570052823,77.4091935679793,56.55022244403731,1.458657526114266,68.52913002808438 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(-26.664352479908445,-3.6656210843408132,33.70888436912671,43.3106461707296,14.245103183601813 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(37.76377563218825,12.524513835755148,45.70902604309833,-3.178915887166454,14.595551717232004 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(43.221983371722644,-41.97478775808927,-36.336997568753304,-84.0726713679835,-10.196037407738757 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(78.99013955316082,42.007917382535766,45.86185112327888,54.72952451768376,29.351645066250313 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(94.04688660185582,75.19260032210352,41.93153543361993,93.06584975190364,82.73427176799527 ) ;
  }
}
