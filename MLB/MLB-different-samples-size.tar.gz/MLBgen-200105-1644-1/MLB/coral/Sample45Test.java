import org.junit.Test;

public class Sample45Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark45(0.0,-7.843632919369554,20.35454912979597 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark45(100.0,37.63625464770692,-100.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark45(1.3877787807814457E-17,1.0000000000000004,1.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark45(20.646061043886462,-66.24938031748692,95.2392892895785 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark45(42.00427626369262,18.147971842926935,100.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark45(-435.6273822354742,-239.2107777892776,18.14637238790364 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark45(45.33648252388093,8.452982762875521,96.59906807449548 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark45(49.159461828321014,70.44732608609073,90.66588850306124 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark45(7.160008138880251,1.0,62.15548946666296 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark45(71.856765557605,28.033409758626533,74.20248504721857 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark45(-7.2757426333304664,35.50522351619742,79.43411571288382 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark45(73.22113071246613,-15.082275494787638,48.55250847085199 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark45(-7.6562894958343435,-97.7326051910936,4.0622280236393635 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark45(9.426589552514258,70.13927013051605,88.62386338869527 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark45(95.19394648258273,97.19394648258273,20.375407134116386 ) ;
  }
}
