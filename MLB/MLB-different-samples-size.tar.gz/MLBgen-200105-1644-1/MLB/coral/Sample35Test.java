import org.junit.Test;

public class Sample35Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark35(-17.278759599462852,-79.5230612605134 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark35(3.141588995891533,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark35(-36.12831552659423,-97.56141163209828 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark35(64.40464950345583,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark35(81.97840318345752,20.599648756989737 ) ;
  }
}
