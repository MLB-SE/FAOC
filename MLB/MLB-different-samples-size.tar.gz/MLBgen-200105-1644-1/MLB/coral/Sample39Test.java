import org.junit.Test;

public class Sample39Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark39(0.9897360669036743,-3.172744828194834E-15 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark39(26.563676613806805,33.12096399869077 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark39(63.637219453859785,-76.97853339324095 ) ;
  }
}
