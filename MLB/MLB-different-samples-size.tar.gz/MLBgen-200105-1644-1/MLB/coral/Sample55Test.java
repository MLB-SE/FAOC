import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(13.317864646939542,21.843956121123274,14.308654607931388 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(18.408668900430115,-35.50002496378602,-36.57905339832814 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(2.8817934779665806,71.81678968154651,-4.504917371257889 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark55(30.08191474394505,87.84303439140203,52.396526195040764 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark55(43.65826637266588,62.928367222418416,70.48864538999263 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark55(83.0230991552929,-66.56829736292084,65.03580694792177 ) ;
  }
}
