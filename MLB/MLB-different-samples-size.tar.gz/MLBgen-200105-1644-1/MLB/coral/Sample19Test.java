import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(0.7171865978751413,14.904171863878048,-0.33645670621397983 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(0.8128739898364294,81.5704224683011,0.3018593724116305 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(0.8238139577311425,27.97432804963872,0.27121096157658714 ) ;
  }
}
