import org.junit.Test;

public class JpfTargetCollision4Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision4(-137,-85,-578 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision4(-37690,178,559 ) ;
  }
}
