import org.junit.Test;

public class JpfTargetCollision2Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision2(480,-116,461,-488 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision2(-525,-752,-135,668 ) ;
  }
}
