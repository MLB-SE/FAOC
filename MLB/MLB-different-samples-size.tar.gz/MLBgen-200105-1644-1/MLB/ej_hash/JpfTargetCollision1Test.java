import org.junit.Test;

public class JpfTargetCollision1Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision1(166,453,-644,402,-474,87 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision1(-507,-153,-69,-535,-1070,-1588 ) ;
  }
}
