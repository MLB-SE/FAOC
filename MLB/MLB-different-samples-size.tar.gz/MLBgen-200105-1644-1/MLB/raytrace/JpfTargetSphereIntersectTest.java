import org.junit.Test;

public class JpfTargetSphereIntersectTest {

  @Test
  public void test0() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.98777676f,22.833588f,23.69014f,96.078636f,-27.546225f,77.31109f,69.4795f,1.2151964f,17.040062f,-25.934351f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.12514026f,0.7630764f,-0.6340775f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.23097527f,0.052629467f,-0.12032611f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.62201154f,0.71778876f,0.22455385f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.7269008f,-0.6844614f,0.055926584f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1.0621625E-6f,1.979134E-6f,-1.4548124E-6f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,3.437514E-6f,-5.477726E-6f,1.176642E-6f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-66.23483f,-76.48461f,-51.10966f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-6.7573315E-15f,1.9969129E-14f,1.8297172E-14f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-89.49648f,-14.386953f,-95.708916f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-93.22486f,18.881592f,-80.58816f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,-100.0f,-98.5804f,73.38214f,21.221443f,100.0f,-0.21679606f,0.17219187f,0.96091074f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-77.44826f,-91.46475f,42.03353f,-100.0f,-60.042152f,-52.969208f,-0.9027895f,-0.4278881f,-0.043393135f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,94.85642f,-94.70712f,100.0f,-100.0f,-25.057516f,-62.639374f,-0.15917177f,0.36829346f,-0.91598266f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,99.42111f,-99.685005f,76.79676f,-100.0f,84.12157f,-33.178272f,-0.50648236f,-0.7283775f,0.46145615f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,10.039389f,-5.8963485f,-48.96648f,57.7632f,-19.44082f,-49.153103f,-24.546047f,-44.580124f,21.684364f,-19.694347f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1.1820245f,60.93841f,-49.425694f,38.91158f,-49.72401f,64.533424f,-49.06815f,-0.8413745f,-0.14035857f,0.2392072f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,12.275468f,-86.35127f,-0.07290206f,60.840694f,-40.181168f,-95.49281f,29.36047f,0.8003464f,-0.25365183f,-0.5069896f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-13.864591f,-17.403627f,-58.57612f,82.97988f,36.15058f,68.51698f,-110.66065f,-27.530745f,-50.150833f,-17.953455f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,14.367664f,-42.047295f,-88.196465f,-39.73223f,-80.65425f,-98.1682f,100.0f,-30.37079f,-10.401923f,40.239067f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,15.814185f,-99.99998f,0.7653273f,99.81483f,23.11191f,-85.60399f,99.71729f,-0.054778118f,-0.24029605f,-0.9691528f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-164.54845f,-71.75573f,-19.808697f,87.8374f,-91.81394f,-44.293823f,-60.381245f,-0.867627f,0.17065273f,-0.46662277f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,16.618753f,50.897655f,-61.049587f,82.76295f,75.84723f,92.21653f,-20.621326f,-0.076562725f,-0.91466784f,0.12702686f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,18.712297f,-80.62305f,-38.408047f,88.48777f,-6.913441f,0.2843226f,-13.359991f,-0.0063526994f,-0.19273224f,-0.45081088f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,18.952745f,-97.96044f,99.69449f,-100.0f,-15.988544f,-82.73748f,-97.89935f,-0.8488339f,0.41790053f,-0.32379028f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-20.737494f,62.112762f,100.0f,-11.997799f,-79.101494f,79.410515f,59.750866f,2.1755602f,2.623695f,-3.4789078f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-22.19957f,-14.064695f,-16.266953f,77.74027f,-57.840294f,6.1345696f,49.8033f,18.712143f,105.85112f,-26.11629f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2.2765505f,9.811728f,85.48552f,99.24629f,66.734215f,73.870415f,45.59165f,-136.96837f,-47.843616f,-163.06107f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,28.829529f,57.72957f,-24.868952f,87.60084f,12.632334f,100.0f,-99.86741f,0.21640281f,-0.435273f,0.87390345f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,29.118423f,80.797165f,36.56215f,100.0f,72.94695f,-50.46644f,91.86526f,-0.51736975f,0.66561675f,-0.53785026f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,30.488256f,13.025277f,-17.672455f,58.149994f,-3.011916f,22.373549f,28.929798f,60.545322f,-17.317106f,-84.15162f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-31.160952f,3.871084f,2.9768472f,88.680916f,-55.162872f,-78.69655f,-18.721031f,0.27248704f,0.5184592f,0.81052506f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,32.138092f,-0.19808534f,-3.4058394f,85.10121f,91.59654f,16.317669f,55.19568f,33.083927f,150.58134f,-100.0f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,33.184055f,48.63515f,-69.319984f,56.79755f,31.49761f,38.68373f,-37.96462f,0.7729665f,0.5403768f,-0.32986528f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-34.390465f,27.993958f,-50.08788f,91.98561f,-83.13392f,-43.808826f,-19.59545f,15.271636f,22.558512f,-9.646834f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-35.068424f,7.1326528f,-17.11184f,87.4698f,-66.964066f,-45.141197f,45.346775f,67.52978f,87.83709f,29.681437f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-35.49194f,93.6483f,58.941456f,70.8431f,-2.1584408f,37.371357f,31.728804f,-40.37598f,84.84492f,17.077051f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-36.140938f,86.92128f,47.116055f,-43.55083f,-85.23281f,46.83152f,74.1999f,5.091709f,-71.78687f,26.029634f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,3.6516178f,34.83183f,18.917845f,82.207214f,-79.7644f,45.27017f,-59.54433f,3.929875f,-2.9576595f,92.92123f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,39.245598f,-49.245567f,100.0f,-81.42751f,6.251413f,-100.0f,-71.469986f,0.52778375f,0.094509415f,-0.074221104f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,39.254543f,100.0f,58.42137f,52.34249f,-2.1981907f,80.902916f,100.0f,0.90252286f,-0.11917063f,-0.4138247f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-40.082085f,-17.724962f,32.676495f,91.682945f,20.557077f,-74.04113f,41.03562f,-19.338476f,-86.63537f,-4.0044384f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,40.262005f,95.35412f,-15.688762f,1.5628079f,-96.655174f,-57.563095f,-26.568844f,74.949356f,-85.65581f,-59.83745f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,41.702694f,73.38406f,-17.29576f,95.39102f,2.9689817f,0.013345358f,-86.58377f,-11.010394f,63.025085f,64.15609f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,42.77871f,-39.198277f,0.83478075f,97.51627f,-39.35482f,-89.833626f,14.961723f,-1.1930851f,-26.050182f,-99.998215f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,47.53876f,10.94355f,-23.338448f,42.311913f,27.05879f,45.20065f,-38.80338f,55.668926f,-12.57966f,-65.30867f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,4.8054957f,-60.21457f,-39.82574f,95.77759f,91.45995f,-19.994938f,-46.661835f,3.0123708f,10.147429f,97.927765f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-49.041126f,18.526306f,-33.971413f,-44.870247f,-57.7317f,49.529736f,-85.16222f,-86.036865f,44.393253f,-56.970444f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,50.64874f,-1.1510487f,77.1568f,-7.2533364f,57.560043f,5.204482f,73.02607f,50.062855f,61.627724f,29.7167f ) ;
  }

  @Test
  public void test49() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-51.65861f,61.321262f,-94.88812f,62.63459f,97.523415f,-81.74971f,68.69352f,-43.865726f,-24.3673f,-0.5221141f ) ;
  }

  @Test
  public void test50() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,63.468628f,-100.0f,100.0f,99.439026f,-66.31657f,-99.98275f,58.025322f,0.4834006f,0.042380083f,0.8743728f ) ;
  }

  @Test
  public void test51() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,63.835114f,-4.528102f,5.250353f,40.31619f,30.164337f,13.780776f,-7.2581873f,99.37397f,100.0f,-116.2694f ) ;
  }

  @Test
  public void test52() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,69.887596f,-32.078213f,-21.943617f,100.0f,-6.9220552f,-0.9168899f,-77.883316f,-69.584854f,-67.31141f,58.107124f ) ;
  }

  @Test
  public void test53() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,70.65895f,100.0f,40.245384f,-100.0f,36.069138f,-88.81699f,63.619946f,-0.14429976f,-0.9851238f,-0.09332019f ) ;
  }

  @Test
  public void test54() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-70.99128f,1.0389085f,0.72076213f,75.930145f,-86.558205f,3.5099435f,-24.111752f,-10.703899f,-81.254364f,-29.533436f ) ;
  }

  @Test
  public void test55() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-71.1802f,-16.587086f,-17.844011f,31.728296f,-61.613102f,-24.876923f,20.776196f,48.300983f,76.81982f,87.363594f ) ;
  }

  @Test
  public void test56() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,73.26287f,-100.0f,-100.0f,26.731474f,100.0f,-100.0f,-100.0f,-331.30655f,-4.168155f,-5.389609f ) ;
  }

  @Test
  public void test57() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,73.78022f,96.694664f,40.41387f,40.78991f,72.45075f,93.46491f,81.05398f,0.1896602f,0.36748248f,-0.26682135f ) ;
  }

  @Test
  public void test58() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-75.52622f,-76.935616f,100.0f,19.301447f,-100.0f,-100.0f,-100.0f,0.07954671f,-0.46602947f,0.057354566f ) ;
  }

  @Test
  public void test59() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-79.90514f,31.067991f,-53.36818f,-45.829002f,-38.763905f,34.79747f,-6.4888353f,82.72513f,57.733498f,24.231691f ) ;
  }

  @Test
  public void test60() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-80.238075f,97.51195f,-83.414856f,87.23355f,-44.00313f,31.94235f,-38.72314f,-0.5375878f,-0.17377415f,-0.82510716f ) ;
  }

  @Test
  public void test61() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-81.63277f,12.212278f,-99.99988f,27.71221f,-99.99969f,8.317118f,-79.37676f,0.84677845f,-0.1789363f,0.9118551f ) ;
  }

  @Test
  public void test62() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,8.208693f,94.197f,-84.42301f,42.384636f,-8.378105f,-7.23078f,34.020298f,57.101974f,36.423756f,-67.99333f ) ;
  }

  @Test
  public void test63() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,82.82849f,26.999357f,-14.351377f,76.98311f,6.4472756f,33.618725f,-7.387697f,0.5794425f,0.40228775f,-0.19637217f ) ;
  }

  @Test
  public void test64() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,86.11801f,-100.0f,11.029828f,-100.0f,46.9215f,78.93302f,-6.8458905f,-0.085017234f,0.09052428f,0.013630565f ) ;
  }

  @Test
  public void test65() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,87.940544f,-16.659018f,-80.21363f,100.0f,-0.9053632f,24.752386f,-100.0f,0.091054484f,-0.88411176f,0.21107173f ) ;
  }

  @Test
  public void test66() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-88.91201f,100.0f,76.92694f,100.0f,-100.0f,3.9739938f,100.0f,0.028799491f,0.9991809f,0.02842599f ) ;
  }

  @Test
  public void test67() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,93.298676f,38.466183f,12.694567f,76.47392f,100.0f,-11.812227f,-21.009659f,-0.19189493f,-0.021178903f,0.085614316f ) ;
  }

  @Test
  public void test68() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-94.326195f,-97.793236f,-56.145954f,35.80724f,7.9577317f,31.162142f,0.29100084f,-0.27662647f,-0.43358594f,0.8576019f ) ;
  }

  @Test
  public void test69() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-95.45621f,13.2438755f,-92.31584f,-84.7609f,-84.00812f,-47.794716f,27.539682f,0.7793491f,-0.05081992f,0.62452567f ) ;
  }

  @Test
  public void test70() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,96.228134f,56.909763f,54.511875f,34.717644f,64.02338f,54.02337f,34.61551f,0.98291266f,0.16491283f,0.039671756f ) ;
  }

  @Test
  public void test71() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-98.021095f,-90.598335f,-1.2765478f,80.19861f,-21.64609f,-22.09416f,83.35745f,67.75162f,38.02196f,42.519535f ) ;
  }

  @Test
  public void test72() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.99702f,-100.0f,100.0f,-95.31431f,4.0018063f,100.0f,99.033966f,0.04822865f,0.45578593f,0.88878185f ) ;
  }
}
