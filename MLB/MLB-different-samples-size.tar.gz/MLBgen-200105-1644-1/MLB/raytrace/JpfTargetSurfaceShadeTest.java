import org.junit.Test;

public class JpfTargetSurfaceShadeTest {

  @Test
  public void test0() {
    TestDrivers.surfaceShade(0.0f,-755.0f,0f,0f,90.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-1005.0f,437.0f,-1989.0f,0f,0f,0f,2,-0.91724527f,100.0f,30.018324f,1.5053109f,-50.59489f,0f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-0.020370003f,91.35183f,0f,0f,0f,0f,0f,0f,0f,33.70616f,-37.543625f,-99.97846f,-245.0f,988.0f,1107.0f,1,-0.035724342f,0.8767801f,-0.3064722f,0f,0f,0f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-0.028805539f,0f,0f,0f,0f,0f,-45.81519f,76.291885f,16.05866f,85.96737f,2.4108958f,99.940926f,0f,0f,0f,2,-46.078312f,76.78994f,16.504215f,0f,0f,0f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,-28.833803f,19.517424f,0f,0f,0f,1,-24.576828f,-100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,-30.356228f,71.421684f,0f,0f,0f,1,31.571903f,100.0f,-72.07729f,0f,0f,0f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,5.940754f,18.049637f,0f,0f,0f,1,-0.21591693f,0.23444808f,-0.93963957f,0f,0f,0f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-17.049204f,74.92704f,100.0f,0f,0f,0f,1,0.8249256f,-0.3406372f,-0.4510699f,0f,0f,0f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,31.067883f,95.770615f,-91.41911f,0f,0f,0f,1,0.030735686f,0.0012332624f,0.4727364f,0f,0f,0f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-78.04013f,91.609184f,-6.379711f,0f,0f,0f,1,78.18471f,-4.8936987f,11.817829f,0f,0f,0f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,100.0f,100.0f,-100.0f,0f,0f,0f,1,-0.42828602f,0.09309925f,0.83425444f,0f,0f,0f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,20.949274f,82.808876f,1710.0f,-420.0f,126.0f,1,0.29413667f,0.37342972f,-0.14522448f,0f,0f,0f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,100.0f,92.18802f,-17.277739f,0f,0f,0f,1,-0.48772287f,0.45307952f,-0.19082102f,0f,0f,0f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,35.47751f,100.0f,71.88676f,-494.0f,828.0f,93.0f,-1,-0.7862027f,-0.13401006f,0.4526014f,0f,0f,0f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,37.143917f,-17.798384f,-100.0f,0f,0f,0f,1,-0.05485774f,-0.28705952f,0.8012179f,0f,0f,0f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-52.530407f,-4.7017026f,15.09795f,0f,0f,0f,1,6.4763303f,-52.324947f,-36.446415f,0f,0f,0f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,61.024418f,-95.29655f,62.50219f,0f,0f,0f,1,-80.01274f,62.161762f,25.5708f,0f,0f,0f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,67.75502f,19.221146f,-26.456223f,0f,0f,0f,1,11.557956f,-34.632305f,15.428109f,0f,0f,0f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-99.99916f,-95.400024f,99.99928f,0f,0f,0f,1,-0.03152223f,-0.017964276f,-0.9993416f,0f,0f,0f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,17.35744f,99.99904f,-14.317643f,-100.0f,-47.996494f,100.0f,0f,0f,0f,5,17.79021f,100.0f,-13.579888f,0f,0f,0f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,100.0f,0f,0f,0f,0f,0f,12.941146f,-87.75973f,-180.26196f,0f,0f,0f,1,100.0f,-33.218586f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,100.0f,0f,0f,0f,0f,0f,-705.0f,1881.0f,-1048.0f,-889.0f,-284.0f,297.0f,-1,-51.34895f,-39.73782f,90.05786f,0f,0f,0f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,-97.005066f,45.38273f,-100.0f,0f,0f,0f,1,-0.034846406f,-0.94377106f,-0.3435485f,0f,0f,0f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,1.0507829f,0f,0f,0f,0f,0f,-74.45314f,-10.609116f,-98.55217f,0f,0f,0f,1,-0.008876052f,-0.060144104f,0.14505138f,0f,0f,0f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,1448.0f,0f,0f,0f,0f,0f,-1018.0f,84.0f,2471.0f,485.0f,-156.0f,878.0f,7,0.9400455f,0.3203375f,-0.11704017f,0f,0f,0f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,1762.0f,0f,0f,0f,0f,0f,-445.0f,679.0f,-1481.0f,-198.0f,-1302.0f,-2320.0f,1,27.703495f,-82.14285f,-8.190833f,0f,0f,0f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,24.733263f,0f,0f,0f,0f,0f,-5.183163f,100.0f,100.0f,0f,0f,0f,1,-100.0f,-3.9990926f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,-25.24729f,0f,0f,0f,0f,0f,67.1673f,58.92139f,-51.495552f,0f,0f,0f,1,-43.892227f,1.0209221f,18.379423f,0f,0f,0f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,25.963789f,0f,0f,0f,0f,0f,100.0f,39.804432f,-100.0f,0f,0f,0f,1,0.63604504f,-0.38048288f,0.6368643f,0f,0f,0f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,34.513626f,0f,0f,0f,0f,0f,100.0f,85.11524f,30.848644f,0f,0f,0f,1,-0.5298054f,0.19797228f,0.10714439f,0f,0f,0f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,402.0f,0f,0f,0f,0f,0f,1266.0f,1075.0f,394.0f,-1234.0f,-776.0f,-927.0f,3,-49.626408f,-58.678497f,24.662106f,0f,0f,0f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,-47.951782f,0f,0f,0f,0f,0f,35.042065f,14.904188f,-55.085194f,0f,0f,0f,1,100.0f,-45.75235f,82.97495f,0f,0f,0f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,497.0f,0f,0f,0f,0f,0f,219.0f,-281.0f,-1792.0f,-916.0f,164.0f,648.0f,3,-100.0f,100.0f,-4.9847975f,0f,0f,0f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,658.0f,0f,0f,0f,0f,0f,-226.0f,832.0f,-334.0f,593.0f,1796.0f,-49.0f,2,62.342316f,-93.707596f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,758.0f,0f,0f,0f,0f,0f,38.0f,31.0f,-114.0f,389.0f,1883.0f,652.0f,-3,13.676205f,1.3050642f,71.98897f,0f,0f,0f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,-77.75368f,0f,0f,0f,0f,0f,-54.37729f,-89.12667f,100.0f,0f,0f,0f,2,-0.29087403f,-0.23579544f,-0.8599422f,0f,0f,0f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,797.0f,0f,0f,0f,0f,0f,853.0f,797.0f,1264.0f,-954.0f,-2295.0f,-699.0f,1,-76.954956f,100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,8.477716f,0f,0f,0f,0f,0f,2.1039238f,-92.18434f,-10.773203f,0f,0f,0f,1,13.7139225f,15.198226f,28.128122f,0f,0f,0f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,88.73428f,0f,0f,0f,0f,0f,100.0f,100.0f,15.940403f,0f,0f,0f,1,0.21281718f,-0.9670956f,-0.13940921f,0f,0f,0f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,-95.174706f,0f,0f,0f,0f,0f,78.21186f,89.58048f,-19.645687f,0f,0f,0f,1,-49.014236f,-28.641403f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,-99.12505f,0f,0f,0f,0f,0f,-68.035774f,-5.843267f,-77.59711f,0f,0f,0f,1,0.048670784f,0.8709961f,0.48887315f,0f,0f,0f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,22.874983f,20.527029f,20.380917f,0f,0f,0f,1,-17.683481f,16.457338f,-8.574587f,0f,0f,0f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,-35.273766f,-81.24911f,99.25651f,0f,0f,0f,1,-0.1337411f,-0.35120502f,-0.45612592f,0f,0f,0f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,-36.328804f,148.21045f,-48.05841f,0f,0f,0f,1,30.458158f,-5.818906f,51.549404f,0f,0f,0f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,-37.639286f,-100.0f,-100.0f,0f,0f,0f,1,-0.18542553f,-0.24043171f,0.68978083f,0f,0f,0f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,53.442635f,-53.724373f,-68.67929f,0f,0f,0f,1,-24.91157f,2.4135053f,76.09301f,0f,0f,0f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,-91.88293f,100.0f,-39.10901f,0f,0f,0f,1,0.04733934f,0.0743655f,0.66484755f,0f,0f,0f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,-9.39904f,-99.99999f,-100.0f,0f,0f,0f,1,0.9072034f,-0.2490251f,0.3390701f,0f,0f,0f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,-79.10391f,47.29912f,14.671507f,-90.997826f,-69.183464f,0f,0f,0f,2,-100.16132f,-79.067795f,47.046906f,0f,0f,0f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-100.0f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,-100.0f,0f,0f,0f,1,-0.13574275f,0.22057953f,0.9658771f,0f,0f,0f ) ;
  }

  @Test
  public void test49() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-100.0f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,-99.14783f,0f,0f,0f,1,0.83480966f,0.47038168f,-0.20525411f,0f,0f,0f ) ;
  }

  @Test
  public void test50() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0.0f,0f,0f,0f,0f,0f,4.8216047f,100.0f,97.17223f,0f,0f,0f,1,-0.4851833f,-0.5016908f,0.396816f,0f,0f,0f ) ;
  }

  @Test
  public void test51() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,100.0f,60.844776f,0f,0f,0f,1,0.949821f,-0.12568568f,-0.18704145f,0f,0f,0f ) ;
  }

  @Test
  public void test52() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,17.31372f,-17.315779f,0f,0f,0f,1,0.6286562f,0.37147176f,-0.60054076f,0f,0f,0f ) ;
  }

  @Test
  public void test53() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,38.492863f,-29.770784f,-61.868824f,-193.0f,-899.0f,996.0f,2,-0.36629504f,-0.804163f,0.46813443f,0f,0f,0f ) ;
  }

  @Test
  public void test54() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,-39.368736f,75.68488f,11.220482f,-1194.0f,-1382.0f,1756.0f,2,72.22822f,26.948229f,71.64837f,0f,0f,0f ) ;
  }

  @Test
  public void test55() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,65.41909f,-77.43326f,-85.72701f,0f,0f,0f,1,-0.6771639f,-0.686979f,0.26364535f,0f,0f,0f ) ;
  }

  @Test
  public void test56() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,-72.17304f,100.0f,-94.01629f,0f,0f,0f,1,-44.519527f,-100.0f,44.519527f,0f,0f,0f ) ;
  }

  @Test
  public void test57() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,8.53071f,-100.0f,88.675476f,244.0f,929.0f,-2181.0f,1,0.99367225f,-0.0140491035f,-0.11143657f,0f,0f,0f ) ;
  }

  @Test
  public void test58() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,9.683099f,-80.07489f,23.68057f,-926.0f,-1273.0f,-354.0f,1,-0.6970382f,-0.072343946f,-0.0040059853f,0f,0f,0f ) ;
  }

  @Test
  public void test59() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,-100.0f,0f,0f,0f,0f,0f,-57.791435f,21.690807f,-100.0f,0f,0f,0f,1,37.616383f,-100.0f,36.280514f,0f,0f,0f ) ;
  }

  @Test
  public void test60() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-100.0f,0f,2.569067f,0f,0f,0f,0f,0f,-36.59859f,-6.56346f,44.742756f,0f,0f,0f,1,0.43600768f,0.14184777f,-0.74837476f,0f,0f,0f ) ;
  }

  @Test
  public void test61() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-100.0f,0f,-62.37648f,0f,0f,0f,0f,0f,-100.0f,-15.473401f,31.19943f,0f,0f,0f,1,100.0f,-29.53009f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test62() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-100.3871f,0f,0.0f,0f,0f,0f,0f,0f,-4.166259f,100.0f,-30.581318f,0f,0f,0f,1,0.3190734f,-0.7957907f,-0.08021197f,0f,0f,0f ) ;
  }

  @Test
  public void test63() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-1012.0f,0f,407.0f,0f,0f,0f,0f,0f,74.0f,-115.0f,303.0f,1073.0f,-1131.0f,-693.0f,-16,111.469246f,-69.396545f,-158.42506f,0f,0f,0f ) ;
  }

  @Test
  public void test64() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,1017.0f,0f,-196.0f,0f,0f,0f,0f,0f,-406.0f,548.0f,-898.0f,1145.0f,416.0f,-677.0f,1,-0.037955467f,0.16073368f,0.8568384f,0f,0f,0f ) ;
  }

  @Test
  public void test65() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,105.60543f,0f,0f,0f,0f,0f,0f,0f,-69.78537f,-100.0f,20.516174f,98.0f,-879.0f,-273.0f,1,25.095581f,22.884441f,64.50654f,0f,0f,0f ) ;
  }

  @Test
  public void test66() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-1082.0f,0f,885.0f,0f,0f,0f,0f,0f,-947.0f,-286.0f,540.0f,-311.0f,-300.0f,-1477.0f,3,-32.136917f,16.696358f,-73.44784f,0f,0f,0f ) ;
  }

  @Test
  public void test67() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-1.0f,0f,1149.0f,0f,0f,0f,0f,0f,1800.0f,966.0f,-343.0f,-513.0f,609.0f,-977.0f,2,-73.11736f,52.58171f,46.29845f,0f,0f,0f ) ;
  }

  @Test
  public void test68() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-1.0f,0f,83.0f,0f,0f,0f,0f,0f,-434.0f,170.0f,-967.0f,399.0f,1283.0f,-1157.0f,6,-17.084158f,-62.279785f,1.1308615f,0f,0f,0f ) ;
  }

  @Test
  public void test69() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,1.1492627f,0f,31.219944f,0f,0f,0f,0f,0f,-49.474365f,-98.81673f,-66.82373f,0f,0f,0f,1,-0.12368218f,-0.00811981f,0.78434134f,0f,0f,0f ) ;
  }

  @Test
  public void test70() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-1169.0f,0f,277.0f,0f,0f,0f,0f,0f,483.0f,594.0f,657.0f,1691.0f,-736.0f,370.0f,-2,-1.4134569f,-0.07065559f,-2.5884254f,0f,0f,0f ) ;
  }

  @Test
  public void test71() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,1174.0f,-83.0f,-1977.0f,0f,0f,0f,0f,0f,5.0f,622.0f,730.0f,144.0f,-584.0f,652.0f,5,-100.0f,-100.0f,-71.86807f,24.950977f,0f,0f ) ;
  }

  @Test
  public void test72() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-1206.0f,0f,361.0f,0f,0f,0f,0f,0f,-88.0f,542.0f,-949.0f,-2313.0f,-149.0f,-1185.0f,-4,-71.81008f,-100.0f,67.46351f,0f,0f,0f ) ;
  }

  @Test
  public void test73() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,1228.0f,0f,742.0f,0f,0f,0f,0f,0f,1247.0f,1433.0f,-51.0f,-1088.0f,950.0f,108.0f,5,46.447086f,-37.003452f,96.005424f,0f,0f,0f ) ;
  }

  @Test
  public void test74() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,12.389082f,0f,0f,0f,0f,0f,0f,0f,81.659355f,100.0f,30.513876f,0f,0f,0f,1,-0.60606694f,0.25950125f,0.46629512f,0f,0f,0f ) ;
  }

  @Test
  public void test75() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-13.0f,0f,1151.0f,0f,0f,0f,0f,0f,-1057.0f,407.0f,-382.0f,-2151.0f,-1300.0f,1116.0f,-3,2.8257356f,1.2038608f,0.23929095f,0f,0f,0f ) ;
  }

  @Test
  public void test76() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,1318.0f,0f,883.0f,0f,0f,0f,0f,0f,1137.0f,281.0f,71.0f,761.0f,954.0f,579.0f,1,-143.24025f,47.580044f,-86.65475f,0f,0f,0f ) ;
  }

  @Test
  public void test77() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,142.0f,0f,-675.0f,0f,0f,0f,0f,0f,-535.0f,371.0f,-1417.0f,-881.0f,1191.0f,-399.0f,1,75.03784f,-66.331184f,-17.284063f,0f,0f,0f ) ;
  }

  @Test
  public void test78() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,1.4222691E-6f,0f,0f,0f,0f,0f,0f,0f,-18.944761f,-63.42292f,80.32088f,-259.0f,-837.0f,-722.0f,1,1.6143519f,-1.5886573f,-4.127269f,0f,0f,0f ) ;
  }

  @Test
  public void test79() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-1456.0f,0f,2644.0f,0f,0f,0f,0f,0f,-108.0f,-513.0f,638.0f,-1414.0f,1126.0f,848.0f,5,0.62472093f,89.242836f,43.13718f,0f,0f,0f ) ;
  }

  @Test
  public void test80() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-1526.0f,0f,354.0f,0f,0f,0f,0f,0f,823.0f,-1557.0f,-1609.0f,-778.0f,-657.0f,-994.0f,1,-88.34884f,58.054386f,5.5952215f,0f,0f,0f ) ;
  }

  @Test
  public void test81() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,15.448889f,0f,0f,0f,0f,0f,0f,0f,-56.03006f,-15.755148f,38.37296f,-730.0f,-1027.0f,952.0f,1,-0.13921653f,-0.4686716f,-0.39570314f,0f,0f,0f ) ;
  }

  @Test
  public void test82() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,15.78174f,0f,0f,0f,0f,0f,0f,0f,18.749033f,83.19833f,-53.964855f,-602.0f,745.0f,1025.0f,2,-100.0f,-6.783f,13.876333f,0f,0f,0f ) ;
  }

  @Test
  public void test83() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-1634.0f,0f,923.0f,0f,0f,0f,0f,0f,465.0f,-1089.0f,-702.0f,-1650.0f,-762.0f,-1221.0f,2,-100.0f,82.768616f,70.976555f,0f,0f,0f ) ;
  }

  @Test
  public void test84() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,1643.0f,0f,0.0f,0f,0f,0f,0f,0f,-1373.0f,409.0f,-129.0f,-156.0f,-127.0f,-686.0f,1,185.90749f,-132.76562f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test85() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,16.625614f,0f,0f,0f,0f,-52.211887f,54.42091f,25.13602f,-100.0f,77.11436f,-80.39128f,0f,0f,0f,2,-53.061115f,54.13449f,25.447765f,0f,0f,0f ) ;
  }

  @Test
  public void test86() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,170.0f,0f,88.0f,0f,0f,0f,0f,0f,457.0f,758.0f,-407.0f,720.0f,-826.0f,-730.0f,3,-100.0f,29.9851f,93.37651f,0f,0f,0f ) ;
  }

  @Test
  public void test87() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,1707.0f,0f,96.0f,0f,0f,0f,0f,0f,169.0f,889.0f,1699.0f,-464.0f,1149.0f,537.0f,-1,-0.30338612f,-0.9040398f,-0.30111274f,0f,0f,0f ) ;
  }

  @Test
  public void test88() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,1748.0f,0f,3164.0f,0f,0f,0f,0f,0f,-41.0f,47.0f,-103.0f,-648.0f,918.0f,688.0f,3,55.70048f,100.0f,23.573877f,0f,0f,0f ) ;
  }

  @Test
  public void test89() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,180.0f,0f,0.0f,0f,0f,0f,0f,0f,-743.0f,-191.0f,-553.0f,646.0f,-1083.0f,-49.0f,3,35.443653f,-82.16872f,17.720808f,0f,0f,0f ) ;
  }

  @Test
  public void test90() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,192.0f,-514.0f,-2466.0f,0f,0f,0f,0f,0f,-1637.0f,11.0f,-2129.0f,-1295.0f,-127.0f,357.0f,4,0.81039625f,-0.3028366f,-0.50154555f,100.0f,0f,0f ) ;
  }

  @Test
  public void test91() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-19.894035f,0f,0f,0f,0f,0f,0f,0f,-91.80496f,100.0f,94.09295f,0f,0f,0f,1,0.7787933f,-0.3578938f,0.5151632f,0f,0f,0f ) ;
  }

  @Test
  public void test92() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,207.0f,0f,0.0f,0f,0f,0f,0f,0f,-318.0f,1694.0f,-480.0f,-872.0f,121.0f,-387.0f,3,30.637072f,-108.78596f,54.282288f,0f,0f,0f ) ;
  }

  @Test
  public void test93() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-2.0f,0f,808.0f,0f,0f,0f,0f,0f,893.0f,1375.0f,-591.0f,-286.0f,20.0f,-387.0f,-6,-6.4133835f,4.154323f,13.930338f,0f,0f,0f ) ;
  }

  @Test
  public void test94() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,21.673672f,0f,0f,0f,0f,0f,0f,0f,-20.968172f,-8.595927f,-8.630318f,1008.0f,392.0f,-821.0f,1,12.700882f,-88.0334f,67.482086f,0f,0f,0f ) ;
  }

  @Test
  public void test95() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,218.0f,-587.0f,0.0f,0f,0f,0f,0f,0f,-997.0f,1994.0f,-296.0f,-759.0f,179.0f,-569.0f,5,-81.07518f,-59.44628f,79.7109f,-65.40011f,0f,0f ) ;
  }

  @Test
  public void test96() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,218.30507f,0f,0f,0f,0f,0f,0f,0f,25.299454f,15.079551f,60.049572f,115.0f,1471.0f,-165.0f,3,1.0479282f,-7.186859f,1.3575225f,0f,0f,0f ) ;
  }

  @Test
  public void test97() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,2184.0f,0f,-362.0f,0f,0f,0f,0f,0f,-693.0f,-1060.0f,2002.0f,2748.0f,365.0f,-3068.0f,2,-0.84670895f,1.8734175f,0.27260295f,0f,0f,0f ) ;
  }

  @Test
  public void test98() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-22.697989f,0f,0f,0f,0f,48.471302f,15.502554f,-100.0f,95.608665f,39.2842f,-100.0f,0f,0f,0f,2,48.470802f,15.552247f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test99() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-227.0f,0f,678.0f,0f,0f,35.0f,60.0f,-63.0f,1291.0f,384.0f,-2089.0f,0f,0f,0f,-1,34.721508f,57.9948f,-65.71669f,0f,0f,0f ) ;
  }

  @Test
  public void test100() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-2.2780821f,0f,32.06553f,0f,0f,0f,0f,0f,-17.437798f,-44.1166f,99.92648f,0f,0f,0f,1,0.76902556f,0.4510026f,-0.44264156f,0f,0f,0f ) ;
  }

  @Test
  public void test101() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-2.3197687f,0f,0.0f,0f,0f,0f,0f,0f,62.019382f,32.410152f,-93.37958f,0f,0f,0f,1,7.1458693f,-100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test102() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,28.015093f,0f,20.687916f,0f,0f,0f,0f,0f,-87.019905f,-98.92221f,-46.63373f,0f,0f,0f,1,66.7698f,-37.979248f,61.275078f,0f,0f,0f ) ;
  }

  @Test
  public void test103() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,290.0f,0f,952.0f,0f,0f,0f,0f,0f,-146.0f,99.0f,216.0f,-2785.0f,126.0f,1123.0f,-2,-10.567684f,-33.53261f,-8.764243f,0f,0f,0f ) ;
  }

  @Test
  public void test104() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,29.0f,0f,-1078.0f,0f,0f,0f,0f,0f,-401.0f,624.0f,-965.0f,654.0f,-566.0f,856.0f,1,-22.668756f,37.46474f,112.28399f,0f,0f,0f ) ;
  }

  @Test
  public void test105() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,303.0f,-542.0f,2.0f,0f,0f,0f,0f,0f,-1539.0f,-1076.0f,926.0f,-213.0f,822.0f,-1739.0f,1,6.778575f,-20.338547f,-13.281118f,-3.4887958f,0f,0f ) ;
  }

  @Test
  public void test106() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-306.0f,0f,392.0f,0f,0f,0f,0f,0f,2544.0f,-712.0f,69.0f,146.0f,854.0f,974.0f,2,-6.2364516f,28.194807f,-34.555134f,0f,0f,0f ) ;
  }

  @Test
  public void test107() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,320.0f,-1958.0f,-1.0f,0f,0f,0f,0f,0f,-587.0f,1146.0f,31.0f,-849.0f,1858.0f,797.0f,2,-25.08094f,-57.16903f,-68.104515f,49.070107f,0f,0f ) ;
  }

  @Test
  public void test108() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,368.0f,0f,563.0f,0f,0f,0f,0f,0f,-1460.0f,-387.0f,1364.0f,1234.0f,-291.0f,-712.0f,-3,96.81733f,-71.3171f,-21.554457f,0f,0f,0f ) ;
  }

  @Test
  public void test109() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-37.093372f,0f,-69.88466f,0f,0f,0f,0f,0f,77.2014f,-77.66232f,89.29723f,0f,0f,0f,1,-0.4454819f,0.101876915f,-0.618077f,0f,0f,0f ) ;
  }

  @Test
  public void test110() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-38.43025f,0f,0f,0f,0f,0f,0f,0f,-71.75714f,-83.49123f,-1.6619854f,0f,0f,0f,1,-0.071460776f,0.45313656f,0.01128535f,0f,0f,0f ) ;
  }

  @Test
  public void test111() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,392.0f,0f,58.0f,0f,0f,0f,0f,0f,273.0f,-332.0f,60.0f,683.0f,-353.0f,-1059.0f,2,-73.27377f,72.10994f,-86.932434f,0f,0f,0f ) ;
  }

  @Test
  public void test112() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,394.0f,-871.0f,0.0f,0f,0f,0f,0f,0f,-1150.0f,-338.0f,295.0f,-995.0f,1875.0f,741.0f,6,100.0f,-73.72703f,-58.521767f,150.54169f,0f,0f ) ;
  }

  @Test
  public void test113() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,40.85589f,0f,0f,0f,0f,0f,0f,0f,160.96944f,1.745998f,-62.42232f,-206.0f,479.0f,829.0f,1,-45.81664f,75.01859f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test114() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-4.0f,0f,1053.0f,0f,0f,0f,0f,0f,971.0f,-1670.0f,9.0f,300.0f,174.0f,36.0f,-1,-100.0f,52.253117f,-63.358482f,0f,0f,0f ) ;
  }

  @Test
  public void test115() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-42.0f,0f,457.0f,0f,0f,0f,0f,0f,-1789.0f,194.0f,37.0f,-2684.0f,118.0f,693.0f,-2,81.845726f,20.516888f,77.260895f,0f,0f,0f ) ;
  }

  @Test
  public void test116() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,43.597916f,0f,0f,0f,0f,0f,0f,0f,74.74495f,24.817274f,18.16105f,281.0f,-756.0f,1103.0f,1,-26.105207f,14.924251f,28.349401f,0f,0f,0f ) ;
  }

  @Test
  public void test117() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,446.0f,0f,-665.0f,0f,0f,0f,0f,0f,743.0f,764.0f,-943.0f,652.0f,837.0f,30.0f,1,2.6018302f,-42.50594f,47.386124f,0f,0f,0f ) ;
  }

  @Test
  public void test118() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,44.75413f,0f,0f,0f,0f,0f,0f,0f,40.403267f,-62.260654f,19.763235f,0f,0f,0f,1,-61.177113f,58.967136f,-25.76014f,0f,0f,0f ) ;
  }

  @Test
  public void test119() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-4.5140953f,0f,74.24285f,0f,0f,0f,0f,0f,40.772667f,54.566994f,43.290287f,0f,0f,0f,1,-100.0f,100.0f,-41.101093f,0f,0f,0f ) ;
  }

  @Test
  public void test120() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-46.12139f,0f,0f,0f,0f,0f,0f,0f,38.893124f,26.337257f,44.48793f,0f,0f,0f,1,-45.339886f,52.977337f,-83.402374f,0f,0f,0f ) ;
  }

  @Test
  public void test121() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-47.40686f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,-20.81693f,-46.946426f,0f,0f,0f,1,43.81f,-74.03162f,48.685944f,0f,0f,0f ) ;
  }

  @Test
  public void test122() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-49.045612f,0f,4.061521f,0f,0f,0f,0f,0f,17.32551f,100.0f,-87.62666f,0f,0f,0f,1,-70.12389f,-34.13761f,-12.642855f,0f,0f,0f ) ;
  }

  @Test
  public void test123() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-49.224125f,0f,64.94777f,0f,0f,0f,0f,0f,-100.0f,-57.936554f,-100.0f,0f,0f,0f,1,0.024621308f,0.97793156f,-0.20746969f,0f,0f,0f ) ;
  }

  @Test
  public void test124() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,50.112484f,0f,58.736847f,0f,0f,0f,0f,0f,-36.852024f,-44.524796f,-18.97294f,0f,0f,0f,1,0.7398971f,0.67269504f,0.0058035613f,0f,0f,0f ) ;
  }

  @Test
  public void test125() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-5.3583264f,0f,-39.38784f,0f,0f,0f,0f,0f,94.757965f,98.95641f,-24.8171f,0f,0f,0f,1,-70.19467f,86.57881f,87.21508f,0f,0f,0f ) ;
  }

  @Test
  public void test126() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-54.748894f,0f,-52.25658f,0f,0f,0f,0f,0f,39.934067f,19.910397f,-100.0f,0f,0f,0f,2,0.43335614f,-0.6587412f,0.40979615f,0f,0f,0f ) ;
  }

  @Test
  public void test127() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,54.96653f,0f,0f,0f,0f,0f,0f,0f,-47.114918f,-98.083824f,19.003624f,-865.0f,-238.0f,-429.0f,1,0.88380104f,0.15881607f,0.10561229f,0f,0f,0f ) ;
  }

  @Test
  public void test128() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,56.0f,0f,0f,0f,0f,58.0f,123.0f,98.0f,2076.0f,-650.0f,-297.0f,502.0f,-961.0f,-49.0f,-16,65.59729f,100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test129() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-57.0f,0f,137.0f,0f,0f,0f,0f,0f,611.0f,411.0f,497.0f,1176.0f,113.0f,-1539.0f,4,-100.0f,-18.121191f,30.408848f,0f,0f,0f ) ;
  }

  @Test
  public void test130() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,59.06618f,0f,0f,0f,0f,0f,0f,0f,2.6278312f,7.463548f,-5.215394f,199.0f,-1381.0f,-197.0f,-2,-0.31768745f,-1.4077647f,-0.7222755f,0f,0f,0f ) ;
  }

  @Test
  public void test131() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-60.617634f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,-52.634834f,0f,0f,0f,1,0.74461836f,-0.08334389f,0.5929943f,0f,0f,0f ) ;
  }

  @Test
  public void test132() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-614.0f,0f,-1889.0f,0f,0f,-72.0f,98.0f,2.0f,-924.0f,-1560.0f,724.0f,0f,0f,0f,7,-82.394516f,98.015114f,0.55895674f,0f,0f,0f ) ;
  }

  @Test
  public void test133() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-617.0f,0f,686.0f,0f,0f,0f,0f,0f,-1685.0f,-828.0f,-232.0f,492.0f,900.0f,699.0f,5,0.27760586f,-0.5246643f,0.9137204f,0f,0f,0f ) ;
  }

  @Test
  public void test134() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-62.712948f,0f,105.95324f,0f,0f,0f,0f,0f,62.63584f,-18.762789f,94.21724f,0f,0f,0f,1,0.08864035f,0.7898338f,-0.15235132f,0f,0f,0f ) ;
  }

  @Test
  public void test135() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-65.14863f,0f,0.0f,0f,0f,0f,0f,0f,-96.65755f,77.26381f,-99.99714f,0f,0f,0f,1,0.6465347f,-0.35323325f,0.16005594f,0f,0f,0f ) ;
  }

  @Test
  public void test136() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-654.0f,0f,1481.0f,0f,0f,0f,0f,0f,310.0f,-495.0f,643.0f,-412.0f,1189.0f,732.0f,1,-78.08587f,93.5767f,46.33363f,0f,0f,0f ) ;
  }

  @Test
  public void test137() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-65.57197f,0f,0.0f,0f,0f,0f,0f,0f,-22.825066f,-86.29741f,16.101784f,0f,0f,0f,1,65.1728f,10.594682f,17.868109f,0f,0f,0f ) ;
  }

  @Test
  public void test138() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-68.0f,0f,1168.0f,0f,0f,0f,0f,0f,852.0f,172.0f,1590.0f,1055.0f,-130.0f,1223.0f,1,-78.00014f,15.4555645f,-86.72988f,0f,0f,0f ) ;
  }

  @Test
  public void test139() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,688.0f,0f,0.0f,0f,0f,0f,0f,0f,848.0f,1180.0f,1044.0f,-2257.0f,551.0f,-1061.0f,6,1.5611866f,-74.16179f,-116.34371f,0f,0f,0f ) ;
  }

  @Test
  public void test140() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,71.0f,-119.0f,-2505.0f,0f,0f,0f,0f,0f,1023.0f,1461.0f,-719.0f,-2400.0f,548.0f,314.0f,2,35.158245f,-100.0f,62.593945f,-8.410097f,0f,0f ) ;
  }

  @Test
  public void test141() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,71.25513f,0f,-100.0f,0f,0f,0f,0f,0f,-12.903742f,-100.0f,-100.0f,0f,0f,0f,1,0.7948061f,0.0030914955f,0.6068555f,0f,0f,0f ) ;
  }

  @Test
  public void test142() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,713.0f,-671.0f,-3136.0f,0f,0f,0f,0f,0f,593.0f,652.0f,-20.0f,-672.0f,907.0f,-508.0f,2,-62.644413f,39.53609f,81.033485f,78.6386f,0f,0f ) ;
  }

  @Test
  public void test143() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,71.37362f,0f,0f,0f,0f,0f,0f,0f,7.696323f,90.09626f,-72.49231f,-144.0f,-241.0f,96.0f,1,0.05902451f,-0.28273386f,0.5567157f,0f,0f,0f ) ;
  }

  @Test
  public void test144() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,736.0f,0f,1.0f,0f,0f,0f,0f,0f,1083.0f,1373.0f,-1571.0f,464.0f,637.0f,-92.0f,-8,0.09596275f,-2.6409552f,-0.6178847f,0f,0f,0f ) ;
  }

  @Test
  public void test145() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-74.74618f,0f,76.96885f,0f,0f,0f,0f,0f,-77.27191f,-59.542736f,-91.346375f,0f,0f,0f,1,75.629555f,100.0f,-53.345314f,0f,0f,0f ) ;
  }

  @Test
  public void test146() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,76.893936f,0f,0f,0f,0f,0f,0f,0f,1.9536527f,63.89026f,2.1258771f,572.0f,195.0f,-941.0f,1,-58.88991f,-46.635464f,84.39855f,0f,0f,0f ) ;
  }

  @Test
  public void test147() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,77.87346f,0f,0f,0f,0f,0f,0f,0f,-72.25672f,-100.0f,39.80662f,0f,0f,0f,1,100.0f,148.222f,92.84174f,0f,0f,0f ) ;
  }

  @Test
  public void test148() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-77.878006f,0f,0f,0f,0f,0f,0f,0f,84.76736f,-68.49412f,54.029503f,0f,0f,0f,1,-63.345795f,-19.101425f,44.58457f,0f,0f,0f ) ;
  }

  @Test
  public void test149() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,797.0f,0f,-556.0f,0f,0f,0f,0f,0f,831.0f,798.0f,-823.0f,-1714.0f,-423.0f,-571.0f,2,-100.0f,-6.273921f,-70.45736f,0f,0f,0f ) ;
  }

  @Test
  public void test150() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,798.0f,-1182.0f,-3079.0f,0f,0f,0f,0f,0f,-169.0f,-255.0f,189.0f,-668.0f,153.0f,-28.0f,-12,-0.03552493f,0.63771635f,-0.043507483f,96.902885f,0f,0f ) ;
  }

  @Test
  public void test151() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,8.0f,0f,882.0f,0f,0f,0f,0f,0f,-897.0f,274.0f,-659.0f,-952.0f,-336.0f,-597.0f,1,76.02358f,-96.32757f,86.60181f,0f,0f,0f ) ;
  }

  @Test
  public void test152() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-818.0f,0f,748.0f,0f,0f,0f,0f,0f,-181.0f,803.0f,809.0f,-1525.0f,-491.0f,146.0f,1,-5.9477344f,8.616527f,-92.60823f,0f,0f,0f ) ;
  }

  @Test
  public void test153() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,84.80946f,0f,0f,0f,0f,0f,0f,0f,-39.97461f,70.36701f,-20.911104f,-336.0f,-1366.0f,746.0f,1,0.7219267f,-0.17822574f,-0.636639f,0f,0f,0f ) ;
  }

  @Test
  public void test154() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-868.0f,0f,1458.0f,0f,0f,0f,0f,0f,-1275.0f,84.0f,324.0f,167.0f,-1014.0f,921.0f,12,5.3178225f,0.32542872f,-0.09808664f,0f,0f,0f ) ;
  }

  @Test
  public void test155() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,87.55752f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,78.94821f,100.0f,0f,0f,0f,1,-0.053857554f,0.71630424f,-0.69570655f,0f,0f,0f ) ;
  }

  @Test
  public void test156() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,87.692154f,0f,0f,0f,0f,0f,0f,0f,19.452877f,36.302696f,-18.547554f,-1337.0f,330.0f,1663.0f,-2,-2.2770107f,0.2928743f,-1.8148434f,0f,0f,0f ) ;
  }

  @Test
  public void test157() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,886.0f,0f,601.0f,0f,0f,0f,0f,0f,204.0f,-616.0f,-869.0f,-615.0f,-3767.0f,22.0f,-1,-0.9285506f,-0.28770372f,0.08169205f,0f,0f,0f ) ;
  }

  @Test
  public void test158() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-92.12328f,0f,-46.25718f,0f,0f,0f,0f,0f,-14.062244f,-45.09899f,3.6944668f,0f,0f,0f,1,-57.30655f,47.779045f,34.190746f,0f,0f,0f ) ;
  }

  @Test
  public void test159() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-92.45538f,0f,-68.8918f,0f,0f,0f,0f,0f,62.26155f,-100.0f,100.0f,0f,0f,0f,1,0.0040577846f,0.13174634f,-0.07365928f,0f,0f,0f ) ;
  }

  @Test
  public void test160() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,93.64665f,0f,0.0f,0f,0f,0f,0f,0f,-81.69205f,-40.518864f,-46.568043f,0f,0f,0f,1,78.91013f,87.61464f,-11.867536f,0f,0f,0f ) ;
  }

  @Test
  public void test161() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-94.08088f,0f,0f,0f,0f,0f,0f,0f,-99.10266f,-64.731094f,12.144718f,0f,0f,0f,1,0.25454536f,0.5336501f,0.024842292f,0f,0f,0f ) ;
  }

  @Test
  public void test162() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-95.92256f,0f,-65.48743f,0f,0f,0f,0f,0f,-89.63035f,63.62743f,9.2057295f,0f,0f,0f,1,0.36548287f,0.5173812f,-0.77378225f,0f,0f,0f ) ;
  }

  @Test
  public void test163() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,96.916336f,0f,0f,0f,0f,0f,0f,0f,74.22673f,-100.0f,-47.59461f,0f,0f,0f,1,54.74076f,67.15554f,29.25925f,0f,0f,0f ) ;
  }

  @Test
  public void test164() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,98.573074f,0f,0f,0f,0f,0f,0f,0f,-100.0f,57.796867f,46.526455f,-1451.0f,-2984.0f,558.0f,1,-23.883419f,-11.833361f,-37.01059f,0f,0f,0f ) ;
  }

  @Test
  public void test165() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,98.62395f,0f,0f,0f,0f,0f,0f,0f,10.6518755f,-42.941116f,-13.501286f,238.0f,-2184.0f,641.0f,1,0.9694454f,0.19280612f,0.15166202f,0f,0f,0f ) ;
  }

  @Test
  public void test166() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-988.0f,0f,784.0f,0f,0f,0f,0f,0f,-264.0f,-311.0f,-579.0f,450.0f,-171.0f,100.0f,-2,-51.630325f,-64.33382f,76.63567f,0f,0f,0f ) ;
  }

  @Test
  public void test167() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-9.883192E-7f,0f,-16.21477f,0f,0f,0f,0f,0f,-100.0f,33.02255f,14.779906f,0f,0f,0f,1,-0.10506141f,0.107008696f,-1.3330919f,0f,0f,0f ) ;
  }

  @Test
  public void test168() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,99.7342f,0f,-38.875275f,0f,0f,0f,0f,0f,18.295279f,79.460045f,66.26879f,0f,0f,0f,1,-0.006334562f,-0.69005847f,0.17400697f,0f,0f,0f ) ;
  }

  @Test
  public void test169() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-0.57786965f,0.025344033f,0f,100.0f,0f,0f,0f,0f,0f,-100.0f,-39.33866f,54.71672f,0f,0f,0f,1,0.7545648f,-0.3589265f,-0.5493666f,0f,0f,0f ) ;
  }

  @Test
  public void test170() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-0.8971643f,65.02984f,0f,0f,0f,0f,0f,0f,0f,25.429995f,31.03645f,70.23094f,-1031.0f,-171.0f,405.0f,1,17.194374f,-61.94243f,21.144363f,0f,0f,0f ) ;
  }

  @Test
  public void test171() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,23.220327f,123.595566f,0f,0f,0f,1,-0.26054978f,-0.38896942f,0.15780808f,0f,0f,0f ) ;
  }

  @Test
  public void test172() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,89.3594f,-100.0f,0f,0f,0f,1,-0.032539174f,0.6594888f,-0.23208104f,0f,0f,0f ) ;
  }

  @Test
  public void test173() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,103.137245f,-83.95913f,51.9492f,0f,0f,0f,1,111.07637f,-38.26305f,67.174126f,0f,0f,0f ) ;
  }

  @Test
  public void test174() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-24.746284f,99.99535f,-71.203545f,0f,0f,0f,1,0.98001134f,0.14735201f,-0.1336608f,0f,0f,0f ) ;
  }

  @Test
  public void test175() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,33.718704f,68.73937f,-25.095867f,0f,0f,0f,1,34.165993f,-26.125322f,-25.65384f,0f,0f,0f ) ;
  }

  @Test
  public void test176() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-34.57729f,40.20627f,-5.239007f,0f,0f,0f,1,89.17606f,75.97931f,-5.46323f,0f,0f,0f ) ;
  }

  @Test
  public void test177() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-3.4631627f,-31.079489f,-45.52519f,0f,0f,0f,1,0.54984456f,0.37081638f,-0.7417339f,0f,0f,0f ) ;
  }

  @Test
  public void test178() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-35.389004f,63.474728f,-46.927784f,0f,0f,0f,1,-16.358927f,37.83809f,63.516502f,0f,0f,0f ) ;
  }

  @Test
  public void test179() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,68.63543f,-15.0957155f,-12.047978f,0f,0f,0f,1,70.77467f,-92.172005f,-54.954037f,0f,0f,0f ) ;
  }

  @Test
  public void test180() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-7.515144f,8.59852f,-65.73876f,0f,0f,0f,1,-0.31930348f,0.9473908f,0.022271236f,0f,0f,0f ) ;
  }

  @Test
  public void test181() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-7.7140865f,-64.00304f,-100.0f,0f,0f,0f,1,-63.714314f,-29.134542f,-22.346739f,0f,0f,0f ) ;
  }

  @Test
  public void test182() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,5.112473f,23.910656f,45.672638f,-36.10165f,39.73754f,-62.40784f,0f,0f,0f,2,5.605375f,24.17445f,45.985455f,0f,0f,0f ) ;
  }

  @Test
  public void test183() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.57008106f,0f,0f,0f,0f,0f,-45.965538f,9.660671f,50.997097f,458.0f,-872.0f,578.0f,-1,-0.058259644f,-0.9955597f,0.073937126f,0f,0f,0f ) ;
  }

  @Test
  public void test184() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test185() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.0016757495f,-0.5090665f,-0.8607255f,0f,0f,0f ) ;
  }

  @Test
  public void test186() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.023423437f,-0.0056463536f,0.120925054f,0f,0f,0f ) ;
  }

  @Test
  public void test187() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.08394615f,0.9506739f,0.29861718f,0f,0f,0f ) ;
  }

  @Test
  public void test188() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.11381287f,-0.35435158f,-0.5629361f,0f,0f,0f ) ;
  }

  @Test
  public void test189() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.11514562f,0.01677907f,-0.12247925f,0f,0f,0f ) ;
  }

  @Test
  public void test190() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.1205975f,-0.707838f,0.094171055f,0f,0f,0f ) ;
  }

  @Test
  public void test191() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.12283795f,-0.9778578f,0.16942538f,0f,0f,0f ) ;
  }

  @Test
  public void test192() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.12716794f,-0.88689685f,-0.4441197f,0f,0f,0f ) ;
  }

  @Test
  public void test193() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.13184054f,-0.90148556f,-0.37852576f,0f,0f,0f ) ;
  }

  @Test
  public void test194() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.18317805f,-0.9315872f,0.31399217f,0f,0f,0f ) ;
  }

  @Test
  public void test195() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.19383773f,0.059606086f,0.4995839f,0f,0f,0f ) ;
  }

  @Test
  public void test196() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.20215316f,0.22926469f,0.587823f,0f,0f,0f ) ;
  }

  @Test
  public void test197() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.23279364f,0.10289799f,-0.9670673f,0f,0f,0f ) ;
  }

  @Test
  public void test198() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.29991138f,-0.10900121f,-0.032300495f,0f,0f,0f ) ;
  }

  @Test
  public void test199() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.31763107f,-0.74540895f,-0.34674123f,0f,0f,0f ) ;
  }

  @Test
  public void test200() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.38193372f,-0.92415035f,-0.00853012f,0f,0f,0f ) ;
  }

  @Test
  public void test201() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.406466f,0.41532966f,0.07324525f,0f,0f,0f ) ;
  }

  @Test
  public void test202() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.41275164f,-0.7813336f,-0.18797442f,0f,0f,0f ) ;
  }

  @Test
  public void test203() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.42015728f,0.53561175f,0.7325216f,0f,0f,0f ) ;
  }

  @Test
  public void test204() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.443527f,-0.1344602f,-0.19926591f,0f,0f,0f ) ;
  }

  @Test
  public void test205() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.4436608f,0.039950628f,-0.073160134f,0f,0f,0f ) ;
  }

  @Test
  public void test206() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.53504187f,0.8441236f,0.016154919f,0f,0f,0f ) ;
  }

  @Test
  public void test207() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.6585903f,0.38998815f,-0.64355886f,0f,0f,0f ) ;
  }

  @Test
  public void test208() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.81409633f,0.08231424f,0.08440865f,0f,0f,0f ) ;
  }

  @Test
  public void test209() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.8388578f,0.4443245f,0.31447312f,0f,0f,0f ) ;
  }

  @Test
  public void test210() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.85973793f,0.39741144f,0.06712939f,0f,0f,0f ) ;
  }

  @Test
  public void test211() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.86351055f,0.013283602f,-0.50415576f,0f,0f,0f ) ;
  }

  @Test
  public void test212() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test213() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test214() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-100.0f,-26.023743f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test215() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-128.79475f,-33.024784f,56.064716f,0f,0f,0f ) ;
  }

  @Test
  public void test216() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-15.575644f,-40.458344f,37.112408f,0f,0f,0f ) ;
  }

  @Test
  public void test217() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-19.674053f,-17.937128f,-78.56283f,0f,0f,0f ) ;
  }

  @Test
  public void test218() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,27.831017f,-69.2209f,-38.89966f,0f,0f,0f ) ;
  }

  @Test
  public void test219() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-29.74724f,71.34408f,8.337914f,0f,0f,0f ) ;
  }

  @Test
  public void test220() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-36.192856f,-93.75857f,46.47914f,0f,0f,0f ) ;
  }

  @Test
  public void test221() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-3.9118095E-5f,-1.3284349E-6f,-9.3038565E-5f,0f,0f,0f ) ;
  }

  @Test
  public void test222() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-48.989822f,-10.728214f,43.362034f,0f,0f,0f ) ;
  }

  @Test
  public void test223() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,54.28471f,-85.87442f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test224() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,56.7543f,68.18365f,-79.14413f,0f,0f,0f ) ;
  }

  @Test
  public void test225() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-7.0642507E-12f,1.899648E-11f,-1.1558302E-11f,0f,0f,0f ) ;
  }

  @Test
  public void test226() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,7.624369f,-25.969532f,39.949947f,0f,0f,0f ) ;
  }

  @Test
  public void test227() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,76.96297f,-85.021164f,-51.407948f,0f,0f,0f ) ;
  }

  @Test
  public void test228() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,78.6591f,-10.001302f,42.19466f,0f,0f,0f ) ;
  }

  @Test
  public void test229() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-82.652275f,-51.15278f,43.605167f,0f,0f,0f ) ;
  }

  @Test
  public void test230() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-83.61482f,-66.12541f,-59.718365f,0f,0f,0f ) ;
  }

  @Test
  public void test231() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-88.41964f,75.01186f,20.662306f,0f,0f,0f ) ;
  }

  @Test
  public void test232() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,9.250876E-9f,-6.3525235E-8f,-5.6348745E-6f,0f,0f,0f ) ;
  }

  @Test
  public void test233() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,9.736719f,76.80768f,78.04806f,0f,0f,0f ) ;
  }

  @Test
  public void test234() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0.18396638f,-0.91565824f,0.35738832f,0f,0f,0f ) ;
  }

  @Test
  public void test235() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test236() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,404,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test237() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-45,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test238() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,570,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test239() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,863,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test240() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-3.1095989f,-62.274017f,0f,0f,0f,1,0.1282571f,-0.39412236f,-0.18522994f,0f,0f,0f ) ;
  }

  @Test
  public void test241() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1.3430989f,23.51801f,21.318672f,0f,0f,0f,1,4.3412623f,-9.220943f,9.898716f,0f,0f,0f ) ;
  }

  @Test
  public void test242() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1.4918091f,99.165085f,-9.8561f,0f,0f,0f,1,-7.7402997f,-1.0493091f,-9.385819f,0f,0f,0f ) ;
  }

  @Test
  public void test243() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-18.410069f,-18.504644f,-57.291626f,0f,0f,0f,1,-0.47892055f,-0.7786479f,0.40539193f,0f,0f,0f ) ;
  }

  @Test
  public void test244() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,26.164602f,-65.045685f,0.7345906f,0f,0f,0f,1,-100.0f,-100.0f,-54.322926f,0f,0f,0f ) ;
  }

  @Test
  public void test245() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,29.187502f,39.269028f,100.0f,0f,0f,0f,1,-11.276273f,-19.157736f,10.814319f,0f,0f,0f ) ;
  }

  @Test
  public void test246() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,34.71325f,-100.0f,-100.0f,0f,0f,0f,1,0.37962443f,0.5428063f,0.1604521f,0f,0f,0f ) ;
  }

  @Test
  public void test247() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-39.101852f,4.1970563f,72.66166f,0f,0f,0f,1,62.262093f,-96.90517f,39.10287f,0f,0f,0f ) ;
  }

  @Test
  public void test248() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-40.495495f,-100.0f,-126.580185f,0f,0f,0f,1,42.253834f,-66.94706f,-20.714455f,0f,0f,0f ) ;
  }

  @Test
  public void test249() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-4.616982f,-28.409632f,-100.0f,0f,0f,0f,1,0.35105795f,-0.12844154f,-0.8594489f,0f,0f,0f ) ;
  }

  @Test
  public void test250() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-46.465126f,44.993404f,-8.311202f,0f,0f,0f,1,55.56613f,6.3585324f,-4.816657f,0f,0f,0f ) ;
  }

  @Test
  public void test251() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,46.99285f,42.498566f,25.12926f,0f,0f,0f,1,2.25435f,-61.622417f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test252() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-47.611526f,-90.65278f,-86.127716f,0f,0f,0f,1,-32.626377f,48.82334f,-69.6241f,0f,0f,0f ) ;
  }

  @Test
  public void test253() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-53.224594f,68.123184f,-49.53011f,0f,0f,0f,1,-0.37935928f,-0.7194197f,-0.5818262f,0f,0f,0f ) ;
  }

  @Test
  public void test254() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,5.594359f,0.039320767f,60.916653f,0f,0f,0f,1,0.1889718f,-0.2698058f,-0.8932912f,0f,0f,0f ) ;
  }

  @Test
  public void test255() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-57.410233f,-48.650066f,8.50187f,0f,0f,0f,1,44.26684f,-7.0315394f,-30.541985f,0f,0f,0f ) ;
  }

  @Test
  public void test256() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,7.2738748f,25.70353f,100.0f,0f,0f,0f,1,0.20023055f,-0.1028787f,-0.39455304f,0f,0f,0f ) ;
  }

  @Test
  public void test257() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-80.435905f,80.8361f,0.44638312f,0f,0f,0f,1,-82.83005f,-82.15563f,-47.871925f,0f,0f,0f ) ;
  }

  @Test
  public void test258() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,8.047907f,-7.593822f,24.4604f,0f,0f,0f,1,4.820657f,36.606735f,-94.61221f,0f,0f,0f ) ;
  }

  @Test
  public void test259() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-85.269554f,31.491043f,80.944305f,0f,0f,0f,1,-0.6978039f,-0.29580513f,-0.13788839f,0f,0f,0f ) ;
  }

  @Test
  public void test260() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.99869f,99.957726f,175.88115f,0f,0f,0f,1,-0.1399928f,0.98103666f,0.134049f,0f,0f,0f ) ;
  }

  @Test
  public void test261() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,100.0f,55.122517f,0f,0f,0f,0f,0f,0f,2,-100.0f,100.0f,55.12244f,0f,0f,0f ) ;
  }

  @Test
  public void test262() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-100.0f,8.215758f,0f,0f,0f,0f,0f,0f,2,100.0f,-99.99872f,7.611706f,0f,0f,0f ) ;
  }

  @Test
  public void test263() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,100.0f,86.966385f,0f,0f,0f,0f,0f,0f,2,99.95864f,100.0f,87.14772f,0f,0f,0f ) ;
  }

  @Test
  public void test264() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,32.953537f,-5.39742f,0f,0f,0f,0f,0f,0f,2,100.0f,32.692726f,-5.033726f,0f,0f,0f ) ;
  }

  @Test
  public void test265() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,35.704502f,-100.0f,0f,0f,0f,0f,0f,0f,2,-100.0f,35.704506f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test266() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-12.866238f,12.108967f,12.167429f,0f,0f,0f,0f,0f,0f,2,-12.437681f,12.132414f,12.063444f,0f,0f,0f ) ;
  }

  @Test
  public void test267() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-14.927094f,-5.1816f,2.476186f,0f,0f,0f,0f,0f,0f,2,-14.698451f,-6.1549435f,2.4942255f,0f,0f,0f ) ;
  }

  @Test
  public void test268() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-15.470598f,77.15233f,-86.61259f,0f,0f,0f,0f,0f,0f,2,-103.16741f,45.761536f,2.5713189f,0f,0f,0f ) ;
  }

  @Test
  public void test269() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,17.734882f,98.31328f,99.996414f,-32.069405f,-100.0f,100.0f,0f,0f,0f,2,17.546116f,98.835434f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test270() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,28.889395f,10.339051f,-12.786371f,97.54476f,26.732319f,-72.88652f,0f,0f,0f,2,34.62668f,11.567517f,-4.657548f,0f,0f,0f ) ;
  }

  @Test
  public void test271() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,32.882313f,-99.94789f,100.0f,0f,0f,0f,0f,0f,0f,2,32.881134f,-99.92797f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test272() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,44.8693f,100.0f,3.1618676f,0f,0f,0f,0f,0f,0f,2,43.987125f,100.0f,3.319196f,0f,0f,0f ) ;
  }

  @Test
  public void test273() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-53.239902f,12.929016f,16.124205f,87.066574f,98.346405f,100.0f,0f,0f,0f,2,-53.295055f,12.746052f,16.881367f,0f,0f,0f ) ;
  }

  @Test
  public void test274() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-72.54889f,33.7053f,6.405198f,0f,0f,0f,0f,0f,0f,2,-72.588905f,34.502785f,6.5554886f,0f,0f,0f ) ;
  }

  @Test
  public void test275() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-78.777306f,21.379694f,28.255917f,0f,0f,0f,0f,0f,0f,4,-78.77568f,21.379337f,28.25735f,0f,0f,0f ) ;
  }

  @Test
  public void test276() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-88.33476f,94.58293f,70.2163f,0f,0f,0f,0f,0f,0f,-1,-5.767081f,37.667015f,34.986526f,0f,0f,0f ) ;
  }

  @Test
  public void test277() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.73255f,-100.0f,-99.94278f,0f,0f,0f,0f,0f,0f,2,-100.0f,-100.0f,-99.9973f,0f,0f,0f ) ;
  }

  @Test
  public void test278() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,100.0f,24.575893f,99.9103f,-1723.0f,2182.0f,-274.0f,1,0.85311383f,-0.3805427f,0.0368184f,0f,0f,0f ) ;
  }

  @Test
  public void test279() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,100.0f,-27.97021f,-15.197202f,129.0f,-1259.0f,1140.0f,2,-0.077410646f,-0.6752873f,0.73348117f,0f,0f,0f ) ;
  }

  @Test
  public void test280() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-100.0f,40.782074f,47.833572f,170.0f,-1016.0f,-250.0f,1,-0.75604606f,-0.32433036f,-0.10224664f,0f,0f,0f ) ;
  }

  @Test
  public void test281() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,100.0f,43.016354f,-100.0f,2275.0f,1924.0f,588.0f,1,-0.023723032f,0.16543488f,-0.046325374f,0f,0f,0f ) ;
  }

  @Test
  public void test282() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,10.69986f,64.16508f,-13.617665f,-458.0f,599.0f,-360.0f,1,46.265263f,-17.634785f,-46.741165f,0f,0f,0f ) ;
  }

  @Test
  public void test283() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-1.6432463f,-94.74556f,49.749268f,-715.0f,293.0f,557.0f,2,-1.1082357f,-0.6506008f,-1.1163459f,0f,0f,0f ) ;
  }

  @Test
  public void test284() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-16.492153f,-32.387817f,-100.0f,0f,0f,0f,1,-100.0f,100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test285() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-1.696361f,34.381157f,-34.248188f,-87.0f,-306.0f,309.0f,1,0.8129157f,-0.39038533f,-0.4321659f,0f,0f,0f ) ;
  }

  @Test
  public void test286() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,-18.91958f,73.4242f,100.0f,0f,0f,0f,1,100.0f,100.0f,-54.504623f,0f,0f,0f ) ;
  }

  @Test
  public void test287() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-30.7993f,-33.8677f,-19.717865f,-115.0f,1338.0f,-2122.0f,1,-1.86919f,0.09716011f,-0.015138438f,0f,0f,0f ) ;
  }

  @Test
  public void test288() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-32.326485f,54.36858f,-58.10658f,-261.0f,696.0f,796.0f,1,-62.182198f,-37.04109f,-0.064357124f,0f,0f,0f ) ;
  }

  @Test
  public void test289() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,32.942757f,34.431168f,80.2584f,-549.0f,460.0f,28.0f,2,63.632362f,99.93097f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test290() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-37.92579f,17.913439f,38.953835f,0f,0f,0f,1,0.032813508f,0.20717192f,0.36439335f,0f,0f,0f ) ;
  }

  @Test
  public void test291() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,38.401062f,-13.7579155f,17.321438f,487.0f,2360.0f,795.0f,1,60.087757f,41.81519f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test292() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-3.9630344f,-47.65817f,-4.4082923f,1655.0f,-2614.0f,-651.0f,1,0.67226744f,0.0013467175f,-0.74030715f,0f,0f,0f ) ;
  }

  @Test
  public void test293() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,39.951866f,23.407673f,25.805815f,-482.0f,2770.0f,837.0f,1,0.34222126f,-0.06005074f,-0.057672154f,0f,0f,0f ) ;
  }

  @Test
  public void test294() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-42.04876f,100.0f,100.0f,986.0f,-668.0f,1348.0f,1,-100.0f,100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test295() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-54.230724f,4.050751f,90.98934f,498.0f,852.0f,261.0f,1,-81.219284f,-91.010124f,-44.35598f,0f,0f,0f ) ;
  }

  @Test
  public void test296() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-6.2663193f,-39.89295f,-83.054436f,2016.0f,264.0f,-279.0f,3,-68.80097f,22.647667f,-5.6872745f,0f,0f,0f ) ;
  }

  @Test
  public void test297() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,63.8735f,-25.669302f,30.820597f,810.0f,1613.0f,-318.0f,-1,1.6540812f,-0.34776002f,-1.0710088f,0f,0f,0f ) ;
  }

  @Test
  public void test298() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-64.333374f,-32.924892f,-77.8685f,-244.0f,559.0f,-1219.0f,1,18.184381f,-42.519283f,-98.96411f,0f,0f,0f ) ;
  }

  @Test
  public void test299() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,77.78443f,-40.089783f,-89.111786f,-161.0f,-977.0f,299.0f,2,2.6748354f,-3.336649f,-0.9936207f,0f,0f,0f ) ;
  }

  @Test
  public void test300() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,92.68295f,39.339096f,42.904316f,-908.0f,1342.0f,731.0f,1,74.56546f,23.355288f,-16.620752f,0f,0f,0f ) ;
  }

  @Test
  public void test301() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-93.570366f,-2.236752f,-100.0f,-420.0f,581.0f,380.0f,1,11.321695f,-100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test302() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-95.640274f,-8.318787f,-99.91006f,-277.0f,371.0f,-592.0f,1,-0.038094252f,-0.023016952f,0.0016885876f,0f,0f,0f ) ;
  }

  @Test
  public void test303() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,99.47819f,100.0f,2.8251257f,0f,0f,0f,1,0.22049592f,0.018682523f,-0.97520894f,0f,0f,0f ) ;
  }

  @Test
  public void test304() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,10.706359f,0f,0f,0f,0f,0f,82.73295f,100.0f,81.5259f,-758.0f,930.0f,751.0f,1,100.0f,-4.931353f,-95.431755f,0f,0f,0f ) ;
  }

  @Test
  public void test305() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,114.99113f,0f,0f,0f,0f,0f,-40.243073f,-4.2432823f,-49.13985f,-499.0f,1254.0f,300.0f,1,-62.830364f,-134.44656f,-98.38091f,0f,0f,0f ) ;
  }

  @Test
  public void test306() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,11.544036f,0f,0f,0f,0f,0f,54.420277f,-18.737709f,-79.100174f,-659.0f,-1019.0f,-212.0f,-4,1.9081825f,81.584816f,-18.013472f,0f,0f,0f ) ;
  }

  @Test
  public void test307() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,1.2409409f,0f,0f,0f,0f,0f,-22.302261f,30.304806f,34.913605f,-11.0f,-379.0f,322.0f,1,55.31381f,97.26324f,-49.090332f,0f,0f,0f ) ;
  }

  @Test
  public void test308() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,14.021673f,0f,0f,0f,0f,0f,73.42151f,-64.33221f,-79.51434f,0f,0f,0f,1,29.253023f,-81.03825f,92.576645f,0f,0f,0f ) ;
  }

  @Test
  public void test309() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,15.397886f,0f,0f,0f,0f,0f,12.103655f,-62.031918f,-100.0f,199.0f,-419.0f,284.0f,1,-76.50136f,28.177784f,-33.946144f,0f,0f,0f ) ;
  }

  @Test
  public void test310() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,16.788263f,0f,0f,0f,0f,0f,115.02994f,60.35209f,-71.98194f,0f,0f,0f,1,0.43922696f,0.47252676f,-0.7517159f,0f,0f,0f ) ;
  }

  @Test
  public void test311() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,17.32571f,0f,0f,0f,0f,0f,-37.3557f,36.160595f,53.55403f,-1292.0f,-1551.0f,1226.0f,1,100.0f,0.6793048f,69.29462f,0f,0f,0f ) ;
  }

  @Test
  public void test312() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,174.6383f,0f,0f,0f,0f,0f,-35.13648f,67.31005f,-1.3288292f,-1178.0f,-195.0f,-1130.0f,-2,-55.13766f,-30.496365f,-86.81968f,0f,0f,0f ) ;
  }

  @Test
  public void test313() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,18.478697f,0f,0f,0f,0f,0f,11.305944f,-90.37046f,-48.01987f,-614.0f,505.0f,-1095.0f,1,46.60112f,29.844437f,-85.27727f,0f,0f,0f ) ;
  }

  @Test
  public void test314() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,20.017952f,0f,0f,0f,0f,0f,-96.50085f,100.0f,-20.575026f,872.0f,846.0f,-1615.0f,1,8.630411f,-9.284453f,-85.60317f,0f,0f,0f ) ;
  }

  @Test
  public void test315() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,20.021042f,0f,0f,0f,0f,0f,-6.917857f,-45.04569f,-27.049252f,2086.0f,-987.0f,1110.0f,1,-38.191006f,28.227692f,-37.240807f,0f,0f,0f ) ;
  }

  @Test
  public void test316() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,217.48994f,0f,0f,0f,0f,0f,111.34463f,91.69436f,-40.101055f,942.0f,289.0f,-1710.0f,1,-13.139293f,77.1224f,-39.240814f,0f,0f,0f ) ;
  }

  @Test
  public void test317() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,22.007837f,0f,0f,0f,0f,0f,100.0f,12.052204f,99.76652f,0f,0f,0f,1,-0.021016404f,0.99485385f,-0.09911683f,0f,0f,0f ) ;
  }

  @Test
  public void test318() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,22.22103f,0f,0f,0f,0f,0f,-11.495133f,-47.79217f,22.015715f,-345.0f,460.0f,819.0f,1,14.881278f,-42.786243f,-85.11126f,0f,0f,0f ) ;
  }

  @Test
  public void test319() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,22.920568f,0f,0f,0f,0f,0f,38.753334f,-42.215004f,-28.298912f,-775.0f,-751.0f,59.0f,-2,-93.971085f,-57.68201f,-42.639317f,0f,0f,0f ) ;
  }

  @Test
  public void test320() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,24.226643f,0f,0f,0f,0f,0f,-92.3583f,78.380936f,98.31852f,-1088.0f,-852.0f,1206.0f,1,-29.477072f,79.56027f,-91.116714f,0f,0f,0f ) ;
  }

  @Test
  public void test321() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,250.49554f,0f,0f,0f,0f,0f,-67.40495f,-64.951935f,78.57242f,-942.0f,-1620.0f,1165.0f,-1,16.392433f,103.989494f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test322() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,251.85866f,0f,0f,0f,0f,0f,-9.964717f,69.65495f,-13.120581f,1356.0f,453.0f,-541.0f,1,31.13477f,61.54237f,-71.04099f,0f,0f,0f ) ;
  }

  @Test
  public void test323() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.26463f,0f,0f,0f,0f,0f,-204.23848f,100.0f,-76.1555f,-1776.0f,-154.0f,-1230.0f,1,-100.0f,-100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test324() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.05832f,0f,0f,0f,0f,0f,6.4041677f,41.12229f,-86.80867f,-2897.0f,2127.0f,-721.0f,-4,-23.946169f,78.0781f,35.165955f,0f,0f,0f ) ;
  }

  @Test
  public void test325() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.41055f,0f,0f,0f,0f,0f,-42.268097f,25.423553f,91.36918f,-929.0f,-875.0f,721.0f,1,-72.40113f,-24.80277f,-4.954758f,0f,0f,0f ) ;
  }

  @Test
  public void test326() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.47272f,0f,0f,0f,0f,0f,-14.375277f,0.87378246f,85.49088f,116.0f,-334.0f,817.0f,2,93.16787f,-87.76092f,26.09383f,0f,0f,0f ) ;
  }

  @Test
  public void test327() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.57875f,0f,0f,0f,0f,0f,10.852186f,-9.573538f,10.355573f,1405.0f,-989.0f,566.0f,1,67.5934f,78.1492f,1.4248731f,0f,0f,0f ) ;
  }

  @Test
  public void test328() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.61844f,0f,0f,0f,0f,0f,-55.19581f,87.054344f,25.229343f,-631.0f,1151.0f,-383.0f,1,-68.36309f,130.6123f,-49.710888f,0f,0f,0f ) ;
  }

  @Test
  public void test329() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.71082f,0f,0f,0f,0f,0f,124.541595f,-34.94648f,-8.757412f,-81.0f,-2198.0f,-811.0f,1,42.87575f,-69.62267f,63.144485f,0f,0f,0f ) ;
  }

  @Test
  public void test330() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.83714f,0f,0f,0f,0f,0f,109.91768f,-20.229824f,128.0668f,83.0f,239.0f,757.0f,1,-14.603551f,-65.008064f,157.88449f,0f,0f,0f ) ;
  }

  @Test
  public void test331() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.90407f,0f,0f,0f,0f,0f,-95.98556f,100.0f,23.713556f,-1746.0f,189.0f,367.0f,1,-100.0f,17.002823f,-4.6009274f,0f,0f,0f ) ;
  }

  @Test
  public void test332() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.94731f,0f,0f,0f,0f,0f,-20.839725f,39.500103f,39.349693f,-38.0f,-323.0f,1944.0f,1,37.372547f,-14.424524f,34.380764f,0f,0f,0f ) ;
  }

  @Test
  public void test333() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.9786f,0f,0f,0f,0f,0f,18.333845f,-85.58735f,67.83308f,-181.0f,-994.0f,341.0f,1,12.692181f,-27.544289f,3.19102f,0f,0f,0f ) ;
  }

  @Test
  public void test334() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.0787f,0f,0f,0f,0f,0f,-100.0f,181.47015f,104.72671f,478.0f,1131.0f,-544.0f,1,135.36813f,54.038822f,156.97368f,0f,0f,0f ) ;
  }

  @Test
  public void test335() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.09697f,0f,0f,0f,0f,0f,-100.0f,100.0f,-100.0f,-125.0f,1671.0f,792.0f,1,72.33875f,100.0f,-27.923615f,0f,0f,0f ) ;
  }

  @Test
  public void test336() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.10016f,0f,0f,0f,0f,0f,-135.5032f,-112.9502f,76.01389f,231.0f,-2020.0f,1165.0f,1,-140.29031f,68.34044f,-4.946539f,0f,0f,0f ) ;
  }

  @Test
  public void test337() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.16434f,0f,0f,0f,0f,0f,173.4169f,100.34045f,-53.38797f,903.0f,1381.0f,218.0f,1,-17.113052f,-9.147904f,-131.35188f,0f,0f,0f ) ;
  }

  @Test
  public void test338() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.40953f,0f,0f,0f,0f,0f,150.16032f,-59.809265f,-41.63226f,1568.0f,-836.0f,31.0f,1,54.488205f,7.7647386f,-43.774002f,0f,0f,0f ) ;
  }

  @Test
  public void test339() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,256.74014f,0f,0f,0f,0f,0f,-19.786375f,-33.9386f,-26.186386f,-2579.0f,-412.0f,1001.0f,1,-144.99689f,138.69846f,-70.22759f,0f,0f,0f ) ;
  }

  @Test
  public void test340() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,259.59018f,0f,0f,0f,0f,0f,-102.283035f,100.0f,-124.34796f,-1117.0f,-840.0f,-2383.0f,1,-100.0f,24.704617f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test341() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,269.95255f,0f,0f,0f,0f,0f,18.262632f,126.932724f,98.441666f,-1006.0f,1214.0f,976.0f,1,0.7289286f,87.62824f,93.02425f,0f,0f,0f ) ;
  }

  @Test
  public void test342() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,27.112154f,0f,0f,0f,0f,0f,49.963955f,-35.865204f,-35.585373f,123.0f,-675.0f,853.0f,1,20.924112f,-100.0f,71.46064f,0f,0f,0f ) ;
  }

  @Test
  public void test343() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,27.337881f,0f,0f,0f,0f,0f,99.9676f,-100.0f,-100.0f,0f,0f,0f,1,0.08233499f,-0.79034436f,-0.6071052f,0f,0f,0f ) ;
  }

  @Test
  public void test344() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,27.714874f,0f,0f,0f,0f,0f,4.1637554f,-44.087566f,14.362846f,520.0f,180.0f,402.0f,-1,-34.745384f,-24.228748f,-64.298904f,0f,0f,0f ) ;
  }

  @Test
  public void test345() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,28.145432f,0f,0f,0f,0f,0f,22.93814f,37.018665f,-125.12547f,-450.0f,-409.0f,-479.0f,1,-49.552135f,-37.367157f,-63.72124f,0f,0f,0f ) ;
  }

  @Test
  public void test346() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,28.147614f,0f,0f,0f,0f,0f,45.098946f,-29.066126f,-2.8127227f,-43.0f,-265.0f,2049.0f,2,-0.10924169f,-2.0984383f,-1.0043585f,0f,0f,0f ) ;
  }

  @Test
  public void test347() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,28.441292f,0f,0f,0f,0f,0f,32.210323f,100.0f,62.83394f,151.0f,-45.0f,-135.0f,1,-0.40349644f,0.89014465f,-0.21173838f,0f,0f,0f ) ;
  }

  @Test
  public void test348() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,29.55769f,0f,0f,0f,0f,0f,91.109856f,-60.569355f,-45.39474f,55.0f,-67.0f,98.0f,1,52.19986f,-45.02601f,54.88621f,0f,0f,0f ) ;
  }

  @Test
  public void test349() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,295.86105f,0f,0f,0f,0f,0f,55.155674f,-71.41295f,100.0f,1179.0f,-373.0f,901.0f,1,17.550478f,100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test350() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-30.79363f,0f,0f,0f,0f,0f,100.0f,98.70687f,-47.15001f,0f,0f,0f,1,0.010774459f,-0.0025436152f,-0.05605318f,0f,0f,0f ) ;
  }

  @Test
  public void test351() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,31.784061f,0f,0f,0f,0f,0f,-20.917067f,-40.68429f,-29.184174f,0f,0f,0f,1,61.229115f,40.253468f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test352() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,317.998f,0f,0f,0f,0f,0f,35.529377f,87.36507f,54.367443f,-507.0f,314.0f,121.0f,1,-91.6239f,93.219475f,169.8859f,0f,0f,0f ) ;
  }

  @Test
  public void test353() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,32.10071f,0f,0f,0f,0f,0f,62.880356f,5.229733f,-23.909372f,1465.0f,284.0f,406.0f,4,23.717995f,-170.49995f,12.885833f,0f,0f,0f ) ;
  }

  @Test
  public void test354() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,32.526894f,0f,0f,0f,0f,0f,-22.136288f,-4.748465f,-21.271418f,-166.0f,962.0f,-42.0f,1,-54.858532f,-67.523285f,28.86604f,0f,0f,0f ) ;
  }

  @Test
  public void test355() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,33.669556f,0f,0f,0f,0f,0f,-35.07835f,69.22895f,36.009285f,-865.0f,1665.0f,675.0f,1,86.07911f,73.014366f,-56.518597f,0f,0f,0f ) ;
  }

  @Test
  public void test356() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,337.4756f,0f,0f,0f,0f,0f,-96.79732f,22.622623f,-10.680519f,152.0f,800.0f,-893.0f,-1,2.2528038f,-35.102093f,-94.73729f,0f,0f,0f ) ;
  }

  @Test
  public void test357() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,3.5527137E-15f,0f,0f,0f,0f,0f,100.0f,-100.0f,54.358063f,-230.0f,1549.0f,173.0f,2,1.1290879f,0.45286193f,-0.098529585f,0f,0f,0f ) ;
  }

  @Test
  public void test358() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-35.938324f,0f,0f,-28.537603f,78.44249f,100.0f,-72.21716f,-67.03391f,127.679634f,0f,0f,0f,2,-28.672432f,78.72672f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test359() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,359.4019f,0f,0f,0f,0f,0f,-13.083505f,-19.973503f,85.543144f,-257.0f,229.0f,562.0f,1,-25.812675f,-33.907963f,61.461952f,0f,0f,0f ) ;
  }

  @Test
  public void test360() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,36.618313f,0f,0f,0f,0f,0f,42.620937f,22.407967f,56.190582f,975.0f,166.0f,-466.0f,1,-76.63869f,79.44798f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test361() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,36.930656f,0f,0f,0f,0f,0f,-49.5267f,-37.299137f,-4.7692804f,-1278.0f,809.0f,-545.0f,1,-35.171772f,58.952053f,-95.80458f,0f,0f,0f ) ;
  }

  @Test
  public void test362() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,37.123726f,0f,0f,0f,0f,0f,92.20615f,-88.94231f,-40.96189f,-388.0f,-370.0f,-70.0f,1,45.735264f,8.132947f,76.398186f,0f,0f,0f ) ;
  }

  @Test
  public void test363() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,41.668728f,0f,0f,0f,0f,0f,-3.108457f,-5.616381f,-4.9072347f,-292.0f,152.0f,11.0f,1,-100.0f,100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test364() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,42.84202f,0f,0f,0f,0f,0f,-100.0f,-100.0f,69.4585f,-596.0f,-710.0f,557.0f,2,-97.81436f,100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test365() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,43.399063f,0f,0f,0f,0f,0f,-90.07858f,1.1861945f,-88.17219f,1764.0f,-556.0f,45.0f,1,-83.7972f,-19.45192f,-15.116102f,0f,0f,0f ) ;
  }

  @Test
  public void test366() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,44.02093f,0f,0f,0f,0f,0f,-73.67495f,2.924255f,-95.29398f,-267.0f,-796.0f,182.0f,1,20.666103f,-0.46148008f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test367() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,47.764072f,0f,0f,0f,0f,0f,10.172402f,-13.830847f,-7.5219903f,1985.0f,930.0f,956.0f,1,0.05609237f,0.27832466f,-1.165033f,0f,0f,0f ) ;
  }

  @Test
  public void test368() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,48.973454f,0f,0f,100.0f,71.66658f,-50.88491f,73.25911f,-99.98467f,86.69324f,0f,0f,0f,3,100.0f,72.19877f,-50.398838f,0f,0f,0f ) ;
  }

  @Test
  public void test369() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,49.20271f,0f,0f,0f,0f,0f,-34.894474f,-71.17452f,-64.85904f,-345.0f,-478.0f,-1389.0f,1,-85.68371f,-39.99888f,89.99191f,0f,0f,0f ) ;
  }

  @Test
  public void test370() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,49.947712f,0f,0f,0f,0f,0f,59.824554f,-70.61689f,-108.82082f,491.0f,-687.0f,-8.0f,1,59.117466f,59.091587f,-8.003623f,0f,0f,0f ) ;
  }

  @Test
  public void test371() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,5.006314f,0f,0f,0f,0f,0f,19.759907f,34.798157f,-84.39003f,555.0f,-725.0f,-169.0f,1,96.56192f,-12.950903f,17.269657f,0f,0f,0f ) ;
  }

  @Test
  public void test372() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,50.977802f,0f,0f,0f,0f,0f,96.96319f,-27.072693f,-97.4712f,-714.0f,871.0f,-2583.0f,2,0.65377194f,-0.65824336f,0.25717023f,0f,0f,0f ) ;
  }

  @Test
  public void test373() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,53.50707f,0f,0f,0f,0f,0f,5.367569f,26.67314f,-33.5556f,1799.0f,993.0f,1077.0f,1,-100.0f,-14.2502575f,-27.323488f,0f,0f,0f ) ;
  }

  @Test
  public void test374() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,55.75427f,0f,0f,0f,0f,0f,41.404255f,100.0f,-95.06472f,-596.0f,-663.0f,-957.0f,1,-79.66263f,100.0f,-61.897045f,0f,0f,0f ) ;
  }

  @Test
  public void test375() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,55.888058f,0f,0f,0f,0f,0f,79.13463f,96.45442f,190.70836f,-828.0f,904.0f,265.0f,1,78.15935f,38.296318f,10.21537f,0f,0f,0f ) ;
  }

  @Test
  public void test376() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,56.44642f,0f,0f,0f,0f,0f,45.86407f,52.317947f,6.147585f,-418.0f,338.0f,242.0f,1,95.49013f,37.200542f,24.907242f,0f,0f,0f ) ;
  }

  @Test
  public void test377() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,56.784397f,0f,0f,0f,0f,0f,-9.714023f,45.696075f,-99.99638f,-967.0f,661.0f,396.0f,1,26.483292f,36.03191f,-16.76975f,0f,0f,0f ) ;
  }

  @Test
  public void test378() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,5.684342E-14f,0f,0f,0f,0f,0f,-63.7337f,-97.434204f,-7.233045f,204.0f,-82.0f,-693.0f,1,0.7009462f,-0.5306422f,0.0693906f,0f,0f,0f ) ;
  }

  @Test
  public void test379() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,59.123047f,0f,0f,0f,0f,0f,-100.0f,-27.061571f,18.804577f,-73.0f,378.0f,772.0f,1,-100.0f,-55.568996f,1.1616488f,0f,0f,0f ) ;
  }

  @Test
  public void test380() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,60.86069f,0f,0f,0f,0f,0f,23.01011f,-17.012888f,58.431892f,814.0f,-655.0f,-506.0f,4,58.08501f,82.76857f,1.2251854f,0f,0f,0f ) ;
  }

  @Test
  public void test381() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,62.40595f,0f,0f,0f,0f,0f,25.912092f,6.6194f,17.543047f,1297.0f,-1893.0f,-1729.0f,1,26.163574f,31.177498f,-50.409103f,0f,0f,0f ) ;
  }

  @Test
  public void test382() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,62.754215f,0f,0f,0f,0f,0f,-100.0f,-31.683548f,-32.43048f,714.0f,-411.0f,7.0f,4,-0.76284045f,0.2935042f,-0.12698174f,0f,0f,0f ) ;
  }

  @Test
  public void test383() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,63.621807f,0f,0f,0f,0f,0f,-37.30592f,65.796036f,58.166496f,-75.0f,-461.0f,528.0f,1,74.42592f,78.9034f,17.450983f,0f,0f,0f ) ;
  }

  @Test
  public void test384() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,64.20896f,0f,0f,0f,0f,0f,57.68919f,33.862778f,59.577415f,942.0f,-1172.0f,-246.0f,1,26.450724f,-40.09485f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test385() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,65.36032f,0f,0f,0f,0f,0f,20.450468f,-36.891537f,40.416706f,0f,0f,0f,1,-97.86651f,-81.775185f,-25.123184f,0f,0f,0f ) ;
  }

  @Test
  public void test386() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,6.547443f,0f,0f,0f,0f,0f,-3.4885712f,-34.286526f,-35.442398f,-53.0f,-816.0f,-1740.0f,1,40.275043f,-69.94216f,-52.28965f,0f,0f,0f ) ;
  }

  @Test
  public void test387() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,66.138405f,0f,0f,0f,0f,0f,-63.476578f,54.729687f,-16.704945f,382.0f,656.0f,631.0f,1,19.120127f,41.381718f,62.92318f,0f,0f,0f ) ;
  }

  @Test
  public void test388() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,67.021835f,0f,0f,0f,0f,0f,15.214681f,-63.26243f,26.094213f,1800.0f,119.0f,-760.0f,1,-33.209698f,-49.234535f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test389() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,68.06275f,0f,0f,0f,0f,0f,17.0536f,5.68297f,70.16959f,-126.0f,-301.0f,55.0f,2,0.019937543f,0.9128224f,0.08436713f,0f,0f,0f ) ;
  }

  @Test
  public void test390() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,69.30752f,0f,0f,0f,0f,0f,21.936457f,-10.866912f,82.90192f,1419.0f,885.0f,92.0f,1,55.99431f,-72.6605f,-17.966627f,0f,0f,0f ) ;
  }

  @Test
  public void test391() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-69.86281f,0f,0f,0f,0f,0f,99.3561f,100.0f,90.64304f,0f,0f,0f,1,100.0f,100.0f,-78.22923f,0f,0f,0f ) ;
  }

  @Test
  public void test392() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,70.30135f,0f,0f,0f,0f,0f,34.873543f,68.01827f,-30.503307f,1227.0f,-1256.0f,-892.0f,1,-70.47597f,8.895791f,-60.736706f,0f,0f,0f ) ;
  }

  @Test
  public void test393() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-70.48412f,0f,0f,0f,0f,0f,-30.360111f,-30.734636f,-15.686463f,0f,0f,0f,1,-100.0f,87.19949f,22.692589f,0f,0f,0f ) ;
  }

  @Test
  public void test394() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,7.1054274E-15f,0f,0f,0f,0f,0f,41.285973f,-1.0647634f,-38.787815f,962.0f,-394.0f,69.0f,1,3.0001113f,4.19427f,-47.10297f,0f,0f,0f ) ;
  }

  @Test
  public void test395() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,7.1054274E-15f,0f,0f,0f,0f,0f,56.09391f,46.51875f,-56.961266f,717.0f,175.0f,849.0f,1,48.512173f,15.851537f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test396() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,71.2811f,0f,0f,0f,0f,0f,100.0f,-26.623701f,33.52628f,-561.0f,345.0f,64.0f,1,77.54527f,-23.07307f,26.98583f,0f,0f,0f ) ;
  }

  @Test
  public void test397() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,71.45941f,0f,0f,0f,0f,0f,33.5837f,8.286099f,-40.781548f,0f,0f,0f,1,127.48392f,21.355835f,-74.919426f,0f,0f,0f ) ;
  }

  @Test
  public void test398() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,71.66053f,0f,0f,0f,0f,0f,6.9099627f,-29.151514f,26.09014f,-863.0f,257.0f,728.0f,1,79.125725f,87.464745f,76.7713f,0f,0f,0f ) ;
  }

  @Test
  public void test399() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,71.978424f,0f,0f,0f,0f,0f,4.1970944f,40.56429f,27.66709f,-1059.0f,965.0f,-1061.0f,1,83.67288f,-54.743614f,67.56955f,0f,0f,0f ) ;
  }

  @Test
  public void test400() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,73.30207f,0f,0f,0f,0f,0f,14.344404f,-30.868244f,31.615997f,231.0f,535.0f,407.0f,1,0.51841605f,-0.5650139f,0.2480764f,0f,0f,0f ) ;
  }

  @Test
  public void test401() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,73.928055f,0f,0f,0f,0f,0f,42.28682f,61.52588f,28.895805f,299.0f,41.0f,127.0f,1,25.712639f,31.585304f,-96.67157f,0f,0f,0f ) ;
  }

  @Test
  public void test402() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,7.478059f,0f,0f,0f,0f,0f,17.618935f,12.650446f,-13.502858f,354.0f,-2141.0f,-1544.0f,1,-8.2015805E-4f,-0.4170085f,-0.731414f,0f,0f,0f ) ;
  }

  @Test
  public void test403() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-75.73407f,0f,0f,0f,0f,0f,53.32949f,13.863242f,64.44461f,0f,0f,0f,1,73.44435f,-56.268024f,13.864062f,0f,0f,0f ) ;
  }

  @Test
  public void test404() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-75.995026f,0f,0f,0f,0f,0f,-94.564514f,38.891457f,88.68642f,0f,0f,0f,1,0.06411868f,-0.46840072f,0.5229405f,0f,0f,0f ) ;
  }

  @Test
  public void test405() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-76.5751f,0f,0f,0f,0f,0f,-4.5417323f,-3.117436f,83.36329f,0f,0f,0f,1,-100.0f,-100.0f,-9.187699f,0f,0f,0f ) ;
  }

  @Test
  public void test406() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,7.979198f,0f,0f,0f,0f,0f,13.877792f,-6.157294f,68.7638f,2023.0f,-1456.0f,298.0f,2,76.74413f,78.05094f,-8.49948f,0f,0f,0f ) ;
  }

  @Test
  public void test407() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,81.49563f,0f,0f,0f,0f,0f,42.30864f,3.657429f,34.62535f,94.0f,-1305.0f,23.0f,1,-20.125994f,-96.66128f,34.80211f,0f,0f,0f ) ;
  }

  @Test
  public void test408() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-8.242232f,0f,0f,0f,0f,0f,47.10181f,-87.13569f,52.535793f,0f,0f,0f,1,-93.24453f,-89.97022f,-3.8184774f,0f,0f,0f ) ;
  }

  @Test
  public void test409() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-82.99209f,0f,0f,0f,0f,0f,-100.0f,-87.844315f,-46.178474f,0f,0f,0f,1,0.18319604f,0.28590485f,-0.94058365f,0f,0f,0f ) ;
  }

  @Test
  public void test410() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,83.0714f,0f,0f,0f,0f,0f,90.70317f,51.35406f,-49.108658f,-642.0f,557.0f,91.0f,1,82.35003f,-49.821632f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test411() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,84.222534f,0f,0f,0f,0f,0f,-51.946003f,-84.08597f,34.288486f,796.0f,968.0f,-194.0f,1,27.9923f,-58.27599f,-85.26901f,0f,0f,0f ) ;
  }

  @Test
  public void test412() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,86.90799f,0f,0f,0f,0f,0f,-39.356606f,-3.2915885f,-4.8372817f,-419.0f,-405.0f,1017.0f,1,-2.5822875f,75.3474f,-30.261324f,0f,0f,0f ) ;
  }

  @Test
  public void test413() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,86.952286f,0f,0f,0f,0f,0f,12.938998f,-33.999413f,17.117384f,1049.0f,-827.0f,769.0f,1,14.3403635f,45.305534f,79.148285f,0f,0f,0f ) ;
  }

  @Test
  public void test414() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,87.422646f,0f,0f,0f,0f,0f,-55.161156f,23.873938f,78.47219f,-554.0f,-808.0f,-1623.0f,1,0.0062530446f,-0.10391873f,0.12425597f,0f,0f,0f ) ;
  }

  @Test
  public void test415() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,88.543945f,0f,0f,0f,0f,0f,-95.82746f,-3.368927f,-9.105439f,-92.0f,1452.0f,431.0f,1,-100.0f,-100.0f,40.077744f,0f,0f,0f ) ;
  }

  @Test
  public void test416() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,8.857571f,0f,0f,0f,0f,0f,-100.0f,-100.0f,8.346214f,-77.0f,766.0f,1306.0f,2,-0.018511092f,1.1700267E-4f,-0.0047646756f,0f,0f,0f ) ;
  }

  @Test
  public void test417() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,8.881784E-16f,0f,0f,0f,0f,0f,-47.151707f,15.950934f,100.0f,-230.0f,-227.0f,82.0f,1,0.068638936f,0.01570729f,1.3919969f,0f,0f,0f ) ;
  }

  @Test
  public void test418() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,89.03833f,0f,0f,0f,0f,0f,100.0f,-92.48279f,21.95689f,1434.0f,-716.0f,-2121.0f,1,76.624214f,100.0f,72.22593f,0f,0f,0f ) ;
  }

  @Test
  public void test419() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,91.7906f,0f,0f,0f,0f,0f,-7.7598953f,-91.39638f,-4.1366014f,-674.0f,25.0f,712.0f,1,1.2741337f,-0.2460149f,-0.04863243f,0f,0f,0f ) ;
  }

  @Test
  public void test420() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,93.82719f,0f,0f,0f,0f,0f,100.0f,-100.0f,-69.5683f,-940.0f,-502.0f,-978.0f,-1,-42.49557f,-85.2995f,-73.94034f,0f,0f,0f ) ;
  }

  @Test
  public void test421() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,9.485719f,0f,0f,0f,0f,0f,100.0f,-19.210333f,-87.95433f,-634.0f,-888.0f,-526.0f,2,-0.45325893f,0.02559167f,-0.8928615f,0f,0f,0f ) ;
  }

  @Test
  public void test422() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,95.60709f,0f,0f,0f,0f,0f,10.233784f,31.606321f,-50.070274f,-1523.0f,-644.0f,-718.0f,1,16.27709f,17.144041f,14.148841f,0f,0f,0f ) ;
  }

  @Test
  public void test423() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,96.08203f,0f,0f,0f,0f,0f,-4.5953445f,62.97609f,-13.365736f,0f,0f,0f,1,-88.94654f,85.4592f,-34.840897f,0f,0f,0f ) ;
  }

  @Test
  public void test424() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,96.257614f,0f,0f,0f,0f,0f,100.0f,155.53569f,-60.646095f,3240.0f,843.0f,1513.0f,1,-0.067253634f,0.54938495f,0.19747004f,0f,0f,0f ) ;
  }

  @Test
  public void test425() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,96.31702f,0f,0f,0f,0f,0f,-98.543465f,74.33994f,-100.0f,0f,0f,0f,1,-0.5834803f,0.06319827f,-0.05381191f,0f,0f,0f ) ;
  }

  @Test
  public void test426() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,97.01133f,0f,0f,0f,0f,0f,10.416144f,-38.51315f,-25.800756f,439.0f,-225.0f,508.0f,1,-0.11505291f,-1.1848707f,0.017485665f,0f,0f,0f ) ;
  }

  @Test
  public void test427() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,99.11721f,0f,0f,0f,0f,0f,1.6208127f,28.705778f,0.3679717f,260.0f,-8.0f,-502.0f,1,-50.912464f,1.8391554f,80.78115f,0f,0f,0f ) ;
  }

  @Test
  public void test428() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-99.30711f,0f,0f,0f,0f,0f,-100.0f,67.55758f,7.027305f,0f,0f,0f,1,-0.10725064f,-0.017290091f,-0.15167433f,0f,0f,0f ) ;
  }

  @Test
  public void test429() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,99.99618f,0f,0f,0f,0f,0f,-41.879246f,-20.111694f,-56.931355f,1000.0f,-616.0f,-518.0f,2,-51.770535f,-76.366196f,-45.0658f,0f,0f,0f ) ;
  }

  @Test
  public void test430() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,99.99989f,0f,0f,0f,0f,0f,67.281654f,-26.33176f,13.104704f,55.0f,-171.0f,-625.0f,-1,-0.26455846f,-0.14244297f,2.9562376f,0f,0f,0f ) ;
  }

  @Test
  public void test431() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-20.058615f,-40.806595f,48.071213f,0f,0f,0f,1,0.57035154f,0.16787396f,0.11017505f,0f,0f,0f ) ;
  }

  @Test
  public void test432() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-27.605822f,-93.53758f,5.0747037f,0f,0f,0f,1,-66.406624f,68.5979f,-10.203255f,0f,0f,0f ) ;
  }

  @Test
  public void test433() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-32.123493f,-100.0f,70.32301f,0f,0f,0f,1,0.071477704f,-0.0021845337f,-0.9837495f,0f,0f,0f ) ;
  }

  @Test
  public void test434() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,1.3755356f,-8.873179f,29.272923f,0f,0f,0f,1,67.79099f,43.240967f,-40.133305f,0f,0f,0f ) ;
  }

  @Test
  public void test435() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-32.770767f,-64.03937f,100.0f,0f,0f,0f,1,0.07923149f,-0.43024465f,-0.708065f,0f,0f,0f ) ;
  }

  @Test
  public void test436() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-98.645515f,100.0f,-100.0f,0f,0f,0f,1,33.119232f,-23.443375f,85.89847f,0f,0f,0f ) ;
  }

  @Test
  public void test437() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0.0f,0f,0f,0f,0f,20.889883f,2.0874915f,-100.0f,22.758415f,-6.5870733f,13.257011f,0f,0f,0f,2,21.708004f,1.7221013f,-99.99776f,0f,0f,0f ) ;
  }

  @Test
  public void test438() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0.0f,0f,100.0f,0f,0f,0f,0f,0f,-100.0f,-1.5722448f,-2.836534f,0f,0f,0f,1,65.153824f,-100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test439() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0.0f,0f,15.882376f,0f,0f,0f,0f,0f,83.52586f,53.600544f,88.004364f,0f,0f,0f,1,0.23770139f,-0.43754974f,-0.8048019f,0f,0f,0f ) ;
  }

  @Test
  public void test440() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0.0f,0f,-16.70697f,0f,0f,0f,0f,0f,-16.735703f,-100.0f,10.394515f,0f,0f,0f,1,0.54735476f,0.23005438f,-0.76905763f,0f,0f,0f ) ;
  }

  @Test
  public void test441() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0.0f,0f,6.443584f,0f,0f,0f,0f,0f,-1.0279258f,100.0f,98.80915f,0f,0f,0f,1,-0.18825774f,-0.9684522f,0.16327699f,0f,0f,0f ) ;
  }

  @Test
  public void test442() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0.0f,0f,69.3286f,0f,0f,0f,0f,0f,71.254715f,-172.5849f,128.44456f,0f,0f,0f,1,0.29456857f,0.37836167f,0.2289995f,0f,0f,0f ) ;
  }

  @Test
  public void test443() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0.0f,0f,-94.09368f,0f,0f,0f,0f,0f,-99.13718f,59.93228f,-8.019632f,0f,0f,0f,1,0.95116794f,0.26361448f,0.16058332f,0f,0f,0f ) ;
  }

  @Test
  public void test444() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0.0f,0f,-9.947598E-14f,0f,0f,0f,0f,0f,90.43365f,37.927956f,-18.540941f,0f,0f,0f,1,-0.19719385f,-0.4349578f,-0.49145135f,0f,0f,0f ) ;
  }

  @Test
  public void test445() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,0f,0f,0f,27.347198f,-26.647844f,-81.16903f,0f,0f,0f,1,0.06388581f,0.8898323f,0.0486531f,0f,0f,0f ) ;
  }

  @Test
  public void test446() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,35.389805f,-10.032778f,-39.261303f,0f,0f,0f,1,-0.3389393f,0.8979642f,-0.2806786f,0f,0f,0f ) ;
  }

  @Test
  public void test447() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,0f,0f,0f,-50.195522f,51.747917f,44.16334f,0f,0f,0f,1,0.5834657f,0.022315698f,-0.069204666f,0f,0f,0f ) ;
  }

  @Test
  public void test448() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,-100.0f,0f,0.0f,0f,0f,0f,0f,0f,-7.708546f,-100.0f,98.69737f,0f,0f,0f,1,0.21434242f,-0.15175454f,-0.92465526f,0f,0f,0f ) ;
  }

  @Test
  public void test449() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,100.0f,-100.0f,1752.0f,-91.0f,402.0f,2,0.30721667f,-0.9111138f,-0.24832456f,0f,0f,0f ) ;
  }

  @Test
  public void test450() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-97.26679f,7.803382f,16.0f,709.0f,-115.0f,1,-0.1407553f,0.069012426f,-0.9876362f,0f,0f,0f ) ;
  }

  @Test
  public void test451() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,-18.301708f,27.142994f,10.956961f,-98.0f,332.0f,-119.0f,1,3.9717906f,1.8811135f,1.9742239f,0f,0f,0f ) ;
  }

  @Test
  public void test452() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,-3.1962652f,85.223724f,-38.080048f,0f,0f,0f,1,9.002261f,32.52524f,85.97958f,0f,0f,0f ) ;
  }

  @Test
  public void test453() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,58.716393f,1.3047533f,-90.24144f,-901.0f,140.0f,-141.0f,3,-5.14662f,-15.912594f,-3.578362f,0f,0f,0f ) ;
  }

  @Test
  public void test454() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,6.376031f,-11.115208f,-2.8784869f,0f,0f,0f,1,-0.42645848f,0.6902511f,0.30911514f,0f,0f,0f ) ;
  }

  @Test
  public void test455() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,82.08856f,-90.577644f,-6.6553726f,-985.0f,-653.0f,-2564.0f,1,-0.42871565f,-0.32664442f,-0.842322f,0f,0f,0f ) ;
  }

  @Test
  public void test456() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,100.0f,0f,0f,0f,0f,-23.894537f,100.0f,-3.251798f,99.315796f,100.0f,-30.919392f,0f,0f,0f,2,-23.898817f,100.0f,-3.3735163f,0f,0f,0f ) ;
  }

  @Test
  public void test457() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,-100.0f,0f,38.531265f,0f,0f,0f,0f,0f,-76.82455f,100.0f,-51.2759f,0f,0f,0f,1,0.049788184f,-0.04323536f,0.5910835f,0f,0f,0f ) ;
  }

  @Test
  public void test458() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-100.0f,0f,9.941198f,0f,0f,0f,0f,0f,22.626823f,11.508383f,-54.958973f,0f,0f,0f,1,-83.541176f,57.55631f,90.778366f,0f,0f,0f ) ;
  }

  @Test
  public void test459() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,21.631887f,0f,0f,0f,0f,0f,0f,0f,-34.78898f,-72.80781f,-59.68704f,-126.0f,-519.0f,-824.0f,1,13.250611f,-36.539864f,36.849964f,0f,0f,0f ) ;
  }

  @Test
  public void test460() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,28.916567f,0f,0f,0f,0f,0f,0f,0f,71.91996f,90.39298f,8.991331f,197.0f,273.0f,-59.0f,-1,8.303365f,-6.4106455f,-1.968587f,0f,0f,0f ) ;
  }

  @Test
  public void test461() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,-34.989334f,0f,-94.576355f,0f,0f,0f,0f,0f,-87.24595f,-42.409523f,-72.714966f,0f,0f,0f,1,49.64947f,79.41158f,-31.331383f,0f,0f,0f ) ;
  }

  @Test
  public void test462() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,35.367657f,0f,0f,0f,0f,0f,0f,0f,25.871384f,-33.099556f,27.354494f,933.0f,640.0f,-108.0f,1,-57.36839f,71.386536f,-3.7051818f,0f,0f,0f ) ;
  }

  @Test
  public void test463() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,41.17812f,0f,0f,0f,0f,0f,0f,0f,-97.59847f,-6.0230827f,-94.799545f,-330.0f,-67.0f,344.0f,1,100.0f,-46.7271f,-38.6673f,0f,0f,0f ) ;
  }

  @Test
  public void test464() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,5.312466f,0f,0f,0f,0f,0f,0f,0f,-72.83779f,-100.0f,-17.407757f,0f,0f,0f,1,-0.10166924f,0.31333748f,0.05145061f,0f,0f,0f ) ;
  }

  @Test
  public void test465() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,74.78591f,0f,0f,0f,0f,0f,0f,0f,2.0174582f,8.50954f,34.442535f,-975.0f,-384.0f,364.0f,1,-1.001516f,0.11411961f,-0.0065039014f,0f,0f,0f ) ;
  }

  @Test
  public void test466() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,74.84229f,0f,0f,0f,0f,0f,0f,0f,59.58128f,-34.573654f,30.981178f,1498.0f,-675.0f,148.0f,-1,-56.76051f,-100.0f,-2.4394815f,0f,0f,0f ) ;
  }

  @Test
  public void test467() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,85.107025f,0f,0f,0f,0f,0f,0f,0f,100.0f,-87.90043f,-100.0f,0f,0f,0f,1,-0.066410206f,0.916408f,-0.3946975f,0f,0f,0f ) ;
  }

  @Test
  public void test468() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,85.71265f,0f,0f,0f,0f,0f,0f,0f,-93.00343f,85.53132f,47.280334f,-1224.0f,884.0f,-1187.0f,1,0.18378879f,-0.7276606f,-0.66085684f,0f,0f,0f ) ;
  }

  @Test
  public void test469() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,87.66461f,0f,0f,0f,0f,0f,0f,0f,-3.1186707f,-15.813405f,50.659966f,291.0f,977.0f,-1440.0f,1,-0.92651266f,0.3716152f,0.05896107f,0f,0f,0f ) ;
  }

  @Test
  public void test470() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-89.479095f,0f,0.0f,0f,0f,0f,0f,0f,89.53377f,-65.30729f,40.33246f,0f,0f,0f,1,0.26190814f,-0.19543846f,-0.9450968f,0f,0f,0f ) ;
  }

  @Test
  public void test471() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,-97.88097f,0f,0.0f,0f,0f,0f,0f,0f,3.59087f,47.22547f,100.0f,0f,0f,0f,1,0.47302637f,0.30202028f,-0.7974209f,0f,0f,0f ) ;
  }

  @Test
  public void test472() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,-99.11557f,0f,100.0f,0f,0f,0f,0f,0f,-38.858826f,-100.0f,-19.767708f,0f,0f,0f,1,100.0f,94.00957f,18.544641f,0f,0f,0f ) ;
  }

  @Test
  public void test473() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1008.0f,204.0f,0f,564.0f,0f,0f,0f,0f,0f,438.0f,1277.0f,753.0f,-817.0f,675.0f,900.0f,-1,-49.749752f,-62.12151f,-20.46463f,0f,0f,0f ) ;
  }

  @Test
  public void test474() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-102.525955f,61.14518f,0f,0f,0f,0f,0f,0f,0f,-88.03326f,63.767773f,-23.94687f,-684.0f,-540.0f,-705.0f,1,91.72143f,98.51262f,-74.85761f,0f,0f,0f ) ;
  }

  @Test
  public void test475() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,102.95102f,24.654884f,0f,0f,0f,0f,0f,0f,0f,7.5471697f,-64.626076f,82.468094f,0f,0f,0f,1,19.031311f,58.829002f,31.194197f,0f,0f,0f ) ;
  }

  @Test
  public void test476() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0328923f,49.648438f,0f,0f,0f,0f,0f,0f,0f,100.0f,-100.0f,-23.730394f,249.0f,1568.0f,-134.0f,1,0.2670402f,0.86324733f,-0.42817253f,0f,0f,0f ) ;
  }

  @Test
  public void test477() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-103.43906f,100.0f,0f,0f,0f,0f,0f,0f,0f,-3.3431113f,-50.307102f,100.0f,0f,0f,0f,1,0.065473266f,0.9559657f,0.0571811f,0f,0f,0f ) ;
  }

  @Test
  public void test478() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,104.61117f,-58.051247f,0f,0f,0f,0f,0f,0f,0f,-31.923494f,0.88387686f,-18.708836f,0f,0f,0f,1,64.076294f,-73.393814f,24.926334f,0f,0f,0f ) ;
  }

  @Test
  public void test479() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1055.0f,1622.0f,1591.0f,3.0f,0f,0f,0f,0f,0f,2347.0f,372.0f,-542.0f,1335.0f,661.0f,-198.0f,16,-0.8348191f,-0.7063088f,-0.17913024f,100.0f,0f,0f ) ;
  }

  @Test
  public void test480() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1059.0f,0.0f,0f,673.0f,0f,0f,0f,0f,0f,-848.0f,2223.0f,-81.0f,473.0f,-2027.0f,-1707.0f,-3,0.7587225f,0.20369667f,0.618747f,0f,0f,0f ) ;
  }

  @Test
  public void test481() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1070.0f,0.0f,0f,1845.0f,0f,0f,0f,0f,0f,285.0f,-181.0f,307.0f,-451.0f,-1065.0f,-202.0f,-1,25.057327f,4.377554f,-47.406986f,0f,0f,0f ) ;
  }

  @Test
  public void test482() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,10.725657f,0.0f,0f,0f,0f,0f,0f,0f,0f,2.3295588f,-2.3195934f,26.806732f,0f,0f,0f,1,-81.8074f,16.932669f,4.3970165f,0f,0f,0f ) ;
  }

  @Test
  public void test483() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1081.0f,0.0f,0f,862.0f,0f,0f,0f,0f,0f,-79.0f,-1329.0f,1628.0f,-2244.0f,345.0f,1679.0f,1,-168.34639f,-13.09129f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test484() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1090.0f,-1309.0f,0f,1028.0f,0f,0f,0f,0f,0f,-156.0f,-240.0f,72.0f,-377.0f,41.0f,-678.0f,1,128.71283f,-82.37832f,-10.597751f,0f,0f,0f ) ;
  }

  @Test
  public void test485() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,0.0f,0f,135.0f,0f,0f,0f,0f,0f,905.0f,-1760.0f,347.0f,-496.0f,958.0f,-1490.0f,1,-2.4014802f,5.0953617f,0.06493437f,0f,0f,0f ) ;
  }

  @Test
  public void test486() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,1097.0f,-941.0f,-1.0f,0f,0f,0f,0f,0f,481.0f,924.0f,-98.0f,219.0f,91.0f,271.0f,2,100.0f,-100.0f,-90.720055f,-40.85721f,0f,0f ) ;
  }

  @Test
  public void test487() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,1.0f,0f,1024.0f,0f,0f,0f,0f,0f,-64.0f,-895.0f,638.0f,-1454.0f,-1113.0f,541.0f,3,-1.2451135f,0.31555653f,0.24657023f,0f,0f,0f ) ;
  }

  @Test
  public void test488() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,1144.0f,904.0f,0.0f,0f,0f,0f,0f,0f,1168.0f,323.0f,-473.0f,-846.0f,-1018.0f,-875.0f,-4,-85.2021f,15.194347f,-100.0f,7.348397f,0f,0f ) ;
  }

  @Test
  public void test489() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,-1153.0f,0f,223.0f,0f,0f,0f,0f,0f,913.0f,1387.0f,587.0f,-961.0f,-654.0f,-947.0f,5,-0.44181666f,-0.5383194f,-3.3692486f,0f,0f,0f ) ;
  }

  @Test
  public void test490() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,1277.0f,766.0f,-40.0f,0f,0f,0f,0f,0f,-1537.0f,-142.0f,-655.0f,1322.0f,614.0f,103.0f,4,0.3384264f,-0.9395957f,-0.051258706f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test491() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,1343.0f,0f,1533.0f,0f,0f,0f,0f,0f,313.0f,559.0f,-381.0f,118.0f,-460.0f,-1426.0f,2,-11.77205f,-48.856113f,82.32003f,0f,0f,0f ) ;
  }

  @Test
  public void test492() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,137.0f,-667.0f,-162.0f,0f,0f,0f,0f,0f,653.0f,-924.0f,2213.0f,936.0f,-1198.0f,-610.0f,-5,100.0f,-100.0f,-100.0f,46.50473f,0f,0f ) ;
  }

  @Test
  public void test493() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,170.0f,0f,-952.0f,0f,0f,0f,0f,0f,-810.0f,-408.0f,164.0f,-2255.0f,1829.0f,2079.0f,-4,0.6055296f,0.70121264f,0.21075942f,0f,0f,0f ) ;
  }

  @Test
  public void test494() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,1733.0f,0f,427.0f,0f,0f,0f,0f,0f,66.0f,-5.0f,62.0f,662.0f,-1283.0f,-808.0f,-8,-55.559017f,-108.96921f,34.376675f,0f,0f,0f ) ;
  }

  @Test
  public void test495() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,2.0f,0f,1978.0f,0f,0f,0f,0f,0f,-394.0f,-1397.0f,1909.0f,1075.0f,408.0f,-1438.0f,3,-0.019901425f,0.6377234f,-0.21231161f,0f,0f,0f ) ;
  }

  @Test
  public void test496() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,300.0f,-701.0f,-1.0f,0f,0f,0f,0f,0f,-646.0f,1059.0f,757.0f,10.0f,-183.0f,30.0f,-3,0.9488792f,-1.8503203f,-0.056089714f,100.0f,0f,0f ) ;
  }

  @Test
  public void test497() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,3.0f,-1309.0f,-842.0f,0f,0f,0f,0f,0f,-975.0f,262.0f,-246.0f,-445.0f,293.0f,987.0f,1,100.0f,-24.302698f,81.96392f,127.5799f,0f,0f ) ;
  }

  @Test
  public void test498() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,386.0f,-223.0f,-1113.0f,0f,0f,0f,0f,0f,-1133.0f,642.0f,-972.0f,264.0f,-1964.0f,604.0f,5,-0.039152816f,0.07109806f,0.45689756f,14.168716f,0f,0f ) ;
  }

  @Test
  public void test499() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,396.0f,0f,1159.0f,0f,0f,0f,0f,0f,-123.0f,101.0f,-5.0f,739.0f,954.0f,1072.0f,-1,100.0f,-52.082466f,-15.462611f,0f,0f,0f ) ;
  }

  @Test
  public void test500() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,406.0f,0f,391.0f,0f,0f,0f,0f,0f,-1189.0f,-2132.0f,-445.0f,-798.0f,1265.0f,-177.0f,-2,0.33518025f,0.33586353f,-1.3598229f,0f,0f,0f ) ;
  }

  @Test
  public void test501() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,-42.0f,0f,2235.0f,0f,0f,0f,0f,0f,-450.0f,-2322.0f,194.0f,470.0f,-3.0f,1054.0f,-13,0.19655035f,3.6317022f,0.3265738f,0f,0f,0f ) ;
  }

  @Test
  public void test502() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,-468.0f,0f,1400.0f,0f,0f,0f,0f,0f,-539.0f,584.0f,-494.0f,-432.0f,-173.0f,266.0f,-2,100.0f,-57.141674f,17.868069f,0f,0f,0f ) ;
  }

  @Test
  public void test503() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,516.0f,0f,-1.0f,0f,0f,0f,0f,0f,1114.0f,1086.0f,-1254.0f,-181.0f,-467.0f,1274.0f,-5,0.49963772f,-2.4806426f,0.31704244f,0f,0f,0f ) ;
  }

  @Test
  public void test504() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,598.0f,0f,204.0f,0f,0f,0f,0f,0f,1226.0f,-576.0f,-296.0f,-962.0f,-769.0f,184.0f,4,-95.470474f,-55.92559f,140.90897f,0f,0f,0f ) ;
  }

  @Test
  public void test505() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,606.0f,0f,0f,0f,0f,-172.0f,-38.0f,-40.0f,-518.0f,-1929.0f,1352.0f,-261.0f,-63.0f,-553.0f,-9,-188.23042f,-45.386448f,-34.765255f,0f,0f,0f ) ;
  }

  @Test
  public void test506() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,607.0f,0f,677.0f,0f,0f,0f,0f,0f,-782.0f,523.0f,-1509.0f,-850.0f,84.0f,1393.0f,-2,8.0624275f,-0.29571742f,0.95643413f,0f,0f,0f ) ;
  }

  @Test
  public void test507() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,-6.0f,0f,1838.0f,0f,0f,0f,0f,0f,147.0f,849.0f,-680.0f,841.0f,-136.0f,12.0f,-5,-100.0f,-100.0f,-23.756948f,0f,0f,0f ) ;
  }

  @Test
  public void test508() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,647.0f,-1199.0f,-2.0f,0f,0f,0f,0f,0f,2136.0f,-838.0f,-69.0f,-1539.0f,2357.0f,-721.0f,-13,0.060659975f,0.86229575f,-0.15136068f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test509() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,-649.0f,0f,770.0f,0f,0f,0f,0f,0f,-807.0f,-894.0f,517.0f,-284.0f,-1148.0f,706.0f,1,0.15680194f,0.41617143f,0.013902132f,0f,0f,0f ) ;
  }

  @Test
  public void test510() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,687.0f,0f,397.0f,0f,0f,0f,0f,0f,1513.0f,-855.0f,168.0f,-330.0f,-279.0f,1347.0f,1,-5.2980013f,36.291843f,40.715134f,0f,0f,0f ) ;
  }

  @Test
  public void test511() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,697.0f,0f,0f,0f,0f,-59.0f,-25.0f,47.0f,475.0f,900.0f,-1163.0f,607.0f,847.0f,901.0f,8,-23.874413f,-20.629019f,53.848656f,0f,0f,0f ) ;
  }

  @Test
  public void test512() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,-843.0f,0f,558.0f,0f,0f,0f,0f,0f,504.0f,-149.0f,451.0f,25.0f,687.0f,199.0f,-44,-3.0358062f,0.9536066f,-2.0458286f,0f,0f,0f ) ;
  }

  @Test
  public void test513() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1102.0f,999.0f,0f,498.0f,0f,0f,0f,0f,0f,-71.0f,-423.0f,631.0f,-587.0f,-322.0f,-167.0f,4,96.99465f,100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test514() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1103.0f,0.0f,0f,1315.0f,0f,0f,0f,0f,0f,-1044.0f,-50.0f,40.0f,586.0f,728.0f,-627.0f,1,80.05302f,32.59097f,-68.16565f,0f,0f,0f ) ;
  }

  @Test
  public void test515() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.1129E-41f,100.0f,0f,0f,0f,0f,0f,0f,0f,38.867672f,99.999954f,-75.77925f,-589.0f,-641.0f,16.0f,1,-100.0f,86.24084f,62.51498f,0f,0f,0f ) ;
  }

  @Test
  public void test516() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1136.0f,0.0f,0f,438.0f,0f,0f,0f,0f,0f,981.0f,-480.0f,786.0f,1583.0f,803.0f,203.0f,2,-100.0f,57.0023f,29.775934f,0f,0f,0f ) ;
  }

  @Test
  public void test517() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1140.0f,411.0f,0f,658.0f,0f,0f,0f,0f,0f,1326.0f,-108.0f,952.0f,237.0f,-378.0f,-1346.0f,4,-44.448902f,-34.395264f,28.67809f,0f,0f,0f ) ;
  }

  @Test
  public void test518() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1143.0f,-452.0f,0f,1324.0f,0f,0f,0f,0f,0f,859.0f,1444.0f,-247.0f,1777.0f,-216.0f,871.0f,1,-36.288387f,-61.10755f,87.64958f,0f,0f,0f ) ;
  }

  @Test
  public void test519() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1144.0f,-1.0f,0f,417.0f,0f,0f,0f,0f,0f,232.0f,-78.0f,-647.0f,589.0f,950.0f,97.0f,2,96.341484f,53.835197f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test520() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1144.0f,-816.0f,0f,19.0f,0f,0f,0f,0f,0f,-761.0f,-1775.0f,712.0f,-1307.0f,-262.0f,-559.0f,1,-0.31945267f,-0.014969224f,-0.947484f,0f,0f,0f ) ;
  }

  @Test
  public void test521() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1145.0f,-120.0f,0f,1132.0f,0f,0f,0f,0f,0f,980.0f,-739.0f,-852.0f,185.0f,-232.0f,414.0f,-6,0.35456857f,0.42138332f,0.833955f,0f,0f,0f ) ;
  }

  @Test
  public void test522() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,115.602066f,0.9265152f,0f,0f,0f,0f,0f,0f,0f,50.762962f,-100.0f,-91.53821f,698.0f,-1894.0f,162.0f,1,0.29101864f,0.70946383f,0.5057641f,0f,0f,0f ) ;
  }

  @Test
  public void test523() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1164.0f,0.0f,0f,356.0f,0f,0f,0f,0f,0f,405.0f,1063.0f,-309.0f,954.0f,-1762.0f,613.0f,1,92.920555f,-100.0f,-91.35466f,0f,0f,0f ) ;
  }

  @Test
  public void test524() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,11.668397f,100.0f,0f,0f,0f,0f,0f,0f,0f,53.966427f,66.0698f,58.9406f,-812.0f,1005.0f,-2009.0f,1,0.55569774f,0.077920824f,-0.8277248f,0f,0f,0f ) ;
  }

  @Test
  public void test525() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,116.711006f,-36.12101f,0f,0.0f,0f,0f,0f,0f,0f,22.5947f,49.109955f,12.537685f,0f,0f,0f,1,20.986933f,-18.012018f,16.07438f,0f,0f,0f ) ;
  }

  @Test
  public void test526() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1196.0f,0.0f,0f,171.0f,0f,0f,0f,0f,0f,-956.0f,915.0f,-125.0f,-797.0f,589.0f,-272.0f,-3,70.152626f,-30.949081f,-93.07685f,0f,0f,0f ) ;
  }

  @Test
  public void test527() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1200.0f,0.0f,0f,256.0f,0f,0f,0f,0f,0f,460.0f,164.0f,43.0f,-505.0f,1665.0f,-976.0f,3,0.33743834f,-18.741194f,-23.195625f,0f,0f,0f ) ;
  }

  @Test
  public void test528() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,121.294975f,-27.78502f,0f,0.0f,0f,0f,0f,0f,0f,-56.390816f,-2.4134738f,12.447132f,0f,0f,0f,1,37.564373f,99.60222f,14.7601795f,0f,0f,0f ) ;
  }

  @Test
  public void test529() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1217.0f,0.0f,0f,324.0f,0f,0f,0f,0f,0f,255.0f,-146.0f,137.0f,-350.0f,703.0f,-984.0f,-4,-100.0f,100.0f,-35.706375f,0f,0f,0f ) ;
  }

  @Test
  public void test530() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-121.71546f,0f,0f,0f,0f,0f,0f,0f,0f,27.486355f,-62.960373f,112.591515f,0f,0f,0f,1,0.3495786f,-7.25184f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test531() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1219.0f,-3.0f,0f,2739.0f,0f,0f,0f,0f,0f,-1614.0f,151.0f,-691.0f,-90.0f,-552.0f,90.0f,5,3.0276575f,3.535623f,-4.1898394f,0f,0f,0f ) ;
  }

  @Test
  public void test532() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-12.196687f,67.00326f,0f,0f,0f,0f,0f,0f,0f,100.0f,-100.0f,-23.815985f,-469.0f,1614.0f,-1234.0f,1,-88.979996f,-61.27025f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test533() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,123.0f,-973.0f,0f,141.0f,0f,0f,0f,0f,0f,-939.0f,-694.0f,1590.0f,1111.0f,-25.0f,-253.0f,3,100.0f,100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test534() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1253.0f,0.0f,0f,2878.0f,0f,0f,0f,0f,0f,-628.0f,1477.0f,651.0f,-1825.0f,1187.0f,-792.0f,4,0.8583908f,-0.22853856f,-0.48765218f,0f,0f,0f ) ;
  }

  @Test
  public void test535() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,127.0f,942.0f,0f,182.0f,0f,0f,0f,0f,0f,1189.0f,-427.0f,-973.0f,713.0f,-1293.0f,269.0f,2,-42.986755f,72.499504f,94.29828f,0f,0f,0f ) ;
  }

  @Test
  public void test536() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-129.61311f,-181.56099f,0f,60.396202f,0f,0f,0f,0f,0f,-73.67946f,-90.29445f,35.429867f,0f,0f,0f,1,27.983624f,36.08471f,-53.867516f,0f,0f,0f ) ;
  }

  @Test
  public void test537() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-13.0f,1841.0f,0f,2136.0f,0f,0f,0f,0f,0f,393.0f,-1678.0f,-626.0f,561.0f,-1728.0f,-225.0f,3,0.0769876f,0.4717438f,0.37359357f,0f,0f,0f ) ;
  }

  @Test
  public void test538() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-131.0f,0.0f,0f,1450.0f,0f,0f,0f,0f,0f,-210.0f,86.0f,89.0f,-810.0f,-142.0f,-1326.0f,-1,26.675463f,75.68434f,-84.67911f,0f,0f,0f ) ;
  }

  @Test
  public void test539() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1326.0f,-547.0f,0f,1312.0f,0f,0f,0f,0f,0f,-513.0f,36.0f,859.0f,787.0f,-813.0f,919.0f,4,-32.15554f,-77.48693f,-66.78513f,0f,0f,0f ) ;
  }

  @Test
  public void test540() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1331.0f,614.0f,0f,64.0f,0f,0f,0f,0f,0f,-192.0f,-78.0f,15.0f,273.0f,-1081.0f,-2153.0f,1,0.043556847f,0.41976005f,-0.02985816f,0f,0f,0f ) ;
  }

  @Test
  public void test541() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1339.0f,-1.0f,0f,1517.0f,0f,0f,0f,0f,0f,-249.0f,454.0f,90.0f,119.0f,56.0f,344.0f,-1,90.02505f,-100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test542() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1339.0f,518.0f,0f,-900.0f,0f,0f,0f,0f,0f,-781.0f,410.0f,-230.0f,-569.0f,-593.0f,594.0f,1,77.44903f,-75.35275f,5.5178833f,0f,0f,0f ) ;
  }

  @Test
  public void test543() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1343.0f,273.0f,-117.0f,-254.0f,0f,0f,0f,0f,0f,-1002.0f,-1468.0f,310.0f,46.0f,-1299.0f,24.0f,2,-0.25314912f,0.6558977f,0.6202479f,-48.280556f,0f,0f ) ;
  }

  @Test
  public void test544() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,13.473985f,141.96307f,0f,-40.407734f,0f,0f,0f,0f,0f,-28.10471f,90.86813f,65.597496f,0f,0f,0f,1,-70.62345f,-14.568759f,-91.24547f,0f,0f,0f ) ;
  }

  @Test
  public void test545() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-135.0f,-487.0f,0f,680.0f,0f,0f,0f,0f,0f,-759.0f,162.0f,-370.0f,-515.0f,-713.0f,417.0f,-2,100.0f,100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test546() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1351.0f,414.0f,0f,0.0f,0f,0f,0f,0f,0f,-708.0f,-490.0f,645.0f,-649.0f,-1165.0f,-220.0f,1,0.012836591f,0.044361383f,-0.18073119f,0f,0f,0f ) ;
  }

  @Test
  public void test547() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1354.0f,948.0f,0f,404.0f,0f,0f,0f,0f,0f,754.0f,-601.0f,-1411.0f,-1211.0f,666.0f,992.0f,-2,0.9435572f,0.51222414f,0.9742402f,0f,0f,0f ) ;
  }

  @Test
  public void test548() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,136.0f,0.0f,0f,1025.0f,0f,0f,0f,0f,0f,3216.0f,-4.0f,-62.0f,11.0f,-787.0f,630.0f,7,-4.2465014f,-0.10560539f,3.3659763f,0f,0f,0f ) ;
  }

  @Test
  public void test549() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-13.637001f,-71.903854f,0f,0.0f,0f,0f,0f,0f,0f,73.95679f,67.05915f,66.98868f,0f,0f,0f,1,-56.531464f,-61.576565f,-45.553898f,0f,0f,0f ) ;
  }

  @Test
  public void test550() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1375.0f,269.0f,-759.0f,-149.0f,0f,0f,0f,0f,0f,-687.0f,-597.0f,846.0f,-592.0f,-909.0f,-156.0f,-2,180.94125f,-55.49131f,-121.35611f,58.491398f,0f,0f ) ;
  }

  @Test
  public void test551() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-137.8682f,100.0f,0f,0f,0f,0f,0f,0f,0f,-75.32856f,-100.0f,100.0f,466.0f,-716.0f,1577.0f,1,-32.035072f,100.0f,54.304996f,0f,0f,0f ) ;
  }

  @Test
  public void test552() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1381.0f,-2128.0f,0f,200.0f,0f,0f,0f,0f,0f,-76.0f,-298.0f,367.0f,-380.0f,522.0f,345.0f,1,-1.1840464f,-0.7947414f,-2.8584263f,0f,0f,0f ) ;
  }

  @Test
  public void test553() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,13.834328f,0.0f,0f,57.875313f,0f,0f,0f,0f,0f,100.0f,-74.1059f,-51.152687f,0f,0f,0f,1,-0.066167295f,0.38582048f,-0.031216495f,0f,0f,0f ) ;
  }

  @Test
  public void test554() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1388.0f,-764.0f,0f,1007.0f,0f,0f,0f,0f,0f,551.0f,-1.0f,221.0f,-193.0f,596.0f,484.0f,-1,-108.61075f,-93.9579f,98.77836f,0f,0f,0f ) ;
  }

  @Test
  public void test555() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,13.9102335f,-22.44032f,0f,0.0f,0f,0f,0f,0f,0f,84.16618f,-87.931656f,-1.7300804f,0f,0f,0f,1,-0.59686744f,-0.44766763f,-0.3916438f,0f,0f,0f ) ;
  }

  @Test
  public void test556() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1396.0f,1480.0f,0f,4.0f,0f,0f,0f,0f,0f,-2660.0f,54.0f,-1618.0f,-1264.0f,2230.0f,-420.0f,3,0.93525463f,-5.570759E-4f,-0.3539752f,0f,0f,0f ) ;
  }

  @Test
  public void test557() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-140.10419f,0f,0f,0f,0f,0f,0f,0f,0f,35.07341f,71.48926f,60.540066f,0f,0f,0f,1,-87.23063f,-62.13555f,-62.13457f,0f,0f,0f ) ;
  }

  @Test
  public void test558() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-14.0f,2007.0f,0f,-176.0f,0f,0f,0f,0f,0f,249.0f,756.0f,-663.0f,-114.0f,1086.0f,-381.0f,1,-37.15955f,-19.785631f,-7.7570586f,0f,0f,0f ) ;
  }

  @Test
  public void test559() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1412.0f,1430.0f,-812.0f,-448.0f,0f,0f,0f,0f,0f,-530.0f,25.0f,-1298.0f,-1340.0f,554.0f,-2080.0f,3,0.019053068f,-0.28891882f,0.14887296f,-54.631348f,0f,0f ) ;
  }

  @Test
  public void test560() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1417.0f,-200.0f,0f,250.0f,0f,0f,0f,0f,0f,-884.0f,858.0f,2260.0f,-892.0f,691.0f,161.0f,1,0.0015563606f,-9.128744E-5f,-1.714633f,0f,0f,0f ) ;
  }

  @Test
  public void test561() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1419.0f,944.0f,0f,0.0f,0f,0f,0f,0f,0f,510.0f,1652.0f,235.0f,-611.0f,569.0f,-256.0f,1,40.887287f,-99.99631f,-5.3022513f,0f,0f,0f ) ;
  }

  @Test
  public void test562() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.4210855E-14f,-8.086159f,0f,-69.11709f,0f,0f,0f,0f,0f,-16.110395f,100.0f,-27.265862f,0f,0f,0f,-1,-0.0018476503f,-3.3136947f,-0.06650896f,0f,0f,0f ) ;
  }

  @Test
  public void test563() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,14.324275f,91.39881f,0f,0f,0f,0f,0f,0f,0f,78.72719f,52.265686f,66.19552f,1219.0f,562.0f,439.0f,2,0.17332982f,0.13525973f,-0.71868426f,0f,0f,0f ) ;
  }

  @Test
  public void test564() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,14.355278f,0.0f,0f,100.0f,0f,0f,0f,0f,0f,29.480162f,40.687244f,-21.555864f,0f,0f,0f,1,-91.64731f,-67.93309f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test565() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,14.527256f,68.878265f,0f,0f,0f,0f,0f,0f,0f,100.0f,27.553333f,-100.0f,0f,0f,0f,1,-0.12669922f,0.00640565f,-0.05225752f,0f,0f,0f ) ;
  }

  @Test
  public void test566() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1477.0f,950.0f,0f,-355.0f,0f,0f,0f,0f,0f,-890.0f,-935.0f,-844.0f,600.0f,-195.0f,719.0f,-1,-49.65483f,39.83752f,96.47294f,0f,0f,0f ) ;
  }

  @Test
  public void test567() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1486.0f,310.0f,0f,257.0f,0f,0f,0f,0f,0f,-546.0f,-951.0f,735.0f,-245.0f,-838.0f,-1266.0f,4,-97.062035f,169.73769f,142.2994f,0f,0f,0f ) ;
  }

  @Test
  public void test568() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.5139316f,100.0f,0f,0f,0f,0f,0f,0f,0f,59.368015f,-46.33025f,66.591644f,0f,0f,0f,1,-43.21896f,-36.05046f,13.449092f,0f,0f,0f ) ;
  }

  @Test
  public void test569() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1538.0f,0.0f,0f,351.0f,0f,0f,0f,0f,0f,558.0f,238.0f,229.0f,584.0f,-494.0f,-910.0f,-5,-100.0f,20.999916f,144.01286f,0f,0f,0f ) ;
  }

  @Test
  public void test570() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1544.0f,-2.0f,0f,783.0f,0f,0f,144.0f,-15.0f,-92.0f,-220.0f,-591.0f,-348.0f,0f,0f,0f,-6,141.72015f,-17.107376f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test571() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1555.0f,805.0f,0f,542.0f,0f,0f,0f,0f,0f,810.0f,-313.0f,829.0f,1371.0f,-378.0f,322.0f,1,0.36171037f,-0.25577942f,-0.89651686f,0f,0f,0f ) ;
  }

  @Test
  public void test572() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1556.0f,74.0f,0f,-758.0f,0f,0f,0f,0f,0f,1186.0f,2519.0f,-196.0f,775.0f,-1402.0f,-505.0f,-3,0.5603038f,-0.45029637f,-0.58462346f,0f,0f,0f ) ;
  }

  @Test
  public void test573() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1591.0f,133.0f,0f,50.0f,0f,0f,0f,0f,0f,1231.0f,1026.0f,30.0f,152.0f,-212.0f,1013.0f,-2,-0.6265307f,0.11990505f,0.7701931f,0f,0f,0f ) ;
  }

  @Test
  public void test574() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1602.0f,0.0f,0f,94.0f,0f,0f,0f,0f,0f,493.0f,32.0f,-831.0f,323.0f,-218.0f,841.0f,2,-54.75917f,90.29368f,79.60744f,0f,0f,0f ) ;
  }

  @Test
  public void test575() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1614.0f,0.0f,0f,12.0f,0f,0f,0f,0f,0f,689.0f,915.0f,311.0f,-920.0f,916.0f,-659.0f,-3,1.9772178f,-3.943188f,7.068108f,0f,0f,0f ) ;
  }

  @Test
  public void test576() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-16.15248f,100.0f,0f,0f,0f,0f,0f,0f,0f,-125.10216f,-15.296533f,-100.0f,0f,0f,0f,1,100.0f,-7.794062f,-13.682724f,0f,0f,0f ) ;
  }

  @Test
  public void test577() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1627.0f,728.0f,-2310.0f,-106.0f,0f,0f,0f,0f,0f,-1794.0f,907.0f,859.0f,-232.0f,-267.0f,-243.0f,1,0.13163905f,-0.5123524f,-0.848626f,58.403423f,0f,0f ) ;
  }

  @Test
  public void test578() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-163.53233f,0.0f,0f,-42.76389f,0f,0f,0f,0f,0f,77.67626f,-5.83278f,63.99884f,0f,0f,0f,1,-48.222393f,-40.19065f,-50.5553f,0f,0f,0f ) ;
  }

  @Test
  public void test579() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,16.45168f,88.324104f,0f,0f,0f,0f,0f,0f,0f,-5.8718796f,-1.991463f,-26.1057f,988.0f,-1040.0f,12.0f,1,-19.545584f,-55.731445f,8.831355f,0f,0f,0f ) ;
  }

  @Test
  public void test580() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.6516547E-21f,100.0f,0f,0f,0f,0f,0f,0f,0f,40.822353f,-65.83669f,60.82069f,-248.0f,-1068.0f,126.0f,1,13.292034f,-1.9310281f,-11.012107f,0f,0f,0f ) ;
  }

  @Test
  public void test581() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-166.0f,752.0f,0f,1250.0f,0f,0f,0f,0f,0f,406.0f,1008.0f,593.0f,-506.0f,215.0f,-19.0f,1,-92.090935f,94.11205f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test582() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-16.947266f,-84.058266f,0f,0.0f,0f,0f,0f,0f,0f,-73.649956f,60.61231f,100.0f,0f,0f,0f,1,100.0f,-65.97055f,-4.817106f,0f,0f,0f ) ;
  }

  @Test
  public void test583() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1707.0f,1137.0f,-347.0f,-594.0f,0f,0f,0f,0f,0f,391.0f,1376.0f,865.0f,-130.0f,872.0f,-825.0f,5,-51.31328f,-19.15461f,-11.708393f,-1.8545111f,0f,0f ) ;
  }

  @Test
  public void test584() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-17.0f,1.0f,0f,766.0f,0f,0f,0f,0f,0f,779.0f,180.0f,-1287.0f,-552.0f,50.0f,-327.0f,-2,-118.24219f,-80.3852f,134.48213f,0f,0f,0f ) ;
  }

  @Test
  public void test585() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,171.47598f,-100.0f,0f,100.0f,0f,0f,0f,0f,0f,-12.585494f,29.755156f,100.0f,0f,0f,0f,2,-0.55952114f,0.108319804f,-0.30969074f,0f,0f,0f ) ;
  }

  @Test
  public void test586() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,176.0f,0.0f,0f,1100.0f,0f,0f,0f,0f,0f,1391.0f,-925.0f,580.0f,-426.0f,558.0f,-420.0f,-1,0.011527804f,0.07380945f,-1.9608934f,0f,0f,0f ) ;
  }

  @Test
  public void test587() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-177.20805f,-81.50177f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,100.0f,-6.9437494f,0f,0f,0f,1,0.8449998f,0.3602549f,-0.27202716f,0f,0f,0f ) ;
  }

  @Test
  public void test588() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1774.0f,-1917.0f,0f,341.0f,0f,0f,0f,0f,0f,1135.0f,-1856.0f,744.0f,-316.0f,573.0f,-499.0f,-1,0.21682104f,0.7686765f,0.13951567f,0f,0f,0f ) ;
  }

  @Test
  public void test589() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,17.745583f,27.818737f,0f,0f,0f,0f,0f,0f,0f,-40.95047f,-20.361967f,-26.937902f,452.0f,-1718.0f,777.0f,1,76.97153f,-15.762965f,-81.76744f,0f,0f,0f ) ;
  }

  @Test
  public void test590() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,179.0f,-76.0f,0f,1063.0f,0f,0f,0f,0f,0f,-2297.0f,430.0f,-2969.0f,-891.0f,1409.0f,-191.0f,-1,0.7992557f,0.19809222f,-0.12192793f,0f,0f,0f ) ;
  }

  @Test
  public void test591() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1793.0f,2189.0f,0f,359.0f,0f,0f,0f,0f,0f,48.0f,80.0f,39.0f,737.0f,-55.0f,-864.0f,5,100.0f,-11.482046f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test592() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1839.0f,1414.0f,-893.0f,-2031.0f,0f,0f,0f,0f,0f,-864.0f,177.0f,695.0f,1242.0f,670.0f,1054.0f,-2,0.68106186f,0.13116297f,0.7203825f,100.0f,0f,0f ) ;
  }

  @Test
  public void test593() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-18.886368f,-27.353853f,0f,13.892068f,0f,0f,0f,0f,0f,37.676037f,-108.86085f,-95.42378f,0f,0f,0f,1,-0.4981017f,0.12700786f,0.16156045f,0f,0f,0f ) ;
  }

  @Test
  public void test594() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1896.0f,809.0f,0f,-2306.0f,0f,0f,0f,0f,0f,4356.0f,-62.0f,-1035.0f,-1226.0f,-1266.0f,-469.0f,3,-0.14325516f,0.25929993f,0.41547883f,0f,0f,0f ) ;
  }

  @Test
  public void test595() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-19.406324f,0.0f,0f,0f,0f,0f,0f,0f,0f,100.0f,12.759596f,-37.329308f,0f,0f,0f,1,-0.88019115f,0.065290615f,0.32631186f,0f,0f,0f ) ;
  }

  @Test
  public void test596() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.9708314f,40.58764f,0f,0.0f,0f,0f,0f,0f,0f,62.32419f,54.933514f,-74.33321f,0f,0f,0f,1,-74.11318f,-7.1251645f,-36.757885f,0f,0f,0f ) ;
  }

  @Test
  public void test597() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-198.0f,-1.0f,0f,555.0f,0f,0f,0f,0f,0f,-1124.0f,424.0f,-869.0f,-387.0f,-627.0f,-802.0f,2,70.52228f,98.42807f,27.365034f,0f,0f,0f ) ;
  }

  @Test
  public void test598() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,19.939913f,47.933064f,0f,0f,0f,0f,0f,0f,0f,21.471098f,55.552162f,31.64152f,0f,0f,0f,1,-0.75839776f,0.3407851f,-0.3048039f,0f,0f,0f ) ;
  }

  @Test
  public void test599() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1999.0f,1.0f,0f,6.0f,0f,0f,91.0f,97.0f,53.0f,1088.0f,-591.0f,1807.0f,0f,0f,0f,7,100.0f,100.0f,60.12914f,0f,0f,0f ) ;
  }

  @Test
  public void test600() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2019.0f,-275.0f,0f,805.0f,0f,0f,0f,0f,0f,866.0f,-766.0f,77.0f,-455.0f,-558.0f,-438.0f,-3,1.1187197f,0.09478053f,0.11438327f,0f,0f,0f ) ;
  }

  @Test
  public void test601() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,202.0f,1629.0f,0f,-949.0f,0f,0f,0f,0f,0f,777.0f,802.0f,431.0f,-684.0f,-736.0f,1174.0f,1,-25.671934f,-18.954004f,20.635805f,0f,0f,0f ) ;
  }

  @Test
  public void test602() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-204.0f,502.0f,-1545.0f,0.0f,0f,0f,0f,0f,0f,939.0f,-293.0f,-258.0f,1077.0f,71.0f,-158.0f,4,26.045582f,51.485123f,76.514305f,5.5988812f,0f,0f ) ;
  }

  @Test
  public void test603() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2056.0f,-881.0f,0f,1634.0f,0f,0f,0f,0f,0f,230.0f,2327.0f,-619.0f,838.0f,45.0f,-1729.0f,1,-0.25664437f,-0.99719197f,0.02853943f,0f,0f,0f ) ;
  }

  @Test
  public void test604() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,207.0f,-765.0f,0f,1028.0f,0f,0f,0f,0f,0f,125.0f,340.0f,601.0f,-593.0f,430.0f,-121.0f,2,-79.82207f,-64.79132f,49.331142f,0f,0f,0f ) ;
  }

  @Test
  public void test605() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2081.0f,0.0f,0f,834.0f,0f,0f,0f,0f,0f,-279.0f,391.0f,1510.0f,-733.0f,-865.0f,-1107.0f,-7,0.010620682f,0.7726765f,-0.6314313f,0f,0f,0f ) ;
  }

  @Test
  public void test606() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,1050.0f,0f,998.0f,0f,0f,0f,0f,0f,1856.0f,382.0f,1174.0f,-705.0f,-178.0f,-1264.0f,1,0.0040699407f,-0.99977416f,0.020859212f,0f,0f,0f ) ;
  }

  @Test
  public void test607() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,1134.0f,0f,1136.0f,0f,0f,0f,0f,0f,-381.0f,119.0f,-333.0f,-338.0f,-750.0f,-706.0f,2,0.44454134f,-0.42298734f,0.026777754f,0f,0f,0f ) ;
  }

  @Test
  public void test608() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,1367.0f,0f,1.0f,0f,0f,0f,0f,0f,1347.0f,-897.0f,-890.0f,-526.0f,-906.0f,843.0f,-2,1.0085666f,0.25609782f,1.9488147f,0f,0f,0f ) ;
  }

  @Test
  public void test609() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,153.0f,-1047.0f,-381.0f,0f,0f,0f,0f,0f,-565.0f,-1801.0f,-2059.0f,-360.0f,286.0f,-1334.0f,-1,30.287485f,52.401028f,58.02224f,-60.547928f,0f,0f ) ;
  }

  @Test
  public void test610() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,1548.0f,0f,1202.0f,0f,0f,0f,0f,0f,-1308.0f,41.0f,-848.0f,-155.0f,720.0f,274.0f,-7,-2.541613f,-0.82940996f,0.8029888f,0f,0f,0f ) ;
  }

  @Test
  public void test611() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,1605.0f,0f,1.0f,0f,0f,0f,0f,0f,-1166.0f,-348.0f,1565.0f,-804.0f,-406.0f,1972.0f,-7,0.92985797f,5.434152f,0.6475356f,0f,0f,0f ) ;
  }

  @Test
  public void test612() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,1638.0f,0f,2560.0f,0f,0f,0f,0f,0f,-520.0f,589.0f,-1456.0f,-182.0f,-1922.0f,-1401.0f,1,0.5105682f,-0.079351805f,0.8451871f,0f,0f,0f ) ;
  }

  @Test
  public void test613() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,1766.0f,807.0f,-1.0f,0f,0f,0f,0f,0f,-934.0f,18.0f,-1920.0f,1289.0f,580.0f,-1362.0f,2,6.6466455f,3.1523585f,-0.3083144f,20.52857f,0f,0f ) ;
  }

  @Test
  public void test614() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,-2230.0f,0f,1719.0f,0f,0f,0f,0f,0f,804.0f,-202.0f,-437.0f,-684.0f,-21.0f,-1249.0f,3,0.26060307f,-0.7330121f,1.7325904f,0f,0f,0f ) ;
  }

  @Test
  public void test615() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,-295.0f,0f,1854.0f,0f,0f,0f,0f,0f,-114.0f,657.0f,-990.0f,-184.0f,-75.0f,-1047.0f,-1,-0.047995575f,-0.55151206f,-0.15736143f,0f,0f,0f ) ;
  }

  @Test
  public void test616() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,3.0f,0f,1568.0f,0f,0f,0f,0f,0f,672.0f,-517.0f,-391.0f,-156.0f,498.0f,-942.0f,8,100.0f,139.35841f,41.491776f,0f,0f,0f ) ;
  }

  @Test
  public void test617() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,-588.0f,0f,3695.0f,0f,0f,0f,0f,0f,1274.0f,233.0f,-647.0f,286.0f,-620.0f,35.0f,-2,-0.99205923f,-0.012703855f,0.12512848f,0f,0f,0f ) ;
  }

  @Test
  public void test618() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,-6.0f,0f,212.0f,0f,0f,0f,0f,0f,162.0f,133.0f,-1023.0f,918.0f,-549.0f,73.0f,-3,29.98375f,-40.11976f,96.43008f,0f,0f,0f ) ;
  }

  @Test
  public void test619() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,940.0f,0f,1484.0f,0f,0f,0f,0f,0f,778.0f,-1213.0f,-355.0f,-551.0f,1157.0f,113.0f,-1,0.071743034f,0.37577832f,0.04377476f,0f,0f,0f ) ;
  }

  @Test
  public void test620() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,-941.0f,0f,816.0f,0f,0f,0f,0f,0f,311.0f,653.0f,770.0f,-783.0f,-918.0f,557.0f,-9,-0.040039666f,-0.74812275f,0.10289264f,0f,0f,0f ) ;
  }

  @Test
  public void test621() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2110.0f,1574.0f,0f,1202.0f,0f,0f,0f,0f,0f,604.0f,1213.0f,893.0f,-558.0f,-126.0f,323.0f,1,0.31188527f,-0.9415815f,-0.12709008f,0f,0f,0f ) ;
  }

  @Test
  public void test622() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-21.104555f,-100.0f,0f,-45.256256f,0f,0f,0f,0f,0f,-100.0f,2.4233727f,-81.36775f,0f,0f,0f,1,0.19468014f,-0.9374473f,0.28860384f,0f,0f,0f ) ;
  }

  @Test
  public void test623() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2117.0f,-307.0f,0f,770.0f,0f,0f,0f,0f,0f,-77.0f,215.0f,-729.0f,-392.0f,-405.0f,-78.0f,11,51.49991f,62.28711f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test624() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.1454911f,-100.0f,0f,79.73552f,0f,0f,0f,0f,0f,21.200438f,50.584408f,36.439426f,0f,0f,0f,1,-0.22054453f,-0.9205109f,-0.32252106f,0f,0f,0f ) ;
  }

  @Test
  public void test625() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-217.16765f,-14.011133f,0f,0f,0f,0f,0f,0f,0f,100.57566f,-3.2126796f,10.524551f,0f,0f,0f,1,-0.2798753f,-0.50111604f,0.80106425f,0f,0f,0f ) ;
  }

  @Test
  public void test626() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.1972024E-19f,0.0f,0f,5.95193E-19f,0f,0f,0f,0f,0f,99.97796f,100.0f,-66.588806f,0f,0f,0f,2,0.039173555f,-0.059426483f,1.0855443f,0f,0f,0f ) ;
  }

  @Test
  public void test627() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,222.0f,127.0f,875.0f,-885.0f,0f,0f,0f,0f,0f,69.0f,719.0f,853.0f,556.0f,634.0f,-134.0f,-114,-68.25604f,16.702187f,86.93859f,87.718124f,0f,0f ) ;
  }

  @Test
  public void test628() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2229.0f,3078.0f,0f,0f,0f,0f,-91.0f,-56.0f,82.0f,2200.0f,1380.0f,-1589.0f,440.0f,-81.0f,926.0f,9,-86.554665f,-53.258232f,75.785164f,0f,0f,0f ) ;
  }

  @Test
  public void test629() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2235.0f,2329.0f,0f,976.0f,0f,0f,0f,0f,0f,101.0f,-366.0f,-250.0f,136.0f,301.0f,-386.0f,-1,100.0f,100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test630() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-224.0f,1.0f,0f,457.0f,0f,0f,0f,0f,0f,-811.0f,-277.0f,324.0f,-441.0f,128.0f,-995.0f,5,94.34559f,-197.00421f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test631() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2247.0f,2884.0f,0f,0f,0f,0f,-250.0f,96.0f,45.0f,-20.0f,246.0f,-92.0f,-2135.0f,-902.0f,-1951.0f,14,-235.20944f,100.0f,26.333149f,0f,0f,0f ) ;
  }

  @Test
  public void test632() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2249.0f,-229.0f,0f,2506.0f,0f,0f,0f,0f,0f,449.0f,976.0f,71.0f,-218.0f,98.0f,31.0f,1,-100.0f,-69.924126f,129.86798f,0f,0f,0f ) ;
  }

  @Test
  public void test633() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-225.0f,420.0f,-20.0f,-5.0f,0f,0f,0f,0f,0f,-2972.0f,-2060.0f,-643.0f,-479.0f,447.0f,316.0f,-4,2.1534884f,1.3594712f,0.11718242f,44.964317f,0f,0f ) ;
  }

  @Test
  public void test634() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2268.0f,-1045.0f,0f,899.0f,0f,0f,0f,0f,0f,169.0f,978.0f,-772.0f,711.0f,-605.0f,-611.0f,-9,5.2272363f,-48.642094f,58.3138f,0f,0f,0f ) ;
  }

  @Test
  public void test635() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2268.0f,-1065.0f,0f,2125.0f,0f,0f,0f,0f,0f,548.0f,-655.0f,836.0f,544.0f,2635.0f,-862.0f,3,0.4370501f,-0.25566226f,-0.6694638f,0f,0f,0f ) ;
  }

  @Test
  public void test636() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2277.0f,-433.0f,0f,229.0f,0f,0f,0f,0f,0f,-1864.0f,-1146.0f,307.0f,-704.0f,-275.0f,308.0f,2,0.37685394f,-0.046240397f,0.80937564f,0f,0f,0f ) ;
  }

  @Test
  public void test637() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,228.0f,-302.0f,0f,406.0f,0f,0f,0f,0f,0f,-467.0f,-373.0f,-355.0f,591.0f,-897.0f,164.0f,4,100.0f,94.3522f,64.629776f,0f,0f,0f ) ;
  }

  @Test
  public void test638() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,23.057777f,46.126137f,0f,21.521206f,0f,0f,0f,0f,0f,92.137146f,-67.44543f,42.218918f,0f,0f,0f,1,-51.432487f,-34.508442f,25.976528f,0f,0f,0f ) ;
  }

  @Test
  public void test639() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,23.0f,655.0f,0f,578.0f,0f,0f,0f,0f,0f,-592.0f,175.0f,-239.0f,729.0f,702.0f,1220.0f,5,0.33032468f,-0.07956592f,0.5446004f,0f,0f,0f ) ;
  }

  @Test
  public void test640() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2313.0f,-1569.0f,0f,164.0f,0f,0f,0f,0f,0f,309.0f,599.0f,-1793.0f,-509.0f,1540.0f,-84.0f,1,-0.033097f,0.21271808f,0.9767983f,0f,0f,0f ) ;
  }

  @Test
  public void test641() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2316.0f,-3520.0f,0f,631.0f,0f,0f,0f,0f,0f,538.0f,1042.0f,-1345.0f,-1557.0f,555.0f,505.0f,1,61.389683f,0.5467853f,64.59036f,0f,0f,0f ) ;
  }

  @Test
  public void test642() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2329.0f,0.0f,0f,863.0f,0f,0f,0f,0f,0f,-1465.0f,168.0f,-857.0f,1006.0f,944.0f,-1465.0f,13,0.20398895f,-0.85364157f,-0.044174556f,0f,0f,0f ) ;
  }

  @Test
  public void test643() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-233.0f,4.0f,-693.0f,-1.0f,0f,0f,0f,0f,0f,-361.0f,-1528.0f,1211.0f,-1865.0f,-96.0f,836.0f,-8,-100.0f,79.9286f,-100.0f,-58.20738f,0f,0f ) ;
  }

  @Test
  public void test644() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-236.0f,-566.0f,0f,185.0f,0f,0f,0f,0f,0f,569.0f,-411.0f,419.0f,-5.0f,-952.0f,-814.0f,1,-68.45479f,67.51668f,48.87781f,0f,0f,0f ) ;
  }

  @Test
  public void test645() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2362.0f,-1556.0f,0f,2323.0f,0f,0f,0f,0f,0f,1627.0f,2045.0f,851.0f,372.0f,839.0f,123.0f,5,-100.0f,44.567684f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test646() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,23.63273f,-28.654408f,0f,0f,0f,0f,0f,0f,0f,7.1298122f,-33.969685f,8.966436f,0f,0f,0f,1,-0.046571545f,0.8291745f,0.23036174f,0f,0f,0f ) ;
  }

  @Test
  public void test647() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,238.0f,745.0f,463.0f,-613.0f,0f,0f,0f,0f,0f,194.0f,-933.0f,723.0f,-348.0f,726.0f,-201.0f,-464,12.558124f,61.64707f,1.3890495f,-77.42825f,0f,0f ) ;
  }

  @Test
  public void test648() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,24.054781f,73.842705f,0f,0f,0f,0f,0f,0f,0f,37.62915f,5.0326023f,-58.595955f,0f,0f,0f,1,95.31109f,-37.059307f,66.55027f,0f,0f,0f ) ;
  }

  @Test
  public void test649() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2427.0f,256.0f,0f,0f,0f,0f,-87.0f,84.0f,137.0f,551.0f,-1340.0f,-1884.0f,-344.0f,-476.0f,-1000.0f,-4,-86.47726f,86.674995f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test650() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-245.0f,-537.0f,0f,100.0f,0f,0f,0f,0f,0f,535.0f,331.0f,412.0f,-776.0f,332.0f,-736.0f,1,-100.0f,-72.71396f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test651() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-246.0f,2681.0f,0f,1141.0f,0f,0f,0f,0f,0f,-1322.0f,-1201.0f,1269.0f,-868.0f,241.0f,2348.0f,3,0.64798445f,0.09936533f,0.50172263f,0f,0f,0f ) ;
  }

  @Test
  public void test652() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-24.693117f,-59.80228f,0f,44.54628f,0f,0f,0f,0f,0f,84.132256f,-15.324801f,5.2115617f,0f,0f,0f,1,-0.3546953f,-0.5857266f,0.59090686f,0f,0f,0f ) ;
  }

  @Test
  public void test653() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-250.0f,758.0f,331.0f,-636.0f,0f,0f,0f,0f,0f,287.0f,328.0f,-14.0f,975.0f,298.0f,-339.0f,2,5.7827125f,-100.0f,-72.066414f,-22.71907f,0f,0f ) ;
  }

  @Test
  public void test654() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-255.0f,2376.0f,0f,156.0f,0f,0f,0f,0f,0f,563.0f,427.0f,-116.0f,882.0f,-1610.0f,-1632.0f,2,52.292793f,-100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test655() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,25.584473f,-33.178978f,0f,0f,0f,0f,0f,0f,0f,-59.197704f,38.395157f,39.83442f,0f,0f,0f,1,-14.789149f,9.446495f,-51.122585f,0f,0f,0f ) ;
  }

  @Test
  public void test656() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,256.0f,0.0f,0f,871.0f,0f,0f,0f,0f,0f,-364.0f,354.0f,986.0f,388.0f,1299.0f,2197.0f,-2,1.1299307f,0.44820198f,0.20383227f,0f,0f,0f ) ;
  }

  @Test
  public void test657() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2621.0f,338.0f,0f,-5.0f,0f,0f,0f,0f,0f,-2058.0f,-777.0f,-205.0f,1118.0f,-182.0f,-493.0f,7,0.15530743f,0.9875122f,0.026445596f,0f,0f,0f ) ;
  }

  @Test
  public void test658() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-264.0f,0.0f,0f,36.0f,0f,0f,0f,0f,0f,588.0f,576.0f,1811.0f,-502.0f,97.0f,-757.0f,2,-88.19387f,9.505376f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test659() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2666.0f,0.0f,0f,1402.0f,0f,0f,0f,0f,0f,741.0f,-1474.0f,773.0f,-1803.0f,-889.0f,36.0f,-4,-100.0f,66.894585f,93.73283f,0f,0f,0f ) ;
  }

  @Test
  public void test660() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-26.762838f,30.43645f,0f,0f,0f,0f,0f,0f,0f,131.27403f,-18.537506f,-90.32019f,13.0f,615.0f,620.0f,1,-19.939821f,-31.284237f,87.08136f,0f,0f,0f ) ;
  }

  @Test
  public void test661() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-268.0f,530.0f,0f,0.0f,0f,0f,0f,0f,0f,-1886.0f,-943.0f,680.0f,-609.0f,-303.0f,-97.0f,2,-3.2824242f,66.24107f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test662() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-270.0f,273.0f,0f,488.0f,0f,0f,0f,0f,0f,-372.0f,-26.0f,-887.0f,-864.0f,-817.0f,-655.0f,1,-39.40637f,-64.082085f,82.74988f,0f,0f,0f ) ;
  }

  @Test
  public void test663() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2708.0f,1235.0f,0f,0.0f,0f,0f,0f,0f,0f,-243.0f,166.0f,-2174.0f,-1836.0f,-843.0f,350.0f,1,0.31603152f,0.92998743f,1.6138123f,0f,0f,0f ) ;
  }

  @Test
  public void test664() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-27.357862f,99.80014f,0f,0f,0f,0f,0f,0f,0f,-40.89481f,-7.7022257f,-55.346527f,-1325.0f,721.0f,489.0f,1,-0.028360972f,0.35981146f,0.08649031f,0f,0f,0f ) ;
  }

  @Test
  public void test665() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2801.0f,-1.0f,0f,1624.0f,0f,0f,0f,0f,0f,-2049.0f,1228.0f,-1477.0f,-338.0f,-1464.0f,-3273.0f,6,0.040987555f,-0.09640822f,-0.0032949115f,0f,0f,0f ) ;
  }

  @Test
  public void test666() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,292.0f,0.0f,0f,41.0f,0f,0f,0f,0f,0f,738.0f,-248.0f,-125.0f,628.0f,1360.0f,1021.0f,1,-45.43226f,55.847797f,40.834988f,0f,0f,0f ) ;
  }

  @Test
  public void test667() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2945.0f,-1119.0f,0f,1690.0f,0f,0f,0f,0f,0f,865.0f,-273.0f,-841.0f,-296.0f,-208.0f,-237.0f,3,-7.89878f,-1.375754f,-7.5329423f,0f,0f,0f ) ;
  }

  @Test
  public void test668() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,298.0f,-1318.0f,0f,164.0f,0f,0f,0f,0f,0f,-194.0f,-773.0f,979.0f,152.0f,-1219.0f,-929.0f,2,-74.70625f,87.83867f,-18.349976f,0f,0f,0f ) ;
  }

  @Test
  public void test669() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-299.0f,714.0f,-1185.0f,-131.0f,0f,0f,0f,0f,0f,390.0f,98.0f,673.0f,853.0f,-410.0f,733.0f,2,-100.0f,79.94817f,-100.0f,-12.530844f,0f,0f ) ;
  }

  @Test
  public void test670() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,302.0f,-121.0f,177.0f,-844.0f,0f,0f,0f,0f,0f,-807.0f,869.0f,254.0f,-392.0f,-32.0f,232.0f,-179,57.661472f,-71.135506f,34.152176f,75.98921f,0f,0f ) ;
  }

  @Test
  public void test671() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3.055886f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-51.803986f,91.83786f,52.10244f,0f,0f,0f,1,-22.021433f,-97.88273f,-32.379677f,0f,0f,0f ) ;
  }

  @Test
  public void test672() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,309.0f,592.0f,0f,-1190.0f,0f,0f,0f,0f,0f,-505.0f,2105.0f,911.0f,653.0f,-1366.0f,140.0f,1,0.091041565f,-0.48233643f,0.7433501f,0f,0f,0f ) ;
  }

  @Test
  public void test673() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-309.0f,921.0f,0f,631.0f,0f,0f,0f,0f,0f,523.0f,-358.0f,808.0f,423.0f,-1280.0f,-1659.0f,2,-87.49929f,-90.420845f,-70.92939f,0f,0f,0f ) ;
  }

  @Test
  public void test674() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,3.0f,1014.0f,-425.0f,-1325.0f,0f,0f,0f,0f,0f,-478.0f,1329.0f,2145.0f,-759.0f,674.0f,590.0f,1,0.43571982f,-0.17347316f,-0.82237196f,55.589928f,0f,0f ) ;
  }

  @Test
  public void test675() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,3.0f,-1074.0f,0f,1780.0f,0f,0f,0f,0f,0f,-318.0f,-1644.0f,1150.0f,150.0f,1914.0f,-685.0f,-2,0.98439234f,-0.15922244f,-0.07496638f,0f,0f,0f ) ;
  }

  @Test
  public void test676() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3.0f,-1150.0f,0f,-3.0f,0f,0f,-11.0f,-67.0f,-26.0f,2511.0f,206.0f,373.0f,0f,0f,0f,-5,-5.5319867f,-71.51576f,-32.43906f,0f,0f,0f ) ;
  }

  @Test
  public void test677() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,3.0f,-2.0f,0f,404.0f,0f,0f,0f,0f,0f,140.0f,426.0f,-1014.0f,-957.0f,-196.0f,-214.0f,9,9.066328f,0.050455105f,2.316393f,0f,0f,0f ) ;
  }

  @Test
  public void test678() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3.0f,-363.0f,0f,1877.0f,0f,0f,0f,0f,0f,-928.0f,-421.0f,-534.0f,335.0f,516.0f,-992.0f,1,100.0f,100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test679() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,3.0f,373.0f,-2083.0f,-365.0f,0f,0f,0f,0f,0f,233.0f,802.0f,894.0f,1311.0f,1002.0f,-204.0f,-7,-0.5041531f,-0.94477624f,0.11586669f,94.44929f,0f,0f ) ;
  }

  @Test
  public void test680() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3149.0f,-125.0f,0f,1367.0f,0f,0f,0f,0f,0f,1351.0f,640.0f,380.0f,-46.0f,-191.0f,485.0f,-1,-27.134764f,34.35758f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test681() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,31.60139f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,-62.19233f,100.0f,0f,0f,0f,1,0.190865f,0.30988944f,-0.4698609f,0f,0f,0f ) ;
  }

  @Test
  public void test682() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-31.713692f,0.0f,0f,-100.48228f,0f,0f,0f,0f,0f,-14.308801f,-121.61127f,-91.06806f,0f,0f,0f,1,-0.100622825f,0.8871325f,-0.3590391f,0f,0f,0f ) ;
  }

  @Test
  public void test683() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-318.0f,447.0f,0f,2671.0f,0f,0f,0f,0f,0f,208.0f,-1729.0f,1250.0f,-161.0f,513.0f,458.0f,3,-0.2754626f,0.025365548f,-1.6788076f,0f,0f,0f ) ;
  }

  @Test
  public void test684() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3186.0f,253.0f,0f,1507.0f,0f,0f,0f,0f,0f,-921.0f,735.0f,-908.0f,161.0f,842.0f,547.0f,4,-100.0f,-14.998874f,89.29835f,0f,0f,0f ) ;
  }

  @Test
  public void test685() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,32.045193f,65.948975f,0f,0f,0f,0f,0f,0f,0f,-33.056683f,21.182652f,17.793703f,-506.0f,234.0f,-112.0f,3,0.5936289f,0.29811832f,0.7474826f,0f,0f,0f ) ;
  }

  @Test
  public void test686() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-326.0f,238.0f,-1905.0f,-65.0f,0f,0f,0f,0f,0f,405.0f,-781.0f,-1699.0f,533.0f,365.0f,2289.0f,1,0.76020414f,0.3698458f,0.5341383f,100.0f,0f,0f ) ;
  }

  @Test
  public void test687() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-32.665188f,42.0942f,0f,-1.4210855E-14f,0f,0f,0f,0f,0f,20.854908f,100.0f,100.0f,0f,0f,0f,1,-0.1978793f,-0.9205868f,0.2365531f,0f,0f,0f ) ;
  }

  @Test
  public void test688() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3281.0f,-4.0f,0f,2048.0f,0f,0f,0f,0f,0f,-285.0f,-132.0f,-5.0f,107.0f,-189.0f,-984.0f,7,3.5411367f,2.7957826f,-2.5631053f,0f,0f,0f ) ;
  }

  @Test
  public void test689() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,32.879757f,0.0f,0f,0f,0f,0f,0f,0f,0f,-40.283237f,100.0f,-86.48559f,0f,0f,0f,1,-0.69341403f,-0.52672195f,-0.17091134f,0f,0f,0f ) ;
  }

  @Test
  public void test690() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-33.222374f,0.0f,0f,7.1054274E-15f,0f,0f,0f,0f,0f,-36.39615f,72.02436f,-23.957405f,0f,0f,0f,1,92.88037f,2.900123f,41.633286f,0f,0f,0f ) ;
  }

  @Test
  public void test691() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,335.0f,-181.0f,0f,850.0f,0f,0f,0f,0f,0f,-603.0f,208.0f,-67.0f,-638.0f,-420.0f,-343.0f,2,42.27581f,110.43433f,12.583408f,0f,0f,0f ) ;
  }

  @Test
  public void test692() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3403.0f,924.0f,-787.0f,0.0f,0f,0f,0f,0f,0f,-551.0f,-218.0f,1605.0f,-838.0f,-1371.0f,657.0f,4,0.2382857f,0.053034272f,0.0331226f,-18.090681f,0f,0f ) ;
  }

  @Test
  public void test693() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,34.18386f,5.828817f,0f,0f,0f,0f,0f,0f,0f,-69.08063f,-100.0f,47.52723f,-1934.0f,1286.0f,1266.0f,1,0.005705709f,0.8789186f,0.063724935f,0f,0f,0f ) ;
  }

  @Test
  public void test694() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-345.0f,-328.0f,899.0f,-139.0f,0f,0f,0f,0f,0f,64.0f,-550.0f,-524.0f,393.0f,959.0f,441.0f,-995,8.099078f,97.85367f,-97.13751f,65.12114f,0f,0f ) ;
  }

  @Test
  public void test695() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3484.0f,135.0f,-784.0f,-1886.0f,0f,0f,0f,0f,0f,-329.0f,88.0f,-991.0f,-1422.0f,-630.0f,-601.0f,1,-77.071266f,-76.9205f,74.24261f,-50.918118f,0f,0f ) ;
  }

  @Test
  public void test696() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,353.0f,714.0f,0f,0.0f,0f,0f,0f,0f,0f,-438.0f,-405.0f,-673.0f,1761.0f,199.0f,-591.0f,3,66.299065f,-99.24633f,95.450806f,0f,0f,0f ) ;
  }

  @Test
  public void test697() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-359.0f,0.0f,0f,183.0f,0f,0f,0f,0f,0f,1202.0f,-127.0f,271.0f,1934.0f,-1295.0f,-36.0f,1,-49.367928f,36.603073f,-93.89804f,0f,0f,0f ) ;
  }

  @Test
  public void test698() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-36.0f,33.0f,0f,1.0f,0f,0f,0f,0f,0f,3.0f,-227.0f,386.0f,-192.0f,-150.0f,-84.0f,1,194.11577f,-100.0f,-60.433445f,0f,0f,0f ) ;
  }

  @Test
  public void test699() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-36.222183f,-100.0f,0f,-24.583706f,0f,0f,0f,0f,0f,36.84516f,-100.0f,-97.432274f,0f,0f,0f,1,0.017063944f,-0.040265955f,0.6324414f,0f,0f,0f ) ;
  }

  @Test
  public void test700() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,363.0f,964.0f,0f,-1236.0f,0f,0f,0f,0f,0f,-195.0f,-2158.0f,-299.0f,-37.0f,-611.0f,959.0f,9,0.2239279f,0.83843327f,-0.39125198f,0f,0f,0f ) ;
  }

  @Test
  public void test701() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-368.0f,0.0f,0f,443.0f,0f,0f,0f,0f,0f,463.0f,13.0f,-346.0f,-1567.0f,113.0f,1875.0f,1,-67.031296f,100.0f,-4.0489736f,0f,0f,0f ) ;
  }

  @Test
  public void test702() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,36.931145f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,-39.90854f,99.46268f,0f,0f,0f,1,-74.45355f,95.69933f,8.50453f,0f,0f,0f ) ;
  }

  @Test
  public void test703() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,36.94595f,-100.0f,0f,0.0f,0f,0f,0f,0f,0f,60.24426f,-2.9869864f,-21.45768f,0f,0f,0f,1,-16.23427f,-33.94413f,49.333084f,0f,0f,0f ) ;
  }

  @Test
  public void test704() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-37.538956f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-80.12452f,100.0f,-42.57793f,0f,0f,0f,1,1.3142416f,-58.61626f,-24.707611f,0f,0f,0f ) ;
  }

  @Test
  public void test705() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,377.0f,0.0f,0f,1237.0f,0f,0f,0f,0f,0f,813.0f,437.0f,-846.0f,728.0f,531.0f,54.0f,7,0.1038757f,-0.94105625f,-0.10925293f,0f,0f,0f ) ;
  }

  @Test
  public void test706() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-378.0f,184.0f,0f,-341.0f,0f,0f,0f,0f,0f,-1470.0f,267.0f,-616.0f,-138.0f,194.0f,473.0f,2,50.31395f,-87.92139f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test707() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3784.0f,235.0f,0f,0.0f,0f,0f,0f,0f,0f,375.0f,-109.0f,2939.0f,-1518.0f,-1481.0f,-2059.0f,1,-8.047997E-4f,-0.16813248f,-1.4771644f,0f,0f,0f ) ;
  }

  @Test
  public void test708() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,37.8756f,5.1893926f,0f,0f,0f,0f,0f,0f,0f,-61.925182f,-21.7997f,56.47655f,376.0f,-976.0f,-712.0f,1,-26.428385f,3.9490588f,-82.76024f,0f,0f,0f ) ;
  }

  @Test
  public void test709() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-381.0f,1531.0f,-1194.0f,-1.0f,0f,0f,0f,0f,0f,-927.0f,-573.0f,-900.0f,-408.0f,-2345.0f,-1896.0f,2,-0.09879137f,0.75909805f,0.22045508f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test710() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-382.0f,566.0f,0f,-863.0f,0f,0f,0f,0f,0f,214.0f,351.0f,-219.0f,-476.0f,-790.0f,-907.0f,1,-64.87698f,-14.808644f,54.96781f,0f,0f,0f ) ;
  }

  @Test
  public void test711() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-382.0f,759.0f,0f,-1845.0f,0f,0f,0f,0f,0f,340.0f,-732.0f,-521.0f,-792.0f,2086.0f,362.0f,-2,0.07667303f,0.89906245f,-0.17588332f,0f,0f,0f ) ;
  }

  @Test
  public void test712() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,382.0f,861.0f,0f,-375.0f,0f,0f,0f,0f,0f,140.0f,436.0f,-1084.0f,1709.0f,-672.0f,-510.0f,-1,0.377533f,-0.8955952f,-0.23532562f,0f,0f,0f ) ;
  }

  @Test
  public void test713() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,385.0f,117.0f,0f,0.0f,0f,0f,0f,0f,0f,588.0f,-640.0f,-396.0f,-513.0f,-655.0f,397.0f,1,-7.9295335f,40.250496f,14.871016f,0f,0f,0f ) ;
  }

  @Test
  public void test714() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,392.0f,822.0f,0f,-229.0f,0f,0f,0f,0f,0f,-97.0f,-1025.0f,-901.0f,-912.0f,-873.0f,-28.0f,4,100.0f,23.204004f,49.32057f,0f,0f,0f ) ;
  }

  @Test
  public void test715() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,394.0f,-543.0f,941.0f,856.0f,0f,0f,0f,0f,0f,-568.0f,86.0f,633.0f,16.0f,230.0f,450.0f,-811,89.02749f,2.176928f,-24.448185f,98.25886f,0f,0f ) ;
  }

  @Test
  public void test716() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,399.0f,0.0f,0f,521.0f,0f,0f,0f,0f,0f,611.0f,-1056.0f,-883.0f,270.0f,618.0f,-40.0f,1,-55.75737f,100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test717() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,403.0f,0.0f,0f,271.0f,0f,0f,0f,0f,0f,137.0f,1188.0f,-160.0f,1410.0f,-135.0f,237.0f,6,1.1265485f,-3.9461045f,-0.6169155f,0f,0f,0f ) ;
  }

  @Test
  public void test718() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,404.0f,722.0f,0f,233.0f,0f,0f,0f,0f,0f,-4205.0f,-187.0f,781.0f,2218.0f,693.0f,243.0f,-1,0.7135259f,-0.20563543f,-0.29423434f,0f,0f,0f ) ;
  }

  @Test
  public void test719() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,40.72308f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-17.811861f,-48.38412f,-41.13193f,0f,0f,0f,1,42.057014f,-32.272266f,74.81181f,0f,0f,0f ) ;
  }

  @Test
  public void test720() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,4.0f,1081.0f,487.0f,-2103.0f,0f,0f,0f,0f,0f,1438.0f,1323.0f,-710.0f,242.0f,-2778.0f,-107.0f,-1,-0.6998999f,-0.5568109f,0.4475149f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test721() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-4.0f,219.0f,0f,1202.0f,0f,0f,0f,0f,0f,409.0f,-808.0f,368.0f,603.0f,456.0f,330.0f,5,3.32936f,5.1713433f,3.0421684f,0f,0f,0f ) ;
  }

  @Test
  public void test722() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-4.0f,96.0f,0f,-1913.0f,0f,0f,0f,0f,0f,-4121.0f,1039.0f,-1722.0f,719.0f,-975.0f,-581.0f,1,-1.2221472f,-0.11182909f,4.170854f,0f,0f,0f ) ;
  }

  @Test
  public void test723() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-41.07279f,-100.0f,0f,16.90065f,0f,0f,0f,0f,0f,-8.9507f,-7.651502f,-43.901474f,0f,0f,0f,1,62.720173f,-15.276737f,20.766806f,0f,0f,0f ) ;
  }

  @Test
  public void test724() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,41.0f,0.0f,0f,2344.0f,0f,0f,0f,0f,0f,-233.0f,429.0f,580.0f,458.0f,-107.0f,263.0f,4,-1.8833873f,0.04144227f,1.8902116f,0f,0f,0f ) ;
  }

  @Test
  public void test725() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,41.49975f,49.54326f,0f,0f,0f,0f,0f,0f,0f,-47.376614f,-6.2854877f,40.648033f,730.0f,-1195.0f,605.0f,1,99.99771f,-98.961334f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test726() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-42.06666f,-33.83327f,0f,0f,0f,0f,-72.47064f,100.0f,-69.76516f,100.0f,100.0f,-100.0f,0f,0f,0f,4,-72.16209f,100.0f,-70.672646f,0f,0f,0f ) ;
  }

  @Test
  public void test727() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,428.0f,1833.0f,0f,1405.0f,0f,0f,0f,0f,0f,-784.0f,-814.0f,57.0f,-732.0f,320.0f,-2.0f,7,0.45910835f,0.8875011f,0.039513778f,0f,0f,0f ) ;
  }

  @Test
  public void test728() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,437.0f,0.0f,0f,1483.0f,0f,0f,0f,0f,0f,408.0f,266.0f,-137.0f,1360.0f,-904.0f,1156.0f,-1,-55.92449f,18.210978f,-44.525864f,0f,0f,0f ) ;
  }

  @Test
  public void test729() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,43.92709f,-100.0f,0f,0f,0f,0f,0f,0f,0f,-67.0512f,-60.453777f,-100.0f,0f,0f,0f,1,-0.3232109f,0.9455995f,-0.0278528f,0f,0f,0f ) ;
  }

  @Test
  public void test730() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,445.0f,255.0f,0f,1091.0f,0f,0f,0f,0f,0f,-898.0f,-1330.0f,504.0f,-267.0f,-843.0f,-1920.0f,-1,1.5678872f,-0.14102904f,-1.137433f,0f,0f,0f ) ;
  }

  @Test
  public void test731() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,445.0f,530.0f,0f,864.0f,0f,0f,0f,0f,0f,-838.0f,-685.0f,-1065.0f,454.0f,830.0f,814.0f,1,88.06681f,99.34777f,-84.10752f,0f,0f,0f ) ;
  }

  @Test
  public void test732() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-45.08964f,18.450886f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,66.799324f,0f,0f,0f,1,0.571828f,0.34552562f,0.4971945f,0f,0f,0f ) ;
  }

  @Test
  public void test733() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,45.0f,44.0f,0f,963.0f,0f,0f,0f,0f,0f,252.0f,225.0f,-39.0f,159.0f,-144.0f,198.0f,3,-72.847595f,-88.958626f,39.596962f,0f,0f,0f ) ;
  }

  @Test
  public void test734() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-451.0f,179.0f,0f,-1447.0f,0f,0f,0f,0f,0f,-626.0f,-1139.0f,1244.0f,831.0f,-1513.0f,889.0f,1,-0.16622168f,-0.20837429f,-0.9509205f,0f,0f,0f ) ;
  }

  @Test
  public void test735() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-45.43525f,0f,0f,0f,0f,0f,0f,0f,0f,69.13798f,-100.0f,100.0f,0f,0f,0f,1,0.13315758f,-0.07299902f,-0.9493292f,0f,0f,0f ) ;
  }

  @Test
  public void test736() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-459.0f,1268.0f,0f,-870.0f,0f,0f,0f,0f,0f,558.0f,-1172.0f,362.0f,-78.0f,725.0f,256.0f,2,-51.010212f,100.0f,-85.38151f,0f,0f,0f ) ;
  }

  @Test
  public void test737() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,46.051464f,0.0f,0f,-8.548414f,0f,0f,0f,0f,0f,62.96463f,-8.768305f,33.012024f,0f,0f,0f,1,-77.36815f,-6.4679384f,9.349448f,0f,0f,0f ) ;
  }

  @Test
  public void test738() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,466.0f,1111.0f,0f,-1675.0f,0f,0f,0f,0f,0f,-1870.0f,-410.0f,482.0f,285.0f,307.0f,-133.0f,5,0.58168787f,-0.63305897f,-0.51075983f,0f,0f,0f ) ;
  }

  @Test
  public void test739() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,46.89f,0.0f,0f,59.502125f,0f,0f,0f,0f,0f,-100.0f,24.975462f,11.794491f,0f,0f,0f,1,0.15803477f,0.30212194f,0.2828016f,0f,0f,0f ) ;
  }

  @Test
  public void test740() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,469.0f,243.0f,0f,2.0f,0f,0f,0f,0f,0f,-145.0f,1742.0f,1179.0f,-2472.0f,1125.0f,-335.0f,2,0.6088588f,-2.8536124f,-3.7122567f,0f,0f,0f ) ;
  }

  @Test
  public void test741() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,480.0f,394.0f,0f,0.0f,0f,0f,0f,0f,0f,-483.0f,-365.0f,841.0f,187.0f,-196.0f,490.0f,2,100.0f,-100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test742() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-48.0f,1.0f,0f,392.0f,0f,0f,0f,0f,0f,388.0f,-1293.0f,392.0f,-52.0f,-1522.0f,-84.0f,2,52.32384f,86.468155f,61.251663f,0f,0f,0f ) ;
  }

  @Test
  public void test743() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-49.369434f,0.0f,0f,2.2623122f,0f,0f,0f,0f,0f,-72.94643f,-100.0f,56.103024f,0f,0f,0f,2,0.25399518f,-0.07239242f,-0.63931507f,0f,0f,0f ) ;
  }

  @Test
  public void test744() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-5.010711f,96.331215f,0f,0f,0f,0f,0f,0f,0f,-98.416176f,81.119965f,-41.372192f,-478.0f,-1068.0f,-957.0f,1,100.0f,98.06068f,119.06434f,0f,0f,0f ) ;
  }

  @Test
  public void test745() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-503.0f,217.0f,0f,382.0f,0f,0f,0f,0f,0f,106.0f,-1410.0f,869.0f,-2375.0f,1478.0f,462.0f,2,0.41856807f,0.5783755f,0.27642193f,0f,0f,0f ) ;
  }

  @Test
  public void test746() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-5.037373f,0.73719734f,0f,0f,0f,0f,0f,0f,0f,-55.296207f,-34.58265f,-5.014992f,1410.0f,-176.0f,834.0f,1,-0.049451485f,0.3208726f,-0.31306082f,0f,0f,0f ) ;
  }

  @Test
  public void test747() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,507.0f,1224.0f,0f,1041.0f,0f,0f,0f,0f,0f,10.0f,2312.0f,-90.0f,1744.0f,-88.0f,-878.0f,5,0.41736048f,-0.059898116f,-0.37269923f,0f,0f,0f ) ;
  }

  @Test
  public void test748() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-5.0f,-1.0f,0f,326.0f,0f,0f,0f,0f,0f,-495.0f,3001.0f,-454.0f,-246.0f,-1359.0f,-56.0f,2,0.27770567f,-0.946059f,0.16971296f,0f,0f,0f ) ;
  }

  @Test
  public void test749() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,513.0f,820.0f,0f,278.0f,0f,0f,0f,0f,0f,-456.0f,2453.0f,484.0f,108.0f,-279.0f,-136.0f,3,44.12076f,-30.232328f,57.74976f,0f,0f,0f ) ;
  }

  @Test
  public void test750() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-515.0f,-181.0f,0f,822.0f,0f,0f,0f,0f,0f,776.0f,459.0f,289.0f,199.0f,-410.0f,426.0f,2,-28.52228f,-12.574217f,-25.221148f,0f,0f,0f ) ;
  }

  @Test
  public void test751() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,51.64882f,100.0f,0f,0f,0f,0f,0f,0f,0f,-5.464298f,-100.0f,14.699853f,-694.0f,-25.0f,1310.0f,1,-100.0f,100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test752() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-520.0f,33.0f,0f,-941.0f,0f,0f,0f,0f,0f,887.0f,349.0f,234.0f,908.0f,445.0f,-679.0f,1,-21.617254f,-49.86032f,30.964407f,0f,0f,0f ) ;
  }

  @Test
  public void test753() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,52.182842f,-29.864674f,0f,7.2484865f,0f,0f,0f,0f,0f,51.923313f,6.1517076f,36.28316f,0f,0f,0f,1,29.439562f,-14.985093f,-90.17217f,0f,0f,0f ) ;
  }

  @Test
  public void test754() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,5.2273474f,-76.38082f,0f,0f,0f,0f,0f,0f,0f,-99.90996f,-56.38127f,44.5267f,0f,0f,0f,1,0.6233415f,-0.35899776f,-0.6946697f,0f,0f,0f ) ;
  }

  @Test
  public void test755() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,524.0f,192.0f,0f,1381.0f,0f,0f,0f,0f,0f,419.0f,590.0f,-60.0f,1015.0f,-913.0f,-1873.0f,-2,0.57612413f,-0.67026335f,-0.87041867f,0f,0f,0f ) ;
  }

  @Test
  public void test756() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-534.0f,-875.0f,595.0f,483.0f,0f,0f,0f,0f,0f,275.0f,236.0f,658.0f,858.0f,-642.0f,776.0f,-816,-16.370964f,-21.721746f,12.611259f,-66.8884f,76.12276f,0f ) ;
  }

  @Test
  public void test757() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,53.881287f,-6.0129356f,0f,0f,0f,0f,0f,0f,0f,-75.78434f,74.939766f,100.0f,0f,0f,0f,1,0.81456494f,0.42036945f,-0.24078226f,0f,0f,0f ) ;
  }

  @Test
  public void test758() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,53.985325f,43.917957f,0f,8.156247f,0f,0f,0f,0f,0f,-95.68027f,-51.373234f,-80.80938f,0f,0f,0f,1,0.593932f,-0.060241792f,-0.1692473f,0f,0f,0f ) ;
  }

  @Test
  public void test759() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,540.0f,2004.0f,0f,1886.0f,0f,0f,0f,0f,0f,477.0f,-2262.0f,-732.0f,714.0f,-2010.0f,-824.0f,1,-0.08537156f,-0.021189699f,0.15346812f,0f,0f,0f ) ;
  }

  @Test
  public void test760() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,54.604855f,0.0f,0f,-18.760418f,0f,0f,0f,0f,0f,91.101036f,89.14106f,-94.829506f,0f,0f,0f,1,0.3949764f,0.079685554f,0.62514454f,0f,0f,0f ) ;
  }

  @Test
  public void test761() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-5.480472f,0.0f,0f,0f,0f,0f,0f,0f,0f,98.95878f,-100.0f,-99.95428f,0f,0f,0f,1,0.044691302f,-0.028159684f,0.4155112f,0f,0f,0f ) ;
  }

  @Test
  public void test762() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-54.84212f,-91.37235f,0f,0f,0f,0f,0f,0f,0f,28.215286f,11.253239f,-72.54719f,0f,0f,0f,1,0.020733474f,0.3142847f,0.49046198f,0f,0f,0f ) ;
  }

  @Test
  public void test763() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-55.33627f,-100.0f,0f,-5.5976906f,0f,0f,0f,0f,0f,-170.28546f,-72.393845f,-100.0f,0f,0f,0f,1,4.7462234f,-15.623435f,55.267704f,0f,0f,0f ) ;
  }

  @Test
  public void test764() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,55.398216f,34.304176f,0f,0f,0f,0f,0f,0f,0f,-71.064095f,57.814537f,-85.72755f,-1089.0f,357.0f,173.0f,1,153.3557f,-100.0f,99.58244f,0f,0f,0f ) ;
  }

  @Test
  public void test765() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,55.556446f,0.0f,0f,-83.551384f,0f,0f,0f,0f,0f,-78.35067f,-84.08679f,40.29268f,0f,0f,0f,1,-86.48964f,95.45961f,-32.573784f,0f,0f,0f ) ;
  }

  @Test
  public void test766() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-5.575182f,16.174212f,0f,-1.5777218E-30f,0f,0f,0f,0f,0f,100.0f,100.0f,-97.710075f,0f,0f,0f,1,-0.9718551f,-0.22402857f,0.07286169f,0f,0f,0f ) ;
  }

  @Test
  public void test767() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,55.774788f,8.621055f,0f,0f,0f,0f,0f,0f,0f,93.017525f,70.28923f,-16.384737f,0f,0f,0f,1,-0.06953344f,-44.208527f,11.359328f,0f,0f,0f ) ;
  }

  @Test
  public void test768() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-56.105255f,23.329744f,0f,0f,0f,0f,0f,0f,0f,-45.15822f,12.71614f,-38.77346f,-1025.0f,366.0f,595.0f,2,49.330776f,-158.04855f,96.85063f,0f,0f,0f ) ;
  }

  @Test
  public void test769() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-57.341797f,100.0f,0f,0f,0f,0f,0f,0f,0f,96.71056f,-100.0f,27.878784f,868.0f,-1149.0f,-2079.0f,1,-0.20671105f,-0.1000144f,0.051972702f,0f,0f,0f ) ;
  }

  @Test
  public void test770() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,57.600388f,47.040405f,0f,0f,0f,0f,0f,0f,0f,-1.1103915f,82.388306f,69.782524f,859.0f,947.0f,-321.0f,1,-3.708211f,2.2994428f,-2.7738354f,0f,0f,0f ) ;
  }

  @Test
  public void test771() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-58.43813f,0.0f,0f,7.274796f,0f,0f,0f,0f,0f,27.371695f,-168.80072f,85.71225f,0f,0f,0f,1,66.031944f,86.87057f,-9.873281f,0f,0f,0f ) ;
  }

  @Test
  public void test772() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-590.0f,0.0f,0f,157.0f,0f,0f,0f,0f,0f,779.0f,457.0f,912.0f,-698.0f,363.0f,-50.0f,5,100.0f,-100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test773() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-591.0f,-392.0f,698.0f,5.0f,0f,0f,0f,0f,0f,-659.0f,858.0f,-30.0f,-822.0f,405.0f,318.0f,-418,-27.527262f,60.049435f,-30.444792f,92.22199f,0f,0f ) ;
  }

  @Test
  public void test774() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-595.0f,1.0f,0f,353.0f,0f,0f,0f,0f,0f,1328.0f,833.0f,248.0f,528.0f,-839.0f,-11.0f,-2,-20.7204f,44.184883f,-125.002716f,0f,0f,0f ) ;
  }

  @Test
  public void test775() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-609.0f,3226.0f,-434.0f,0.0f,0f,0f,0f,0f,0f,260.0f,-41.0f,-570.0f,1433.0f,254.0f,-1378.0f,-2,-33.733856f,14.460024f,94.67565f,58.32698f,0f,0f ) ;
  }

  @Test
  public void test776() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-6.0f,262.0f,0f,-1.0f,0f,0f,0f,0f,0f,79.0f,-216.0f,1303.0f,380.0f,993.0f,-818.0f,2,100.0f,-92.65487f,-88.18213f,0f,0f,0f ) ;
  }

  @Test
  public void test777() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-611.0f,512.0f,0f,602.0f,0f,0f,0f,0f,0f,42.0f,-603.0f,-1053.0f,-621.0f,1158.0f,-177.0f,-1,-89.34577f,80.727516f,23.766762f,0f,0f,0f ) ;
  }

  @Test
  public void test778() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-61.262413f,-33.771725f,0f,0.0f,0f,0f,0f,0f,0f,68.550476f,38.716755f,-80.340454f,0f,0f,0f,1,45.043037f,39.83943f,92.70482f,0f,0f,0f ) ;
  }

  @Test
  public void test779() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,6.192487E-4f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-61.21101f,65.5573f,27.07967f,0f,0f,0f,1,0.97148776f,-0.13414884f,-0.017404804f,0f,0f,0f ) ;
  }

  @Test
  public void test780() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,62.812313f,-10.201407f,0f,0f,0f,0f,0f,0f,0f,-7.227687f,-27.164553f,-73.85279f,0f,0f,0f,1,-19.666374f,-78.31558f,193.7602f,0f,0f,0f ) ;
  }

  @Test
  public void test781() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-6.2910595f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,49.00384f,-100.0f,-71.53332f,0f,0f,0f,1,-0.94341826f,-0.10261029f,0.3087227f,0f,0f,0f ) ;
  }

  @Test
  public void test782() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,630.0f,699.0f,0f,1.0f,0f,0f,0f,0f,0f,-593.0f,106.0f,-758.0f,-485.0f,870.0f,-943.0f,2,36.444603f,-100.0f,14.646685f,0f,0f,0f ) ;
  }

  @Test
  public void test783() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,63.28037f,0.0f,0f,0f,0f,0f,0f,0f,0f,-41.461227f,55.583305f,-91.16094f,0f,0f,0f,1,39.590378f,-6.488647f,-8.028659f,0f,0f,0f ) ;
  }

  @Test
  public void test784() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-63.359745f,0f,0f,0f,0f,0f,0f,0f,0f,-59.581295f,-95.81898f,-42.95532f,0f,0f,0f,1,-46.426933f,81.65216f,-70.55873f,0f,0f,0f ) ;
  }

  @Test
  public void test785() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,63.372585f,32.888966f,0f,0f,0f,0f,0f,0f,0f,-87.73465f,-17.877691f,-58.68273f,-94.0f,-1551.0f,-136.0f,1,-76.59964f,47.717842f,99.99999f,0f,0f,0f ) ;
  }

  @Test
  public void test786() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-63.48829f,-100.0f,0f,-39.9006f,0f,0f,0f,0f,0f,-7.5866256f,-115.27219f,14.851753f,0f,0f,0f,1,-48.939877f,73.5289f,63.298504f,0f,0f,0f ) ;
  }

  @Test
  public void test787() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,638.0f,-946.0f,0f,911.0f,0f,0f,0f,0f,0f,-92.0f,272.0f,149.0f,1789.0f,807.0f,-369.0f,1,-63.474396f,-100.0f,61.743896f,0f,0f,0f ) ;
  }

  @Test
  public void test788() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-640.0f,233.0f,692.0f,-105.0f,0f,0f,0f,0f,0f,70.0f,-475.0f,983.0f,-538.0f,381.0f,-988.0f,-459,50.02653f,-86.924286f,-47.27278f,39.874683f,0f,0f ) ;
  }

  @Test
  public void test789() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-64.0f,0.0f,0f,1220.0f,0f,0f,0f,0f,0f,482.0f,196.0f,-113.0f,369.0f,-432.0f,828.0f,-1,17.218689f,-100.0f,76.632675f,0f,0f,0f ) ;
  }

  @Test
  public void test790() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-641.0f,2.0f,0f,-1000.0f,0f,0f,76.0f,-236.0f,72.0f,2268.0f,-895.0f,-359.0f,0f,0f,0f,8,95.535255f,-224.8647f,81.08058f,0f,0f,0f ) ;
  }

  @Test
  public void test791() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-646.0f,-1484.0f,0f,406.0f,0f,0f,0f,0f,0f,203.0f,565.0f,-127.0f,799.0f,-395.0f,-567.0f,1,98.08154f,-60.68639f,76.13359f,0f,0f,0f ) ;
  }

  @Test
  public void test792() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,64.69623f,0.0f,0f,81.95774f,0f,0f,0f,0f,0f,-158.82446f,31.63474f,-8.344208f,0f,0f,0f,1,9.487329f,-61.157753f,-38.504337f,0f,0f,0f ) ;
  }

  @Test
  public void test793() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,659.0f,36.0f,28.0f,-847.0f,0f,0f,0f,0f,0f,-670.0f,417.0f,507.0f,-574.0f,92.0f,342.0f,-164,-54.75976f,19.060581f,32.723305f,-76.98766f,0f,0f ) ;
  }

  @Test
  public void test794() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,66.40736f,0.0f,0f,-99.21165f,0f,0f,0f,0f,0f,-100.0f,-65.78002f,104.69512f,0f,0f,0f,1,-0.047209434f,0.67190874f,-0.057848487f,0f,0f,0f ) ;
  }

  @Test
  public void test795() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,66.71153f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,78.47831f,16.36584f,19.697649f,0f,0f,0f,1,-41.555634f,37.968315f,119.916504f,0f,0f,0f ) ;
  }

  @Test
  public void test796() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-673.0f,-6.0f,0f,65.0f,0f,0f,0f,0f,0f,525.0f,235.0f,-199.0f,-366.0f,-498.0f,-1553.0f,1,-58.456585f,35.492924f,5.729015f,0f,0f,0f ) ;
  }

  @Test
  public void test797() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,675.0f,407.0f,0f,468.0f,0f,0f,0f,0f,0f,800.0f,-203.0f,-1592.0f,1674.0f,-1201.0f,-288.0f,-3,-100.0f,-45.560963f,-44.441647f,0f,0f,0f ) ;
  }

  @Test
  public void test798() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-67.55055f,1.8088745f,0f,0f,0f,0f,0f,0f,0f,45.29335f,15.631354f,6.9368715f,752.0f,118.0f,884.0f,1,3.126526f,-8.367187f,-1.5598625f,0f,0f,0f ) ;
  }

  @Test
  public void test799() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,679.0f,-1.0f,0f,505.0f,0f,0f,0f,0f,0f,-234.0f,527.0f,-970.0f,406.0f,-1358.0f,858.0f,1,55.28074f,-74.154274f,-9.83397f,0f,0f,0f ) ;
  }

  @Test
  public void test800() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,681.0f,-481.0f,0f,635.0f,0f,0f,0f,0f,0f,293.0f,-1252.0f,1247.0f,-878.0f,-1692.0f,314.0f,-1,0.1606354f,-0.07623328f,-0.9840654f,0f,0f,0f ) ;
  }

  @Test
  public void test801() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-692.0f,1326.0f,0f,0.0f,0f,0f,0f,0f,0f,251.0f,-478.0f,-197.0f,-1108.0f,1055.0f,544.0f,2,98.57649f,67.79824f,17.762156f,0f,0f,0f ) ;
  }

  @Test
  public void test802() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-69.287674f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-89.79992f,-13.518723f,-19.214783f,0f,0f,0f,1,0.1872557f,0.61157745f,0.7687056f,0f,0f,0f ) ;
  }

  @Test
  public void test803() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-69.37176f,0.0f,0f,0f,0f,0f,0f,0f,0f,25.44687f,-93.71875f,35.40855f,0f,0f,0f,1,-51.333984f,90.77919f,-2.1502795f,0f,0f,0f ) ;
  }

  @Test
  public void test804() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,69.698395f,-86.39152f,0f,-72.2063f,0f,0f,0f,0f,0f,-30.030216f,11.001904f,-84.989586f,0f,0f,0f,1,0.7926748f,-0.18642037f,0.580443f,0f,0f,0f ) ;
  }

  @Test
  public void test805() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-703.0f,243.0f,-481.0f,2.0f,0f,0f,0f,0f,0f,598.0f,-1690.0f,1035.0f,188.0f,-494.0f,-593.0f,-4,0.04336035f,0.24970911f,-0.87290174f,-93.979805f,0f,0f ) ;
  }

  @Test
  public void test806() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,7.1054274E-15f,-100.0f,0f,-5.1689014f,0f,0f,0f,0f,0f,38.940376f,-2.7629364f,-14.152578f,0f,0f,0f,1,0.16656923f,-2.4687918E-4f,0.86361367f,0f,0f,0f ) ;
  }

  @Test
  public void test807() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,712.0f,755.0f,0f,-1.0f,0f,0f,0f,0f,0f,-837.0f,347.0f,761.0f,591.0f,-1793.0f,-1134.0f,2,0.001153066f,-0.27189836f,-0.37494394f,0f,0f,0f ) ;
  }

  @Test
  public void test808() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-718.0f,-658.0f,0f,1141.0f,0f,0f,0f,0f,0f,675.0f,1265.0f,772.0f,969.0f,-3721.0f,678.0f,1,-0.28063342f,-0.4832247f,-0.6858396f,0f,0f,0f ) ;
  }

  @Test
  public void test809() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,72.19729f,15.764415f,0f,0f,0f,0f,0f,0f,0f,1.1271087f,85.986984f,-5.7758245f,-853.0f,-1739.0f,-610.0f,2,100.0f,-1.179902f,19.83079f,0f,0f,0f ) ;
  }

  @Test
  public void test810() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,722.0f,-92.0f,0f,262.0f,0f,0f,0f,0f,0f,-1044.0f,-988.0f,565.0f,-1617.0f,-718.0f,1317.0f,3,100.0f,66.93061f,13.396251f,0f,0f,0f ) ;
  }

  @Test
  public void test811() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,72.22437f,0.0f,0f,0f,0f,0f,0f,0f,0f,-9.836289f,-5.4869328f,-36.46492f,0f,0f,0f,1,44.621178f,11.937158f,-8.273199f,0f,0f,0f ) ;
  }

  @Test
  public void test812() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,7.304267f,0.0f,0f,100.0f,0f,0f,0f,0f,0f,-13.43175f,-154.51909f,-100.0f,0f,0f,0f,1,80.58248f,85.58072f,-20.976372f,0f,0f,0f ) ;
  }

  @Test
  public void test813() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,731.0f,-964.0f,0f,441.0f,0f,0f,0f,0f,0f,-545.0f,672.0f,-461.0f,-569.0f,624.0f,1582.0f,13,0.9385379f,-0.3693274f,2.2637386f,0f,0f,0f ) ;
  }

  @Test
  public void test814() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,73.439926f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,-100.0f,-11.707163f,0f,0f,0f,2,-0.7354524f,-0.17202441f,0.2949728f,0f,0f,0f ) ;
  }

  @Test
  public void test815() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-74.02557f,-64.278984f,0f,0.0f,0f,0f,0f,0f,0f,-67.60217f,-15.896442f,63.301495f,0f,0f,0f,1,0.5000001f,-0.02955854f,-0.7339042f,0f,0f,0f ) ;
  }

  @Test
  public void test816() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,741.0f,-707.0f,0f,949.0f,0f,0f,0f,0f,0f,904.0f,-1396.0f,-882.0f,232.0f,791.0f,940.0f,-2,11.409925f,-1.5509042f,42.83973f,0f,0f,0f ) ;
  }

  @Test
  public void test817() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-742.0f,0.0f,0f,254.0f,0f,0f,0f,0f,0f,2729.0f,607.0f,559.0f,492.0f,1544.0f,-1659.0f,1,-36.695786f,25.922804f,-48.356327f,0f,0f,0f ) ;
  }

  @Test
  public void test818() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,743.0f,-363.0f,0f,496.0f,0f,0f,0f,0f,0f,-212.0f,855.0f,-855.0f,421.0f,1185.0f,-889.0f,1,14.553178f,43.241764f,41.26138f,0f,0f,0f ) ;
  }

  @Test
  public void test819() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-74.34227f,-20.682642f,0f,-87.00943f,0f,0f,0f,0f,0f,5.6332965f,-97.80552f,37.510994f,0f,0f,0f,1,-0.30237085f,0.12208616f,-0.75545126f,0f,0f,0f ) ;
  }

  @Test
  public void test820() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,75.0f,-8.0f,0f,698.0f,0f,0f,0f,0f,0f,487.0f,131.0f,2793.0f,-47.0f,1378.0f,-3469.0f,-2,-0.6125362f,-0.75748765f,-0.22585809f,0f,0f,0f ) ;
  }

  @Test
  public void test821() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,751.0f,0.0f,0f,175.0f,0f,0f,0f,0f,0f,-136.0f,-353.0f,-174.0f,695.0f,-187.0f,-19.0f,1,55.131012f,100.0f,-10.0515f,0f,0f,0f ) ;
  }

  @Test
  public void test822() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-758.0f,0.0f,0f,1125.0f,0f,0f,0f,0f,0f,-13.0f,163.0f,727.0f,1243.0f,-882.0f,220.0f,4,-99.03002f,-12.346796f,-8.301107f,0f,0f,0f ) ;
  }

  @Test
  public void test823() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-759.0f,0.0f,0f,1018.0f,0f,0f,0f,0f,0f,910.0f,232.0f,-1107.0f,1308.0f,1295.0f,-221.0f,1,-63.429585f,-84.33796f,41.226307f,0f,0f,0f ) ;
  }

  @Test
  public void test824() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-762.0f,846.0f,0f,782.0f,0f,0f,0f,0f,0f,-680.0f,445.0f,-131.0f,-461.0f,-698.0f,-729.0f,-1,66.164055f,-71.17165f,-82.793304f,0f,0f,0f ) ;
  }

  @Test
  public void test825() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-76.26891f,0.0f,0f,-99.27806f,0f,0f,0f,0f,0f,-5.25326f,171.55556f,96.58653f,0f,0f,0f,1,-68.05871f,-86.68777f,-20.06892f,0f,0f,0f ) ;
  }

  @Test
  public void test826() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,764.0f,-3.0f,0f,670.0f,0f,0f,0f,0f,0f,-415.0f,26.0f,-1268.0f,310.0f,-2.0f,-359.0f,7,-1.1187289f,-0.41520888f,0.59249514f,0f,0f,0f ) ;
  }

  @Test
  public void test827() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-76.76259f,14.980116f,0f,0f,0f,0f,0f,0f,0f,-50.11307f,-51.941135f,18.201136f,143.0f,-1112.0f,-2326.0f,1,-78.27998f,86.48684f,31.28234f,0f,0f,0f ) ;
  }

  @Test
  public void test828() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-77.85266f,30.978834f,0f,0f,0f,0f,0f,0f,0f,-44.092762f,-0.6873932f,-21.740484f,-225.0f,137.0f,452.0f,1,47.776794f,23.769802f,-2.1425457f,0f,0f,0f ) ;
  }

  @Test
  public void test829() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-78.173584f,100.0f,0f,19.700432f,0f,0f,0f,0f,0f,-73.49398f,-100.0f,1.345168f,0f,0f,0f,1,0.6981447f,-0.48917663f,0.2250906f,0f,0f,0f ) ;
  }

  @Test
  public void test830() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,78.42692f,0f,0f,0f,0f,0f,0f,0f,0f,-110.05237f,-127.26991f,60.205475f,0f,0f,0f,1,-34.750263f,117.21435f,79.45848f,0f,0f,0f ) ;
  }

  @Test
  public void test831() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,786.0f,1.0f,0f,1215.0f,0f,0f,0f,0f,0f,565.0f,-559.0f,57.0f,-495.0f,-467.0f,332.0f,-2,48.878025f,100.0f,82.56421f,0f,0f,0f ) ;
  }

  @Test
  public void test832() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,78.97425f,0.0f,0f,-70.79126f,0f,0f,0f,0f,0f,40.674778f,44.445145f,-70.9897f,0f,0f,0f,1,82.81613f,29.094055f,73.17565f,0f,0f,0f ) ;
  }

  @Test
  public void test833() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,79.0f,847.0f,0f,28.0f,0f,0f,0f,0f,0f,-923.0f,-267.0f,-1650.0f,454.0f,184.0f,778.0f,2,-0.053724665f,0.24013531f,0.388422f,0f,0f,0f ) ;
  }

  @Test
  public void test834() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-79.20121f,100.0f,0f,0f,0f,0f,0f,0f,0f,-48.343567f,8.182777f,20.233171f,1647.0f,1899.0f,-695.0f,2,0.09913392f,-0.74474406f,-0.44375995f,0f,0f,0f ) ;
  }

  @Test
  public void test835() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,79.225845f,-40.252026f,0f,-24.17783f,0f,0f,0f,0f,0f,-51.807446f,-78.17563f,1.243187f,0f,0f,0f,1,85.69621f,24.315886f,-1.3663381f,0f,0f,0f ) ;
  }

  @Test
  public void test836() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-799.0f,115.0f,0f,1245.0f,0f,0f,0f,0f,0f,678.0f,317.0f,1567.0f,900.0f,128.0f,-415.0f,4,-0.8856979f,0.22686926f,0.080426574f,0f,0f,0f ) ;
  }

  @Test
  public void test837() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,80.07944f,-7.036326f,0f,39.170063f,0f,0f,0f,0f,0f,29.155575f,10.736026f,-25.97639f,0f,0f,0f,1,-15.987468f,135.67336f,47.079575f,0f,0f,0f ) ;
  }

  @Test
  public void test838() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-801.0f,378.0f,986.0f,693.0f,0f,0f,0f,0f,0f,757.0f,-854.0f,-306.0f,987.0f,234.0f,330.0f,-556,23.744177f,45.469677f,97.39458f,-82.92949f,0f,0f ) ;
  }

  @Test
  public void test839() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-80.13113f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-14.086657f,-100.0f,0f,0f,0f,1,0.239662f,-0.04326902f,0.3657715f,0f,0f,0f ) ;
  }

  @Test
  public void test840() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,802.0f,2.0f,0f,2589.0f,0f,0f,0f,0f,0f,-390.0f,1266.0f,-1142.0f,-464.0f,-1476.0f,795.0f,1,1.0389677f,0.46935323f,0.4381525f,0f,0f,0f ) ;
  }

  @Test
  public void test841() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-806.0f,-553.0f,0f,871.0f,0f,0f,0f,0f,0f,-652.0f,351.0f,-686.0f,-769.0f,-342.0f,557.0f,1,2.2091475f,-1.559479f,-0.109626345f,0f,0f,0f ) ;
  }

  @Test
  public void test842() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-8.070859f,-76.31194f,0f,-114.03328f,0f,0f,0f,0f,0f,8.448538f,-5.8775353f,14.896382f,0f,0f,0f,1,-10.932503f,100.0f,0.81628346f,0f,0f,0f ) ;
  }

  @Test
  public void test843() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,809.0f,-299.0f,0f,771.0f,0f,0f,0f,0f,0f,-1317.0f,504.0f,267.0f,897.0f,694.0f,537.0f,1,99.7767f,12.070161f,26.810265f,0f,0f,0f ) ;
  }

  @Test
  public void test844() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-809.0f,-806.0f,0f,681.0f,0f,0f,0f,0f,0f,-909.0f,-131.0f,233.0f,890.0f,449.0f,480.0f,4,42.72995f,79.81829f,139.20648f,0f,0f,0f ) ;
  }

  @Test
  public void test845() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-8.0f,432.0f,0f,315.0f,0f,0f,0f,0f,0f,-592.0f,781.0f,955.0f,62.0f,-745.0f,1502.0f,3,-80.20487f,-14.039524f,-40.734f,0f,0f,0f ) ;
  }

  @Test
  public void test846() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-8.0f,5.0f,0f,2069.0f,0f,0f,0f,0f,0f,748.0f,1851.0f,970.0f,2187.0f,-975.0f,171.0f,2,-0.979498f,5.0582438f,-15.3860655f,0f,0f,0f ) ;
  }

  @Test
  public void test847() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-815.0f,314.0f,0f,1427.0f,0f,0f,0f,0f,0f,-572.0f,733.0f,119.0f,-906.0f,-856.0f,921.0f,1,-100.0f,-96.38547f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test848() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,818.0f,-116.0f,793.0f,-344.0f,0f,0f,0f,0f,0f,-345.0f,377.0f,-875.0f,-752.0f,-538.0f,-115.0f,164,-89.320335f,30.24163f,-43.961834f,-99.43509f,0f,0f ) ;
  }

  @Test
  public void test849() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-81.835785f,46.44542f,0f,0f,0f,0f,0f,0f,0f,120.29826f,-52.68939f,5.449861f,1355.0f,394.0f,638.0f,1,-74.5771f,25.507309f,-6.4605017f,0f,0f,0f ) ;
  }

  @Test
  public void test850() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,81.93926f,-62.177986f,0f,-7.126495f,0f,0f,0f,0f,0f,-58.08365f,-97.00091f,64.46478f,0f,0f,0f,1,-0.30773485f,0.85761595f,0.40105218f,0f,0f,0f ) ;
  }

  @Test
  public void test851() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-829.0f,-1.0f,0f,208.0f,0f,0f,0f,0f,0f,619.0f,384.0f,577.0f,-1192.0f,-231.0f,-871.0f,3,-78.045395f,-47.7792f,-30.705313f,0f,0f,0f ) ;
  }

  @Test
  public void test852() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-830.0f,-136.0f,233.0f,276.0f,0f,0f,0f,0f,0f,162.0f,-255.0f,-524.0f,367.0f,940.0f,180.0f,-452,-98.33142f,-91.636024f,-7.530273f,-4.9302845f,-55.872295f,0f ) ;
  }

  @Test
  public void test853() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,83.04705f,0f,0f,0f,0f,0f,0f,0f,0f,10.36931f,42.873905f,72.9377f,0f,0f,0f,1,-3.702505f,44.084915f,-62.246944f,0f,0f,0f ) ;
  }

  @Test
  public void test854() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-834.0f,1.0f,0f,1096.0f,0f,0f,0f,0f,0f,696.0f,789.0f,-2848.0f,1290.0f,932.0f,1625.0f,2,0.04893203f,0.1802601f,0.41054726f,0f,0f,0f ) ;
  }

  @Test
  public void test855() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-83.62265f,0f,0f,0f,0f,0f,0f,0f,0f,-99.01434f,79.51503f,-84.81522f,0f,0f,0f,1,0.73933685f,0.44907126f,-0.25682822f,0f,0f,0f ) ;
  }

  @Test
  public void test856() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-83.768295f,63.341404f,0f,0f,0f,0f,0f,0f,0f,52.103065f,-8.475395f,37.35534f,-97.0f,833.0f,221.0f,3,-82.52737f,89.7544f,-89.967995f,0f,0f,0f ) ;
  }

  @Test
  public void test857() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,846.0f,1271.0f,0f,260.0f,0f,0f,0f,0f,0f,1116.0f,391.0f,-1339.0f,-956.0f,-428.0f,105.0f,3,-42.62273f,-77.55368f,-57.142265f,0f,0f,0f ) ;
  }

  @Test
  public void test858() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,846.0f,-920.0f,792.0f,-614.0f,0f,0f,0f,0f,0f,848.0f,-904.0f,-937.0f,177.0f,-242.0f,772.0f,230,3.247718f,85.801735f,-53.01421f,-77.48201f,21.880669f,0f ) ;
  }

  @Test
  public void test859() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,847.0f,-517.0f,0f,2534.0f,0f,0f,0f,0f,0f,-1503.0f,409.0f,70.0f,-230.0f,-752.0f,-545.0f,-1,136.57195f,-52.779785f,-41.315475f,0f,0f,0f ) ;
  }

  @Test
  public void test860() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,852.0f,-1472.0f,0f,23.0f,0f,0f,0f,0f,0f,70.0f,-423.0f,698.0f,753.0f,357.0f,141.0f,1,11.36567f,-46.122414f,-69.621124f,0f,0f,0f ) ;
  }

  @Test
  public void test861() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,857.0f,-843.0f,321.0f,354.0f,0f,0f,0f,0f,0f,419.0f,50.0f,38.0f,-818.0f,-34.0f,768.0f,385,-7.3258114f,79.114555f,24.530216f,47.66028f,0f,0f ) ;
  }

  @Test
  public void test862() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-86.30247f,68.644485f,0f,0f,0f,0f,0f,0f,0f,39.487522f,-22.166468f,-77.438576f,0f,0f,0f,1,-1.4630371f,46.03355f,65.859825f,0f,0f,0f ) ;
  }

  @Test
  public void test863() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-865.0f,-1150.0f,0f,1093.0f,0f,0f,0f,0f,0f,-833.0f,-754.0f,-6.0f,894.0f,215.0f,-600.0f,2,0.4847002f,0.11479601f,-0.86711454f,0f,0f,0f ) ;
  }

  @Test
  public void test864() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,86.95372f,32.719685f,0f,-100.0f,0f,0f,0f,0f,0f,64.40155f,34.931725f,76.467064f,0f,0f,0f,1,0.03407217f,-0.22243544f,0.0162966f,0f,0f,0f ) ;
  }

  @Test
  public void test865() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-87.04856f,100.0f,0f,0f,0f,0f,0f,0f,0f,13.202738f,71.12682f,-100.0f,0f,0f,0f,1,-0.48058704f,0.65787655f,0.5798573f,0f,0f,0f ) ;
  }

  @Test
  public void test866() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,87.26059f,3.1566331f,0f,0.0f,0f,0f,0f,0f,0f,-35.544815f,-56.74812f,90.165924f,0f,0f,0f,1,0.003042719f,0.5816227f,0.16544954f,0f,0f,0f ) ;
  }

  @Test
  public void test867() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,873.0f,-4357.0f,0f,188.0f,0f,0f,0f,0f,0f,-684.0f,646.0f,762.0f,-1562.0f,-491.0f,-2593.0f,4,0.14811797f,-0.0150677655f,-0.9888549f,0f,0f,0f ) ;
  }

  @Test
  public void test868() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-882.0f,6.0f,0f,1301.0f,0f,0f,0f,0f,0f,-523.0f,780.0f,944.0f,149.0f,591.0f,-406.0f,3,-0.45688832f,0.5379282f,-0.99659556f,0f,0f,0f ) ;
  }

  @Test
  public void test869() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,883.0f,-326.0f,0f,539.0f,0f,0f,0f,0f,0f,986.0f,339.0f,849.0f,1077.0f,773.0f,886.0f,1,-100.0f,-76.0109f,-74.04148f,0f,0f,0f ) ;
  }

  @Test
  public void test870() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-88.70805f,2.9196343f,0f,0f,0f,0f,0f,0f,0f,-23.589483f,-35.720642f,-29.132746f,-31.0f,310.0f,-355.0f,1,1.2836212f,24.892881f,66.26007f,0f,0f,0f ) ;
  }

  @Test
  public void test871() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-88.884094f,-71.32996f,0f,0f,0f,0f,0f,0f,0f,20.46124f,-24.335817f,-30.380018f,0f,0f,0f,1,-57.07169f,66.809296f,-45.419666f,0f,0f,0f ) ;
  }

  @Test
  public void test872() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-889.0f,1531.0f,29.0f,-656.0f,0f,0f,0f,0f,0f,-542.0f,-974.0f,1455.0f,-215.0f,-1006.0f,-238.0f,1,0.11761226f,0.013866746f,-0.3953036f,-110.739944f,0f,0f ) ;
  }

  @Test
  public void test873() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-88.975266f,-58.80176f,0f,0f,0f,0f,0f,0f,0f,-7.055623f,-83.10117f,-12.1497755f,0f,0f,0f,1,1.1782368f,44.200073f,-11.058534f,0f,0f,0f ) ;
  }

  @Test
  public void test874() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,89.0f,1146.0f,0f,689.0f,0f,0f,0f,0f,0f,96.0f,271.0f,274.0f,99.0f,133.0f,-166.0f,3,-0.851604f,-3.1516829f,-3.8267562f,0f,0f,0f ) ;
  }

  @Test
  public void test875() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-891.0f,782.0f,0f,2607.0f,0f,0f,0f,0f,0f,587.0f,-565.0f,24.0f,471.0f,-195.0f,-973.0f,1,-144.31061f,30.133507f,77.039825f,0f,0f,0f ) ;
  }

  @Test
  public void test876() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,89.1685f,183.21764f,0f,0f,0f,0f,0f,0f,0f,109.70889f,-100.647514f,-47.22304f,1474.0f,-912.0f,1856.0f,1,21.626307f,50.69449f,-0.40999782f,0f,0f,0f ) ;
  }

  @Test
  public void test877() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-8.988568f,0.0f,0f,-97.03878f,0f,0f,0f,0f,0f,29.19712f,59.54819f,-78.85601f,0f,0f,0f,1,0.71382356f,0.21499908f,0.6665068f,0f,0f,0f ) ;
  }

  @Test
  public void test878() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,90.0f,0.0f,0f,408.0f,0f,0f,0f,0f,0f,-497.0f,-1471.0f,1032.0f,1136.0f,-2718.0f,1512.0f,-1,0.1095244f,-0.06524868f,-0.9918759f,0f,0f,0f ) ;
  }

  @Test
  public void test879() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,904.0f,266.0f,0f,0.0f,0f,0f,0f,0f,0f,326.0f,798.0f,-575.0f,-1704.0f,-82.0f,-461.0f,12,0.3275453f,-1.8903153f,0.46027002f,0f,0f,0f ) ;
  }

  @Test
  public void test880() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-9.065291f,0.0f,0f,-78.76662f,0f,0f,0f,0f,0f,97.60543f,22.482273f,58.43203f,0f,0f,0f,1,0.016651314f,-0.6881662f,-0.5494211f,0f,0f,0f ) ;
  }

  @Test
  public void test881() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-90.65601f,0.0f,0f,17.851904f,0f,0f,0f,0f,0f,33.49581f,92.19277f,-27.990711f,0f,0f,0f,1,0.23475774f,-0.47004473f,0.59959966f,0f,0f,0f ) ;
  }

  @Test
  public void test882() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-9.081434f,-19.233099f,0f,0f,0f,0f,0f,0f,0f,68.44039f,100.0f,10.07429f,0f,0f,0f,1,-0.21886867f,0.2326289f,-0.9069079f,0f,0f,0f ) ;
  }

  @Test
  public void test883() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-91.0f,794.0f,288.0f,593.0f,0f,0f,0f,0f,0f,-595.0f,280.0f,305.0f,952.0f,401.0f,-223.0f,-778,-16.51731f,78.469604f,16.250393f,14.127767f,0f,0f ) ;
  }

  @Test
  public void test884() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-913.0f,1029.0f,0f,956.0f,0f,0f,0f,0f,0f,-301.0f,1730.0f,-3252.0f,-540.0f,-97.0f,570.0f,-2,0.64754647f,0.6005807f,0.46902707f,0f,0f,0f ) ;
  }

  @Test
  public void test885() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-913.0f,405.0f,0f,470.0f,0f,0f,0f,0f,0f,-822.0f,-1231.0f,86.0f,-1292.0f,939.0f,-452.0f,1,6.586544f,70.64332f,-32.165054f,0f,0f,0f ) ;
  }

  @Test
  public void test886() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-918.0f,-2.0f,0f,446.0f,0f,0f,0f,0f,0f,-513.0f,266.0f,73.0f,-800.0f,-1276.0f,-974.0f,-30,100.0f,54.61805f,-42.95436f,0f,0f,0f ) ;
  }

  @Test
  public void test887() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,92.07929f,0f,0f,0f,0f,0f,0f,0f,0f,-99.8742f,93.95893f,100.0f,0f,0f,0f,1,0.36798498f,0.027308458f,0.34093446f,0f,0f,0f ) ;
  }

  @Test
  public void test888() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-92.193184f,170.00453f,0f,-81.14804f,0f,0f,0f,0f,0f,99.52098f,59.601433f,10.645733f,0f,0f,0f,1,-0.5953976f,-0.798663f,0.08740159f,0f,0f,0f ) ;
  }

  @Test
  public void test889() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-92.43777f,-100.0f,0f,53.88589f,0f,0f,0f,0f,0f,-44.685436f,37.894566f,84.6938f,0f,0f,0f,1,6.9642003E-4f,-0.97893935f,-0.20153472f,0f,0f,0f ) ;
  }

  @Test
  public void test890() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,92.61259f,0f,0f,0f,0f,0f,0f,0f,0f,-85.48063f,-20.439964f,-7.526079f,0f,0f,0f,1,14.7523f,20.52944f,23.36429f,0f,0f,0f ) ;
  }

  @Test
  public void test891() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-932.0f,1284.0f,0f,0.0f,0f,0f,0f,0f,0f,-507.0f,383.0f,308.0f,1474.0f,-1480.0f,880.0f,1,55.622986f,18.33189f,-38.69819f,0f,0f,0f ) ;
  }

  @Test
  public void test892() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-93.33607f,13.834252f,0f,0f,0f,0f,0f,0f,0f,-45.956715f,-46.886715f,-108.27491f,497.0f,-248.0f,501.0f,1,26.049513f,52.505554f,-28.338707f,0f,0f,0f ) ;
  }

  @Test
  public void test893() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-94.0f,258.0f,0f,374.0f,0f,0f,0f,0f,0f,-1487.0f,-137.0f,856.0f,-242.0f,72.0f,-409.0f,20,1.812253f,2.379927f,0.12574792f,0f,0f,0f ) ;
  }

  @Test
  public void test894() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-941.0f,4.0f,0f,129.0f,0f,0f,0f,0f,0f,-2505.0f,-126.0f,-40.0f,-253.0f,-39.0f,-86.0f,-1,0.874337f,0.20483854f,-0.4399727f,0f,0f,0f ) ;
  }

  @Test
  public void test895() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-945.0f,-1.0f,0f,2006.0f,0f,0f,0f,0f,0f,-1367.0f,-122.0f,830.0f,618.0f,-1367.0f,817.0f,-4,83.65885f,53.804264f,-26.123516f,0f,0f,0f ) ;
  }

  @Test
  public void test896() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-946.0f,16.0f,0f,1018.0f,0f,0f,0f,0f,0f,207.0f,-973.0f,-486.0f,790.0f,-624.0f,1587.0f,-2,0.43754497f,0.3639248f,0.82226115f,0f,0f,0f ) ;
  }

  @Test
  public void test897() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-94.74281f,13.8534355f,0f,0f,0f,0f,0f,0f,0f,-39.3354f,-92.74049f,-80.648445f,-466.0f,-706.0f,114.0f,1,49.943142f,61.19524f,-94.72896f,0f,0f,0f ) ;
  }

  @Test
  public void test898() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-95.32406f,0.0f,0f,100.0f,0f,0f,0f,0f,0f,54.11939f,48.6296f,31.992113f,0f,0f,0f,1,-0.7323515f,0.5651553f,0.37981668f,0f,0f,0f ) ;
  }

  @Test
  public void test899() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,954.0f,-882.0f,0f,1483.0f,0f,0f,0f,0f,0f,-980.0f,-256.0f,746.0f,4.0f,657.0f,231.0f,-2,-0.7463687f,-0.7669451f,-4.5808215f,0f,0f,0f ) ;
  }

  @Test
  public void test900() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-95.439415f,82.10865f,0f,0f,0f,0f,0f,0f,0f,20.327074f,75.30341f,10.954899f,388.0f,-216.0f,-824.0f,1,52.13558f,-17.579811f,24.092978f,0f,0f,0f ) ;
  }

  @Test
  public void test901() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-95.499626f,41.71124f,0f,0f,0f,0f,0f,0f,0f,-99.999985f,61.314114f,-100.0f,0f,0f,0f,1,0.9977422f,5.8857194E-4f,-0.031749424f,0f,0f,0f ) ;
  }

  @Test
  public void test902() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,95.580086f,-29.645044f,0f,-100.0f,0f,0f,0f,0f,0f,-100.0f,8.10716f,100.0f,0f,0f,0f,1,2.388239f,100.0f,-5.7189207f,0f,0f,0f ) ;
  }

  @Test
  public void test903() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-956.0f,-18.0f,0f,114.0f,0f,0f,0f,0f,0f,-1096.0f,349.0f,-691.0f,1391.0f,-559.0f,349.0f,-3,-0.677896f,-0.5050681f,2.9210005f,0f,0f,0f ) ;
  }

  @Test
  public void test904() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-96.60673f,-50.22795f,0f,0f,0f,0f,0f,0f,0f,0.51978314f,100.0f,8.537482f,0f,0f,0f,1,-0.2662286f,-0.88499284f,0.38198167f,0f,0f,0f ) ;
  }

  @Test
  public void test905() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,96.975235f,100.0f,0f,0f,0f,0f,0f,0f,0f,100.0f,59.60502f,-53.00079f,-809.0f,-227.0f,-599.0f,1,-0.40491408f,-0.025477393f,0.88721114f,0f,0f,0f ) ;
  }

  @Test
  public void test906() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,97.13463f,0f,0f,0f,0f,0f,0f,0f,0f,36.347824f,-36.68649f,-68.31963f,0f,0f,0f,1,-0.31627366f,-0.88505465f,0.34153953f,0f,0f,0f ) ;
  }

  @Test
  public void test907() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,97.58674f,0f,0f,0f,0f,0f,-37.58137f,-13.661164f,-54.76112f,191.39343f,100.0f,42.077923f,0f,0f,0f,3,-37.689137f,-12.751084f,-54.68843f,0f,0f,0f ) ;
  }

  @Test
  public void test908() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,976.0f,653.0f,0f,644.0f,0f,0f,0f,0f,0f,-1129.0f,-327.0f,949.0f,1971.0f,-1232.0f,-1350.0f,2,-0.21249649f,0.013118772f,-0.9770738f,0f,0f,0f ) ;
  }

  @Test
  public void test909() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,97.87604f,0.0f,0f,0f,0f,0f,0f,0f,0f,48.752148f,100.0f,27.84439f,0f,0f,0f,1,-0.84063536f,0.30070066f,0.09501058f,0f,0f,0f ) ;
  }

  @Test
  public void test910() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,979.0f,-321.0f,0f,1590.0f,0f,0f,0f,0f,0f,32.0f,-866.0f,1372.0f,836.0f,1271.0f,244.0f,3,-0.052629583f,-0.14786172f,-0.46135554f,0f,0f,0f ) ;
  }

  @Test
  public void test911() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,99.065765f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,29.374025f,99.77853f,-100.0f,0f,0f,0f,1,0.48773345f,0.29581213f,0.82134724f,0f,0f,0f ) ;
  }

  @Test
  public void test912() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-99.0f,1.0f,0f,256.0f,0f,0f,0f,0f,0f,-420.0f,-618.0f,923.0f,-841.0f,-1181.0f,-944.0f,2,-93.50786f,45.30085f,-35.865013f,0f,0f,0f ) ;
  }

  @Test
  public void test913() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-99.14625f,0.0f,0f,-43.3377f,0f,0f,0f,0f,0f,-12.349714f,-52.676777f,44.872707f,0f,0f,0f,1,172.81776f,-69.101944f,-40.867237f,0f,0f,0f ) ;
  }

  @Test
  public void test914() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-99.419304f,-98.64097f,0f,-14.689889f,0f,0f,0f,0f,0f,-15.496972f,-18.927053f,54.40995f,0f,0f,0f,1,-0.188444f,-0.45518032f,-0.5394228f,0f,0f,0f ) ;
  }

  @Test
  public void test915() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,99.49165f,-19.009052f,0f,100.0f,0f,0f,0f,0f,0f,100.0f,-50.821075f,-39.247215f,0f,0f,0f,1,0.107256055f,0.20981596f,0.959621f,0f,0f,0f ) ;
  }

  @Test
  public void test916() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-99.49873f,85.22822f,0f,0f,0f,0f,0f,0f,0f,14.912371f,-49.59719f,-50.13935f,-1162.0f,1524.0f,-170.0f,1,-10.821256f,0.73152465f,-3.9403596f,0f,0f,0f ) ;
  }

  @Test
  public void test917() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-99.74157f,-79.318344f,0f,0.0f,0f,0f,0f,0f,0f,82.283585f,-39.045918f,-100.0f,0f,0f,0f,2,0.00484106f,0.62368196f,0.005125511f,0f,0f,0f ) ;
  }

  @Test
  public void test918() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-998.0f,1035.0f,113.0f,-764.0f,0f,0f,0f,0f,0f,-587.0f,-254.0f,912.0f,-591.0f,1509.0f,324.0f,2,-0.34859776f,-0.30844915f,-0.7247298f,64.87119f,0f,0f ) ;
  }

  @Test
  public void test919() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,99.97534f,0.0f,0f,0f,0f,0f,0f,0f,0f,63.665215f,24.172035f,-29.005835f,0f,0f,0f,1,-0.1471687f,-0.74675876f,0.64860827f,0f,0f,0f ) ;
  }

  @Test
  public void test920() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-99.98236f,0.0f,0f,0f,0f,0f,0f,0f,0f,12.865408f,-99.98911f,97.19248f,0f,0f,0f,1,-0.7646959f,0.56635815f,-0.30737382f,0f,0f,0f ) ;
  }

  @Test
  public void test921() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,99.99225f,-99.98862f,0f,100.0f,0f,0f,0f,0f,0f,6.2796755f,-2.4608023f,15.60549f,0f,0f,0f,1,-0.62087595f,-0.7431764f,-0.24940313f,0f,0f,0f ) ;
  }

  @Test
  public void test922() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,99.99609f,0.0f,0f,0f,0f,0f,0f,0f,0f,24.894688f,-77.0669f,48.66626f,0f,0f,0f,1,-0.062769964f,-0.014149461f,0.0010913961f,0f,0f,0f ) ;
  }

  @Test
  public void test923() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,99.99997f,-100.0f,0f,0.0f,0f,0f,0f,0f,0f,2.8522835f,100.0f,-72.80719f,0f,0f,0f,3,0.94134545f,-0.33708993f,-0.015464307f,0f,0f,0f ) ;
  }

  @Test
  public void test924() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-99.99999f,57.40532f,0f,0f,0f,0f,0f,0f,0f,9.782454f,-33.23223f,66.196754f,-482.0f,1123.0f,635.0f,2,-100.0f,-38.013027f,-13.232295f,0f,0f,0f ) ;
  }

  @Test
  public void test925() {
    TestDrivers.surfaceShade(0f,1058.0f,2.0f,0f,12.0f,-1013.0f,0f,-2513.0f,0f,0f,0f,0f,0f,706.0f,512.0f,1085.0f,0f,0f,0f,4,-2.0834527f,3.3204546f,-0.3827344f,0f,-97.18791f,-1.3127666f ) ;
  }

  @Test
  public void test926() {
    TestDrivers.surfaceShade(0f,-1075.0f,-4070.0f,0f,676.0f,-559.0f,0f,-663.0f,0f,0f,0f,0f,0f,1.0f,-476.0f,82.0f,0f,0f,0f,4,0.23657227f,0.43951878f,-0.66988575f,0f,-3.6929607f,100.0f ) ;
  }

  @Test
  public void test927() {
    TestDrivers.surfaceShade(0f,-1076.0f,0f,0f,29.541552f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,-100.0f,-81.436554f,0f,0f,0f,1,-0.87227577f,0.47664133f,-0.10930698f,0f,55.853893f,0f ) ;
  }

  @Test
  public void test928() {
    TestDrivers.surfaceShade(0f,1096.0f,-420.0f,0f,947.0f,-46.0f,0f,-1693.0f,0f,0f,0f,0f,0f,1725.0f,-1129.0f,687.0f,0f,0f,0f,2,-0.1566294f,0.30056614f,-0.74459535f,0f,-100.0f,25.193043f ) ;
  }

  @Test
  public void test929() {
    TestDrivers.surfaceShade(0f,111.0f,0f,0f,0.49995255f,-52.63745f,0f,-97.756325f,0f,0f,0f,0f,0f,69.48179f,68.75872f,-99.15374f,0f,0f,0f,1,0.14466769f,0.26471266f,0.62660104f,0f,-21.40363f,0f ) ;
  }

  @Test
  public void test930() {
    TestDrivers.surfaceShade(0f,1130.0f,-55.0f,0f,138.0f,0.0f,0f,-7.0f,0f,0f,0f,0f,0f,300.0f,1833.0f,-81.0f,0f,0f,0f,-1,-6.6127796f,-4.8750176f,2.2783062f,0f,43.988144f,0.5295699f ) ;
  }

  @Test
  public void test931() {
    TestDrivers.surfaceShade(0f,1211.0f,0f,0f,100.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,100.0f,-62.634243f,0f,0f,0f,5,-0.06637607f,-0.051189385f,0.99648076f,0f,99.99974f,0f ) ;
  }

  @Test
  public void test932() {
    TestDrivers.surfaceShade(0f,1236.0f,7.0f,0f,68.0f,2.0f,0f,0.0f,0f,0f,0f,0f,0f,-1278.0f,-870.0f,1211.0f,0f,0f,0f,1,-0.73556364f,0.25350237f,-0.6282377f,0f,-140.77876f,3.711235E-5f ) ;
  }

  @Test
  public void test933() {
    TestDrivers.surfaceShade(0f,-1282.0f,233.0f,0f,1912.0f,-900.0f,0f,0f,0f,0f,0f,0f,0f,-1677.0f,1979.0f,818.0f,0f,0f,0f,1,0.5991227f,0.45088184f,-0.111928895f,0f,-100.0f,-22.192324f ) ;
  }

  @Test
  public void test934() {
    TestDrivers.surfaceShade(0f,-1289.0f,-1325.0f,0f,2337.0f,-3.0f,0f,-3.0f,0f,0f,0f,0f,0f,-561.0f,140.0f,-415.0f,0f,0f,0f,-1,-0.3582117f,-2.518608f,-0.009400318f,0f,76.867584f,7.7302303f ) ;
  }

  @Test
  public void test935() {
    TestDrivers.surfaceShade(0f,-13.0f,0f,0f,756.0f,1975.0f,0f,-359.0f,0f,0f,0f,0f,0f,-53.0f,-1272.0f,657.0f,-797.0f,921.0f,1211.0f,2,1.0823956f,0.6259924f,0.005757448f,0f,-40.215733f,0f ) ;
  }

  @Test
  public void test936() {
    TestDrivers.surfaceShade(0f,1388.0f,0f,0f,86.72403f,-165.68883f,0f,-28.228214f,0f,0f,0f,0f,0f,-60.93332f,-136.57837f,146.42603f,0f,0f,0f,1,-0.0055725565f,-0.41738343f,-0.66594875f,0f,-14.803122f,0f ) ;
  }

  @Test
  public void test937() {
    TestDrivers.surfaceShade(0f,-1539.0f,-7.0f,0f,29.0f,-4.0f,0f,-6.0f,0f,0f,0f,0f,0f,479.0f,-988.0f,-1110.0f,0f,0f,0f,13,0.033148766f,-0.55218464f,0.5162432f,0f,144.85934f,0.16566175f ) ;
  }

  @Test
  public void test938() {
    TestDrivers.surfaceShade(0f,-1561.0f,0f,0f,100.0f,0.0f,0f,-1.0842163E-19f,0f,0f,0f,0f,0f,-99.999886f,21.38603f,-99.881035f,0f,0f,0f,1,-0.56610763f,-0.7127284f,0.41417545f,0f,100.0f,0f ) ;
  }

  @Test
  public void test939() {
    TestDrivers.surfaceShade(0f,-16.0f,0f,0f,0.12832962f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,53.450085f,-100.0f,-55.170162f,0f,0f,0f,1,-7.139719f,-1.5194813f,-3.8170543f,0f,7.8834553f,0f ) ;
  }

  @Test
  public void test940() {
    TestDrivers.surfaceShade(0f,175.0f,1084.0f,0f,12.0f,-147.0f,0f,-1663.0f,0f,0f,0f,0f,0f,-740.0f,-820.0f,1068.0f,0f,0f,0f,-3,3.9197466f,-1.3289722f,1.6384444f,0f,100.0f,0.17913198f ) ;
  }

  @Test
  public void test941() {
    TestDrivers.surfaceShade(0f,-1855.0f,-1016.0f,0f,2712.0f,1.0f,0f,2.0f,0f,0f,0f,0f,0f,-1406.0f,166.0f,1158.0f,0f,0f,0f,5,0.33342367f,-0.89283395f,0.17058335f,0f,2.1481788f,68.27834f ) ;
  }

  @Test
  public void test942() {
    TestDrivers.surfaceShade(0f,-2072.0f,638.0f,0f,398.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,815.0f,798.0f,-1949.0f,0f,0f,0f,-3,0.11613868f,-0.63589185f,0.95618874f,0f,-50.067593f,117.530846f ) ;
  }

  @Test
  public void test943() {
    TestDrivers.surfaceShade(0f,-230.0f,-9.0f,0f,65.0f,-1080.0f,0f,0f,0f,0f,0f,0f,0f,-731.0f,-377.0f,-806.0f,0f,0f,0f,1,-0.97435945f,3.0941305f,-0.34607688f,0f,61.31621f,-1.0910398f ) ;
  }

  @Test
  public void test944() {
    TestDrivers.surfaceShade(0f,-23.0f,0f,0f,898.0f,1742.0f,0f,-786.0f,0f,0f,0f,0f,0f,-1750.0f,-1186.0f,750.0f,666.0f,245.0f,-2740.0f,1,0.13672496f,-0.7146463f,-1.4279932f,0f,-0.0013259655f,0f ) ;
  }

  @Test
  public void test945() {
    TestDrivers.surfaceShade(0f,-2370.0f,795.0f,0f,1998.0f,-454.0f,0f,-806.0f,0f,0f,0f,0f,0f,-1608.0f,-28.0f,-2999.0f,0f,0f,0f,2,-1.4796691f,1.0269477f,2.9407659f,0f,-87.4872f,78.26047f ) ;
  }

  @Test
  public void test946() {
    TestDrivers.surfaceShade(0f,2509.0f,0f,0f,932.0f,80.0f,0f,-76.0f,0f,0f,0f,0f,0f,-694.0f,826.0f,1386.0f,814.0f,-1462.0f,663.0f,-3,0.87919307f,0.32470354f,-0.2845811f,0f,-39.67653f,0f ) ;
  }

  @Test
  public void test947() {
    TestDrivers.surfaceShade(0f,291.0f,0f,0f,64.67047f,-28.11786f,0f,-100.0f,0f,0f,0f,0f,0f,64.54148f,98.467186f,21.737457f,0f,0f,0f,1,-0.78671926f,-0.36150897f,-0.43273795f,0f,25.414282f,0f ) ;
  }

  @Test
  public void test948() {
    TestDrivers.surfaceShade(0f,-366.0f,98.0f,0f,239.0f,1.0f,0f,-1.0f,0f,0f,0f,0f,0f,-901.0f,642.0f,-3666.0f,0f,0f,0f,-4,1.9806564f,-0.0025982715f,5.7553496f,0f,-40.805717f,-100.0f ) ;
  }

  @Test
  public void test949() {
    TestDrivers.surfaceShade(0f,383.0f,1271.0f,0f,335.0f,0.0f,0f,2.0f,0f,0f,0f,0f,0f,-2010.0f,-76.0f,-199.0f,0f,0f,0f,2,0.15916803f,-0.042832002f,-0.81805974f,0f,-23.827034f,97.89021f ) ;
  }

  @Test
  public void test950() {
    TestDrivers.surfaceShade(0f,407.0f,-133.0f,0f,327.0f,-679.0f,0f,0f,0f,0f,0f,0f,0f,650.0f,109.0f,604.0f,0f,0f,0f,4,-0.30477396f,-1.0100513f,0.22957811f,0f,99.97781f,0.014348325f ) ;
  }

  @Test
  public void test951() {
    TestDrivers.surfaceShade(0f,-436.0f,0f,0f,93.60037f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-18.0444f,-5.1489325f,-100.0f,0f,0f,0f,1,0.464284f,-0.60110265f,-0.036136735f,0f,-26.496563f,0f ) ;
  }

  @Test
  public void test952() {
    TestDrivers.surfaceShade(0f,-449.0f,-757.0f,0f,610.0f,-832.0f,0f,0f,0f,0f,0f,0f,0f,-370.0f,-1556.0f,482.0f,0f,0f,0f,-2,0.4973007f,0.11620769f,-0.1260935f,0f,15.891474f,29.700691f ) ;
  }

  @Test
  public void test953() {
    TestDrivers.surfaceShade(0f,505.0f,0f,0f,31.495712f,-100.0f,0f,0f,0f,0f,0f,0f,0f,-12.276973f,100.0f,40.268192f,0f,0f,0f,1,-0.8521189f,-0.20878197f,-0.263189f,0f,100.0f,0f ) ;
  }

  @Test
  public void test954() {
    TestDrivers.surfaceShade(0f,-516.0f,255.0f,0f,1158.0f,-2422.0f,0f,-407.0f,0f,0f,0f,0f,0f,-1212.0f,78.0f,0.0f,0f,0f,0f,1,0.11840497f,0.016805064f,0.0028314304f,0f,37.967693f,98.36287f ) ;
  }

  @Test
  public void test955() {
    TestDrivers.surfaceShade(0f,-596.0f,0f,0f,54.96134f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,24.365545f,33.143906f,-100.0f,0f,0f,0f,1,-0.85934156f,-0.21849437f,0.3058693f,0f,58.1219f,0f ) ;
  }

  @Test
  public void test956() {
    TestDrivers.surfaceShade(0f,-648.0f,403.0f,0f,779.0f,-907.0f,0f,0f,0f,0f,0f,0f,0f,-754.0f,-411.0f,2193.0f,0f,0f,0f,2,0.4268371f,0.02519626f,0.028612357f,0f,20.43546f,31.893612f ) ;
  }

  @Test
  public void test957() {
    TestDrivers.surfaceShade(0f,69.0f,2174.0f,0f,2131.0f,0.0f,0f,-1.0f,0f,0f,0f,0f,0f,-770.0f,287.0f,-812.0f,0f,0f,0f,-1,0.9082411f,0.39614272f,0.13479246f,0f,-23.56063f,32.31419f ) ;
  }

  @Test
  public void test958() {
    TestDrivers.surfaceShade(0f,839.0f,-473.0f,0f,156.0f,-1148.0f,0f,0f,0f,0f,0f,0f,0f,-505.0f,659.0f,-2117.0f,0f,0f,0f,1,-1.014227f,0.0909333f,0.91637254f,0f,48.01517f,-99.98158f ) ;
  }

  @Test
  public void test959() {
    TestDrivers.surfaceShade(0f,-960.0f,0f,0f,0.9215544f,-100.0f,0f,0f,0f,0f,0f,0f,0f,-1.1588279f,82.31753f,-81.61343f,0f,0f,0f,1,-3.2466073f,9.099455f,13.480598f,0f,-0.035812628f,0f ) ;
  }

  @Test
  public void test960() {
    TestDrivers.surfaceShade(0f,975.0f,0f,0f,58.177937f,-13.451893f,0f,0f,0f,0f,0f,0f,0f,-14.2097025f,50.435535f,29.75806f,0f,0f,0f,1,-0.81357807f,-0.24495392f,-0.26881734f,0f,-85.27703f,0f ) ;
  }

  @Test
  public void test961() {
    TestDrivers.surfaceShade(10.0f,0f,0f,0f,100.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,-100.0f,100.0f,0f,0f,0f,1,-0.84762603f,-0.08888229f,-0.5230966f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test962() {
    TestDrivers.surfaceShade(10.0f,0f,0f,0f,11.0f,859.0f,0f,-523.0f,0f,0f,0f,0f,0f,-670.0f,490.0f,1017.0f,-618.0f,-879.0f,-1460.0f,2,-0.074136354f,-0.037594408f,-3.0848613f,0.0015773547f,0f,0f ) ;
  }

  @Test
  public void test963() {
    TestDrivers.surfaceShade(-10.0f,0f,0f,0f,4.9864044f,0.0f,0f,-9.968186f,0f,0f,0f,0f,0f,-9.42412f,-9.966569f,-2.79464f,0f,0f,0f,3,0.8595079f,0.9390762f,-1.9448534f,-0.0038767946f,0f,0f ) ;
  }

  @Test
  public void test964() {
    TestDrivers.surfaceShade(-10.0f,-1355.0f,0f,0f,1528.0f,0.0f,0f,-645.0f,0f,0f,0f,0f,0f,2240.0f,675.0f,-496.0f,0f,0f,0f,6,-75.227776f,33.536434f,77.863556f,87.28583f,-100.0f,0f ) ;
  }

  @Test
  public void test965() {
    TestDrivers.surfaceShade(-10.0f,843.0f,0f,0f,923.0f,0.0f,0f,-438.0f,0f,0f,0f,0f,0f,700.0f,-200.0f,-1032.0f,0f,0f,0f,5,100.0f,100.0f,100.0f,-100.0f,93.98344f,0f ) ;
  }

  @Test
  public void test966() {
    TestDrivers.surfaceShade(-1010.0f,-584.0f,303.0f,0f,131.0f,-1.0f,0f,-2060.0f,0f,0f,0f,0f,0f,101.0f,-270.0f,360.0f,0f,0f,0f,7,22.842093f,22.858454f,-48.817337f,-10.748173f,16.514956f,100.0f ) ;
  }

  @Test
  public void test967() {
    TestDrivers.surfaceShade(102.0f,0f,0f,0f,107.34361f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-34.83164f,35.032665f,7.937438f,0f,0f,0f,2,-20.43445f,-32.811394f,-100.0f,39.096542f,0f,0f ) ;
  }

  @Test
  public void test968() {
    TestDrivers.surfaceShade(-102.0f,0f,0f,0f,70.0237f,-56.284107f,0f,0.0f,0f,0f,0f,0f,0f,11.492712f,-91.50152f,-67.477264f,0f,0f,0f,2,-47.799557f,21.739746f,63.35727f,73.79392f,0f,0f ) ;
  }

  @Test
  public void test969() {
    TestDrivers.surfaceShade(-1034.0f,80.0f,0f,0f,138.0f,-2743.0f,0f,0.0f,0f,0f,0f,0f,0f,362.0f,187.0f,249.0f,0f,0f,0f,6,-31.526627f,-6.870215f,50.9934f,-2.943961f,0.47214356f,0f ) ;
  }

  @Test
  public void test970() {
    TestDrivers.surfaceShade(-1046.0f,-1039.0f,-102.0f,0f,148.0f,-1.0f,0f,-2576.0f,0f,0f,0f,0f,0f,-683.0f,-588.0f,463.0f,0f,0f,0f,2,-8.606424f,97.65606f,100.0f,99.80143f,24.044415f,-1.7331166E-6f ) ;
  }

  @Test
  public void test971() {
    TestDrivers.surfaceShade(105.0f,0f,0f,0f,35.0f,0.0f,0f,982.0f,0f,0f,0f,0f,0f,-866.0f,988.0f,-897.0f,1469.0f,907.0f,432.0f,1,-70.72471f,-1.3619701f,67.40427f,4.7506826E-5f,0f,0f ) ;
  }

  @Test
  public void test972() {
    TestDrivers.surfaceShade(-1055.0f,0f,0f,0f,3.7260102E-6f,-99.99998f,0f,-86.76265f,0f,0f,0f,0f,0f,-5.337421f,-56.96767f,28.221842f,0f,0f,0f,1,-86.04566f,28.143091f,-1.2998716f,-19.508238f,0f,0f ) ;
  }

  @Test
  public void test973() {
    TestDrivers.surfaceShade(-1062.0f,590.0f,0f,0f,3114.0f,-2805.0f,0f,0.0f,0f,0f,0f,0f,0f,118.0f,105.0f,-512.0f,0f,0f,0f,10,-0.029775405f,-0.24356627f,0.88464195f,90.06603f,23.515951f,0f ) ;
  }

  @Test
  public void test974() {
    TestDrivers.surfaceShade(-109.0f,0f,0f,0f,-127.0f,938.0f,124.0f,-877.0f,0f,0f,0f,0f,0f,310.0f,641.0f,127.0f,147.0f,-443.0f,-571.0f,546,4.0594325f,33.117107f,4.736287f,-60.885765f,0f,0f ) ;
  }

  @Test
  public void test975() {
    TestDrivers.surfaceShade(109.0f,0f,0f,0f,-447.0f,-827.0f,912.0f,-939.0f,0f,0f,0f,0f,0f,-407.0f,-87.0f,-128.0f,-632.0f,791.0f,595.0f,-147,85.0965f,40.338627f,-76.92065f,-57.30692f,0f,0f ) ;
  }

  @Test
  public void test976() {
    TestDrivers.surfaceShade(109.0f,0f,0f,0f,6.318122f,-3.749561f,0f,-94.87272f,0f,0f,0f,0f,0f,18.268606f,37.9925f,81.17428f,0f,0f,0f,1,4.2539454f,2.9936337f,-16.526459f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test977() {
    TestDrivers.surfaceShade(1096.0f,0f,0f,0f,3.4562087f,-26.592966f,0f,-2.493647f,0f,0f,0f,0f,0f,78.50521f,18.09884f,3.269772f,0f,0f,0f,1,-0.39915016f,0.37450835f,-0.22290516f,100.0f,0f,0f ) ;
  }

  @Test
  public void test978() {
    TestDrivers.surfaceShade(-1.0f,0f,0f,0f,0.007340757f,-62.126263f,0f,0.0f,0f,0f,0f,0f,0f,-6.787061f,58.246246f,-10.082171f,0f,0f,0f,1,61.88925f,3.0139158f,-3.677943f,-40.767292f,0f,0f ) ;
  }

  @Test
  public void test979() {
    TestDrivers.surfaceShade(-1101.0f,0f,-1066.0f,0f,1772.0f,1.0f,0f,-1797.0f,0f,0f,0f,0f,0f,2951.0f,-301.0f,944.0f,0f,0f,0f,1,-0.6798855f,0.33244476f,-0.015900986f,10.110853f,0f,72.09812f ) ;
  }

  @Test
  public void test980() {
    TestDrivers.surfaceShade(-1108.0f,1458.0f,-891.0f,0f,1200.0f,1.0f,0f,-1215.0f,0f,0f,0f,0f,0f,-1878.0f,-965.0f,167.0f,0f,0f,0f,-1,43.31851f,-100.0f,-100.0f,83.32927f,-100.0f,-8.323331E-8f ) ;
  }

  @Test
  public void test981() {
    TestDrivers.surfaceShade(11.0f,-256.0f,0f,0f,238.0f,-227.0f,0f,0.0f,0f,0f,0f,0f,0f,-1035.0f,-1769.0f,-97.0f,0f,0f,0f,2,66.24991f,-41.09444f,73.25564f,31.629581f,29.49988f,0f ) ;
  }

  @Test
  public void test982() {
    TestDrivers.surfaceShade(-1123.0f,281.0f,0f,0f,107.0f,1.0f,0f,-1179.0f,0f,0f,0f,0f,0f,-603.0f,-845.0f,-271.0f,0f,0f,0f,-5,0.7311876f,-0.18454757f,-0.18185818f,100.0f,1.094715E-7f,0f ) ;
  }

  @Test
  public void test983() {
    TestDrivers.surfaceShade(1125.0f,0f,0f,0f,83.55984f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,38.745346f,46.793533f,27.587498f,0f,0f,0f,1,-67.72953f,-23.696882f,93.634995f,1.0913114E-6f,0f,0f ) ;
  }

  @Test
  public void test984() {
    TestDrivers.surfaceShade(-1146.0f,386.0f,0f,0f,1612.0f,-160.0f,0f,1.0f,0f,0f,0f,0f,0f,-1858.0f,-154.0f,-182.0f,0f,0f,0f,1,31.677565f,-47.247486f,38.598354f,-142.85823f,-60.56923f,0f ) ;
  }

  @Test
  public void test985() {
    TestDrivers.surfaceShade(-1154.0f,283.0f,0f,0f,197.0f,-5.0f,0f,-1101.0f,0f,0f,0f,0f,0f,53.0f,-319.0f,-767.0f,0f,0f,0f,1,0.42232051f,-1.9404616f,0.8747092f,100.0f,0.21391504f,0f ) ;
  }

  @Test
  public void test986() {
    TestDrivers.surfaceShade(-1178.0f,-761.0f,365.0f,0f,907.0f,0.0f,0f,-299.0f,0f,0f,0f,0f,0f,888.0f,646.0f,853.0f,0f,0f,0f,1,-49.601295f,109.77756f,-85.18113f,69.08879f,92.857796f,30.541891f ) ;
  }

  @Test
  public void test987() {
    TestDrivers.surfaceShade(1194.0f,0f,0f,0f,312.0f,-1609.0f,0f,1054.0f,0f,0f,0f,0f,0f,-372.0f,39.0f,644.0f,176.0f,-802.0f,-1339.0f,-2,50.66812f,135.9477f,15.373175f,59.930546f,0f,0f ) ;
  }

  @Test
  public void test988() {
    TestDrivers.surfaceShade(1194.0f,0f,0f,0f,38.426563f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,44.698643f,-22.114702f,-8.796387f,0f,0f,0f,2,-14.832607f,-1.6717937f,5.5031896f,-130.55243f,0f,0f ) ;
  }

  @Test
  public void test989() {
    TestDrivers.surfaceShade(-1200.0f,0f,0f,0f,72.867096f,-53.646587f,0f,4.9303807E-32f,0f,0f,0f,0f,0f,13.61739f,-7.9974294f,-70.67444f,0f,0f,0f,-1,-0.40636718f,0.3687433f,1.0787162f,21.146769f,0f,0f ) ;
  }

  @Test
  public void test990() {
    TestDrivers.surfaceShade(-120.0f,0f,0f,0f,48.85614f,-41.57826f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,-86.071686f,-21.940407f,0f,0f,0f,1,-100.0f,-100.0f,-63.48236f,-10.108511f,0f,0f ) ;
  }

  @Test
  public void test991() {
    TestDrivers.surfaceShade(1201.0f,807.0f,0f,0f,288.0f,0.0f,0f,-1650.0f,0f,0f,0f,0f,0f,-952.0f,-1383.0f,-2122.0f,0f,0f,0f,2,0.9350255f,0.3537603f,0.024102315f,100.0f,1.4857543f,0f ) ;
  }

  @Test
  public void test992() {
    TestDrivers.surfaceShade(1216.0f,0f,0f,0f,158.11116f,-116.90773f,0f,-56.97015f,0f,0f,0f,0f,0f,39.657368f,-54.080822f,57.548172f,0f,0f,0f,-2,-0.75489247f,-0.07607225f,-0.40964454f,-82.138596f,0f,0f ) ;
  }

  @Test
  public void test993() {
    TestDrivers.surfaceShade(-122.0f,0f,0f,0f,669.0f,836.0f,0f,-492.0f,0f,0f,0f,0f,0f,1421.0f,-668.0f,-133.0f,-1036.0f,863.0f,1241.0f,1,-41.416946f,23.840302f,-148.03606f,-31.73028f,0f,0f ) ;
  }

  @Test
  public void test994() {
    TestDrivers.surfaceShade(-1224.0f,210.0f,-1211.0f,0f,3.0f,0.0f,0f,-1413.0f,0f,0f,0f,0f,0f,951.0f,220.0f,-312.0f,0f,0f,0f,-2,9.725123f,99.7624f,99.98833f,87.26227f,6.17933f,-1.0230484f ) ;
  }

  @Test
  public void test995() {
    TestDrivers.surfaceShade(1232.0f,1661.0f,0f,0f,1540.0f,0.0f,0f,-1286.0f,0f,0f,0f,0f,0f,24.0f,735.0f,-499.0f,0f,0f,0f,1,0.028760996f,-0.57669073f,-0.20675294f,100.0f,-70.30641f,0f ) ;
  }

  @Test
  public void test996() {
    TestDrivers.surfaceShade(1251.0f,0f,-9.0f,0f,5.0f,-944.0f,0f,-399.0f,0f,0f,0f,0f,0f,-1351.0f,1013.0f,3021.0f,0f,0f,0f,4,-12.56263f,-193.43854f,59.174065f,52.225483f,0f,-0.02524528f ) ;
  }

  @Test
  public void test997() {
    TestDrivers.surfaceShade(-1256.0f,659.0f,0f,0f,156.0f,2.0f,0f,1.0f,0f,0f,0f,0f,0f,161.0f,-711.0f,-1647.0f,0f,0f,0f,-7,-100.0f,-27.543364f,2.1149557f,-54.701866f,100.0f,0f ) ;
  }

  @Test
  public void test998() {
    TestDrivers.surfaceShade(126.0f,-155.0f,0f,0f,266.0f,-1746.0f,0f,2.0f,0f,0f,0f,0f,0f,475.0f,516.0f,665.0f,0f,0f,0f,-4,2.1314712f,-31.737268f,23.10373f,0.92918414f,-0.5330247f,0f ) ;
  }

  @Test
  public void test999() {
    TestDrivers.surfaceShade(-1264.0f,892.0f,0f,0f,19.0f,2.0f,0f,-1180.0f,0f,0f,0f,0f,0f,225.0f,-1528.0f,2072.0f,0f,0f,0f,7,68.341034f,2.8594487f,-6.6920257f,-99.72573f,1.3483811E-6f,0f ) ;
  }

  @Test
  public void test1000() {
    TestDrivers.surfaceShade(-127.0f,0f,0f,0f,46.888653f,-30.939089f,0f,-73.49527f,0f,0f,0f,0f,0f,78.12183f,72.46023f,-45.184235f,0f,0f,0f,1,-73.72986f,32.48589f,63.72942f,-48.50336f,0f,0f ) ;
  }

  @Test
  public void test1001() {
    TestDrivers.surfaceShade(-1275.0f,0f,777.0f,0f,669.0f,-214.0f,0f,-406.0f,0f,0f,0f,0f,0f,316.0f,-167.0f,656.0f,0f,0f,0f,1,96.05436f,-78.82633f,-66.5893f,13.697451f,0f,-78.185265f ) ;
  }

  @Test
  public void test1002() {
    TestDrivers.surfaceShade(1282.0f,0f,0f,0f,25.631594f,0.0f,0f,-26.485456f,0f,0f,0f,0f,0f,81.47795f,-29.594166f,-81.47125f,0f,0f,0f,1,-0.07075624f,0.17941114f,0.9812264f,6.4106694E-5f,0f,0f ) ;
  }

  @Test
  public void test1003() {
    TestDrivers.surfaceShade(1285.0f,176.0f,0f,0f,335.0f,0.0f,0f,-145.0f,0f,0f,0f,0f,0f,-608.0f,-1528.0f,365.0f,0f,0f,0f,1,-64.181465f,100.0f,-63.1383f,73.722404f,-32.536804f,0f ) ;
  }

  @Test
  public void test1004() {
    TestDrivers.surfaceShade(1316.0f,-131.0f,0f,0f,36.0f,-235.0f,0f,-66.0f,0f,0f,0f,0f,0f,131.0f,-852.0f,-337.0f,0f,0f,0f,1,100.0f,100.0f,90.29183f,-17.890675f,14.28951f,0f ) ;
  }

  @Test
  public void test1005() {
    TestDrivers.surfaceShade(-1317.0f,-29.0f,0f,0f,6.0f,-1.0f,0f,-1675.0f,0f,0f,0f,0f,0f,-1373.0f,-77.0f,-1348.0f,0f,0f,0f,2,97.71533f,100.0f,-100.0f,-100.0f,-1.3986792E-4f,0f ) ;
  }

  @Test
  public void test1006() {
    TestDrivers.surfaceShade(-133.0f,0f,0f,0f,173.46219f,-100.0f,0f,0f,0f,0f,0f,0f,0f,84.466415f,100.0f,-10.598537f,0f,0f,0f,2,-0.41268983f,-0.28819692f,0.6689824f,-30.946995f,0f,0f ) ;
  }

  @Test
  public void test1007() {
    TestDrivers.surfaceShade(-1331.0f,0f,0f,0f,100.76085f,-40.84569f,0f,-75.40076f,0f,0f,0f,0f,0f,10.807542f,68.18263f,11.594931f,0f,0f,0f,1,-0.727828f,-0.23066635f,-0.64580137f,0.41321132f,0f,0f ) ;
  }

  @Test
  public void test1008() {
    TestDrivers.surfaceShade(1338.0f,0f,0f,0f,2.9806668E-7f,-99.9966f,0f,-90.69881f,0f,0f,0f,0f,0f,87.035255f,-9.579614f,2.4866433f,0f,0f,0f,1,-100.0f,17.410366f,99.99203f,41.43846f,0f,0f ) ;
  }

  @Test
  public void test1009() {
    TestDrivers.surfaceShade(1342.0f,-1354.0f,-660.0f,0f,711.0f,-1.0f,0f,-1553.0f,0f,0f,0f,0f,0f,29.0f,-332.0f,235.0f,0f,0f,0f,1,40.626816f,44.07891f,-24.95566f,80.15488f,100.0f,78.56894f ) ;
  }

  @Test
  public void test1010() {
    TestDrivers.surfaceShade(1347.0f,0f,-3.0f,0f,6.0f,-130.0f,0f,-571.0f,0f,0f,0f,0f,0f,109.0f,421.0f,2049.0f,0f,0f,0f,1,6.7423916f,-59.537796f,11.811288f,-63.509514f,0f,-0.026268024f ) ;
  }

  @Test
  public void test1011() {
    TestDrivers.surfaceShade(-1362.0f,0f,0f,0f,2.7947135f,-36.382046f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,32.973583f,0f,0f,0f,3,-0.15054421f,0.981039f,-0.10513237f,-30.265648f,0f,0f ) ;
  }

  @Test
  public void test1012() {
    TestDrivers.surfaceShade(1364.0f,-169.0f,-1174.0f,0f,281.0f,-1.0f,0f,-1600.0f,0f,0f,0f,0f,0f,-1239.0f,-467.0f,-347.0f,0f,0f,0f,-4,1.1014086f,-0.3189005f,0.42379084f,36.102676f,54.130375f,75.08661f ) ;
  }

  @Test
  public void test1013() {
    TestDrivers.surfaceShade(1365.0f,0f,0f,0f,100.0f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,41.244648f,123.535805f,20.019573f,0f,0f,0f,-1,-4.1872835f,0.7943958f,0.11584671f,15.92427f,0f,0f ) ;
  }

  @Test
  public void test1014() {
    TestDrivers.surfaceShade(1370.0f,0f,0f,0f,21.71255f,0.0f,0f,-67.78937f,0f,0f,0f,0f,0f,23.168577f,54.93485f,17.818266f,0f,0f,0f,1,0.022981497f,-0.33032453f,0.0641412f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test1015() {
    TestDrivers.surfaceShade(-137.0f,0f,0f,0f,66.37582f,-32.922173f,0f,0f,0f,0f,0f,0f,0f,-100.0f,17.32142f,36.43242f,0f,0f,0f,2,0.028707653f,-0.47420192f,-0.08280275f,126.434746f,0f,0f ) ;
  }

  @Test
  public void test1016() {
    TestDrivers.surfaceShade(-1379.0f,155.0f,0f,0f,972.0f,0.0f,0f,-533.0f,0f,0f,0f,0f,0f,1277.0f,1859.0f,1331.0f,0f,0f,0f,-1,-0.0011565188f,-0.7242648f,-0.68952096f,-40.70091f,-2.1851928f,0f ) ;
  }

  @Test
  public void test1017() {
    TestDrivers.surfaceShade(-1392.0f,0f,0f,0f,58.621887f,-58.29907f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,99.89401f,-99.82982f,0f,0f,0f,1,24.502632f,-100.0f,13.1133f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test1018() {
    TestDrivers.surfaceShade(-140.0f,0f,0f,0f,291.0f,833.0f,-12.0f,-1.0f,0f,0f,0f,0f,0f,925.0f,593.0f,-114.0f,572.0f,-597.0f,-1056.0f,-1,4.0305204f,5.612002f,81.57727f,-99.32954f,0f,0f ) ;
  }

  @Test
  public void test1019() {
    TestDrivers.surfaceShade(1407.0f,-710.0f,0f,0f,1730.0f,0.0f,0f,-37.0f,0f,0f,0f,0f,0f,-618.0f,279.0f,724.0f,0f,0f,0f,1,-85.886826f,65.308624f,-98.47951f,23.680794f,-97.06735f,0f ) ;
  }

  @Test
  public void test1020() {
    TestDrivers.surfaceShade(1409.0f,0f,1.0f,0f,434.0f,-1318.0f,0f,0.0f,0f,0f,0f,0f,0f,374.0f,-905.0f,343.0f,0f,0f,0f,2,-7.6915474f,100.0f,72.038414f,-20.982538f,0f,-22.867285f ) ;
  }

  @Test
  public void test1021() {
    TestDrivers.surfaceShade(14.0f,-130.0f,0f,0f,58.0f,-1324.0f,0f,-132.0f,0f,0f,0f,0f,0f,685.0f,-1.0f,185.0f,0f,0f,0f,-2,-2.2589626f,-92.1497f,6.220597f,3.7373908E-4f,10.740532f,0f ) ;
  }

  @Test
  public void test1022() {
    TestDrivers.surfaceShade(142.0f,0f,0f,0f,17.919388f,-55.844517f,0f,-21.956121f,0f,0f,0f,0f,0f,-15.942512f,-66.555786f,46.4929f,0f,0f,0f,1,-72.032364f,8.524909f,-100.0f,36.14215f,0f,0f ) ;
  }

  @Test
  public void test1023() {
    TestDrivers.surfaceShade(-1449.0f,-1057.0f,0.0f,0f,12.0f,-7.0f,0f,-2.0f,0f,0f,0f,0f,0f,-656.0f,-873.0f,-1314.0f,0f,0f,0f,4,41.40929f,-20.570036f,52.2709f,60.888493f,66.57444f,61.88103f ) ;
  }

  @Test
  public void test1024() {
    TestDrivers.surfaceShade(145.0f,-613.0f,-1083.0f,0f,752.0f,-152.0f,0f,-1.0f,0f,0f,0f,0f,0f,1732.0f,-1607.0f,267.0f,0f,0f,0f,1,-76.02501f,-85.39812f,-131.7692f,-55.513107f,148.88611f,-148.82251f ) ;
  }

  @Test
  public void test1025() {
    TestDrivers.surfaceShade(1454.0f,-524.0f,0f,0f,1194.0f,1.0f,0f,-2.0f,0f,0f,0f,0f,0f,1354.0f,504.0f,1666.0f,0f,0f,0f,-7,-4.2895575f,2.6140532f,-0.8146166f,-88.28865f,-30.733759f,0f ) ;
  }

  @Test
  public void test1026() {
    TestDrivers.surfaceShade(1460.0f,6.0f,0f,0f,56.0f,-1850.0f,0f,-847.0f,0f,0f,0f,0f,0f,1082.0f,-288.0f,-1005.0f,0f,0f,0f,3,-61.18971f,-91.39533f,27.414787f,48.57408f,5.0025533E-6f,0f ) ;
  }

  @Test
  public void test1027() {
    TestDrivers.surfaceShade(-1470.0f,0f,0f,0f,237.0f,2319.0f,-932.0f,-798.0f,0f,0f,0f,0f,0f,-1717.0f,487.0f,-1783.0f,135.0f,-835.0f,-941.0f,7,-0.19640955f,0.24356161f,0.35043022f,19.411291f,0f,0f ) ;
  }

  @Test
  public void test1028() {
    TestDrivers.surfaceShade(147.0f,745.0f,0f,0f,1499.0f,-2718.0f,0f,0.0f,0f,0f,0f,0f,0f,-469.0f,-1095.0f,-339.0f,0f,0f,0f,2,-85.61604f,7.308987f,94.91247f,88.78245f,-100.0f,0f ) ;
  }

  @Test
  public void test1029() {
    TestDrivers.surfaceShade(148.0f,288.0f,0f,0f,99.0f,-1131.0f,0f,-749.0f,0f,0f,0f,0f,0f,-422.0f,872.0f,401.0f,0f,0f,0f,-6,6.877261f,45.27668f,-91.21962f,1.0585608f,97.33064f,0f ) ;
  }

  @Test
  public void test1030() {
    TestDrivers.surfaceShade(149.0f,367.0f,0f,0f,929.0f,1349.0f,0f,-646.0f,0f,0f,0f,0f,0f,569.0f,725.0f,-284.0f,322.0f,79.0f,893.0f,-5,83.31069f,-40.37237f,64.909035f,-80.24726f,-91.738495f,0f ) ;
  }

  @Test
  public void test1031() {
    TestDrivers.surfaceShade(-15.0f,-16.0f,0f,0f,21.0f,-616.0f,0f,0.0f,0f,0f,0f,0f,0f,-91.0f,-2004.0f,-927.0f,0f,0f,0f,1,93.78013f,-1.4623845f,-2.745523f,-100.0f,-9.1267364E-5f,0f ) ;
  }

  @Test
  public void test1032() {
    TestDrivers.surfaceShade(1521.0f,-8.0f,-750.0f,0f,2.0f,0.0f,0f,-490.0f,0f,0f,0f,0f,0f,160.0f,632.0f,-287.0f,0f,0f,0f,4,93.31683f,6.3756294f,100.0f,-191.65453f,-1.3919548f,-38.00584f ) ;
  }

  @Test
  public void test1033() {
    TestDrivers.surfaceShade(-1525.0f,-214.0f,0f,0f,1385.0f,-761.0f,0f,1.0f,0f,0f,0f,0f,0f,924.0f,-75.0f,-1105.0f,0f,0f,0f,-4,-0.4762739f,-0.61899185f,0.21783644f,34.61383f,85.50458f,0f ) ;
  }

  @Test
  public void test1034() {
    TestDrivers.surfaceShade(1533.0f,-101.0f,0f,0f,545.0f,1.0f,0f,-2381.0f,0f,0f,0f,0f,0f,-749.0f,1023.0f,-2283.0f,0f,0f,0f,2,-0.24120721f,0.03175589f,0.11903933f,100.0f,-8.9644175E-8f,0f ) ;
  }

  @Test
  public void test1035() {
    TestDrivers.surfaceShade(1543.0f,0f,-17.0f,0f,14.0f,-1324.0f,0f,-5.0f,0f,0f,0f,0f,0f,979.0f,-407.0f,410.0f,0f,0f,0f,1,57.76195f,71.23243f,-69.049774f,-0.73755556f,0f,8.084987f ) ;
  }

  @Test
  public void test1036() {
    TestDrivers.surfaceShade(1550.0f,0f,0f,0f,96.12965f,0.0f,0f,-97.45685f,0f,0f,0f,0f,0f,24.91039f,90.44457f,49.71419f,0f,0f,0f,1,0.09661761f,-0.9571858f,0.18627569f,-4.163245f,0f,0f ) ;
  }

  @Test
  public void test1037() {
    TestDrivers.surfaceShade(1565.0f,-154.0f,-1062.0f,0f,676.0f,-25.0f,0f,-282.0f,0f,0f,0f,0f,0f,-1089.0f,-549.0f,511.0f,0f,0f,0f,2,4.0794597f,100.0f,3.90252f,-29.190697f,77.850075f,58.49903f ) ;
  }

  @Test
  public void test1038() {
    TestDrivers.surfaceShade(1568.0f,716.0f,0f,0f,1469.0f,0.0f,0f,-1.0f,0f,0f,0f,0f,0f,-3098.0f,24.0f,-1214.0f,0f,0f,0f,1,90.799835f,0.9348304f,100.0f,-100.0f,0.39638385f,0f ) ;
  }

  @Test
  public void test1039() {
    TestDrivers.surfaceShade(-1572.0f,34.0f,0f,0f,825.0f,0.0f,0f,-476.0f,0f,0f,0f,0f,0f,-673.0f,-167.0f,8.0f,0f,0f,0f,2,100.0f,100.0f,100.0f,11.471069f,-37.653103f,0f ) ;
  }

  @Test
  public void test1040() {
    TestDrivers.surfaceShade(1572.0f,-705.0f,17.0f,0f,67.0f,-1074.0f,0f,-290.0f,0f,0f,0f,0f,0f,-713.0f,131.0f,783.0f,0f,0f,0f,5,80.60175f,-51.602406f,78.10735f,6.5734377f,9.469352f,3.7123136E-5f ) ;
  }

  @Test
  public void test1041() {
    TestDrivers.surfaceShade(1588.0f,0f,0f,0f,51.81677f,-8.22461f,0f,0.0f,0f,0f,0f,0f,0f,-22.635918f,56.823883f,-39.60302f,0f,0f,0f,2,10.046766f,4.8968244f,1.2837101f,55.500374f,0f,0f ) ;
  }

  @Test
  public void test1042() {
    TestDrivers.surfaceShade(1589.0f,-11.0f,0f,0f,68.0f,-398.0f,0f,-1.0f,0f,0f,0f,0f,0f,-1085.0f,1183.0f,-844.0f,0f,0f,0f,5,86.32861f,20.894842f,-81.61754f,84.366165f,-0.0025702915f,0f ) ;
  }

  @Test
  public void test1043() {
    TestDrivers.surfaceShade(159.0f,-1262.0f,0f,0f,167.0f,-309.0f,0f,-1.0f,0f,0f,0f,0f,0f,707.0f,-223.0f,-2261.0f,0f,0f,0f,2,18.74586f,99.92732f,-3.2711809f,-5.0067925E-4f,-53.377026f,0f ) ;
  }

  @Test
  public void test1044() {
    TestDrivers.surfaceShade(160.0f,-270.0f,0f,0f,25.0f,1.0f,0f,-5.0f,0f,0f,0f,0f,0f,771.0f,-291.0f,-1800.0f,0f,0f,0f,4,100.0f,78.65428f,31.513754f,65.80893f,0.06516098f,0f ) ;
  }

  @Test
  public void test1045() {
    TestDrivers.surfaceShade(-1633.0f,0f,1891.0f,0f,12.0f,-919.0f,0f,-1.0f,0f,0f,0f,0f,0f,-636.0f,981.0f,-881.0f,0f,0f,0f,4,-83.02765f,-100.0f,47.407757f,130.06418f,0f,69.0642f ) ;
  }

  @Test
  public void test1046() {
    TestDrivers.surfaceShade(-1639.0f,-831.0f,-776.0f,0f,445.0f,908.0f,0f,-911.0f,0f,0f,0f,0f,0f,-814.0f,-276.0f,1042.0f,1310.0f,433.0f,592.0f,7,-32.50221f,29.223644f,-100.0f,-7.671475f,8.030285f,-32.52712f ) ;
  }

  @Test
  public void test1047() {
    TestDrivers.surfaceShade(-1641.0f,-50.0f,27.0f,0f,6.0f,-921.0f,0f,-2684.0f,0f,0f,0f,0f,0f,-276.0f,-855.0f,941.0f,0f,0f,0f,-1,98.80266f,57.30642f,81.00293f,2.6300287f,100.0f,0.020339359f ) ;
  }

  @Test
  public void test1048() {
    TestDrivers.surfaceShade(-1645.0f,157.0f,-468.0f,0f,988.0f,-1.0f,0f,-122.0f,0f,0f,0f,0f,0f,1575.0f,-171.0f,1873.0f,0f,0f,0f,1,53.285618f,-1.6772751f,-75.50273f,96.84722f,-44.4564f,-5.7863097f ) ;
  }

  @Test
  public void test1049() {
    TestDrivers.surfaceShade(-1650.0f,0f,0f,0f,73.21159f,2.9E-44f,0f,-98.189316f,0f,0f,0f,0f,0f,-49.59971f,-4.7381186f,73.28951f,0f,0f,0f,-1,0.7274809f,-33.61768f,-1.6810284f,-5.56292f,0f,0f ) ;
  }

  @Test
  public void test1050() {
    TestDrivers.surfaceShade(165.0f,94.0f,0f,0f,508.0f,718.0f,0f,-923.0f,0f,0f,0f,0f,0f,140.0f,-192.0f,18.0f,-986.0f,559.0f,411.0f,-7,1.7518122f,81.21143f,100.0f,-98.47389f,113.492096f,0f ) ;
  }

  @Test
  public void test1051() {
    TestDrivers.surfaceShade(1684.0f,1530.0f,0f,0f,227.0f,0.0f,0f,-739.0f,0f,0f,0f,0f,0f,-2364.0f,-831.0f,846.0f,0f,0f,0f,-2,100.0f,-1.5852779f,7.977933f,-84.29095f,45.55086f,0f ) ;
  }

  @Test
  public void test1052() {
    TestDrivers.surfaceShade(1705.0f,-2.0f,0f,0f,44.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-1208.0f,-174.0f,-1366.0f,0f,0f,0f,3,100.0f,-84.31555f,-73.89139f,-100.0f,1.7971057f,0f ) ;
  }

  @Test
  public void test1053() {
    TestDrivers.surfaceShade(1713.0f,-356.0f,0f,0f,1080.0f,-589.0f,0f,0.0f,0f,0f,0f,0f,0f,1053.0f,-245.0f,-28.0f,0f,0f,0f,2,-69.59136f,-10.42165f,-45.99647f,182.77666f,-98.87904f,0f ) ;
  }

  @Test
  public void test1054() {
    TestDrivers.surfaceShade(-178.0f,-1034.0f,0f,0f,371.0f,0.0f,0f,-1107.0f,0f,0f,0f,0f,0f,-1412.0f,-107.0f,666.0f,0f,0f,0f,4,37.167355f,52.019527f,81.05286f,-33.259617f,-21.246681f,0f ) ;
  }

  @Test
  public void test1055() {
    TestDrivers.surfaceShade(-1837.0f,-34.0f,0f,0f,4.0f,0.0f,0f,-3.0f,0f,0f,0f,0f,0f,-450.0f,-966.0f,1585.0f,0f,0f,0f,-3,3.2163098f,-1.179461f,-0.030637585f,25.69961f,1.2177914f,0f ) ;
  }

  @Test
  public void test1056() {
    TestDrivers.surfaceShade(1860.0f,900.0f,0f,0f,12.0f,767.0f,0f,-1285.0f,0f,0f,0f,0f,0f,2825.0f,623.0f,-622.0f,204.0f,-1318.0f,444.0f,1,5.10961f,-61.298565f,64.47376f,64.150345f,-18.36621f,0f ) ;
  }

  @Test
  public void test1057() {
    TestDrivers.surfaceShade(-186.0f,0f,0f,0f,44.918114f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-10.389383f,68.64346f,56.61635f,0f,0f,0f,1,6.2303715f,-79.103905f,-27.127144f,84.754944f,0f,0f ) ;
  }

  @Test
  public void test1058() {
    TestDrivers.surfaceShade(-186.0f,91.0f,0f,0f,58.0f,3.0f,0f,0.0f,0f,0f,0f,0f,0f,-1126.0f,-1004.0f,-151.0f,0f,0f,0f,6,81.14554f,-81.6842f,-61.97963f,-0.626252f,-0.38619587f,0f ) ;
  }

  @Test
  public void test1059() {
    TestDrivers.surfaceShade(1880.0f,0f,0f,0f,88.61665f,-98.83517f,0f,0.0f,0f,0f,0f,0f,0f,39.984623f,57.728813f,100.0f,0f,0f,0f,1,-100.0f,-44.915123f,37.586514f,-78.74014f,0f,0f ) ;
  }

  @Test
  public void test1060() {
    TestDrivers.surfaceShade(-1889.0f,0f,0f,0f,99.976906f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,37.21359f,-29.83956f,-99.997505f,0f,0f,0f,1,-0.9937863f,-0.5443276f,0.005886076f,-17.367294f,0f,0f ) ;
  }

  @Test
  public void test1061() {
    TestDrivers.surfaceShade(1894.0f,571.0f,-1180.0f,0f,605.0f,-1.0f,0f,-1424.0f,0f,0f,0f,0f,0f,-258.0f,-879.0f,-14.0f,0f,0f,0f,2,83.748795f,-23.308872f,-79.90643f,-8.059696f,100.0f,-7.474821f ) ;
  }

  @Test
  public void test1062() {
    TestDrivers.surfaceShade(190.0f,0f,0f,0f,70.08076f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,66.98544f,100.0f,-32.92414f,0f,0f,0f,1,0.37204787f,-0.024550816f,0.9278888f,88.80796f,0f,0f ) ;
  }

  @Test
  public void test1063() {
    TestDrivers.surfaceShade(-19.0f,781.0f,0f,0f,261.0f,6.0f,0f,-1.0f,0f,0f,0f,0f,0f,584.0f,-2727.0f,-617.0f,0f,0f,0f,5,-1.33184f,15.430695f,-69.30544f,5.006367f,15.358096f,0f ) ;
  }

  @Test
  public void test1064() {
    TestDrivers.surfaceShade(1917.0f,0f,0f,0f,100.0f,-32.942596f,0f,-100.0f,0f,0f,0f,0f,0f,-96.48976f,-80.85326f,-100.0f,0f,0f,0f,1,0.6158956f,-0.78671753f,0.041810527f,1.5798671f,0f,0f ) ;
  }

  @Test
  public void test1065() {
    TestDrivers.surfaceShade(-197.0f,0f,0f,0f,55.707554f,-7.7866898f,0f,0.0f,0f,0f,0f,0f,0f,-75.78478f,21.96064f,63.140835f,0f,0f,0f,1,47.05667f,94.72686f,6.8215075f,-34.986847f,0f,0f ) ;
  }

  @Test
  public void test1066() {
    TestDrivers.surfaceShade(1971.0f,43.0f,0f,0f,37.0f,-393.0f,0f,-871.0f,0f,0f,0f,0f,0f,874.0f,363.0f,1026.0f,0f,0f,0f,2,-99.11787f,0.24394514f,76.92243f,5.228735f,1.0351627E-5f,0f ) ;
  }

  @Test
  public void test1067() {
    TestDrivers.surfaceShade(200.0f,2133.0f,-1362.0f,0f,1166.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-1690.0f,-526.0f,911.0f,0f,0f,0f,-4,32.62701f,-56.925243f,-60.676247f,-12.312854f,-2.251734f,-100.0f ) ;
  }

  @Test
  public void test1068() {
    TestDrivers.surfaceShade(202.0f,0f,0f,0f,1056.0f,696.0f,0f,0f,0f,0f,0f,0f,0f,-311.0f,-574.0f,786.0f,-1.0f,-717.0f,-894.0f,2,13.85453f,5.421489f,7.5500093f,-10.762951f,0f,0f ) ;
  }

  @Test
  public void test1069() {
    TestDrivers.surfaceShade(-2066.0f,599.0f,-1020.0f,0f,1230.0f,0.0f,0f,-1270.0f,0f,0f,0f,0f,0f,293.0f,-681.0f,-292.0f,0f,0f,0f,4,100.0f,100.0f,69.65382f,-100.0f,-100.0f,68.14486f ) ;
  }

  @Test
  public void test1070() {
    TestDrivers.surfaceShade(-2072.0f,0f,0f,0f,1257.0f,722.0f,-725.0f,5.0f,0f,0f,0f,0f,0f,-193.0f,485.0f,875.0f,264.0f,767.0f,-47.0f,-2,185.8682f,84.11038f,-26.722244f,-99.5933f,0f,0f ) ;
  }

  @Test
  public void test1071() {
    TestDrivers.surfaceShade(-2.0f,1088.0f,0f,0f,3.0f,-904.0f,0f,-1262.0f,0f,0f,0f,0f,0f,-189.0f,876.0f,577.0f,0f,0f,0f,3,-84.21297f,47.263134f,-99.85933f,-0.077155136f,-100.0f,0f ) ;
  }

  @Test
  public void test1072() {
    TestDrivers.surfaceShade(2.0f,-196.0f,0f,0f,5.0f,-2542.0f,0f,-228.0f,0f,0f,0f,0f,0f,-399.0f,953.0f,-221.0f,0f,0f,0f,1,-100.0f,-65.08313f,-99.99914f,0.87216324f,-0.005063601f,0f ) ;
  }

  @Test
  public void test1073() {
    TestDrivers.surfaceShade(-215.0f,445.0f,0f,0f,16.0f,-1.0f,0f,-550.0f,0f,0f,0f,0f,0f,253.0f,-772.0f,841.0f,0f,0f,0f,10,-35.612293f,-31.776184f,-18.456148f,6.7306733f,-0.5557142f,0f ) ;
  }

  @Test
  public void test1074() {
    TestDrivers.surfaceShade(-219.0f,318.0f,0f,0f,366.0f,-538.0f,0f,-567.0f,0f,0f,0f,0f,0f,-341.0f,-430.0f,807.0f,0f,0f,0f,1,100.0f,100.0f,-100.0f,-26.432188f,100.0f,0f ) ;
  }

  @Test
  public void test1075() {
    TestDrivers.surfaceShade(-2222.0f,0f,0f,0f,426.0f,589.0f,1018.0f,-321.0f,0f,0f,0f,0f,0f,289.0f,-484.0f,1225.0f,-63.0f,-218.0f,461.0f,2,41.862297f,-50.72191f,-62.454723f,68.61947f,0f,0f ) ;
  }

  @Test
  public void test1076() {
    TestDrivers.surfaceShade(-2237.0f,0f,0f,0f,35.565083f,-15.98663f,0f,-63.954647f,0f,0f,0f,0f,0f,-91.938034f,110.349304f,100.0f,0f,0f,0f,-1,-0.08548272f,-0.1130285f,-0.14702834f,1.389584f,0f,0f ) ;
  }

  @Test
  public void test1077() {
    TestDrivers.surfaceShade(-225.0f,817.0f,0f,0f,1842.0f,-1270.0f,0f,-1415.0f,0f,0f,0f,0f,0f,-563.0f,1232.0f,731.0f,0f,0f,0f,2,66.977005f,-70.22259f,17.877491f,-98.41546f,92.93131f,0f ) ;
  }

  @Test
  public void test1078() {
    TestDrivers.surfaceShade(232.0f,532.0f,305.0f,0f,210.0f,-835.0f,0f,-446.0f,0f,0f,0f,0f,0f,890.0f,-425.0f,-482.0f,0f,0f,0f,1,-31.11416f,-100.0f,58.35301f,-20.884909f,-62.2566f,87.1741f ) ;
  }

  @Test
  public void test1079() {
    TestDrivers.surfaceShade(-236.0f,0f,0f,0f,0.006493143f,0.0f,0f,-96.68191f,0f,0f,0f,0f,0f,21.917255f,100.0f,53.106895f,0f,0f,0f,1,89.44353f,-2.5292645f,-32.688652f,-2.1764917f,0f,0f ) ;
  }

  @Test
  public void test1080() {
    TestDrivers.surfaceShade(242.0f,0f,0f,0f,577.0f,74.0f,0f,-1100.0f,0f,0f,0f,0f,0f,2029.0f,468.0f,506.0f,-956.0f,-289.0f,-1349.0f,3,-0.06475552f,7.5978047E-4f,0.014973655f,-57.033134f,0f,0f ) ;
  }

  @Test
  public void test1081() {
    TestDrivers.surfaceShade(2482.0f,802.0f,0f,0f,110.0f,1.0f,0f,-3.0f,0f,0f,0f,0f,0f,-1002.0f,702.0f,-1309.0f,0f,0f,0f,-1,73.286705f,100.0f,-2.4688482f,-3.8584485f,0.004902408f,0f ) ;
  }

  @Test
  public void test1082() {
    TestDrivers.surfaceShade(2483.0f,-4.0f,0f,0f,14.0f,0.0f,0f,-497.0f,0f,0f,0f,0f,0f,291.0f,-1619.0f,-690.0f,0f,0f,0f,-2,-23.119858f,38.690384f,-100.0f,31.30641f,0.057533678f,0f ) ;
  }

  @Test
  public void test1083() {
    TestDrivers.surfaceShade(-250.0f,0f,0f,0f,1125.0f,1364.0f,-342.0f,-3.0f,0f,0f,0f,0f,0f,-977.0f,565.0f,-779.0f,2214.0f,450.0f,535.0f,1,-0.423746f,-0.5091911f,0.1731813f,100.0f,0f,0f ) ;
  }

  @Test
  public void test1084() {
    TestDrivers.surfaceShade(250.0f,0f,0f,0f,24.162653f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,68.37826f,-100.0f,0f,0f,0f,1,-0.0310445f,-0.23328547f,-0.04535445f,50.47449f,0f,0f ) ;
  }

  @Test
  public void test1085() {
    TestDrivers.surfaceShade(254.0f,121.0f,604.0f,0f,566.0f,-468.0f,0f,-275.0f,0f,0f,0f,0f,0f,-256.0f,921.0f,-521.0f,0f,0f,0f,3,-54.11001f,-73.89846f,-71.733475f,6.3828053f,-100.0f,-52.002365f ) ;
  }

  @Test
  public void test1086() {
    TestDrivers.surfaceShade(2577.0f,0.0f,0f,0f,114.0f,-1058.0f,0f,-818.0f,0f,0f,0f,0f,0f,754.0f,-228.0f,1308.0f,0f,0f,0f,1,-100.0f,86.216606f,1.0782251f,100.0f,0.1463851f,0f ) ;
  }

  @Test
  public void test1087() {
    TestDrivers.surfaceShade(267.0f,300.0f,0f,0f,777.0f,-547.0f,0f,-944.0f,0f,0f,0f,0f,0f,359.0f,474.0f,960.0f,0f,0f,0f,2,-42.962273f,26.137096f,-67.87533f,-22.004913f,-77.63573f,0f ) ;
  }

  @Test
  public void test1088() {
    TestDrivers.surfaceShade(-269.0f,-1.0f,0f,0f,9.0f,404.0f,0f,-31.0f,0f,0f,0f,0f,0f,-367.0f,-813.0f,-503.0f,-175.0f,972.0f,1277.0f,2,11.658838f,56.604725f,-99.785515f,-54.73115f,-0.12050792f,0f ) ;
  }

  @Test
  public void test1089() {
    TestDrivers.surfaceShade(271.0f,2246.0f,0f,0f,758.0f,-1.0f,0f,-654.0f,0f,0f,0f,0f,0f,-949.0f,1434.0f,1075.0f,0f,0f,0f,-3,0.3242523f,-0.074217565f,-0.020639198f,-100.0f,-161.43915f,0f ) ;
  }

  @Test
  public void test1090() {
    TestDrivers.surfaceShade(2721.0f,0f,0f,0f,89.36892f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-95.549126f,-22.366821f,20.871376f,0f,0f,0f,1,100.0f,100.0f,100.0f,1.5250355f,0f,0f ) ;
  }

  @Test
  public void test1091() {
    TestDrivers.surfaceShade(-281.0f,0f,0f,0f,100.0f,0.0f,0f,-53.105675f,0f,0f,0f,0f,0f,54.580723f,103.10739f,-43.094795f,0f,0f,0f,1,24.896402f,-100.0f,-110.84851f,-75.39877f,0f,0f ) ;
  }

  @Test
  public void test1092() {
    TestDrivers.surfaceShade(283.0f,0f,0f,0f,3.8495241E-7f,-53.944714f,0f,0.0f,0f,0f,0f,0f,0f,-33.89204f,8.472142f,92.26084f,0f,0f,0f,1,78.67828f,-30.005873f,-99.69775f,98.8442f,0f,0f ) ;
  }

  @Test
  public void test1093() {
    TestDrivers.surfaceShade(286.0f,177.0f,0f,0f,3.0f,-3.0f,0f,-1.0f,0f,0f,0f,0f,0f,-43.0f,-345.0f,-930.0f,0f,0f,0f,5,0.59139115f,0.026618907f,2.8092945f,7.789462f,-16.691761f,0f ) ;
  }

  @Test
  public void test1094() {
    TestDrivers.surfaceShade(288.0f,0f,0f,0f,49.856167f,0.0f,0f,-23.306765f,0f,0f,0f,0f,0f,100.0f,74.93118f,11.778692f,0f,0f,0f,1,-82.88745f,-100.0f,26.397926f,-33.209034f,0f,0f ) ;
  }

  @Test
  public void test1095() {
    TestDrivers.surfaceShade(-2923.0f,1151.0f,-145.0f,0f,2.0f,-4.0f,0f,-828.0f,0f,0f,0f,0f,0f,2928.0f,849.0f,414.0f,0f,0f,0f,8,-0.41312605f,0.26311234f,1.0774215f,-28.19153f,-84.98032f,-4.8627524f ) ;
  }

  @Test
  public void test1096() {
    TestDrivers.surfaceShade(-307.0f,0f,0f,0f,41.95943f,-58.6833f,0f,-54.84984f,0f,0f,0f,0f,0f,4.0279174f,0.7751675f,17.770626f,0f,0f,0f,1,-0.69603723f,0.21620989f,-0.11062302f,-2.738588E-5f,0f,0f ) ;
  }

  @Test
  public void test1097() {
    TestDrivers.surfaceShade(-308.0f,0f,0f,0f,2.2259424E-5f,-100.0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-35.15053f,-100.0f,0f,0f,0f,1,-0.17636645f,-0.7502175f,0.41296482f,-3.9164908f,0f,0f ) ;
  }

  @Test
  public void test1098() {
    TestDrivers.surfaceShade(3.0f,0f,0f,0f,12.0f,-882.0f,0f,815.0f,0f,0f,0f,0f,0f,542.0f,-462.0f,403.0f,-1602.0f,-60.0f,-601.0f,3,21.168718f,96.18801f,81.79914f,9.853991f,0f,0f ) ;
  }

  @Test
  public void test1099() {
    TestDrivers.surfaceShade(-3.0f,353.0f,0f,0f,30.0f,-217.0f,0f,-1.0f,0f,0f,0f,0f,0f,-1911.0f,-851.0f,-149.0f,0f,0f,0f,-4,11.628175f,-6.356357f,-91.646805f,-3.259269E-4f,-47.747047f,0f ) ;
  }

  @Test
  public void test1100() {
    TestDrivers.surfaceShade(310.0f,3518.0f,0f,0f,8.0f,-1753.0f,0f,-1.0f,0f,0f,0f,0f,0f,-1169.0f,-1129.0f,777.0f,0f,0f,0f,-3,77.196785f,-100.0f,-36.284004f,9.562672E-6f,40.201153f,0f ) ;
  }

  @Test
  public void test1101() {
    TestDrivers.surfaceShade(-318.0f,0f,0f,0f,97.0f,535.0f,-350.0f,-465.0f,0f,0f,0f,0f,0f,-536.0f,-908.0f,-1278.0f,-787.0f,581.0f,-655.0f,3,-61.20649f,-100.0f,100.0f,100.0f,0f,0f ) ;
  }

  @Test
  public void test1102() {
    TestDrivers.surfaceShade(323.0f,0f,0f,0f,71.839294f,-117.35694f,0f,-6.302749f,0f,0f,0f,0f,0f,59.614113f,-65.38073f,67.54159f,0f,0f,0f,1,-78.6851f,-14.318223f,-50.95342f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test1103() {
    TestDrivers.surfaceShade(-324.0f,597.0f,0f,0f,1224.0f,-622.0f,0f,-385.0f,0f,0f,0f,0f,0f,-773.0f,-988.0f,144.0f,0f,0f,0f,2,-39.24764f,64.82756f,81.88587f,54.315067f,82.37481f,0f ) ;
  }

  @Test
  public void test1104() {
    TestDrivers.surfaceShade(327.0f,-764.0f,0f,0f,485.0f,-1546.0f,0f,-490.0f,0f,0f,0f,0f,0f,-576.0f,-584.0f,1944.0f,0f,0f,0f,-2,100.0f,19.574547f,33.309807f,-93.81456f,-128.06711f,0f ) ;
  }

  @Test
  public void test1105() {
    TestDrivers.surfaceShade(329.0f,0f,0f,0f,120.75003f,0.0f,0f,-53.514072f,0f,0f,0f,0f,0f,-100.0f,100.0f,27.836826f,0f,0f,0f,1,27.307388f,-100.0f,-168.46657f,-49.336285f,0f,0f ) ;
  }

  @Test
  public void test1106() {
    TestDrivers.surfaceShade(329.0f,940.0f,66.0f,0f,146.0f,2234.0f,0f,-222.0f,0f,0f,0f,0f,0f,922.0f,329.0f,1494.0f,-268.0f,-367.0f,-1422.0f,2,22.296621f,-100.0f,7.8546557f,84.24076f,-1.2583694f,1.754893E-5f ) ;
  }

  @Test
  public void test1107() {
    TestDrivers.surfaceShade(330.0f,-1487.0f,0f,0f,2160.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,362.0f,408.0f,-205.0f,0f,0f,0f,7,34.851093f,-53.2935f,13.382116f,160.86255f,-87.54414f,0f ) ;
  }

  @Test
  public void test1108() {
    TestDrivers.surfaceShade(333.0f,0f,0f,0f,703.0f,478.0f,0f,-18.0f,0f,0f,0f,0f,0f,-385.0f,-977.0f,-339.0f,1284.0f,1728.0f,686.0f,1,68.37871f,-1.9637783f,76.90212f,-45.003075f,0f,0f ) ;
  }

  @Test
  public void test1109() {
    TestDrivers.surfaceShade(335.0f,0f,0f,0f,816.0f,700.0f,0f,0f,0f,0f,0f,0f,0f,1667.0f,-1331.0f,-895.0f,-747.0f,1281.0f,1055.0f,-1,-23.4513f,14.8890505f,53.989418f,2.0714324E-9f,0f,0f ) ;
  }

  @Test
  public void test1110() {
    TestDrivers.surfaceShade(-338.0f,0f,0f,0f,579.0f,1286.0f,0f,-221.0f,0f,0f,0f,0f,0f,131.0f,399.0f,1893.0f,2969.0f,994.0f,-1062.0f,1,0.02345534f,-0.7540053f,-0.41150978f,-36.277184f,0f,0f ) ;
  }

  @Test
  public void test1111() {
    TestDrivers.surfaceShade(347.0f,0f,-10.0f,0f,20.0f,0.0f,0f,-884.0f,0f,0f,0f,0f,0f,-2046.0f,-866.0f,102.0f,0f,0f,0f,1,-0.5954213f,1.6803714f,-0.15768476f,-28.567701f,0f,-1.8021623E-4f ) ;
  }

  @Test
  public void test1112() {
    TestDrivers.surfaceShade(357.0f,0f,0f,0f,99.65064f,0.0f,0f,-68.342674f,0f,0f,0f,0f,0f,1.0356723f,99.23417f,17.393122f,0f,0f,0f,1,-0.09702237f,-0.19642736f,-0.9757064f,-41.662563f,0f,0f ) ;
  }

  @Test
  public void test1113() {
    TestDrivers.surfaceShade(36.0f,-1087.0f,0f,0f,344.0f,-569.0f,0f,0.0f,0f,0f,0f,0f,0f,362.0f,605.0f,-542.0f,0f,0f,0f,2,-21.94288f,100.0f,96.96846f,0.01377071f,100.0f,0f ) ;
  }

  @Test
  public void test1114() {
    TestDrivers.surfaceShade(-362.0f,0.0f,0f,0f,31.0f,-755.0f,0f,-914.0f,0f,0f,0f,0f,0f,221.0f,523.0f,-206.0f,0f,0f,0f,2,54.551018f,6.530722f,76.18818f,40.698982f,0.6948773f,0f ) ;
  }

  @Test
  public void test1115() {
    TestDrivers.surfaceShade(-363.0f,0f,0f,0f,100.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,60.666794f,100.0f,28.985384f,0f,0f,0f,1,-64.48177f,-100.0f,-27.693338f,-14.570372f,0f,0f ) ;
  }

  @Test
  public void test1116() {
    TestDrivers.surfaceShade(-365.0f,0f,0f,0f,100.0f,-5.695751f,0f,0.0f,0f,0f,0f,0f,0f,11.612757f,68.1021f,-9.707865f,0f,0f,0f,1,-53.45014f,-69.7147f,13.0179f,-18.106554f,0f,0f ) ;
  }

  @Test
  public void test1117() {
    TestDrivers.surfaceShade(-3675.0f,0f,0f,0f,100.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-88.76377f,30.694075f,99.99974f,0f,0f,0f,1,-0.25882763f,-0.5624752f,-0.16307482f,100.0f,0f,0f ) ;
  }

  @Test
  public void test1118() {
    TestDrivers.surfaceShade(377.0f,0f,0f,0f,76.4955f,-100.0f,0f,0.0f,0f,0f,0f,0f,0f,-30.396563f,100.0f,6.2441363f,0f,0f,0f,1,0.19565186f,0.035735548f,-0.35698268f,-62.688972f,0f,0f ) ;
  }

  @Test
  public void test1119() {
    TestDrivers.surfaceShade(-380.0f,0f,0f,0f,1473.0f,765.0f,-191.0f,-1725.0f,0f,0f,0f,0f,0f,-486.0f,-865.0f,-446.0f,590.0f,290.0f,232.0f,4,67.07845f,-35.696304f,72.50185f,42.594822f,0f,0f ) ;
  }

  @Test
  public void test1120() {
    TestDrivers.surfaceShade(-382.0f,-480.0f,0f,0f,13.0f,-3.0f,0f,0.0f,0f,0f,0f,0f,0f,446.0f,1542.0f,-797.0f,0f,0f,0f,5,0.34196442f,-0.8782875f,-0.10788239f,-5.619218f,-54.798717f,0f ) ;
  }

  @Test
  public void test1121() {
    TestDrivers.surfaceShade(-385.0f,-1362.0f,0f,0f,254.0f,0.0f,0f,-1540.0f,0f,0f,0f,0f,0f,-640.0f,-280.0f,-172.0f,0f,0f,0f,2,-0.17225584f,0.28905338f,0.490725f,0.10866176f,29.065083f,0f ) ;
  }

  @Test
  public void test1122() {
    TestDrivers.surfaceShade(-386.0f,0f,0f,0f,100.0f,0.0f,0f,-36.23673f,0f,0f,0f,0f,0f,7.0960374f,3.4151516f,100.0f,0f,0f,0f,1,0.2723932f,-0.004514136f,-0.8993548f,-3.855232E-7f,0f,0f ) ;
  }

  @Test
  public void test1123() {
    TestDrivers.surfaceShade(393.0f,13.0f,0f,0f,724.0f,0.0f,0f,-948.0f,0f,0f,0f,0f,0f,-34.0f,-1586.0f,-483.0f,0f,0f,0f,1,109.961914f,54.22016f,43.92451f,-53.729958f,-37.23803f,0f ) ;
  }

  @Test
  public void test1124() {
    TestDrivers.surfaceShade(-394.0f,217.0f,530.0f,0f,222.0f,-575.0f,0f,-651.0f,0f,0f,0f,0f,0f,322.0f,-396.0f,521.0f,0f,0f,0f,-1,80.618416f,70.563225f,-78.012924f,-25.263006f,-100.0f,24.5476f ) ;
  }

  @Test
  public void test1125() {
    TestDrivers.surfaceShade(-402.0f,355.0f,0f,0f,360.0f,-2.0f,0f,1.0f,0f,0f,0f,0f,0f,1180.0f,-818.0f,265.0f,0f,0f,0f,-1,-1.0892527f,0.1679362f,0.18993598f,5.1500015f,-92.59437f,0f ) ;
  }

  @Test
  public void test1126() {
    TestDrivers.surfaceShade(-416.0f,0f,0f,0f,94.438095f,0.0f,0f,-2.5680178E-18f,0f,0f,0f,0f,0f,-99.79108f,-57.284134f,-100.0f,0f,0f,0f,-1,2.4591439f,-0.10714358f,1.7869834f,100.0f,0f,0f ) ;
  }

  @Test
  public void test1127() {
    TestDrivers.surfaceShade(-416.0f,180.0f,0f,0f,41.0f,-143.0f,0f,-1.0f,0f,0f,0f,0f,0f,-504.0f,-715.0f,609.0f,0f,0f,0f,1,19.355871f,52.83725f,78.05252f,0.2557526f,6.3466177f,0f ) ;
  }

  @Test
  public void test1128() {
    TestDrivers.surfaceShade(432.0f,554.0f,0f,0f,391.0f,-338.0f,0f,0.0f,0f,0f,0f,0f,0f,-268.0f,-426.0f,74.0f,0f,0f,0f,1,58.09591f,100.0f,-88.88788f,-19.146458f,-100.0f,0f ) ;
  }

  @Test
  public void test1129() {
    TestDrivers.surfaceShade(438.0f,1848.0f,839.0f,0f,203.0f,469.0f,0f,-1123.0f,0f,0f,0f,0f,0f,951.0f,-967.0f,355.0f,220.0f,1596.0f,946.0f,4,28.231405f,50.245956f,0.17233983f,105.25783f,-30.484713f,-0.65201056f ) ;
  }

  @Test
  public void test1130() {
    TestDrivers.surfaceShade(442.0f,6.0f,0f,0f,4.0f,-1401.0f,0f,-76.0f,0f,0f,0f,0f,0f,-371.0f,-464.0f,-964.0f,0f,0f,0f,1,81.6853f,40.297245f,-50.793804f,-20.482576f,0.1145277f,0f ) ;
  }

  @Test
  public void test1131() {
    TestDrivers.surfaceShade(445.0f,365.0f,0f,0f,1588.0f,0.0f,0f,-343.0f,0f,0f,0f,0f,0f,385.0f,1118.0f,-645.0f,0f,0f,0f,4,-0.16245347f,-0.6313403f,0.3266732f,100.0f,100.0f,0f ) ;
  }

  @Test
  public void test1132() {
    TestDrivers.surfaceShade(-467.0f,0f,0f,0f,87.8456f,-6.3514886f,0f,-23.504322f,0f,0f,0f,0f,0f,-177.57903f,12.711721f,-95.80941f,0f,0f,0f,2,0.16335882f,-0.09051631f,-0.28697246f,-75.84956f,0f,0f ) ;
  }

  @Test
  public void test1133() {
    TestDrivers.surfaceShade(-49.0f,513.0f,0f,0f,50.0f,-23.0f,0f,-317.0f,0f,0f,0f,0f,0f,1726.0f,-438.0f,37.0f,0f,0f,0f,2,-7.177803f,-31.282469f,-35.482338f,-1.4975555f,-90.30878f,0f ) ;
  }

  @Test
  public void test1134() {
    TestDrivers.surfaceShade(-494.0f,0f,-377.0f,0f,851.0f,-931.0f,0f,-408.0f,0f,0f,0f,0f,0f,727.0f,-451.0f,423.0f,0f,0f,0f,3,69.424095f,77.70011f,-44.44318f,-38.35117f,0f,86.28623f ) ;
  }

  @Test
  public void test1135() {
    TestDrivers.surfaceShade(505.0f,-368.0f,0f,0f,952.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-550.0f,-620.0f,92.0f,0f,0f,0f,-1,98.42934f,-63.870075f,90.79871f,-88.560036f,-184.45279f,0f ) ;
  }

  @Test
  public void test1136() {
    TestDrivers.surfaceShade(5.0f,890.0f,0f,0f,141.0f,-174.0f,0f,3.0f,0f,0f,0f,0f,0f,308.0f,-396.0f,-83.0f,0f,0f,0f,-2,81.26471f,42.50946f,98.766556f,0.103972055f,100.0f,0f ) ;
  }

  @Test
  public void test1137() {
    TestDrivers.surfaceShade(-510.0f,-1152.0f,0f,0f,188.0f,0.0f,0f,-288.0f,0f,0f,0f,0f,0f,810.0f,-925.0f,206.0f,0f,0f,0f,2,-2.9490647f,88.67691f,-0.2729987f,-57.269188f,-1.2947353E-8f,0f ) ;
  }

  @Test
  public void test1138() {
    TestDrivers.surfaceShade(510.0f,981.0f,0f,0f,95.0f,1.0f,0f,-2610.0f,0f,0f,0f,0f,0f,496.0f,121.0f,-221.0f,0f,0f,0f,-3,-0.34370586f,-0.12920655f,0.66730624f,-100.0f,9.398739f,0f ) ;
  }

  @Test
  public void test1139() {
    TestDrivers.surfaceShade(-513.0f,0f,0f,0f,1.4085761E-7f,0.0f,0f,-7.1054274E-15f,0f,0f,0f,0f,0f,99.49991f,100.0f,100.0f,0f,0f,0f,3,-0.8353027f,-1.2182893f,-0.08632125f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test1140() {
    TestDrivers.surfaceShade(-526.0f,0f,0f,0f,521.0f,958.0f,-987.0f,1.0f,0f,0f,0f,0f,0f,-183.0f,325.0f,3.0f,-1285.0f,797.0f,-802.0f,1,-60.350227f,-87.77318f,-100.0f,46.80096f,0f,0f ) ;
  }

  @Test
  public void test1141() {
    TestDrivers.surfaceShade(-53.0f,0f,0f,0f,-478.0f,204.0f,826.0f,-662.0f,0f,0f,0f,0f,0f,60.0f,-463.0f,438.0f,-641.0f,-821.0f,185.0f,127,-7.7351875f,29.791777f,19.784826f,-74.63629f,0f,0f ) ;
  }

  @Test
  public void test1142() {
    TestDrivers.surfaceShade(-539.0f,1604.0f,0f,0f,1131.0f,1.0f,0f,-1696.0f,0f,0f,0f,0f,0f,-1266.0f,-307.0f,356.0f,0f,0f,0f,2,-3.3308063f,100.0f,-8.776584f,70.245865f,1.8699742E-9f,0f ) ;
  }

  @Test
  public void test1143() {
    TestDrivers.surfaceShade(-540.0f,-1221.0f,-253.0f,0f,427.0f,-1.0f,0f,-1130.0f,0f,0f,0f,0f,0f,-1072.0f,1015.0f,-179.0f,0f,0f,0f,3,78.6052f,14.042166f,-91.975624f,74.58668f,52.664127f,87.872955f ) ;
  }

  @Test
  public void test1144() {
    TestDrivers.surfaceShade(540.0f,-52.0f,0f,0f,2.0f,-1287.0f,0f,-3.0f,0f,0f,0f,0f,0f,780.0f,465.0f,3121.0f,0f,0f,0f,2,-1.3981345f,0.1931744f,-2.78891f,-8.1546f,-4.3812497E-6f,0f ) ;
  }

  @Test
  public void test1145() {
    TestDrivers.surfaceShade(-546.0f,240.0f,-1594.0f,0f,1081.0f,0.0f,0f,-656.0f,0f,0f,0f,0f,0f,-533.0f,234.0f,-118.0f,0f,0f,0f,2,40.8407f,38.882336f,-83.31898f,-57.484707f,-52.008884f,-12.245741f ) ;
  }

  @Test
  public void test1146() {
    TestDrivers.surfaceShade(-575.0f,0f,0f,0f,1094.0f,2492.0f,-1907.0f,2.0f,0f,0f,0f,0f,0f,-1309.0f,-1805.0f,-1317.0f,-644.0f,323.0f,-25.0f,3,0.80976f,0.042099584f,0.12869105f,-69.52585f,0f,0f ) ;
  }

  @Test
  public void test1147() {
    TestDrivers.surfaceShade(575.0f,0f,0f,0f,963.0f,1240.0f,0f,0f,0f,0f,0f,0f,0f,240.0f,-56.0f,-371.0f,-1091.0f,231.0f,-363.0f,3,100.0f,48.04787f,100.0f,89.80552f,0f,0f ) ;
  }

  @Test
  public void test1148() {
    TestDrivers.surfaceShade(-578.0f,0f,307.0f,0f,538.0f,-753.0f,0f,-194.0f,0f,0f,0f,0f,0f,926.0f,128.0f,535.0f,0f,0f,0f,1,-30.816238f,67.923485f,-51.307446f,35.15822f,0f,19.017862f ) ;
  }

  @Test
  public void test1149() {
    TestDrivers.surfaceShade(-588.0f,1546.0f,-99.0f,0f,50.0f,0.0f,0f,-1316.0f,0f,0f,0f,0f,0f,-864.0f,1286.0f,699.0f,0f,0f,0f,3,-100.0f,-40.914036f,-48.333607f,-51.46201f,-43.977367f,-0.03738753f ) ;
  }

  @Test
  public void test1150() {
    TestDrivers.surfaceShade(59.0f,0f,0f,0f,5.5344095f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,13.04185f,-99.45669f,-10.874206f,0f,0f,0f,3,-0.80276436f,0.11087455f,0.39481136f,1.0704431E-4f,0f,0f ) ;
  }

  @Test
  public void test1151() {
    TestDrivers.surfaceShade(-591.0f,0f,0f,0f,38.82156f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,71.77772f,24.551573f,30.379807f,0f,0f,0f,1,-0.47657317f,-0.6039479f,0.6388466f,-87.24844f,0f,0f ) ;
  }

  @Test
  public void test1152() {
    TestDrivers.surfaceShade(-596.0f,1096.0f,0f,0f,2221.0f,-237.0f,0f,0.0f,0f,0f,0f,0f,0f,1375.0f,136.0f,-660.0f,0f,0f,0f,-1,-77.57748f,33.15728f,45.815193f,2.7766518E-9f,-42.48147f,0f ) ;
  }

  @Test
  public void test1153() {
    TestDrivers.surfaceShade(599.0f,-1089.0f,0f,0f,1169.0f,-460.0f,0f,-3.0f,0f,0f,0f,0f,0f,716.0f,-87.0f,-26.0f,0f,0f,0f,1,-27.16453f,-68.222885f,-41.639816f,-100.0f,-144.38048f,0f ) ;
  }

  @Test
  public void test1154() {
    TestDrivers.surfaceShade(6.0f,2103.0f,0f,0f,6.0f,9.0f,0f,-1886.0f,0f,0f,0f,0f,0f,-341.0f,170.0f,413.0f,0f,0f,0f,1,6.82396f,65.6231f,-22.729925f,0.0050015347f,14.987489f,0f ) ;
  }

  @Test
  public void test1155() {
    TestDrivers.surfaceShade(-6.0f,50.0f,0f,0f,57.0f,2.0f,0f,1.0f,0f,0f,0f,0f,0f,-102.0f,1463.0f,692.0f,0f,0f,0f,2,-2.8613527f,1.9321703f,-4.6202602f,-100.0f,6.522107f,0f ) ;
  }

  @Test
  public void test1156() {
    TestDrivers.surfaceShade(614.0f,0f,0f,0f,38.936123f,-23.029156f,0f,-100.0f,0f,0f,0f,0f,0f,44.753723f,95.88915f,2.3070831f,0f,0f,0f,1,86.52287f,-40.665936f,11.790351f,76.761475f,0f,0f ) ;
  }

  @Test
  public void test1157() {
    TestDrivers.surfaceShade(620.0f,54.0f,0f,0f,2.0f,0.0f,0f,-1068.0f,0f,0f,0f,0f,0f,687.0f,685.0f,426.0f,0f,0f,0f,4,-0.6721641f,-0.7333915f,-0.10164811f,100.0f,-0.07720328f,0f ) ;
  }

  @Test
  public void test1158() {
    TestDrivers.surfaceShade(625.0f,-450.0f,0f,0f,6.0f,-1088.0f,0f,-1062.0f,0f,0f,0f,0f,0f,-1322.0f,548.0f,703.0f,0f,0f,0f,3,75.50072f,53.396824f,100.0f,-39.843082f,-2.0138746E-4f,0f ) ;
  }

  @Test
  public void test1159() {
    TestDrivers.surfaceShade(-626.0f,0f,0f,0f,17.928623f,-100.0f,0f,-16.263817f,0f,0f,0f,0f,0f,-21.751822f,8.059774f,-7.6975713f,0f,0f,0f,1,-20.09594f,1.673084f,93.033936f,11.564015f,0f,0f ) ;
  }

  @Test
  public void test1160() {
    TestDrivers.surfaceShade(629.0f,0f,0f,0f,56.145195f,-38.193783f,0f,-2.4771843f,0f,0f,0f,0f,0f,-12.7149725f,56.29415f,-45.02788f,0f,0f,0f,2,-0.4232968f,0.14438379f,0.37328306f,5.0017748E-6f,0f,0f ) ;
  }

  @Test
  public void test1161() {
    TestDrivers.surfaceShade(63.0f,1050.0f,0f,0f,1802.0f,-1042.0f,0f,-1.0f,0f,0f,0f,0f,0f,258.0f,-373.0f,-261.0f,0f,0f,0f,-1,-42.91087f,-8.998288f,33.21452f,20.407942f,-86.7749f,0f ) ;
  }

  @Test
  public void test1162() {
    TestDrivers.surfaceShade(633.0f,409.0f,1437.0f,0f,1408.0f,-1.0f,0f,-1.0f,0f,0f,0f,0f,0f,-1260.0f,353.0f,1657.0f,0f,0f,0f,2,1.030816f,8.030651f,-120.93426f,-100.0f,-137.50969f,-100.0f ) ;
  }

  @Test
  public void test1163() {
    TestDrivers.surfaceShade(636.0f,0f,0f,0f,16.916363f,-99.964226f,0f,-100.0f,0f,0f,0f,0f,0f,-89.50624f,-15.975187f,-3.446781f,0f,0f,0f,-2,0.061213005f,0.60081667f,-0.7970397f,99.99965f,0f,0f ) ;
  }

  @Test
  public void test1164() {
    TestDrivers.surfaceShade(-641.0f,0f,0f,0f,1230.0f,-674.0f,0f,908.0f,0f,0f,0f,0f,0f,435.0f,-50.0f,-481.0f,198.0f,552.0f,874.0f,6,-90.96831f,-59.80423f,52.468044f,23.021704f,0f,0f ) ;
  }

  @Test
  public void test1165() {
    TestDrivers.surfaceShade(-645.0f,-624.0f,-719.0f,0f,446.0f,1.0f,0f,-877.0f,0f,0f,0f,0f,0f,-117.0f,435.0f,-18.0f,0f,0f,0f,-2,100.0f,-12.276734f,72.433876f,17.277508f,36.778217f,31.587782f ) ;
  }

  @Test
  public void test1166() {
    TestDrivers.surfaceShade(-647.0f,200.0f,29.0f,0f,23.0f,-177.0f,0f,5.0f,0f,0f,0f,0f,0f,569.0f,54.0f,-1380.0f,0f,0f,0f,1,-100.0f,-49.889877f,-43.02296f,73.11185f,-100.0f,-0.4421666f ) ;
  }

  @Test
  public void test1167() {
    TestDrivers.surfaceShade(-648.0f,720.0f,0f,0f,552.0f,-548.0f,0f,-561.0f,0f,0f,0f,0f,0f,-164.0f,-763.0f,401.0f,0f,0f,0f,-1,-42.006935f,100.0f,-100.0f,-10.016524f,-13.504965f,0f ) ;
  }

  @Test
  public void test1168() {
    TestDrivers.surfaceShade(650.0f,1378.0f,0f,0f,985.0f,-1360.0f,0f,-142.0f,0f,0f,0f,0f,0f,278.0f,-534.0f,586.0f,0f,0f,0f,1,-73.19042f,72.26536f,99.882866f,-48.087437f,64.03517f,0f ) ;
  }

  @Test
  public void test1169() {
    TestDrivers.surfaceShade(65.0f,-926.0f,0f,0f,446.0f,-2.0f,0f,1.0f,0f,0f,0f,0f,0f,715.0f,-242.0f,-955.0f,0f,0f,0f,1,-100.0f,-100.0f,18.68384f,100.0f,-38.922985f,0f ) ;
  }

  @Test
  public void test1170() {
    TestDrivers.surfaceShade(-66.0f,0f,0f,0f,11.0f,3030.0f,0f,-604.0f,0f,0f,0f,0f,0f,-191.0f,104.0f,662.0f,-670.0f,781.0f,-1174.0f,4,17.299187f,-12.232721f,6.908965f,-0.011748917f,0f,0f ) ;
  }

  @Test
  public void test1171() {
    TestDrivers.surfaceShade(669.0f,0f,0f,0f,28.563225f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,-1.1039352f,100.0f,100.0f,0f,0f,0f,2,-0.17809701f,0.083481856f,-1.0596809f,-99.73643f,0f,0f ) ;
  }

  @Test
  public void test1172() {
    TestDrivers.surfaceShade(672.0f,0f,0f,0f,24.191334f,-47.69748f,0f,0.0f,0f,0f,0f,0f,0f,50.63186f,-1.6209688f,53.28598f,0f,0f,0f,1,-79.86269f,-54.15361f,-14.235176f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test1173() {
    TestDrivers.surfaceShade(-68.0f,0f,0f,0f,66.91615f,0.0f,0f,-77.17163f,0f,0f,0f,0f,0f,12.933936f,34.808f,1.769717f,0f,0f,0f,2,0.3322222f,-0.20221314f,0.9071238f,-1.8903204E-4f,0f,0f ) ;
  }

  @Test
  public void test1174() {
    TestDrivers.surfaceShade(-68.0f,-1849.0f,0f,0f,23.0f,-944.0f,0f,-245.0f,0f,0f,0f,0f,0f,204.0f,-905.0f,62.0f,0f,0f,0f,4,25.451359f,12.373748f,96.867874f,-0.32011375f,-5.5658866E-6f,0f ) ;
  }

  @Test
  public void test1175() {
    TestDrivers.surfaceShade(68.0f,549.0f,0f,0f,9.0f,4.0f,0f,-866.0f,0f,0f,0f,0f,0f,108.0f,227.0f,30.0f,0f,0f,0f,-5,11.466346f,-19.407614f,100.0f,0.0010020083f,-61.704082f,0f ) ;
  }

  @Test
  public void test1176() {
    TestDrivers.surfaceShade(-686.0f,-282.0f,0f,0f,803.0f,-84.0f,0f,-99.0f,0f,0f,0f,0f,0f,576.0f,-764.0f,100.0f,0f,0f,0f,1,8.21702f,80.381905f,36.98717f,-9.210824f,20.194464f,0f ) ;
  }

  @Test
  public void test1177() {
    TestDrivers.surfaceShade(-691.0f,0f,0f,0f,100.0f,0.0f,0f,-91.109406f,0f,0f,0f,0f,0f,-59.296017f,-33.831234f,-50.990112f,0f,0f,0f,1,100.0f,8.056322f,71.63063f,-165.57516f,0f,0f ) ;
  }

  @Test
  public void test1178() {
    TestDrivers.surfaceShade(-691.0f,-789.0f,0f,0f,715.0f,0.0f,0f,-1959.0f,0f,0f,0f,0f,0f,-1224.0f,214.0f,-278.0f,0f,0f,0f,1,0.33013123f,0.94171387f,-0.06471743f,100.0f,100.0f,0f ) ;
  }

  @Test
  public void test1179() {
    TestDrivers.surfaceShade(-696.0f,943.0f,0f,0f,1309.0f,0.0f,0f,-842.0f,0f,0f,0f,0f,0f,-416.0f,-295.0f,7.0f,0f,0f,0f,2,59.720173f,-38.13385f,93.33633f,5.7528267f,7.3360504E-9f,0f ) ;
  }

  @Test
  public void test1180() {
    TestDrivers.surfaceShade(-700.0f,0f,0f,0f,141.8492f,-90.541336f,0f,0.0f,0f,0f,0f,0f,0f,-28.640072f,24.261795f,-175.26447f,0f,0f,0f,2,0.12585804f,-0.081026584f,0.90360165f,-97.426056f,0f,0f ) ;
  }

  @Test
  public void test1181() {
    TestDrivers.surfaceShade(7.0f,530.0f,0f,0f,45.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-1169.0f,-1028.0f,-395.0f,0f,0f,0f,-1,-100.0f,100.0f,87.36163f,0.17210999f,-96.90877f,0f ) ;
  }

  @Test
  public void test1182() {
    TestDrivers.surfaceShade(7.0f,70.0f,0f,0f,52.0f,-1783.0f,0f,1.0f,0f,0f,0f,0f,0f,-446.0f,30.0f,805.0f,0f,0f,0f,-2,-85.92408f,-87.231735f,-44.365086f,-0.90953404f,0.002054449f,0f ) ;
  }

  @Test
  public void test1183() {
    TestDrivers.surfaceShade(-721.0f,0f,328.0f,0f,490.0f,-676.0f,0f,-1677.0f,0f,0f,0f,0f,0f,-7.0f,389.0f,634.0f,0f,0f,0f,2,147.1644f,-12.542495f,-23.212156f,-31.388515f,0f,90.01706f ) ;
  }

  @Test
  public void test1184() {
    TestDrivers.surfaceShade(-734.0f,2017.0f,0f,0f,1376.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,522.0f,-502.0f,208.0f,0f,0f,0f,-8,-39.68884f,-45.734398f,-55.14784f,-62.171688f,-13.403961f,0f ) ;
  }

  @Test
  public void test1185() {
    TestDrivers.surfaceShade(745.0f,0f,0f,0f,100.0f,-100.0f,0f,-1.0842022E-19f,0f,0f,0f,0f,0f,-18.457087f,100.0f,-25.197552f,0f,0f,0f,5,0.99906796f,0.13584778f,-0.19268163f,-0.7270687f,0f,0f ) ;
  }

  @Test
  public void test1186() {
    TestDrivers.surfaceShade(752.0f,552.0f,-3.0f,0f,89.0f,3.0f,0f,-1300.0f,0f,0f,0f,0f,0f,119.0f,-181.0f,-646.0f,0f,0f,0f,-1,-95.32763f,40.407623f,-28.881805f,75.33555f,-99.13772f,-3.316738f ) ;
  }

  @Test
  public void test1187() {
    TestDrivers.surfaceShade(-754.0f,0f,0f,0f,100.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,37.793446f,-89.797844f,-37.010365f,0f,0f,0f,1,82.24238f,62.208096f,-66.95233f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test1188() {
    TestDrivers.surfaceShade(-77.0f,0f,0f,0f,99.650505f,0.0f,0f,-54.5003f,0f,0f,0f,0f,0f,-25.268589f,65.79414f,73.95932f,0f,0f,0f,1,-40.299973f,3.9179833f,-79.03018f,-9.676783f,0f,0f ) ;
  }

  @Test
  public void test1189() {
    TestDrivers.surfaceShade(-777.0f,-10.0f,0f,0f,4.0f,-4.0f,0f,1.0f,0f,0f,0f,0f,0f,649.0f,1222.0f,-1544.0f,0f,0f,0f,14,40.335632f,100.0f,96.520195f,-73.71712f,20.304356f,0f ) ;
  }

  @Test
  public void test1190() {
    TestDrivers.surfaceShade(-788.0f,-25.0f,0f,0f,9.0f,-329.0f,0f,-5.0f,0f,0f,0f,0f,0f,271.0f,1949.0f,549.0f,0f,0f,0f,1,146.49155f,-28.312092f,27.327482f,34.18527f,-3.8764012f,0f ) ;
  }

  @Test
  public void test1191() {
    TestDrivers.surfaceShade(79.0f,-1053.0f,0f,0f,230.0f,1.0f,0f,0.0f,0f,0f,0f,0f,0f,759.0f,-751.0f,321.0f,0f,0f,0f,3,44.88673f,103.11385f,-100.0f,-25.461428f,70.33268f,0f ) ;
  }

  @Test
  public void test1192() {
    TestDrivers.surfaceShade(-800.0f,-615.0f,0f,0f,1.0f,-2051.0f,0f,0.0f,0f,0f,0f,0f,0f,1389.0f,642.0f,-484.0f,0f,0f,0f,-2,-76.29565f,-133.97333f,-100.0f,-129.23332f,-22.231247f,0f ) ;
  }

  @Test
  public void test1193() {
    TestDrivers.surfaceShade(807.0f,-1732.0f,0f,0f,141.0f,-636.0f,0f,0.0f,0f,0f,0f,0f,0f,579.0f,713.0f,-461.0f,0f,0f,0f,1,100.0f,-100.0f,-7.9596786f,-154.95102f,-100.0f,0f ) ;
  }

  @Test
  public void test1194() {
    TestDrivers.surfaceShade(-8.0f,0f,0f,0f,0.031407677f,0.0f,0f,-66.08287f,0f,0f,0f,0f,0f,91.69264f,-99.93136f,8.451674f,0f,0f,0f,1,-100.0f,-86.15438f,65.52862f,-99.18391f,0f,0f ) ;
  }

  @Test
  public void test1195() {
    TestDrivers.surfaceShade(8.0f,-43.0f,0f,0f,78.0f,-2.0f,0f,0.0f,0f,0f,0f,0f,0f,-474.0f,1503.0f,330.0f,0f,0f,0f,16,75.2863f,33.60332f,-61.574795f,-0.0058256765f,100.0f,0f ) ;
  }

  @Test
  public void test1196() {
    TestDrivers.surfaceShade(-820.0f,-3.0f,0f,0f,2.0f,-489.0f,0f,0.0f,0f,0f,0f,0f,0f,802.0f,-1211.0f,-1305.0f,0f,0f,0f,-1,100.0f,100.0f,-30.236706f,100.0f,-0.01672539f,0f ) ;
  }

  @Test
  public void test1197() {
    TestDrivers.surfaceShade(-82.0f,-471.0f,0f,0f,1581.0f,-1.0f,0f,2.0f,0f,0f,0f,0f,0f,-438.0f,-1931.0f,-85.0f,0f,0f,0f,5,-65.20775f,84.6031f,97.54865f,-63.06229f,115.788315f,0f ) ;
  }

  @Test
  public void test1198() {
    TestDrivers.surfaceShade(821.0f,529.0f,0f,0f,400.0f,-775.0f,0f,0.0f,0f,0f,0f,0f,0f,158.0f,-736.0f,-678.0f,0f,0f,0f,2,-96.148964f,33.91095f,76.8694f,59.644146f,14.3005705f,0f ) ;
  }

  @Test
  public void test1199() {
    TestDrivers.surfaceShade(826.0f,663.0f,429.0f,0f,839.0f,-736.0f,0f,-457.0f,0f,0f,0f,0f,0f,788.0f,-982.0f,-373.0f,0f,0f,0f,2,-85.97223f,-54.74424f,25.656857f,-77.74781f,100.0f,-76.118286f ) ;
  }

  @Test
  public void test1200() {
    TestDrivers.surfaceShade(837.0f,-1126.0f,0f,0f,1057.0f,0.0f,0f,-491.0f,0f,0f,0f,0f,0f,1823.0f,-896.0f,-310.0f,0f,0f,0f,1,-94.26172f,46.865387f,-100.0f,100.0f,100.0f,0f ) ;
  }

  @Test
  public void test1201() {
    TestDrivers.surfaceShade(-839.0f,0f,0f,0f,422.0f,1208.0f,708.0f,-1102.0f,0f,0f,0f,0f,0f,-661.0f,-246.0f,-962.0f,-294.0f,489.0f,-501.0f,-10,0.66306037f,-0.100199394f,-0.10889182f,-18.297802f,0f,0f ) ;
  }

  @Test
  public void test1202() {
    TestDrivers.surfaceShade(-844.0f,0f,0f,0f,1555.0f,0.0f,0f,364.0f,0f,0f,0f,0f,0f,-109.0f,33.0f,1525.0f,659.0f,-595.0f,-899.0f,2,-100.0f,-148.5768f,-100.0f,-0.23780377f,0f,0f ) ;
  }

  @Test
  public void test1203() {
    TestDrivers.surfaceShade(-846.0f,-910.0f,0f,0f,3.0f,553.0f,0f,-646.0f,0f,0f,0f,0f,0f,-665.0f,-693.0f,776.0f,15.0f,141.0f,29.0f,4,35.756695f,-93.52911f,-52.883957f,100.0f,-0.087203845f,0f ) ;
  }

  @Test
  public void test1204() {
    TestDrivers.surfaceShade(853.0f,0f,0f,0f,100.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,44.94254f,76.18409f,0f,0f,0f,1,-0.201549f,-0.18958165f,0.29505557f,88.62082f,0f,0f ) ;
  }

  @Test
  public void test1205() {
    TestDrivers.surfaceShade(-856.0f,-505.0f,0f,0f,115.0f,0.0f,0f,-1003.0f,0f,0f,0f,0f,0f,658.0f,-447.0f,742.0f,0f,0f,0f,2,24.78076f,73.99025f,3.3670878f,46.142685f,-30.094168f,0f ) ;
  }

  @Test
  public void test1206() {
    TestDrivers.surfaceShade(-866.0f,0f,0f,0f,100.0f,1.166849E-39f,0f,-0.0f,0f,0f,0f,0f,0f,-85.420364f,46.469147f,12.395164f,0f,0f,0f,1,-61.755074f,-100.0f,-50.683178f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test1207() {
    TestDrivers.surfaceShade(-867.0f,0f,0f,0f,73.19647f,0.0f,0f,-2.2020624E-32f,0f,0f,0f,0f,0f,-4.6787643f,39.20787f,9.634069f,0f,0f,0f,-1,14.19262f,2.1206896f,-1.7379776f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test1208() {
    TestDrivers.surfaceShade(-868.0f,0f,0f,0f,58.54445f,0.0f,0f,-26.430859f,0f,0f,0f,0f,0f,100.0f,41.04045f,-24.803661f,0f,0f,0f,1,-15.908789f,-100.0f,-100.0f,71.500984f,0f,0f ) ;
  }

  @Test
  public void test1209() {
    TestDrivers.surfaceShade(-869.0f,0f,0f,0f,1016.0f,0.0f,0f,865.0f,0f,0f,0f,0f,0f,193.0f,1560.0f,505.0f,-2731.0f,-10.0f,-559.0f,6,-65.36648f,-22.07856f,-89.529945f,34.345974f,0f,0f ) ;
  }

  @Test
  public void test1210() {
    TestDrivers.surfaceShade(877.0f,2401.0f,0f,0f,84.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,755.0f,-252.0f,-111.0f,0f,0f,0f,1,-42.819077f,98.53289f,100.0f,-28.941135f,-61.69879f,0f ) ;
  }

  @Test
  public void test1211() {
    TestDrivers.surfaceShade(880.0f,0f,0f,0f,65.074745f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-88.342545f,-65.25942f,20.31441f,0f,0f,0f,1,-18.201847f,17.100973f,-68.8977f,-45.145386f,0f,0f ) ;
  }

  @Test
  public void test1212() {
    TestDrivers.surfaceShade(884.0f,2818.0f,0f,0f,27.0f,-50.0f,0f,-2315.0f,0f,0f,0f,0f,0f,942.0f,326.0f,-767.0f,0f,0f,0f,-1,64.85454f,47.780014f,100.0f,1.7502574E-4f,55.70914f,0f ) ;
  }

  @Test
  public void test1213() {
    TestDrivers.surfaceShade(885.0f,1022.0f,0f,0f,2055.0f,1.0f,0f,-1542.0f,0f,0f,0f,0f,0f,-897.0f,-2246.0f,-1719.0f,0f,0f,0f,-4,-0.016349599f,0.99894214f,-0.042980798f,-57.501225f,31.250328f,0f ) ;
  }

  @Test
  public void test1214() {
    TestDrivers.surfaceShade(885.0f,-890.0f,0f,0f,781.0f,0.0f,0f,-1870.0f,0f,0f,0f,0f,0f,-642.0f,-2394.0f,-379.0f,0f,0f,0f,1,-0.588033f,0.63383275f,0.04703643f,-100.0f,-100.0f,0f ) ;
  }

  @Test
  public void test1215() {
    TestDrivers.surfaceShade(89.0f,-314.0f,3.0f,0f,86.0f,-348.0f,0f,-1607.0f,0f,0f,0f,0f,0f,727.0f,990.0f,386.0f,0f,0f,0f,5,71.37372f,-82.78621f,77.89987f,-30.30187f,-11.738524f,1.7083048f ) ;
  }

  @Test
  public void test1216() {
    TestDrivers.surfaceShade(-897.0f,-44.0f,0f,0f,376.0f,2.0f,0f,-1062.0f,0f,0f,0f,0f,0f,549.0f,-705.0f,-1194.0f,0f,0f,0f,4,-1.6874336f,-0.61946553f,-0.37343016f,86.32505f,0.051431417f,0f ) ;
  }

  @Test
  public void test1217() {
    TestDrivers.surfaceShade(90.0f,989.0f,0f,0f,887.0f,0.0f,0f,-1076.0f,0f,0f,0f,0f,0f,-664.0f,235.0f,-728.0f,0f,0f,0f,1,87.91141f,-91.692184f,38.835117f,-28.748228f,-80.554f,0f ) ;
  }

  @Test
  public void test1218() {
    TestDrivers.surfaceShade(-9.0f,-248.0f,0f,0f,69.0f,-1769.0f,0f,-1056.0f,0f,0f,0f,0f,0f,-755.0f,981.0f,218.0f,0f,0f,0f,-1,-100.0f,-100.0f,100.0f,0.0039092177f,-16.846651f,0f ) ;
  }

  @Test
  public void test1219() {
    TestDrivers.surfaceShade(-920.0f,1138.0f,1332.0f,0f,2479.0f,-11.0f,0f,-1150.0f,0f,0f,0f,0f,0f,-514.0f,1057.0f,-655.0f,0f,0f,0f,-4,-0.010825082f,-1.370206f,-0.08011192f,-100.0f,-65.5824f,20.616716f ) ;
  }

  @Test
  public void test1220() {
    TestDrivers.surfaceShade(-920.0f,-609.0f,0f,0f,206.0f,145.0f,0f,-1655.0f,0f,0f,0f,0f,0f,-826.0f,126.0f,-278.0f,-364.0f,-914.0f,1747.0f,3,100.0f,100.0f,-100.0f,-100.0f,-83.81574f,0f ) ;
  }

  @Test
  public void test1221() {
    TestDrivers.surfaceShade(-921.0f,779.0f,1522.0f,0f,282.0f,-548.0f,0f,0.0f,0f,0f,0f,0f,0f,1194.0f,327.0f,274.0f,0f,0f,0f,4,-11.185905f,-58.9582f,-53.107643f,67.8972f,-62.583897f,-32.129173f ) ;
  }

  @Test
  public void test1222() {
    TestDrivers.surfaceShade(-922.0f,-724.0f,0f,0f,138.0f,-222.0f,0f,-655.0f,0f,0f,0f,0f,0f,-811.0f,204.0f,344.0f,0f,0f,0f,4,-4.156353f,-59.78855f,-126.63931f,-60.86384f,-47.013226f,0f ) ;
  }

  @Test
  public void test1223() {
    TestDrivers.surfaceShade(-933.0f,330.0f,0f,0f,310.0f,0.0f,0f,-849.0f,0f,0f,0f,0f,0f,1269.0f,-780.0f,92.0f,0f,0f,0f,-1,-21.940601f,97.47725f,74.46848f,-0.54086894f,-4.6593094f,0f ) ;
  }

  @Test
  public void test1224() {
    TestDrivers.surfaceShade(-935.0f,-1629.0f,0f,0f,337.0f,-1512.0f,0f,-348.0f,0f,0f,0f,0f,0f,-508.0f,-1642.0f,-1534.0f,0f,0f,0f,2,-68.97303f,1.2901815f,100.0f,100.0f,100.0f,0f ) ;
  }

  @Test
  public void test1225() {
    TestDrivers.surfaceShade(937.0f,0f,0f,0f,97.54558f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,99.17675f,18.610844f,18.202385f,0f,0f,0f,5,-0.7573634f,0.057052538f,0.58433723f,89.18842f,0f,0f ) ;
  }

  @Test
  public void test1226() {
    TestDrivers.surfaceShade(946.0f,0f,1575.0f,0f,1171.0f,-2.0f,0f,-566.0f,0f,0f,0f,0f,0f,1497.0f,1564.0f,-1387.0f,0f,0f,0f,-2,0.014449592f,0.10096243f,0.18495375f,-68.0452f,0f,92.61977f ) ;
  }

  @Test
  public void test1227() {
    TestDrivers.surfaceShade(953.0f,0f,0f,0f,0.42229992f,-24.223858f,0f,-41.29401f,0f,0f,0f,0f,0f,-5.6250615f,49.119785f,-31.39838f,0f,0f,0f,1,-100.0f,-69.20215f,29.434118f,20.465157f,0f,0f ) ;
  }

  @Test
  public void test1228() {
    TestDrivers.surfaceShade(962.0f,-77.0f,0f,0f,489.0f,-950.0f,0f,-1776.0f,0f,0f,0f,0f,0f,127.0f,-460.0f,662.0f,0f,0f,0f,1,5.937758f,-100.0f,-70.66523f,-0.06894255f,0.08734593f,0f ) ;
  }

  @Test
  public void test1229() {
    TestDrivers.surfaceShade(964.0f,0f,0f,0f,-982.0f,804.0f,669.0f,-411.0f,0f,0f,0f,0f,0f,-295.0f,-123.0f,967.0f,173.0f,993.0f,697.0f,-977,35.307545f,-72.24814f,-74.683945f,99.46389f,0f,0f ) ;
  }

  @Test
  public void test1230() {
    TestDrivers.surfaceShade(-970.0f,-96.0f,0f,0f,593.0f,-171.0f,0f,-195.0f,0f,0f,0f,0f,0f,-555.0f,120.0f,-178.0f,0f,0f,0f,3,19.473648f,-9.9979f,15.209078f,-35.128147f,65.58933f,0f ) ;
  }

  @Test
  public void test1231() {
    TestDrivers.surfaceShade(-982.0f,387.0f,143.0f,0f,1212.0f,-204.0f,0f,-897.0f,0f,0f,0f,0f,0f,-206.0f,-404.0f,-616.0f,0f,0f,0f,1,90.09465f,1.8696558f,24.721184f,25.2924f,7.666049E-9f,33.567493f ) ;
  }

  @Test
  public void test1232() {
    TestDrivers.surfaceShade(-985.0f,0f,0f,0f,79.0f,536.0f,334.0f,-713.0f,0f,0f,0f,0f,0f,534.0f,923.0f,307.0f,45.0f,57.0f,189.0f,2,100.0f,-100.0f,68.778404f,73.137085f,0f,0f ) ;
  }
}
