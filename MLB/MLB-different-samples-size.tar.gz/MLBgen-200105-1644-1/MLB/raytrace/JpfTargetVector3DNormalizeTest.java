import org.junit.Test;

public class JpfTargetVector3DNormalizeTest {

  @Test
  public void test0() {
    TestDrivers.vector3DNormalize(0.041368287f,-0.038635228f,0.9983967f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.vector3DNormalize(-0.09084722f,-0.8177852f,-0.5683081f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.vector3DNormalize(-0.3955928f,0.364678f,0.7948066f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.vector3DNormalize(-0.41705883f,-0.60252684f,0.14858648f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.vector3DNormalize(-13.067532f,-85.72985f,15.878536f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.vector3DNormalize(26.835155f,42.290005f,-84.89866f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.vector3DNormalize(-4.115234E-7f,-2.3520895E-8f,8.216266E-7f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.vector3DNormalize(47.88624f,76.916504f,-48.629078f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.vector3DNormalize(6.3100885E-14f,-1.8772993E-14f,5.6883744E-14f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.vector3DNormalize(-8.850766E-6f,-2.2234926E-5f,-1.2649603E-5f ) ;
  }
}
