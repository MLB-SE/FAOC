import org.junit.Test;

public class JpfTargetRayTraceTest {

  @Test
  public void test0() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,0.3839969f,0.35169488f,0.8537313f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,0.43786216f,0.046942763f,-0.0767089f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,0.45722207f,-0.8090869f,-0.0045707333f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-0.98839396f,0.099564046f,-0.11473589f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-1.5361279E-7f,-1.435812E-7f,2.808934E-7f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-4.5220408E-13f,1.3639267E-13f,1.5753127E-13f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,52.418602f,41.593803f,-31.412943f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,81.88332f,-75.454384f,87.62499f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,85.46069f,39.946438f,-48.064278f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-9.895058E-7f,-9.30874E-8f,-1.535342E-6f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.rayTrace(100.0f,-100.0f,-100.0f,100.0f,-3.901248f,-100.0f,40.98783f,0.3815999f,-0.095153034f,-0.77227175f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.rayTrace(-100.0f,-100.0f,-62.522152f,-100.0f,-100.0f,97.31734f,23.588732f,0.14526395f,-0.98767036f,-0.058357667f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.rayTrace(100.0f,-12.747267f,30.823917f,100.0f,100.0f,6.3415866f,86.55256f,0.5795881f,-0.6468117f,-0.19241384f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.rayTrace(-100.0f,99.944565f,-100.0f,89.55652f,5.982562f,99.85508f,-100.0f,-0.53426975f,0.56677306f,0.62715554f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.rayTrace(11.702588f,-35.043003f,-67.40582f,-73.84914f,-64.64351f,-26.658092f,2.3878784f,-66.26098f,-27.140768f,14.557356f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.rayTrace(-12.164876f,-4.55837f,20.740772f,-97.708496f,-44.611454f,43.422398f,-17.718657f,-0.006248312f,0.25256658f,-0.004067434f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.rayTrace(-13.122882f,18.354813f,-10.27255f,28.0423f,-50.71951f,18.957775f,-23.805984f,68.352776f,-31.158688f,61.04889f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.rayTrace(17.116825f,-54.17879f,-75.87063f,-32.87401f,14.939279f,-84.35448f,-88.7309f,-98.16609f,100.0f,94.31677f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.rayTrace(20.1375f,-97.01781f,-100.0f,56.858994f,-69.86865f,68.35786f,96.329895f,-0.8795168f,0.37374237f,-0.09090256f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.rayTrace(20.203041f,-100.0f,-100.0f,-81.79872f,21.15921f,-100.0f,-90.62912f,0.08190162f,0.16247317f,-0.6212497f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.rayTrace(-21.856958f,40.664516f,16.709951f,-78.158485f,-21.557281f,35.88493f,10.144799f,-90.815445f,-61.87394f,22.148108f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.rayTrace(26.314194f,85.5877f,44.347935f,-88.04913f,-42.902138f,-45.645306f,-29.99394f,0.8675442f,-0.19707406f,0.42158487f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.rayTrace(-26.880056f,13.933582f,-47.6194f,-58.998184f,-37.772953f,64.93485f,-89.704384f,1.4580468f,0.03160953f,-2.571989f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.rayTrace(-30.444706f,-100.0f,-100.0f,-100.0f,-67.87445f,-100.0f,-100.0f,-0.18643174f,0.16758402f,0.9680696f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.rayTrace(-32.75968f,97.53171f,-2.087381f,-94.04493f,100.0f,94.74966f,-100.0f,0.62379956f,-0.064959124f,-0.77888024f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.rayTrace(32.882866f,100.0f,-77.15033f,-7.492496f,26.039593f,52.92759f,100.0f,0.007930812f,-0.059967745f,0.9981688f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.rayTrace(35.640945f,-22.932667f,-34.15f,10.304051f,61.093975f,-33.50301f,4.692497f,-64.814804f,30.639006f,-65.186134f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.rayTrace(-36.363567f,62.044796f,-8.58537f,-95.71526f,38.97547f,75.95468f,-28.366232f,-31.329502f,92.041664f,-56.78206f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.rayTrace(-36.92044f,-100.0f,-100.0f,100.0f,40.002296f,75.419815f,100.0f,0.5308712f,0.62725097f,0.5698526f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.rayTrace(37.625866f,-24.246151f,-37.625866f,82.079124f,-100.0f,93.51784f,100.0f,-0.5800432f,0.6832802f,0.30944818f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.rayTrace(42.366936f,-32.180275f,55.052612f,7.596686f,-10.46375f,-11.816219f,-45.82374f,20.546907f,36.300236f,-44.66947f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.rayTrace(4.7113786f,-92.823265f,-137.12335f,89.49227f,-64.722046f,-88.7705f,-80.80753f,-0.038282245f,0.46480083f,-1.0477759f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.rayTrace(49.62243f,-52.511524f,-90.244545f,-69.889f,28.982618f,97.414215f,-41.78128f,-64.5392f,94.04368f,26.240717f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.rayTrace(-61.190643f,21.127861f,-26.83666f,-52.678547f,-1.667165f,29.188898f,-17.313011f,-46.77578f,42.673767f,-86.904625f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.rayTrace(61.26898f,100.0f,-100.0f,100.0f,12.389793f,-24.513744f,8.744225f,0.6787338f,0.5329244f,-0.5052841f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.rayTrace(63.423424f,74.8009f,34.01105f,-100.0f,-93.32946f,-84.69997f,-14.207561f,-0.43552008f,-0.8981672f,0.060149238f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.rayTrace(67.10392f,73.09363f,35.569805f,-60.168766f,58.630333f,61.363125f,0.36438915f,-13.689977f,-56.66956f,93.967514f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.rayTrace(68.386406f,-56.475445f,-18.237103f,100.0f,20.12754f,3.7261174f,14.215903f,-0.26765123f,-0.17077243f,0.4383451f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.rayTrace(7.41708f,-22.196972f,38.36663f,-75.67322f,33.36466f,-69.43036f,80.5869f,0.66512567f,0.72382766f,-0.14079736f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.rayTrace(74.41537f,82.36036f,26.417925f,-59.236046f,-12.453998f,28.791447f,-5.916237f,-7.908415f,-3.7195804f,79.79902f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.rayTrace(7.649466f,-82.02594f,-14.858014f,86.77575f,29.652637f,82.79822f,-3.049422f,0.56803656f,-0.7307281f,0.1906536f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.rayTrace(-76.52583f,63.727985f,47.54398f,54.946835f,26.568508f,7.2802725f,-80.21845f,-0.7467541f,-0.4953613f,-0.44381917f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.rayTrace(86.41401f,19.710058f,-31.721474f,-47.735535f,21.02225f,61.103043f,93.31518f,-74.882126f,50.219376f,73.86817f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.rayTrace(93.74588f,46.028694f,10.792055f,97.85192f,-17.62687f,99.17253f,49.96434f,88.63113f,75.22915f,-91.81428f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.rayTrace(-98.1348f,78.68758f,-69.34819f,87.35305f,-9.723161f,93.5232f,-86.95772f,67.41655f,34.039074f,96.90451f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.rayTrace(98.62123f,-6.848293f,66.8068f,-100.0f,25.764187f,-71.09537f,43.054672f,0.9893227f,0.13370748f,-0.05799021f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.rayTrace(-99.34092f,32.056255f,3.4310007f,-54.756233f,-64.62627f,-46.392727f,34.903603f,-79.878876f,47.845608f,-16.508924f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.rayTrace(99.85722f,-100.0f,-100.0f,-72.10323f,100.0f,-100.0f,-100.0f,-0.16776055f,-0.96896154f,0.18157642f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.rayTrace(99.94502f,-19.936377f,100.0f,100.0f,98.1707f,99.96268f,-100.0f,-0.37500724f,-0.47369105f,0.7968603f ) ;
  }
}
