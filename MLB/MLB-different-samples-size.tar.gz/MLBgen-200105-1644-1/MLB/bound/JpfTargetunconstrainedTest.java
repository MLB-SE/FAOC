import org.junit.Test;

public class JpfTargetunconstrainedTest {

  @Test
  public void test0() {
    bound.unconstrained.solve(1,1,350,0 ) ;
  }

  @Test
  public void test1() {
    bound.unconstrained.solve(1,6,779,0 ) ;
  }

  @Test
  public void test2() {
    bound.unconstrained.solve(4,5,-121,0 ) ;
  }

  @Test
  public void test3() {
    bound.unconstrained.solve(4,5,2,152 ) ;
  }

  @Test
  public void test4() {
    bound.unconstrained.solve(4,864,0,0 ) ;
  }

  @Test
  public void test5() {
    bound.unconstrained.solve(49,0,0,0 ) ;
  }

  @Test
  public void test6() {
    bound.unconstrained.solve(5,10,5,-1189 ) ;
  }

  @Test
  public void test7() {
    bound.unconstrained.solve(5,7,9,197 ) ;
  }

  @Test
  public void test8() {
    bound.unconstrained.solve(6,0,0,0 ) ;
  }

  @Test
  public void test9() {
    bound.unconstrained.solve(6,2,8,6 ) ;
  }

  @Test
  public void test10() {
    bound.unconstrained.solve(6,2,9,5 ) ;
  }

  @Test
  public void test11() {
    bound.unconstrained.solve(-646,0,0,0 ) ;
  }

  @Test
  public void test12() {
    bound.unconstrained.solve(6,8,4,5 ) ;
  }

  @Test
  public void test13() {
    bound.unconstrained.solve(7,-318,0,0 ) ;
  }

  @Test
  public void test14() {
    bound.unconstrained.solve(858,0,0,0 ) ;
  }

  @Test
  public void test15() {
    bound.unconstrained.solve(8,8,0,0 ) ;
  }

  @Test
  public void test16() {
    bound.unconstrained.solve(8,9,9,0 ) ;
  }

  @Test
  public void test17() {
    bound.unconstrained.solve(9,10,0,0 ) ;
  }
}
