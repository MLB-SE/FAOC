import org.junit.Test;

public class JpfTargetgroceryTest {

  @Test
  public void test0() {
    bound.grocery.solve(108,24,119,532 ) ;
  }

  @Test
  public void test1() {
    bound.grocery.solve(14,660,978,0 ) ;
  }

  @Test
  public void test2() {
    bound.grocery.solve(22,573,111,5 ) ;
  }

  @Test
  public void test3() {
    bound.grocery.solve(226,69,267,149 ) ;
  }

  @Test
  public void test4() {
    bound.grocery.solve(240,101,214,156 ) ;
  }

  @Test
  public void test5() {
    bound.grocery.solve(2,82,406,717 ) ;
  }

  @Test
  public void test6() {
    bound.grocery.solve(291,219,551,-824 ) ;
  }

  @Test
  public void test7() {
    bound.grocery.solve(313,0,0,0 ) ;
  }

  @Test
  public void test8() {
    bound.grocery.solve(398,-727,0,0 ) ;
  }

  @Test
  public void test9() {
    bound.grocery.solve(-423,0,0,0 ) ;
  }

  @Test
  public void test10() {
    bound.grocery.solve(427,628,119,0 ) ;
  }

  @Test
  public void test11() {
    bound.grocery.solve(461,457,-535,0 ) ;
  }

  @Test
  public void test12() {
    bound.grocery.solve(486,0,0,0 ) ;
  }

  @Test
  public void test13() {
    bound.grocery.solve(497,238,0,0 ) ;
  }

  @Test
  public void test14() {
    bound.grocery.solve(55,614,1288,0 ) ;
  }

  @Test
  public void test15() {
    bound.grocery.solve(609,539,0,0 ) ;
  }

  @Test
  public void test16() {
    bound.grocery.solve(618,245,702,728 ) ;
  }

  @Test
  public void test17() {
    bound.grocery.solve(657,69,556,273 ) ;
  }

  @Test
  public void test18() {
    bound.grocery.solve(671,921,0,0 ) ;
  }

  @Test
  public void test19() {
    bound.grocery.solve(819,0,0,0 ) ;
  }

  @Test
  public void test20() {
    bound.grocery.solve(99,141,238,233 ) ;
  }
}
