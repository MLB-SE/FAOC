import org.junit.Test;

public class JpfTargetunboundedTest {

  @Test
  public void test0() {
    bound.unbounded.solve(-432,-549 ) ;
  }

  @Test
  public void test1() {
    bound.unbounded.solve(-443,569 ) ;
  }

  @Test
  public void test2() {
    bound.unbounded.solve(530,-393 ) ;
  }

  @Test
  public void test3() {
    bound.unbounded.solve(-636,352 ) ;
  }
}
