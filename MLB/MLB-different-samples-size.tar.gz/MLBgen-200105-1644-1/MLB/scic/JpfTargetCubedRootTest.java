import org.junit.Test;

public class JpfTargetCubedRootTest {

  @Test
  public void test0() {
    scic.CubedRoot.check(24.99854013611927 ) ;
  }

  @Test
  public void test1() {
    scic.CubedRoot.check(40.46714619480284 ) ;
  }

  @Test
  public void test2() {
    scic.CubedRoot.check(8.69363755303607 ) ;
  }
}
