import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(-12.750000230959268,-100.0 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(-13.908237942347455,-49.17429342553312 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(17.443529122863467,-75.58530161543489 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(2.0174639531388863,41.747683860623226 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(-22.249999999982712,0 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(-23.124095039564125,0 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonMethod.newton(-42.38836218679436,0.15853511017535737 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonMethod.newton(-55.63583789293525,0 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonMethod.newton(-64.75,29.582930526133833 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonMethod.newton(-66.7364754802451,0.01374349085172355 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonMethod.newton(-82.75,0.0 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonMethod.newton(-86.30984627401224,17.811056470397446 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonMethod.newton(95.47488038589158,0 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonMethod.newton(97.76825541149819,0 ) ;
  }
}
