import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(-0.28607184582807577,-52.04757406811129 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(-0.47304229772481676,0 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(-0.7459379599575229,0 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(0.8573309228525545,42.70878987046973 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(0.9595765522774258,0 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(1.255271030369002,-8.680204421360088 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonSimpson.newton(1.644838642116339,1.997144671861406E-10 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonSimpson.newton(1.6448535049758468,52.866264447580505 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonSimpson.newton(1.6511597940976657,56.472538453712076 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonSimpson.newton(18.258414799758,0 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonSimpson.newton(1.8452071517105537,0 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonSimpson.newton(-18.799415622786086,0 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonSimpson.newton(-28.524670608096642,0 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonSimpson.newton(33.791288471173516,23.52193490525201 ) ;
  }

  @Test
  public void test14() {
    scic.NewtonSimpson.newton(35.7040781472225,39.052709743246936 ) ;
  }

  @Test
  public void test15() {
    scic.NewtonSimpson.newton(-37.36761825278023,-75.69258385087971 ) ;
  }

  @Test
  public void test16() {
    scic.NewtonSimpson.newton(7.25951305700012,0 ) ;
  }

  @Test
  public void test17() {
    scic.NewtonSimpson.newton(-8.181310730735717,0 ) ;
  }

  @Test
  public void test18() {
    scic.NewtonSimpson.newton(93.83976733431822,0 ) ;
  }
}
