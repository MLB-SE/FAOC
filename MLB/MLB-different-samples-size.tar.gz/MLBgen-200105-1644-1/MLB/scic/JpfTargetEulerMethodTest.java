import org.junit.Test;

public class JpfTargetEulerMethodTest {

  @Test
  public void test0() {
    scic.EulerMethod.euler(-15.603456562445103 ) ;
  }

  @Test
  public void test1() {
    scic.EulerMethod.euler(16.205530431530974 ) ;
  }

  @Test
  public void test2() {
    scic.EulerMethod.euler(-1.9946221946070222 ) ;
  }
}
