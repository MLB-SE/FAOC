import org.junit.Test;

public class JpfTargetSimpsonSolverTest {

  @Test
  public void test0() {
    scic.SimpsonSolver.simpson(-75.98286091461975,32.35942450790753 ) ;
  }

  @Test
  public void test1() {
    scic.SimpsonSolver.simpson(77.49912552938713,-86.92337168340617 ) ;
  }

  @Test
  public void test2() {
    scic.SimpsonSolver.simpson(-93.24024126774013,42.802297196656895 ) ;
  }
}
