import org.junit.Test;

public class JpfTargetRungeKuttaTest {

  @Test
  public void test0() {
    scic.RungeKutta.rungeKutta(21.591834591489373 ) ;
  }

  @Test
  public void test1() {
    scic.RungeKutta.rungeKutta(-31.87415529714363 ) ;
  }

  @Test
  public void test2() {
    scic.RungeKutta.rungeKutta(3820.397066977907 ) ;
  }

  @Test
  public void test3() {
    scic.RungeKutta.rungeKutta(3826.7787612619654 ) ;
  }

  @Test
  public void test4() {
    scic.RungeKutta.rungeKutta(3832.2095195871066 ) ;
  }

  @Test
  public void test5() {
    scic.RungeKutta.rungeKutta(3833.51753204155 ) ;
  }

  @Test
  public void test6() {
    scic.RungeKutta.rungeKutta(-40.67470612201798 ) ;
  }

  @Test
  public void test7() {
    scic.RungeKutta.rungeKutta(-41.42175416128462 ) ;
  }

  @Test
  public void test8() {
    scic.RungeKutta.rungeKutta(45.077875112275535 ) ;
  }

  @Test
  public void test9() {
    scic.RungeKutta.rungeKutta(-53.625542638101756 ) ;
  }

  @Test
  public void test10() {
    scic.RungeKutta.rungeKutta(87.01403173219458 ) ;
  }

  @Test
  public void test11() {
    scic.RungeKutta.rungeKutta(89.11225370806642 ) ;
  }

  @Test
  public void test12() {
    scic.RungeKutta.rungeKutta(89.89792723571145 ) ;
  }

  @Test
  public void test13() {
    scic.RungeKutta.rungeKutta(91.74880727532042 ) ;
  }

  @Test
  public void test14() {
    scic.RungeKutta.rungeKutta(93.03520569380939 ) ;
  }

  @Test
  public void test15() {
    scic.RungeKutta.rungeKutta(93.36804193324826 ) ;
  }

  @Test
  public void test16() {
    scic.RungeKutta.rungeKutta(97.24226131420917 ) ;
  }

  @Test
  public void test17() {
    scic.RungeKutta.rungeKutta(99.16250375492803 ) ;
  }
}
