import org.junit.Test;

public class JpfTargetPowTestTest {

  @Test
  public void test0() {
    concolic.PowExample.test(1,1 ) ;
  }

  @Test
  public void test1() {
    concolic.PowExample.test(113,27 ) ;
  }

  @Test
  public void test2() {
    concolic.PowExample.test(22,484 ) ;
  }

  @Test
  public void test3() {
    concolic.PowExample.test(257,0 ) ;
  }

  @Test
  public void test4() {
    concolic.PowExample.test(347,-662 ) ;
  }

  @Test
  public void test5() {
    concolic.PowExample.test(419,-864 ) ;
  }

  @Test
  public void test6() {
    concolic.PowExample.test(42,1764 ) ;
  }

  @Test
  public void test7() {
    concolic.PowExample.test(-905,0 ) ;
  }
}
