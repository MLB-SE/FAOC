import org.junit.Test;

public class TestellpiTest {

  @Test
  public void test0() {
    ell.ellpi(-102.10136834722442,0,-1.0000000771830238 ) ;
  }

  @Test
  public void test1() {
    ell.ellpi(-10.995574287564276,0,-1.0 ) ;
  }

  @Test
  public void test2() {
    ell.ellpi(10.996552018201896,0,1.0000009559573522 ) ;
  }

  @Test
  public void test3() {
    ell.ellpi(12.566370434959476,0,-1.000238317059171 ) ;
  }

  @Test
  public void test4() {
    ell.ellpi(12.566370473043646,0,-4.130045426496135 ) ;
  }

  @Test
  public void test5() {
    ell.ellpi(-12.566370598632597,0,43.67066823165436 ) ;
  }

  @Test
  public void test6() {
    ell.ellpi(-12.56637062706825,0,0.9182745624987336 ) ;
  }

  @Test
  public void test7() {
    ell.ellpi(-131.95678872216183,0,0.9596729530656916 ) ;
  }

  @Test
  public void test8() {
    ell.ellpi(-14.137166938452943,0,1.0 ) ;
  }

  @Test
  public void test9() {
    ell.ellpi(147.65485470777637,0,-0.9986775636173097 ) ;
  }

  @Test
  public void test10() {
    ell.ellpi(15.159777925733195,0,1.9188726402072525 ) ;
  }

  @Test
  public void test11() {
    ell.ellpi(153.93838166492367,0,-1.2659443794591939E-5 ) ;
  }

  @Test
  public void test12() {
    ell.ellpi(15.707963256639465,0,1.206000981815717 ) ;
  }

  @Test
  public void test13() {
    ell.ellpi(1.5707963267948968,0,-1.7821190126410396E-9 ) ;
  }

  @Test
  public void test14() {
    ell.ellpi(15.70796326830843,0,45.165683260394445 ) ;
  }

  @Test
  public void test15() {
    ell.ellpi(-15.70796328355559,0,1.0211841487433828 ) ;
  }

  @Test
  public void test16() {
    ell.ellpi(15.707963286691351,0,0.6547291780808561 ) ;
  }

  @Test
  public void test17() {
    ell.ellpi(166.5035545477241,0,-0.9745188519058714 ) ;
  }

  @Test
  public void test18() {
    ell.ellpi(-191.6377184972189,0,1.1802256331484067E-5 ) ;
  }

  @Test
  public void test19() {
    ell.ellpi(20.610474496623404,0,-1.0363742795265505 ) ;
  }

  @Test
  public void test20() {
    ell.ellpi(-207.34511514403363,0,-1.0000000015441082 ) ;
  }

  @Test
  public void test21() {
    ell.ellpi(21.991148576087134,0,15.770867993987004 ) ;
  }

  @Test
  public void test22() {
    ell.ellpi(23.265285919805322,0,0.02134579700791317 ) ;
  }

  @Test
  public void test23() {
    ell.ellpi(-25.1327412286459,0,-8.918079382543183 ) ;
  }

  @Test
  public void test24() {
    ell.ellpi(-26.703537479491544,0,-1.0000000000000027 ) ;
  }

  @Test
  public void test25() {
    ell.ellpi(26.70354536072935,0,1.0000000000001046 ) ;
  }

  @Test
  public void test26() {
    ell.ellpi(-28.274333880707037,0,46.946391027325284 ) ;
  }

  @Test
  public void test27() {
    ell.ellpi(28.274334907520014,0,-1.0000523654463638 ) ;
  }

  @Test
  public void test28() {
    ell.ellpi(28.289493803107018,0,93.28455593149835 ) ;
  }

  @Test
  public void test29() {
    ell.ellpi(28.340029165905264,0,-15.232747607922859 ) ;
  }

  @Test
  public void test30() {
    ell.ellpi(31.182992441933976,0,4.332129335618224 ) ;
  }

  @Test
  public void test31() {
    ell.ellpi(-31.307521772217555,0,-9.242779130630742 ) ;
  }

  @Test
  public void test32() {
    ell.ellpi(-3.141576328587453,0,-4.372141683540165E-4 ) ;
  }

  @Test
  public void test33() {
    ell.ellpi(3.1415926584327143,0,2.474374151186497 ) ;
  }

  @Test
  public void test34() {
    ell.ellpi(31.415926599528714,0,0.001190357261090661 ) ;
  }

  @Test
  public void test35() {
    ell.ellpi(-3.141592665256239,0,0.9565308872756204 ) ;
  }

  @Test
  public void test36() {
    ell.ellpi(31.419236422898447,0,1.0000000000003995 ) ;
  }

  @Test
  public void test37() {
    ell.ellpi(36.12831552507985,0,-1.0 ) ;
  }

  @Test
  public void test38() {
    ell.ellpi(37.69895878406538,0,-67.01075896880992 ) ;
  }

  @Test
  public void test39() {
    ell.ellpi(37.699111826829935,0,0.5653095986089447 ) ;
  }

  @Test
  public void test40() {
    ell.ellpi(-37.699111831981824,0,1.498404004683887 ) ;
  }

  @Test
  public void test41() {
    ell.ellpi(-37.699111833488324,0,21.849424357921237 ) ;
  }

  @Test
  public void test42() {
    ell.ellpi(-37.69911185184327,0,-1.0543594968552723 ) ;
  }

  @Test
  public void test43() {
    ell.ellpi(37.69911185816925,0,-8.206542376249297 ) ;
  }

  @Test
  public void test44() {
    ell.ellpi(37.69911771649054,0,-0.002832554583744095 ) ;
  }

  @Test
  public void test45() {
    ell.ellpi(37.813097745210406,0,-8.792041230798342 ) ;
  }

  @Test
  public void test46() {
    ell.ellpi(40.84095121249964,0,-3.36255991552454E-5 ) ;
  }

  @Test
  public void test47() {
    ell.ellpi(-43.98229713865948,0,0.9466594774065697 ) ;
  }

  @Test
  public void test48() {
    ell.ellpi(-43.98229714701875,0,-3.308812696020908 ) ;
  }

  @Test
  public void test49() {
    ell.ellpi(-43.98229714942797,0,13.197884594795656 ) ;
  }

  @Test
  public void test50() {
    ell.ellpi(-43.98229715349063,0,-3.0313275481766526 ) ;
  }

  @Test
  public void test51() {
    ell.ellpi(-43.982962866787595,0,-7.030299727249448E-4 ) ;
  }

  @Test
  public void test52() {
    ell.ellpi(45.55094258222622,0,1.0000046219235168 ) ;
  }

  @Test
  public void test53() {
    ell.ellpi(-46.810792929729075,0,0.2148283501198256 ) ;
  }

  @Test
  public void test54() {
    ell.ellpi(-47.123793252111746,0,-0.07181275636498174 ) ;
  }

  @Test
  public void test55() {
    ell.ellpi(4.71238898038469,0,-0.682692961828139 ) ;
  }

  @Test
  public void test56() {
    ell.ellpi(47.123889803928705,0,85.03184921474369 ) ;
  }

  @Test
  public void test57() {
    ell.ellpi(47.12388981053534,0,-0.8942213994775408 ) ;
  }

  @Test
  public void test58() {
    ell.ellpi(-47.12389016671252,0,-0.8211090842431885 ) ;
  }

  @Test
  public void test59() {
    ell.ellpi(-50.265482440404284,0,0.6524122151366079 ) ;
  }

  @Test
  public void test60() {
    ell.ellpi(-50.26548244143952,0,0.9978299491143505 ) ;
  }

  @Test
  public void test61() {
    ell.ellpi(50.26548244313043,0,1.55503556368594 ) ;
  }

  @Test
  public void test62() {
    ell.ellpi(-50.26548245613462,0,-6.296330704313043 ) ;
  }

  @Test
  public void test63() {
    ell.ellpi(50.26548489246636,0,-1.00002731101302 ) ;
  }

  @Test
  public void test64() {
    ell.ellpi(51.17593211194708,0,33.785889613155746 ) ;
  }

  @Test
  public void test65() {
    ell.ellpi(-51.83627878423159,0,1.0 ) ;
  }

  @Test
  public void test66() {
    ell.ellpi(-53.40707520424849,0,-10.228839722476028 ) ;
  }

  @Test
  public void test67() {
    ell.ellpi(-54.31620324112028,0,0.6127881556126056 ) ;
  }

  @Test
  public void test68() {
    ell.ellpi(-54.97787143264745,0,0.9999999999997748 ) ;
  }

  @Test
  public void test69() {
    ell.ellpi(56.44946683260166,0,8.984747975133054 ) ;
  }

  @Test
  public void test70() {
    ell.ellpi(-56.54866775354392,0,-0.6213913695095095 ) ;
  }

  @Test
  public void test71() {
    ell.ellpi(56.54866776355877,0,14.119506879188986 ) ;
  }

  @Test
  public void test72() {
    ell.ellpi(57.31228357684075,0,1.7838542204767027 ) ;
  }

  @Test
  public void test73() {
    ell.ellpi(-58.119464091411174,0,-0.9999999999999999 ) ;
  }

  @Test
  public void test74() {
    ell.ellpi(-58.38799890635757,0,0.005439155197418 ) ;
  }

  @Test
  public void test75() {
    ell.ellpi(59.69026040741485,0,1.1610920139537768 ) ;
  }

  @Test
  public void test76() {
    ell.ellpi(-59.690260416936255,0,100.0 ) ;
  }

  @Test
  public void test77() {
    ell.ellpi(59.690260422598506,0,2.2830589907514796 ) ;
  }

  @Test
  public void test78() {
    ell.ellpi(-62.827829260605945,0,248.5212777924851 ) ;
  }

  @Test
  public void test79() {
    ell.ellpi(62.83185305587762,0,0.7861757239180953 ) ;
  }

  @Test
  public void test80() {
    ell.ellpi(62.83185306183019,0,143.12433843270654 ) ;
  }

  @Test
  public void test81() {
    ell.ellpi(-62.83185306652483,0,-2.3486950586398825 ) ;
  }

  @Test
  public void test82() {
    ell.ellpi(62.83185307323336,0,71.55013348283578 ) ;
  }

  @Test
  public void test83() {
    ell.ellpi(-62.831853074478175,0,48.78761264030862 ) ;
  }

  @Test
  public void test84() {
    ell.ellpi(-6.283185318031232,0,1.2610887307236283 ) ;
  }

  @Test
  public void test85() {
    ell.ellpi(-62.83185355346368,0,-0.8269442510396717 ) ;
  }

  @Test
  public void test86() {
    ell.ellpi(65.97344572544787,0,-100.0 ) ;
  }

  @Test
  public void test87() {
    ell.ellpi(6.653497142558609E-4,0,-1.0000000001177105 ) ;
  }

  @Test
  public void test88() {
    ell.ellpi(68.08505443237445,0,-22.197809261338946 ) ;
  }

  @Test
  public void test89() {
    ell.ellpi(69.11503807383947,0,-0.038109611192444 ) ;
  }

  @Test
  public void test90() {
    ell.ellpi(-69.21057327916074,0,-0.5311452750165415 ) ;
  }

  @Test
  public void test91() {
    ell.ellpi(72.25663105027971,0,-1.003274601848679 ) ;
  }

  @Test
  public void test92() {
    ell.ellpi(-72.25875295736967,0,-1.000000000004896 ) ;
  }

  @Test
  public void test93() {
    ell.ellpi(72.83151054226661,0,0.544449214812996 ) ;
  }

  @Test
  public void test94() {
    ell.ellpi(-73.82989270729416,0,-1.000006077946593 ) ;
  }

  @Test
  public void test95() {
    ell.ellpi(75.39822368066687,0,2.1416503743641186 ) ;
  }

  @Test
  public void test96() {
    ell.ellpi(75.40735085631215,0,50.252884875267995 ) ;
  }

  @Test
  public void test97() {
    ell.ellpi(75.88162491897617,0,-0.06988051854452237 ) ;
  }

  @Test
  public void test98() {
    ell.ellpi(-78.5331512451234,0,150.03649021551902 ) ;
  }

  @Test
  public void test99() {
    ell.ellpi(78.53741876696397,0,7.183409362310407E-7 ) ;
  }

  @Test
  public void test100() {
    ell.ellpi(78.53981634070142,0,2.6516920493842804 ) ;
  }

  @Test
  public void test101() {
    ell.ellpi(-78.53981634557765,0,1.4792394033257763 ) ;
  }

  @Test
  public void test102() {
    ell.ellpi(-78.72997489065682,0,-5.29059687178809 ) ;
  }

  @Test
  public void test103() {
    ell.ellpi(-78.95461750093723,0,-2.481340556119932 ) ;
  }

  @Test
  public void test104() {
    ell.ellpi(-8.094769253696072,0,-40.691416475156615 ) ;
  }

  @Test
  public void test105() {
    ell.ellpi(81.68140897613742,0,-0.018355754165605642 ) ;
  }

  @Test
  public void test106() {
    ell.ellpi(8.172600833528705,0,-1.0529986136062683 ) ;
  }

  @Test
  public void test107() {
    ell.ellpi(-86.39379797371932,0,-0.9999999999999999 ) ;
  }

  @Test
  public void test108() {
    ell.ellpi(-87.9644348317617,0,3.739903828510162E-5 ) ;
  }

  @Test
  public void test109() {
    ell.ellpi(87.96455242587886,0,0.9999999747164284 ) ;
  }

  @Test
  public void test110() {
    ell.ellpi(-87.96459428949251,0,-40.12990060323469 ) ;
  }

  @Test
  public void test111() {
    ell.ellpi(87.96459429966164,0,-6.620707468281381 ) ;
  }

  @Test
  public void test112() {
    ell.ellpi(91.10618693094912,0,0.6699437654615918 ) ;
  }

  @Test
  public void test113() {
    ell.ellpi(-91.1061915689868,0,0.0024610010690800654 ) ;
  }

  @Test
  public void test114() {
    ell.ellpi(92.8275658551865,0,-1.0114456695618026 ) ;
  }

  @Test
  public void test115() {
    ell.ellpi(-9.424777951450103,0,-58.191750665256386 ) ;
  }

  @Test
  public void test116() {
    ell.ellpi(-94.24777959164734,0,0.9219247977855223 ) ;
  }

  @Test
  public void test117() {
    ell.ellpi(94.24777960360201,0,-69.26179585471608 ) ;
  }

  @Test
  public void test118() {
    ell.ellpi(-94.24777960681048,0,-1.5771958727169846 ) ;
  }

  @Test
  public void test119() {
    ell.ellpi(-94.24777962233398,0,-0.9471437302934334 ) ;
  }

  @Test
  public void test120() {
    ell.ellpi(94.24777963322443,0,1.1073910015479207 ) ;
  }

  @Test
  public void test121() {
    ell.ellpi(9.424777979602423,0,0.8549150639142263 ) ;
  }

  @Test
  public void test122() {
    ell.ellpi(-94.25591635951523,0,122.90052056237681 ) ;
  }

  @Test
  public void test123() {
    ell.ellpi(-94.25643137624299,0,-115.58474662607443 ) ;
  }

  @Test
  public void test124() {
    ell.ellpi(95.81857594404434,0,-0.7506293418780907 ) ;
  }

  @Test
  public void test125() {
    ell.ellpi(-97.38937227407582,0,1.6577216357191538 ) ;
  }

  @Test
  public void test126() {
    ell.ellpi(-97.54652946554292,0,-6.3893239563572 ) ;
  }

  @Test
  public void test127() {
    ell.ellpi(98.6831918904514,0,-1.0396236421070886 ) ;
  }

  @Test
  public void test128() {
    ell.ellpi(-99.15491797081094,0,-1.0381785354111177 ) ;
  }

  @Test
  public void test129() {
    ell.ellpi(-99.99999980652869,0,-1.9748568807615172 ) ;
  }
}
