import org.junit.Test;

public class TestzbrentTest {

  @Test
  public void test0() {
    ell.zbrent(-0.5460603218394624,40.840704496667314,0 ) ;
  }

  @Test
  public void test1() {
    ell.zbrent(-100.0,-100.0,0 ) ;
  }

  @Test
  public void test2() {
    ell.zbrent(-100.0,100.0,0 ) ;
  }

  @Test
  public void test3() {
    ell.zbrent(100.0,-100.0,0 ) ;
  }

  @Test
  public void test4() {
    ell.zbrent(100.0,100.0,0 ) ;
  }

  @Test
  public void test5() {
    ell.zbrent(-100.0,-100.0,-100.0 ) ;
  }

  @Test
  public void test6() {
    ell.zbrent(-100.0,-100.0,100.0 ) ;
  }

  @Test
  public void test7() {
    ell.zbrent(-100.0,100.0,100.0 ) ;
  }

  @Test
  public void test8() {
    ell.zbrent(100.0,-100.0,100.0 ) ;
  }

  @Test
  public void test9() {
    ell.zbrent(100.0,100.0,-100.0 ) ;
  }

  @Test
  public void test10() {
    ell.zbrent(-100.0,100.0,-29.152753795005584 ) ;
  }

  @Test
  public void test11() {
    ell.zbrent(100.0,-100.0,-36.60448636738061 ) ;
  }

  @Test
  public void test12() {
    ell.zbrent(100.0,-100.0,84.83801929507759 ) ;
  }

  @Test
  public void test13() {
    ell.zbrent(-100.0,-18.84955592153876,0 ) ;
  }

  @Test
  public void test14() {
    ell.zbrent(1.0578337292058109,1.9936910893569006,0 ) ;
  }

  @Test
  public void test15() {
    ell.zbrent(10.62966785647919,76.60311358186485,0 ) ;
  }

  @Test
  public void test16() {
    ell.zbrent(10.750852509209352,10.750852509209352,0 ) ;
  }

  @Test
  public void test17() {
    ell.zbrent(113.0891716948244,-34.565683023895865,0 ) ;
  }

  @Test
  public void test18() {
    ell.zbrent(-1.1E-322,19.78618126341412,0 ) ;
  }

  @Test
  public void test19() {
    ell.zbrent(-13.334280250422765,-7.051094943243179,0 ) ;
  }

  @Test
  public void test20() {
    ell.zbrent(13.945337640962492,81.19605282198197,0 ) ;
  }

  @Test
  public void test21() {
    ell.zbrent(-14.266845981846714,-39.59157583041786,0 ) ;
  }

  @Test
  public void test22() {
    ell.zbrent(14.277143560243715,98.82375844812555,0 ) ;
  }

  @Test
  public void test23() {
    ell.zbrent(-14.322807385492098,2.7061224510920727,0 ) ;
  }

  @Test
  public void test24() {
    ell.zbrent(-14.328222636351782,-47.12388980384689,0 ) ;
  }

  @Test
  public void test25() {
    ell.zbrent(14.629595827565117,-8.34641052038553,-45.95201269590096 ) ;
  }

  @Test
  public void test26() {
    ell.zbrent(15.707963267948967,-14.568181511675988,0 ) ;
  }

  @Test
  public void test27() {
    ell.zbrent(1.58E-322,-55.77180185792253,0 ) ;
  }

  @Test
  public void test28() {
    ell.zbrent(17.048227982750916,-15.707963267948966,0 ) ;
  }

  @Test
  public void test29() {
    ell.zbrent(17.447561592653365,77.13782201085944,0 ) ;
  }

  @Test
  public void test30() {
    ell.zbrent(18.570128385062645,-81.68140899333461,0 ) ;
  }

  @Test
  public void test31() {
    ell.zbrent(-18.84955592153876,-100.0,0 ) ;
  }

  @Test
  public void test32() {
    ell.zbrent(-18.849555921538762,0,0 ) ;
  }

  @Test
  public void test33() {
    ell.zbrent(18.84955592153876,-78.53981633974483,0 ) ;
  }

  @Test
  public void test34() {
    ell.zbrent(-19.88383166853045,83.78872589993273,-103.67255756845982 ) ;
  }

  @Test
  public void test35() {
    ell.zbrent(20.0625388611964,7.496168246837228,0 ) ;
  }

  @Test
  public void test36() {
    ell.zbrent(2.145640437319438,4.1375448698601485,0 ) ;
  }

  @Test
  public void test37() {
    ell.zbrent(-23.246990213252484,50.2654824574367,0 ) ;
  }

  @Test
  public void test38() {
    ell.zbrent(23.663486279104728,83.15066394294824,-59.487177663840185 ) ;
  }

  @Test
  public void test39() {
    ell.zbrent(24.24347279459296,77.65054790561945,-49.58155947708238 ) ;
  }

  @Test
  public void test40() {
    ell.zbrent(25.30296960137359,44.1168993707181,0 ) ;
  }

  @Test
  public void test41() {
    ell.zbrent(-25.647632699650273,1.9212391495637178,0 ) ;
  }

  @Test
  public void test42() {
    ell.zbrent(26.21852982430829,11.480582018769228,100.0 ) ;
  }

  @Test
  public void test43() {
    ell.zbrent(-2.6775978065704007,78.07582149272544,0 ) ;
  }

  @Test
  public void test44() {
    ell.zbrent(-27.072407028001905,62.31219510839344,0 ) ;
  }

  @Test
  public void test45() {
    ell.zbrent(-27.721468386577968,-6.9E-323,0 ) ;
  }

  @Test
  public void test46() {
    ell.zbrent(29.026607888749737,0,0 ) ;
  }

  @Test
  public void test47() {
    ell.zbrent(32.54584426905052,79.46087555301969,0 ) ;
  }

  @Test
  public void test48() {
    ell.zbrent(33.02145210645639,-7.8192523902109246,92.14471053164121 ) ;
  }

  @Test
  public void test49() {
    ell.zbrent(-34.0337167263028,-15.397175788782278,0 ) ;
  }

  @Test
  public void test50() {
    ell.zbrent(34.55751918948772,-2.5847587851233698,0 ) ;
  }

  @Test
  public void test51() {
    ell.zbrent(36.3004322792263,20.007335987952786,0 ) ;
  }

  @Test
  public void test52() {
    ell.zbrent(-37.62936482163393,6.283185307179587,0 ) ;
  }

  @Test
  public void test53() {
    ell.zbrent(-38.59836265572998,0,0 ) ;
  }

  @Test
  public void test54() {
    ell.zbrent(-38.853015141845034,16.861866566716483,-55.714881708562196 ) ;
  }

  @Test
  public void test55() {
    ell.zbrent(-39.229705831291994,89.15640925508882,0 ) ;
  }

  @Test
  public void test56() {
    ell.zbrent(39.31680185715501,0,0 ) ;
  }

  @Test
  public void test57() {
    ell.zbrent(-40.13058157450573,-15.707963267948966,0 ) ;
  }

  @Test
  public void test58() {
    ell.zbrent(40.50912087783277,-55.13424684108463,0 ) ;
  }

  @Test
  public void test59() {
    ell.zbrent(-40.58777101604814,83.61143569051669,0 ) ;
  }

  @Test
  public void test60() {
    ell.zbrent(-4.128194243156798,6.91711682824851,0 ) ;
  }

  @Test
  public void test61() {
    ell.zbrent(-41.8358586241256,50.26548245743669,0 ) ;
  }

  @Test
  public void test62() {
    ell.zbrent(42.94456220347311,75.39822368615505,0 ) ;
  }

  @Test
  public void test63() {
    ell.zbrent(43.17563849063807,-29.080992541927174,0 ) ;
  }

  @Test
  public void test64() {
    ell.zbrent(-44.101949219856266,-47.00423773424774,100.0 ) ;
  }

  @Test
  public void test65() {
    ell.zbrent(44.11443252033277,21.01582424446258,0 ) ;
  }

  @Test
  public void test66() {
    ell.zbrent(4.4E-323,-88.9136213012269,0 ) ;
  }

  @Test
  public void test67() {
    ell.zbrent(45.1395524766146,-0.6826586243175825,0 ) ;
  }

  @Test
  public void test68() {
    ell.zbrent(-45.96798127463755,-46.45078225573207,0 ) ;
  }

  @Test
  public void test69() {
    ell.zbrent(45.97735281486331,42.77940822272777,0 ) ;
  }

  @Test
  public void test70() {
    ell.zbrent(-46.78774134815027,9.42477796076938,0 ) ;
  }

  @Test
  public void test71() {
    ell.zbrent(47.12388980384689,-23.489997430654014,0 ) ;
  }

  @Test
  public void test72() {
    ell.zbrent(-47.12388980384689,36.74553200342524,0 ) ;
  }

  @Test
  public void test73() {
    ell.zbrent(-47.577752192154634,-33.73505400955396,0 ) ;
  }

  @Test
  public void test74() {
    ell.zbrent(47.766495678791884,46.48128392890192,0 ) ;
  }

  @Test
  public void test75() {
    ell.zbrent(49.0533989428101,-12.566370614359174,0 ) ;
  }

  @Test
  public void test76() {
    ell.zbrent(-50.2654824574367,0,0 ) ;
  }

  @Test
  public void test77() {
    ell.zbrent(-50.44138511000875,62.83185307179586,0 ) ;
  }

  @Test
  public void test78() {
    ell.zbrent(-51.50275572650467,-59.69026041820607,0 ) ;
  }

  @Test
  public void test79() {
    ell.zbrent(-52.17398831144222,1.58E-322,0 ) ;
  }

  @Test
  public void test80() {
    ell.zbrent(-5.228516556579962,216.7727788776205,0 ) ;
  }

  @Test
  public void test81() {
    ell.zbrent(-52.674951148615,5.666266E-318,0 ) ;
  }

  @Test
  public void test82() {
    ell.zbrent(53.53829335016812,63.925472928152345,0 ) ;
  }

  @Test
  public void test83() {
    ell.zbrent(-54.241805626108565,2.306862138507713,0 ) ;
  }

  @Test
  public void test84() {
    ell.zbrent(-54.716512548908746,-48.44655236533232,0 ) ;
  }

  @Test
  public void test85() {
    ell.zbrent(54.805551281103874,86.08713522688839,0 ) ;
  }

  @Test
  public void test86() {
    ell.zbrent(-55.05398378174629,-3.1415926535897936,0 ) ;
  }

  @Test
  public void test87() {
    ell.zbrent(-56.65029298856974,-88.8674259490231,0 ) ;
  }

  @Test
  public void test88() {
    ell.zbrent(-57.34367298786645,96.50409145316817,0 ) ;
  }

  @Test
  public void test89() {
    ell.zbrent(-5.739226532047882,-15.164004492817261,0 ) ;
  }

  @Test
  public void test90() {
    ell.zbrent(-58.66878270517637,-60.71173813123578,0 ) ;
  }

  @Test
  public void test91() {
    ell.zbrent(59.14795594961285,14.57029154995682,0 ) ;
  }

  @Test
  public void test92() {
    ell.zbrent(59.53449988272688,59.534499882726884,0 ) ;
  }

  @Test
  public void test93() {
    ell.zbrent(-59.69026041820607,-75.9634425814767,0 ) ;
  }

  @Test
  public void test94() {
    ell.zbrent(60.33794947412892,-39.496661804098345,0 ) ;
  }

  @Test
  public void test95() {
    ell.zbrent(-61.133526709256124,-25.13274122871835,0 ) ;
  }

  @Test
  public void test96() {
    ell.zbrent(-61.393132982488964,-20.059455818691248,0 ) ;
  }

  @Test
  public void test97() {
    ell.zbrent(61.39965700664088,-84.82300164692442,0 ) ;
  }

  @Test
  public void test98() {
    ell.zbrent(6.283185307179584,-75.39822368615503,0 ) ;
  }

  @Test
  public void test99() {
    ell.zbrent(-63.45296764109844,-34.55751918948773,0 ) ;
  }

  @Test
  public void test100() {
    ell.zbrent(63.526574978048615,-51.80025726338524,0 ) ;
  }

  @Test
  public void test101() {
    ell.zbrent(-63.924785157915146,51.35841454355597,-31.59655085247777 ) ;
  }

  @Test
  public void test102() {
    ell.zbrent(63.99173524900695,-72.55911722826274,0 ) ;
  }

  @Test
  public void test103() {
    ell.zbrent(65.97344572538566,0,0 ) ;
  }

  @Test
  public void test104() {
    ell.zbrent(65.97344572538566,-59.69026041820607,0 ) ;
  }

  @Test
  public void test105() {
    ell.zbrent(-68.52015353015717,9.424777960769381,0 ) ;
  }

  @Test
  public void test106() {
    ell.zbrent(69.11503837897546,62.83185307179586,0 ) ;
  }

  @Test
  public void test107() {
    ell.zbrent(6.9167560157704235,-19.483126630129597,0 ) ;
  }

  @Test
  public void test108() {
    ell.zbrent(-70.40489297361434,-67.26330032002454,-6.283185307182284 ) ;
  }

  @Test
  public void test109() {
    ell.zbrent(-71.38756276265815,87.96459430051421,0 ) ;
  }

  @Test
  public void test110() {
    ell.zbrent(-71.75486062291569,-63.47239271693677,0 ) ;
  }

  @Test
  public void test111() {
    ell.zbrent(-71.96027172339839,29.67902017252635,0 ) ;
  }

  @Test
  public void test112() {
    ell.zbrent(-72.25663103256525,-37.69911184307752,0 ) ;
  }

  @Test
  public void test113() {
    ell.zbrent(72.25663103256527,91.10618695410398,0 ) ;
  }

  @Test
  public void test114() {
    ell.zbrent(72.6625367823543,52.93325726768916,0 ) ;
  }

  @Test
  public void test115() {
    ell.zbrent(72.85338980020342,72.8533898002034,0 ) ;
  }

  @Test
  public void test116() {
    ell.zbrent(73.84760065380587,-42.269176255645306,0 ) ;
  }

  @Test
  public void test117() {
    ell.zbrent(74.69599273206097,71.55440007847118,0 ) ;
  }

  @Test
  public void test118() {
    ell.zbrent(-75.18941022673815,-45.87481462674994,0 ) ;
  }

  @Test
  public void test119() {
    ell.zbrent(75.39822368615503,-47.1238898038469,0 ) ;
  }

  @Test
  public void test120() {
    ell.zbrent(75.39822368615503,59.02871592486119,0 ) ;
  }

  @Test
  public void test121() {
    ell.zbrent(-75.39822368615503,-74.20907818299287,0 ) ;
  }

  @Test
  public void test122() {
    ell.zbrent(-76.25888016329084,-43.121640673121306,-21.784465469099583 ) ;
  }

  @Test
  public void test123() {
    ell.zbrent(76.88129326770868,50.2654824574367,0 ) ;
  }

  @Test
  public void test124() {
    ell.zbrent(7.755583880114434,-65.97344572538566,0 ) ;
  }

  @Test
  public void test125() {
    ell.zbrent(77.61766905139217,-83.76924539608395,0 ) ;
  }

  @Test
  public void test126() {
    ell.zbrent(79.13718579040875,96.08116508613719,0 ) ;
  }

  @Test
  public void test127() {
    ell.zbrent(-7.9E-323,-69.7392888591967,0 ) ;
  }

  @Test
  public void test128() {
    ell.zbrent(80.07299095579168,35.311495780347855,0 ) ;
  }

  @Test
  public void test129() {
    ell.zbrent(81.37513599227546,49.90501749690824,0 ) ;
  }

  @Test
  public void test130() {
    ell.zbrent(-82.12080029180552,-82.12080029180551,0 ) ;
  }

  @Test
  public void test131() {
    ell.zbrent(-8.234760148892768,64.02187088367248,0 ) ;
  }

  @Test
  public void test132() {
    ell.zbrent(83.02528600163848,80.33753198503076,0 ) ;
  }

  @Test
  public void test133() {
    ell.zbrent(83.06899923974888,-97.47945811264331,0 ) ;
  }

  @Test
  public void test134() {
    ell.zbrent(84.5697239218073,-75.39822368615503,0 ) ;
  }

  @Test
  public void test135() {
    ell.zbrent(-85.21209847144291,46.6106843598626,0 ) ;
  }

  @Test
  public void test136() {
    ell.zbrent(-86.76461740684775,-39.52345826925967,0 ) ;
  }

  @Test
  public void test137() {
    ell.zbrent(-87.23222867785985,93.4143902212453,0 ) ;
  }

  @Test
  public void test138() {
    ell.zbrent(-87.9726942561662,-0.008099955651996405,0 ) ;
  }

  @Test
  public void test139() {
    ell.zbrent(88.44313447535734,15.229423093105837,73.21371138225211 ) ;
  }

  @Test
  public void test140() {
    ell.zbrent(8.85074697617243,-44.556328134854056,-53.4070751110247 ) ;
  }

  @Test
  public void test141() {
    ell.zbrent(-88.74199853092495,-98.13641836749203,0 ) ;
  }

  @Test
  public void test142() {
    ell.zbrent(88.74614845902416,-28.274333882308138,0 ) ;
  }

  @Test
  public void test143() {
    ell.zbrent(89.06914199401491,-1.1045476935007024,0 ) ;
  }

  @Test
  public void test144() {
    ell.zbrent(-89.32435622205826,43.348241387637785,0 ) ;
  }

  @Test
  public void test145() {
    ell.zbrent(89.37594200199547,-4.0E-323,0 ) ;
  }

  @Test
  public void test146() {
    ell.zbrent(-89.58802571190233,76.9163849283567,0 ) ;
  }

  @Test
  public void test147() {
    ell.zbrent(90.23453866233046,40.84070449666731,0 ) ;
  }

  @Test
  public void test148() {
    ell.zbrent(91.106186954104,-89.81146488359204,0 ) ;
  }

  @Test
  public void test149() {
    ell.zbrent(-91.62281979829532,-21.488199429351226,0 ) ;
  }

  @Test
  public void test150() {
    ell.zbrent(-91.63715186897738,-100.0,0 ) ;
  }

  @Test
  public void test151() {
    ell.zbrent(-92.6663103165039,25.516050124842977,0 ) ;
  }

  @Test
  public void test152() {
    ell.zbrent(92.77285075568558,1.4749288520082153,0 ) ;
  }

  @Test
  public void test153() {
    ell.zbrent(-93.55150384042824,-94.94405537495936,0 ) ;
  }

  @Test
  public void test154() {
    ell.zbrent(94.90153326633205,-56.548667764616276,0 ) ;
  }

  @Test
  public void test155() {
    ell.zbrent(95.37656674103451,-97.38937226128358,0 ) ;
  }

  @Test
  public void test156() {
    ell.zbrent(97.3893722612836,4.97890582908012,0 ) ;
  }

  @Test
  public void test157() {
    ell.zbrent(-99.12091680642371,6.9E-323,0 ) ;
  }

  @Test
  public void test158() {
    ell.zbrent(99.9999999756448,25.13274122871835,0 ) ;
  }
}
