import org.junit.Test;

public class TestcisiTest {

  @Test
  public void test0() {
    frenel.cisi(-10.134964713683686 ) ;
  }

  @Test
  public void test1() {
    frenel.cisi(-1.6690975285322764 ) ;
  }

  @Test
  public void test2() {
    frenel.cisi(17.130060955835205 ) ;
  }

  @Test
  public void test3() {
    frenel.cisi(-1.999999999999993 ) ;
  }

  @Test
  public void test4() {
    frenel.cisi(1.9999999999999996 ) ;
  }

  @Test
  public void test5() {
    frenel.cisi(-2.0 ) ;
  }

  @Test
  public void test6() {
    frenel.cisi(2.0 ) ;
  }

  @Test
  public void test7() {
    frenel.cisi(-2.220446049250313E-16 ) ;
  }

  @Test
  public void test8() {
    frenel.cisi(23.048264259278355 ) ;
  }

  @Test
  public void test9() {
    frenel.cisi(-2.465190328815662E-32 ) ;
  }

  @Test
  public void test10() {
    frenel.cisi(-33.342756437800205 ) ;
  }

  @Test
  public void test11() {
    frenel.cisi(3.762366149181034 ) ;
  }

  @Test
  public void test12() {
    frenel.cisi(4.3789276038368 ) ;
  }

  @Test
  public void test13() {
    frenel.cisi(4.448643917661215 ) ;
  }

  @Test
  public void test14() {
    frenel.cisi(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test15() {
    frenel.cisi(5.902019585467542 ) ;
  }

  @Test
  public void test16() {
    frenel.cisi(5.929244679447848 ) ;
  }

  @Test
  public void test17() {
    frenel.cisi(6.822714610299869 ) ;
  }

  @Test
  public void test18() {
    frenel.cisi(-75.37175459820607 ) ;
  }

  @Test
  public void test19() {
    frenel.cisi(85.87887400641645 ) ;
  }

  @Test
  public void test20() {
    frenel.cisi(96.13500155424205 ) ;
  }

  @Test
  public void test21() {
    frenel.cisi(97.15684405946206 ) ;
  }

  @Test
  public void test22() {
    frenel.cisi(9.860761315262648E-32 ) ;
  }

  @Test
  public void test23() {
    frenel.cisi(-9.953657815047578 ) ;
  }
}
