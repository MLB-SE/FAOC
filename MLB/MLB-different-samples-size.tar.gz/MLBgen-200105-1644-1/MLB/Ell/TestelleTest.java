import org.junit.Test;

public class TestelleTest {

  @Test
  public void test0() {
    ell.elle(100.0,1.0000000000000007 ) ;
  }

  @Test
  public void test1() {
    ell.elle(102.10082041470193,1.0000008851555087 ) ;
  }

  @Test
  public void test2() {
    ell.elle(-103.67281746204233,-3697.375895367605 ) ;
  }

  @Test
  public void test3() {
    ell.elle(-11.928138011032473,0.4500066833513756 ) ;
  }

  @Test
  public void test4() {
    ell.elle(-123.85118987563493,1.029942802195639 ) ;
  }

  @Test
  public void test5() {
    ell.elle(12.442024425442812,8.062825734718338 ) ;
  }

  @Test
  public void test6() {
    ell.elle(12.566370619749403,1.0498895902033427 ) ;
  }

  @Test
  public void test7() {
    ell.elle(12.566370849016499,0.005945160318247877 ) ;
  }

  @Test
  public void test8() {
    ell.elle(-12.566396037994258,0.9999999079363966 ) ;
  }

  @Test
  public void test9() {
    ell.elle(-127.56835324300117,1.0584390485788602 ) ;
  }

  @Test
  public void test10() {
    ell.elle(135.08848410909022,-1.0000000007579795 ) ;
  }

  @Test
  public void test11() {
    ell.elle(-150.7964473561133,0.753775420073107 ) ;
  }

  @Test
  public void test12() {
    ell.elle(15.682541325486476,1.283003572315276E-7 ) ;
  }

  @Test
  public void test13() {
    ell.elle(15.70796326632531,-0.055163176450619744 ) ;
  }

  @Test
  public void test14() {
    ell.elle(-15.707963269755096,3.1052591712058826 ) ;
  }

  @Test
  public void test15() {
    ell.elle(-15.707963281908006,-5.794872910691225 ) ;
  }

  @Test
  public void test16() {
    ell.elle(-185.35396654445844,0.9999999995358749 ) ;
  }

  @Test
  public void test17() {
    ell.elle(18.84955591024627,1.53568840802816 ) ;
  }

  @Test
  public void test18() {
    ell.elle(18.849555912178225,1.266599038892516 ) ;
  }

  @Test
  public void test19() {
    ell.elle(-18.849586241162285,-2.2025267814651528E-4 ) ;
  }

  @Test
  public void test20() {
    ell.elle(-19.02103727313849,90.645959407399 ) ;
  }

  @Test
  public void test21() {
    ell.elle(-20.42035223779694,1.0 ) ;
  }

  @Test
  public void test22() {
    ell.elle(-21.991148563487755,1.1896255735894508 ) ;
  }

  @Test
  public void test23() {
    ell.elle(-21.991148568416556,2.0787255291910274 ) ;
  }

  @Test
  public void test24() {
    ell.elle(-21.99114857529126,-65.60899214297086 ) ;
  }

  @Test
  public void test25() {
    ell.elle(21.99114858132509,-53.28007323940779 ) ;
  }

  @Test
  public void test26() {
    ell.elle(21.99114858953409,-20.498556322450753 ) ;
  }

  @Test
  public void test27() {
    ell.elle(22.014423065071043,-36.57126171553528 ) ;
  }

  @Test
  public void test28() {
    ell.elle(-23.501562499208244,1.0036482603797103 ) ;
  }

  @Test
  public void test29() {
    ell.elle(-25.13274120496409,1.1759619309188167 ) ;
  }

  @Test
  public void test30() {
    ell.elle(25.132742088078366,-0.005887544872032139 ) ;
  }

  @Test
  public void test31() {
    ell.elle(-26.703537555513183,-1.0 ) ;
  }

  @Test
  public void test32() {
    ell.elle(28.198480268583285,4.337487879850136E-8 ) ;
  }

  @Test
  public void test33() {
    ell.elle(28.26664494428713,-130.0582539006428 ) ;
  }

  @Test
  public void test34() {
    ell.elle(28.27433389808228,0.510933254770265 ) ;
  }

  @Test
  public void test35() {
    ell.elle(-29.845130198796497,-1.0 ) ;
  }

  @Test
  public void test36() {
    ell.elle(31.40845975616903,0.3763780641518508 ) ;
  }

  @Test
  public void test37() {
    ell.elle(3.1415926537032055,-61.13538869407189 ) ;
  }

  @Test
  public void test38() {
    ell.elle(-3.1415926584248024,-5.811185092305422 ) ;
  }

  @Test
  public void test39() {
    ell.elle(31.470265567466733,-18.41203758002211 ) ;
  }

  @Test
  public void test40() {
    ell.elle(32.97666329327299,0.5340748389957923 ) ;
  }

  @Test
  public void test41() {
    ell.elle(34.564945794185626,-134.65227154900157 ) ;
  }

  @Test
  public void test42() {
    ell.elle(37.69911182138209,-0.9656937693982981 ) ;
  }

  @Test
  public void test43() {
    ell.elle(-37.69911183130277,-1.1987506780673678 ) ;
  }

  @Test
  public void test44() {
    ell.elle(37.69911184733576,-1.5055213594219576 ) ;
  }

  @Test
  public void test45() {
    ell.elle(37.69911185992257,0.485936630529622 ) ;
  }

  @Test
  public void test46() {
    ell.elle(37.73596215286693,-1.4122027060295324 ) ;
  }

  @Test
  public void test47() {
    ell.elle(-38.75201205338594,-1.1509299149513001 ) ;
  }

  @Test
  public void test48() {
    ell.elle(40.718828160706124,-0.9999999999999999 ) ;
  }

  @Test
  public void test49() {
    ell.elle(-40.84070448826178,75.12112352238651 ) ;
  }

  @Test
  public void test50() {
    ell.elle(42.41150170493547,-0.9999999999999993 ) ;
  }

  @Test
  public void test51() {
    ell.elle(-43.67163183119853,-0.9110568556353904 ) ;
  }

  @Test
  public void test52() {
    ell.elle(-43.98229696141639,-0.03057584453529394 ) ;
  }

  @Test
  public void test53() {
    ell.elle(43.982297156651526,0.598851782953908 ) ;
  }

  @Test
  public void test54() {
    ell.elle(43.98229725659327,0.15415866650076704 ) ;
  }

  @Test
  public void test55() {
    ell.elle(47.09519606865359,-34.47686111651278 ) ;
  }

  @Test
  public void test56() {
    ell.elle(-47.110776983873386,-76.2634322952282 ) ;
  }

  @Test
  public void test57() {
    ell.elle(-47.12388968972562,-0.08417903763414272 ) ;
  }

  @Test
  public void test58() {
    ell.elle(47.123889816486376,0.3487215443568574 ) ;
  }

  @Test
  public void test59() {
    ell.elle(-47.234470372558654,-0.29482368420322036 ) ;
  }

  @Test
  public void test60() {
    ell.elle(50.26548244933771,-29.152104157625974 ) ;
  }

  @Test
  public void test61() {
    ell.elle(50.26548245451781,5.485984085312106 ) ;
  }

  @Test
  public void test62() {
    ell.elle(50.26548245562165,-6.797128561382863 ) ;
  }

  @Test
  public void test63() {
    ell.elle(50.26548286355725,-1.4541294047167894 ) ;
  }

  @Test
  public void test64() {
    ell.elle(-53.40685976519097,-0.26567035711589426 ) ;
  }

  @Test
  public void test65() {
    ell.elle(-53.407075097012836,-0.08122736019593457 ) ;
  }

  @Test
  public void test66() {
    ell.elle(-53.40707511071123,17.732286373004072 ) ;
  }

  @Test
  public void test67() {
    ell.elle(53.40707513224962,1.0000600754469753 ) ;
  }

  @Test
  public void test68() {
    ell.elle(56.54876950484548,0.008772485880557563 ) ;
  }

  @Test
  public void test69() {
    ell.elle(56.55179444729993,2.6850889339733505E-6 ) ;
  }

  @Test
  public void test70() {
    ell.elle(-58.11909328725054,1.0000001336075057 ) ;
  }

  @Test
  public void test71() {
    ell.elle(-59.69026042477756,-0.2597114710519719 ) ;
  }

  @Test
  public void test72() {
    ell.elle(61.261056747029,-0.9999999999999993 ) ;
  }

  @Test
  public void test73() {
    ell.elle(-6.2831851570302,1.0011027313565282 ) ;
  }

  @Test
  public void test74() {
    ell.elle(-62.83185166228216,0.6868992247594008 ) ;
  }

  @Test
  public void test75() {
    ell.elle(62.83185306494485,43.59793344549319 ) ;
  }

  @Test
  public void test76() {
    ell.elle(62.83185308498321,-9.054271508385614 ) ;
  }

  @Test
  public void test77() {
    ell.elle(62.83185311625253,-0.9085296390430239 ) ;
  }

  @Test
  public void test78() {
    ell.elle(6.283185315611454,-46.72111354247382 ) ;
  }

  @Test
  public void test79() {
    ell.elle(-65.29809571611612,1.5995635543115696 ) ;
  }

  @Test
  public void test80() {
    ell.elle(65.70785504261599,-71.48450948658325 ) ;
  }

  @Test
  public void test81() {
    ell.elle(65.9734457242061,1.918943193733382 ) ;
  }

  @Test
  public void test82() {
    ell.elle(65.97344573601279,-0.6810677739573574 ) ;
  }

  @Test
  public void test83() {
    ell.elle(65.97344574296851,-0.6840313991053326 ) ;
  }

  @Test
  public void test84() {
    ell.elle(70.68583470577035,1.0 ) ;
  }

  @Test
  public void test85() {
    ell.elle(-70.69883064316718,1.0001688991440587 ) ;
  }

  @Test
  public void test86() {
    ell.elle(-71.9786567646384,5.0557359631824905 ) ;
  }

  @Test
  public void test87() {
    ell.elle(72.18766088022326,14.510526943571795 ) ;
  }

  @Test
  public void test88() {
    ell.elle(-72.25663102208243,30.37132315954239 ) ;
  }

  @Test
  public void test89() {
    ell.elle(-72.26380765502527,139.34250960058762 ) ;
  }

  @Test
  public void test90() {
    ell.elle(-75.3982237041003,0.20642365364872184 ) ;
  }

  @Test
  public void test91() {
    ell.elle(75.40796884790602,-102.6166474973038 ) ;
  }

  @Test
  public void test92() {
    ell.elle(-7.799914417479592,1.0014634143753123 ) ;
  }

  @Test
  public void test93() {
    ell.elle(-78.53981633561736,1.6344824831799656 ) ;
  }

  @Test
  public void test94() {
    ell.elle(78.5398163390534,2.507412185429621 ) ;
  }

  @Test
  public void test95() {
    ell.elle(-7.853981633974483,0.9999999999999999 ) ;
  }

  @Test
  public void test96() {
    ell.elle(78.53981634375327,3.3212428841731714 ) ;
  }

  @Test
  public void test97() {
    ell.elle(78.55823382162549,76.78430747827457 ) ;
  }

  @Test
  public void test98() {
    ell.elle(81.34180804974918,-3.0020036576130993 ) ;
  }

  @Test
  public void test99() {
    ell.elle(81.68070439732485,1.0000000002929808 ) ;
  }

  @Test
  public void test100() {
    ell.elle(81.68105558805927,0.9290994593835115 ) ;
  }

  @Test
  public void test101() {
    ell.elle(82.29422369782525,-1.7386095935397 ) ;
  }

  @Test
  public void test102() {
    ell.elle(-82.55135614561937,6.2835130430260335 ) ;
  }

  @Test
  public void test103() {
    ell.elle(83.25220532143602,-0.9657062982288158 ) ;
  }

  @Test
  public void test104() {
    ell.elle(84.81516704721943,-0.3254239150183813 ) ;
  }

  @Test
  public void test105() {
    ell.elle(-84.82300162974504,1.0246691006944546 ) ;
  }

  @Test
  public void test106() {
    ell.elle(-84.82300163158024,-0.8240375851847617 ) ;
  }

  @Test
  public void test107() {
    ell.elle(84.82300165732063,-62.15178164586981 ) ;
  }

  @Test
  public void test108() {
    ell.elle(-84.82748393257735,-223.10120905260555 ) ;
  }

  @Test
  public void test109() {
    ell.elle(87.58865112452382,2.7236824298372637 ) ;
  }

  @Test
  public void test110() {
    ell.elle(-87.96458141254706,-1.0000002106745585 ) ;
  }

  @Test
  public void test111() {
    ell.elle(-87.96459430011397,40.95756221814705 ) ;
  }

  @Test
  public void test112() {
    ell.elle(-87.96459430068727,1.1064513698158605 ) ;
  }

  @Test
  public void test113() {
    ell.elle(87.96459430174427,-4.289863580586969 ) ;
  }

  @Test
  public void test114() {
    ell.elle(89.18863969524668,-1.063284739618773 ) ;
  }

  @Test
  public void test115() {
    ell.elle(-91.30535031187196,0.880918963242614 ) ;
  }

  @Test
  public void test116() {
    ell.elle(-92.6769832808989,0.6082183232649072 ) ;
  }

  @Test
  public void test117() {
    ell.elle(-94.2477793889248,9.904345933678498E-4 ) ;
  }

  @Test
  public void test118() {
    ell.elle(-9.424777945307758,24.710009294088195 ) ;
  }

  @Test
  public void test119() {
    ell.elle(-9.424777948036953,0.9638249772999892 ) ;
  }

  @Test
  public void test120() {
    ell.elle(9.4247779569122,1.0001349748774888 ) ;
  }

  @Test
  public void test121() {
    ell.elle(-94.24777959121903,0.34952446312840113 ) ;
  }

  @Test
  public void test122() {
    ell.elle(-94.2477795999687,-1.025457368441053 ) ;
  }

  @Test
  public void test123() {
    ell.elle(-94.24777960371019,0.022156246389489098 ) ;
  }

  @Test
  public void test124() {
    ell.elle(-94.24777963371889,0.8752381253439783 ) ;
  }

  @Test
  public void test125() {
    ell.elle(-9.424777973011622,-1.6804964975462555 ) ;
  }

  @Test
  public void test126() {
    ell.elle(9.45264679095166,-35.88702684939998 ) ;
  }

  @Test
  public void test127() {
    ell.elle(95.61553921102234,-1.0415218650157134 ) ;
  }

  @Test
  public void test128() {
    ell.elle(97.3889711220779,-3.983322462709051E-6 ) ;
  }

  @Test
  public void test129() {
    ell.elle(-97.38937224379892,0.4361390168629242 ) ;
  }

  @Test
  public void test130() {
    ell.elle(-97.38937227475614,-1.0305678621623926 ) ;
  }

  @Test
  public void test131() {
    ell.elle(97.38937243220305,1.4656974145687096 ) ;
  }

  @Test
  public void test132() {
    ell.elle(97.58100267659339,-7.357617530048339 ) ;
  }
}
