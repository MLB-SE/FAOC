import org.junit.Test;

public class TestplgndrTest {

  @Test
  public void test0() {
    plgndr.plgndr(0,0,0 ) ;
  }

  @Test
  public void test1() {
    plgndr.plgndr(0,-1,0 ) ;
  }

  @Test
  public void test2() {
    plgndr.plgndr(0,-407,0 ) ;
  }

  @Test
  public void test3() {
    plgndr.plgndr(0,-834,0 ) ;
  }

  @Test
  public void test4() {
    plgndr.plgndr(0,934,0 ) ;
  }

  @Test
  public void test5() {
    plgndr.plgndr(-1,0,0 ) ;
  }

  @Test
  public void test6() {
    plgndr.plgndr(1266,264,-0.39840773882990743 ) ;
  }

  @Test
  public void test7() {
    plgndr.plgndr(-127,945,0 ) ;
  }

  @Test
  public void test8() {
    plgndr.plgndr(1300,941,0.9999999999999999 ) ;
  }

  @Test
  public void test9() {
    plgndr.plgndr(142,0,0.0 ) ;
  }

  @Test
  public void test10() {
    plgndr.plgndr(146,490,0 ) ;
  }

  @Test
  public void test11() {
    plgndr.plgndr(-169,-169,0 ) ;
  }

  @Test
  public void test12() {
    plgndr.plgndr(199,170,1.2768115131518654E-15 ) ;
  }

  @Test
  public void test13() {
    plgndr.plgndr(2,0,0 ) ;
  }

  @Test
  public void test14() {
    plgndr.plgndr(-249,-43,0 ) ;
  }

  @Test
  public void test15() {
    plgndr.plgndr(271,7,-1.0 ) ;
  }

  @Test
  public void test16() {
    plgndr.plgndr(-344,0,0 ) ;
  }

  @Test
  public void test17() {
    plgndr.plgndr(-371,1,0 ) ;
  }

  @Test
  public void test18() {
    plgndr.plgndr(-396,1,0 ) ;
  }

  @Test
  public void test19() {
    plgndr.plgndr(453,219,1.0000000000000002 ) ;
  }

  @Test
  public void test20() {
    plgndr.plgndr(-457,-304,0 ) ;
  }

  @Test
  public void test21() {
    plgndr.plgndr(-486,0,0 ) ;
  }

  @Test
  public void test22() {
    plgndr.plgndr(496,341,75.06669287884847 ) ;
  }

  @Test
  public void test23() {
    plgndr.plgndr(505,379,1.0 ) ;
  }

  @Test
  public void test24() {
    plgndr.plgndr(-51,-225,0 ) ;
  }

  @Test
  public void test25() {
    plgndr.plgndr(524,412,0.0 ) ;
  }

  @Test
  public void test26() {
    plgndr.plgndr(573,658,0 ) ;
  }

  @Test
  public void test27() {
    plgndr.plgndr(680,162,0.0 ) ;
  }

  @Test
  public void test28() {
    plgndr.plgndr(-699,0,0 ) ;
  }

  @Test
  public void test29() {
    plgndr.plgndr(-801,0,0 ) ;
  }

  @Test
  public void test30() {
    plgndr.plgndr(803,35,-76.90609738375997 ) ;
  }

  @Test
  public void test31() {
    plgndr.plgndr(811,-86,0 ) ;
  }

  @Test
  public void test32() {
    plgndr.plgndr(839,918,0 ) ;
  }

  @Test
  public void test33() {
    plgndr.plgndr(842,239,-70.10756878501212 ) ;
  }

  @Test
  public void test34() {
    plgndr.plgndr(891,823,0 ) ;
  }

  @Test
  public void test35() {
    plgndr.plgndr(896,207,84.01574909125617 ) ;
  }

  @Test
  public void test36() {
    plgndr.plgndr(-924,-925,0 ) ;
  }

  @Test
  public void test37() {
    plgndr.plgndr(979,721,0.0 ) ;
  }
}
