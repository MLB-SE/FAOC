import org.junit.Test;

public class TestfrenelTest {

  @Test
  public void test0() {
    frenel.frenel(-0.01763753190623185 ) ;
  }

  @Test
  public void test1() {
    frenel.frenel(-0.04891665270810108 ) ;
  }

  @Test
  public void test2() {
    frenel.frenel(-0.456733264031838 ) ;
  }

  @Test
  public void test3() {
    frenel.frenel(-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test4() {
    frenel.frenel(12.894056829181451 ) ;
  }

  @Test
  public void test5() {
    frenel.frenel(-1.4188616860636845 ) ;
  }

  @Test
  public void test6() {
    frenel.frenel(-1.4188616860636847 ) ;
  }

  @Test
  public void test7() {
    frenel.frenel(-1.418861686063685 ) ;
  }

  @Test
  public void test8() {
    frenel.frenel(-1.4188616860636853 ) ;
  }

  @Test
  public void test9() {
    frenel.frenel(-1.4188616860636944 ) ;
  }

  @Test
  public void test10() {
    frenel.frenel(-1.4188616860637218 ) ;
  }

  @Test
  public void test11() {
    frenel.frenel(-1.4188616860637357 ) ;
  }

  @Test
  public void test12() {
    frenel.frenel(-1.4188616860637409 ) ;
  }

  @Test
  public void test13() {
    frenel.frenel(-1.4188616860639558 ) ;
  }

  @Test
  public void test14() {
    frenel.frenel(-1.4188616860641217 ) ;
  }

  @Test
  public void test15() {
    frenel.frenel(-1.418861686064213 ) ;
  }

  @Test
  public void test16() {
    frenel.frenel(-1.4188616860647405 ) ;
  }

  @Test
  public void test17() {
    frenel.frenel(-1.4188616880608869 ) ;
  }

  @Test
  public void test18() {
    frenel.frenel(-1.4188635688792106 ) ;
  }

  @Test
  public void test19() {
    frenel.frenel(-1.4189615125885287 ) ;
  }

  @Test
  public void test20() {
    frenel.frenel(-1.4301314480908984 ) ;
  }

  @Test
  public void test21() {
    frenel.frenel(-1.4324163343211826 ) ;
  }

  @Test
  public void test22() {
    frenel.frenel(-1.4330842109379502 ) ;
  }

  @Test
  public void test23() {
    frenel.frenel(-1.4549249728533262 ) ;
  }

  @Test
  public void test24() {
    frenel.frenel(-1.4613894978842206 ) ;
  }

  @Test
  public void test25() {
    frenel.frenel(-1.463495382750764 ) ;
  }

  @Test
  public void test26() {
    frenel.frenel(-1.4677297132175764 ) ;
  }

  @Test
  public void test27() {
    frenel.frenel(-1.474625673266137 ) ;
  }

  @Test
  public void test28() {
    frenel.frenel(-1.4857549788361646 ) ;
  }

  @Test
  public void test29() {
    frenel.frenel(-1.4888586929199132 ) ;
  }

  @Test
  public void test30() {
    frenel.frenel(-1.4894130489674975 ) ;
  }

  @Test
  public void test31() {
    frenel.frenel(-1.4999999634100303 ) ;
  }

  @Test
  public void test32() {
    frenel.frenel(-1.4999999999999427 ) ;
  }

  @Test
  public void test33() {
    frenel.frenel(-1.4999999999999705 ) ;
  }

  @Test
  public void test34() {
    frenel.frenel(-1.4999999999999758 ) ;
  }

  @Test
  public void test35() {
    frenel.frenel(-1.4999999999999847 ) ;
  }

  @Test
  public void test36() {
    frenel.frenel(-1.4999999999999856 ) ;
  }

  @Test
  public void test37() {
    frenel.frenel(-1.4999999999999891 ) ;
  }

  @Test
  public void test38() {
    frenel.frenel(-1.499999999999993 ) ;
  }

  @Test
  public void test39() {
    frenel.frenel(-1.4999999999999964 ) ;
  }

  @Test
  public void test40() {
    frenel.frenel(-1.4999999999999982 ) ;
  }

  @Test
  public void test41() {
    frenel.frenel(-1.4999999999999987 ) ;
  }

  @Test
  public void test42() {
    frenel.frenel(-1.4999999999999991 ) ;
  }

  @Test
  public void test43() {
    frenel.frenel(-1.4999999999999993 ) ;
  }

  @Test
  public void test44() {
    frenel.frenel(-1.4999999999999996 ) ;
  }

  @Test
  public void test45() {
    frenel.frenel(-1.4999999999999998 ) ;
  }

  @Test
  public void test46() {
    frenel.frenel(-1.5 ) ;
  }

  @Test
  public void test47() {
    frenel.frenel(-18.01282110258444 ) ;
  }

  @Test
  public void test48() {
    frenel.frenel(-1.9259299443872359E-34 ) ;
  }

  @Test
  public void test49() {
    frenel.frenel(-19.82625960945211 ) ;
  }

  @Test
  public void test50() {
    frenel.frenel(-2.465190328815662E-32 ) ;
  }

  @Test
  public void test51() {
    frenel.frenel(-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test52() {
    frenel.frenel(3.0259510623185264 ) ;
  }

  @Test
  public void test53() {
    frenel.frenel(-32.844979239335444 ) ;
  }

  @Test
  public void test54() {
    frenel.frenel(-4.0E-323 ) ;
  }

  @Test
  public void test55() {
    frenel.frenel(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test56() {
    frenel.frenel(-6.938893903907228E-18 ) ;
  }

  @Test
  public void test57() {
    frenel.frenel(-7.2911220195563975E-304 ) ;
  }

  @Test
  public void test58() {
    frenel.frenel(-7.765351881710529 ) ;
  }

  @Test
  public void test59() {
    frenel.frenel(-8.881784197001252E-16 ) ;
  }

  @Test
  public void test60() {
    frenel.frenel(-90.63150197130432 ) ;
  }
}
