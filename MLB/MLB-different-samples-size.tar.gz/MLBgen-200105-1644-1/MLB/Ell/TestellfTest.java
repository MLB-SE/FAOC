import org.junit.Test;

public class TestellfTest {

  @Test
  public void test0() {
    ell.ellf(-100.0,1.0000000000000002 ) ;
  }

  @Test
  public void test1() {
    ell.ellf(117.80972450961724,0.9999999999999999 ) ;
  }

  @Test
  public void test2() {
    ell.ellf(12.209906464481392,-13.455299598817376 ) ;
  }

  @Test
  public void test3() {
    ell.ellf(12.539562757952837,37.306965978367764 ) ;
  }

  @Test
  public void test4() {
    ell.ellf(12.615419244182545,-20.396106425765506 ) ;
  }

  @Test
  public void test5() {
    ell.ellf(155.4935843726441,1.0001163227224346 ) ;
  }

  @Test
  public void test6() {
    ell.ellf(15.707963277402966,44.04322207241774 ) ;
  }

  @Test
  public void test7() {
    ell.ellf(-161.7687305854732,1.0005425232267828 ) ;
  }

  @Test
  public void test8() {
    ell.ellf(1.6860376556598027,0.7961286657483697 ) ;
  }

  @Test
  public void test9() {
    ell.ellf(-21.991148564629608,-27.85248267655498 ) ;
  }

  @Test
  public void test10() {
    ell.ellf(21.991148567392703,-100.0 ) ;
  }

  @Test
  public void test11() {
    ell.ellf(-21.9911485708311,1.469152919528774 ) ;
  }

  @Test
  public void test12() {
    ell.ellf(25.07194509583283,16.458551663591305 ) ;
  }

  @Test
  public void test13() {
    ell.ellf(-25.13273725879435,1.5608033859459275E-4 ) ;
  }

  @Test
  public void test14() {
    ell.ellf(-25.13274123808181,20.03814254302354 ) ;
  }

  @Test
  public void test15() {
    ell.ellf(-25.13274135639377,-0.035172429484052525 ) ;
  }

  @Test
  public void test16() {
    ell.ellf(-29.135602918050083,30.40036925741117 ) ;
  }

  @Test
  public void test17() {
    ell.ellf(31.415926536185104,-34.57651004063311 ) ;
  }

  @Test
  public void test18() {
    ell.ellf(3.1415926542259998,10.210491473809974 ) ;
  }

  @Test
  public void test19() {
    ell.ellf(32.98334002335847,1.0000114406270155 ) ;
  }

  @Test
  public void test20() {
    ell.ellf(32.98672283913202,-1.0 ) ;
  }

  @Test
  public void test21() {
    ell.ellf(-34.557519174225476,-0.37852772581319455 ) ;
  }

  @Test
  public void test22() {
    ell.ellf(34.5575192050889,-1.1135449638025425 ) ;
  }

  @Test
  public void test23() {
    ell.ellf(-36.108718603272756,1.0006881138928159 ) ;
  }

  @Test
  public void test24() {
    ell.ellf(-36.12831550713348,0.9694902142295924 ) ;
  }

  @Test
  public void test25() {
    ell.ellf(-37.5208398545263,-5.63922874575097 ) ;
  }

  @Test
  public void test26() {
    ell.ellf(37.699111857381986,0.7199195312320081 ) ;
  }

  @Test
  public void test27() {
    ell.ellf(-37.706944529248446,-1.0000000000003992 ) ;
  }

  @Test
  public void test28() {
    ell.ellf(-40.840704496968264,31.74140026894722 ) ;
  }

  @Test
  public void test29() {
    ell.ellf(40.94218269359383,7.161164306117442 ) ;
  }

  @Test
  public void test30() {
    ell.ellf(-4.201079989474039,-1.1466512604621124 ) ;
  }

  @Test
  public void test31() {
    ell.ellf(43.98229714837804,2.6771057425878553 ) ;
  }

  @Test
  public void test32() {
    ell.ellf(47.12388081162219,1.0000003802723345 ) ;
  }

  @Test
  public void test33() {
    ell.ellf(47.1238896836039,-1.0046738943631222 ) ;
  }

  @Test
  public void test34() {
    ell.ellf(-47.123889805464415,1.8256491368433103 ) ;
  }

  @Test
  public void test35() {
    ell.ellf(47.123889809732994,0.5605187805161551 ) ;
  }

  @Test
  public void test36() {
    ell.ellf(47.12388982405096,1.2822998145186704 ) ;
  }

  @Test
  public void test37() {
    ell.ellf(-50.19499538544696,-1.7271732447580743E-7 ) ;
  }

  @Test
  public void test38() {
    ell.ellf(-50.259293787518864,161.58664084186907 ) ;
  }

  @Test
  public void test39() {
    ell.ellf(-50.26547382874107,0.0014578960637084831 ) ;
  }

  @Test
  public void test40() {
    ell.ellf(-53.39096089002211,-7.462176804784075E-7 ) ;
  }

  @Test
  public void test41() {
    ell.ellf(-53.40707511399466,0.1303267814823812 ) ;
  }

  @Test
  public void test42() {
    ell.ellf(53.40707511454088,-35.536930048075696 ) ;
  }

  @Test
  public void test43() {
    ell.ellf(-53.408455498572984,-8.199404972560119E-6 ) ;
  }

  @Test
  public void test44() {
    ell.ellf(-54.97787180138763,0.9999999999999946 ) ;
  }

  @Test
  public void test45() {
    ell.ellf(54.98907822734314,-1.0001255947607006 ) ;
  }

  @Test
  public void test46() {
    ell.ellf(55.13070243897945,1.023450924679165 ) ;
  }

  @Test
  public void test47() {
    ell.ellf(56.54866773674839,0.48657191544210926 ) ;
  }

  @Test
  public void test48() {
    ell.ellf(56.548667741890256,0.597281013445115 ) ;
  }

  @Test
  public void test49() {
    ell.ellf(-56.54866777628359,1.2703725863706476 ) ;
  }

  @Test
  public void test50() {
    ell.ellf(56.56280966456251,99.9999999999197 ) ;
  }

  @Test
  public void test51() {
    ell.ellf(59.672098518194076,-3.018166416697328E-7 ) ;
  }

  @Test
  public void test52() {
    ell.ellf(59.690260404880036,-1.182759902435322 ) ;
  }

  @Test
  public void test53() {
    ell.ellf(59.6902604165937,-7.4402080145673475 ) ;
  }

  @Test
  public void test54() {
    ell.ellf(-59.69026041873953,1.0012810506636498 ) ;
  }

  @Test
  public void test55() {
    ell.ellf(59.690270245712846,-0.00144610961089775 ) ;
  }

  @Test
  public void test56() {
    ell.ellf(-59.70026058488024,-100.0 ) ;
  }

  @Test
  public void test57() {
    ell.ellf(61.261056755538036,1.0000000000000002 ) ;
  }

  @Test
  public void test58() {
    ell.ellf(6.217850790133208,15.316739648221787 ) ;
  }

  @Test
  public void test59() {
    ell.ellf(6.254251376085517,34.56632073621283 ) ;
  }

  @Test
  public void test60() {
    ell.ellf(-6.281923268265791,-0.9636304779023135 ) ;
  }

  @Test
  public void test61() {
    ell.ellf(-6.283184888929518,0.025974876628521937 ) ;
  }

  @Test
  public void test62() {
    ell.ellf(6.283185289538294,7.931104936095073 ) ;
  }

  @Test
  public void test63() {
    ell.ellf(-6.283185295032954,-0.4917935337771155 ) ;
  }

  @Test
  public void test64() {
    ell.ellf(62.831853069461886,-5.249068909244187 ) ;
  }

  @Test
  public void test65() {
    ell.ellf(-62.831853071979964,-80.88755571197662 ) ;
  }

  @Test
  public void test66() {
    ell.ellf(-62.831853086204255,-5.999441626458349 ) ;
  }

  @Test
  public void test67() {
    ell.ellf(6.283185308817544,6.28875493290186 ) ;
  }

  @Test
  public void test68() {
    ell.ellf(-62.83185308911525,-0.6540767302204529 ) ;
  }

  @Test
  public void test69() {
    ell.ellf(62.88439400027542,-7.419052460615646 ) ;
  }

  @Test
  public void test70() {
    ell.ellf(6.288454402706366,189.78677121349804 ) ;
  }

  @Test
  public void test71() {
    ell.ellf(64.40264938952978,-0.9999999999999997 ) ;
  }

  @Test
  public void test72() {
    ell.ellf(-65.1451544718898,1.3005432585569707 ) ;
  }

  @Test
  public void test73() {
    ell.ellf(65.93295208742586,-0.9999999999999695 ) ;
  }

  @Test
  public void test74() {
    ell.ellf(65.96999468355155,1.6360037670995296E-6 ) ;
  }

  @Test
  public void test75() {
    ell.ellf(-65.97344570853394,0.4537646387879104 ) ;
  }

  @Test
  public void test76() {
    ell.ellf(-65.97344571073623,0.6845544069264466 ) ;
  }

  @Test
  public void test77() {
    ell.ellf(-68.97392849299247,-7.11024876370596 ) ;
  }

  @Test
  public void test78() {
    ell.ellf(72.14627537041767,-0.13438183294705652 ) ;
  }

  @Test
  public void test79() {
    ell.ellf(72.25663101749605,-1.7747702875711866 ) ;
  }

  @Test
  public void test80() {
    ell.ellf(-72.25663102200063,-1.2519122257927344 ) ;
  }

  @Test
  public void test81() {
    ell.ellf(72.25663103420003,-100.0 ) ;
  }

  @Test
  public void test82() {
    ell.ellf(-73.82742720307944,-1.0000000001843665 ) ;
  }

  @Test
  public void test83() {
    ell.ellf(75.1788690431104,-4.5955929771773505 ) ;
  }

  @Test
  public void test84() {
    ell.ellf(-75.39822375610566,-0.263466811059672 ) ;
  }

  @Test
  public void test85() {
    ell.ellf(-75.97311616259941,1.8390988774790686 ) ;
  }

  @Test
  public void test86() {
    ell.ellf(7.853981623437771,1.0 ) ;
  }

  @Test
  public void test87() {
    ell.ellf(78.53981636386234,0.901488682578015 ) ;
  }

  @Test
  public void test88() {
    ell.ellf(78.5398170848432,-0.999902896440786 ) ;
  }

  @Test
  public void test89() {
    ell.ellf(78.54003991365762,-0.0029721868787130202 ) ;
  }

  @Test
  public void test90() {
    ell.ellf(81.55981099800601,-1.000000000000007 ) ;
  }

  @Test
  public void test91() {
    ell.ellf(-81.68140899394363,-24.685638948340753 ) ;
  }

  @Test
  public void test92() {
    ell.ellf(-81.68140899643555,70.55790964004316 ) ;
  }

  @Test
  public void test93() {
    ell.ellf(81.68140900397741,0.6043983458780657 ) ;
  }

  @Test
  public void test94() {
    ell.ellf(81.68140900601514,-6.411747033737569 ) ;
  }

  @Test
  public void test95() {
    ell.ellf(-81.68141121697818,-0.01361441159133762 ) ;
  }

  @Test
  public void test96() {
    ell.ellf(82.33119003623827,10.133487385788982 ) ;
  }

  @Test
  public void test97() {
    ell.ellf(-83.54508348678804,-0.37864649879087153 ) ;
  }

  @Test
  public void test98() {
    ell.ellf(-84.82300166466646,1.000603552413512 ) ;
  }

  @Test
  public void test99() {
    ell.ellf(-87.96459430525232,-20.202233296526416 ) ;
  }

  @Test
  public void test100() {
    ell.ellf(87.96459435293593,-0.9943322411294394 ) ;
  }

  @Test
  public void test101() {
    ell.ellf(-89.14808689646227,0.3551423415267365 ) ;
  }

  @Test
  public void test102() {
    ell.ellf(-89.5353906367895,0.999999999999999 ) ;
  }

  @Test
  public void test103() {
    ell.ellf(90.53521362177887,-0.1926165712672372 ) ;
  }

  @Test
  public void test104() {
    ell.ellf(91.10618695107465,1.480356759528639 ) ;
  }

  @Test
  public void test105() {
    ell.ellf(-91.10618695179633,-4.344274037399582 ) ;
  }

  @Test
  public void test106() {
    ell.ellf(-91.10624620011114,-0.9999999969256466 ) ;
  }

  @Test
  public void test107() {
    ell.ellf(-91.11162033723456,184.04829850289855 ) ;
  }

  @Test
  public void test108() {
    ell.ellf(9.266674029624937,-0.7985465859268146 ) ;
  }

  @Test
  public void test109() {
    ell.ellf(-92.6769832808989,-0.448648686477917 ) ;
  }

  @Test
  public void test110() {
    ell.ellf(94.09301040041353,-0.8152478958243705 ) ;
  }

  @Test
  public void test111() {
    ell.ellf(-94.24777863670069,1.0000055792261453 ) ;
  }

  @Test
  public void test112() {
    ell.ellf(-9.424777951336587,-0.7036392448008798 ) ;
  }

  @Test
  public void test113() {
    ell.ellf(-94.24777960781657,54.153688944669234 ) ;
  }

  @Test
  public void test114() {
    ell.ellf(-94.24777961207238,-3.132708572027539 ) ;
  }

  @Test
  public void test115() {
    ell.ellf(-9.424777972342673,-1.489100793822301 ) ;
  }

  @Test
  public void test116() {
    ell.ellf(-97.35978227237374,-0.17253269525213444 ) ;
  }

  @Test
  public void test117() {
    ell.ellf(-97.38937226126002,-93.50801155692923 ) ;
  }

  @Test
  public void test118() {
    ell.ellf(-98.96016857754176,-1.0000000000000002 ) ;
  }
}
