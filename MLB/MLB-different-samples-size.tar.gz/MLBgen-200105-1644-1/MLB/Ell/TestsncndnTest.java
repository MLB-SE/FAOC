import org.junit.Test;

public class TestsncndnTest {

  @Test
  public void test0() {
    ell.sncndn(0,-0.5315727454038628 ) ;
  }

  @Test
  public void test1() {
    ell.sncndn(0,-0.6180339887498949 ) ;
  }

  @Test
  public void test2() {
    ell.sncndn(0,0.9999999679129834 ) ;
  }

  @Test
  public void test3() {
    ell.sncndn(0,0.9999999799978351 ) ;
  }

  @Test
  public void test4() {
    ell.sncndn(0,0.99999998 ) ;
  }

  @Test
  public void test5() {
    ell.sncndn(0,0.9999999811034492 ) ;
  }

  @Test
  public void test6() {
    ell.sncndn(0,1.0 ) ;
  }

  @Test
  public void test7() {
    ell.sncndn(0,1.0000000010181158 ) ;
  }

  @Test
  public void test8() {
    ell.sncndn(0,1.00000002 ) ;
  }

  @Test
  public void test9() {
    ell.sncndn(0,1.0000000356069292 ) ;
  }

  @Test
  public void test10() {
    ell.sncndn(0,1.0000000484995017 ) ;
  }

  @Test
  public void test11() {
    ell.sncndn(0,10.930594854351568 ) ;
  }

  @Test
  public void test12() {
    ell.sncndn(0,-13.243417508576982 ) ;
  }

  @Test
  public void test13() {
    ell.sncndn(0,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test14() {
    ell.sncndn(0,20.511477108420692 ) ;
  }

  @Test
  public void test15() {
    ell.sncndn(0,-21.441541843481332 ) ;
  }

  @Test
  public void test16() {
    ell.sncndn(0,-2.148804274470592 ) ;
  }

  @Test
  public void test17() {
    ell.sncndn(0,2.220446049250313E-16 ) ;
  }

  @Test
  public void test18() {
    ell.sncndn(0,-35.3993462886169 ) ;
  }

  @Test
  public void test19() {
    ell.sncndn(0,-3731.6421210874464 ) ;
  }

  @Test
  public void test20() {
    ell.sncndn(0,-40.49148463529648 ) ;
  }

  @Test
  public void test21() {
    ell.sncndn(0,-43.260871443006856 ) ;
  }

  @Test
  public void test22() {
    ell.sncndn(0,4.930380657631324E-32 ) ;
  }

  @Test
  public void test23() {
    ell.sncndn(0,52.59647147321212 ) ;
  }

  @Test
  public void test24() {
    ell.sncndn(0,52.76092648134889 ) ;
  }

  @Test
  public void test25() {
    ell.sncndn(0,5.673109653701729 ) ;
  }

  @Test
  public void test26() {
    ell.sncndn(0,-6.992856881133292 ) ;
  }

  @Test
  public void test27() {
    ell.sncndn(0,-87.56656234138325 ) ;
  }

  @Test
  public void test28() {
    ell.sncndn(0,8.881784197001252E-16 ) ;
  }

  @Test
  public void test29() {
    ell.sncndn(0,97.14019023206387 ) ;
  }

  @Test
  public void test30() {
    ell.sncndn(27.501606633702313,1.115548009556286 ) ;
  }

  @Test
  public void test31() {
    ell.sncndn(-29.914837023316284,0.999999999999415 ) ;
  }

  @Test
  public void test32() {
    ell.sncndn(-47.782331078610056,1.0000000000000002 ) ;
  }

  @Test
  public void test33() {
    ell.sncndn(54.51106573467392,1.1551073535374117 ) ;
  }

  @Test
  public void test34() {
    ell.sncndn(-56.632385415405295,0.999999980000299 ) ;
  }

  @Test
  public void test35() {
    ell.sncndn(59.473151120189215,1.0000000038314085 ) ;
  }

  @Test
  public void test36() {
    ell.sncndn(-8.24676476229638,1.0000000000042186 ) ;
  }

  @Test
  public void test37() {
    ell.sncndn(93.05671635441352,1.0 ) ;
  }

  @Test
  public void test38() {
    ell.sncndn(-99.99999999999999,1.0213513660912659 ) ;
  }
}
