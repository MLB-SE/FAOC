import org.junit.Test;

public class TestgasdevTest {

  @Test
  public void test0() {
    dev.gasdev(0 ) ;
  }

  @Test
  public void test1() {
    dev.gasdev(-1 ) ;
  }

  @Test
  public void test2() {
    dev.gasdev(-177 ) ;
  }

  @Test
  public void test3() {
    dev.gasdev(-184 ) ;
  }

  @Test
  public void test4() {
    dev.gasdev(-198 ) ;
  }

  @Test
  public void test5() {
    dev.gasdev(-266 ) ;
  }

  @Test
  public void test6() {
    dev.gasdev(-28 ) ;
  }

  @Test
  public void test7() {
    dev.gasdev(-311 ) ;
  }

  @Test
  public void test8() {
    dev.gasdev(-32 ) ;
  }

  @Test
  public void test9() {
    dev.gasdev(-365 ) ;
  }

  @Test
  public void test10() {
    dev.gasdev(393 ) ;
  }

  @Test
  public void test11() {
    dev.gasdev(-446 ) ;
  }

  @Test
  public void test12() {
    dev.gasdev(-631 ) ;
  }

  @Test
  public void test13() {
    dev.gasdev(-757 ) ;
  }

  @Test
  public void test14() {
    dev.gasdev(-802 ) ;
  }

  @Test
  public void test15() {
    dev.gasdev(-847 ) ;
  }
}
