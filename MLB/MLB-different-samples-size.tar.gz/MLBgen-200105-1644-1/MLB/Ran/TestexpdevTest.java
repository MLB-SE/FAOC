import org.junit.Test;

public class TestexpdevTest {

  @Test
  public void test0() {
    dev.expdev(0 ) ;
  }

  @Test
  public void test1() {
    dev.expdev(-1 ) ;
  }

  @Test
  public void test2() {
    dev.expdev(-109 ) ;
  }

  @Test
  public void test3() {
    dev.expdev(-266 ) ;
  }

  @Test
  public void test4() {
    dev.expdev(-282 ) ;
  }

  @Test
  public void test5() {
    dev.expdev(-356 ) ;
  }

  @Test
  public void test6() {
    dev.expdev(-490 ) ;
  }

  @Test
  public void test7() {
    dev.expdev(-532 ) ;
  }

  @Test
  public void test8() {
    dev.expdev(-577 ) ;
  }

  @Test
  public void test9() {
    dev.expdev(-622 ) ;
  }

  @Test
  public void test10() {
    dev.expdev(-631 ) ;
  }

  @Test
  public void test11() {
    dev.expdev(654 ) ;
  }

  @Test
  public void test12() {
    dev.expdev(-687 ) ;
  }

  @Test
  public void test13() {
    dev.expdev(-712 ) ;
  }

  @Test
  public void test14() {
    dev.expdev(-786 ) ;
  }

  @Test
  public void test15() {
    dev.expdev(-802 ) ;
  }

  @Test
  public void test16() {
    dev.expdev(-841 ) ;
  }

  @Test
  public void test17() {
    dev.expdev(-847 ) ;
  }

  @Test
  public void test18() {
    dev.expdev(867 ) ;
  }

  @Test
  public void test19() {
    dev.expdev(-877 ) ;
  }
}
