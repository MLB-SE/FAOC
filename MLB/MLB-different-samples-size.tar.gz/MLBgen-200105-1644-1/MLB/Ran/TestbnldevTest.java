import org.junit.Test;

public class TestbnldevTest {

  @Test
  public void test0() {
    dev.bnldev(0.0,114,0 ) ;
  }

  @Test
  public void test1() {
    dev.bnldev(0.0,48,0 ) ;
  }

  @Test
  public void test2() {
    dev.bnldev(-100.0,62,0 ) ;
  }

  @Test
  public void test3() {
    dev.bnldev(1.0,127,0 ) ;
  }

  @Test
  public void test4() {
    dev.bnldev(1.0,242,330 ) ;
  }

  @Test
  public void test5() {
    dev.bnldev(1.0,-32,0 ) ;
  }

  @Test
  public void test6() {
    dev.bnldev(1.0,523,65 ) ;
  }

  @Test
  public void test7() {
    dev.bnldev(1.0,539,0 ) ;
  }

  @Test
  public void test8() {
    dev.bnldev(106.0,203,-106 ) ;
  }

  @Test
  public void test9() {
    dev.bnldev(1.0,-655,0 ) ;
  }

  @Test
  public void test10() {
    dev.bnldev(-107.0,444,982 ) ;
  }

  @Test
  public void test11() {
    dev.bnldev(10.98247121131817,0,0 ) ;
  }

  @Test
  public void test12() {
    dev.bnldev(-117.0,-483,0 ) ;
  }

  @Test
  public void test13() {
    dev.bnldev(-149.0,87,9 ) ;
  }

  @Test
  public void test14() {
    dev.bnldev(15.0,25,0 ) ;
  }

  @Test
  public void test15() {
    dev.bnldev(-151.0,61,146 ) ;
  }

  @Test
  public void test16() {
    dev.bnldev(-185.0,-939,0 ) ;
  }

  @Test
  public void test17() {
    dev.bnldev(-194.0,-973,0 ) ;
  }

  @Test
  public void test18() {
    dev.bnldev(2.0,558,154 ) ;
  }

  @Test
  public void test19() {
    dev.bnldev(215.0,861,0 ) ;
  }

  @Test
  public void test20() {
    dev.bnldev(-351.0,256,-267 ) ;
  }

  @Test
  public void test21() {
    dev.bnldev(-355.0,240,409 ) ;
  }

  @Test
  public void test22() {
    dev.bnldev(-355.0,-458,0 ) ;
  }

  @Test
  public void test23() {
    dev.bnldev(-364.0,166,422 ) ;
  }

  @Test
  public void test24() {
    dev.bnldev(370.0,563,469 ) ;
  }

  @Test
  public void test25() {
    dev.bnldev(388.0,315,981 ) ;
  }

  @Test
  public void test26() {
    dev.bnldev(389.0,23,0 ) ;
  }

  @Test
  public void test27() {
    dev.bnldev(41.0,-571,0 ) ;
  }

  @Test
  public void test28() {
    dev.bnldev(-435.0,288,117 ) ;
  }

  @Test
  public void test29() {
    dev.bnldev(489.0,-839,0 ) ;
  }

  @Test
  public void test30() {
    dev.bnldev(54.98211874698643,0,0 ) ;
  }

  @Test
  public void test31() {
    dev.bnldev(58.0,12,299 ) ;
  }

  @Test
  public void test32() {
    dev.bnldev(588.0,450,-124 ) ;
  }

  @Test
  public void test33() {
    dev.bnldev(592.0,274,705 ) ;
  }

  @Test
  public void test34() {
    dev.bnldev(-6.0,88,997 ) ;
  }

  @Test
  public void test35() {
    dev.bnldev(619.0,388,980 ) ;
  }

  @Test
  public void test36() {
    dev.bnldev(62.0,-683,0 ) ;
  }

  @Test
  public void test37() {
    dev.bnldev(624.0,-1,942 ) ;
  }

  @Test
  public void test38() {
    dev.bnldev(-628.0,-1,0 ) ;
  }

  @Test
  public void test39() {
    dev.bnldev(-629.0,-887,0 ) ;
  }

  @Test
  public void test40() {
    dev.bnldev(638.0,311,0 ) ;
  }

  @Test
  public void test41() {
    dev.bnldev(-638.0,950,500 ) ;
  }

  @Test
  public void test42() {
    dev.bnldev(-645.0,595,0 ) ;
  }

  @Test
  public void test43() {
    dev.bnldev(-650.0,589,0 ) ;
  }

  @Test
  public void test44() {
    dev.bnldev(-685.0,292,932 ) ;
  }

  @Test
  public void test45() {
    dev.bnldev(-72.0,1610,-1 ) ;
  }

  @Test
  public void test46() {
    dev.bnldev(749.0,16,379 ) ;
  }

  @Test
  public void test47() {
    dev.bnldev(775.0,468,373 ) ;
  }

  @Test
  public void test48() {
    dev.bnldev(-778.0,699,-981 ) ;
  }

  @Test
  public void test49() {
    dev.bnldev(-829.0,12,-365 ) ;
  }

  @Test
  public void test50() {
    dev.bnldev(841.0,4,-536 ) ;
  }

  @Test
  public void test51() {
    dev.bnldev(-845.0,63,0 ) ;
  }

  @Test
  public void test52() {
    dev.bnldev(-862.0,10,0 ) ;
  }

  @Test
  public void test53() {
    dev.bnldev(92.0,421,-1 ) ;
  }

  @Test
  public void test54() {
    dev.bnldev(-922.0,11,857 ) ;
  }

  @Test
  public void test55() {
    dev.bnldev(952.0,762,0 ) ;
  }

  @Test
  public void test56() {
    dev.bnldev(-959.0,25,87 ) ;
  }

  @Test
  public void test57() {
    dev.bnldev(985.0,680,0 ) ;
  }

  @Test
  public void test58() {
    dev.bnldev(-99.900324999819,0,0 ) ;
  }
}
