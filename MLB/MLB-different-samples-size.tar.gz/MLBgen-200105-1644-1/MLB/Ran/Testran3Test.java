import org.junit.Test;

public class Testran3Test {

  @Test
  public void test0() {
    ran.ran3(0 ) ;
  }

  @Test
  public void test1() {
    ran.ran3(111 ) ;
  }

  @Test
  public void test2() {
    ran.ran3(2 ) ;
  }

  @Test
  public void test3() {
    ran.ran3(269 ) ;
  }

  @Test
  public void test4() {
    ran.ran3(28232 ) ;
  }

  @Test
  public void test5() {
    ran.ran3(28427 ) ;
  }

  @Test
  public void test6() {
    ran.ran3(306 ) ;
  }

  @Test
  public void test7() {
    ran.ran3(32378 ) ;
  }

  @Test
  public void test8() {
    ran.ran3(36 ) ;
  }

  @Test
  public void test9() {
    ran.ran3(360 ) ;
  }

  @Test
  public void test10() {
    ran.ran3(37127 ) ;
  }

  @Test
  public void test11() {
    ran.ran3(37154 ) ;
  }

  @Test
  public void test12() {
    ran.ran3(37217 ) ;
  }

  @Test
  public void test13() {
    ran.ran3(37254 ) ;
  }

  @Test
  public void test14() {
    ran.ran3(37273 ) ;
  }

  @Test
  public void test15() {
    ran.ran3(37299 ) ;
  }

  @Test
  public void test16() {
    ran.ran3(37307 ) ;
  }

  @Test
  public void test17() {
    ran.ran3(37406 ) ;
  }

  @Test
  public void test18() {
    ran.ran3(37411 ) ;
  }

  @Test
  public void test19() {
    ran.ran3(37412 ) ;
  }

  @Test
  public void test20() {
    ran.ran3(38217 ) ;
  }

  @Test
  public void test21() {
    ran.ran3(38229 ) ;
  }

  @Test
  public void test22() {
    ran.ran3(387 ) ;
  }

  @Test
  public void test23() {
    ran.ran3(394 ) ;
  }

  @Test
  public void test24() {
    ran.ran3(402 ) ;
  }

  @Test
  public void test25() {
    ran.ran3(437 ) ;
  }

  @Test
  public void test26() {
    ran.ran3(449 ) ;
  }

  @Test
  public void test27() {
    ran.ran3(534 ) ;
  }

  @Test
  public void test28() {
    ran.ran3(544 ) ;
  }

  @Test
  public void test29() {
    ran.ran3(-6 ) ;
  }

  @Test
  public void test30() {
    ran.ran3(615 ) ;
  }

  @Test
  public void test31() {
    ran.ran3(63 ) ;
  }

  @Test
  public void test32() {
    ran.ran3(664 ) ;
  }

  @Test
  public void test33() {
    ran.ran3(715 ) ;
  }

  @Test
  public void test34() {
    ran.ran3(761 ) ;
  }

  @Test
  public void test35() {
    ran.ran3(827 ) ;
  }

  @Test
  public void test36() {
    ran.ran3(840 ) ;
  }

  @Test
  public void test37() {
    ran.ran3(85 ) ;
  }

  @Test
  public void test38() {
    ran.ran3(865 ) ;
  }

  @Test
  public void test39() {
    ran.ran3(905 ) ;
  }

  @Test
  public void test40() {
    ran.ran3(941 ) ;
  }

  @Test
  public void test41() {
    ran.ran3(9561 ) ;
  }

  @Test
  public void test42() {
    ran.ran3(9735 ) ;
  }

  @Test
  public void test43() {
    ran.ran3(9852 ) ;
  }
}
