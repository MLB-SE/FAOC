import org.junit.Test;

public class TestbetacfTest {

  @Test
  public void test0() {
    beta.betacf(-0.9446036740605263,-2.9370511444400433,-0.014271316881513074 ) ;
  }

  @Test
  public void test1() {
    beta.betacf(-100.0,-1.1845423814201652,0.9784103151528285 ) ;
  }

  @Test
  public void test2() {
    beta.betacf(12.415925047140234,57.393510666047604,-99.12385320914095 ) ;
  }

  @Test
  public void test3() {
    beta.betacf(-14.002290889841902,50.83246200455159,-0.35303368125403267 ) ;
  }

  @Test
  public void test4() {
    beta.betacf(17.466566491154254,57.542072152877495,94.95125943995282 ) ;
  }

  @Test
  public void test5() {
    beta.betacf(-19.626299439110312,94.13171788234914,-33.69985333119136 ) ;
  }

  @Test
  public void test6() {
    beta.betacf(21.702813026569316,-19.63132421903215,10.959660001041064 ) ;
  }

  @Test
  public void test7() {
    beta.betacf(-32.53483188437782,14.945913677002778,-25.63176775778571 ) ;
  }

  @Test
  public void test8() {
    beta.betacf(-40.164732258363166,-23.426976433625285,0.6158779668598101 ) ;
  }

  @Test
  public void test9() {
    beta.betacf(43.398360323001384,-56.47361524087757,-3.3956018908894054 ) ;
  }

  @Test
  public void test10() {
    beta.betacf(50.168453620191315,-58.155841253525665,-6.406156301547989 ) ;
  }

  @Test
  public void test11() {
    beta.betacf(51.04049798604737,-10.15825010542035,90.6285133186623 ) ;
  }

  @Test
  public void test12() {
    beta.betacf(-53.922996135470584,54.80590195239978,-59.941836513820064 ) ;
  }

  @Test
  public void test13() {
    beta.betacf(56.77748455705495,13.373188740119545,98.12647985405695 ) ;
  }

  @Test
  public void test14() {
    beta.betacf(58.007292905151914,-52.600106832181304,10.912754269751693 ) ;
  }

  @Test
  public void test15() {
    beta.betacf(-66.37950947625077,67.19846465555378,-79.83282984044864 ) ;
  }

  @Test
  public void test16() {
    beta.betacf(-73.95701892892708,-32.3296115599713,-80.38716832328048 ) ;
  }

  @Test
  public void test17() {
    beta.betacf(76.78886186292803,77.5438218574499,54.808106146967816 ) ;
  }

  @Test
  public void test18() {
    beta.betacf(-79.66654785276172,80.61528917891668,-82.91675052417082 ) ;
  }

  @Test
  public void test19() {
    beta.betacf(79.83894813198282,-73.14134662198816,-73.24335018468729 ) ;
  }

  @Test
  public void test20() {
    beta.betacf(-8.914799917048228,0,0 ) ;
  }

  @Test
  public void test21() {
    beta.betacf(92.7550094166952,-56.67726340651012,2.5986936487170595 ) ;
  }

  @Test
  public void test22() {
    beta.betacf(-9.801239433642905,0,0 ) ;
  }
}
