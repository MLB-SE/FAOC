import org.junit.Test;

public class TesteiTest {

  @Test
  public void test0() {
    expint.ei(0.0015652377189554862 ) ;
  }

  @Test
  public void test1() {
    expint.ei(0.008458251006125591 ) ;
  }

  @Test
  public void test2() {
    expint.ei(0.061362327321052304 ) ;
  }

  @Test
  public void test3() {
    expint.ei(0.19355198123718914 ) ;
  }

  @Test
  public void test4() {
    expint.ei(0.4156956373798926 ) ;
  }

  @Test
  public void test5() {
    expint.ei(0.7232656054321196 ) ;
  }

  @Test
  public void test6() {
    expint.ei(1.0118E-320 ) ;
  }

  @Test
  public void test7() {
    expint.ei(1.02357610986477E-310 ) ;
  }

  @Test
  public void test8() {
    expint.ei(1.0235761228164E-310 ) ;
  }

  @Test
  public void test9() {
    expint.ei(1.0826321357697676E-308 ) ;
  }

  @Test
  public void test10() {
    expint.ei(-1.0876772950704492 ) ;
  }

  @Test
  public void test11() {
    expint.ei(1.1064215796514614 ) ;
  }

  @Test
  public void test12() {
    expint.ei(1.107293711123526E-309 ) ;
  }

  @Test
  public void test13() {
    expint.ei(1.108423140501529E-308 ) ;
  }

  @Test
  public void test14() {
    expint.ei(1.1102230246251565E-16 ) ;
  }

  @Test
  public void test15() {
    expint.ei(1.1665795231290236E-302 ) ;
  }

  @Test
  public void test16() {
    expint.ei(1.18206852048384E-309 ) ;
  }

  @Test
  public void test17() {
    expint.ei(1.192156968048778E-307 ) ;
  }

  @Test
  public void test18() {
    expint.ei(1.295163E-318 ) ;
  }

  @Test
  public void test19() {
    expint.ei(1.5548613752727984 ) ;
  }

  @Test
  public void test20() {
    expint.ei(1.58E-322 ) ;
  }

  @Test
  public void test21() {
    expint.ei(16.140356156483364 ) ;
  }

  @Test
  public void test22() {
    expint.ei(1.61895E-319 ) ;
  }

  @Test
  public void test23() {
    expint.ei(1.73833895195875E-310 ) ;
  }

  @Test
  public void test24() {
    expint.ei(1.7763568394002505E-15 ) ;
  }

  @Test
  public void test25() {
    expint.ei(1.79219153366381E-309 ) ;
  }

  @Test
  public void test26() {
    expint.ei(1.79607086532951E-309 ) ;
  }

  @Test
  public void test27() {
    expint.ei(-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test28() {
    expint.ei(1.9721522630525295E-31 ) ;
  }

  @Test
  public void test29() {
    expint.ei(19.906972086905526 ) ;
  }

  @Test
  public void test30() {
    expint.ei(2.0237E-320 ) ;
  }

  @Test
  public void test31() {
    expint.ei(2.04715223268117E-310 ) ;
  }

  @Test
  public void test32() {
    expint.ei(2.059628621785645 ) ;
  }

  @Test
  public void test33() {
    expint.ei(2.121995791E-314 ) ;
  }

  @Test
  public void test34() {
    expint.ei(2.1775305773227E-310 ) ;
  }

  @Test
  public void test35() {
    expint.ei(2.17753057752505E-310 ) ;
  }

  @Test
  public void test36() {
    expint.ei(2.220446049250313E-16 ) ;
  }

  @Test
  public void test37() {
    expint.ei(2.23254072297923E-309 ) ;
  }

  @Test
  public void test38() {
    expint.ei(2.258143216076511E-307 ) ;
  }

  @Test
  public void test39() {
    expint.ei(2.465190328815662E-32 ) ;
  }

  @Test
  public void test40() {
    expint.ei(2.53E-321 ) ;
  }

  @Test
  public void test41() {
    expint.ei(2.57300023170921E-309 ) ;
  }

  @Test
  public void test42() {
    expint.ei(2.613567102297931 ) ;
  }

  @Test
  public void test43() {
    expint.ei(2.6688954500947E-310 ) ;
  }

  @Test
  public void test44() {
    expint.ei(28.26008283736212 ) ;
  }

  @Test
  public void test45() {
    expint.ei(28.69067576102745 ) ;
  }

  @Test
  public void test46() {
    expint.ei(2.90628543530604E-310 ) ;
  }

  @Test
  public void test47() {
    expint.ei(2.9692982555461E-310 ) ;
  }

  @Test
  public void test48() {
    expint.ei(3.1031765596797E-310 ) ;
  }

  @Test
  public void test49() {
    expint.ei(3.19381547886123E-310 ) ;
  }

  @Test
  public void test50() {
    expint.ei(3.2112354868671114 ) ;
  }

  @Test
  public void test51() {
    expint.ei(32.23619130191664 ) ;
  }

  @Test
  public void test52() {
    expint.ei(3.2379E-319 ) ;
  }

  @Test
  public void test53() {
    expint.ei(3.39374838186613E-309 ) ;
  }

  @Test
  public void test54() {
    expint.ei(3.53747308332866E-310 ) ;
  }

  @Test
  public void test55() {
    expint.ei(3.5601181736115222E-307 ) ;
  }

  @Test
  public void test56() {
    expint.ei(3.76049032837693E-310 ) ;
  }

  @Test
  public void test57() {
    expint.ei(37.96938758605049 ) ;
  }

  @Test
  public void test58() {
    expint.ei(3.848621014927715 ) ;
  }

  @Test
  public void test59() {
    expint.ei(3.8965006389031E-310 ) ;
  }

  @Test
  public void test60() {
    expint.ei(3.998752092352898E-19 ) ;
  }

  @Test
  public void test61() {
    expint.ei(4.0474E-320 ) ;
  }

  @Test
  public void test62() {
    expint.ei(4.207882906344466 ) ;
  }

  @Test
  public void test63() {
    expint.ei(4.242640912119312E-7 ) ;
  }

  @Test
  public void test64() {
    expint.ei(4.242640912119313E-7 ) ;
  }

  @Test
  public void test65() {
    expint.ei(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test66() {
    expint.ei(4.440892098500626E-16 ) ;
  }

  @Test
  public void test67() {
    expint.ei(-45.00065015109873 ) ;
  }

  @Test
  public void test68() {
    expint.ei(4.5227880323828895 ) ;
  }

  @Test
  public void test69() {
    expint.ei(4.930380657631324E-32 ) ;
  }

  @Test
  public void test70() {
    expint.ei(5.04460303179955E-310 ) ;
  }

  @Test
  public void test71() {
    expint.ei(5.07180826047317E-310 ) ;
  }

  @Test
  public void test72() {
    expint.ei(5.117880549324E-311 ) ;
  }

  @Test
  public void test73() {
    expint.ei(5.117880581703E-311 ) ;
  }

  @Test
  public void test74() {
    expint.ei(5.117880614082E-311 ) ;
  }

  @Test
  public void test75() {
    expint.ei(5.231525446547925 ) ;
  }

  @Test
  public void test76() {
    expint.ei(5.48573631829175E-310 ) ;
  }

  @Test
  public void test77() {
    expint.ei(5.676220811910483 ) ;
  }

  @Test
  public void test78() {
    expint.ei(5.973037656324737 ) ;
  }

  @Test
  public void test79() {
    expint.ei(5.98457105203001E-309 ) ;
  }

  @Test
  public void test80() {
    expint.ei(6.162975822039155E-33 ) ;
  }

  @Test
  public void test81() {
    expint.ei(6.47582E-319 ) ;
  }

  @Test
  public void test82() {
    expint.ei(6.636151467456136E-6 ) ;
  }

  @Test
  public void test83() {
    expint.ei(-66.88479337589592 ) ;
  }

  @Test
  public void test84() {
    expint.ei(6.75890154935193E-309 ) ;
  }

  @Test
  public void test85() {
    expint.ei(6.87544111186628E-309 ) ;
  }

  @Test
  public void test86() {
    expint.ei(6.9E-323 ) ;
  }

  @Test
  public void test87() {
    expint.ei(7.2911220195563975E-304 ) ;
  }

  @Test
  public void test88() {
    expint.ei(7.703719777548943E-34 ) ;
  }

  @Test
  public void test89() {
    expint.ei(8.09021681102903E-309 ) ;
  }

  @Test
  public void test90() {
    expint.ei(8.0948E-320 ) ;
  }

  @Test
  public void test91() {
    expint.ei(8.408976054230806 ) ;
  }

  @Test
  public void test92() {
    expint.ei(8.470329472543003E-22 ) ;
  }

  @Test
  public void test93() {
    expint.ei(8.881784197001252E-16 ) ;
  }

  @Test
  public void test94() {
    expint.ei(8.900295434028806E-308 ) ;
  }

  @Test
  public void test95() {
    expint.ei(98.5514772537606 ) ;
  }

  @Test
  public void test96() {
    expint.ei(9.860761315262648E-32 ) ;
  }

  @Test
  public void test97() {
    expint.ei(9.864929395126312E-5 ) ;
  }
}
