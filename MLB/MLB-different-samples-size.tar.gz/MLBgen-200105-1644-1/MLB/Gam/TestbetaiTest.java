import org.junit.Test;

public class TestbetaiTest {

  @Test
  public void test0() {
    beta.betai(0,0,0.9999918711694706 ) ;
  }

  @Test
  public void test1() {
    beta.betai(0,0,1.0 ) ;
  }

  @Test
  public void test2() {
    beta.betai(0,0,1.0000000000000002 ) ;
  }

  @Test
  public void test3() {
    beta.betai(0,0,1.0000000000000009 ) ;
  }

  @Test
  public void test4() {
    beta.betai(0,0,-1.0357329552989256 ) ;
  }

  @Test
  public void test5() {
    beta.betai(0,0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test6() {
    beta.betai(0,0,-11.548251058212088 ) ;
  }

  @Test
  public void test7() {
    beta.betai(0,0,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test8() {
    beta.betai(0,0,16.311647787133452 ) ;
  }

  @Test
  public void test9() {
    beta.betai(0,0,17.40076509935436 ) ;
  }

  @Test
  public void test10() {
    beta.betai(0,0,-17.926315354789082 ) ;
  }

  @Test
  public void test11() {
    beta.betai(0,0,24.444880383351645 ) ;
  }

  @Test
  public void test12() {
    beta.betai(0,0,-30.799983046136788 ) ;
  }

  @Test
  public void test13() {
    beta.betai(0,0,30.94290245662387 ) ;
  }

  @Test
  public void test14() {
    beta.betai(0,0,-39.31873523684586 ) ;
  }

  @Test
  public void test15() {
    beta.betai(0,0,-4.295540067551812 ) ;
  }

  @Test
  public void test16() {
    beta.betai(0,0,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test17() {
    beta.betai(0,0,-6.096163364275881 ) ;
  }

  @Test
  public void test18() {
    beta.betai(0,0,72.02749019841451 ) ;
  }

  @Test
  public void test19() {
    beta.betai(0,0,83.9650307381757 ) ;
  }

  @Test
  public void test20() {
    beta.betai(0,0,-95.43436346239191 ) ;
  }

  @Test
  public void test21() {
    beta.betai(-19.25990861757654,17.25990861757654,-77.57870593891451 ) ;
  }

  @Test
  public void test22() {
    beta.betai(19.46332700264304,-77.93570504960064,-74.58142433175792 ) ;
  }

  @Test
  public void test23() {
    beta.betai(-36.169784632400535,35.169784632400535,-99.96975974667113 ) ;
  }

  @Test
  public void test24() {
    beta.betai(50.708870269368845,32.75688868359819,97.40499895315381 ) ;
  }

  @Test
  public void test25() {
    beta.betai(79.24403503646357,-80.24403503646357,49.74314951140863 ) ;
  }

  @Test
  public void test26() {
    beta.betai(8.085616977110448,10.389585183532631,-64.19001454560897 ) ;
  }
}
