import org.junit.Test;

public class TesterfccTest {

  @Test
  public void test0() {
    erf.erfcc(-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1() {
    erf.erfcc(1.14E-322 ) ;
  }

  @Test
  public void test2() {
    erf.erfcc(1.5089795706478242 ) ;
  }

  @Test
  public void test3() {
    erf.erfcc(-2.6739733848415597 ) ;
  }

  @Test
  public void test4() {
    erf.erfcc(-27.250433939953794 ) ;
  }

  @Test
  public void test5() {
    erf.erfcc(28.905615026939387 ) ;
  }

  @Test
  public void test6() {
    erf.erfcc(-42.019674591091686 ) ;
  }

  @Test
  public void test7() {
    erf.erfcc(5.096331928025762 ) ;
  }

  @Test
  public void test8() {
    erf.erfcc(-51.09265467832509 ) ;
  }

  @Test
  public void test9() {
    erf.erfcc(5.551115123125783E-17 ) ;
  }

  @Test
  public void test10() {
    erf.erfcc(8.610496911029486 ) ;
  }

  @Test
  public void test11() {
    erf.erfcc(-8.938797152507021 ) ;
  }

  @Test
  public void test12() {
    erf.erfcc(-8.9E-323 ) ;
  }
}
