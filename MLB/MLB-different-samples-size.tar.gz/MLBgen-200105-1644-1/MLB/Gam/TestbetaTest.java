import org.junit.Test;

public class TestbetaTest {

  @Test
  public void test0() {
    beta.beta(-13.11423519348611,0 ) ;
  }

  @Test
  public void test1() {
    beta.beta(15.359024338558427,0 ) ;
  }

  @Test
  public void test2() {
    beta.beta(-2.0,0 ) ;
  }

  @Test
  public void test3() {
    beta.beta(-3.0,0 ) ;
  }

  @Test
  public void test4() {
    beta.beta(-3.0482502839271177,0 ) ;
  }

  @Test
  public void test5() {
    beta.beta(47.83869695704837,0 ) ;
  }
}
