import org.junit.Test;

public class TestbicoTest {

  @Test
  public void test0() {
    gam.bico(0,0 ) ;
  }

  @Test
  public void test1() {
    gam.bico(0,-1 ) ;
  }

  @Test
  public void test2() {
    gam.bico(0,-935 ) ;
  }

  @Test
  public void test3() {
    gam.bico(0,-946 ) ;
  }

  @Test
  public void test4() {
    gam.bico(-1,0 ) ;
  }

  @Test
  public void test5() {
    gam.bico(1,0 ) ;
  }

  @Test
  public void test6() {
    gam.bico(1,-1 ) ;
  }

  @Test
  public void test7() {
    gam.bico(1,1 ) ;
  }

  @Test
  public void test8() {
    gam.bico(-130,0 ) ;
  }

  @Test
  public void test9() {
    gam.bico(1,-464 ) ;
  }

  @Test
  public void test10() {
    gam.bico(1,495 ) ;
  }

  @Test
  public void test11() {
    gam.bico(-153,-571 ) ;
  }

  @Test
  public void test12() {
    gam.bico(16,0 ) ;
  }

  @Test
  public void test13() {
    gam.bico(1,-750 ) ;
  }

  @Test
  public void test14() {
    gam.bico(-175,-1 ) ;
  }

  @Test
  public void test15() {
    gam.bico(-188,-190 ) ;
  }

  @Test
  public void test16() {
    gam.bico(1,900 ) ;
  }

  @Test
  public void test17() {
    gam.bico(-262,0 ) ;
  }

  @Test
  public void test18() {
    gam.bico(29,0 ) ;
  }

  @Test
  public void test19() {
    gam.bico(293,0 ) ;
  }

  @Test
  public void test20() {
    gam.bico(-298,-523 ) ;
  }

  @Test
  public void test21() {
    gam.bico(-311,820 ) ;
  }

  @Test
  public void test22() {
    gam.bico(-36,85 ) ;
  }

  @Test
  public void test23() {
    gam.bico(-374,-123 ) ;
  }

  @Test
  public void test24() {
    gam.bico(-459,-460 ) ;
  }

  @Test
  public void test25() {
    gam.bico(-467,0 ) ;
  }

  @Test
  public void test26() {
    gam.bico(-516,-426 ) ;
  }

  @Test
  public void test27() {
    gam.bico(-521,-26 ) ;
  }

  @Test
  public void test28() {
    gam.bico(-549,1 ) ;
  }

  @Test
  public void test29() {
    gam.bico(-634,-959 ) ;
  }

  @Test
  public void test30() {
    gam.bico(-777,163 ) ;
  }

  @Test
  public void test31() {
    gam.bico(-877,0 ) ;
  }

  @Test
  public void test32() {
    gam.bico(-928,319 ) ;
  }

  @Test
  public void test33() {
    gam.bico(962,0 ) ;
  }
}
