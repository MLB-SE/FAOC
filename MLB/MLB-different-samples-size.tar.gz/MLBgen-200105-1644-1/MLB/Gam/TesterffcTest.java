import org.junit.Test;

public class TesterffcTest {

  @Test
  public void test0() {
    gam.erffc(-0.009689124422458395 ) ;
  }

  @Test
  public void test1() {
    gam.erffc(-0.012868915807872083 ) ;
  }

  @Test
  public void test2() {
    gam.erffc(-0.4663458923785142 ) ;
  }

  @Test
  public void test3() {
    gam.erffc(-0.47935131159910327 ) ;
  }

  @Test
  public void test4() {
    gam.erffc(-0.5955419259892096 ) ;
  }

  @Test
  public void test5() {
    gam.erffc(-0.8963350845248055 ) ;
  }

  @Test
  public void test6() {
    gam.erffc(-1.0489708659658419 ) ;
  }

  @Test
  public void test7() {
    gam.erffc(1.0978223386067727 ) ;
  }

  @Test
  public void test8() {
    gam.erffc(-1.1066481416793823 ) ;
  }

  @Test
  public void test9() {
    gam.erffc(1.1102230246251565E-16 ) ;
  }

  @Test
  public void test10() {
    gam.erffc(1.1980269148596445 ) ;
  }

  @Test
  public void test11() {
    gam.erffc(1.224744871391589 ) ;
  }

  @Test
  public void test12() {
    gam.erffc(-1.2247448713915892 ) ;
  }

  @Test
  public void test13() {
    gam.erffc(1.2247448713915892 ) ;
  }

  @Test
  public void test14() {
    gam.erffc(-1.2247448713915953E-7 ) ;
  }

  @Test
  public void test15() {
    gam.erffc(-1.224744871391595E-7 ) ;
  }

  @Test
  public void test16() {
    gam.erffc(1.224744871391595E-7 ) ;
  }

  @Test
  public void test17() {
    gam.erffc(-1.224919060816379E-7 ) ;
  }

  @Test
  public void test18() {
    gam.erffc(-1.2252565283802986E-7 ) ;
  }

  @Test
  public void test19() {
    gam.erffc(1.2634920662350609E-175 ) ;
  }

  @Test
  public void test20() {
    gam.erffc(-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test21() {
    gam.erffc(1.3877787807814457E-17 ) ;
  }

  @Test
  public void test22() {
    gam.erffc(1.4225655996704496E-160 ) ;
  }

  @Test
  public void test23() {
    gam.erffc(-14.819618615515907 ) ;
  }

  @Test
  public void test24() {
    gam.erffc(1.5192908393215678E-64 ) ;
  }

  @Test
  public void test25() {
    gam.erffc(-1.734723475976807E-18 ) ;
  }

  @Test
  public void test26() {
    gam.erffc(-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test27() {
    gam.erffc(1.7763568394002505E-15 ) ;
  }

  @Test
  public void test28() {
    gam.erffc(-2.220446049250313E-16 ) ;
  }

  @Test
  public void test29() {
    gam.erffc(-2.2227587494850775E-162 ) ;
  }

  @Test
  public void test30() {
    gam.erffc(29.148060937958377 ) ;
  }

  @Test
  public void test31() {
    gam.erffc(-31.953031291637558 ) ;
  }

  @Test
  public void test32() {
    gam.erffc(33.18321019011714 ) ;
  }

  @Test
  public void test33() {
    gam.erffc(38.31424599102283 ) ;
  }

  @Test
  public void test34() {
    gam.erffc(-3.8461027721301347E-4 ) ;
  }

  @Test
  public void test35() {
    gam.erffc(39.18608757684581 ) ;
  }

  @Test
  public void test36() {
    gam.erffc(-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test37() {
    gam.erffc(-4.3790577010150533E-47 ) ;
  }

  @Test
  public void test38() {
    gam.erffc(-4.400558825994401E-4 ) ;
  }

  @Test
  public void test39() {
    gam.erffc(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test40() {
    gam.erffc(4.440892098500626E-16 ) ;
  }

  @Test
  public void test41() {
    gam.erffc(52.47722977971168 ) ;
  }

  @Test
  public void test42() {
    gam.erffc(-55.48111251459267 ) ;
  }

  @Test
  public void test43() {
    gam.erffc(61.33600373368978 ) ;
  }

  @Test
  public void test44() {
    gam.erffc(6.3174603311753045E-176 ) ;
  }

  @Test
  public void test45() {
    gam.erffc(64.73361584910177 ) ;
  }

  @Test
  public void test46() {
    gam.erffc(-6.851857049792159 ) ;
  }

  @Test
  public void test47() {
    gam.erffc(-69.4958394894383 ) ;
  }

  @Test
  public void test48() {
    gam.erffc(-71.03379217001606 ) ;
  }

  @Test
  public void test49() {
    gam.erffc(-7.112827998352248E-161 ) ;
  }

  @Test
  public void test50() {
    gam.erffc(7.112827998352248E-161 ) ;
  }

  @Test
  public void test51() {
    gam.erffc(81.43136946362355 ) ;
  }

  @Test
  public void test52() {
    gam.erffc(-8.881784197001252E-16 ) ;
  }

  @Test
  public void test53() {
    gam.erffc(8.881784197001252E-16 ) ;
  }

  @Test
  public void test54() {
    gam.erffc(-8.892725007008589E-5 ) ;
  }

  @Test
  public void test55() {
    gam.erffc(-93.56457764777551 ) ;
  }

  @Test
  public void test56() {
    gam.erffc(-97.27692202973093 ) ;
  }
}
