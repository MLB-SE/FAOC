import org.junit.Test;

public class TestexpintTest {

  @Test
  public void test0() {
    expint.expint(0,0.0 ) ;
  }

  @Test
  public void test1() {
    expint.expint(0,48.979657762300064 ) ;
  }

  @Test
  public void test2() {
    expint.expint(1,0.0 ) ;
  }

  @Test
  public void test3() {
    expint.expint(17,1.0 ) ;
  }

  @Test
  public void test4() {
    expint.expint(-305,0 ) ;
  }

  @Test
  public void test5() {
    expint.expint(39,74.03009818079508 ) ;
  }

  @Test
  public void test6() {
    expint.expint(433,0.0 ) ;
  }

  @Test
  public void test7() {
    expint.expint(463,0.0 ) ;
  }

  @Test
  public void test8() {
    expint.expint(505,44.490310418159964 ) ;
  }

  @Test
  public void test9() {
    expint.expint(544,0.0 ) ;
  }

  @Test
  public void test10() {
    expint.expint(579,-1.5E-323 ) ;
  }

  @Test
  public void test11() {
    expint.expint(593,0 ) ;
  }

  @Test
  public void test12() {
    expint.expint(648,-1.1369637766292868 ) ;
  }

  @Test
  public void test13() {
    expint.expint(694,0.9991401633474016 ) ;
  }

  @Test
  public void test14() {
    expint.expint(694,8.4E-323 ) ;
  }

  @Test
  public void test15() {
    expint.expint(706,1.0E-322 ) ;
  }

  @Test
  public void test16() {
    expint.expint(739,75.0145285641712 ) ;
  }

  @Test
  public void test17() {
    expint.expint(753,9.546984000945244 ) ;
  }

  @Test
  public void test18() {
    expint.expint(774,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test19() {
    expint.expint(842,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test20() {
    expint.expint(864,1.040152481007155 ) ;
  }

  @Test
  public void test21() {
    expint.expint(916,9.4E-323 ) ;
  }

  @Test
  public void test22() {
    expint.expint(940,0.0 ) ;
  }
}
