import org.junit.Test;

public class TesterffTest {

  @Test
  public void test0() {
    gam.erff(0.012757429415758637 ) ;
  }

  @Test
  public void test1() {
    gam.erff(-0.13903185689115105 ) ;
  }

  @Test
  public void test2() {
    gam.erff(0.2866797366616609 ) ;
  }

  @Test
  public void test3() {
    gam.erff(0.8284019864422447 ) ;
  }

  @Test
  public void test4() {
    gam.erff(0.8327060595768605 ) ;
  }

  @Test
  public void test5() {
    gam.erff(-0.9880782951994063 ) ;
  }

  @Test
  public void test6() {
    gam.erff(1.0107936529880487E-174 ) ;
  }

  @Test
  public void test7() {
    gam.erff(-1.0276161120798266 ) ;
  }

  @Test
  public void test8() {
    gam.erff(1.0947644252537633E-47 ) ;
  }

  @Test
  public void test9() {
    gam.erff(-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test10() {
    gam.erff(-1.1380524797363597E-159 ) ;
  }

  @Test
  public void test11() {
    gam.erff(1.1892301236312979 ) ;
  }

  @Test
  public void test12() {
    gam.erff(-1.2065918547898147 ) ;
  }

  @Test
  public void test13() {
    gam.erff(-1.224744871391589 ) ;
  }

  @Test
  public void test14() {
    gam.erff(1.224744871391589 ) ;
  }

  @Test
  public void test15() {
    gam.erff(-1.2247448713915892 ) ;
  }

  @Test
  public void test16() {
    gam.erff(1.2247448713915892 ) ;
  }

  @Test
  public void test17() {
    gam.erff(-1.224744871391595E-7 ) ;
  }

  @Test
  public void test18() {
    gam.erff(1.224744871391595E-7 ) ;
  }

  @Test
  public void test19() {
    gam.erff(-12.255741053318815 ) ;
  }

  @Test
  public void test20() {
    gam.erff(1.2634920662350609E-175 ) ;
  }

  @Test
  public void test21() {
    gam.erff(-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test22() {
    gam.erff(-16.22673744535163 ) ;
  }

  @Test
  public void test23() {
    gam.erff(16.691067961752196 ) ;
  }

  @Test
  public void test24() {
    gam.erff(-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test25() {
    gam.erff(1.7763568394002505E-15 ) ;
  }

  @Test
  public void test26() {
    gam.erff(21.588151154458217 ) ;
  }

  @Test
  public void test27() {
    gam.erff(-2.5269841324701218E-175 ) ;
  }

  @Test
  public void test28() {
    gam.erff(-25.50365653779194 ) ;
  }

  @Test
  public void test29() {
    gam.erff(2.7755575615628914E-17 ) ;
  }

  @Test
  public void test30() {
    gam.erff(2.973498315583086 ) ;
  }

  @Test
  public void test31() {
    gam.erff(32.31141005258104 ) ;
  }

  @Test
  public void test32() {
    gam.erff(3.423664972728858 ) ;
  }

  @Test
  public void test33() {
    gam.erff(-3.552713678800501E-15 ) ;
  }

  @Test
  public void test34() {
    gam.erff(36.399414437159635 ) ;
  }

  @Test
  public void test35() {
    gam.erff(-39.771781460292345 ) ;
  }

  @Test
  public void test36() {
    gam.erff(40.96303653514971 ) ;
  }

  @Test
  public void test37() {
    gam.erff(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test38() {
    gam.erff(4.440892098500626E-16 ) ;
  }

  @Test
  public void test39() {
    gam.erff(-4.5522099189454387E-159 ) ;
  }

  @Test
  public void test40() {
    gam.erff(4.5522099189454387E-159 ) ;
  }

  @Test
  public void test41() {
    gam.erff(-5.0539682649402436E-175 ) ;
  }

  @Test
  public void test42() {
    gam.erff(5.421010862427522E-20 ) ;
  }

  @Test
  public void test43() {
    gam.erff(54.54115084302805 ) ;
  }

  @Test
  public void test44() {
    gam.erff(5.551115123125783E-17 ) ;
  }

  @Test
  public void test45() {
    gam.erff(5.6902623986817984E-160 ) ;
  }

  @Test
  public void test46() {
    gam.erff(-61.81979221263576 ) ;
  }

  @Test
  public void test47() {
    gam.erff(64.73503539094284 ) ;
  }

  @Test
  public void test48() {
    gam.erff(6.938893903907228E-18 ) ;
  }

  @Test
  public void test49() {
    gam.erff(-70.28376682263948 ) ;
  }

  @Test
  public void test50() {
    gam.erff(-82.92206649558892 ) ;
  }

  @Test
  public void test51() {
    gam.erff(-85.30411276233121 ) ;
  }

  @Test
  public void test52() {
    gam.erff(-8.881784197001252E-16 ) ;
  }

  @Test
  public void test53() {
    gam.erff(-9.629649721936179E-35 ) ;
  }
}
