import org.junit.Test;

public class TestjuldayTest {

  @Test
  public void test0() {
    caldat.julday(0,0,0 ) ;
  }

  @Test
  public void test1() {
    caldat.julday(0,0,-1 ) ;
  }

  @Test
  public void test2() {
    caldat.julday(0,0,-420 ) ;
  }

  @Test
  public void test3() {
    caldat.julday(0,0,-696 ) ;
  }

  @Test
  public void test4() {
    caldat.julday(0,0,894 ) ;
  }

  @Test
  public void test5() {
    caldat.julday(1,0,0 ) ;
  }

  @Test
  public void test6() {
    caldat.julday(-1023,-167,0 ) ;
  }

  @Test
  public void test7() {
    caldat.julday(-11,0,-429 ) ;
  }

  @Test
  public void test8() {
    caldat.julday(-1120,0,1 ) ;
  }

  @Test
  public void test9() {
    caldat.julday(1,-125,245 ) ;
  }

  @Test
  public void test10() {
    caldat.julday(-11,623,2053 ) ;
  }

  @Test
  public void test11() {
    caldat.julday(1235,-673,0 ) ;
  }

  @Test
  public void test12() {
    caldat.julday(-13,0,0 ) ;
  }

  @Test
  public void test13() {
    caldat.julday(-13,0,-1487 ) ;
  }

  @Test
  public void test14() {
    caldat.julday(-13,0,234 ) ;
  }

  @Test
  public void test15() {
    caldat.julday(-13,0,409 ) ;
  }

  @Test
  public void test16() {
    caldat.julday(-13,0,-860 ) ;
  }

  @Test
  public void test17() {
    caldat.julday(1,31015,-3 ) ;
  }

  @Test
  public void test18() {
    caldat.julday(1,31486,2 ) ;
  }

  @Test
  public void test19() {
    caldat.julday(-13,25983,-4 ) ;
  }

  @Test
  public void test20() {
    caldat.julday(-132,-910,1781 ) ;
  }

  @Test
  public void test21() {
    caldat.julday(-13,31010,0 ) ;
  }

  @Test
  public void test22() {
    caldat.julday(-13,430,-684 ) ;
  }

  @Test
  public void test23() {
    caldat.julday(-13,-517,1813 ) ;
  }

  @Test
  public void test24() {
    caldat.julday(-13,-830,633 ) ;
  }

  @Test
  public void test25() {
    caldat.julday(-13,873,1903 ) ;
  }

  @Test
  public void test26() {
    caldat.julday(142,-925,-554 ) ;
  }

  @Test
  public void test27() {
    caldat.julday(-156,0,-1 ) ;
  }

  @Test
  public void test28() {
    caldat.julday(-158,748,954 ) ;
  }

  @Test
  public void test29() {
    caldat.julday(-16,33144,2 ) ;
  }

  @Test
  public void test30() {
    caldat.julday(-169,0,0 ) ;
  }

  @Test
  public void test31() {
    caldat.julday(-17,29178,-6 ) ;
  }

  @Test
  public void test32() {
    caldat.julday(19173,1410,0 ) ;
  }

  @Test
  public void test33() {
    caldat.julday(19215,1231,-5 ) ;
  }

  @Test
  public void test34() {
    caldat.julday(197,0,-352 ) ;
  }

  @Test
  public void test35() {
    caldat.julday(-2,0,0 ) ;
  }

  @Test
  public void test36() {
    caldat.julday(-2,0,-10 ) ;
  }

  @Test
  public void test37() {
    caldat.julday(20122,895,-80 ) ;
  }

  @Test
  public void test38() {
    caldat.julday(-2016,-102,719 ) ;
  }

  @Test
  public void test39() {
    caldat.julday(-2016,573,-162 ) ;
  }

  @Test
  public void test40() {
    caldat.julday(-2,0,468 ) ;
  }

  @Test
  public void test41() {
    caldat.julday(-2,0,610 ) ;
  }

  @Test
  public void test42() {
    caldat.julday(-2,0,-741 ) ;
  }

  @Test
  public void test43() {
    caldat.julday(-217,0,594 ) ;
  }

  @Test
  public void test44() {
    caldat.julday(-22,32303,-4 ) ;
  }

  @Test
  public void test45() {
    caldat.julday(-237,0,2 ) ;
  }

  @Test
  public void test46() {
    caldat.julday(-240,0,190 ) ;
  }

  @Test
  public void test47() {
    caldat.julday(2,438,690 ) ;
  }

  @Test
  public void test48() {
    caldat.julday(2,-523,0 ) ;
  }

  @Test
  public void test49() {
    caldat.julday(-27,0,623 ) ;
  }

  @Test
  public void test50() {
    caldat.julday(-27,529,1636 ) ;
  }

  @Test
  public void test51() {
    caldat.julday(2,938,2396 ) ;
  }

  @Test
  public void test52() {
    caldat.julday(301,584,316 ) ;
  }

  @Test
  public void test53() {
    caldat.julday(305,328,1590 ) ;
  }

  @Test
  public void test54() {
    caldat.julday(-312,0,597 ) ;
  }

  @Test
  public void test55() {
    caldat.julday(344,0,-418 ) ;
  }

  @Test
  public void test56() {
    caldat.julday(-3,563,-281 ) ;
  }

  @Test
  public void test57() {
    caldat.julday(-371,0,1 ) ;
  }

  @Test
  public void test58() {
    caldat.julday(3899,-467,2072 ) ;
  }

  @Test
  public void test59() {
    caldat.julday(4,0,0 ) ;
  }

  @Test
  public void test60() {
    caldat.julday(4,0,162 ) ;
  }

  @Test
  public void test61() {
    caldat.julday(4,0,-21 ) ;
  }

  @Test
  public void test62() {
    caldat.julday(4,0,588 ) ;
  }

  @Test
  public void test63() {
    caldat.julday(-406,0,-997 ) ;
  }

  @Test
  public void test64() {
    caldat.julday(4,0,-634 ) ;
  }

  @Test
  public void test65() {
    caldat.julday(410,-23,-229 ) ;
  }

  @Test
  public void test66() {
    caldat.julday(430,0,64 ) ;
  }

  @Test
  public void test67() {
    caldat.julday(438,0,1 ) ;
  }

  @Test
  public void test68() {
    caldat.julday(-46,842,265 ) ;
  }

  @Test
  public void test69() {
    caldat.julday(471,0,1 ) ;
  }

  @Test
  public void test70() {
    caldat.julday(48,0,428 ) ;
  }

  @Test
  public void test71() {
    caldat.julday(-509,0,809 ) ;
  }

  @Test
  public void test72() {
    caldat.julday(530,0,0 ) ;
  }

  @Test
  public void test73() {
    caldat.julday(-6,0,136 ) ;
  }

  @Test
  public void test74() {
    caldat.julday(-6,292,-32 ) ;
  }

  @Test
  public void test75() {
    caldat.julday(-645,0,0 ) ;
  }

  @Test
  public void test76() {
    caldat.julday(-653,0,-856 ) ;
  }

  @Test
  public void test77() {
    caldat.julday(-655,482,-8 ) ;
  }

  @Test
  public void test78() {
    caldat.julday(656,0,-673 ) ;
  }

  @Test
  public void test79() {
    caldat.julday(659,0,746 ) ;
  }

  @Test
  public void test80() {
    caldat.julday(698,0,162 ) ;
  }

  @Test
  public void test81() {
    caldat.julday(-7,0,-1407 ) ;
  }

  @Test
  public void test82() {
    caldat.julday(714,0,820 ) ;
  }

  @Test
  public void test83() {
    caldat.julday(716,0,-1 ) ;
  }

  @Test
  public void test84() {
    caldat.julday(727,0,-705 ) ;
  }

  @Test
  public void test85() {
    caldat.julday(-7,31457,-4 ) ;
  }

  @Test
  public void test86() {
    caldat.julday(752,0,-423 ) ;
  }

  @Test
  public void test87() {
    caldat.julday(799,0,0 ) ;
  }

  @Test
  public void test88() {
    caldat.julday(-8,0,481 ) ;
  }

  @Test
  public void test89() {
    caldat.julday(814,683,354 ) ;
  }

  @Test
  public void test90() {
    caldat.julday(-8,28387,-7 ) ;
  }

  @Test
  public void test91() {
    caldat.julday(-840,-875,-798 ) ;
  }

  @Test
  public void test92() {
    caldat.julday(-8,-499,0 ) ;
  }

  @Test
  public void test93() {
    caldat.julday(-88,0,0 ) ;
  }

  @Test
  public void test94() {
    caldat.julday(887,0,-1 ) ;
  }

  @Test
  public void test95() {
    caldat.julday(901,0,0 ) ;
  }

  @Test
  public void test96() {
    caldat.julday(-943,0,-252 ) ;
  }

  @Test
  public void test97() {
    caldat.julday(-989,0,-460 ) ;
  }
}
