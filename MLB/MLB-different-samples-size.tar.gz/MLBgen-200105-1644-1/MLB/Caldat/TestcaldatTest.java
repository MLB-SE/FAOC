import org.junit.Test;

public class TestcaldatTest {

  @Test
  public void test0() {
    caldat.caldat(0 ) ;
  }

  @Test
  public void test1() {
    caldat.caldat(-1 ) ;
  }

  @Test
  public void test2() {
    caldat.caldat(-102 ) ;
  }

  @Test
  public void test3() {
    caldat.caldat(-104 ) ;
  }

  @Test
  public void test4() {
    caldat.caldat(14086 ) ;
  }

  @Test
  public void test5() {
    caldat.caldat(-225 ) ;
  }

  @Test
  public void test6() {
    caldat.caldat(-32 ) ;
  }

  @Test
  public void test7() {
    caldat.caldat(-334 ) ;
  }

  @Test
  public void test8() {
    caldat.caldat(-335 ) ;
  }

  @Test
  public void test9() {
    caldat.caldat(342 ) ;
  }

  @Test
  public void test10() {
    caldat.caldat(358 ) ;
  }

  @Test
  public void test11() {
    caldat.caldat(-361 ) ;
  }

  @Test
  public void test12() {
    caldat.caldat(37332 ) ;
  }

  @Test
  public void test13() {
    caldat.caldat(38 ) ;
  }

  @Test
  public void test14() {
    caldat.caldat(-386 ) ;
  }

  @Test
  public void test15() {
    caldat.caldat(41 ) ;
  }

  @Test
  public void test16() {
    caldat.caldat(-566 ) ;
  }

  @Test
  public void test17() {
    caldat.caldat(646 ) ;
  }

  @Test
  public void test18() {
    caldat.caldat(-664 ) ;
  }

  @Test
  public void test19() {
    caldat.caldat(-682 ) ;
  }

  @Test
  public void test20() {
    caldat.caldat(-689 ) ;
  }

  @Test
  public void test21() {
    caldat.caldat(-708 ) ;
  }

  @Test
  public void test22() {
    caldat.caldat(733 ) ;
  }

  @Test
  public void test23() {
    caldat.caldat(766 ) ;
  }

  @Test
  public void test24() {
    caldat.caldat(770 ) ;
  }

  @Test
  public void test25() {
    caldat.caldat(771 ) ;
  }

  @Test
  public void test26() {
    caldat.caldat(786 ) ;
  }

  @Test
  public void test27() {
    caldat.caldat(80 ) ;
  }

  @Test
  public void test28() {
    caldat.caldat(-862 ) ;
  }

  @Test
  public void test29() {
    caldat.caldat(985 ) ;
  }
}
