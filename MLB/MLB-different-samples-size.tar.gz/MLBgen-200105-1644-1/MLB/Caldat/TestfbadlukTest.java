import org.junit.Test;

public class TestfbadlukTest {

  @Test
  public void test0() {
    caldat.badluk(0 ) ;
  }

  @Test
  public void test1() {
    caldat.badluk(-1 ) ;
  }

  @Test
  public void test2() {
    caldat.badluk(1 ) ;
  }

  @Test
  public void test3() {
    caldat.badluk(12 ) ;
  }

  @Test
  public void test4() {
    caldat.badluk(121 ) ;
  }

  @Test
  public void test5() {
    caldat.badluk(-13 ) ;
  }

  @Test
  public void test6() {
    caldat.badluk(-132 ) ;
  }

  @Test
  public void test7() {
    caldat.badluk(-14 ) ;
  }

  @Test
  public void test8() {
    caldat.badluk(1678 ) ;
  }

  @Test
  public void test9() {
    caldat.badluk(1685 ) ;
  }

  @Test
  public void test10() {
    caldat.badluk(17 ) ;
  }

  @Test
  public void test11() {
    caldat.badluk(18 ) ;
  }

  @Test
  public void test12() {
    caldat.badluk(-19 ) ;
  }

  @Test
  public void test13() {
    caldat.badluk(19 ) ;
  }

  @Test
  public void test14() {
    caldat.badluk(-2 ) ;
  }

  @Test
  public void test15() {
    caldat.badluk(2 ) ;
  }

  @Test
  public void test16() {
    caldat.badluk(-20 ) ;
  }

  @Test
  public void test17() {
    caldat.badluk(-23 ) ;
  }

  @Test
  public void test18() {
    caldat.badluk(-25 ) ;
  }

  @Test
  public void test19() {
    caldat.badluk(25 ) ;
  }

  @Test
  public void test20() {
    caldat.badluk(-26 ) ;
  }

  @Test
  public void test21() {
    caldat.badluk(26 ) ;
  }

  @Test
  public void test22() {
    caldat.badluk(-266 ) ;
  }

  @Test
  public void test23() {
    caldat.badluk(-27 ) ;
  }

  @Test
  public void test24() {
    caldat.badluk(273 ) ;
  }

  @Test
  public void test25() {
    caldat.badluk(-28 ) ;
  }

  @Test
  public void test26() {
    caldat.badluk(-3 ) ;
  }

  @Test
  public void test27() {
    caldat.badluk(3 ) ;
  }

  @Test
  public void test28() {
    caldat.badluk(-4 ) ;
  }

  @Test
  public void test29() {
    caldat.badluk(4 ) ;
  }

  @Test
  public void test30() {
    caldat.badluk(-40 ) ;
  }

  @Test
  public void test31() {
    caldat.badluk(434 ) ;
  }

  @Test
  public void test32() {
    caldat.badluk(-460 ) ;
  }

  @Test
  public void test33() {
    caldat.badluk(-5 ) ;
  }

  @Test
  public void test34() {
    caldat.badluk(5 ) ;
  }

  @Test
  public void test35() {
    caldat.badluk(-501 ) ;
  }

  @Test
  public void test36() {
    caldat.badluk(-514 ) ;
  }

  @Test
  public void test37() {
    caldat.badluk(-598 ) ;
  }

  @Test
  public void test38() {
    caldat.badluk(6 ) ;
  }

  @Test
  public void test39() {
    caldat.badluk(7 ) ;
  }

  @Test
  public void test40() {
    caldat.badluk(-720 ) ;
  }

  @Test
  public void test41() {
    caldat.badluk(-721 ) ;
  }

  @Test
  public void test42() {
    caldat.badluk(721 ) ;
  }

  @Test
  public void test43() {
    caldat.badluk(8 ) ;
  }

  @Test
  public void test44() {
    caldat.badluk(-844 ) ;
  }

  @Test
  public void test45() {
    caldat.badluk(9 ) ;
  }

  @Test
  public void test46() {
    caldat.badluk(-952 ) ;
  }

  @Test
  public void test47() {
    caldat.badluk(954 ) ;
  }

  @Test
  public void test48() {
    caldat.badluk(-996 ) ;
  }
}
