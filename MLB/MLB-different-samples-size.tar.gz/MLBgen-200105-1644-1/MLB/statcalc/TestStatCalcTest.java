import org.junit.Test;

public class TestStatCalcTest {

  @Test
  public void test0() {
    concolic.TestStatCalc.run(227 ) ;
  }

  @Test
  public void test1() {
    concolic.TestStatCalc.run(-286 ) ;
  }

  @Test
  public void test2() {
    concolic.TestStatCalc.run(3 ) ;
  }

  @Test
  public void test3() {
    concolic.TestStatCalc.run(452 ) ;
  }

  @Test
  public void test4() {
    concolic.TestStatCalc.run(-534 ) ;
  }

  @Test
  public void test5() {
    concolic.TestStatCalc.run(-568 ) ;
  }

  @Test
  public void test6() {
    concolic.TestStatCalc.run(-595 ) ;
  }

  @Test
  public void test7() {
    concolic.TestStatCalc.run(637 ) ;
  }

  @Test
  public void test8() {
    concolic.TestStatCalc.run(638 ) ;
  }

  @Test
  public void test9() {
    concolic.TestStatCalc.run(-67 ) ;
  }

  @Test
  public void test10() {
    concolic.TestStatCalc.run(-69 ) ;
  }

  @Test
  public void test11() {
    concolic.TestStatCalc.run(754 ) ;
  }

  @Test
  public void test12() {
    concolic.TestStatCalc.run(787 ) ;
  }

  @Test
  public void test13() {
    concolic.TestStatCalc.run(865 ) ;
  }

  @Test
  public void test14() {
    concolic.TestStatCalc.run(-983 ) ;
  }

  @Test
  public void test15() {
    concolic.TestStatCalc.run(-999 ) ;
  }
}
