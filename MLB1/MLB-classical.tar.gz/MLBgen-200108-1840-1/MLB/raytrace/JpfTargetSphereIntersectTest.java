import org.junit.Test;

public class JpfTargetSphereIntersectTest {

  @Test
  public void test0() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.033806313f,0.7093006f,-0.68988425f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.6766997f,-0.27623048f,-0.6151697f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.79153943f,0.59480447f,-0.14026064f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.80359584f,0.48089388f,-0.35067764f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1.4241814E-9f,5.530338E-10f,2.77071E-11f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2.4504997E-4f,-2.9037334E-4f,1.4814445E-4f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,47.6987f,-58.23219f,-93.412796f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,6.823394E-5f,1.5693122E-5f,-1.5083195E-4f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,81.211205f,-18.910118f,-26.309084f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,94.05021f,67.08509f,-94.93804f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,100.0f,-100.0f,-99.999016f,-100.0f,54.60345f,100.0f,-0.9073997f,0.22158258f,-0.3571092f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,99.99993f,-94.609604f,-65.984566f,-60.634586f,-1.3731745f,0.21785821f,-0.08878434f,-0.9719337f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-51.92802f,90.57583f,100.0f,-100.0f,81.42308f,100.0f,-0.52523524f,0.49766204f,0.20694008f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-7.405046f,-100.0f,-99.99708f,-12.131474f,18.098274f,-100.0f,-0.95651877f,-0.284621f,0.063739315f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-99.99978f,100.0f,-3.7980036E-4f,99.99969f,-100.0f,100.0f,-0.87337834f,-0.48690242f,-0.011704832f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-10.631248f,-93.78674f,0.33636275f,100.0f,-100.0f,-97.44493f,-49.277775f,0.9662538f,0.2471264f,-0.07267785f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-11.391103f,-89.437744f,-90.247894f,88.42488f,-25.309776f,-10.884646f,-59.505974f,62.24897f,15.654048f,67.68599f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,16.351046f,27.448975f,-39.40178f,76.4297f,-34.87664f,75.75658f,-9.676382f,1.220447f,0.690569f,-0.24465215f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-18.663013f,25.609629f,-100.0f,6.473953f,-37.52394f,-60.951904f,-24.750845f,-11.592022f,-0.9392958f,-5.077784f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-21.947641f,-100.0f,99.99764f,96.95086f,-96.81209f,-37.420723f,87.99477f,0.85736823f,-0.50930065f,0.07438165f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,22.13966f,46.349148f,-23.390057f,69.26973f,74.3968f,17.09967f,11.388424f,0.18613437f,-0.19238281f,-0.96350217f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,23.405447f,2.249008f,-99.37966f,52.74362f,38.69667f,-81.74193f,-91.53703f,-0.34448302f,-0.894121f,-0.2861453f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-26.20212f,6.9557495f,-77.69606f,47.906044f,-1.6608481f,-30.957289f,-93.67213f,-86.06431f,131.10574f,52.663666f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-26.64899f,50.69362f,100.0f,100.0f,-51.728497f,-5.0738425f,100.0f,-0.36409506f,0.010490256f,-0.62881356f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,27.285011f,-82.567986f,-82.01175f,45.971455f,20.271688f,-99.99794f,-40.05481f,101.07397f,-12.360744f,1.082942f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,29.040632f,74.19551f,66.43418f,-5.9349732f,89.624855f,-38.970463f,24.27761f,0.92148143f,-0.16260071f,-0.002102008f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-29.448296f,7.330528f,-58.4339f,97.16872f,53.54621f,36.128853f,-99.95893f,-6.026663f,0.035617985f,-0.9982707f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,30.953722f,-51.71432f,-93.956726f,97.39252f,55.222004f,37.142693f,-62.321552f,-21.020533f,-74.75484f,9.7738085f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,32.719494f,81.07934f,-25.91325f,-68.17332f,58.561066f,17.58088f,-4.3756027f,-0.17437561f,-0.14590739f,-0.1259002f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-35.85024f,22.79728f,-1.3445101f,57.4099f,-63.43766f,72.852325f,22.363243f,95.45584f,-79.582f,-83.596405f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,36.21316f,98.951385f,27.687443f,79.6917f,100.0f,63.057487f,-3.7637734f,-0.8830848f,0.44191977f,0.15769657f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-36.38736f,-93.994934f,63.228424f,55.90748f,-1.4119414f,-40.925262f,58.097813f,-5.568491f,-8.931018f,-4.6985674f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,36.97214f,-87.60646f,52.44244f,21.04834f,98.192085f,57.277336f,10.6592655f,-14.279451f,56.27731f,-40.884075f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,40.402294f,13.215356f,-65.80724f,35.89258f,-8.85584f,21.644388f,-56.910645f,16.365788f,-0.17097026f,11.066804f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,41.97694f,3.3339894f,-81.17534f,45.277615f,-47.86973f,-71.70022f,-36.453342f,-30.09562f,-19.345356f,31.33229f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,42.75947f,43.266113f,-66.311424f,97.76602f,-44.17089f,11.605542f,-97.917046f,62.065685f,23.62697f,21.232002f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,42.81104f,42.743965f,47.187115f,62.22433f,8.754515f,-90.79864f,-56.20072f,71.51127f,72.548355f,-49.182945f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-4.3918977f,44.85018f,84.91449f,100.0f,18.318167f,37.462814f,-100.0f,0.13920979f,-0.94812447f,0.28579816f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-44.178535f,37.676807f,-36.492546f,81.434685f,-10.481997f,-35.703613f,-47.050236f,-28.323257f,61.717247f,8.781933f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-4.689136f,-70.1668f,13.696439f,65.183815f,0.2968781f,-76.39068f,78.39059f,-23.619226f,82.258156f,-100.0f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-52.256f,74.88447f,-57.209072f,18.304739f,-64.42331f,73.002335f,-70.75446f,19.31241f,15.691212f,-19.463554f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,53.01857f,-37.998676f,-90.023865f,-98.79488f,-4.703093f,47.039288f,36.376133f,-3.2163599f,-0.96908194f,9.800442f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-54.7531f,7.3946767f,91.0725f,78.21918f,-89.00884f,31.903568f,91.06722f,17.787062f,-34.72136f,35.51684f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-54.827385f,40.195564f,-50.43872f,55.54746f,-59.41784f,-14.938836f,-45.474266f,13.430126f,33.55675f,-14.877106f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-55.89712f,-26.515694f,-23.311003f,71.27165f,-42.193104f,-54.604626f,-43.192627f,0.17179374f,-0.21127588f,0.024961386f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-58.3414f,29.764889f,-21.74813f,54.416668f,-96.453766f,32.67313f,16.98381f,0.48065114f,0.4728127f,-0.57644284f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,59.24476f,-16.101088f,1.5795676f,63.80085f,73.20833f,9.89551f,-54.986713f,-0.30855948f,-0.6428724f,0.5547608f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,59.34183f,-58.07223f,1.316794f,90.039566f,58.666077f,67.37716f,9.5062475f,-89.69058f,-96.034325f,24.39017f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-62.46828f,-50.199997f,60.241398f,84.245964f,1.2066735f,-53.3121f,-1.2597393f,10.053075f,-48.85468f,67.255035f ) ;
  }

  @Test
  public void test49() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-63.374847f,-54.605114f,-68.42674f,96.51319f,27.458311f,-29.770191f,-36.16462f,-75.63624f,-14.507584f,-7.3083453f ) ;
  }

  @Test
  public void test50() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-6.485064f,100.0f,-99.13549f,11.763133f,-17.924347f,100.0f,-100.0f,-0.50375986f,0.86258054f,-0.046698447f ) ;
  }

  @Test
  public void test51() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-67.53974f,-36.609962f,-42.130833f,-85.17991f,-60.779755f,48.372955f,-73.94916f,-15.356956f,92.75508f,-8.164502f ) ;
  }

  @Test
  public void test52() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,68.36989f,-30.901203f,54.04465f,69.224945f,36.474915f,22.405088f,84.59367f,63.323536f,-108.99626f,-63.391945f ) ;
  }

  @Test
  public void test53() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-69.7623f,4.2653136f,-100.0f,99.98262f,-49.845272f,99.99988f,-9.3585005f,-0.07402588f,-0.99667263f,-0.03411494f ) ;
  }

  @Test
  public void test54() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-72.12937f,29.032185f,36.161224f,100.0f,34.99177f,78.61709f,66.181465f,-0.10555272f,-0.38039148f,-0.40509292f ) ;
  }

  @Test
  public void test55() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,7.312455f,-8.917102f,-5.575705f,41.860405f,26.346647f,-44.126087f,-49.19467f,-83.65149f,81.74466f,10.182462f ) ;
  }

  @Test
  public void test56() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,74.88363f,15.659646f,13.159509f,68.81663f,20.397758f,46.912334f,-14.95255f,17.43191f,29.414991f,59.364513f ) ;
  }

  @Test
  public void test57() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-75.858406f,-82.625244f,-55.02724f,31.76967f,-44.95962f,-83.081215f,-62.40079f,-91.35907f,11.755608f,1.302904f ) ;
  }

  @Test
  public void test58() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,78.30313f,72.44657f,-16.06364f,32.99463f,8.518897f,38.517918f,-62.22475f,0.3246358f,-0.8476847f,-0.41175345f ) ;
  }

  @Test
  public void test59() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-80.71418f,-1.7743703f,83.02022f,92.25718f,-52.39592f,-53.10373f,11.782861f,-0.93679386f,0.16834483f,-0.012541069f ) ;
  }

  @Test
  public void test60() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-8.320287f,-29.018633f,-43.83386f,94.77835f,51.943474f,-12.812904f,27.500494f,90.48521f,-71.27515f,-60.292442f ) ;
  }

  @Test
  public void test61() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,84.73776f,-100.0f,-42.42562f,-99.99999f,95.65151f,-72.35565f,69.17117f,-0.034447365f,0.114894256f,0.99278027f ) ;
  }

  @Test
  public void test62() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,88.192795f,-16.532682f,-68.11351f,29.400846f,19.234865f,-59.975113f,83.20322f,-20.326284f,-17.632065f,54.792908f ) ;
  }

  @Test
  public void test63() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,94.29736f,1.8648254f,-100.0f,-99.99994f,20.884914f,-80.87068f,-11.893716f,-0.100644276f,-0.9871446f,0.12406828f ) ;
  }

  @Test
  public void test64() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,94.721245f,80.18916f,14.720509f,-6.290212f,-50.409733f,-81.31654f,22.445963f,-0.08599282f,0.019955304f,-0.6578521f ) ;
  }

  @Test
  public void test65() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-9.733966f,83.55661f,18.660578f,61.720486f,-73.74175f,55.197475f,42.25787f,69.53536f,96.01803f,-97.54548f ) ;
  }

  @Test
  public void test66() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,97.86038f,88.98478f,-13.069184f,30.923128f,86.232605f,60.695526f,-7.9172244f,100.0f,-28.577166f,19.370485f ) ;
  }

  @Test
  public void test67() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-98.57749f,-64.15253f,79.53559f,-45.960762f,74.23436f,8.447259f,95.121666f,-15.0815325f,64.88412f,32.730568f ) ;
  }

  @Test
  public void test68() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,99.44079f,66.076256f,26.606087f,43.685135f,75.90052f,97.38736f,7.2705708f,0.11783766f,-0.25472143f,0.41536343f ) ;
  }

  @Test
  public void test69() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.930405f,-40.963673f,29.652557f,-92.79289f,73.097916f,9.084214f,-100.0f,0.6685366f,0.296958f,-0.68181723f ) ;
  }

  @Test
  public void test70() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.99823f,-100.0f,-29.87329f,-100.0f,-43.605137f,7.927184f,85.60224f,0.4377421f,-0.008134499f,-0.89906377f ) ;
  }

  @Test
  public void test71() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.99984f,99.75623f,-2.3823764f,-100.0f,-98.59767f,-53.97026f,-100.0f,0.5507901f,-0.12108306f,-0.82581425f ) ;
  }

  @Test
  public void test72() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.999954f,100.0f,-99.99467f,31.20576f,-62.423195f,45.6505f,-92.12713f,-0.09311139f,0.1965972f,0.9760532f ) ;
  }
}
