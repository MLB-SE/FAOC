import org.junit.Test;

public class JpfTargetSurfaceShadeTest {

  @Test
  public void test0() {
    TestDrivers.surfaceShade(0.0f,0f,-327.0f,0f,736.0f,-124.0f,0f,514.0f,0f,0f,0f,0f,0f,-1352.0f,-185.0f,-705.0f,-230.0f,936.0f,919.0f,909,55.697994f,-11.752988f,-100.0f,60.100372f,0f,-47.771828f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.surfaceShade(0.0f,2489.0f,0f,0f,112.0f,0.0f,0f,-38.0f,0f,0f,0f,0f,0f,692.0f,1127.0f,-2092.0f,0f,0f,0f,-727,0.1330584f,0.0077524614f,0.05095028f,4.3942122f,-77.55156f,0f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.surfaceShade(0.0f,-81.0f,0f,-45.0f,0f,0f,0f,1520.0f,0f,0f,0f,0f,0f,286.0f,922.0f,-2118.0f,-1009.0f,453.0f,678.0f,8,0f,0f,0f,26.424631f,2.7434842E-4f,0f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.029160323f,0.0f,0f,-72.493935f,0f,0f,0f,0f,0f,52.468765f,-65.35402f,-0.8385629f,0f,0f,0f,-1010,37.827892f,99.55504f,2.9298713f,0f,0f,0f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,74.09698f,66.3446f,0f,0f,0f,-411,0.15915318f,0.36779377f,-0.891149f,0f,0f,0f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,25.322794f,3.9720058f,-7.437331f,0f,0f,0f,-630,2.0269918f,23.32452f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-87.23978f,50.28364f,-67.498146f,0f,0f,0f,3085,0.60235554f,0.6031184f,0.52289194f,0f,0f,0f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-47.26053f,-18.02282f,0f,0f,0f,-727,0.14991955f,0.40419623f,0.9023023f,0f,0f,0f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-17.575619f,48.506256f,-41.5983f,0f,0f,0f,-752,50.519768f,-51.119865f,98.20604f,0f,0f,0f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,86.317856f,-40.388565f,4.181128f,0f,0f,0f,1428,-0.28584608f,0.028303226f,-0.0076401336f,0f,0f,0f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,41.37593f,0f,0f,0f,0f,0f,-28.987858f,43.817337f,56.16162f,0f,0f,0f,-417,-65.784325f,-56.469803f,-4.0564957f,0f,0f,0f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,-46.330288f,0f,0f,0f,0f,0f,-21.098927f,100.0f,-56.855648f,0f,0f,0f,-363,0.085713014f,0.14983538f,0.6825261f,0f,0f,0f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,54.56111f,0f,0f,0f,0f,0f,-47.27796f,100.0f,100.0f,0f,0f,0f,582,-0.3928485f,-0.3835847f,-0.13636161f,0f,0f,0f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,-81.65359f,0f,0f,0f,0f,0f,-21.053385f,-82.42442f,59.78556f,0f,0f,0f,-1096,26.158632f,-23.08444f,-29.475346f,0f,0f,0f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-0.2273011f,0f,-16.024683f,0f,0f,0f,0f,0f,42.809982f,-77.22217f,-6.433642f,0f,0f,0f,558,46.52117f,61.62151f,-70.29464f,0f,0f,0f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,-18.640892f,-61.527103f,100.0f,0f,0f,0f,-869,0.5797875f,0.22979315f,-0.17447536f,0f,0f,0f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,68.21771f,1.7073275f,-20.550436f,0f,0f,0f,922,-17.250145f,-11.162999f,33.071316f,0f,0f,0f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,-88.78725f,-100.0f,-100.0f,0f,0f,0f,-744,-0.32703766f,-0.3078359f,0.89346707f,0f,0f,0f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,62.34675f,-49.658306f,560.0f,813.0f,-107.0f,-272,31.745522f,28.961172f,-27.566732f,0f,0f,0f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,68.12978f,-14.918833f,-43.650173f,0f,0f,0f,-785,-0.04596926f,0.79169035f,-0.31680262f,0f,0f,0f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,70.26488f,-80.444954f,-45.574512f,0f,0f,0f,1223,-0.1404118f,-0.066358715f,0.98786694f,0f,0f,0f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,-95.56483f,100.0f,100.0f,0f,0f,0f,-3113,0.32513827f,-0.8421294f,-0.43023616f,0f,0f,0f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-1.0206782E-37f,0f,88.05257f,0f,0f,0f,0f,0f,-4.951053f,26.47832f,-88.40107f,0f,0f,0f,-848,0.07013539f,-0.27347f,0.9593202f,0f,0f,0f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,11.649475f,0f,0f,0f,0f,0f,0f,0f,100.0f,100.0f,100.0f,0f,0f,0f,-344,-100.0f,-100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,13.3723545f,0f,0f,0f,0f,0f,0f,0f,-11.4175005f,65.85445f,-4.6271176f,-324.0f,-472.0f,34.0f,123,-7.368482f,-29.919518f,-52.843723f,0f,0f,0f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-15.114789f,0f,0f,0f,0f,0f,0f,0f,-87.83467f,-23.666718f,30.511135f,0f,0f,0f,-671,60.583652f,-72.14637f,-21.400896f,0f,0f,0f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,180.0f,0f,-819.0f,0f,0f,0f,0f,0f,793.0f,332.0f,-255.0f,-295.0f,741.0f,751.0f,-216,-64.36469f,-49.871964f,-20.083843f,0f,0f,0f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,22.044956f,0f,0f,0f,0f,0f,0f,0f,-1.2501404f,-47.798264f,20.913645f,-12.0f,12.0f,442.0f,318,-16.668167f,35.921803f,-33.38555f,0f,0f,0f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,2548.0f,0f,1830.0f,0f,0f,0f,0f,0f,720.0f,-3457.0f,616.0f,79.0f,1227.0f,221.0f,404,-0.36520058f,0.38334668f,0.8483359f,0f,0f,0f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,25.87702f,0f,0f,0f,0f,0f,0f,0f,-50.769615f,-7.746672f,8.366488f,-57.0f,96.0f,-257.0f,1546,40.99628f,-30.831549f,-22.236797f,0f,0f,0f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-26.877625f,0f,-100.0f,0f,0f,0f,0f,0f,-79.99506f,15.015507f,-74.015625f,0f,0f,0f,826,0.4514804f,-0.8417304f,-0.29606643f,0f,0f,0f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,30.299997f,0f,0f,0f,0f,0f,0f,0f,-36.256775f,-37.71821f,13.691585f,-70.0f,1527.0f,-1526.0f,-1342,0.5810627f,0.21304801f,0.71747625f,0f,0f,0f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,31.380213f,0f,0f,0f,0f,0f,0f,0f,-55.659164f,-69.2696f,15.605104f,399.0f,-228.0f,364.0f,1499,0.09300669f,-0.108748145f,-0.15129147f,0f,0f,0f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,37.664207f,0f,0f,0f,0f,0f,0f,0f,-39.578773f,-4.2542377f,63.61175f,-752.0f,618.0f,-497.0f,177,-23.278687f,-38.99827f,-17.095299f,0f,0f,0f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,50.545433f,0f,0f,0f,0f,0f,0f,0f,33.38195f,-100.0f,-9.903024f,-739.0f,736.0f,470.0f,-960,0.0017518696f,0.14982066f,-0.98871166f,0f,0f,0f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,513.0f,0f,1753.0f,0f,0f,0f,0f,0f,-683.0f,-532.0f,-438.0f,-304.0f,-829.0f,-405.0f,-1019,47.055466f,95.20573f,-59.569122f,0f,0f,0f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-51.776894f,0f,-49.733498f,0f,0f,0f,0f,0f,3.397072f,-16.846312f,-39.810986f,0f,0f,0f,498,0.042228535f,-0.035739735f,0.23556289f,0f,0f,0f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,528.0f,0f,1.0f,0f,0f,0f,0f,0f,-800.0f,878.0f,303.0f,-119.0f,235.0f,1913.0f,139,100.0f,48.76188f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-53.01457f,0f,0.0f,0f,0f,0f,0f,0f,96.88699f,67.23449f,39.85763f,0f,0f,0f,-249,-0.4336558f,0.469665f,-0.74922985f,0f,0f,0f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,55.89131f,0f,0f,0f,0f,0f,0f,0f,-9.600959f,19.695553f,73.078285f,1474.0f,-708.0f,449.0f,-812,-25.679085f,-31.885431f,-2.083291f,0f,0f,0f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-56.246002f,0f,0.0f,0f,0f,0f,0f,0f,-29.507002f,63.159115f,-84.9572f,0f,0f,0f,-1033,0.11778755f,-0.93341357f,-0.33891767f,0f,0f,0f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,56.852097f,0f,0f,0f,0f,0f,0f,0f,16.63222f,-72.66225f,-49.72213f,-936.0f,106.0f,-468.0f,-785,-82.05203f,100.0f,-99.99988f,0f,0f,0f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,59.96122f,0f,0f,0f,0f,0f,0f,0f,54.227524f,46.01012f,-3.8519886f,730.0f,1389.0f,831.0f,-461,-0.16933621f,-0.6617739f,0.14747958f,0f,0f,0f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,616.0f,0f,-1.0f,0f,0f,0f,0f,0f,951.0f,-114.0f,-1073.0f,-208.0f,-1019.0f,852.0f,539,-27.328787f,-2.4599907f,43.70195f,0f,0f,0f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,63.498337f,0f,0f,0f,0f,0f,0f,0f,-28.253284f,-52.10388f,58.10989f,831.0f,-183.0f,240.0f,-384,95.319626f,22.923046f,-19.609531f,0f,0f,0f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-641.0f,0f,1159.0f,0f,0f,0f,0f,0f,483.0f,2351.0f,-620.0f,2224.0f,-37.0f,-950.0f,728,0.73823816f,-0.24973564f,0.3088322f,0f,0f,0f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,68.30946f,0f,0f,0f,0f,0f,0f,0f,4.033383f,10.79772f,-79.19456f,-233.0f,-468.0f,-412.0f,561,22.629585f,13.210591f,55.458244f,0f,0f,0f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,76.873146f,0f,0f,0f,0f,0f,0f,0f,-55.052437f,100.0f,-34.248596f,885.0f,342.0f,-424.0f,-526,99.999374f,-99.99969f,99.98662f,0f,0f,0f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-84.26334f,0f,49.69371f,0f,0f,0f,0f,0f,-15.147321f,76.277084f,44.9855f,0f,0f,0f,808,-65.34891f,-100.0f,26.746868f,0f,0f,0f ) ;
  }

  @Test
  public void test49() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,86.28214f,0f,0f,0f,0f,0f,0f,0f,100.0f,70.44889f,-89.91308f,642.0f,356.0f,-500.0f,227,-99.80837f,-32.571632f,-51.951973f,0f,0f,0f ) ;
  }

  @Test
  public void test50() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-88.14643f,0f,0f,0f,0f,0f,0f,0f,100.0f,-7.2340975f,-98.62649f,0f,0f,0f,2633,-0.27228877f,0.7935724f,0.38452035f,0f,0f,0f ) ;
  }

  @Test
  public void test51() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-9.333031f,0f,19.599724f,0f,0f,0f,0f,0f,-30.922699f,19.321001f,100.0f,0f,0f,0f,697,-0.73829657f,0.2830405f,-0.6122142f,0f,0f,0f ) ;
  }

  @Test
  public void test52() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-970.0f,0f,1766.0f,0f,0f,0f,0f,0f,396.0f,128.0f,-16.0f,-524.0f,-950.0f,-762.0f,158,-29.467028f,90.43643f,22.272146f,0f,0f,0f ) ;
  }

  @Test
  public void test53() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,97.81503f,0f,0f,0f,0f,0f,0f,0f,-10.408299f,57.98622f,-2.6314704f,416.0f,747.0f,-190.0f,-696,20.44466f,-73.87746f,55.73509f,0f,0f,0f ) ;
  }

  @Test
  public void test54() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,99.71996f,0f,0f,0f,0f,0f,0f,0f,-25.63107f,53.160954f,-100.0f,21.0f,977.0f,514.0f,-589,100.0f,-1.8824263f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test55() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-99.84197f,0f,28.308279f,0f,0f,0f,0f,0f,37.34108f,2.6567774f,24.517803f,0f,0f,0f,-985,-0.5815296f,0.19317624f,0.6677995f,0f,0f,0f ) ;
  }

  @Test
  public void test56() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-9.988487f,0f,0.0f,0f,0f,0f,0f,0f,-18.610626f,57.896336f,46.19626f,0f,0f,0f,-557,52.11579f,-76.42519f,-58.520954f,0f,0f,0f ) ;
  }

  @Test
  public void test57() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,99.999916f,0f,0f,0f,0f,0f,0f,0f,-94.01363f,-100.0f,100.0f,1237.0f,-1410.0f,662.0f,-870,-4.7379982E-4f,0.111016676f,-0.9938184f,0f,0f,0f ) ;
  }

  @Test
  public void test58() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test59() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,53.79013f,-100.0f,0f,0f,0f,558,-0.5766864f,0.007790161f,-0.81692845f,0f,0f,0f ) ;
  }

  @Test
  public void test60() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,6.454004f,100.0f,0f,0f,0f,-878,93.601036f,96.67458f,-99.84042f,0f,0f,0f ) ;
  }

  @Test
  public void test61() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,35.58762f,58.142357f,-10.725116f,0f,0f,0f,261,-0.11364084f,0.12439643f,0.009406117f,0f,0f,0f ) ;
  }

  @Test
  public void test62() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,79.548965f,-23.76783f,17.94198f,0f,0f,0f,-428,10.918731f,-54.05097f,61.204166f,0f,0f,0f ) ;
  }

  @Test
  public void test63() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-0.5174372f,0f,0f,0f,0f,0f,-15.993597f,-0.2192451f,-77.55342f,0f,0f,0f,-640,-0.0725267f,-0.72327024f,-0.48730475f,0f,0f,0f ) ;
  }

  @Test
  public void test64() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test65() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.0039022432f,-0.0037342373f,-2.2261789E-4f,0f,0f,0f ) ;
  }

  @Test
  public void test66() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test67() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test68() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1338,-8.6572703E-7f,-1.0753968E-6f,-7.0071667E-7f,0f,0f,0f ) ;
  }

  @Test
  public void test69() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,7.251008E-4f,3.135554E-4f,-4.9726415E-4f,0f,0f,0f ) ;
  }

  @Test
  public void test70() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test71() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,-36.742004f,-8.188007f,99.42934f,0f,0f,0f ) ;
  }

  @Test
  public void test72() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-273,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test73() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-523,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test74() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-617,-1.0912491E-5f,-1.17198455E-4f,-6.909006E-5f,0f,0f,0f ) ;
  }

  @Test
  public void test75() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-625,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test76() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,637,0.39749527f,0.8056893f,0.2630061f,0f,0f,0f ) ;
  }

  @Test
  public void test77() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,638,-48.338146f,1.9841708f,35.739674f,0f,0f,0f ) ;
  }

  @Test
  public void test78() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-677,-0.62508035f,0.24508929f,0.4504982f,0f,0f,0f ) ;
  }

  @Test
  public void test79() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,754,0.0019911935f,0.001163846f,0.004570258f,0f,0f,0f ) ;
  }

  @Test
  public void test80() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-792,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test81() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-848,-0.010315579f,-0.003778248f,-0.9999397f,0f,0f,0f ) ;
  }

  @Test
  public void test82() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,890,-0.37378487f,0.864509f,0.33601946f,0f,0f,0f ) ;
  }

  @Test
  public void test83() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-913,-17.370428f,9.37902f,-1.0744902f,0f,0f,0f ) ;
  }

  @Test
  public void test84() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-924,45.008224f,-14.222307f,40.028873f,0f,0f,0f ) ;
  }

  @Test
  public void test85() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,15.467832f,-47.20174f,67.597786f,0f,0f,0f,836,-0.662061f,-0.6209293f,-0.28208464f,0f,0f,0f ) ;
  }

  @Test
  public void test86() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-2.713806f,-55.22038f,-1.9717163f,0f,0f,0f,670,-79.86931f,-42.8994f,-69.20175f,0f,0f,0f ) ;
  }

  @Test
  public void test87() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-46.062275f,43.41183f,-7.250683f,0f,0f,0f,-459,0.10612729f,-0.053918608f,-0.99703294f,0f,0f,0f ) ;
  }

  @Test
  public void test88() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-58.604187f,35.594856f,-16.541636f,0f,0f,0f,-1718,-0.06833426f,-1.3496382f,-2.6621008f,0f,0f,0f ) ;
  }

  @Test
  public void test89() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-60.038017f,79.59476f,65.97939f,0f,0f,0f,1251,-0.25661647f,0.17093424f,-0.43971628f,0f,0f,0f ) ;
  }

  @Test
  public void test90() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-68.1645f,48.93529f,59.03055f,0f,0f,0f,450,64.052666f,44.774887f,36.846104f,0f,0f,0f ) ;
  }

  @Test
  public void test91() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,83.6664f,66.866646f,82.20374f,0f,0f,0f,868,-40.52454f,50.32183f,-98.71142f,0f,0f,0f ) ;
  }

  @Test
  public void test92() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-8.652363f,-40.66454f,-50.22009f,0f,0f,0f,-1381,-0.2589471f,0.2790356f,0.92470837f,0f,0f,0f ) ;
  }

  @Test
  public void test93() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,99.75385f,26.035973f,-97.96264f,0f,0f,0f,163,-0.13286711f,0.98844475f,-0.072960764f,0f,0f,0f ) ;
  }

  @Test
  public void test94() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.04854f,50.834694f,-54.29414f,0f,0f,0f,0f,0f,0f,2,100.0f,51.213f,-54.121174f,0f,0f,0f ) ;
  }

  @Test
  public void test95() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,100.0f,100.0f,0f,0f,0f,0f,0f,0f,2,100.0f,100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test96() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-100.0f,25.026772f,0f,0f,0f,0f,0f,0f,3,100.0f,-100.0f,25.022358f,0f,0f,0f ) ;
  }

  @Test
  public void test97() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,100.0f,45.157867f,0f,0f,0f,0f,0f,0f,3,100.0f,100.0f,45.165073f,0f,0f,0f ) ;
  }

  @Test
  public void test98() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-15.995336f,3.9545052f,0f,0f,0f,0f,0f,0f,3,100.0f,-16.451773f,3.0647492f,0f,0f,0f ) ;
  }

  @Test
  public void test99() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,17.476114f,-37.85023f,0f,0f,0f,0f,0f,0f,2,-100.0f,17.806925f,-37.222214f,0f,0f,0f ) ;
  }

  @Test
  public void test100() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,37.172325f,95.05826f,0f,0f,0f,0f,0f,0f,2,7.141368f,-37.136105f,98.81765f,0f,0f,0f ) ;
  }

  @Test
  public void test101() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-71.58017f,64.48519f,0f,0f,0f,0f,0f,0f,4,100.0f,-71.58039f,64.48642f,0f,0f,0f ) ;
  }

  @Test
  public void test102() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,11.681897f,100.0f,62.94193f,5.0967207f,-38.977444f,34.239796f,0f,0f,0f,2,37.292747f,97.461426f,56.23983f,0f,0f,0f ) ;
  }

  @Test
  public void test103() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-13.903846f,26.965677f,29.338037f,0f,0f,0f,0f,0f,0f,2,-14.2929125f,27.083357f,28.643257f,0f,0f,0f ) ;
  }

  @Test
  public void test104() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,19.791042f,-100.0f,1.7548743f,-100.0f,31.09325f,100.0f,0f,0f,0f,4,19.89894f,-100.0f,2.732798f,0f,0f,0f ) ;
  }

  @Test
  public void test105() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-26.740881f,70.524734f,-29.737873f,0f,0f,0f,0f,0f,0f,3,44.27088f,32.80735f,27.882578f,0f,0f,0f ) ;
  }

  @Test
  public void test106() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,27.959448f,0.87804866f,-7.717004f,0f,0f,0f,0f,0f,0f,3,28.00811f,0.89123285f,-7.7206326f,0f,0f,0f ) ;
  }

  @Test
  public void test107() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,29.00436f,-99.342094f,-100.0f,-34.105415f,-10.41507f,-72.690384f,0f,0f,0f,-1,28.118118f,-99.50044f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test108() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,33.56004f,-50.57553f,36.502262f,0f,0f,0f,0f,0f,0f,2,33.408306f,-50.99006f,36.240166f,0f,0f,0f ) ;
  }

  @Test
  public void test109() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,34.33295f,83.28541f,-44.31878f,0f,0f,0f,0f,0f,0f,2,35.99015f,42.93112f,34.37297f,0f,0f,0f ) ;
  }

  @Test
  public void test110() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-40.592228f,-100.0f,40.701492f,32.503063f,-16.041128f,100.0f,0f,0f,0f,-1,-40.58926f,-100.0f,40.602055f,0f,0f,0f ) ;
  }

  @Test
  public void test111() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,41.18421f,100.0f,-99.99327f,0f,0f,0f,0f,0f,0f,2,41.14101f,100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test112() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,45.727146f,92.92005f,61.603516f,0f,0f,0f,0f,0f,0f,2,45.97325f,92.39893f,61.042732f,0f,0f,0f ) ;
  }

  @Test
  public void test113() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,56.568043f,-19.220734f,100.0f,81.13847f,100.0f,100.0f,0f,0f,0f,4,56.632904f,-19.475002f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test114() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,60.921986f,100.0f,14.534647f,58.31499f,-52.95368f,-23.27293f,0f,0f,0f,10,27.33778f,65.197914f,9.569026f,0f,0f,0f ) ;
  }

  @Test
  public void test115() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,62.73017f,55.06278f,100.0f,0f,0f,0f,0f,0f,0f,2,62.73017f,55.06278f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test116() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,64.761665f,15.665252f,1.2761987f,0f,0f,0f,0f,0f,0f,2,64.742165f,15.446298f,1.083615f,0f,0f,0f ) ;
  }

  @Test
  public void test117() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-74.72762f,-13.65025f,42.74975f,0f,0f,0f,0f,0f,0f,2,-74.89445f,-14.341411f,43.286995f,0f,0f,0f ) ;
  }

  @Test
  public void test118() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,7.8109937f,14.082655f,-36.314774f,0f,0f,0f,0f,0f,0f,4,8.410968f,14.727998f,-36.641365f,0f,0f,0f ) ;
  }

  @Test
  public void test119() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,8.140779f,-100.0f,-67.79338f,0f,0f,0f,0f,0f,0f,2,-91.394165f,-89.52473f,-9.6790695f,0f,0f,0f ) ;
  }

  @Test
  public void test120() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-82.83545f,-0.65123177f,63.5987f,0f,0f,0f,0f,0f,0f,2,-45.538544f,217.51181f,74.2936f,0f,0f,0f ) ;
  }

  @Test
  public void test121() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,86.14599f,-85.54977f,10.086794f,0f,0f,0f,0f,0f,0f,2,6.751004f,-9.696247f,-63.75316f,0f,0f,0f ) ;
  }

  @Test
  public void test122() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,86.76411f,44.02005f,-62.18134f,0f,0f,0f,0f,0f,0f,2,86.17998f,43.63267f,-62.22956f,0f,0f,0f ) ;
  }

  @Test
  public void test123() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-96.87187f,-96.244576f,100.0f,0f,0f,0f,0f,0f,0f,2,-96.13585f,-95.96367f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test124() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.23018f,-69.04499f,47.564487f,0f,0f,0f,0f,0f,0f,3,-99.99949f,-69.47729f,48.034885f,0f,0f,0f ) ;
  }

  @Test
  public void test125() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.517235f,89.4399f,-100.0f,0f,0f,0f,0f,0f,0f,3,-100.0f,89.91868f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test126() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-12.206973f,5.871379f,-79.267494f,-293.0f,176.0f,-428.0f,682,-0.8872046f,-0.0010756139f,-0.44813523f,0f,0f,0f ) ;
  }

  @Test
  public void test127() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,14.82357f,46.802235f,-100.0f,1574.0f,2133.0f,732.0f,-431,0.00524976f,-0.23860349f,-0.974112f,0f,0f,0f ) ;
  }

  @Test
  public void test128() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,98.87527f,-37.56746f,75.195496f,0f,0f,0f,875,-0.16921175f,-0.9229153f,0.34582475f,0f,0f,0f ) ;
  }

  @Test
  public void test129() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,99.99985f,-1.6716677f,-100.0f,-647.0f,-489.0f,-575.0f,-555,0.516649f,0.7840048f,-0.34410787f,0f,0f,0f ) ;
  }

  @Test
  public void test130() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,14.653944f,0f,0f,0f,0f,0f,40.091564f,-5.323779f,63.71943f,741.0f,-1882.0f,80.0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test131() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,18.418333f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test132() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,19.375381f,0f,0f,0f,0f,0f,18.944876f,10.523681f,39.16719f,-73.0f,-639.0f,207.0f,-895,1.0611373f,-0.3594095f,-0.004262192f,0f,0f,0f ) ;
  }

  @Test
  public void test133() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,22.204739f,0f,0f,0f,0f,0f,-78.98183f,-26.598421f,-50.993923f,799.0f,-881.0f,-778.0f,782,-25.792194f,-28.962568f,-9.989702f,0f,0f,0f ) ;
  }

  @Test
  public void test134() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,22.45716f,0f,0f,0f,0f,0f,73.19887f,25.623697f,-97.00538f,694.0f,853.0f,749.0f,237,-73.65556f,100.0f,-71.376686f,0f,0f,0f ) ;
  }

  @Test
  public void test135() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,22.543129f,0f,0f,0f,0f,0f,41.019585f,-67.28185f,-48.090633f,643.0f,-347.0f,-12.0f,633,-17.356836f,39.23234f,-78.55855f,0f,0f,0f ) ;
  }

  @Test
  public void test136() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,23.84633f,0f,0f,0f,0f,0f,75.4863f,-49.505596f,-1.9590166f,-198.0f,-290.0f,-301.0f,-514,-0.16735563f,-0.24819209f,-0.18196274f,0f,0f,0f ) ;
  }

  @Test
  public void test137() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,24.106674f,0f,0f,0f,0f,0f,32.827534f,-49.24208f,-88.52647f,1041.0f,971.0f,757.0f,569,-62.647522f,54.23322f,-53.39782f,0f,0f,0f ) ;
  }

  @Test
  public void test138() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,24.418453f,0f,0f,0f,0f,0f,14.754678f,0.11730235f,17.944487f,-401.0f,-655.0f,334.0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test139() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,246.16074f,0f,0f,0f,0f,0f,49.320587f,95.22514f,84.69672f,1986.0f,218.0f,-377.0f,-247,-48.58131f,-60.961624f,96.68397f,0f,0f,0f ) ;
  }

  @Test
  public void test140() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,248.66998f,0f,0f,0f,0f,0f,-71.660095f,-13.697188f,30.431473f,-1543.0f,304.0f,1116.0f,629,-36.40153f,-56.1439f,-110.989395f,0f,0f,0f ) ;
  }

  @Test
  public void test141() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,250.9416f,0f,0f,0f,0f,0f,-89.02714f,5.071174f,-19.691082f,116.0f,-1022.0f,-1541.0f,-1204,-2.9756205f,-90.39485f,-9.834416f,0f,0f,0f ) ;
  }

  @Test
  public void test142() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,251.37231f,0f,0f,0f,0f,0f,-35.23065f,33.644794f,-60.31445f,-32.0f,2296.0f,305.0f,-1063,-66.087425f,-28.63887f,22.662735f,0f,0f,0f ) ;
  }

  @Test
  public void test143() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,252.10922f,0f,0f,0f,0f,0f,-17.707811f,22.205385f,-112.1647f,-503.0f,1159.0f,-733.0f,681,-50.570198f,100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test144() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,252.13258f,0f,0f,0f,0f,0f,-20.411276f,-74.330696f,-85.369354f,870.0f,-802.0f,-979.0f,400,-3.6651874f,-87.48168f,76.99117f,0f,0f,0f ) ;
  }

  @Test
  public void test145() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,252.30496f,0f,0f,0f,0f,0f,100.0f,-100.0f,-100.0f,420.0f,101.0f,185.0f,-835,163.42033f,100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test146() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,252.58066f,0f,0f,0f,0f,0f,-86.12349f,-118.856804f,-74.367065f,-1944.0f,984.0f,108.0f,1707,-0.012903783f,-0.29502058f,-0.42840025f,0f,0f,0f ) ;
  }

  @Test
  public void test147() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,252.70204f,0f,0f,0f,0f,0f,-51.20333f,100.0f,57.01496f,-558.0f,209.0f,543.0f,-510,-120.430534f,42.18164f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test148() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,252.87767f,0f,0f,0f,0f,0f,-65.67063f,-41.894554f,-40.249405f,-128.0f,-898.0f,-848.0f,-507,-53.37019f,-65.355774f,43.576843f,0f,0f,0f ) ;
  }

  @Test
  public void test149() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.43562f,0f,0f,0f,0f,0f,-73.10597f,-68.74166f,-156.12952f,-1343.0f,80.0f,-511.0f,970,0.10751189f,0.0129355965f,-1.1930974f,0f,0f,0f ) ;
  }

  @Test
  public void test150() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.8342f,0f,0f,0f,0f,0f,26.66625f,10.590378f,66.96095f,2223.0f,183.0f,-503.0f,-960,1.7579173f,-0.017713528f,0.18912245f,0f,0f,0f ) ;
  }

  @Test
  public void test151() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.16975f,0f,0f,0f,0f,0f,-98.371376f,-26.674986f,83.98914f,-616.0f,-427.0f,53.0f,386,-71.955284f,-61.705475f,38.838463f,0f,0f,0f ) ;
  }

  @Test
  public void test152() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.28564f,0f,0f,0f,0f,0f,-100.0f,-40.573288f,-100.0f,-283.0f,-523.0f,75.0f,1392,-127.665504f,-100.0f,78.25992f,0f,0f,0f ) ;
  }

  @Test
  public void test153() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.34798f,0f,0f,0f,0f,0f,52.590115f,-58.684017f,100.0f,-31.0f,-85.0f,79.0f,590,93.030624f,100.0f,53.417824f,0f,0f,0f ) ;
  }

  @Test
  public void test154() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.46501f,0f,0f,0f,0f,0f,31.176664f,83.35369f,-88.94909f,390.0f,85.0f,-1250.0f,-803,0.0017256833f,0.297819f,-0.113894545f,0f,0f,0f ) ;
  }

  @Test
  public void test155() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.7229f,0f,0f,0f,0f,0f,6.6039834f,-44.70451f,37.151596f,-229.0f,-1234.0f,-1115.0f,-232,0.58401674f,-0.057276744f,1.7624111f,0f,0f,0f ) ;
  }

  @Test
  public void test156() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.24052f,0f,0f,0f,0f,0f,-58.715572f,48.656746f,-78.13583f,-1838.0f,1070.0f,-299.0f,152,-48.210407f,-47.27919f,6.7862597f,0f,0f,0f ) ;
  }

  @Test
  public void test157() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.29358f,0f,0f,0f,0f,0f,100.0f,-20.820223f,-65.08212f,-301.0f,-985.0f,-1520.0f,-228,98.17708f,100.0f,67.003876f,0f,0f,0f ) ;
  }

  @Test
  public void test158() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.44998f,0f,0f,0f,0f,0f,57.007103f,123.29303f,-46.992477f,79.0f,1210.0f,55.0f,580,0.41513962f,0.21767807f,-0.63939863f,0f,0f,0f ) ;
  }

  @Test
  public void test159() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.74551f,0f,0f,0f,0f,0f,-127.93059f,160.20335f,-20.03021f,1597.0f,1693.0f,-22.0f,-3053,0.35577047f,0.6517831f,-0.148862f,0f,0f,0f ) ;
  }

  @Test
  public void test160() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,25.576405f,0f,0f,0f,0f,0f,39.095264f,-14.836007f,-43.124165f,-684.0f,770.0f,-885.0f,133,0.7744159f,-0.35786384f,0.35892493f,0f,0f,0f ) ;
  }

  @Test
  public void test161() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,256.72415f,0f,0f,0f,0f,0f,-4.1582828f,51.25192f,-38.583694f,2068.0f,615.0f,330.0f,876,-142.02695f,-75.62512f,-85.14173f,0f,0f,0f ) ;
  }

  @Test
  public void test162() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,256.90298f,0f,0f,0f,0f,0f,9.200877f,23.822035f,45.881237f,651.0f,25.0f,776.0f,-918,-38.090107f,57.66497f,-22.301807f,0f,0f,0f ) ;
  }

  @Test
  public void test163() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,259.04343f,0f,0f,0f,0f,0f,-17.33392f,-115.57664f,-50.180664f,258.0f,-226.0f,-908.0f,-42,19.74656f,-61.680466f,50.104366f,0f,0f,0f ) ;
  }

  @Test
  public void test164() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,260.29153f,0f,0f,0f,0f,0f,50.50812f,20.833944f,34.532032f,1825.0f,-418.0f,649.0f,1676,0.73368263f,0.5795195f,1.1744533f,0f,0f,0f ) ;
  }

  @Test
  public void test165() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,263.18323f,0f,0f,0f,0f,0f,-129.52235f,-81.62123f,-83.39481f,-327.0f,-492.0f,-348.0f,490,-83.713196f,-54.048115f,77.5865f,0f,0f,0f ) ;
  }

  @Test
  public void test166() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,269.7919f,0f,0f,0f,0f,0f,49.258556f,40.148357f,-45.96768f,419.0f,511.0f,787.0f,128,-54.490837f,0.6137906f,-74.99826f,0f,0f,0f ) ;
  }

  @Test
  public void test167() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,27.355223f,0f,0f,0f,0f,0f,-32.449738f,56.20526f,38.439903f,277.0f,565.0f,-592.0f,-75,68.2423f,81.967545f,-62.241642f,0f,0f,0f ) ;
  }

  @Test
  public void test168() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,2.7666602f,0f,0f,0f,0f,0f,56.04143f,-39.60024f,26.734406f,-29.0f,-677.0f,-942.0f,-475,-25.160818f,-51.892426f,-24.122627f,0f,0f,0f ) ;
  }

  @Test
  public void test169() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,27.758688f,0f,0f,0f,0f,0f,6.571134f,-36.405212f,59.898315f,0f,0f,0f,839,0.57333636f,0.72587705f,0.37998417f,0f,0f,0f ) ;
  }

  @Test
  public void test170() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,289.84253f,0f,0f,0f,0f,0f,-17.562551f,-39.345375f,96.96964f,411.0f,-617.0f,961.0f,-1723,0.3988628f,0.43532464f,0.779715f,0f,0f,0f ) ;
  }

  @Test
  public void test171() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,293.16525f,0f,0f,0f,0f,0f,-31.791412f,-47.597675f,82.33162f,528.0f,-957.0f,-63.0f,-459,156.5231f,-117.62005f,-7.519242f,0f,0f,0f ) ;
  }

  @Test
  public void test172() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,29.508898f,0f,0f,0f,0f,0f,69.69854f,-57.85665f,26.875854f,720.0f,967.0f,217.0f,386,30.699821f,12.755213f,-52.156803f,0f,0f,0f ) ;
  }

  @Test
  public void test173() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,303.52176f,0f,0f,0f,0f,0f,-79.5141f,19.015865f,95.54467f,-240.0f,4.0f,616.0f,565,15.764453f,3.9661665f,22.938236f,0f,0f,0f ) ;
  }

  @Test
  public void test174() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-31.013075f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test175() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,33.37509f,0f,0f,0f,0f,0f,9.858707f,-3.647331f,-1.615272f,-249.0f,-530.0f,-323.0f,519,5.7468376f,36.672523f,-47.732166f,0f,0f,0f ) ;
  }

  @Test
  public void test176() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,33.74648f,0f,0f,0f,0f,0f,48.800484f,-136.46805f,-66.43601f,558.0f,171.0f,58.0f,673,50.038956f,-42.735466f,-15.556502f,0f,0f,0f ) ;
  }

  @Test
  public void test177() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,36.18472f,0f,0f,0f,0f,0f,32.92317f,100.0f,-59.716213f,-301.0f,934.0f,864.0f,-1133,0.6115808f,0.034979824f,0.08861316f,0f,0f,0f ) ;
  }

  @Test
  public void test178() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,3.7209053f,0f,0f,0f,0f,0f,13.832224f,-17.605986f,-30.413061f,-513.0f,53.0f,-264.0f,1001,32.97267f,-89.303055f,-15.484447f,0f,0f,0f ) ;
  }

  @Test
  public void test179() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-37.23466f,0f,0f,0f,0f,0f,-40.569324f,-89.24922f,-20.361095f,0f,0f,0f,-1000,9.450069f,-12.787185f,37.221153f,0f,0f,0f ) ;
  }

  @Test
  public void test180() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,41.86855f,0f,0f,0f,0f,0f,-97.32925f,-91.80876f,-43.02564f,0f,0f,0f,898,-0.82874364f,-0.27920225f,-0.2358876f,0f,0f,0f ) ;
  }

  @Test
  public void test181() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,42.847393f,0f,0f,0f,0f,0f,-48.569702f,-10.433597f,61.14834f,-961.0f,248.0f,-721.0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test182() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,45.962944f,0f,0f,0f,0f,0f,4.4276237f,12.296153f,34.08135f,-496.0f,-87.0f,653.0f,-989,96.824295f,85.856995f,10.0562105f,0f,0f,0f ) ;
  }

  @Test
  public void test183() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-46.61537f,0f,0f,0f,0f,0f,14.280716f,-2.3414612f,-48.578484f,0f,0f,0f,-97,-42.648983f,-42.537556f,-35.286293f,0f,0f,0f ) ;
  }

  @Test
  public void test184() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,46.722923f,0f,0f,0f,0f,0f,-35.871284f,5.469071f,32.33326f,930.0f,980.0f,866.0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test185() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,46.731396f,0f,0f,0f,0f,0f,-49.072987f,-28.322512f,14.364047f,0f,0f,0f,-673,33.78432f,-28.23346f,59.75022f,0f,0f,0f ) ;
  }

  @Test
  public void test186() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,47.054653f,0f,0f,0f,0f,0f,14.292023f,-100.0f,-78.7834f,-703.0f,-548.0f,-584.0f,1126,-0.23697345f,-0.81650496f,-0.50907505f,0f,0f,0f ) ;
  }

  @Test
  public void test187() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,47.517292f,0f,0f,0f,0f,0f,-31.9525f,-23.125996f,-42.022808f,-646.0f,169.0f,-823.0f,184,3.9370213f,3.513534f,-7.340145f,0f,0f,0f ) ;
  }

  @Test
  public void test188() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,49.869774f,0f,0f,0f,0f,0f,-1.5406048f,-145.76938f,13.20575f,1094.0f,-421.0f,196.0f,-1,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test189() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,52.549366f,0f,0f,0f,0f,0f,57.70315f,-70.10203f,39.48193f,813.0f,-477.0f,-712.0f,233,-40.704082f,-16.772337f,29.709257f,0f,0f,0f ) ;
  }

  @Test
  public void test190() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,54.480545f,0f,0f,0f,0f,0f,-23.607243f,50.211033f,30.913347f,-1069.0f,-466.0f,-59.0f,689,39.699585f,70.55524f,-84.28247f,0f,0f,0f ) ;
  }

  @Test
  public void test191() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,56.433952f,0f,0f,0f,0f,0f,40.006596f,45.04824f,100.0f,37.0f,-44.0f,-1226.0f,448,0.45074666f,0.29167357f,-0.107475184f,0f,0f,0f ) ;
  }

  @Test
  public void test192() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,5.684342E-14f,0f,0f,0f,0f,0f,100.0f,-100.0f,-100.0f,-127.0f,301.0f,-277.0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test193() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,60.485878f,0f,0f,0f,0f,0f,-29.317638f,21.366486f,-12.07139f,-1612.0f,540.0f,629.0f,-228,-0.5666665f,-0.23103282f,-0.27937204f,0f,0f,0f ) ;
  }

  @Test
  public void test194() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,62.826855f,0f,0f,0f,0f,0f,5.653739f,34.855873f,44.980053f,152.0f,-573.0f,355.0f,18,-4.7843375f,71.81645f,-9.25665f,0f,0f,0f ) ;
  }

  @Test
  public void test195() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,6.3139915f,0f,0f,0f,0f,0f,62.178246f,94.25716f,-94.831825f,0f,0f,0f,-289,92.04747f,-40.57865f,-75.722664f,0f,0f,0f ) ;
  }

  @Test
  public void test196() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,6.4025555f,0f,0f,0f,0f,0f,-23.29191f,22.100405f,-15.309589f,230.0f,976.0f,1059.0f,1048,0.13472773f,0.24424729f,0.14761321f,0f,0f,0f ) ;
  }

  @Test
  public void test197() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,65.25883f,0f,0f,0f,0f,0f,-89.62332f,85.80933f,-20.326458f,-730.0f,358.0f,396.0f,-147,-36.379482f,-54.742695f,-70.69524f,0f,0f,0f ) ;
  }

  @Test
  public void test198() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,66.12437f,0f,0f,0f,0f,0f,-77.259964f,31.506697f,5.0014668f,217.0f,678.0f,53.0f,981,-96.386856f,44.209236f,-97.37268f,0f,0f,0f ) ;
  }

  @Test
  public void test199() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,66.52636f,0f,0f,0f,0f,0f,1.2053794f,34.641403f,47.24707f,796.0f,301.0f,-241.0f,166,-49.23784f,49.69894f,2.5296633f,0f,0f,0f ) ;
  }

  @Test
  public void test200() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,68.581955f,0f,0f,0f,0f,0f,-68.06422f,3.5159636f,38.561665f,-618.0f,1200.0f,-194.0f,-600,0.048572592f,0.8242369f,0.014561821f,0f,0f,0f ) ;
  }

  @Test
  public void test201() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,70.65954f,0f,0f,0f,0f,0f,89.76837f,-28.432852f,-60.20892f,10.0f,-573.0f,-935.0f,-938,84.0462f,-63.248455f,49.088497f,0f,0f,0f ) ;
  }

  @Test
  public void test202() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,73.05605f,0f,0f,0f,0f,0f,-15.615867f,-43.71945f,49.29782f,-352.0f,-142.0f,-168.0f,712,3.4588299f,-32.59684f,-27.812654f,0f,0f,0f ) ;
  }

  @Test
  public void test203() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,75.18854f,0f,0f,0f,0f,0f,34.878826f,-66.79148f,94.82639f,983.0f,676.0f,315.0f,-94,51.46244f,63.589024f,25.860476f,0f,0f,0f ) ;
  }

  @Test
  public void test204() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,75.95265f,0f,0f,0f,0f,0f,1.2062631f,-13.6768055f,17.283478f,-720.0f,-1176.0f,-818.0f,-719,0.12764269f,-2.8877556f,-2.2940547f,0f,0f,0f ) ;
  }

  @Test
  public void test205() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,81.25165f,0f,0f,0f,0f,0f,33.857357f,99.93443f,100.0f,-994.0f,1247.0f,-178.0f,227,-0.3151422f,0.7851646f,-0.41252857f,0f,0f,0f ) ;
  }

  @Test
  public void test206() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,81.3204f,0f,0f,0f,0f,0f,-96.02571f,39.040047f,-78.472176f,-671.0f,-428.0f,13.0f,111,-99.52601f,-64.64508f,-39.864216f,0f,0f,0f ) ;
  }

  @Test
  public void test207() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,82.48185f,0f,0f,0f,0f,0f,-95.179115f,40.808876f,21.632694f,-213.0f,-210.0f,-541.0f,775,-0.32116768f,0.61491185f,-0.26691416f,0f,0f,0f ) ;
  }

  @Test
  public void test208() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,86.130104f,0f,0f,0f,0f,0f,22.084734f,-63.19128f,73.15724f,299.0f,255.0f,130.0f,309,0.2711002f,-0.7491533f,-0.53512496f,0f,0f,0f ) ;
  }

  @Test
  public void test209() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,87.754906f,0f,0f,0f,0f,0f,38.147068f,10.738079f,-19.729261f,847.0f,-324.0f,-594.0f,898,12.329972f,10.723472f,29.676819f,0f,0f,0f ) ;
  }

  @Test
  public void test210() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,91.56593f,0f,0f,0f,0f,0f,84.693146f,13.022005f,-62.459602f,498.0f,-1235.0f,-541.0f,-367,0.3194935f,0.030446747f,-0.111211695f,0f,0f,0f ) ;
  }

  @Test
  public void test211() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,9.165287f,0f,0f,0f,0f,0f,20.29596f,-53.5046f,25.712881f,964.0f,135.0f,-480.0f,378,100.0f,-36.417217f,-82.1486f,0f,0f,0f ) ;
  }

  @Test
  public void test212() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,93.64561f,0f,0f,0f,0f,0f,72.64257f,-51.53803f,-162.26654f,-912.0f,-321.0f,-588.0f,807,81.398f,-68.95367f,-71.5202f,0f,0f,0f ) ;
  }

  @Test
  public void test213() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,94.29686f,0f,0f,0f,0f,0f,-32.157436f,-39.35891f,-26.000074f,395.0f,-5.0f,-481.0f,-2491,-0.014127388f,-0.16237867f,-1.0714753f,0f,0f,0f ) ;
  }

  @Test
  public void test214() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,9.712865f,0f,0f,0f,0f,0f,-71.65043f,-70.70356f,-29.792353f,-170.0f,101.0f,168.0f,-481,-68.81193f,65.8865f,9.129673f,0f,0f,0f ) ;
  }

  @Test
  public void test215() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,98.23596f,0f,0f,0f,0f,0f,-4.983354f,56.109863f,3.8560948f,-132.0f,250.0f,26.0f,763,42.96846f,8.165054f,-63.27983f,0f,0f,0f ) ;
  }

  @Test
  public void test216() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-71.173454f,100.0f,100.0f,0f,0f,0f,-3286,0.2873437f,0.49898514f,-0.81758636f,0f,0f,0f ) ;
  }

  @Test
  public void test217() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0.0f,0f,-79.53614f,0f,0f,0f,0f,0f,100.0f,-34.787968f,99.99133f,0f,0f,0f,-206,-0.51851946f,-0.5242353f,0.3361775f,0f,0f,0f ) ;
  }

  @Test
  public void test218() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,-35.08702f,-92.68662f,84.4538f,1476.0f,-171.0f,-486.0f,1436,0.19041274f,0.6687234f,0.7187155f,0f,0f,0f ) ;
  }

  @Test
  public void test219() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,100.0f,0f,100.0f,0f,0f,0f,0f,0f,-100.0f,100.0f,100.0f,0f,0f,0f,-832,-0.0528556f,0.23706834f,-0.9700541f,0f,0f,0f ) ;
  }

  @Test
  public void test220() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,28.53604f,0f,0f,0f,0f,0f,0f,0f,-100.0f,55.084175f,-99.99952f,-1305.0f,-601.0f,-160.0f,64,0.9745606f,0.16996974f,-0.14608876f,0f,0f,0f ) ;
  }

  @Test
  public void test221() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,52.996384f,0f,0f,0f,0f,0f,0f,0f,35.821026f,-82.54608f,90.05225f,852.0f,-789.0f,517.0f,1090,0.047147818f,0.36762628f,-0.5913676f,0f,0f,0f ) ;
  }

  @Test
  public void test222() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,91.63593f,0f,0f,0f,0f,0f,0f,0f,-22.542887f,-95.131714f,-29.79028f,0f,0f,0f,2520,0.7140447f,-0.20843898f,0.25478965f,0f,0f,0f ) ;
  }

  @Test
  public void test223() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-99.98712f,0f,93.65921f,0f,0f,0f,0f,0f,-60.64859f,99.99865f,-100.0f,0f,0f,0f,-846,0.17269948f,0.29683918f,0.93918127f,0f,0f,0f ) ;
  }

  @Test
  public void test224() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1009.0f,515.0f,0f,2456.0f,0f,0f,0f,0f,0f,-460.0f,45.0f,-1067.0f,-146.0f,-326.0f,49.0f,1049,188.49762f,4.064693f,7.329396f,0f,0f,0f ) ;
  }

  @Test
  public void test225() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,101.0f,738.0f,0f,492.0f,0f,0f,0f,0f,0f,218.0f,-241.0f,-118.0f,841.0f,412.0f,710.0f,-1270,-0.99279743f,0.22962947f,-0.7048956f,0f,0f,0f ) ;
  }

  @Test
  public void test226() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1011.0f,-944.0f,0f,211.0f,0f,0f,0f,0f,0f,-346.0f,-692.0f,872.0f,-546.0f,-303.0f,-457.0f,-191,100.0f,-100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test227() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1028.0f,-985.0f,0f,1242.0f,0f,0f,0f,0f,0f,-1330.0f,553.0f,-769.0f,156.0f,1118.0f,534.0f,-2724,-2.2632453f,0.8822025f,5.010407f,0f,0f,0f ) ;
  }

  @Test
  public void test228() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1034.0f,-231.0f,0f,254.0f,0f,0f,0f,0f,0f,1139.0f,2357.0f,158.0f,-957.0f,719.0f,-864.0f,189,-0.23767456f,-0.8309307f,0.012379056f,0f,0f,0f ) ;
  }

  @Test
  public void test229() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1043.0f,1172.0f,0f,183.0f,0f,0f,0f,0f,0f,-76.0f,224.0f,1289.0f,119.0f,-742.0f,815.0f,1381,0.032594033f,-0.5771045f,-0.6024979f,0f,0f,0f ) ;
  }

  @Test
  public void test230() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1070.0f,-902.0f,0f,124.0f,0f,0f,0f,0f,0f,-938.0f,1400.0f,821.0f,-932.0f,548.0f,345.0f,-1299,-0.03384446f,-0.26954606f,-0.07096023f,0f,0f,0f ) ;
  }

  @Test
  public void test231() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1083.0f,1883.0f,0f,1063.0f,0f,0f,0f,0f,0f,719.0f,-69.0f,-750.0f,699.0f,-1126.0f,771.0f,-709,0.29118246f,0.72843975f,0.45909208f,0f,0f,0f ) ;
  }

  @Test
  public void test232() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1089.0f,-2124.0f,0f,255.0f,0f,0f,0f,0f,0f,1825.0f,715.0f,783.0f,436.0f,224.0f,1184.0f,-1696,-0.22909854f,0.4066431f,-0.68386614f,0f,0f,0f ) ;
  }

  @Test
  public void test233() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-10.977281f,0.0f,0f,79.276794f,0f,0f,0f,0f,0f,37.758125f,-20.066593f,40.954178f,0f,0f,0f,-1569,0.0033449458f,0.19879904f,-0.06315399f,0f,0f,0f ) ;
  }

  @Test
  public void test234() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,1073.0f,0f,583.0f,0f,0f,0f,0f,0f,492.0f,73.0f,1363.0f,856.0f,-1165.0f,-734.0f,754,0.4622233f,-0.09747275f,-0.45426548f,0f,0f,0f ) ;
  }

  @Test
  public void test235() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,-1.0f,0f,2741.0f,0f,0f,0f,0f,0f,513.0f,-296.0f,376.0f,947.0f,456.0f,955.0f,-1317,-24.568018f,86.44446f,-167.6733f,0f,0f,0f ) ;
  }

  @Test
  public void test236() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,1165.0f,-549.0f,2096.0f,0f,0f,0f,0f,0f,680.0f,607.0f,-858.0f,699.0f,-431.0f,90.0f,-1318,-29.680256f,21.659576f,40.127636f,70.22244f,0f,0f ) ;
  }

  @Test
  public void test237() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,-124.0f,0f,2275.0f,0f,0f,0f,0f,0f,361.0f,-987.0f,-301.0f,-114.0f,417.0f,-1505.0f,-636,-0.32461503f,5.713158f,4.094958f,0f,0f,0f ) ;
  }

  @Test
  public void test238() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,1613.0f,-30.0f,0f,0f,0f,0f,0f,0f,168.0f,-507.0f,667.0f,1565.0f,680.0f,115.0f,-744,107.02684f,39.562687f,3.0637913f,-141.9468f,0f,0f ) ;
  }

  @Test
  public void test239() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,-206.0f,0f,868.0f,0f,0f,0f,0f,0f,1580.0f,409.0f,2562.0f,-743.0f,-1212.0f,55.0f,512,0.09720237f,0.16489139f,-0.42737523f,0f,0f,0f ) ;
  }

  @Test
  public void test240() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,238.0f,0f,592.0f,0f,0f,0f,0f,0f,719.0f,685.0f,-846.0f,-480.0f,-450.0f,659.0f,858,-70.845924f,-38.81015f,84.175896f,0f,0f,0f ) ;
  }

  @Test
  public void test241() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,-252.0f,0f,934.0f,0f,0f,0f,0f,0f,210.0f,-822.0f,127.0f,-701.0f,1301.0f,-1024.0f,-1005,-0.60100263f,0.60269403f,-0.41507542f,0f,0f,0f ) ;
  }

  @Test
  public void test242() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,253.0f,0f,-1242.0f,0f,0f,0f,0f,0f,377.0f,340.0f,-275.0f,782.0f,-213.0f,-1162.0f,1119,0.4638799f,-0.5705532f,0.57498777f,0f,0f,0f ) ;
  }

  @Test
  public void test243() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,515.0f,0f,675.0f,0f,0f,0f,0f,0f,893.0f,-923.0f,1617.0f,1949.0f,-853.0f,-21.0f,-393,-0.8819569f,0.08346348f,-0.097218364f,0f,0f,0f ) ;
  }

  @Test
  public void test244() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,-6.0f,0f,1087.0f,0f,0f,0f,0f,0f,905.0f,965.0f,957.0f,2135.0f,-296.0f,1798.0f,-226,-0.92353934f,0.24053963f,0.5410594f,0f,0f,0f ) ;
  }

  @Test
  public void test245() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,-806.0f,0f,522.0f,0f,0f,0f,0f,0f,551.0f,-82.0f,709.0f,-2216.0f,-1157.0f,1590.0f,986,0.27203187f,0.34623066f,-0.17710644f,0f,0f,0f ) ;
  }

  @Test
  public void test246() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,872.0f,-138.0f,1118.0f,0f,0f,0f,0f,0f,-457.0f,466.0f,194.0f,-134.0f,-415.0f,785.0f,38,100.0f,100.0f,-36.702007f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test247() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,-890.0f,0f,200.0f,0f,0f,0f,0f,0f,1824.0f,2058.0f,1053.0f,-386.0f,310.0f,60.0f,-137,-0.8378617f,0.67469686f,-2.806784f,0f,0f,0f ) ;
  }

  @Test
  public void test248() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1106.0f,-420.0f,0f,731.0f,0f,0f,0f,0f,0f,1735.0f,-707.0f,93.0f,97.0f,6.0f,-967.0f,-812,-0.24012738f,-0.4746127f,-0.15400064f,0f,0f,0f ) ;
  }

  @Test
  public void test249() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-111.0f,27.0f,0f,-1415.0f,0f,0f,0f,0f,0f,-481.0f,1187.0f,-657.0f,2240.0f,1709.0f,547.0f,3765,-0.08204626f,-0.13118532f,-0.17694415f,0f,0f,0f ) ;
  }

  @Test
  public void test250() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1128.0f,1603.0f,0f,251.0f,0f,0f,0f,0f,0f,-593.0f,-478.0f,256.0f,-1505.0f,-1007.0f,960.0f,117,7.186247f,-60.21015f,-95.77742f,0f,0f,0f ) ;
  }

  @Test
  public void test251() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1129.0f,1283.0f,0f,668.0f,0f,0f,0f,0f,0f,336.0f,-1799.0f,-590.0f,964.0f,-863.0f,711.0f,778,-95.40833f,-13.098281f,-14.39558f,0f,0f,0f ) ;
  }

  @Test
  public void test252() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1131.0f,1407.0f,0f,1281.0f,0f,0f,0f,0f,0f,494.0f,70.0f,516.0f,-275.0f,213.0f,1182.0f,-99,15.857628f,98.715324f,-28.573141f,0f,0f,0f ) ;
  }

  @Test
  public void test253() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,114.0f,-377.0f,0f,885.0f,0f,0f,0f,0f,0f,7.0f,463.0f,-21.0f,-536.0f,547.0f,-853.0f,-331,65.342064f,-96.2341f,-86.24352f,0f,0f,0f ) ;
  }

  @Test
  public void test254() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-114.0f,835.0f,17.0f,-1.0f,0f,0f,0f,0f,0f,-180.0f,1481.0f,-1701.0f,-604.0f,1192.0f,605.0f,21,-0.5191916f,-0.85261995f,-0.05898558f,100.0f,0f,0f ) ;
  }

  @Test
  public void test255() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1151.0f,-705.0f,0f,579.0f,0f,0f,0f,0f,0f,26.0f,582.0f,512.0f,-38.0f,-176.0f,202.0f,262,87.41557f,25.66741f,-68.86744f,0f,0f,0f ) ;
  }

  @Test
  public void test256() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,116.0f,-1816.0f,0f,731.0f,0f,0f,0f,0f,0f,1371.0f,852.0f,187.0f,-66.0f,188.0f,-371.0f,-509,0.017087547f,-1.2043209f,-0.05263073f,0f,0f,0f ) ;
  }

  @Test
  public void test257() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,11.881313f,0f,0f,0f,0f,0f,0f,0f,0f,56.01671f,-79.87803f,-33.70114f,0f,0f,0f,-659,3.4778001f,61.002476f,55.411415f,0f,0f,0f ) ;
  }

  @Test
  public void test258() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,119.27689f,102.39699f,0f,0f,0f,0f,0f,0f,0f,94.897804f,88.114456f,-99.33426f,-548.0f,-457.0f,662.0f,-2317,2.6388454f,-2.018411f,0.73055816f,0f,0f,0f ) ;
  }

  @Test
  public void test259() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-120.0f,-564.0f,0f,157.0f,0f,0f,0f,0f,0f,526.0f,763.0f,-939.0f,-469.0f,-74.0f,-324.0f,894,0.5198762f,0.4234713f,1.1646302f,0f,0f,0f ) ;
  }

  @Test
  public void test260() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1212.0f,-3706.0f,0f,94.0f,0f,0f,0f,0f,0f,44.0f,38.0f,103.0f,-729.0f,838.0f,8.0f,-1280,0.008066772f,0.5450196f,-0.85023034f,0f,0f,0f ) ;
  }

  @Test
  public void test261() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1215.0f,114.0f,0f,655.0f,0f,0f,0f,0f,0f,-772.0f,-423.0f,823.0f,-61.0f,1085.0f,113.0f,161,90.29179f,-2.4589307f,83.432724f,0f,0f,0f ) ;
  }

  @Test
  public void test262() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1218.0f,883.0f,0f,125.0f,0f,0f,0f,0f,0f,772.0f,326.0f,-716.0f,-1055.0f,-379.0f,-603.0f,-721,-58.23832f,-3.1289546f,-64.217766f,0f,0f,0f ) ;
  }

  @Test
  public void test263() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-122.0f,-2374.0f,0f,1454.0f,0f,0f,0f,0f,0f,-135.0f,175.0f,-60.0f,-671.0f,-88.0f,1242.0f,2221,-0.5323476f,-0.45683312f,-0.13464785f,0f,0f,0f ) ;
  }

  @Test
  public void test264() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1228.0f,1474.0f,0f,1.0f,0f,0f,0f,0f,0f,-221.0f,-791.0f,-509.0f,-489.0f,-676.0f,-411.0f,897,-29.745495f,100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test265() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1240.0f,714.0f,0f,1743.0f,0f,0f,0f,0f,0f,29.0f,-657.0f,526.0f,-297.0f,-710.0f,-870.0f,1052,-57.802425f,90.997375f,-98.7699f,0f,0f,0f ) ;
  }

  @Test
  public void test266() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,126.0f,-1159.0f,0f,770.0f,0f,0f,0f,0f,0f,-1000.0f,-930.0f,-1277.0f,-146.0f,-64.0f,161.0f,-794,-0.76949334f,0.5107062f,0.2317374f,0f,0f,0f ) ;
  }

  @Test
  public void test267() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1269.0f,-1169.0f,0f,258.0f,0f,0f,0f,0f,0f,834.0f,855.0f,152.0f,24.0f,622.0f,161.0f,-1662,0.13082513f,-0.16451792f,-0.56307834f,0f,0f,0f ) ;
  }

  @Test
  public void test268() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1270.0f,997.0f,0f,2283.0f,0f,0f,0f,0f,0f,-222.0f,109.0f,-1322.0f,131.0f,86.0f,-15.0f,1173,0.5515965f,-0.4950834f,0.21506563f,0f,0f,0f ) ;
  }

  @Test
  public void test269() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1279.0f,506.0f,0f,540.0f,0f,0f,0f,0f,0f,81.0f,195.0f,874.0f,1213.0f,796.0f,-290.0f,147,0.65330744f,-2.6069813f,0.45166254f,0f,0f,0f ) ;
  }

  @Test
  public void test270() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1282.0f,1941.0f,0f,501.0f,0f,0f,0f,0f,0f,1050.0f,909.0f,616.0f,-267.0f,762.0f,-667.0f,170,-2.0925772f,65.37895f,-92.909515f,0f,0f,0f ) ;
  }

  @Test
  public void test271() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-129.0f,0.0f,0f,2649.0f,0f,0f,0f,0f,0f,-625.0f,380.0f,932.0f,-265.0f,1084.0f,276.0f,50,83.06199f,-31.588675f,-57.904686f,0f,0f,0f ) ;
  }

  @Test
  public void test272() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1338.0f,715.0f,0f,1653.0f,0f,0f,0f,0f,0f,794.0f,-1183.0f,-169.0f,-697.0f,-472.0f,29.0f,192,-88.40007f,-5.845754f,-25.248325f,0f,0f,0f ) ;
  }

  @Test
  public void test273() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-136.0f,1112.0f,0f,-675.0f,0f,0f,0f,0f,0f,244.0f,627.0f,664.0f,279.0f,324.0f,-1542.0f,-166,-0.2694513f,-0.14923602f,-0.74049115f,0f,0f,0f ) ;
  }

  @Test
  public void test274() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,139.0f,82.0f,0f,1000.0f,0f,0f,0f,0f,0f,662.0f,-307.0f,450.0f,252.0f,-516.0f,932.0f,331,47.402065f,37.69023f,-44.02059f,0f,0f,0f ) ;
  }

  @Test
  public void test275() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1398.0f,-1381.0f,0f,1887.0f,0f,0f,0f,0f,0f,1865.0f,121.0f,1659.0f,444.0f,-391.0f,-469.0f,-2380,0.023274498f,0.85543483f,-0.12660833f,0f,0f,0f ) ;
  }

  @Test
  public void test276() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,14.0f,94.0f,0f,499.0f,0f,0f,0f,0f,0f,835.0f,545.0f,389.0f,749.0f,361.0f,435.0f,985,-74.774f,-44.064392f,20.649668f,0f,0f,0f ) ;
  }

  @Test
  public void test277() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1439.0f,-861.0f,0f,259.0f,0f,0f,0f,0f,0f,-1791.0f,836.0f,1231.0f,-261.0f,848.0f,-73.0f,-180,75.95927f,-6.6412187f,-5.5595527f,0f,0f,0f ) ;
  }

  @Test
  public void test278() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.4499531E-16f,36.194424f,0f,0f,0f,0f,0f,0f,0f,17.057272f,30.817863f,-33.52529f,-134.0f,769.0f,108.0f,878,-1.194436f,-0.1682398f,-0.762368f,0f,0f,0f ) ;
  }

  @Test
  public void test279() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1460.0f,-535.0f,0f,1192.0f,0f,0f,0f,0f,0f,834.0f,-966.0f,149.0f,1061.0f,202.0f,-1000.0f,708,-0.44235286f,0.1586046f,0.15578301f,0f,0f,0f ) ;
  }

  @Test
  public void test280() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1466.0f,0.0f,0f,1967.0f,0f,0f,0f,0f,0f,-634.0f,-504.0f,-283.0f,-511.0f,672.0f,-49.0f,956,0.56284904f,3.2889156f,3.9171994f,0f,0f,0f ) ;
  }

  @Test
  public void test281() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-14.740125f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-9.172411f,41.463272f,-28.3536f,0f,0f,0f,-159,4.8141685f,-58.397392f,-29.258154f,0f,0f,0f ) ;
  }

  @Test
  public void test282() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,15.0f,477.0f,-2320.0f,0f,0f,0f,0f,0f,0f,-569.0f,-394.0f,-476.0f,723.0f,253.0f,-1074.0f,1209,208.5588f,-52.52545f,42.314175f,-93.77594f,0f,0f ) ;
  }

  @Test
  public void test283() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1521.0f,571.0f,0f,318.0f,0f,0f,0f,0f,0f,-825.0f,1465.0f,1902.0f,-1495.0f,-953.0f,-171.0f,1089,0.25452816f,-0.6750475f,-0.69247836f,0f,0f,0f ) ;
  }

  @Test
  public void test284() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1548.0f,-942.0f,0f,591.0f,0f,0f,0f,0f,0f,-277.0f,-348.0f,-94.0f,466.0f,-350.0f,-80.0f,61,15.463211f,-4.308401f,93.402504f,0f,0f,0f ) ;
  }

  @Test
  public void test285() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1570.0f,-5.0f,0f,190.0f,0f,0f,0f,0f,0f,632.0f,-2257.0f,-1294.0f,-227.0f,-1343.0f,-722.0f,-328,0.36650443f,-0.007892165f,0.24311385f,0f,0f,0f ) ;
  }

  @Test
  public void test286() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-157.0f,-2104.0f,0f,2217.0f,0f,0f,0f,0f,0f,-234.0f,290.0f,424.0f,-559.0f,704.0f,-788.0f,32,0.3752615f,-0.59268755f,0.6097807f,0f,0f,0f ) ;
  }

  @Test
  public void test287() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1571.0f,127.0f,20.0f,-523.0f,0f,0f,0f,0f,0f,-528.0f,1013.0f,187.0f,-2447.0f,-147.0f,-410.0f,759,-0.16139343f,-0.86865294f,-0.35061458f,66.93576f,0f,0f ) ;
  }

  @Test
  public void test288() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1573.0f,120.0f,0f,255.0f,0f,0f,0f,0f,0f,1434.0f,-25.0f,734.0f,1847.0f,-771.0f,1346.0f,340,-24.687716f,45.339096f,49.776104f,0f,0f,0f ) ;
  }

  @Test
  public void test289() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-158.0f,-879.0f,0f,298.0f,0f,0f,0f,0f,0f,-394.0f,-1449.0f,31.0f,-304.0f,-673.0f,-910.0f,-440,-56.051254f,35.99972f,44.23077f,0f,0f,0f ) ;
  }

  @Test
  public void test290() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1594.0f,606.0f,0f,329.0f,0f,0f,0f,0f,0f,1034.0f,565.0f,1389.0f,1386.0f,925.0f,435.0f,-152,-0.5811819f,-0.39162308f,0.4590432f,0f,0f,0f ) ;
  }

  @Test
  public void test291() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-160.0f,-1028.0f,0f,770.0f,0f,0f,0f,0f,0f,-985.0f,-277.0f,140.0f,-22.0f,25.0f,661.0f,-667,100.0f,-81.34836f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test292() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1604.0f,1392.0f,0f,1769.0f,0f,0f,0f,0f,0f,-730.0f,566.0f,-825.0f,-609.0f,93.0f,596.0f,328,-41.01472f,51.432552f,71.7516f,0f,0f,0f ) ;
  }

  @Test
  public void test293() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1606.0f,1417.0f,0f,-3267.0f,0f,0f,0f,0f,0f,-12.0f,1069.0f,-849.0f,1935.0f,381.0f,2432.0f,1484,-0.5212769f,-0.851473f,-0.057133444f,0f,0f,0f ) ;
  }

  @Test
  public void test294() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,16.0f,6.0f,0f,310.0f,0f,0f,0f,0f,0f,-86.0f,443.0f,76.0f,-286.0f,-172.0f,689.0f,-862,-39.718513f,-139.13626f,-163.07443f,0f,0f,0f ) ;
  }

  @Test
  public void test295() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-162.0f,108.0f,0f,756.0f,0f,0f,0f,0f,0f,-489.0f,-62.0f,-471.0f,-1214.0f,1623.0f,435.0f,-62,-17.168808f,-21.883823f,20.705635f,0f,0f,0f ) ;
  }

  @Test
  public void test296() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-16.290773f,-16.393171f,0f,-52.163887f,0f,0f,0f,0f,0f,-99.20171f,-68.06281f,-28.835546f,0f,0f,0f,961,-0.10775272f,0.40331507f,-0.5812792f,0f,0f,0f ) ;
  }

  @Test
  public void test297() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-163.0f,589.0f,76.0f,46.0f,0f,0f,0f,0f,0f,-536.0f,324.0f,-966.0f,-518.0f,-562.0f,-717.0f,-835,34.49024f,-81.80635f,54.674282f,0.071047395f,0f,0f ) ;
  }

  @Test
  public void test298() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1691.0f,559.0f,0f,0.0f,0f,0f,0f,0f,0f,-460.0f,545.0f,1410.0f,130.0f,1193.0f,-855.0f,804,83.5916f,-43.135944f,-56.0248f,0f,0f,0f ) ;
  }

  @Test
  public void test299() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1705.0f,-580.0f,0f,590.0f,0f,0f,0f,0f,0f,837.0f,700.0f,307.0f,-642.0f,-128.0f,2042.0f,-1309,-0.07084035f,0.40047118f,-0.9176183f,0f,0f,0f ) ;
  }

  @Test
  public void test300() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1706.0f,-122.0f,0f,499.0f,0f,0f,0f,0f,0f,6.0f,507.0f,-514.0f,-357.0f,-866.0f,-859.0f,1566,100.0f,-2.8873641f,41.692024f,0f,0f,0f ) ;
  }

  @Test
  public void test301() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,171.0f,-65.0f,0f,78.0f,0f,0f,0f,0f,0f,-251.0f,-649.0f,-1003.0f,-641.0f,-2262.0f,566.0f,-558,0.85997325f,0.19194376f,0.074569836f,0f,0f,0f ) ;
  }

  @Test
  public void test302() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1747.0f,458.0f,0f,253.0f,0f,0f,0f,0f,0f,603.0f,73.0f,-496.0f,895.0f,12.0f,-314.0f,125,-94.36153f,100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test303() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1756.0f,183.0f,0f,839.0f,0f,0f,0f,0f,0f,-278.0f,177.0f,-658.0f,418.0f,-810.0f,-395.0f,-1064,-100.0f,100.0f,69.15793f,0f,0f,0f ) ;
  }

  @Test
  public void test304() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-176.0f,41.0f,0f,577.0f,0f,0f,0f,0f,0f,706.0f,-623.0f,-1859.0f,305.0f,331.0f,4.0f,-2491,0.40591168f,-0.3889987f,0.3501832f,0f,0f,0f ) ;
  }

  @Test
  public void test305() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,180.0f,2601.0f,0f,1032.0f,0f,0f,0f,0f,0f,248.0f,730.0f,-13.0f,916.0f,-282.0f,1651.0f,-2022,0.5825387f,-0.19642425f,0.08307008f,0f,0f,0f ) ;
  }

  @Test
  public void test306() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-18.0f,26.0f,535.0f,-46.0f,0f,0f,0f,0f,0f,-428.0f,-544.0f,917.0f,-698.0f,-612.0f,592.0f,622,88.85049f,-61.781666f,-59.47465f,-19.675829f,0f,0f ) ;
  }

  @Test
  public void test307() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-182.0f,0.0f,0f,558.0f,0f,0f,0f,0f,0f,-357.0f,-871.0f,47.0f,965.0f,-437.0f,-771.0f,-293,0.4888754f,65.08577f,-36.424618f,0f,0f,0f ) ;
  }

  @Test
  public void test308() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1823.0f,239.0f,0f,0.0f,0f,0f,0f,0f,0f,-313.0f,-886.0f,224.0f,2010.0f,738.0f,-688.0f,-218,0.81316215f,-3.4491118E-4f,-0.58203137f,0f,0f,0f ) ;
  }

  @Test
  public void test309() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1860.0f,-1697.0f,0f,464.0f,0f,0f,0f,0f,0f,-276.0f,1803.0f,-796.0f,426.0f,1292.0f,-143.0f,485,0.64978355f,0.08373555f,0.4838608f,0f,0f,0f ) ;
  }

  @Test
  public void test310() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-186.0f,-883.0f,0f,254.0f,0f,0f,0f,0f,0f,-593.0f,290.0f,1536.0f,-1384.0f,1183.0f,560.0f,277,-0.14417984f,-0.5340546f,-0.66033286f,0f,0f,0f ) ;
  }

  @Test
  public void test311() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1917.0f,-95.0f,0f,253.0f,0f,0f,0f,0f,0f,-1555.0f,-136.0f,1030.0f,-750.0f,126.0f,363.0f,930,0.6396322f,-0.3341746f,0.20823781f,0f,0f,0f ) ;
  }

  @Test
  public void test312() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1931.0f,-7.0f,0f,309.0f,0f,0f,0f,0f,0f,-1439.0f,304.0f,187.0f,-481.0f,-165.0f,576.0f,753,0.8080504f,-0.046609003f,1.3298693E-4f,0f,0f,0f ) ;
  }

  @Test
  public void test313() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1978.0f,946.0f,0f,2506.0f,0f,0f,0f,0f,0f,-764.0f,449.0f,-331.0f,124.0f,685.0f,642.0f,1491,97.15384f,100.0f,-87.44531f,0f,0f,0f ) ;
  }

  @Test
  public void test314() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-198.0f,-721.0f,0f,822.0f,0f,0f,0f,0f,0f,874.0f,-77.0f,-611.0f,665.0f,-1541.0f,-1761.0f,-960,-0.025144035f,-0.45750386f,0.035886418f,0f,0f,0f ) ;
  }

  @Test
  public void test315() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,207.0f,-111.0f,70.0f,994.0f,0f,0f,0f,0f,0f,-750.0f,-228.0f,808.0f,428.0f,945.0f,175.0f,-799,-68.37158f,-50.58766f,-11.993336f,14.794652f,0f,0f ) ;
  }

  @Test
  public void test316() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-208.0f,3.0f,450.0f,-884.0f,0f,0f,0f,0f,0f,149.0f,-38.0f,-148.0f,590.0f,758.0f,404.0f,719,36.128525f,12.074432f,-20.984152f,18.094921f,0f,0f ) ;
  }

  @Test
  public void test317() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,0.0f,0f,1781.0f,0f,0f,0f,0f,0f,1497.0f,306.0f,-344.0f,195.0f,-24.0f,821.0f,1018,-98.627556f,63.24129f,127.83006f,0f,0f,0f ) ;
  }

  @Test
  public void test318() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,2492.0f,0f,-20.0f,0f,0f,0f,0f,0f,525.0f,-2470.0f,1322.0f,-801.0f,246.0f,-1565.0f,319,-0.47106153f,0.033256732f,-0.07259743f,0f,0f,0f ) ;
  }

  @Test
  public void test319() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,2988.0f,-432.0f,0f,0f,0f,0f,0f,0f,623.0f,-1061.0f,9.0f,-348.0f,-188.0f,1952.0f,-1087,55.519028f,32.767353f,19.756334f,100.0f,0f,0f ) ;
  }

  @Test
  public void test320() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,471.0f,0f,0.0f,0f,0f,0f,0f,0f,-2140.0f,1931.0f,558.0f,-1507.0f,248.0f,-405.0f,-824,0.8293978f,0.3528751f,0.35301995f,0f,0f,0f ) ;
  }

  @Test
  public void test321() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,567.0f,0f,255.0f,0f,0f,0f,0f,0f,223.0f,-50.0f,329.0f,824.0f,-163.0f,645.0f,-1525,-100.0f,46.316326f,74.82002f,0f,0f,0f ) ;
  }

  @Test
  public void test322() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,-570.0f,0f,555.0f,0f,0f,0f,0f,0f,-747.0f,-919.0f,-670.0f,253.0f,-889.0f,-625.0f,-903,31.74544f,-7.762174f,56.960068f,0f,0f,0f ) ;
  }

  @Test
  public void test323() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,608.0f,0f,-551.0f,0f,0f,0f,0f,0f,-960.0f,-989.0f,32.0f,-840.0f,176.0f,-561.0f,687,-32.59371f,60.248398f,-49.771553f,0f,0f,0f ) ;
  }

  @Test
  public void test324() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,975.0f,0f,993.0f,0f,0f,0f,0f,0f,-893.0f,-781.0f,-252.0f,372.0f,47.0f,-14.0f,-865,58.233517f,45.665203f,-58.76288f,0f,0f,0f ) ;
  }

  @Test
  public void test325() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,210.0f,2.0f,0f,577.0f,0f,0f,0f,0f,0f,-245.0f,-790.0f,-483.0f,-848.0f,-841.0f,-239.0f,1410,21.293144f,-22.254057f,25.598108f,0f,0f,0f ) ;
  }

  @Test
  public void test326() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2107.0f,2283.0f,0f,2488.0f,0f,0f,0f,0f,0f,-581.0f,1128.0f,1320.0f,711.0f,555.0f,34.0f,-614,-1.673663f,-1.2660466f,0.34522626f,0f,0f,0f ) ;
  }

  @Test
  public void test327() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,21.0f,1115.0f,0f,1984.0f,0f,0f,0f,0f,0f,-551.0f,-322.0f,-44.0f,699.0f,-984.0f,-1554.0f,-949,1.6702659f,2.1326096f,-34.203316f,0f,0f,0f ) ;
  }

  @Test
  public void test328() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2168.0f,-2.0f,0f,512.0f,0f,0f,0f,0f,0f,-185.0f,28.0f,30.0f,-162.0f,-384.0f,-638.0f,-1641,-0.046178404f,2.6614788f,-2.7688138f,0f,0f,0f ) ;
  }

  @Test
  public void test329() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2183.0f,1603.0f,0f,337.0f,0f,0f,0f,0f,0f,955.0f,855.0f,41.0f,165.0f,-185.0f,14.0f,-684,-0.29565957f,0.24061036f,0.429253f,0f,0f,0f ) ;
  }

  @Test
  public void test330() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2187.0f,869.0f,0f,488.0f,0f,0f,0f,0f,0f,-19.0f,732.0f,-656.0f,356.0f,-504.0f,-574.0f,247,-0.28237528f,0.41620106f,0.47303146f,0f,0f,0f ) ;
  }

  @Test
  public void test331() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,219.0f,1539.0f,0f,254.0f,0f,0f,0f,0f,0f,-43.0f,-675.0f,-3656.0f,1515.0f,-665.0f,-979.0f,-792,-0.90222734f,-0.40338585f,0.15253438f,0f,0f,0f ) ;
  }

  @Test
  public void test332() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-219.0f,3.0f,0f,962.0f,0f,0f,0f,0f,0f,280.0f,-147.0f,976.0f,24.0f,-395.0f,-1393.0f,682,-0.60084164f,-0.5279906f,-0.52512956f,0f,0f,0f ) ;
  }

  @Test
  public void test333() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2225.0f,-1748.0f,0f,1304.0f,0f,0f,0f,0f,0f,1187.0f,584.0f,1092.0f,-222.0f,743.0f,-156.0f,-529,-0.21733364f,-0.6279023f,0.5326976f,0f,0f,0f ) ;
  }

  @Test
  public void test334() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2229.0f,685.0f,0f,740.0f,0f,0f,0f,0f,0f,-699.0f,-449.0f,-319.0f,-947.0f,836.0f,897.0f,23,0.40898114f,0.35385838f,-1.3767496f,0f,0f,0f ) ;
  }

  @Test
  public void test335() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2240.0f,250.0f,0f,1431.0f,0f,0f,0f,0f,0f,-886.0f,223.0f,625.0f,235.0f,-558.0f,533.0f,-846,0.056488696f,-0.899066f,0.4008651f,0f,0f,0f ) ;
  }

  @Test
  public void test336() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-224.0f,446.0f,639.0f,-965.0f,0f,0f,0f,0f,0f,607.0f,-242.0f,-788.0f,289.0f,769.0f,954.0f,282,7.402963f,-2.355111f,87.45305f,0f,36.412567f,0f ) ;
  }

  @Test
  public void test337() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-225.0f,224.0f,-999.0f,-364.0f,0f,0f,0f,0f,0f,-805.0f,-519.0f,137.0f,-17.0f,-379.0f,-873.0f,511,23.789654f,96.74215f,65.832436f,-65.57096f,-18.829771f,0f ) ;
  }

  @Test
  public void test338() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-22.61992f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-94.315056f,26.554491f,-88.646545f,0f,0f,0f,-858,-0.23380327f,-0.69996226f,0.039076854f,0f,0f,0f ) ;
  }

  @Test
  public void test339() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2279.0f,611.0f,0f,1691.0f,0f,0f,0f,0f,0f,-1224.0f,336.0f,-92.0f,4.0f,-58.0f,-266.0f,-818,-0.0818479f,-0.3266503f,0.060294878f,0f,0f,0f ) ;
  }

  @Test
  public void test340() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,22.904787f,0.0f,0f,99.870384f,0f,0f,0f,0f,0f,81.88933f,-35.32161f,-100.0f,0f,0f,0f,-720,-0.8307298f,-0.26941803f,0.08891339f,0f,0f,0f ) ;
  }

  @Test
  public void test341() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2332.0f,-1194.0f,0f,250.0f,0f,0f,0f,0f,0f,641.0f,-12.0f,835.0f,747.0f,-1305.0f,1706.0f,-52,0.054279782f,0.16192856f,-0.6999715f,0f,0f,0f ) ;
  }

  @Test
  public void test342() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2335.0f,-1827.0f,0f,2291.0f,0f,0f,0f,0f,0f,1730.0f,822.0f,1218.0f,1061.0f,1984.0f,250.0f,1253,0.20359719f,0.40147293f,-0.73942196f,0f,0f,0f ) ;
  }

  @Test
  public void test343() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-236.0f,6.0f,0f,1.0f,0f,0f,0f,0f,0f,-1471.0f,-104.0f,1606.0f,-461.0f,-868.0f,-1579.0f,-1397,0.010133251f,0.29817033f,-0.9246168f,0f,0f,0f ) ;
  }

  @Test
  public void test344() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2410.0f,3112.0f,0f,-2.0f,0f,0f,0f,0f,0f,-1433.0f,1280.0f,-262.0f,766.0f,-288.0f,-857.0f,876,0.063664064f,-0.7592986f,0.3930902f,0f,0f,0f ) ;
  }

  @Test
  public void test345() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.4261425f,-96.229935f,0f,0f,0f,0f,0f,0f,0f,-99.76591f,-99.80403f,31.659391f,0f,0f,0f,-411,0.9980948f,0.02400499f,0.056837954f,0f,0f,0f ) ;
  }

  @Test
  public void test346() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2461.0f,359.0f,0f,590.0f,0f,0f,0f,0f,0f,615.0f,826.0f,-984.0f,-705.0f,841.0f,265.0f,-1394,-0.7374217f,0.4692746f,-0.06696495f,0f,0f,0f ) ;
  }

  @Test
  public void test347() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2462.0f,1352.0f,0f,1011.0f,0f,0f,0f,0f,0f,449.0f,520.0f,-796.0f,465.0f,841.0f,811.0f,1764,0.11431279f,-0.26759642f,-0.11017761f,0f,0f,0f ) ;
  }

  @Test
  public void test348() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2477.0f,502.0f,0f,676.0f,0f,0f,0f,0f,0f,-414.0f,693.0f,-88.0f,2135.0f,-325.0f,-137.0f,115,1.6223885f,0.87782186f,-0.7197373f,0f,0f,0f ) ;
  }

  @Test
  public void test349() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,24.98946f,-39.77025f,0f,-58.542004f,0f,0f,0f,0f,0f,64.74532f,51.980515f,6.5674906f,0f,0f,0f,63,-64.58235f,53.858425f,-46.206818f,0f,0f,0f ) ;
  }

  @Test
  public void test350() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-253.0f,581.0f,0f,524.0f,0f,0f,0f,0f,0f,215.0f,-644.0f,473.0f,812.0f,-55.0f,534.0f,760,-36.71516f,33.690636f,-29.684032f,0f,0f,0f ) ;
  }

  @Test
  public void test351() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-253.0f,68.0f,0f,169.0f,0f,0f,0f,0f,0f,-502.0f,-648.0f,604.0f,-845.0f,310.0f,73.0f,-327,-90.58651f,3.713883f,-80.24631f,0f,0f,0f ) ;
  }

  @Test
  public void test352() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,25.72526f,0.0f,0f,-21.069727f,0f,0f,0f,0f,0f,-95.04629f,100.0f,-100.0f,0f,0f,0f,167,0.9790314f,-0.20359923f,-0.006696856f,0f,0f,0f ) ;
  }

  @Test
  public void test353() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-259.0f,-609.0f,212.0f,-791.0f,0f,0f,0f,0f,0f,554.0f,521.0f,-163.0f,-588.0f,-125.0f,-408.0f,-316,-55.248577f,57.737225f,-14.902152f,73.11637f,16.35512f,10.028395f ) ;
  }

  @Test
  public void test354() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,25.950478f,0.0f,0f,0f,0f,0f,0f,0f,0f,17.864096f,61.846786f,-91.03088f,0f,0f,0f,-903,6.5534315f,-4.413908f,13.6053915f,0f,0f,0f ) ;
  }

  @Test
  public void test355() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-261.0f,108.0f,0f,246.0f,0f,0f,0f,0f,0f,-947.0f,940.0f,23.0f,836.0f,478.0f,1656.0f,1370,-0.16297387f,-0.41273817f,0.89615107f,0f,0f,0f ) ;
  }

  @Test
  public void test356() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-261.0f,1621.0f,0f,260.0f,0f,0f,0f,0f,0f,-735.0f,484.0f,382.0f,-380.0f,957.0f,730.0f,337,-39.126305f,-69.249374f,12.457758f,0f,0f,0f ) ;
  }

  @Test
  public void test357() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-261.0f,-2582.0f,0f,857.0f,0f,0f,0f,0f,0f,-1062.0f,-437.0f,-1053.0f,-1334.0f,-661.0f,-743.0f,606,-0.021143531f,-0.30649772f,0.3208912f,0f,0f,0f ) ;
  }

  @Test
  public void test358() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,265.0f,-1.0f,0f,27.0f,0f,0f,0f,0f,0f,1159.0f,361.0f,271.0f,1095.0f,464.0f,320.0f,-974,-3.4682422f,-44.15807f,22.925833f,0f,0f,0f ) ;
  }

  @Test
  public void test359() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,268.0f,493.0f,0f,937.0f,0f,0f,0f,0f,0f,938.0f,861.0f,-238.0f,-234.0f,502.0f,-349.0f,635,23.80753f,-56.263706f,6.161824f,0f,0f,0f ) ;
  }

  @Test
  public void test360() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2695.0f,-494.0f,0f,180.0f,0f,0f,0f,0f,0f,-1155.0f,679.0f,-1457.0f,-1055.0f,-421.0f,-1033.0f,-1180,0.26256168f,-0.93761295f,0.032989178f,0f,0f,0f ) ;
  }

  @Test
  public void test361() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2777.0f,-743.0f,0f,538.0f,0f,0f,0f,0f,0f,742.0f,-511.0f,1199.0f,-928.0f,1485.0f,-924.0f,170,0.6666548f,0.6974934f,-0.2018975f,0f,0f,0f ) ;
  }

  @Test
  public void test362() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,28.18542f,-74.37115f,0f,0f,0f,0f,0f,0f,0f,-73.705185f,-8.940874f,-12.395324f,0f,0f,0f,280,0.13411948f,-0.41850355f,-0.49563155f,0f,0f,0f ) ;
  }

  @Test
  public void test363() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.8288383f,0.0f,0f,0f,0f,0f,0f,0f,0f,-53.684334f,-85.83665f,-100.0f,0f,0f,0f,-632,-0.51424026f,-0.12389842f,0.645698f,0f,0f,0f ) ;
  }

  @Test
  public void test364() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-285.0f,527.0f,0f,905.0f,0f,0f,0f,0f,0f,509.0f,681.0f,-83.0f,828.0f,-570.0f,-577.0f,441,-6.2245026f,15.704016f,90.6792f,0f,0f,0f ) ;
  }

  @Test
  public void test365() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-28.58827f,13.583567f,0f,0f,0f,0f,0f,0f,0f,-97.31219f,61.55118f,15.682421f,521.0f,711.0f,-722.0f,571,0.15339622f,-0.39384198f,-0.7767048f,0f,0f,0f ) ;
  }

  @Test
  public void test366() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2879.0f,1568.0f,0f,262.0f,0f,0f,0f,0f,0f,-205.0f,264.0f,-275.0f,55.0f,-527.0f,-673.0f,647,35.868504f,88.70915f,58.423077f,0f,0f,0f ) ;
  }

  @Test
  public void test367() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2889.0f,-3088.0f,0f,995.0f,0f,0f,0f,0f,0f,133.0f,831.0f,1505.0f,696.0f,-1685.0f,1128.0f,-1220,-0.010236808f,0.40884233f,-0.4665464f,0f,0f,0f ) ;
  }

  @Test
  public void test368() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-292.0f,304.0f,-26.0f,-353.0f,0f,0f,0f,0f,0f,-542.0f,-273.0f,612.0f,103.0f,318.0f,606.0f,95,36.254093f,8.951146f,1.7509261f,-13.505343f,23.095602f,0f ) ;
  }

  @Test
  public void test369() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-292.0f,920.0f,0f,109.0f,0f,0f,0f,0f,0f,-765.0f,-881.0f,-2060.0f,-749.0f,993.0f,184.0f,2179,0.66238594f,0.46835142f,0.50654787f,0f,0f,0f ) ;
  }

  @Test
  public void test370() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,299.0f,-351.0f,0f,403.0f,0f,0f,0f,0f,0f,943.0f,1153.0f,1804.0f,-925.0f,1471.0f,45.0f,490,-0.090433255f,0.2932905f,-0.2646397f,0f,0f,0f ) ;
  }

  @Test
  public void test371() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-30.152775f,0f,0f,0f,0f,0f,0f,0f,0f,-98.812256f,-100.0f,100.0f,0f,0f,0f,1006,-0.6892413f,0.48056218f,-0.5422236f,0f,0f,0f ) ;
  }

  @Test
  public void test372() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3.0f,-1.0f,0f,77.0f,0f,0f,0f,0f,0f,-605.0f,-463.0f,209.0f,2107.0f,770.0f,655.0f,-57,159.83997f,125.89559f,-49.94867f,0f,0f,0f ) ;
  }

  @Test
  public void test373() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3.0f,1833.0f,0f,-2861.0f,0f,0f,0f,0f,0f,-393.0f,1089.0f,1121.0f,1073.0f,373.0f,-1154.0f,-1445,0.6896633f,-0.52176845f,-0.50211775f,0f,0f,0f ) ;
  }

  @Test
  public void test374() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3.0f,-2.0f,0f,1360.0f,0f,0f,0f,0f,0f,-510.0f,845.0f,-1149.0f,-1482.0f,129.0f,980.0f,-330,0.5320309f,-0.1230212f,0.81468046f,0f,0f,0f ) ;
  }

  @Test
  public void test375() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3.0f,-3.0f,0f,745.0f,0f,0f,0f,0f,0f,-612.0f,-595.0f,1671.0f,262.0f,543.0f,288.0f,77,1.5375271f,-3.8679435f,-4.140198f,0f,0f,0f ) ;
  }

  @Test
  public void test376() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-310.0f,-68.0f,795.0f,0f,0f,0f,0f,0f,0f,-79.0f,-284.0f,-313.0f,-965.0f,-217.0f,546.0f,-751,12.644713f,94.284424f,-49.897816f,-35.82228f,0f,0f ) ;
  }

  @Test
  public void test377() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-315.0f,1.0f,0f,744.0f,0f,0f,0f,0f,0f,254.0f,74.0f,128.0f,-238.0f,948.0f,-75.0f,892,-35.140182f,35.742607f,-52.958828f,0f,0f,0f ) ;
  }

  @Test
  public void test378() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,319.0f,219.0f,0f,-1.0f,0f,0f,0f,0f,0f,483.0f,712.0f,-251.0f,688.0f,-700.0f,-765.0f,151,62.179073f,-100.0f,-66.87808f,0f,0f,0f ) ;
  }

  @Test
  public void test379() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,319.0f,648.0f,697.0f,683.0f,0f,0f,0f,0f,0f,-710.0f,-456.0f,180.0f,231.0f,152.0f,869.0f,529,-99.71726f,7.540859f,-33.709034f,-18.370396f,-61.544376f,0f ) ;
  }

  @Test
  public void test380() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-319.0f,656.0f,0f,805.0f,0f,0f,0f,0f,0f,-149.0f,-1179.0f,-704.0f,-868.0f,340.0f,-386.0f,-1403,99.93058f,27.689234f,-67.425446f,0f,0f,0f ) ;
  }

  @Test
  public void test381() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,32.447563f,-47.534267f,0f,0.0f,0f,0f,0f,0f,0f,-49.280785f,36.839733f,35.52315f,0f,0f,0f,323,-4.346204f,0.0198016f,-69.794106f,0f,0f,0f ) ;
  }

  @Test
  public void test382() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,327.0f,1742.0f,0f,811.0f,0f,0f,0f,0f,0f,-133.0f,232.0f,-108.0f,828.0f,542.0f,142.0f,-147,0.91480845f,7.600728f,15.20092f,0f,0f,0f ) ;
  }

  @Test
  public void test383() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,33.064846f,-24.567463f,0f,-30.870562f,0f,0f,0f,0f,0f,-44.963245f,-97.19656f,-63.10812f,0f,0f,0f,-1857,0.90511316f,-0.19864313f,0.375921f,0f,0f,0f ) ;
  }

  @Test
  public void test384() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-33.0f,452.0f,0f,398.0f,0f,0f,0f,0f,0f,3.0f,-326.0f,-711.0f,1650.0f,-172.0f,86.0f,578,-0.21768257f,0.13783729f,0.5469073f,0f,0f,0f ) ;
  }

  @Test
  public void test385() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-331.0f,464.0f,0f,1273.0f,0f,0f,0f,0f,0f,497.0f,-222.0f,-284.0f,34.0f,169.0f,689.0f,-1014,13.835384f,-44.340572f,58.872517f,0f,0f,0f ) ;
  }

  @Test
  public void test386() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-334.0f,386.0f,-270.0f,-600.0f,0f,0f,0f,0f,0f,134.0f,215.0f,-695.0f,-581.0f,70.0f,-265.0f,-780,-28.199053f,-37.349895f,82.89742f,-76.845116f,27.287533f,0f ) ;
  }

  @Test
  public void test387() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,33.73992f,-18.40057f,0f,9.568954f,0f,0f,0f,0f,0f,58.29701f,99.684906f,100.0f,0f,0f,0f,837,-0.39900774f,-0.77509516f,0.48991868f,0f,0f,0f ) ;
  }

  @Test
  public void test388() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3374.0f,-177.0f,0f,250.0f,0f,0f,0f,0f,0f,69.0f,-906.0f,-2544.0f,848.0f,-895.0f,-89.0f,-523,-0.3238044f,-0.46515733f,0.20325744f,0f,0f,0f ) ;
  }

  @Test
  public void test389() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,338.0f,325.0f,0f,-1307.0f,0f,0f,0f,0f,0f,909.0f,116.0f,-955.0f,-1093.0f,2063.0f,-2438.0f,-234,-0.39134234f,0.23984365f,0.8884403f,0f,0f,0f ) ;
  }

  @Test
  public void test390() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-340.0f,294.0f,0f,315.0f,0f,0f,0f,0f,0f,1306.0f,511.0f,943.0f,709.0f,66.0f,-794.0f,900,-0.98635167f,0.16458231f,-0.0048045847f,0f,0f,0f ) ;
  }

  @Test
  public void test391() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,3415.0f,-400.0f,0f,341.0f,0f,0f,0f,0f,0f,-1088.0f,-490.0f,-681.0f,-1100.0f,624.0f,-872.0f,-205,0.24929956f,0.081773266f,0.9649678f,0f,0f,0f ) ;
  }

  @Test
  public void test392() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-34.320587f,28.97763f,0f,0f,0f,0f,0f,0f,0f,76.13768f,100.0f,84.38539f,-427.0f,611.0f,-333.0f,-100,100.0f,-25.292656f,-60.713135f,0f,0f,0f ) ;
  }

  @Test
  public void test393() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,352.0f,-716.0f,0f,379.0f,0f,0f,0f,0f,0f,369.0f,324.0f,923.0f,752.0f,942.0f,-631.0f,1564,-76.11891f,-0.7487125f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test394() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-353.0f,794.0f,0f,885.0f,0f,0f,0f,0f,0f,663.0f,356.0f,-1587.0f,-559.0f,-1397.0f,-934.0f,-417,0.04779926f,-0.614139f,0.78009564f,0f,0f,0f ) ;
  }

  @Test
  public void test395() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-354.0f,958.0f,0f,306.0f,0f,0f,0f,0f,0f,619.0f,-288.0f,-453.0f,726.0f,-335.0f,-819.0f,314,68.449425f,27.739935f,75.896454f,0f,0f,0f ) ;
  }

  @Test
  public void test396() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,35.790928f,81.15778f,0f,0f,0f,0f,0f,0f,0f,-33.77832f,-97.62104f,-57.50802f,-536.0f,-849.0f,-125.0f,973,38.639835f,10.514188f,-0.95838225f,0f,0f,0f ) ;
  }

  @Test
  public void test397() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,362.0f,1166.0f,0f,1770.0f,0f,0f,0f,0f,0f,500.0f,-193.0f,-457.0f,-107.0f,476.0f,-965.0f,970,-0.44209757f,-0.3992787f,-0.3150722f,0f,0f,0f ) ;
  }

  @Test
  public void test398() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,36.489304f,33.485775f,0f,0f,0f,0f,0f,0f,0f,46.982685f,56.816116f,94.647385f,615.0f,831.0f,-576.0f,194,0.10708235f,-0.86777455f,0.46753696f,0f,0f,0f ) ;
  }

  @Test
  public void test399() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-366.0f,0.0f,0f,1327.0f,0f,0f,0f,0f,0f,-280.0f,655.0f,-226.0f,1501.0f,449.0f,-567.0f,1542,37.070988f,-81.963295f,17.418074f,0f,0f,0f ) ;
  }

  @Test
  public void test400() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-366.0f,-461.0f,0f,366.0f,0f,0f,0f,0f,0f,720.0f,319.0f,-13.0f,-306.0f,792.0f,2458.0f,-1171,-0.3791228f,-0.030178102f,0.13655138f,0f,0f,0f ) ;
  }

  @Test
  public void test401() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-368.0f,402.0f,0f,373.0f,0f,0f,0f,0f,0f,-620.0f,656.0f,286.0f,-227.0f,-536.0f,737.0f,-780,-76.360916f,-100.0f,63.83298f,0f,0f,0f ) ;
  }

  @Test
  public void test402() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-374.0f,142.0f,0f,-1.0f,0f,0f,0f,0f,0f,-1942.0f,893.0f,747.0f,-1263.0f,833.0f,1093.0f,-1091,0.35655472f,-0.028531823f,-0.050188232f,0f,0f,0f ) ;
  }

  @Test
  public void test403() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-383.0f,-889.0f,0f,630.0f,0f,0f,0f,0f,0f,-795.0f,-206.0f,958.0f,-930.0f,-673.0f,496.0f,-138,17.318665f,-49.204544f,-60.949238f,0f,0f,0f ) ;
  }

  @Test
  public void test404() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,386.0f,-2.0f,0f,730.0f,0f,0f,0f,0f,0f,-522.0f,257.0f,-158.0f,-616.0f,-1032.0f,355.0f,602,-1.1564187f,-3.4888105f,0.04382103f,0f,0f,0f ) ;
  }

  @Test
  public void test405() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-392.0f,-167.0f,0f,633.0f,0f,0f,0f,0f,0f,-27.0f,598.0f,736.0f,663.0f,994.0f,629.0f,-118,-68.98389f,-25.066753f,-9.327438f,0f,0f,0f ) ;
  }

  @Test
  public void test406() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,39.524536f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-43.333496f,-16.031326f,-47.248634f,0f,0f,0f,-491,64.55151f,20.922415f,20.99565f,0f,0f,0f ) ;
  }

  @Test
  public void test407() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-397.0f,73.0f,-45.0f,470.0f,0f,0f,0f,0f,0f,-815.0f,-217.0f,84.0f,-961.0f,-305.0f,214.0f,91,-13.924735f,28.012278f,-69.58166f,0f,-100.0f,0f ) ;
  }

  @Test
  public void test408() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-402.0f,-578.0f,0f,102.0f,0f,0f,0f,0f,0f,-458.0f,25.0f,-881.0f,-946.0f,-323.0f,139.0f,781,-81.88953f,-53.592083f,47.24709f,0f,0f,0f ) ;
  }

  @Test
  public void test409() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-403.0f,906.0f,-421.0f,-998.0f,0f,0f,0f,0f,0f,-285.0f,935.0f,-888.0f,-504.0f,569.0f,537.0f,215,-100.0f,63.46698f,100.0f,6.819712f,83.46216f,0f ) ;
  }

  @Test
  public void test410() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,4.0f,-1761.0f,0f,932.0f,0f,0f,0f,0f,0f,208.0f,-206.0f,873.0f,189.0f,539.0f,82.0f,1242,59.27815f,45.051975f,-113.048096f,0f,0f,0f ) ;
  }

  @Test
  public void test411() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-417.0f,786.0f,-1201.0f,2904.0f,0f,0f,0f,0f,0f,-576.0f,461.0f,-130.0f,288.0f,509.0f,872.0f,-551,62.524494f,69.2871f,-31.328876f,-96.33604f,0f,0f ) ;
  }

  @Test
  public void test412() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-424.0f,-326.0f,0f,254.0f,0f,0f,0f,0f,0f,-676.0f,-489.0f,-1117.0f,217.0f,-894.0f,91.0f,317,0.9029706f,-23.132792f,27.07825f,0f,0f,0f ) ;
  }

  @Test
  public void test413() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-42.64568f,0.0f,0f,0f,0f,0f,0f,0f,0f,-1.5679972f,100.0f,19.729635f,0f,0f,0f,1108,0.8281361f,0.11183525f,-0.5492572f,0f,0f,0f ) ;
  }

  @Test
  public void test414() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,429.0f,-1162.0f,0f,781.0f,0f,0f,0f,0f,0f,774.0f,-622.0f,1214.0f,1518.0f,-873.0f,1470.0f,745,-0.24011546f,0.8254983f,0.5107809f,0f,0f,0f ) ;
  }

  @Test
  public void test415() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,429.0f,286.0f,0f,912.0f,0f,0f,0f,0f,0f,958.0f,-906.0f,441.0f,410.0f,-342.0f,-134.0f,752,71.38249f,82.30233f,-5.1541653f,0f,0f,0f ) ;
  }

  @Test
  public void test416() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,430.0f,52.0f,0f,392.0f,0f,0f,0f,0f,0f,238.0f,-270.0f,828.0f,832.0f,-703.0f,-36.0f,816,-71.40727f,-27.464622f,11.569356f,0f,0f,0f ) ;
  }

  @Test
  public void test417() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-432.0f,1005.0f,0f,188.0f,0f,0f,0f,0f,0f,-40.0f,58.0f,-44.0f,-783.0f,-616.0f,-156.0f,907,61.401623f,66.2904f,31.790926f,0f,0f,0f ) ;
  }

  @Test
  public void test418() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-439.0f,-323.0f,0f,255.0f,0f,0f,0f,0f,0f,-1399.0f,-14.0f,-500.0f,-1178.0f,-789.0f,-549.0f,63,94.21315f,-16.372952f,19.749506f,0f,0f,0f ) ;
  }

  @Test
  public void test419() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,44.484013f,0f,0f,0f,0f,0f,0f,0f,0f,63.17633f,-21.095678f,100.0f,0f,0f,0f,82,-0.42361727f,0.11716235f,-0.89404005f,0f,0f,0f ) ;
  }

  @Test
  public void test420() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,456.0f,-162.0f,533.0f,244.0f,0f,0f,0f,0f,0f,-288.0f,535.0f,677.0f,-372.0f,258.0f,526.0f,-236,79.25215f,37.74569f,-67.923485f,-54.39992f,2.3378844f,0f ) ;
  }

  @Test
  public void test421() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-46.0f,-802.0f,0f,254.0f,0f,0f,0f,0f,0f,207.0f,24.0f,-702.0f,-820.0f,-460.0f,-438.0f,-107,-13.3015f,-48.04309f,14.199883f,0f,0f,0f ) ;
  }

  @Test
  public void test422() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,461.0f,1462.0f,0f,1531.0f,0f,0f,0f,0f,0f,-918.0f,-2086.0f,-1078.0f,3233.0f,493.0f,-686.0f,-433,-0.90340304f,0.38254607f,0.12970923f,0f,0f,0f ) ;
  }

  @Test
  public void test423() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-464.0f,-680.0f,0f,255.0f,0f,0f,0f,0f,0f,568.0f,-675.0f,-875.0f,-20.0f,-705.0f,-824.0f,-579,54.589745f,3.1728213f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test424() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,46.926533f,100.0f,0f,0f,0f,0f,0f,0f,0f,94.82505f,-3.8510036f,26.60674f,0f,0f,0f,845,-0.95000535f,-0.081307985f,0.30146128f,0f,0f,0f ) ;
  }

  @Test
  public void test425() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-47.201336f,-98.66234f,0f,54.918823f,0f,0f,0f,0f,0f,92.24853f,98.77204f,26.59467f,0f,0f,0f,-366,-0.21468884f,-0.14784196f,0.014229898f,0f,0f,0f ) ;
  }

  @Test
  public void test426() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-47.201885f,-34.07379f,0f,-49.30295f,0f,0f,0f,0f,0f,8.511216f,14.349053f,85.59602f,0f,0f,0f,797,1.2008477f,7.5553193f,-48.497604f,0f,0f,0f ) ;
  }

  @Test
  public void test427() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-472.0f,1.0f,0f,325.0f,0f,0f,0f,0f,0f,-738.0f,944.0f,-172.0f,697.0f,924.0f,-59.0f,-43,99.61213f,-100.0f,12.457928f,0f,0f,0f ) ;
  }

  @Test
  public void test428() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-489.0f,723.0f,-475.0f,325.0f,0f,0f,0f,0f,0f,917.0f,855.0f,-199.0f,478.0f,-483.0f,-949.0f,-705,9.272668f,-36.58068f,-27.671183f,77.096275f,0f,0f ) ;
  }

  @Test
  public void test429() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,490.0f,-974.0f,627.0f,-82.0f,0f,0f,0f,0f,0f,404.0f,-567.0f,55.0f,-45.0f,452.0f,484.0f,-7,62.871098f,-60.1759f,33.862648f,-46.507854f,87.10734f,36.23857f ) ;
  }

  @Test
  public void test430() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-497.0f,234.0f,0f,765.0f,0f,0f,0f,0f,0f,-737.0f,-119.0f,-77.0f,520.0f,-766.0f,-571.0f,-904,75.85025f,64.52543f,85.99483f,0f,0f,0f ) ;
  }

  @Test
  public void test431() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-500.0f,-187.0f,0f,256.0f,0f,0f,0f,0f,0f,45.0f,-422.0f,284.0f,1059.0f,-791.0f,-585.0f,16,18.620792f,84.311165f,-59.450443f,0f,0f,0f ) ;
  }

  @Test
  public void test432() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-505.0f,-96.0f,0f,255.0f,0f,0f,0f,0f,0f,9.0f,587.0f,9.0f,-103.0f,348.0f,325.0f,228,-130.37988f,-67.44801f,86.217064f,0f,0f,0f ) ;
  }

  @Test
  public void test433() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-506.0f,1112.0f,0f,743.0f,0f,0f,0f,0f,0f,58.0f,-46.0f,-898.0f,-1045.0f,-367.0f,-49.0f,-642,-0.7607208f,0.032404788f,0.27334592f,0f,0f,0f ) ;
  }

  @Test
  public void test434() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-50.72969f,81.214874f,0f,0f,0f,0f,0f,0f,0f,-1.0588988f,90.90493f,1.4263873f,947.0f,524.0f,-987.0f,259,6.432331f,-87.34788f,-2.0897403f,0f,0f,0f ) ;
  }

  @Test
  public void test435() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-510.0f,2952.0f,0f,447.0f,0f,0f,0f,0f,0f,-459.0f,-201.0f,660.0f,-1544.0f,-1122.0f,18.0f,778,-0.18018551f,0.9807322f,0.07713972f,0f,0f,0f ) ;
  }

  @Test
  public void test436() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-511.0f,-999.0f,0f,2243.0f,0f,0f,0f,0f,0f,267.0f,84.0f,280.0f,-325.0f,-333.0f,410.0f,1311,0.09241245f,0.17966458f,-0.2718104f,0f,0f,0f ) ;
  }

  @Test
  public void test437() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-525.0f,1310.0f,0f,628.0f,0f,0f,0f,0f,0f,332.0f,700.0f,565.0f,2324.0f,491.0f,1513.0f,419,0.14649133f,-0.1951475f,-0.18281743f,0f,0f,0f ) ;
  }

  @Test
  public void test438() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,528.0f,704.0f,846.0f,-425.0f,0f,0f,0f,0f,0f,-367.0f,-712.0f,658.0f,575.0f,648.0f,415.0f,360,-23.579407f,22.147655f,-91.625595f,-12.742769f,0f,0f ) ;
  }

  @Test
  public void test439() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-52.992653f,83.27857f,0f,0f,0f,0f,0f,0f,0f,-41.32804f,-88.38033f,47.216995f,-657.0f,291.0f,-388.0f,892,-34.967083f,-0.71320087f,-98.697235f,0f,0f,0f ) ;
  }

  @Test
  public void test440() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-531.0f,502.0f,0f,1525.0f,0f,0f,0f,0f,0f,-137.0f,92.0f,48.0f,-763.0f,-1655.0f,793.0f,326,0.15029927f,0.1235148f,0.02019177f,0f,0f,0f ) ;
  }

  @Test
  public void test441() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,53.6969f,0f,0f,0f,0f,0f,0f,0f,0f,45.507652f,52.19328f,-100.0f,0f,0f,0f,-468,-0.9883821f,0.004831498f,0.15191273f,0f,0f,0f ) ;
  }

  @Test
  public void test442() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,53.822872f,16.517756f,0f,0f,0f,0f,0f,0f,0f,-67.510796f,-16.19872f,52.162624f,217.0f,762.0f,233.0f,-628,-70.99781f,87.35054f,-64.78522f,0f,0f,0f ) ;
  }

  @Test
  public void test443() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-54.0f,-333.0f,0f,771.0f,0f,0f,0f,0f,0f,397.0f,-965.0f,437.0f,37.0f,-445.0f,407.0f,622,-54.798172f,38.5645f,-69.92818f,0f,0f,0f ) ;
  }

  @Test
  public void test444() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,54.0f,-614.0f,0f,458.0f,0f,0f,0f,0f,0f,852.0f,542.0f,874.0f,-602.0f,-189.0f,-171.0f,318,-72.76828f,-50.29263f,88.67345f,0f,0f,0f ) ;
  }

  @Test
  public void test445() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,54.99504f,0.0f,0f,0f,0f,0f,0f,0f,0f,4.0280557f,72.35762f,-84.46246f,0f,0f,0f,661,0.093485676f,-0.8401632f,-0.1394703f,0f,0f,0f ) ;
  }

  @Test
  public void test446() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,550.0f,0.0f,0f,665.0f,0f,0f,0f,0f,0f,-672.0f,-865.0f,-601.0f,2120.0f,499.0f,-924.0f,2873,-0.3933152f,-0.21885255f,0.8483408f,0f,0f,0f ) ;
  }

  @Test
  public void test447() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-553.0f,11.0f,-446.0f,771.0f,0f,0f,0f,0f,0f,718.0f,860.0f,739.0f,-208.0f,-922.0f,-608.0f,-951,-20.435045f,-54.871212f,83.709885f,-57.196167f,35.910664f,0f ) ;
  }

  @Test
  public void test448() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-5.557607E-16f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,-97.581825f,67.72132f,54.540165f,0f,0f,0f,-2833,0.6657103f,0.58234614f,0.46658635f,0f,0f,0f ) ;
  }

  @Test
  public void test449() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,556.0f,722.0f,0f,659.0f,0f,0f,0f,0f,0f,2231.0f,287.0f,532.0f,-1551.0f,-496.0f,955.0f,517,-0.27315813f,0.2515384f,0.16200289f,0f,0f,0f ) ;
  }

  @Test
  public void test450() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,556.0f,-750.0f,0f,419.0f,0f,0f,0f,0f,0f,-260.0f,-874.0f,372.0f,-514.0f,71.0f,846.0f,-748,-26.204668f,41.786247f,-91.031746f,0f,0f,0f ) ;
  }

  @Test
  public void test451() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-56.0f,657.0f,0f,249.0f,0f,0f,0f,0f,0f,-83.0f,279.0f,179.0f,197.0f,-140.0f,311.0f,-226,169.9452f,-29.352661f,-21.793135f,0f,0f,0f ) ;
  }

  @Test
  public void test452() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-562.0f,-1140.0f,0f,980.0f,0f,0f,0f,0f,0f,569.0f,1339.0f,261.0f,-232.0f,-54.0f,783.0f,-779,-37.87673f,-37.091244f,-41.614826f,0f,0f,0f ) ;
  }

  @Test
  public void test453() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-576.0f,-1323.0f,0f,1406.0f,0f,0f,0f,0f,0f,322.0f,964.0f,58.0f,-66.0f,87.0f,-1077.0f,853,41.047928f,-95.53516f,-116.43162f,0f,0f,0f ) ;
  }

  @Test
  public void test454() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,582.0f,990.0f,0f,581.0f,0f,0f,0f,0f,0f,498.0f,211.0f,583.0f,-507.0f,-273.0f,532.0f,-612,28.94537f,32.353046f,-36.987244f,0f,0f,0f ) ;
  }

  @Test
  public void test455() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,584.0f,708.0f,0f,1672.0f,0f,0f,0f,0f,0f,-535.0f,219.0f,809.0f,820.0f,-453.0f,665.0f,-112,-39.956226f,-38.673595f,-26.818872f,0f,0f,0f ) ;
  }

  @Test
  public void test456() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,587.0f,571.0f,0f,1549.0f,0f,0f,0f,0f,0f,-131.0f,712.0f,1036.0f,-531.0f,-807.0f,324.0f,-135,0.79805815f,-0.6993064f,0.581517f,0f,0f,0f ) ;
  }

  @Test
  public void test457() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-594.0f,-635.0f,939.0f,-30.0f,0f,0f,0f,0f,0f,-472.0f,251.0f,740.0f,-706.0f,-147.0f,-167.0f,-210,-42.229267f,69.21589f,58.724445f,12.836056f,-29.781876f,0f ) ;
  }

  @Test
  public void test458() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,595.0f,1903.0f,0f,329.0f,0f,0f,0f,0f,0f,-137.0f,-88.0f,-507.0f,435.0f,-404.0f,-451.0f,243,0.075631656f,-0.7770837f,0.21752748f,0f,0f,0f ) ;
  }

  @Test
  public void test459() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,60.08809f,11.94302f,0f,0f,0f,0f,0f,0f,0f,45.153816f,13.500323f,-62.366188f,956.0f,-1133.0f,-340.0f,-930,-0.58754116f,0.7108338f,-0.12273652f,0f,0f,0f ) ;
  }

  @Test
  public void test460() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-601.0f,-1231.0f,0f,257.0f,0f,0f,0f,0f,0f,-235.0f,-332.0f,-78.0f,497.0f,-1763.0f,-919.0f,3027,-0.047946323f,0.78687656f,-0.07317748f,0f,0f,0f ) ;
  }

  @Test
  public void test461() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,603.0f,1969.0f,0f,385.0f,0f,0f,0f,0f,0f,288.0f,-242.0f,-48.0f,450.0f,343.0f,958.0f,304,-58.602f,-54.647068f,-76.0997f,0f,0f,0f ) ;
  }

  @Test
  public void test462() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,6.0f,1098.0f,0f,-5.0f,0f,0f,0f,0f,0f,-2005.0f,1214.0f,769.0f,-86.0f,-2276.0f,752.0f,-67,0.50389653f,1.278292f,-0.7395404f,0f,0f,0f ) ;
  }

  @Test
  public void test463() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-61.0f,957.0f,0f,-516.0f,0f,0f,0f,0f,0f,-764.0f,-961.0f,-27.0f,835.0f,-26.0f,472.0f,828,34.955246f,89.15261f,-20.897886f,0f,0f,0f ) ;
  }

  @Test
  public void test464() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-612.0f,2025.0f,0f,-1.0f,0f,0f,0f,0f,0f,-606.0f,-676.0f,-164.0f,300.0f,1409.0f,2148.0f,-41,-59.701553f,61.299282f,-32.06814f,0f,0f,0f ) ;
  }

  @Test
  public void test465() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,612.0f,-424.0f,0f,135.0f,0f,0f,0f,0f,0f,29.0f,111.0f,-182.0f,-675.0f,834.0f,401.0f,1024,-2.4264627f,-1.4912884f,4.6477304f,0f,0f,0f ) ;
  }

  @Test
  public void test466() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,613.0f,251.0f,0f,215.0f,0f,0f,0f,0f,0f,261.0f,1310.0f,-118.0f,-405.0f,-12.0f,-1028.0f,354,-0.20242567f,-0.10652566f,-0.9479509f,0f,0f,0f ) ;
  }

  @Test
  public void test467() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-61.440468f,-95.84506f,0f,0.0f,0f,0f,0f,0f,0f,43.481976f,-100.0f,27.815453f,0f,0f,0f,-135,0.5869575f,0.378751f,0.4115479f,0f,0f,0f ) ;
  }

  @Test
  public void test468() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,615.0f,4.0f,0f,533.0f,0f,0f,0f,0f,0f,518.0f,-143.0f,229.0f,-339.0f,168.0f,871.0f,854,-109.908295f,18.053581f,-5.667047f,0f,0f,0f ) ;
  }

  @Test
  public void test469() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-616.0f,1099.0f,-123.0f,1311.0f,0f,0f,0f,0f,0f,-892.0f,88.0f,242.0f,-142.0f,-925.0f,-682.0f,251,-19.340582f,48.326622f,-88.8618f,-84.38546f,0f,0f ) ;
  }

  @Test
  public void test470() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-618.0f,753.0f,0f,254.0f,0f,0f,0f,0f,0f,81.0f,122.0f,638.0f,528.0f,483.0f,809.0f,1369,-49.264137f,-84.276764f,22.370104f,0f,0f,0f ) ;
  }

  @Test
  public void test471() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-618.0f,87.0f,174.0f,-722.0f,0f,0f,0f,0f,0f,-441.0f,836.0f,-174.0f,-82.0f,198.0f,391.0f,773,-72.0757f,-70.095116f,25.480204f,16.919718f,0f,0f ) ;
  }

  @Test
  public void test472() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,62.0f,-383.0f,0f,1112.0f,0f,0f,0f,0f,0f,-729.0f,1023.0f,152.0f,-174.0f,1148.0f,509.0f,-359,0.8644507f,0.0874433f,0.3102751f,0f,0f,0f ) ;
  }

  @Test
  public void test473() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-632.0f,-697.0f,0f,251.0f,0f,0f,0f,0f,0f,936.0f,-384.0f,613.0f,670.0f,-766.0f,-397.0f,-318,-27.574678f,-2.039151f,-62.122272f,0f,0f,0f ) ;
  }

  @Test
  public void test474() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,635.0f,1341.0f,0f,-1575.0f,0f,0f,0f,0f,0f,-557.0f,821.0f,1429.0f,-929.0f,5.0f,-660.0f,795,0.9463772f,0.13086176f,0.2502892f,0f,0f,0f ) ;
  }

  @Test
  public void test475() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-637.0f,1188.0f,0f,955.0f,0f,0f,0f,0f,0f,-353.0f,589.0f,-270.0f,-442.0f,-225.0f,87.0f,691,92.5943f,100.0f,97.089676f,0f,0f,0f ) ;
  }

  @Test
  public void test476() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-63.79872f,0.0f,0f,54.84925f,0f,0f,0f,0f,0f,45.43074f,-24.451508f,-49.914738f,0f,0f,0f,-305,-57.184242f,-16.244242f,24.129652f,0f,0f,0f ) ;
  }

  @Test
  public void test477() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,644.0f,-3359.0f,0f,90.0f,0f,0f,0f,0f,0f,-292.0f,1401.0f,-840.0f,130.0f,31.0f,6.0f,1616,0.99350804f,0.9621595f,1.2593822f,0f,0f,0f ) ;
  }

  @Test
  public void test478() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,64.44812f,-60.884956f,0f,0f,0f,0f,0f,0f,0f,-4.067215f,86.230064f,81.67578f,0f,0f,0f,586,-6.6104636f,-16.287766f,-80.29486f,0f,0f,0f ) ;
  }

  @Test
  public void test479() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,65.2334f,29.744755f,0f,0f,0f,0f,0f,0f,0f,-61.82978f,70.66838f,4.596561f,0f,0f,0f,-576,58.23934f,-44.45739f,61.882347f,0f,0f,0f ) ;
  }

  @Test
  public void test480() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-654.0f,600.0f,-724.0f,676.0f,0f,0f,0f,0f,0f,-94.0f,515.0f,-496.0f,-246.0f,-689.0f,64.0f,159,-15.850666f,-87.011856f,-87.34086f,18.374628f,-91.2052f,0f ) ;
  }

  @Test
  public void test481() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,65.64909f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,6.590652f,41.88981f,0f,0f,0f,290,-0.81245905f,0.24212605f,0.14285533f,0f,0f,0f ) ;
  }

  @Test
  public void test482() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-659.0f,540.0f,0f,255.0f,0f,0f,0f,0f,0f,623.0f,327.0f,-301.0f,-512.0f,174.0f,-1794.0f,-963,100.0f,-98.47231f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test483() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-659.0f,701.0f,0f,704.0f,0f,0f,0f,0f,0f,823.0f,670.0f,-1045.0f,844.0f,384.0f,81.0f,-506,-0.838232f,0.07264771f,-0.048841543f,0f,0f,0f ) ;
  }

  @Test
  public void test484() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-66.0f,-146.0f,648.0f,0f,0f,0f,0f,0f,0f,64.0f,481.0f,-318.0f,294.0f,-489.0f,-107.0f,234,-17.351616f,-77.44984f,-93.31436f,-54.62536f,0f,0f ) ;
  }

  @Test
  public void test485() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-661.0f,-1914.0f,0f,253.0f,0f,0f,0f,0f,0f,273.0f,-1985.0f,-1951.0f,1303.0f,-1250.0f,1205.0f,-693,-0.07455816f,0.7084874f,-0.11957855f,0f,0f,0f ) ;
  }

  @Test
  public void test486() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-661.0f,-69.0f,0f,61.0f,0f,0f,0f,0f,0f,-234.0f,-517.0f,-21.0f,112.0f,-103.0f,-206.0f,231,128.6367f,-56.753f,-21.43773f,0f,0f,0f ) ;
  }

  @Test
  public void test487() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-669.0f,117.0f,703.0f,904.0f,0f,0f,0f,0f,0f,303.0f,787.0f,-461.0f,-968.0f,463.0f,176.0f,392,60.769104f,-49.476112f,-31.344505f,27.330471f,0f,0f ) ;
  }

  @Test
  public void test488() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,67.0f,302.0f,0f,-517.0f,0f,0f,0f,0f,0f,686.0f,-27.0f,-861.0f,-982.0f,-915.0f,-937.0f,-697,-3.9605832f,15.182193f,-0.6345941f,0f,0f,0f ) ;
  }

  @Test
  public void test489() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-68.0f,288.0f,0f,137.0f,0f,0f,0f,0f,0f,307.0f,703.0f,-172.0f,149.0f,396.0f,-395.0f,-671,100.0f,-100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test490() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-682.0f,268.0f,0f,807.0f,0f,0f,0f,0f,0f,-153.0f,-230.0f,-79.0f,404.0f,40.0f,-1309.0f,407,87.695915f,-92.67893f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test491() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,685.0f,358.0f,0f,1089.0f,0f,0f,0f,0f,0f,-842.0f,-430.0f,-468.0f,865.0f,-808.0f,-817.0f,60,6.694058f,82.22417f,87.18638f,0f,0f,0f ) ;
  }

  @Test
  public void test492() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-686.0f,1300.0f,0f,2081.0f,0f,0f,0f,0f,0f,221.0f,-170.0f,-643.0f,-1794.0f,-157.0f,-584.0f,491,0.08253376f,1.5124905f,-0.13761526f,0f,0f,0f ) ;
  }

  @Test
  public void test493() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,687.0f,0.0f,0f,468.0f,0f,0f,0f,0f,0f,2362.0f,-429.0f,-555.0f,-1350.0f,650.0f,-940.0f,-907,-0.3898968f,0.92370296f,0.060108975f,0f,0f,0f ) ;
  }

  @Test
  public void test494() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-687.0f,-753.0f,0f,224.0f,0f,0f,0f,0f,0f,-831.0f,-245.0f,338.0f,-1053.0f,609.0f,-695.0f,-835,16.70466f,58.249866f,80.82874f,0f,0f,0f ) ;
  }

  @Test
  public void test495() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-68.74187f,-100.0f,0f,-75.59264f,0f,0f,0f,0f,0f,-66.430695f,-3.4246302f,-3.3379097f,0f,0f,0f,-2152,0.092882015f,-0.99567676f,-9.1242034E-4f,0f,0f,0f ) ;
  }

  @Test
  public void test496() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-68.90529f,-79.22141f,0f,0.0f,0f,0f,0f,0f,0f,50.93134f,-14.256821f,33.214077f,0f,0f,0f,-692,-59.17101f,-55.770824f,58.55922f,0f,0f,0f ) ;
  }

  @Test
  public void test497() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-689.0f,1118.0f,0f,38.0f,0f,0f,0f,0f,0f,801.0f,-39.0f,-874.0f,496.0f,-507.0f,292.0f,725,-91.153595f,19.920351f,-84.428696f,0f,0f,0f ) ;
  }

  @Test
  public void test498() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,6.9455686f,5.656895f,0f,0f,0f,0f,0f,0f,0f,-99.99997f,100.0f,100.0f,1141.0f,85.0f,-202.0f,744,0.022857198f,-0.92729235f,-0.37363952f,0f,0f,0f ) ;
  }

  @Test
  public void test499() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-697.0f,521.0f,-411.0f,-55.0f,0f,0f,0f,0f,0f,299.0f,91.0f,-179.0f,799.0f,-384.0f,-646.0f,-774,-100.0f,-51.56277f,100.0f,100.0f,100.0f,100.0f ) ;
  }

  @Test
  public void test500() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-7.0f,527.0f,-355.0f,0f,0f,0f,0f,0f,0f,-284.0f,-785.0f,564.0f,968.0f,-558.0f,-289.0f,200,100.0f,63.3056f,36.830296f,81.52794f,0f,0f ) ;
  }

  @Test
  public void test501() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-73.0f,467.0f,0f,464.0f,0f,0f,0f,0f,0f,1103.0f,-1182.0f,372.0f,-1388.0f,68.0f,-691.0f,768,0.39102596f,0.8033873f,-0.3343339f,0f,0f,0f ) ;
  }

  @Test
  public void test502() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-73.0f,948.0f,-861.0f,-6.0f,0f,0f,0f,0f,0f,1790.0f,-732.0f,-33.0f,-257.0f,-1053.0f,984.0f,-966,-0.04990074f,0.1653633f,-0.08276533f,-36.846733f,0f,0f ) ;
  }

  @Test
  public void test503() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,732.0f,-1701.0f,0f,863.0f,0f,0f,0f,0f,0f,62.0f,-691.0f,-689.0f,1942.0f,612.0f,-442.0f,1505,-0.70974857f,0.99676824f,0.13136715f,0f,0f,0f ) ;
  }

  @Test
  public void test504() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-73.28051f,-16.332615f,0f,0f,0f,0f,0f,0f,0f,-20.563793f,18.344143f,-8.256448f,0f,0f,0f,300,-0.13588026f,0.0051035085f,0.34979242f,0f,0f,0f ) ;
  }

  @Test
  public void test505() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,738.0f,927.0f,0f,-1.0f,0f,0f,0f,0f,0f,1381.0f,1062.0f,-668.0f,281.0f,580.0f,-918.0f,609,0.119854115f,-0.030841293f,0.99232566f,0f,0f,0f ) ;
  }

  @Test
  public void test506() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,74.0f,-473.0f,0f,127.0f,0f,0f,0f,0f,0f,-796.0f,190.0f,-86.0f,93.0f,241.0f,-328.0f,1173,35.797653f,89.87749f,-91.69534f,0f,0f,0f ) ;
  }

  @Test
  public void test507() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-74.91365f,0.0f,0f,-24.561878f,0f,0f,0f,0f,0f,83.41958f,32.318836f,-3.5660264f,0f,0f,0f,691,-34.971706f,24.396357f,27.794437f,0f,0f,0f ) ;
  }

  @Test
  public void test508() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,74.92823f,-100.0f,0f,-100.0f,0f,0f,0f,0f,0f,56.84277f,-8.18653f,19.507812f,0f,0f,0f,1196,-0.37097207f,-0.30754095f,-0.72405225f,0f,0f,0f ) ;
  }

  @Test
  public void test509() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,76.0672f,67.98589f,0f,0f,0f,0f,0f,0f,0f,51.094135f,-71.03983f,39.757015f,-734.0f,-739.0f,-401.0f,872,86.29507f,97.15246f,5.8904777f,0f,0f,0f ) ;
  }

  @Test
  public void test510() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-76.0f,-352.0f,756.0f,955.0f,0f,0f,0f,0f,0f,70.0f,-471.0f,-911.0f,-328.0f,378.0f,-701.0f,-752,-74.09909f,65.77009f,51.12935f,27.294262f,0f,0f ) ;
  }

  @Test
  public void test511() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-766.0f,0.0f,0f,572.0f,0f,0f,0f,0f,0f,-320.0f,-561.0f,-210.0f,593.0f,841.0f,14.0f,-467,25.26209f,35.295128f,-49.5673f,0f,0f,0f ) ;
  }

  @Test
  public void test512() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-767.0f,1183.0f,0f,25.0f,0f,0f,0f,0f,0f,-279.0f,733.0f,480.0f,-601.0f,744.0f,-276.0f,407,72.268616f,30.909378f,-5.195063f,0f,0f,0f ) ;
  }

  @Test
  public void test513() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,777.0f,1209.0f,0f,588.0f,0f,0f,0f,0f,0f,1300.0f,-180.0f,66.0f,-18.0f,-433.0f,-804.0f,-557,-0.80526966f,0.28915614f,0.49316964f,0f,0f,0f ) ;
  }

  @Test
  public void test514() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,783.0f,80.0f,0f,-170.0f,0f,0f,0f,0f,0f,232.0f,890.0f,463.0f,-936.0f,-922.0f,504.0f,-497,-16.903576f,-35.0351f,-52.06198f,0f,0f,0f ) ;
  }

  @Test
  public void test515() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-784.0f,343.0f,0f,255.0f,0f,0f,0f,0f,0f,141.0f,-258.0f,765.0f,-500.0f,-134.0f,47.0f,618,-100.0f,14.749314f,23.385101f,0f,0f,0f ) ;
  }

  @Test
  public void test516() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,785.0f,728.0f,0f,723.0f,0f,0f,0f,0f,0f,766.0f,-624.0f,-492.0f,534.0f,-525.0f,-292.0f,913,-23.374756f,-66.80579f,90.25576f,0f,0f,0f ) ;
  }

  @Test
  public void test517() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,79.50401f,-27.082092f,0f,0.0f,0f,0f,0f,0f,0f,-4.5019746f,-100.0f,51.722282f,0f,0f,0f,718,0.2801956f,0.1878222f,0.04805379f,0f,0f,0f ) ;
  }

  @Test
  public void test518() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,795.0f,-659.0f,0f,1447.0f,0f,0f,0f,0f,0f,-169.0f,-611.0f,601.0f,-932.0f,-646.0f,-918.0f,-2066,99.70822f,-37.969234f,-16.646967f,0f,0f,0f ) ;
  }

  @Test
  public void test519() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-796.0f,-622.0f,0f,493.0f,0f,0f,0f,0f,0f,-581.0f,-136.0f,-943.0f,271.0f,458.0f,-772.0f,277,96.88679f,-70.00091f,-48.92361f,0f,0f,0f ) ;
  }

  @Test
  public void test520() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-800.0f,207.0f,0f,846.0f,0f,0f,0f,0f,0f,-177.0f,913.0f,-553.0f,-515.0f,-523.0f,-698.0f,-740,-89.473885f,40.38164f,95.30798f,0f,0f,0f ) ;
  }

  @Test
  public void test521() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,801.0f,452.0f,0f,369.0f,0f,0f,0f,0f,0f,-682.0f,-483.0f,-30.0f,270.0f,-506.0f,344.0f,488,88.613594f,39.913677f,89.1285f,0f,0f,0f ) ;
  }

  @Test
  public void test522() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,80.5945f,-84.34442f,0f,0f,0f,0f,0f,0f,0f,-72.42655f,-3.0396955f,-37.577473f,0f,0f,0f,1877,0.85130644f,-0.39190024f,0.34884322f,0f,0f,0f ) ;
  }

  @Test
  public void test523() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-808.0f,836.0f,0f,1634.0f,0f,0f,0f,0f,0f,-64.0f,-217.0f,148.0f,-318.0f,-408.0f,-732.0f,229,9.1172085f,64.469154f,97.8512f,0f,0f,0f ) ;
  }

  @Test
  public void test524() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,80.929855f,-50.417118f,0f,91.8429f,0f,0f,0f,0f,0f,46.509605f,-27.482182f,-48.850006f,0f,0f,0f,-123,0.14050138f,0.817347f,-0.29873568f,0f,0f,0f ) ;
  }

  @Test
  public void test525() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-8.0f,1217.0f,0f,-2.0f,0f,0f,0f,0f,0f,2219.0f,-997.0f,1319.0f,-442.0f,459.0f,-1128.0f,-1982,-0.035694543f,-0.16150956f,-1.1867924f,0f,0f,0f ) ;
  }

  @Test
  public void test526() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,812.0f,695.0f,0f,1058.0f,0f,0f,0f,0f,0f,77.0f,134.0f,-302.0f,43.0f,1159.0f,519.0f,-863,-100.0f,34.332222f,-10.263186f,0f,0f,0f ) ;
  }

  @Test
  public void test527() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-813.0f,1102.0f,0f,880.0f,0f,0f,0f,0f,0f,-830.0f,1480.0f,1063.0f,-235.0f,-1528.0f,-183.0f,-859,0.74660206f,-0.34152207f,0.57091856f,0f,0f,0f ) ;
  }

  @Test
  public void test528() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-81.418495f,12.678002f,0f,0f,0f,0f,0f,0f,0f,-94.53691f,-80.48894f,85.10924f,0f,0f,0f,233,97.941895f,1.3580424f,-88.34163f,0f,0f,0f ) ;
  }

  @Test
  public void test529() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,819.0f,557.0f,0f,759.0f,0f,0f,0f,0f,0f,643.0f,669.0f,-912.0f,136.0f,-18.0f,176.0f,147,58.21901f,-77.029564f,50.586258f,0f,0f,0f ) ;
  }

  @Test
  public void test530() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-82.057304f,4.440892E-16f,0f,0f,0f,0f,0f,0f,0f,26.227936f,-51.276085f,-64.88358f,-308.0f,-911.0f,-345.0f,752,3.449679f,-1.3173009f,2.435589f,0f,0f,0f ) ;
  }

  @Test
  public void test531() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,821.0f,1161.0f,0f,1204.0f,0f,0f,0f,0f,0f,735.0f,-388.0f,-547.0f,-130.0f,72.0f,-233.0f,444,1.4981558f,0.68869656f,1.6504536f,0f,0f,0f ) ;
  }

  @Test
  public void test532() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,824.0f,1289.0f,0f,1070.0f,0f,0f,0f,0f,0f,791.0f,720.0f,956.0f,609.0f,1318.0f,-1229.0f,-123,87.094376f,-69.60585f,-19.639591f,0f,0f,0f ) ;
  }

  @Test
  public void test533() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-82.434f,0f,0f,0f,0f,0f,0f,0f,0f,-11.210068f,-44.70954f,100.0f,0f,0f,0f,11,0.12623721f,-0.019500041f,-0.8012139f,0f,0f,0f ) ;
  }

  @Test
  public void test534() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-83.0f,-9.0f,0f,317.0f,0f,0f,0f,0f,0f,827.0f,913.0f,858.0f,134.0f,802.0f,-537.0f,256,-71.81104f,42.000656f,-77.18712f,0f,0f,0f ) ;
  }

  @Test
  public void test535() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,833.0f,846.0f,0f,-1.0f,0f,0f,0f,0f,0f,908.0f,374.0f,676.0f,1045.0f,227.0f,722.0f,668,-0.23583153f,-0.8548755f,-0.1465625f,0f,0f,0f ) ;
  }

  @Test
  public void test536() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,83.50802f,-81.38273f,0f,20.460012f,0f,0f,0f,0f,0f,-38.54238f,-15.985981f,-65.8032f,0f,0f,0f,-23,-54.455124f,85.76367f,15.71528f,0f,0f,0f ) ;
  }

  @Test
  public void test537() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-835.0f,2898.0f,0f,2524.0f,0f,0f,0f,0f,0f,-614.0f,597.0f,-52.0f,-700.0f,-711.0f,119.0f,664,-0.28056788f,-1.6389581f,0.3517714f,0f,0f,0f ) ;
  }

  @Test
  public void test538() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-838.0f,1211.0f,-187.0f,2000.0f,0f,0f,0f,0f,0f,-44.0f,-58.0f,-338.0f,-149.0f,149.0f,540.0f,-780,-55.984158f,-39.28304f,14.028755f,-7.523485f,0f,0f ) ;
  }

  @Test
  public void test539() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-838.0f,-516.0f,0f,963.0f,0f,0f,0f,0f,0f,977.0f,-469.0f,108.0f,-794.0f,-99.0f,500.0f,-903,-17.063091f,-6.7203608f,48.718388f,0f,0f,0f ) ;
  }

  @Test
  public void test540() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-841.0f,-347.0f,0f,255.0f,0f,0f,0f,0f,0f,915.0f,533.0f,588.0f,975.0f,-252.0f,-930.0f,401,21.230587f,-86.88427f,-20.71739f,0f,0f,0f ) ;
  }

  @Test
  public void test541() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-844.0f,-638.0f,882.0f,-774.0f,0f,0f,0f,0f,0f,-806.0f,-88.0f,-647.0f,516.0f,487.0f,-194.0f,-656,47.155136f,-33.615105f,22.495403f,8.275746f,0f,0f ) ;
  }

  @Test
  public void test542() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-84.563354f,96.3933f,0f,0.0f,0f,0f,0f,0f,0f,92.56092f,-44.39769f,99.61673f,0f,0f,0f,-702,-0.45793727f,0.78024566f,0.4260401f,0f,0f,0f ) ;
  }

  @Test
  public void test543() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,848.0f,-562.0f,0f,1218.0f,0f,0f,0f,0f,0f,86.0f,-521.0f,-1296.0f,376.0f,990.0f,1310.0f,-239,-0.9984931f,0.03248946f,0.044226777f,0f,0f,0f ) ;
  }

  @Test
  public void test544() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-851.0f,560.0f,0f,-794.0f,0f,0f,0f,0f,0f,132.0f,161.0f,477.0f,14.0f,999.0f,-86.0f,-397,-8.249359f,81.853455f,-27.088648f,0f,0f,0f ) ;
  }

  @Test
  public void test545() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,853.0f,666.0f,0f,639.0f,0f,0f,0f,0f,0f,-42.0f,357.0f,-616.0f,456.0f,-893.0f,530.0f,-695,-9.649287f,-19.04437f,72.89891f,0f,0f,0f ) ;
  }

  @Test
  public void test546() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-854.0f,586.0f,0f,0.0f,0f,0f,0f,0f,0f,-329.0f,-391.0f,-96.0f,-769.0f,1190.0f,882.0f,-895,-0.5854249f,179.4707f,-98.53008f,0f,0f,0f ) ;
  }

  @Test
  public void test547() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-854.0f,978.0f,0f,493.0f,0f,0f,0f,0f,0f,1411.0f,57.0f,96.0f,-77.0f,-691.0f,1543.0f,746,0.115818836f,-1.8911115f,-0.6298473f,0f,0f,0f ) ;
  }

  @Test
  public void test548() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-8.575909f,-65.32802f,0f,0f,0f,0f,0f,0f,0f,69.88241f,-71.44987f,-26.660591f,0f,0f,0f,796,-28.24548f,86.845825f,35.224697f,0f,0f,0f ) ;
  }

  @Test
  public void test549() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-876.0f,845.0f,0f,647.0f,0f,0f,0f,0f,0f,-947.0f,-208.0f,-900.0f,-827.0f,-981.0f,-800.0f,-801,69.06987f,86.643906f,52.261173f,0f,0f,0f ) ;
  }

  @Test
  public void test550() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,877.0f,967.0f,0f,-915.0f,0f,0f,0f,0f,0f,515.0f,-280.0f,1334.0f,656.0f,-1256.0f,142.0f,423,-0.2487315f,-0.11850736f,-0.40118283f,0f,0f,0f ) ;
  }

  @Test
  public void test551() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-87.77807f,19.36425f,0f,0f,0f,0f,0f,0f,0f,99.999855f,100.0f,100.0f,233.0f,-842.0f,3310.0f,227,0.47064832f,-0.84874386f,-0.2410893f,0f,0f,0f ) ;
  }

  @Test
  public void test552() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,891.0f,11.0f,0f,997.0f,0f,0f,0f,0f,0f,-738.0f,1140.0f,1431.0f,-233.0f,1596.0f,2772.0f,-722,0.86005163f,0.26150063f,0.20273428f,0f,0f,0f ) ;
  }

  @Test
  public void test553() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-893.0f,527.0f,0f,2283.0f,0f,0f,0f,0f,0f,214.0f,921.0f,1220.0f,968.0f,1438.0f,-729.0f,-686,-2.0025787f,0.4086955f,0.0427404f,0f,0f,0f ) ;
  }

  @Test
  public void test554() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-894.0f,-676.0f,83.0f,-739.0f,0f,0f,0f,0f,0f,425.0f,-813.0f,-983.0f,718.0f,315.0f,-229.0f,970,-36.002407f,-32.045536f,-51.386578f,0f,-39.101307f,0f ) ;
  }

  @Test
  public void test555() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,898.0f,893.0f,0f,109.0f,0f,0f,0f,0f,0f,485.0f,429.0f,-38.0f,295.0f,-273.0f,681.0f,-1621,81.64846f,-96.81797f,-50.931686f,0f,0f,0f ) ;
  }

  @Test
  public void test556() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-90.0f,-315.0f,0f,1218.0f,0f,0f,0f,0f,0f,-652.0f,-611.0f,1.0f,-909.0f,-924.0f,692.0f,-104,-0.03440174f,0.07546157f,0.6705478f,0f,0f,0f ) ;
  }

  @Test
  public void test557() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-908.0f,1570.0f,0f,-1615.0f,0f,0f,0f,0f,0f,-106.0f,252.0f,-91.0f,-512.0f,-532.0f,-809.0f,-602,-100.0f,-63.084026f,-58.09343f,0f,0f,0f ) ;
  }

  @Test
  public void test558() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-9.0f,1033.0f,-314.0f,145.0f,0f,0f,0f,0f,0f,-696.0f,1078.0f,-447.0f,-651.0f,699.0f,-65.0f,-1218,0.050662514f,-0.36186773f,-0.8149211f,-57.80858f,0f,0f ) ;
  }

  @Test
  public void test559() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,916.0f,-9.0f,0f,395.0f,0f,0f,0f,0f,0f,747.0f,463.0f,-1034.0f,762.0f,798.0f,220.0f,540,-0.10614201f,-0.97013193f,-0.21812369f,0f,0f,0f ) ;
  }

  @Test
  public void test560() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-9.192452f,0f,0f,0f,0f,0f,0f,0f,0f,73.79729f,-8.567721f,45.582737f,0f,0f,0f,-232,8.758147f,83.34032f,-87.9751f,0f,0f,0f ) ;
  }

  @Test
  public void test561() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,92.23733f,21.225285f,0f,0f,0f,0f,0f,0f,0f,-100.0f,100.0f,31.974308f,955.0f,-1184.0f,721.0f,274,-0.49422395f,-0.66067874f,0.36631423f,0f,0f,0f ) ;
  }

  @Test
  public void test562() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-936.0f,106.0f,-788.0f,442.0f,0f,0f,0f,0f,0f,-310.0f,538.0f,-103.0f,-784.0f,348.0f,536.0f,-714,100.0f,15.539492f,-100.0f,54.80324f,0f,0f ) ;
  }

  @Test
  public void test563() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,9.380325f,100.0f,0f,0f,0f,0f,0f,0f,0f,81.50274f,30.825668f,3.911245f,0f,0f,0f,343,-0.20626687f,0.41027933f,-0.87966776f,0f,0f,0f ) ;
  }

  @Test
  public void test564() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-940.0f,1232.0f,0f,1636.0f,0f,0f,0f,0f,0f,-158.0f,-17.0f,216.0f,121.0f,1535.0f,213.0f,-726,0.341853f,-0.33283484f,-0.76656604f,0f,0f,0f ) ;
  }

  @Test
  public void test565() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-940.0f,503.0f,0f,1943.0f,0f,0f,0f,0f,0f,-2216.0f,881.0f,1730.0f,-999.0f,1447.0f,254.0f,-377,-0.14854594f,0.076640986f,-0.6795822f,0f,0f,0f ) ;
  }

  @Test
  public void test566() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,9.403955E-38f,51.30427f,0f,0f,0f,0f,0f,0f,0f,-63.74084f,-44.33969f,94.365456f,523.0f,623.0f,646.0f,-1252,43.37955f,74.17574f,-43.541386f,0f,0f,0f ) ;
  }

  @Test
  public void test567() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-943.0f,-533.0f,0f,1073.0f,0f,0f,0f,0f,0f,211.0f,542.0f,421.0f,230.0f,273.0f,-466.0f,-579,-20.551388f,-85.5382f,67.44777f,0f,0f,0f ) ;
  }

  @Test
  public void test568() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,946.0f,-505.0f,0f,969.0f,0f,0f,0f,0f,0f,-920.0f,-979.0f,-971.0f,-949.0f,207.0f,539.0f,-476,30.89254f,-30.539274f,58.15099f,0f,0f,0f ) ;
  }

  @Test
  public void test569() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-949.0f,1172.0f,0f,1853.0f,0f,0f,0f,0f,0f,-104.0f,-62.0f,141.0f,329.0f,-737.0f,-80.0f,35,100.0f,42.379837f,-98.6679f,0f,0f,0f ) ;
  }

  @Test
  public void test570() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-949.0f,406.0f,0f,1186.0f,0f,0f,0f,0f,0f,-742.0f,252.0f,240.0f,359.0f,873.0f,195.0f,803,40.151863f,32.573006f,89.934525f,0f,0f,0f ) ;
  }

  @Test
  public void test571() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,961.0f,-2660.0f,0f,2193.0f,0f,0f,0f,0f,0f,-736.0f,882.0f,-231.0f,-302.0f,-144.0f,375.0f,893,-0.40255788f,-0.46112987f,0.6147285f,0f,0f,0f ) ;
  }

  @Test
  public void test572() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,96.58208f,0.0f,0f,8.013132f,0f,0f,0f,0f,0f,-28.906881f,95.035774f,69.146f,0f,0f,0f,-1368,33.06016f,-34.88622f,39.8955f,0f,0f,0f ) ;
  }

  @Test
  public void test573() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,969.0f,-70.0f,0f,185.0f,0f,0f,0f,0f,0f,601.0f,495.0f,-78.0f,700.0f,-341.0f,-517.0f,157,-23.283503f,29.742859f,56.195824f,0f,0f,0f ) ;
  }

  @Test
  public void test574() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-9.745492f,91.00211f,0f,0f,0f,0f,0f,0f,0f,100.0f,38.742096f,-56.531773f,1235.0f,556.0f,-676.0f,1054,2.479867f,-1.3544251f,3.4584713f,0f,0f,0f ) ;
  }

  @Test
  public void test575() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-975.0f,308.0f,0f,175.0f,0f,0f,0f,0f,0f,147.0f,4.0f,212.0f,684.0f,122.0f,429.0f,868,-37.90656f,-76.557686f,27.72875f,0f,0f,0f ) ;
  }

  @Test
  public void test576() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-97.873184f,0.0f,0f,0f,0f,0f,0f,0f,0f,55.404934f,-67.041145f,1.5363625f,0f,0f,0f,42,100.0f,100.0f,-57.136852f,0f,0f,0f ) ;
  }

  @Test
  public void test577() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-980.0f,928.0f,-723.0f,902.0f,0f,0f,0f,0f,0f,-658.0f,-417.0f,-734.0f,65.0f,-260.0f,51.0f,905,43.80877f,-62.85304f,1.2447742f,61.47289f,0f,0f ) ;
  }

  @Test
  public void test578() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-98.704926f,-53.679897f,0f,51.77896f,0f,0f,0f,0f,0f,55.36032f,67.78584f,-68.69361f,0f,0f,0f,-496,72.977104f,-25.007643f,60.93457f,0f,0f,0f ) ;
  }

  @Test
  public void test579() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-98.99591f,0.0f,0f,-75.48296f,0f,0f,0f,0f,0f,38.830383f,-100.0f,-6.1221657f,0f,0f,0f,63,0.32076037f,0.11191436f,0.20643222f,0f,0f,0f ) ;
  }

  @Test
  public void test580() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-990.0f,-134.0f,0f,1323.0f,0f,0f,0f,0f,0f,1082.0f,-448.0f,380.0f,-30.0f,634.0f,833.0f,-18,-28.525162f,-7.423433f,-270.17224f,0f,0f,0f ) ;
  }

  @Test
  public void test581() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-993.0f,-587.0f,0f,66.0f,0f,0f,0f,0f,0f,-1844.0f,-136.0f,-1061.0f,649.0f,368.0f,-1421.0f,1656,0.7836836f,-0.35419318f,-0.43858665f,0f,0f,0f ) ;
  }

  @Test
  public void test582() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,994.0f,0.0f,0f,385.0f,0f,0f,0f,0f,0f,666.0f,-92.0f,-221.0f,-591.0f,857.0f,-92.0f,554,-32.517067f,40.78283f,-97.581375f,0f,0f,0f ) ;
  }

  @Test
  public void test583() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,994.0f,-740.0f,0f,135.0f,0f,0f,0f,0f,0f,-1777.0f,306.0f,453.0f,26.0f,-584.0f,-1085.0f,-337,0.053562876f,0.4268066f,-0.11307425f,0f,0f,0f ) ;
  }

  @Test
  public void test584() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-99.58122f,13.399183f,0f,-54.2664f,0f,0f,0f,0f,0f,71.83973f,100.0f,100.0f,0f,0f,0f,938,0.019446861f,0.015896063f,-0.99968827f,0f,0f,0f ) ;
  }

  @Test
  public void test585() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-996.0f,3.0f,0f,530.0f,0f,0f,0f,0f,0f,-100.0f,490.0f,538.0f,817.0f,962.0f,729.0f,-274,-50.586857f,40.39617f,-70.123436f,0f,0f,0f ) ;
  }

  @Test
  public void test586() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-99.971596f,-100.0f,0f,0.0f,0f,0f,0f,0f,0f,31.242928f,43.794724f,99.63531f,0f,0f,0f,1295,0.8548442f,-0.17581834f,-0.48818976f,0f,0f,0f ) ;
  }

  @Test
  public void test587() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,99.98164f,0.0f,0f,40.31442f,0f,0f,0f,0f,0f,-99.97941f,99.93564f,73.183624f,0f,0f,0f,2101,0.91346896f,-0.041501f,0.40478647f,0f,0f,0f ) ;
  }

  @Test
  public void test588() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-99.99997f,31.293398f,0f,0f,0f,0f,0f,0f,0f,30.755423f,100.0f,4.64075f,0f,0f,0f,-681,-0.11733851f,-0.032963365f,0.9925448f,0f,0f,0f ) ;
  }

  @Test
  public void test589() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,99.999985f,0.0f,0f,1.92593E-34f,0f,0f,0f,0f,0f,100.0f,100.0f,70.61771f,0f,0f,0f,-2413,-0.72641623f,-0.23407863f,-0.646163f,0f,0f,0f ) ;
  }

  @Test
  public void test590() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,99.99999f,-15.654158f,0f,0.0f,0f,0f,0f,0f,0f,8.39501f,100.0f,-11.904833f,0f,0f,0f,1470,-0.7636895f,-0.015602037f,-0.64539516f,0f,0f,0f ) ;
  }

  @Test
  public void test591() {
    TestDrivers.surfaceShade(0f,-1011.0f,-226.0f,0f,528.0f,284.0f,-1502.0f,-266.0f,0f,0f,0f,0f,0f,283.0f,-439.0f,-455.0f,-936.0f,-952.0f,139.0f,-295,-0.25974327f,-0.13225102f,0.7486432f,0f,50.096256f,-71.1096f ) ;
  }

  @Test
  public void test592() {
    TestDrivers.surfaceShade(0f,-113.0f,0f,0f,211.0f,88.0f,861.0f,-826.0f,0f,0f,0f,0f,0f,-267.0f,432.0f,-645.0f,-898.0f,-17.0f,-30.0f,107,27.175686f,6.8098664f,93.22041f,0f,-57.177883f,0f ) ;
  }

  @Test
  public void test593() {
    TestDrivers.surfaceShade(0f,-1269.0f,0f,0f,230.0f,1262.0f,1172.0f,-2121.0f,0f,0f,0f,0f,0f,846.0f,-202.0f,-816.0f,-716.0f,-609.0f,-1314.0f,899,-0.21898827f,-0.48599935f,-0.10673065f,0f,55.638294f,0f ) ;
  }

  @Test
  public void test594() {
    TestDrivers.surfaceShade(0f,-156.0f,0f,0f,787.0f,1127.0f,-984.0f,-393.0f,0f,0f,0f,0f,0f,-238.0f,-194.0f,-1749.0f,735.0f,130.0f,-2687.0f,854,-0.53204125f,-0.11526853f,0.15451737f,0f,68.80317f,0f ) ;
  }

  @Test
  public void test595() {
    TestDrivers.surfaceShade(0f,-206.0f,-281.0f,0f,-867.0f,456.0f,808.0f,701.0f,0f,0f,0f,0f,0f,-965.0f,640.0f,-262.0f,68.0f,-746.0f,622.0f,773,14.209823f,-97.08522f,7.6804943f,0f,43.004665f,-21.284163f ) ;
  }

  @Test
  public void test596() {
    TestDrivers.surfaceShade(0f,33.0f,-95.0f,0f,565.0f,507.0f,899.0f,699.0f,0f,0f,0f,0f,0f,833.0f,-397.0f,-246.0f,232.0f,-8.0f,-255.0f,592,71.93367f,-97.60745f,-71.82317f,0f,-88.298225f,-21.60574f ) ;
  }

  @Test
  public void test597() {
    TestDrivers.surfaceShade(0f,-405.0f,403.0f,0f,268.0f,468.0f,-63.0f,-846.0f,0f,0f,0f,0f,0f,819.0f,340.0f,-265.0f,969.0f,-729.0f,-590.0f,-1546,-100.0f,100.0f,100.0f,0f,39.879787f,-100.0f ) ;
  }

  @Test
  public void test598() {
    TestDrivers.surfaceShade(0f,527.0f,0f,0f,797.0f,558.0f,-1853.0f,-741.0f,0f,0f,0f,0f,0f,-786.0f,1469.0f,-494.0f,129.0f,1858.0f,-2184.0f,-752,0.55291176f,-0.02658112f,0.15215111f,0f,-61.007935f,0f ) ;
  }

  @Test
  public void test599() {
    TestDrivers.surfaceShade(0f,-644.0f,-641.0f,0f,224.0f,-461.0f,591.0f,278.0f,0f,0f,0f,0f,0f,954.0f,102.0f,-981.0f,863.0f,-107.0f,524.0f,-855,79.90693f,37.352867f,80.871056f,0f,-88.88651f,-11.121989f ) ;
  }

  @Test
  public void test600() {
    TestDrivers.surfaceShade(0f,705.0f,486.0f,0f,678.0f,119.0f,-254.0f,-76.0f,0f,0f,0f,0f,0f,1000.0f,803.0f,-494.0f,751.0f,737.0f,445.0f,-335,-84.92803f,96.97246f,70.01928f,0f,26.647324f,89.2365f ) ;
  }

  @Test
  public void test601() {
    TestDrivers.surfaceShade(0f,-731.0f,0f,0f,876.0f,196.0f,-430.0f,-63.0f,0f,0f,0f,0f,0f,480.0f,698.0f,925.0f,-733.0f,879.0f,187.0f,790,-46.9575f,39.514538f,-81.84306f,0f,-91.54874f,0f ) ;
  }

  @Test
  public void test602() {
    TestDrivers.surfaceShade(0f,-737.0f,0f,0f,121.0f,505.0f,837.0f,-582.0f,0f,0f,0f,0f,0f,909.0f,-477.0f,649.0f,974.0f,617.0f,-732.0f,912,-81.2748f,15.957788f,55.909634f,0f,-76.98538f,0f ) ;
  }

  @Test
  public void test603() {
    TestDrivers.surfaceShade(0f,-891.0f,-747.0f,0f,-208.0f,436.0f,892.0f,-880.0f,0f,0f,0f,0f,0f,898.0f,-225.0f,-232.0f,-476.0f,-912.0f,524.0f,-941,55.100697f,-39.395718f,-89.48713f,0f,28.591677f,-89.1405f ) ;
  }

  @Test
  public void test604() {
    TestDrivers.surfaceShade(0f,-946.0f,-903.0f,0f,1281.0f,20.0f,-1833.0f,-791.0f,0f,0f,0f,0f,0f,-342.0f,-515.0f,-792.0f,372.0f,920.0f,-146.0f,-427,0.063880414f,0.507553f,-0.35762233f,0f,-65.97951f,-100.0f ) ;
  }

  @Test
  public void test605() {
    TestDrivers.surfaceShade(0f,-963.0f,-552.0f,0f,286.0f,1507.0f,-480.0f,-206.0f,0f,0f,0f,0f,0f,-719.0f,-226.0f,389.0f,-641.0f,-271.0f,-194.0f,228,-64.18494f,140.49506f,-100.0f,0f,100.0f,-73.62251f ) ;
  }

  @Test
  public void test606() {
    TestDrivers.surfaceShade(-1000.0f,-918.0f,0f,0f,624.0f,576.0f,0f,549.0f,0f,0f,0f,0f,0f,500.0f,872.0f,841.0f,433.0f,35.0f,510.0f,-896,7.6804004f,34.106937f,-39.93038f,100.0f,47.106556f,0f ) ;
  }

  @Test
  public void test607() {
    TestDrivers.surfaceShade(1001.0f,-2265.0f,135.0f,0f,27.0f,838.0f,0f,-216.0f,0f,0f,0f,0f,0f,499.0f,-832.0f,-1199.0f,-683.0f,-2400.0f,1469.0f,-805,0.24791735f,0.08028713f,0.047466118f,6.178857f,64.402275f,43.908714f ) ;
  }

  @Test
  public void test608() {
    TestDrivers.surfaceShade(1001.0f,-424.0f,872.0f,331.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-44.060337f,-7.125349E-6f,8.945349f ) ;
  }

  @Test
  public void test609() {
    TestDrivers.surfaceShade(1009.0f,-2188.0f,1370.0f,0f,1.0f,-226.0f,0f,946.0f,0f,0f,0f,0f,0f,1135.0f,1724.0f,773.0f,-871.0f,1854.0f,559.0f,-465,-0.17893939f,0.21079752f,-0.20739812f,-7.885152f,75.14534f,-90.93099f ) ;
  }

  @Test
  public void test610() {
    TestDrivers.surfaceShade(10.0f,-106.0f,0f,0f,2546.0f,-1.0f,0f,0.0f,0f,0f,0f,0f,0f,1119.0f,-766.0f,-344.0f,0f,0f,0f,-896,20.325958f,100.0f,89.14545f,-61.71376f,-8.6628475f,0f ) ;
  }

  @Test
  public void test611() {
    TestDrivers.surfaceShade(-1010.0f,-950.0f,-782.0f,0f,26.0f,1410.0f,0f,1936.0f,0f,0f,0f,0f,0f,291.0f,-91.0f,-271.0f,-334.0f,-374.0f,1179.0f,1006,0.26803038f,0.2120052f,0.41052002f,-75.97038f,-90.599495f,-40.683426f ) ;
  }

  @Test
  public void test612() {
    TestDrivers.surfaceShade(-101.0f,-1302.0f,-1323.0f,0f,472.0f,238.0f,0f,218.0f,0f,0f,0f,0f,0f,733.0f,424.0f,-656.0f,178.0f,-436.0f,464.0f,-205,-0.11852111f,-0.3450031f,0.68007463f,-64.22173f,25.122458f,62.375988f ) ;
  }

  @Test
  public void test613() {
    TestDrivers.surfaceShade(-101.0f,2120.0f,-703.0f,0f,207.0f,-645.0f,0f,-1897.0f,0f,0f,0f,0f,0f,-817.0f,763.0f,926.0f,0f,0f,0f,-125,0.7007686f,0.15657465f,0.48926726f,-28.80241f,100.0f,-100.0f ) ;
  }

  @Test
  public void test614() {
    TestDrivers.surfaceShade(1012.0f,959.0f,0f,0f,35.0f,742.0f,0f,715.0f,0f,0f,0f,0f,0f,-451.0f,686.0f,252.0f,-1531.0f,-897.0f,956.0f,404,74.2327f,25.03896f,64.691345f,100.0f,94.936f,0f ) ;
  }

  @Test
  public void test615() {
    TestDrivers.surfaceShade(-1015.0f,1239.0f,-477.0f,0f,15.0f,-1029.0f,0f,2.0f,0f,0f,0f,0f,0f,663.0f,-119.0f,666.0f,0f,0f,0f,-728,97.64002f,74.88446f,-83.81995f,-69.85302f,-100.62475f,-97.8686f ) ;
  }

  @Test
  public void test616() {
    TestDrivers.surfaceShade(102.0f,1308.0f,0f,0f,908.0f,-345.0f,0f,357.0f,0f,0f,0f,0f,0f,-373.0f,44.0f,-97.0f,972.0f,367.0f,1655.0f,-465,2.4919498f,5.360312f,-7.1509643f,29.017708f,97.61643f,0f ) ;
  }

  @Test
  public void test617() {
    TestDrivers.surfaceShade(102.0f,-558.0f,0f,0f,535.0f,-648.0f,0f,311.0f,0f,0f,0f,0f,0f,455.0f,-185.0f,439.0f,-933.0f,329.0f,1450.0f,-927,-61.151188f,-4.3123965f,11.894472f,-78.12179f,-47.312965f,0f ) ;
  }

  @Test
  public void test618() {
    TestDrivers.surfaceShade(-1023.0f,0f,0f,0f,717.0f,-2239.0f,0f,43.0f,0f,0f,0f,0f,0f,-2051.0f,-1650.0f,-682.0f,518.0f,72.0f,-1475.0f,-1440,-0.23635325f,0.43348983f,0.051219195f,53.571274f,0f,0f ) ;
  }

  @Test
  public void test619() {
    TestDrivers.surfaceShade(1026.0f,1516.0f,0f,0f,22.0f,-205.0f,0f,424.0f,0f,0f,0f,0f,0f,-696.0f,-224.0f,-202.0f,-1687.0f,86.0f,-652.0f,-771,-35.291466f,38.069736f,79.38238f,-85.0021f,-74.88165f,0f ) ;
  }

  @Test
  public void test620() {
    TestDrivers.surfaceShade(-103.0f,-905.0f,133.0f,0f,486.0f,378.0f,0f,-503.0f,0f,0f,0f,0f,0f,364.0f,-725.0f,896.0f,1186.0f,896.0f,-19.0f,958,-3.4122698f,1.2874475f,0.18288618f,-0.65886587f,-100.0f,100.0f ) ;
  }

  @Test
  public void test621() {
    TestDrivers.surfaceShade(1037.0f,-745.0f,0f,0f,21.0f,-209.0f,0f,-143.0f,0f,0f,0f,0f,0f,-633.0f,-580.0f,745.0f,0f,0f,0f,-1778,0.06969721f,-0.0064739184f,0.054044772f,4.587134E-4f,-100.0f,0f ) ;
  }

  @Test
  public void test622() {
    TestDrivers.surfaceShade(-1039.0f,739.0f,1123.0f,0f,1340.0f,-411.0f,0f,1200.0f,0f,0f,0f,0f,0f,610.0f,249.0f,807.0f,-1465.0f,-965.0f,171.0f,-79,-1.1292899f,-5.6288013f,2.590382f,54.989056f,24.997776f,0.78994536f ) ;
  }

  @Test
  public void test623() {
    TestDrivers.surfaceShade(-104.0f,0f,0f,0f,1983.0f,0.0f,0f,2021.0f,0f,0f,0f,0f,0f,1403.0f,809.0f,66.0f,318.0f,-711.0f,220.0f,105,18.462507f,-90.991684f,-76.242226f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test624() {
    TestDrivers.surfaceShade(104.0f,0f,0f,0f,363.0f,-610.0f,0f,492.0f,0f,0f,0f,0f,0f,-387.0f,886.0f,-549.0f,794.0f,895.0f,284.0f,-65,20.147116f,-1.4575717f,-16.554358f,-86.45248f,0f,0f ) ;
  }

  @Test
  public void test625() {
    TestDrivers.surfaceShade(-1042.0f,100.0f,-1019.0f,662.0f,0f,0f,0f,-59.332775f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-1.4496871E-6f,-108.88454f,50.593735f ) ;
  }

  @Test
  public void test626() {
    TestDrivers.surfaceShade(-1044.0f,0f,1837.0f,0f,1.0f,-1893.0f,0f,-3.0f,0f,0f,0f,0f,0f,818.0f,372.0f,-52.0f,0f,0f,0f,907,-36.025967f,92.14304f,92.461f,-50.00896f,0f,61.460915f ) ;
  }

  @Test
  public void test627() {
    TestDrivers.surfaceShade(1052.0f,327.0f,790.0f,0f,143.0f,142.0f,0f,427.0f,0f,0f,0f,0f,0f,66.0f,-317.0f,591.0f,-142.0f,1690.0f,-1667.0f,-399,60.997093f,-18.110174f,-69.07329f,47.585052f,74.97422f,100.0f ) ;
  }

  @Test
  public void test628() {
    TestDrivers.surfaceShade(1055.0f,-1488.0f,-920.0f,0f,540.0f,-628.0f,0f,348.0f,0f,0f,0f,0f,0f,1060.0f,1011.0f,-424.0f,-572.0f,-1668.0f,588.0f,-1410,-0.8331961f,0.33895558f,-1.274773f,59.279694f,-100.0f,-53.92429f ) ;
  }

  @Test
  public void test629() {
    TestDrivers.surfaceShade(1055.0f,643.0f,0f,0f,105.0f,0.0f,0f,-1.0f,0f,0f,0f,0f,0f,348.0f,-30.0f,-975.0f,0f,0f,0f,-1033,20.358599f,61.083763f,160.13554f,-87.58366f,-35.84565f,0f ) ;
  }

  @Test
  public void test630() {
    TestDrivers.surfaceShade(1073.0f,1542.0f,766.0f,0f,784.0f,-1441.0f,0f,566.0f,0f,0f,0f,0f,0f,860.0f,555.0f,-2643.0f,-517.0f,-276.0f,-321.0f,-1160,-0.18842407f,-0.006800963f,0.48827305f,-1.7622551f,37.454014f,100.0f ) ;
  }

  @Test
  public void test631() {
    TestDrivers.surfaceShade(1084.0f,1470.0f,0f,0f,683.0f,-754.0f,0f,523.0f,0f,0f,0f,0f,0f,-10.0f,764.0f,-985.0f,757.0f,-1006.0f,771.0f,-1606,-0.055102035f,-0.5803904f,0.038664274f,-33.384205f,73.95926f,0f ) ;
  }

  @Test
  public void test632() {
    TestDrivers.surfaceShade(1087.0f,0f,0f,0f,673.0f,-490.0f,0f,1044.0f,0f,0f,0f,0f,0f,-2098.0f,-269.0f,370.0f,625.0f,-902.0f,-2296.0f,-369,0.16109845f,-0.09526949f,0.5274614f,51.768806f,0f,0f ) ;
  }

  @Test
  public void test633() {
    TestDrivers.surfaceShade(1090.0f,224.0f,258.0f,0f,1284.0f,731.0f,0f,-284.0f,0f,0f,0f,0f,0f,21.0f,-945.0f,1457.0f,1277.0f,1107.0f,146.0f,2135,0.21032614f,-0.10785194f,-0.29840735f,-7.306637f,11.957002f,66.52245f ) ;
  }

  @Test
  public void test634() {
    TestDrivers.surfaceShade(-1096.0f,189.0f,-1047.0f,-637.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,-60.419365f,-5.1760807f,99.1957f ) ;
  }

  @Test
  public void test635() {
    TestDrivers.surfaceShade(1.0f,-2452.0f,365.0f,0f,1080.0f,-788.0f,0f,-745.0f,0f,0f,0f,0f,0f,-303.0f,-782.0f,807.0f,0f,0f,0f,-1822,95.04025f,-38.210617f,-1.3426348f,100.0f,85.119125f,-7.911579f ) ;
  }

  @Test
  public void test636() {
    TestDrivers.surfaceShade(1100.0f,-209.0f,0f,0f,581.0f,5.0f,0f,-1708.0f,0f,0f,0f,0f,0f,700.0f,861.0f,-450.0f,0f,0f,0f,-689,-0.6519306f,-0.15929136f,-0.34367457f,13.02802f,21.839922f,0f ) ;
  }

  @Test
  public void test637() {
    TestDrivers.surfaceShade(-1101.0f,1211.0f,2025.0f,0f,3.0f,1716.0f,0f,338.0f,0f,0f,0f,0f,0f,386.0f,424.0f,92.0f,960.0f,966.0f,89.0f,-548,-54.49531f,57.111923f,-34.56809f,87.541214f,-10.175601f,62.08873f ) ;
  }

  @Test
  public void test638() {
    TestDrivers.surfaceShade(1104.0f,3311.0f,0f,0f,171.0f,-1.0f,0f,-1265.0f,0f,0f,0f,0f,0f,-262.0f,-48.0f,-521.0f,0f,0f,0f,669,-0.67806435f,0.0194152f,0.33919564f,11.989447f,4.146133f,0f ) ;
  }

  @Test
  public void test639() {
    TestDrivers.surfaceShade(-1108.0f,0f,0f,0f,1019.0f,382.0f,-501.0f,-1018.0f,0f,0f,0f,0f,0f,-1002.0f,-194.0f,-229.0f,-498.0f,536.0f,-537.0f,1481,0.8235633f,-0.08044228f,0.0030238524f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test640() {
    TestDrivers.surfaceShade(-1109.0f,-938.0f,121.0f,75.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-3,0f,0f,0f,-11.001549f,0.93407524f,-79.05613f ) ;
  }

  @Test
  public void test641() {
    TestDrivers.surfaceShade(11.0f,0f,0f,0f,1582.0f,437.0f,530.0f,-146.0f,0f,0f,0f,0f,0f,763.0f,377.0f,-1264.0f,833.0f,559.0f,-288.0f,-282,0.10177951f,0.13712148f,0.9068024f,20.28996f,0f,0f ) ;
  }

  @Test
  public void test642() {
    TestDrivers.surfaceShade(-111.0f,-195.0f,-224.0f,0f,842.0f,2348.0f,0f,-1129.0f,0f,0f,0f,0f,0f,999.0f,376.0f,-753.0f,-1165.0f,1774.0f,-616.0f,-482,-6.418158f,-15.780904f,-16.3949f,-50.379787f,-27.611046f,-0.34242946f ) ;
  }

  @Test
  public void test643() {
    TestDrivers.surfaceShade(-112.0f,128.0f,0f,0f,5.0f,-1167.0f,0f,-1885.0f,0f,0f,0f,0f,0f,142.0f,-25.0f,-595.0f,0f,0f,0f,-176,0.12327697f,0.8926978f,-0.008087515f,-39.660828f,1.2343107f,0f ) ;
  }

  @Test
  public void test644() {
    TestDrivers.surfaceShade(-1121.0f,-1466.0f,-525.0f,0f,1680.0f,910.0f,0f,186.0f,0f,0f,0f,0f,0f,-1040.0f,771.0f,-1455.0f,-1012.0f,802.0f,1295.0f,-910,0.45006552f,-0.28418145f,0.508079f,1.9314423f,85.70576f,53.26455f ) ;
  }

  @Test
  public void test645() {
    TestDrivers.surfaceShade(113.0f,0f,0f,0f,1244.0f,478.0f,-356.0f,-272.0f,0f,0f,0f,0f,0f,-590.0f,-224.0f,-70.0f,667.0f,-2005.0f,577.0f,-1076,-0.027990261f,0.12429475f,0.9918505f,100.0f,0f,0f ) ;
  }

  @Test
  public void test646() {
    TestDrivers.surfaceShade(1138.0f,69.0f,856.0f,0f,147.0f,-6.0f,0f,448.0f,0f,0f,0f,0f,0f,444.0f,-456.0f,-453.0f,1032.0f,-865.0f,-309.0f,-43,-0.8010675f,-0.4862255f,-0.29570666f,75.378586f,100.0f,-39.834526f ) ;
  }

  @Test
  public void test647() {
    TestDrivers.surfaceShade(114.0f,-444.0f,-518.0f,59.0f,0f,0f,0f,-2.2634773f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,4,0f,0f,0f,-6.978367E-4f,-4.0196805E-6f,0.003717472f ) ;
  }

  @Test
  public void test648() {
    TestDrivers.surfaceShade(1141.0f,-2229.0f,-1695.0f,0f,518.0f,850.0f,0f,-910.0f,0f,0f,0f,0f,0f,-267.0f,-272.0f,-446.0f,854.0f,49.0f,144.0f,892,-81.424225f,68.997475f,6.6658177f,46.08083f,-63.48266f,-99.57214f ) ;
  }

  @Test
  public void test649() {
    TestDrivers.surfaceShade(1147.0f,346.0f,-1431.0f,0f,804.0f,713.0f,0f,-2546.0f,0f,0f,0f,0f,0f,3.0f,881.0f,-390.0f,1028.0f,327.0f,-471.0f,495,-59.137714f,-27.776176f,-63.200577f,100.0f,67.15935f,73.241035f ) ;
  }

  @Test
  public void test650() {
    TestDrivers.surfaceShade(1147.0f,377.0f,-973.0f,0f,1043.0f,50.0f,0f,-254.0f,0f,0f,0f,0f,0f,560.0f,-1221.0f,-501.0f,-1438.0f,-249.0f,1.0f,-1364,0.22441012f,0.64361f,0.14769839f,48.139954f,-100.0f,100.0f ) ;
  }

  @Test
  public void test651() {
    TestDrivers.surfaceShade(115.0f,790.0f,-197.0f,0f,248.0f,331.0f,0f,1786.0f,0f,0f,0f,0f,0f,268.0f,526.0f,-163.0f,-1664.0f,-171.0f,1212.0f,962,23.085096f,-30.229902f,-45.694134f,-32.617004f,-9.948727f,-9.032884E-9f ) ;
  }

  @Test
  public void test652() {
    TestDrivers.surfaceShade(1156.0f,130.0f,0f,0f,76.0f,-1745.0f,0f,939.0f,0f,0f,0f,0f,0f,-668.0f,1038.0f,-124.0f,-1827.0f,980.0f,-654.0f,-114,-0.32558534f,-0.12871261f,0.7764482f,-3.0018265f,5.477542f,0f ) ;
  }

  @Test
  public void test653() {
    TestDrivers.surfaceShade(-1157.0f,109.0f,0f,0f,5.0f,-964.0f,0f,567.0f,0f,0f,0f,0f,0f,895.0f,-443.0f,288.0f,-713.0f,174.0f,262.0f,-88,-5.19863f,100.0f,-100.0f,82.516464f,-100.0f,0f ) ;
  }

  @Test
  public void test654() {
    TestDrivers.surfaceShade(-1159.0f,-920.0f,861.0f,0f,74.0f,-1224.0f,0f,0.0f,0f,0f,0f,0f,0f,604.0f,169.0f,-68.0f,0f,0f,0f,-73,0.064913735f,-1.1432352f,-2.264689f,-62.245632f,1.623393f,42.093597f ) ;
  }

  @Test
  public void test655() {
    TestDrivers.surfaceShade(1160.0f,0f,-848.0f,0f,229.0f,1.0f,0f,-1778.0f,0f,0f,0f,0f,0f,2359.0f,-1013.0f,-604.0f,0f,0f,0f,228,0.3414868f,0.5706532f,0.54261523f,-78.38017f,0f,3.5130552E-7f ) ;
  }

  @Test
  public void test656() {
    TestDrivers.surfaceShade(-1169.0f,1846.0f,1335.0f,0f,1427.0f,-604.0f,0f,535.0f,0f,0f,0f,0f,0f,252.0f,154.0f,-615.0f,-1515.0f,106.0f,34.0f,-555,0.34205803f,-0.7026567f,-0.035789445f,100.0f,100.0f,25.276321f ) ;
  }

  @Test
  public void test657() {
    TestDrivers.surfaceShade(119.0f,1312.0f,-292.0f,-2.0f,0f,0f,0f,-8.881784E-16f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-0.004201681f,-47.765423f,-7.5666494f ) ;
  }

  @Test
  public void test658() {
    TestDrivers.surfaceShade(1192.0f,-805.0f,8.0f,0f,554.0f,1148.0f,0f,357.0f,0f,0f,0f,0f,0f,-12.0f,893.0f,-107.0f,855.0f,-1815.0f,522.0f,762,-0.29808637f,-0.09529621f,-0.7618923f,10.369616f,85.532326f,91.264984f ) ;
  }

  @Test
  public void test659() {
    TestDrivers.surfaceShade(1200.0f,0f,-1284.0f,0f,881.0f,1847.0f,0f,2246.0f,0f,0f,0f,0f,0f,882.0f,-84.0f,195.0f,-939.0f,-1329.0f,271.0f,-378,-9.964989f,86.37053f,82.278175f,91.15008f,0f,-100.0f ) ;
  }

  @Test
  public void test660() {
    TestDrivers.surfaceShade(-1213.0f,0f,0f,0f,9.698944f,0.0f,0f,-74.11492f,0f,0f,0f,0f,0f,-69.92845f,99.99996f,100.0f,0f,0f,0f,-34,0.38147637f,-0.74254996f,-0.52283037f,-19.871063f,0f,0f ) ;
  }

  @Test
  public void test661() {
    TestDrivers.surfaceShade(-122.0f,1316.0f,-286.0f,0f,408.0f,-1363.0f,0f,779.0f,0f,0f,0f,0f,0f,439.0f,379.0f,695.0f,816.0f,870.0f,602.0f,-306,83.65012f,81.74636f,-97.41622f,9.160297f,-100.0f,41.32501f ) ;
  }

  @Test
  public void test662() {
    TestDrivers.surfaceShade(-122.0f,-731.0f,0f,68.0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-1.2054002E-4f,-75.65856f,0f ) ;
  }

  @Test
  public void test663() {
    TestDrivers.surfaceShade(-1232.0f,0f,0f,0f,35.0f,95.0f,0f,-1.0f,0f,0f,0f,0f,0f,-911.0f,266.0f,335.0f,-503.0f,8.0f,-1524.0f,-83,51.553642f,60.07477f,92.493965f,-1.8038732f,0f,0f ) ;
  }

  @Test
  public void test664() {
    TestDrivers.surfaceShade(-124.0f,2457.0f,0f,0f,5.0f,-1.0f,0f,-2179.0f,0f,0f,0f,0f,0f,-1230.0f,-487.0f,-672.0f,0f,0f,0f,1043,0.8385543f,1.7550887f,-0.60410506f,-76.85094f,-3.323351f,0f ) ;
  }

  @Test
  public void test665() {
    TestDrivers.surfaceShade(1244.0f,-1843.0f,-270.0f,0f,50.0f,48.0f,0f,620.0f,0f,0f,0f,0f,0f,48.0f,-188.0f,265.0f,-1021.0f,-1184.0f,5.0f,836,-55.57328f,91.40272f,74.91027f,-86.117f,-100.0f,-23.794916f ) ;
  }

  @Test
  public void test666() {
    TestDrivers.surfaceShade(-1244.0f,383.0f,0f,0f,471.0f,-238.0f,0f,1246.0f,0f,0f,0f,0f,0f,-836.0f,604.0f,-623.0f,169.0f,803.0f,-593.0f,1418,0.6036678f,-0.1009493f,-0.20087849f,-100.0f,82.08927f,0f ) ;
  }

  @Test
  public void test667() {
    TestDrivers.surfaceShade(-125.0f,-614.0f,439.0f,0f,1049.0f,1706.0f,0f,-251.0f,0f,0f,0f,0f,0f,655.0f,1362.0f,-766.0f,849.0f,-963.0f,251.0f,-1225,-1.3493193f,0.35521123f,-0.52220166f,-88.076904f,-8.889955f,33.59565f ) ;
  }

  @Test
  public void test668() {
    TestDrivers.surfaceShade(-125.0f,913.0f,0f,0f,279.0f,-574.0f,0f,-5.0f,0f,0f,0f,0f,0f,485.0f,-1897.0f,-299.0f,0f,0f,0f,202,0.029535336f,0.040405545f,0.059157785f,-100.0f,-63.000057f,0f ) ;
  }

  @Test
  public void test669() {
    TestDrivers.surfaceShade(-128.0f,0f,0f,0f,11.785629f,-32.451424f,0f,0.0f,0f,0f,0f,0f,0f,86.25783f,-10.690675f,-21.734793f,0f,0f,0f,678,-74.65712f,47.36146f,-20.786253f,30.114212f,0f,0f ) ;
  }

  @Test
  public void test670() {
    TestDrivers.surfaceShade(-128.0f,-39.0f,-479.0f,-344.0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,2.2710756E-5f,-100.0f,42.038776f ) ;
  }

  @Test
  public void test671() {
    TestDrivers.surfaceShade(-130.0f,-11.0f,0f,0f,31.0f,1341.0f,0f,-2545.0f,0f,0f,0f,0f,0f,-931.0f,2741.0f,-1791.0f,1840.0f,-960.0f,1438.0f,-259,0.074868836f,0.46378237f,0.67086804f,-3.0666616f,-38.972523f,0f ) ;
  }

  @Test
  public void test672() {
    TestDrivers.surfaceShade(-131.0f,439.0f,659.0f,0f,41.0f,-123.0f,0f,636.0f,0f,0f,0f,0f,0f,-380.0f,-863.0f,-244.0f,910.0f,705.0f,-868.0f,995,31.592443f,28.646004f,-24.58263f,-100.0f,-82.08184f,21.265285f ) ;
  }

  @Test
  public void test673() {
    TestDrivers.surfaceShade(131.0f,-881.0f,385.0f,0f,6.0f,572.0f,0f,-1247.0f,0f,0f,0f,0f,0f,-749.0f,937.0f,2.0f,-506.0f,-887.0f,430.0f,953,-0.60464334f,-0.48284924f,-0.22441816f,1.8624512f,100.0f,-45.131588f ) ;
  }

  @Test
  public void test674() {
    TestDrivers.surfaceShade(1313.0f,-475.0f,-28.0f,-100.0f,0f,0f,0f,-27.434896f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,-72.92139f,14.402181f,3.5714285E-4f ) ;
  }

  @Test
  public void test675() {
    TestDrivers.surfaceShade(1323.0f,576.0f,0f,0f,150.0f,-1391.0f,0f,-320.0f,0f,0f,0f,0f,0f,-909.0f,1742.0f,-912.0f,0f,0f,0f,-552,-0.04597313f,-0.06886197f,0.65233696f,50.716778f,-84.15701f,0f ) ;
  }

  @Test
  public void test676() {
    TestDrivers.surfaceShade(-1330.0f,0f,-903.0f,0f,845.0f,-701.0f,0f,1163.0f,0f,0f,0f,0f,0f,-1777.0f,-777.0f,-284.0f,1863.0f,-3377.0f,-676.0f,-303,0.45463523f,0.6852347f,-0.5689993f,63.651447f,0f,-15.980201f ) ;
  }

  @Test
  public void test677() {
    TestDrivers.surfaceShade(-133.0f,817.0f,0f,0f,225.0f,478.0f,0f,1967.0f,0f,0f,0f,0f,0f,-660.0f,613.0f,-1098.0f,369.0f,154.0f,120.0f,-98,0.0021255147f,-0.39232406f,0.59779376f,-1.7995868f,38.112976f,0f ) ;
  }

  @Test
  public void test678() {
    TestDrivers.surfaceShade(-1343.0f,-717.0f,-331.0f,0f,266.0f,450.0f,0f,-145.0f,0f,0f,0f,0f,0f,-606.0f,31.0f,667.0f,910.0f,1651.0f,-1221.0f,320,1.1208767f,-0.14261764f,1.024996f,-100.0f,-52.17529f,-26.403622f ) ;
  }

  @Test
  public void test679() {
    TestDrivers.surfaceShade(-1347.0f,0f,0f,0f,99.99991f,-84.84251f,0f,-16.42125f,0f,0f,0f,0f,0f,-28.84921f,-95.18866f,-28.229813f,0f,0f,0f,-1568,-32.99229f,22.88944f,-43.465168f,-64.50453f,0f,0f ) ;
  }

  @Test
  public void test680() {
    TestDrivers.surfaceShade(-1347.0f,1694.0f,0f,0f,69.0f,-1400.0f,0f,910.0f,0f,0f,0f,0f,0f,1126.0f,-956.0f,829.0f,-2697.0f,1246.0f,1071.0f,775,0.56774414f,0.45482558f,-0.2466425f,-41.95007f,8.648382f,0f ) ;
  }

  @Test
  public void test681() {
    TestDrivers.surfaceShade(-135.0f,0f,0f,0f,77.9555f,-79.919914f,0f,0.0f,0f,0f,0f,0f,0f,83.01086f,32.63629f,-29.12444f,0f,0f,0f,371,-0.6445632f,-0.06202384f,-1.9066452f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test682() {
    TestDrivers.surfaceShade(1351.0f,695.0f,0f,0f,56.0f,-827.0f,0f,-86.0f,0f,0f,0f,0f,0f,361.0f,-95.0f,563.0f,0f,0f,0f,844,41.94163f,-65.04969f,-37.869717f,100.0f,99.99914f,0f ) ;
  }

  @Test
  public void test683() {
    TestDrivers.surfaceShade(1352.0f,705.0f,23.0f,-471.0f,0f,0f,0f,-93.34089f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,27.199852f,56.605854f,-0.0033444816f ) ;
  }

  @Test
  public void test684() {
    TestDrivers.surfaceShade(-1355.0f,582.0f,-259.0f,0f,14.0f,-848.0f,0f,386.0f,0f,0f,0f,0f,0f,97.0f,-6.0f,671.0f,63.0f,266.0f,284.0f,-1366,0.5895303f,-0.36222836f,-0.48856896f,-6.923359f,4.2120275f,41.741188f ) ;
  }

  @Test
  public void test685() {
    TestDrivers.surfaceShade(-1361.0f,562.0f,1945.0f,0f,2102.0f,556.0f,0f,-307.0f,0f,0f,0f,0f,0f,427.0f,-676.0f,1777.0f,-81.0f,3124.0f,-870.0f,-172,-0.46281585f,0.39241412f,-0.01007697f,-92.232475f,10.439303f,-46.962425f ) ;
  }

  @Test
  public void test686() {
    TestDrivers.surfaceShade(-1364.0f,0f,0f,0f,1381.0f,-1337.0f,0f,64.0f,0f,0f,0f,0f,0f,150.0f,136.0f,795.0f,217.0f,-2344.0f,-232.0f,-848,1.0989742f,-0.8406013f,-0.06355265f,-14.468894f,0f,0f ) ;
  }

  @Test
  public void test687() {
    TestDrivers.surfaceShade(1364.0f,-144.0f,810.0f,0f,54.0f,-2796.0f,0f,121.0f,0f,0f,0f,0f,0f,-418.0f,-214.0f,310.0f,-651.0f,-597.0f,305.0f,1043,90.891556f,-76.10722f,70.01846f,69.72256f,49.268288f,-23.866978f ) ;
  }

  @Test
  public void test688() {
    TestDrivers.surfaceShade(-1369.0f,-265.0f,0f,0f,117.0f,-22.0f,0f,114.0f,0f,0f,0f,0f,0f,983.0f,411.0f,635.0f,-1346.0f,63.0f,554.0f,281,-0.3108401f,0.37495852f,-0.36569047f,-14.5243635f,99.86383f,0f ) ;
  }

  @Test
  public void test689() {
    TestDrivers.surfaceShade(-1370.0f,0f,0f,0f,1084.0f,1131.0f,0f,881.0f,0f,0f,0f,0f,0f,858.0f,1250.0f,1374.0f,-331.0f,269.0f,-1196.0f,-872,-0.2302309f,0.13292259f,-0.18886341f,-19.479712f,0f,0f ) ;
  }

  @Test
  public void test690() {
    TestDrivers.surfaceShade(-1374.0f,0f,0f,0f,39.534657f,2.7668275E-6f,0f,-100.0f,0f,0f,0f,0f,0f,-3.6324668f,-59.116585f,66.574814f,0f,0f,0f,1979,-0.017677782f,0.6715365f,-0.75600433f,-3.3973286f,0f,0f ) ;
  }

  @Test
  public void test691() {
    TestDrivers.surfaceShade(-1374.0f,-943.0f,1438.0f,0f,32.0f,-515.0f,0f,-174.0f,0f,0f,0f,0f,0f,912.0f,-215.0f,56.0f,0f,0f,0f,-379,-0.0434669f,0.3891913f,0.06967347f,-34.398346f,-100.0f,21.5718f ) ;
  }

  @Test
  public void test692() {
    TestDrivers.surfaceShade(-138.0f,-787.0f,110.0f,81.0f,0f,0f,0f,-37.2485f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-8.946144E-5f,-17.050425f,1.1223344E-4f ) ;
  }

  @Test
  public void test693() {
    TestDrivers.surfaceShade(1384.0f,-830.0f,0f,0f,1805.0f,1050.0f,0f,1078.0f,0f,0f,0f,0f,0f,345.0f,-856.0f,-532.0f,-1001.0f,-916.0f,1838.0f,-2158,63.587624f,17.064337f,13.779433f,44.993576f,-73.33995f,0f ) ;
  }

  @Test
  public void test694() {
    TestDrivers.surfaceShade(1390.0f,1799.0f,0f,0f,65.0f,-6.0f,0f,743.0f,0f,0f,0f,0f,0f,-615.0f,-1306.0f,-586.0f,270.0f,770.0f,1360.0f,-324,-100.0f,71.49001f,-21.856703f,-24.786787f,-48.75795f,0f ) ;
  }

  @Test
  public void test695() {
    TestDrivers.surfaceShade(1394.0f,0f,0f,0f,173.0f,109.0f,0f,-1192.0f,0f,0f,0f,0f,0f,-725.0f,-498.0f,-95.0f,165.0f,-554.0f,1316.0f,997,-43.216747f,72.95228f,-52.611496f,83.82468f,0f,0f ) ;
  }

  @Test
  public void test696() {
    TestDrivers.surfaceShade(-1408.0f,258.0f,1312.0f,0f,332.0f,1917.0f,0f,-1800.0f,0f,0f,0f,0f,0f,211.0f,-215.0f,284.0f,-963.0f,-47.0f,788.0f,-822,0.63365513f,-0.048064116f,-0.50716555f,-100.0f,34.337986f,44.562603f ) ;
  }

  @Test
  public void test697() {
    TestDrivers.surfaceShade(-14.0f,557.0f,0f,0f,296.0f,-371.0f,0f,-2177.0f,0f,0f,0f,0f,0f,-244.0f,726.0f,62.0f,0f,0f,0f,-450,3.7095761f,-4.505762f,67.36f,-25.596535f,222.16815f,0f ) ;
  }

  @Test
  public void test698() {
    TestDrivers.surfaceShade(-1411.0f,165.0f,887.0f,0f,5.0f,734.0f,0f,-47.0f,0f,0f,0f,0f,0f,-29.0f,264.0f,-140.0f,-89.0f,-85.0f,835.0f,-555,100.0f,-100.0f,100.0f,100.0f,-100.0f,100.0f ) ;
  }

  @Test
  public void test699() {
    TestDrivers.surfaceShade(143.0f,0f,0f,-105.0f,0f,0f,0f,-90.61538f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-6.660006E-5f,0f,0f ) ;
  }

  @Test
  public void test700() {
    TestDrivers.surfaceShade(-1450.0f,173.0f,0f,0f,51.0f,-221.0f,0f,1426.0f,0f,0f,0f,0f,0f,-190.0f,1736.0f,-1613.0f,-711.0f,-681.0f,404.0f,298,0.91809183f,-0.053040974f,0.39280277f,71.34043f,-75.27622f,0f ) ;
  }

  @Test
  public void test701() {
    TestDrivers.surfaceShade(-1455.0f,-401.0f,0f,0f,663.0f,-1850.0f,0f,319.0f,0f,0f,0f,0f,0f,-939.0f,-70.0f,-1220.0f,365.0f,-708.0f,1013.0f,785,-0.060437314f,-0.11972493f,0.59872234f,20.005823f,91.38689f,0f ) ;
  }

  @Test
  public void test702() {
    TestDrivers.surfaceShade(-1455.0f,760.0f,538.0f,0f,626.0f,2317.0f,0f,111.0f,0f,0f,0f,0f,0f,887.0f,531.0f,477.0f,-455.0f,-339.0f,-452.0f,-1711,-0.08710452f,-0.5594308f,0.07266608f,100.0f,-49.4497f,82.79682f ) ;
  }

  @Test
  public void test703() {
    TestDrivers.surfaceShade(-146.0f,0f,0f,0f,334.0f,775.0f,0f,-103.0f,0f,0f,0f,0f,0f,314.0f,-78.0f,310.0f,-766.0f,-477.0f,-44.0f,-108,-0.65558803f,0.23477037f,-0.03448122f,35.59321f,0f,0f ) ;
  }

  @Test
  public void test704() {
    TestDrivers.surfaceShade(146.0f,0f,0f,0f,59.0f,980.0f,0f,1.0f,0f,0f,0f,0f,0f,209.0f,-20.0f,84.0f,-904.0f,811.0f,27.0f,1479,-1.8820612f,36.40736f,-146.51686f,-8.275207f,0f,0f ) ;
  }

  @Test
  public void test705() {
    TestDrivers.surfaceShade(-146.0f,-1071.0f,177.0f,0f,953.0f,-1357.0f,0f,27.0f,0f,0f,0f,0f,0f,-317.0f,-639.0f,386.0f,-344.0f,-890.0f,-521.0f,-780,0.78161365f,-0.2687366f,0.18473339f,-64.93f,96.29039f,-100.0f ) ;
  }

  @Test
  public void test706() {
    TestDrivers.surfaceShade(1467.0f,0f,0f,-844.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,24.402987f,0f,0f ) ;
  }

  @Test
  public void test707() {
    TestDrivers.surfaceShade(1481.0f,503.0f,0f,0f,1114.0f,2023.0f,0f,-23.0f,0f,0f,0f,0f,0f,-1398.0f,-109.0f,-2120.0f,1550.0f,554.0f,579.0f,170,0.17618832f,-0.4814592f,-0.091430284f,62.697327f,0.09775678f,0f ) ;
  }

  @Test
  public void test708() {
    TestDrivers.surfaceShade(1497.0f,0f,368.0f,0f,155.0f,-556.0f,0f,0.0f,0f,0f,0f,0f,0f,-909.0f,228.0f,-366.0f,0f,0f,0f,202,59.81561f,-58.666637f,-100.0f,100.0f,0f,68.98897f ) ;
  }

  @Test
  public void test709() {
    TestDrivers.surfaceShade(-15.0f,-609.0f,0f,0f,2079.0f,527.0f,0f,1990.0f,0f,0f,0f,0f,0f,-873.0f,-232.0f,476.0f,-125.0f,1380.0f,0.0f,528,7.892621f,-98.14874f,-33.36187f,-1.2201797f,6.0545197f,0f ) ;
  }

  @Test
  public void test710() {
    TestDrivers.surfaceShade(1515.0f,0f,0f,0f,207.0f,755.0f,0f,936.0f,0f,0f,0f,0f,0f,351.0f,385.0f,-652.0f,133.0f,-387.0f,-201.0f,-47,-17.80089f,100.0f,49.467445f,9.610302f,0f,0f ) ;
  }

  @Test
  public void test711() {
    TestDrivers.surfaceShade(152.0f,94.0f,277.0f,0f,586.0f,337.0f,0f,965.0f,0f,0f,0f,0f,0f,-992.0f,635.0f,757.0f,367.0f,-934.0f,65.0f,-778,-27.608616f,-100.0f,-12.359717f,-9.439677f,-100.0f,60.29947f ) ;
  }

  @Test
  public void test712() {
    TestDrivers.surfaceShade(-1545.0f,-227.0f,-1246.0f,0f,1200.0f,-962.0f,0f,207.0f,0f,0f,0f,0f,0f,684.0f,812.0f,661.0f,-1088.0f,66.0f,-855.0f,-960,0.78279525f,25.065243f,-31.601225f,96.024994f,-19.283329f,45.91002f ) ;
  }

  @Test
  public void test713() {
    TestDrivers.surfaceShade(-1558.0f,726.0f,0f,0f,446.0f,1441.0f,0f,1664.0f,0f,0f,0f,0f,0f,329.0f,-451.0f,889.0f,443.0f,-140.0f,153.0f,61,-74.14885f,-45.534523f,4.340722f,34.849903f,78.50415f,0f ) ;
  }

  @Test
  public void test714() {
    TestDrivers.surfaceShade(-1558.0f,-732.0f,0f,0f,391.0f,-299.0f,0f,8.0f,0f,0f,0f,0f,0f,-954.0f,-746.0f,-506.0f,1571.0f,403.0f,-268.0f,495,-79.85939f,80.2053f,32.317604f,-36.539703f,-50.36313f,0f ) ;
  }

  @Test
  public void test715() {
    TestDrivers.surfaceShade(156.0f,0f,0f,0f,100.0f,-60.591927f,0f,0.0f,0f,0f,0f,0f,0f,-24.715069f,-91.61102f,-100.0f,0f,0f,0f,-79,-0.30110082f,-0.16361947f,0.87477595f,-7.833807f,0f,0f ) ;
  }

  @Test
  public void test716() {
    TestDrivers.surfaceShade(-156.0f,538.0f,308.0f,0f,711.0f,329.0f,0f,-414.0f,0f,0f,0f,0f,0f,-457.0f,322.0f,-140.0f,-71.0f,-1689.0f,-209.0f,565,22.098661f,-1.1765488f,70.90294f,-93.07076f,-29.30835f,96.913506f ) ;
  }

  @Test
  public void test717() {
    TestDrivers.surfaceShade(157.0f,-499.0f,334.0f,0f,1826.0f,-765.0f,0f,-1391.0f,0f,0f,0f,0f,0f,1122.0f,978.0f,-51.0f,0f,0f,0f,860,0.038698163f,-0.27584258f,0.19526649f,83.99346f,14.567896f,-0.88740635f ) ;
  }

  @Test
  public void test718() {
    TestDrivers.surfaceShade(-1586.0f,0f,0f,-112.0f,0f,0f,0f,56.315895f,0f,0f,0f,0f,0f,-72.03561f,85.31509f,18.058445f,773.0f,829.0f,-833.0f,2,0f,0f,0f,56.866463f,0f,0f ) ;
  }

  @Test
  public void test719() {
    TestDrivers.surfaceShade(-159.0f,0f,0f,302.0f,0f,0f,0f,-1.4452963f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-91.607f,0f,0f ) ;
  }

  @Test
  public void test720() {
    TestDrivers.surfaceShade(-159.0f,69.0f,75.0f,512.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-74.58122f,2.830616E-5f,-79.69364f ) ;
  }

  @Test
  public void test721() {
    TestDrivers.surfaceShade(-1595.0f,13.0f,-401.0f,-28.0f,0f,0f,0f,-17.032082f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-84.175735f,-0.0027472528f,47.26387f ) ;
  }

  @Test
  public void test722() {
    TestDrivers.surfaceShade(161.0f,0f,0f,0f,467.0f,772.0f,-323.0f,-1145.0f,0f,0f,0f,0f,0f,847.0f,1042.0f,18.0f,-1076.0f,1984.0f,-389.0f,328,0.34964833f,-0.39316258f,0.30353817f,80.03608f,0f,0f ) ;
  }

  @Test
  public void test723() {
    TestDrivers.surfaceShade(-1620.0f,773.0f,0f,0f,99.0f,-2199.0f,0f,2.0f,0f,0f,0f,0f,0f,591.0f,-1274.0f,-1359.0f,0f,0f,0f,-832,-6.5692134f,10.663066f,-12.852944f,-72.097046f,21.290047f,0f ) ;
  }

  @Test
  public void test724() {
    TestDrivers.surfaceShade(1624.0f,-1034.0f,0f,0f,477.0f,-1693.0f,0f,-5.0f,0f,0f,0f,0f,0f,-954.0f,794.0f,-784.0f,0f,0f,0f,623,-0.21174645f,-0.26379025f,0.4886315f,-67.09025f,-14.67018f,0f ) ;
  }

  @Test
  public void test725() {
    TestDrivers.surfaceShade(164.0f,0f,0f,0f,737.0f,242.0f,165.0f,-396.0f,0f,0f,0f,0f,0f,153.0f,715.0f,-90.0f,95.0f,185.0f,-730.0f,706,100.0f,-100.0f,100.0f,100.0f,0f,0f ) ;
  }

  @Test
  public void test726() {
    TestDrivers.surfaceShade(1648.0f,-1283.0f,0f,0f,360.0f,0.0f,0f,-3.0f,0f,0f,0f,0f,0f,-924.0f,-431.0f,-403.0f,0f,0f,0f,-975,-1.5706662f,0.067347914f,3.5292027f,51.42025f,-50.23894f,0f ) ;
  }

  @Test
  public void test727() {
    TestDrivers.surfaceShade(-1648.0f,2585.0f,90.0f,0f,2093.0f,-471.0f,0f,-949.0f,0f,0f,0f,0f,0f,-241.0f,1522.0f,681.0f,0f,0f,0f,1634,-0.4955395f,-0.0885978f,-0.589333f,-100.0f,0.45410267f,-27.891695f ) ;
  }

  @Test
  public void test728() {
    TestDrivers.surfaceShade(166.0f,0f,0f,0f,419.0f,902.0f,0f,1277.0f,0f,0f,0f,0f,0f,-307.0f,157.0f,-417.0f,730.0f,498.0f,-764.0f,358,-31.833794f,72.22201f,50.627888f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test729() {
    TestDrivers.surfaceShade(167.0f,410.0f,0f,0f,555.0f,-655.0f,0f,121.0f,0f,0f,0f,0f,0f,-410.0f,-651.0f,-434.0f,1950.0f,136.0f,487.0f,16,-100.0f,60.56211f,100.0f,100.0f,85.191216f,0f ) ;
  }

  @Test
  public void test730() {
    TestDrivers.surfaceShade(-1674.0f,812.0f,566.0f,0f,746.0f,39.0f,0f,384.0f,0f,0f,0f,0f,0f,164.0f,-465.0f,618.0f,1236.0f,-767.0f,1017.0f,-389,-90.06204f,96.15412f,96.24893f,-100.0f,-77.18816f,16.967127f ) ;
  }

  @Test
  public void test731() {
    TestDrivers.surfaceShade(1693.0f,88.0f,0f,0f,672.0f,-189.0f,0f,435.0f,0f,0f,0f,0f,0f,789.0f,146.0f,-553.0f,-680.0f,771.0f,-297.0f,-1147,8.534726f,23.638187f,18.417856f,-46.604355f,74.77912f,0f ) ;
  }

  @Test
  public void test732() {
    TestDrivers.surfaceShade(170.0f,176.0f,0f,287.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,100.0f,1.9797277E-5f,0f ) ;
  }

  @Test
  public void test733() {
    TestDrivers.surfaceShade(-170.0f,1808.0f,-859.0f,-250.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,2.3529412E-5f,-5.685212f,91.01175f ) ;
  }

  @Test
  public void test734() {
    TestDrivers.surfaceShade(-1717.0f,0f,0f,0f,1561.0f,0.0f,0f,442.0f,0f,0f,0f,0f,0f,-632.0f,-435.0f,-243.0f,124.0f,484.0f,-729.0f,609,77.8264f,-12.377501f,19.81093f,100.0f,0f,0f ) ;
  }

  @Test
  public void test735() {
    TestDrivers.surfaceShade(1718.0f,0f,0f,0f,1190.0f,-3.0f,0f,741.0f,0f,0f,0f,0f,0f,289.0f,-2030.0f,844.0f,1373.0f,1284.0f,-171.0f,-1862,0.38356557f,-0.26360098f,-0.8359906f,11.548827f,0f,0f ) ;
  }

  @Test
  public void test736() {
    TestDrivers.surfaceShade(172.0f,0f,0f,0f,209.0f,2015.0f,0f,-392.0f,0f,0f,0f,0f,0f,1784.0f,-189.0f,-949.0f,-918.0f,-115.0f,573.0f,-225,0.079689376f,-0.013158568f,0.15242657f,4.753997f,0f,0f ) ;
  }

  @Test
  public void test737() {
    TestDrivers.surfaceShade(-1721.0f,186.0f,-1448.0f,0f,1863.0f,-365.0f,0f,-419.0f,0f,0f,0f,0f,0f,649.0f,-375.0f,363.0f,0f,0f,0f,-554,-0.17668404f,-0.038836427f,0.2638915f,-72.596504f,-28.188042f,-100.0f ) ;
  }

  @Test
  public void test738() {
    TestDrivers.surfaceShade(173.0f,229.0f,127.0f,0f,388.0f,-20.0f,0f,-322.0f,0f,0f,0f,0f,0f,-244.0f,664.0f,309.0f,0f,0f,0f,799,-99.32558f,-65.81761f,35.891582f,18.392351f,-16.88233f,2.4225812E-9f ) ;
  }

  @Test
  public void test739() {
    TestDrivers.surfaceShade(174.0f,1421.0f,-467.0f,0f,1439.0f,-1389.0f,0f,2269.0f,0f,0f,0f,0f,0f,150.0f,-2526.0f,258.0f,1781.0f,-776.0f,-720.0f,552,-0.56265575f,0.060658593f,-0.23879196f,-62.81169f,4.599149f,45.76891f ) ;
  }

  @Test
  public void test740() {
    TestDrivers.surfaceShade(-175.0f,1577.0f,0f,0f,464.0f,-500.0f,0f,0.0f,0f,0f,0f,0f,0f,407.0f,411.0f,14.0f,0f,0f,0f,233,-48.307217f,-11.081264f,100.0f,-5.39778E-10f,-100.0f,0f ) ;
  }

  @Test
  public void test741() {
    TestDrivers.surfaceShade(-1773.0f,1315.0f,-563.0f,0f,633.0f,-737.0f,0f,-309.0f,0f,0f,0f,0f,0f,-44.0f,-2491.0f,-342.0f,0f,0f,0f,748,0.79156286f,0.16473337f,-0.048052832f,-37.24277f,25.168474f,-22.950472f ) ;
  }

  @Test
  public void test742() {
    TestDrivers.surfaceShade(1781.0f,-854.0f,0f,0f,510.0f,1664.0f,0f,-839.0f,0f,0f,0f,0f,0f,746.0f,-13.0f,397.0f,548.0f,1005.0f,256.0f,1180,5.6195416f,-39.96556f,-11.868338f,100.0f,-99.99917f,0f ) ;
  }

  @Test
  public void test743() {
    TestDrivers.surfaceShade(1785.0f,0f,0f,0f,15.375906f,0.0f,0f,-60.218952f,0f,0f,0f,0f,0f,58.97173f,-30.779684f,-84.33077f,0f,0f,0f,892,-0.36556214f,0.20555134f,-0.3297245f,-46.87943f,0f,0f ) ;
  }

  @Test
  public void test744() {
    TestDrivers.surfaceShade(181.0f,0f,0f,0f,924.0f,373.0f,0f,-302.0f,0f,0f,0f,0f,0f,-933.0f,-899.0f,-1204.0f,-46.0f,-67.0f,412.0f,249,-33.923447f,-13.858985f,37.756935f,140.68715f,0f,0f ) ;
  }

  @Test
  public void test745() {
    TestDrivers.surfaceShade(-181.0f,-182.0f,-480.0f,0f,225.0f,-230.0f,0f,148.0f,0f,0f,0f,0f,0f,-465.0f,198.0f,350.0f,-711.0f,191.0f,895.0f,-546,-100.0f,-100.0f,-100.0f,100.0f,97.169266f,-100.0f ) ;
  }

  @Test
  public void test746() {
    TestDrivers.surfaceShade(181.0f,-745.0f,85.0f,0f,44.0f,-813.0f,0f,-939.0f,0f,0f,0f,0f,0f,275.0f,239.0f,1351.0f,0f,0f,0f,-1533,-2.1518342f,0.36183313f,-0.34343517f,-10.989472f,35.305134f,-100.0f ) ;
  }

  @Test
  public void test747() {
    TestDrivers.surfaceShade(1811.0f,215.0f,112.0f,0f,45.0f,-777.0f,0f,-815.0f,0f,0f,0f,0f,0f,834.0f,-2729.0f,502.0f,0f,0f,0f,-804,-0.9145415f,-0.24829969f,0.16955717f,93.9796f,-93.31527f,3.0890477f ) ;
  }

  @Test
  public void test748() {
    TestDrivers.surfaceShade(182.0f,840.0f,0f,0f,689.0f,-778.0f,0f,103.0f,0f,0f,0f,0f,0f,-933.0f,575.0f,-733.0f,843.0f,-715.0f,714.0f,-203,23.796757f,-33.531586f,-26.25591f,36.902946f,-70.3394f,0f ) ;
  }

  @Test
  public void test749() {
    TestDrivers.surfaceShade(1829.0f,-580.0f,-1336.0f,0f,1513.0f,1980.0f,0f,1723.0f,0f,0f,0f,0f,0f,1750.0f,450.0f,-629.0f,129.0f,-1699.0f,-846.0f,-1333,-0.14683588f,0.6121493f,0.4970705f,14.461593f,-21.55426f,34.98496f ) ;
  }

  @Test
  public void test750() {
    TestDrivers.surfaceShade(185.0f,-305.0f,0f,-1011.0f,0f,0f,0f,-64.86572f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,68.671234f,-6.637624f,0f ) ;
  }

  @Test
  public void test751() {
    TestDrivers.surfaceShade(-1868.0f,-501.0f,-1009.0f,0f,1185.0f,-348.0f,0f,34.0f,0f,0f,0f,0f,0f,469.0f,1129.0f,528.0f,-281.0f,-1141.0f,286.0f,528,-0.11918881f,-0.0930691f,-0.21931139f,-38.02067f,28.865337f,42.149837f ) ;
  }

  @Test
  public void test752() {
    TestDrivers.surfaceShade(-187.0f,-1963.0f,-263.0f,263.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-82.01149f,37.226788f,-1.4457343E-5f ) ;
  }

  @Test
  public void test753() {
    TestDrivers.surfaceShade(188.0f,645.0f,0f,343.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-100.0f,-100.0f,0f ) ;
  }

  @Test
  public void test754() {
    TestDrivers.surfaceShade(-1883.0f,858.0f,-16.0f,0f,1754.0f,-540.0f,0f,782.0f,0f,0f,0f,0f,0f,-649.0f,-224.0f,1398.0f,-303.0f,85.0f,23.0f,101,0.61805713f,0.74624944f,0.2022436f,62.77325f,-22.21824f,-3.2858238f ) ;
  }

  @Test
  public void test755() {
    TestDrivers.surfaceShade(190.0f,-720.0f,201.0f,0f,48.0f,-1616.0f,0f,1.0f,0f,0f,0f,0f,0f,-686.0f,-795.0f,907.0f,0f,0f,0f,-545,45.030148f,-48.05534f,-15.05914f,-38.921745f,100.0f,0.9605818f ) ;
  }

  @Test
  public void test756() {
    TestDrivers.surfaceShade(19.0f,-1442.0f,0f,0f,20.0f,-811.0f,0f,159.0f,0f,0f,0f,0f,0f,-296.0f,-423.0f,-826.0f,-695.0f,-937.0f,878.0f,1241,-0.63485634f,-0.4482083f,0.45703578f,1.3293599f,71.629875f,0f ) ;
  }

  @Test
  public void test757() {
    TestDrivers.surfaceShade(-19.0f,-446.0f,0f,0f,1651.0f,-4.0f,0f,338.0f,0f,0f,0f,0f,0f,242.0f,152.0f,-161.0f,-1499.0f,552.0f,929.0f,-475,-10.482082f,3.7906666f,-12.17691f,-37.964577f,61.9594f,0f ) ;
  }

  @Test
  public void test758() {
    TestDrivers.surfaceShade(-19.0f,635.0f,18.0f,0f,41.0f,962.0f,0f,-692.0f,0f,0f,0f,0f,0f,342.0f,174.0f,-223.0f,-1327.0f,-246.0f,1980.0f,728,-31.77013f,-55.248608f,-91.83248f,-3.6251996f,-61.174133f,61.211555f ) ;
  }

  @Test
  public void test759() {
    TestDrivers.surfaceShade(193.0f,906.0f,-987.0f,112.0f,0f,0f,0f,-48.12533f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,-0.6834362f,9.854935E-6f,6.6069627f ) ;
  }

  @Test
  public void test760() {
    TestDrivers.surfaceShade(-194.0f,-289.0f,0f,0f,909.0f,975.0f,-618.0f,721.0f,0f,0f,0f,0f,0f,1257.0f,503.0f,-188.0f,668.0f,-858.0f,-2.0f,563,-77.199326f,79.36494f,39.657703f,37.13653f,-50.694588f,0f ) ;
  }

  @Test
  public void test761() {
    TestDrivers.surfaceShade(1966.0f,-896.0f,0f,0f,523.0f,278.0f,0f,-1813.0f,0f,0f,0f,0f,0f,-785.0f,1226.0f,-748.0f,1088.0f,493.0f,569.0f,416,0.43048254f,-0.3891923f,0.75919724f,-62.547806f,23.918655f,0f ) ;
  }

  @Test
  public void test762() {
    TestDrivers.surfaceShade(-1967.0f,-407.0f,-1738.0f,0f,808.0f,-239.0f,0f,-688.0f,0f,0f,0f,0f,0f,-767.0f,-571.0f,-484.0f,0f,0f,0f,226,68.178444f,44.907574f,-3.5709639f,-48.248398f,-3.9902567E-11f,84.993996f ) ;
  }

  @Test
  public void test763() {
    TestDrivers.surfaceShade(198.0f,533.0f,0f,-234.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,100.0f,-8.0178315E-6f,0f ) ;
  }

  @Test
  public void test764() {
    TestDrivers.surfaceShade(1990.0f,673.0f,1283.0f,0f,941.0f,1019.0f,0f,1210.0f,0f,0f,0f,0f,0f,503.0f,-493.0f,-331.0f,-1553.0f,237.0f,591.0f,-543,66.56504f,81.71635f,-20.55572f,79.74361f,-7.0101233f,80.8352f ) ;
  }

  @Test
  public void test765() {
    TestDrivers.surfaceShade(199.0f,0f,0f,0f,29.0f,-342.0f,0f,2304.0f,0f,0f,0f,0f,0f,535.0f,480.0f,-369.0f,-1333.0f,-110.0f,-56.0f,905,0.42547664f,-0.88327384f,0.19696946f,-58.048313f,0f,0f ) ;
  }

  @Test
  public void test766() {
    TestDrivers.surfaceShade(-201.0f,-141.0f,-627.0f,112.0f,0f,0f,0f,-28.023882f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-1.6275004f,-6.3323205E-5f,74.35306f ) ;
  }

  @Test
  public void test767() {
    TestDrivers.surfaceShade(203.0f,210.0f,0f,966.0f,0f,0f,0f,-46.99268f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,5.099491E-6f,-85.650955f,0f ) ;
  }

  @Test
  public void test768() {
    TestDrivers.surfaceShade(2031.0f,-346.0f,656.0f,0f,376.0f,-276.0f,0f,2166.0f,0f,0f,0f,0f,0f,-84.0f,-18.0f,845.0f,-1082.0f,-739.0f,1001.0f,-163,-0.021127922f,-0.16220552f,-0.10153515f,11.658243f,-64.30168f,29.92092f ) ;
  }

  @Test
  public void test769() {
    TestDrivers.surfaceShade(-206.0f,-105.0f,0f,0f,38.0f,-1147.0f,0f,158.0f,0f,0f,0f,0f,0f,-362.0f,353.0f,428.0f,747.0f,-783.0f,-988.0f,-51,-0.6654873f,-0.25982708f,-0.34856984f,63.82723f,-0.57713014f,0f ) ;
  }

  @Test
  public void test770() {
    TestDrivers.surfaceShade(-2080.0f,993.0f,0f,0f,441.0f,-1.0f,0f,988.0f,0f,0f,0f,0f,0f,806.0f,486.0f,-559.0f,676.0f,-878.0f,672.0f,-1237,78.088104f,-79.63416f,43.357437f,-113.532295f,231.56645f,0f ) ;
  }

  @Test
  public void test771() {
    TestDrivers.surfaceShade(209.0f,0f,0f,758.0f,0f,0f,0f,-9.544314f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-12.73614f,0f,0f ) ;
  }

  @Test
  public void test772() {
    TestDrivers.surfaceShade(2099.0f,-11.0f,0f,0f,244.0f,-3958.0f,0f,-5.0f,0f,0f,0f,0f,0f,213.0f,-349.0f,876.0f,0f,0f,0f,-989,0.7540106f,-0.30963722f,-0.312297f,100.0f,0.54343015f,0f ) ;
  }

  @Test
  public void test773() {
    TestDrivers.surfaceShade(-2.0f,0f,0f,0f,14.0f,936.0f,0f,515.0f,0f,0f,0f,0f,0f,-1303.0f,-950.0f,789.0f,254.0f,238.0f,-808.0f,-1107,0.6710455f,-0.5480912f,0.44817063f,2.0989108f,0f,0f ) ;
  }

  @Test
  public void test774() {
    TestDrivers.surfaceShade(-2.0f,865.0f,1002.0f,12.0f,0f,0f,0f,-24.074982f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-0.041666668f,9.6339114E-5f,26.623386f ) ;
  }

  @Test
  public void test775() {
    TestDrivers.surfaceShade(-21.0f,482.0f,0f,229.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-78.92862f,59.250698f,0f ) ;
  }

  @Test
  public void test776() {
    TestDrivers.surfaceShade(2110.0f,-673.0f,632.0f,-1683.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-100.0f,58.345066f,4.4664454f ) ;
  }

  @Test
  public void test777() {
    TestDrivers.surfaceShade(214.0f,-459.0f,-102.0f,0f,40.0f,-1223.0f,0f,-4.0f,0f,0f,0f,0f,0f,-162.0f,-565.0f,968.0f,0f,0f,0f,-420,0.86486953f,0.19370812f,0.25780365f,-100.0f,-100.0f,-88.83397f ) ;
  }

  @Test
  public void test778() {
    TestDrivers.surfaceShade(-2187.0f,1180.0f,1207.0f,0f,610.0f,1118.0f,0f,1298.0f,0f,0f,0f,0f,0f,-449.0f,277.0f,-46.0f,1854.0f,809.0f,667.0f,711,-62.2735f,-92.01145f,53.77453f,-42.686443f,46.66703f,-100.0f ) ;
  }

  @Test
  public void test779() {
    TestDrivers.surfaceShade(2203.0f,-1054.0f,-1297.0f,0f,692.0f,-824.0f,0f,1102.0f,0f,0f,0f,0f,0f,-1488.0f,399.0f,-408.0f,1058.0f,-861.0f,-101.0f,1452,-25.146515f,-20.30455f,71.854164f,46.13078f,-100.0f,-1.4151367f ) ;
  }

  @Test
  public void test780() {
    TestDrivers.surfaceShade(22.0f,-334.0f,-726.0f,0f,1245.0f,250.0f,0f,-958.0f,0f,0f,0f,0f,0f,520.0f,302.0f,-148.0f,1209.0f,-133.0f,-370.0f,181,-80.10076f,100.0f,-77.381065f,86.49463f,18.67416f,-2.626491f ) ;
  }

  @Test
  public void test781() {
    TestDrivers.surfaceShade(221.0f,392.0f,40.0f,109.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,4.1512725E-5f,5.752594f,2.293578E-4f ) ;
  }

  @Test
  public void test782() {
    TestDrivers.surfaceShade(-222.0f,-1584.0f,0f,0f,2206.0f,1007.0f,0f,564.0f,0f,0f,0f,0f,0f,1871.0f,-33.0f,804.0f,-1324.0f,-985.0f,-1469.0f,-25,-0.5974888f,0.21730202f,0.3752274f,-46.94443f,73.50005f,0f ) ;
  }

  @Test
  public void test783() {
    TestDrivers.surfaceShade(-225.0f,0f,1163.0f,0f,1363.0f,-1247.0f,0f,548.0f,0f,0f,0f,0f,0f,52.0f,639.0f,1050.0f,1143.0f,-1673.0f,-198.0f,-1423,1.1585329f,-0.6030576f,0.30962867f,45.412773f,0f,128.43117f ) ;
  }

  @Test
  public void test784() {
    TestDrivers.surfaceShade(-2256.0f,55.0f,1522.0f,0f,442.0f,-1210.0f,0f,156.0f,0f,0f,0f,0f,0f,671.0f,346.0f,642.0f,212.0f,228.0f,898.0f,-1205,-22.809374f,57.934742f,-7.3836927f,2.4615045f,7.294319f,38.675728f ) ;
  }

  @Test
  public void test785() {
    TestDrivers.surfaceShade(227.0f,759.0f,-1105.0f,0f,248.0f,-235.0f,0f,-1569.0f,0f,0f,0f,0f,0f,83.0f,1465.0f,1010.0f,0f,0f,0f,1988,0.5961639f,-0.43526548f,0.2448145f,-55.796284f,60.867073f,6.716957f ) ;
  }

  @Test
  public void test786() {
    TestDrivers.surfaceShade(228.0f,-1732.0f,-321.0f,0f,5.0f,121.0f,0f,-2427.0f,0f,0f,0f,0f,0f,111.0f,577.0f,960.0f,209.0f,-909.0f,441.0f,3302,38.975407f,79.33128f,-52.18794f,-48.212536f,-2.390256f,-12.896958f ) ;
  }

  @Test
  public void test787() {
    TestDrivers.surfaceShade(-23.0f,-1636.0f,0f,0f,588.0f,1108.0f,0f,539.0f,0f,0f,0f,0f,0f,323.0f,350.0f,674.0f,729.0f,545.0f,-1655.0f,534,-31.348064f,-98.13132f,65.981285f,-0.28999096f,-94.74043f,0f ) ;
  }

  @Test
  public void test788() {
    TestDrivers.surfaceShade(-2313.0f,0f,0f,0f,689.0f,1221.0f,-1981.0f,-1806.0f,0f,0f,0f,0f,0f,-1849.0f,1333.0f,811.0f,295.0f,380.0f,657.0f,2434,0.12354724f,-0.46414357f,-0.87710136f,100.0f,0f,0f ) ;
  }

  @Test
  public void test789() {
    TestDrivers.surfaceShade(232.0f,-210.0f,-862.0f,0f,624.0f,-824.0f,0f,-540.0f,0f,0f,0f,0f,0f,160.0f,-939.0f,911.0f,0f,0f,0f,983,77.103836f,8.620845f,-4.656027f,-86.93964f,-96.62729f,68.79585f ) ;
  }

  @Test
  public void test790() {
    TestDrivers.surfaceShade(234.0f,-30.0f,0f,0f,20.0f,-1848.0f,0f,-6.0f,0f,0f,0f,0f,0f,687.0f,661.0f,-1076.0f,0f,0f,0f,-603,0.6746378f,-0.70582765f,0.03994492f,-6.1309967f,-3.618731E-5f,0f ) ;
  }

  @Test
  public void test791() {
    TestDrivers.surfaceShade(-235.0f,-1213.0f,36.0f,0f,115.0f,280.0f,0f,969.0f,0f,0f,0f,0f,0f,-347.0f,840.0f,325.0f,424.0f,-853.0f,-292.0f,-366,-0.5872739f,-0.033393003f,-0.54072046f,45.007153f,4.0244994f,4.9144835f ) ;
  }

  @Test
  public void test792() {
    TestDrivers.surfaceShade(2360.0f,-914.0f,637.0f,0f,1441.0f,2169.0f,0f,-1448.0f,0f,0f,0f,0f,0f,-415.0f,70.0f,-160.0f,-159.0f,-1233.0f,2000.0f,-180,23.395538f,91.86657f,-20.490557f,100.0f,-50.956875f,73.064354f ) ;
  }

  @Test
  public void test793() {
    TestDrivers.surfaceShade(-236.0f,-227.0f,-814.0f,0f,510.0f,-1778.0f,0f,2.0f,0f,0f,0f,0f,0f,321.0f,400.0f,656.0f,0f,0f,0f,-486,32.553375f,-21.362421f,-2.9034529f,-83.374626f,-41.684395f,71.446465f ) ;
  }

  @Test
  public void test794() {
    TestDrivers.surfaceShade(236.0f,-643.0f,3.0f,0f,2580.0f,1008.0f,0f,783.0f,0f,0f,0f,0f,0f,-163.0f,-296.0f,-989.0f,-1361.0f,816.0f,260.0f,-260,34.97948f,60.816483f,-23.96697f,-100.0f,-100.0f,100.0f ) ;
  }

  @Test
  public void test795() {
    TestDrivers.surfaceShade(-2376.0f,-842.0f,668.0f,0f,582.0f,-578.0f,0f,1354.0f,0f,0f,0f,0f,0f,233.0f,706.0f,17.0f,-798.0f,-237.0f,-565.0f,-850,-50.800644f,15.857277f,37.724277f,-78.68132f,-26.041763f,32.825436f ) ;
  }

  @Test
  public void test796() {
    TestDrivers.surfaceShade(-2388.0f,1284.0f,524.0f,0f,23.0f,685.0f,0f,847.0f,0f,0f,0f,0f,0f,1451.0f,-1382.0f,652.0f,-335.0f,698.0f,-338.0f,-339,-0.003669691f,-0.33140352f,-0.69428676f,78.90388f,80.16602f,3.1944647f ) ;
  }

  @Test
  public void test797() {
    TestDrivers.surfaceShade(239.0f,-1213.0f,-1208.0f,0f,1276.0f,1328.0f,0f,-89.0f,0f,0f,0f,0f,0f,329.0f,-833.0f,235.0f,-491.0f,282.0f,-1127.0f,932,-0.48611897f,28.019287f,100.0f,70.65343f,-100.0f,-30.811033f ) ;
  }

  @Test
  public void test798() {
    TestDrivers.surfaceShade(-2401.0f,666.0f,0f,454.0f,0f,0f,0f,-89.91747f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-46.79922f,3.307272E-6f,0f ) ;
  }

  @Test
  public void test799() {
    TestDrivers.surfaceShade(-2402.0f,0f,0f,0f,99.0f,-74.0f,0f,212.0f,0f,0f,0f,0f,0f,-981.0f,1491.0f,-49.0f,764.0f,-271.0f,-454.0f,862,-0.032231517f,-0.7795676f,-0.6255083f,-21.246065f,0f,0f ) ;
  }

  @Test
  public void test800() {
    TestDrivers.surfaceShade(241.0f,652.0f,1625.0f,0f,691.0f,97.0f,0f,-244.0f,0f,0f,0f,0f,0f,963.0f,-230.0f,231.0f,-893.0f,375.0f,686.0f,179,-0.122665f,-0.22433609f,-0.5187756f,-59.349743f,-100.0f,21.708588f ) ;
  }

  @Test
  public void test801() {
    TestDrivers.surfaceShade(242.0f,-165.0f,-1251.0f,0f,258.0f,-1680.0f,0f,-565.0f,0f,0f,0f,0f,0f,-140.0f,-638.0f,-62.0f,0f,0f,0f,245,-24.242075f,10.981262f,-58.260567f,100.0f,-59.77633f,-68.4626f ) ;
  }

  @Test
  public void test802() {
    TestDrivers.surfaceShade(242.0f,-202.0f,-430.0f,907.0f,0f,0f,0f,-56.568867f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-2,0f,0f,0f,-115.657524f,78.868324f,-90.247765f ) ;
  }

  @Test
  public void test803() {
    TestDrivers.surfaceShade(243.0f,0f,0f,0f,14.132008f,-99.54497f,0f,0.0f,0f,0f,0f,0f,0f,-55.613308f,93.39637f,-14.550887f,0f,0f,0f,-722,1.1134601f,0.65283024f,-0.06537152f,37.591858f,0f,0f ) ;
  }

  @Test
  public void test804() {
    TestDrivers.surfaceShade(-244.0f,192.0f,0f,0f,1000.0f,-89.0f,0f,2383.0f,0f,0f,0f,0f,0f,134.0f,164.0f,-143.0f,-2982.0f,-504.0f,965.0f,-1068,-0.71255606f,0.082096964f,-0.5735567f,-1.0730798f,2.0933106f,0f ) ;
  }

  @Test
  public void test805() {
    TestDrivers.surfaceShade(249.0f,653.0f,0f,0f,265.0f,-1553.0f,0f,-423.0f,0f,0f,0f,0f,0f,1873.0f,316.0f,724.0f,0f,0f,0f,395,-46.53358f,62.843807f,92.95408f,100.0f,38.22496f,0f ) ;
  }

  @Test
  public void test806() {
    TestDrivers.surfaceShade(-25.0f,0f,0f,0f,32.719673f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-26.921604f,26.686428f,0.3429612f,0f,0f,0f,1797,-100.0f,-99.82741f,-82.001884f,-71.948685f,0f,0f ) ;
  }

  @Test
  public void test807() {
    TestDrivers.surfaceShade(251.0f,0f,0f,0f,400.0f,834.0f,-817.0f,-17.0f,0f,0f,0f,0f,0f,408.0f,-1.0f,-312.0f,307.0f,581.0f,-397.0f,512,55.25458f,46.748787f,100.0f,30.680923f,0f,0f ) ;
  }

  @Test
  public void test808() {
    TestDrivers.surfaceShade(-251.0f,-179.0f,0f,0f,151.0f,919.0f,0f,-203.0f,0f,0f,0f,0f,0f,-223.0f,42.0f,-1082.0f,-704.0f,-2133.0f,1531.0f,2607,0.03064443f,0.16699654f,1.6649844E-4f,13.000425f,-8.080613f,0f ) ;
  }

  @Test
  public void test809() {
    TestDrivers.surfaceShade(-252.0f,-259.0f,0f,-170.0f,0f,0f,0f,859.0f,0f,0f,0f,0f,0f,-970.0f,-687.0f,-769.0f,781.0f,-87.0f,782.0f,5,0f,0f,0f,2.334267E-5f,53.887714f,0f ) ;
  }

  @Test
  public void test810() {
    TestDrivers.surfaceShade(-253.0f,-284.0f,695.0f,0f,1333.0f,-550.0f,0f,3.0f,0f,0f,0f,0f,0f,-979.0f,479.0f,-441.0f,0f,0f,0f,-1005,18.604416f,4.882831f,-35.997383f,-13.188447f,-1.5718055E-5f,45.23056f ) ;
  }

  @Test
  public void test811() {
    TestDrivers.surfaceShade(-256.0f,0f,0f,0f,235.0f,0.0f,0f,30.0f,0f,0f,0f,0f,0f,-323.0f,1002.0f,-937.0f,40.0f,-1298.0f,654.0f,1806,-1.0981369f,-1.3562075f,-1.047138f,28.407541f,0f,0f ) ;
  }

  @Test
  public void test812() {
    TestDrivers.surfaceShade(256.0f,536.0f,0f,0f,825.0f,-2.0f,0f,-762.0f,0f,0f,0f,0f,0f,-832.0f,253.0f,-403.0f,0f,0f,0f,-859,13.865442f,27.945498f,39.864407f,94.89714f,14.468813f,0f ) ;
  }

  @Test
  public void test813() {
    TestDrivers.surfaceShade(258.0f,-674.0f,-70.0f,0f,85.0f,843.0f,0f,-243.0f,0f,0f,0f,0f,0f,-42.0f,227.0f,-549.0f,978.0f,-455.0f,121.0f,-823,-0.046617623f,0.79342973f,0.56218636f,11.769335f,11.092774f,-89.74804f ) ;
  }

  @Test
  public void test814() {
    TestDrivers.surfaceShade(258.0f,883.0f,0f,0f,48.0f,1622.0f,0f,749.0f,0f,0f,0f,0f,0f,-52.0f,-55.0f,-59.0f,882.0f,850.0f,329.0f,-248,-0.6108145f,-0.1735289f,0.70010924f,-100.0f,9.624278f,0f ) ;
  }

  @Test
  public void test815() {
    TestDrivers.surfaceShade(-26.0f,389.0f,-399.0f,0f,418.0f,-408.0f,0f,508.0f,0f,0f,0f,0f,0f,-961.0f,819.0f,759.0f,971.0f,-308.0f,-163.0f,-182,-75.67994f,-94.3664f,6.0048227f,-94.262535f,-68.60372f,28.868086f ) ;
  }

  @Test
  public void test816() {
    TestDrivers.surfaceShade(263.0f,-273.0f,-835.0f,0f,190.0f,-756.0f,0f,325.0f,0f,0f,0f,0f,0f,-808.0f,-509.0f,-522.0f,1294.0f,-971.0f,-219.0f,-618,-22.095448f,57.815025f,-22.173807f,-12.840567f,-60.6822f,-44.432625f ) ;
  }

  @Test
  public void test817() {
    TestDrivers.surfaceShade(2673.0f,0f,0f,0f,350.0f,-7.0f,0f,1241.0f,0f,0f,0f,0f,0f,-1102.0f,-1392.0f,-317.0f,-656.0f,1685.0f,2220.0f,535,0.18608975f,0.19578986f,0.035734158f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test818() {
    TestDrivers.surfaceShade(-2673.0f,159.0f,-2311.0f,0f,1872.0f,49.0f,0f,-456.0f,0f,0f,0f,0f,0f,-389.0f,45.0f,630.0f,2156.0f,-1859.0f,1086.0f,272,-75.56713f,-63.835445f,-42.100033f,-98.81737f,-19.655308f,-99.278244f ) ;
  }

  @Test
  public void test819() {
    TestDrivers.surfaceShade(270.0f,1339.0f,-1957.0f,0f,1202.0f,-1596.0f,0f,140.0f,0f,0f,0f,0f,0f,-2508.0f,-261.0f,477.0f,819.0f,-48.0f,2149.0f,485,0.3201256f,-0.5473145f,-0.20583425f,-41.5423f,99.85503f,37.516697f ) ;
  }

  @Test
  public void test820() {
    TestDrivers.surfaceShade(2704.0f,-822.0f,1468.0f,0f,2596.0f,43.0f,0f,372.0f,0f,0f,0f,0f,0f,-58.0f,444.0f,647.0f,-352.0f,2131.0f,975.0f,702,91.39195f,-91.21727f,70.790115f,100.0f,100.0f,-100.0f ) ;
  }

  @Test
  public void test821() {
    TestDrivers.surfaceShade(-271.0f,-281.0f,0f,0f,98.0f,-1222.0f,0f,1404.0f,0f,0f,0f,0f,0f,599.0f,974.0f,-308.0f,1451.0f,-265.0f,1561.0f,222,-0.4043047f,0.2878261f,0.12391018f,-19.058403f,0.72722536f,0f ) ;
  }

  @Test
  public void test822() {
    TestDrivers.surfaceShade(273.0f,0f,0f,0f,768.0f,581.0f,701.0f,-10.0f,0f,0f,0f,0f,0f,-71.0f,143.0f,224.0f,765.0f,-340.0f,609.0f,-531,-35.14728f,-32.819412f,80.3665f,-94.04588f,0f,0f ) ;
  }

  @Test
  public void test823() {
    TestDrivers.surfaceShade(-273.0f,705.0f,0f,0f,607.0f,-55.0f,0f,-780.0f,0f,0f,0f,0f,0f,-199.0f,-62.0f,765.0f,0f,0f,0f,3003,1.1116916f,1.8591235f,0.4398592f,100.0f,92.69592f,0f ) ;
  }

  @Test
  public void test824() {
    TestDrivers.surfaceShade(-276.0f,-278.0f,720.0f,582.0f,0f,0f,0f,-65.10301f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,115.30667f,77.94419f,-67.82423f ) ;
  }

  @Test
  public void test825() {
    TestDrivers.surfaceShade(277.0f,-1423.0f,0f,0f,1814.0f,353.0f,0f,394.0f,0f,0f,0f,0f,0f,-768.0f,111.0f,699.0f,-201.0f,-601.0f,-1189.0f,9,0.011372688f,-0.030245576f,-0.37724876f,-100.0f,86.865524f,0f ) ;
  }

  @Test
  public void test826() {
    TestDrivers.surfaceShade(-280.0f,0f,0f,0f,-458.0f,-1000.0f,831.0f,-788.0f,0f,0f,0f,0f,0f,-617.0f,288.0f,-958.0f,64.0f,688.0f,327.0f,390,-85.49033f,-23.182512f,-52.854645f,45.596474f,0f,0f ) ;
  }

  @Test
  public void test827() {
    TestDrivers.surfaceShade(28.0f,-669.0f,-201.0f,0f,546.0f,69.0f,-24.0f,249.0f,0f,0f,0f,0f,0f,-13.0f,797.0f,-184.0f,-48.0f,779.0f,-435.0f,-235,-38.439358f,-48.63668f,38.043896f,21.751514f,39.359295f,-42.077118f ) ;
  }

  @Test
  public void test828() {
    TestDrivers.surfaceShade(28.0f,731.0f,-655.0f,0f,50.0f,-498.0f,0f,-311.0f,0f,0f,0f,0f,0f,294.0f,-402.0f,-795.0f,0f,0f,0f,541,38.955338f,4.810345f,88.85979f,-65.21415f,98.65575f,94.45407f ) ;
  }

  @Test
  public void test829() {
    TestDrivers.surfaceShade(281.0f,845.0f,-632.0f,0f,1097.0f,350.0f,0f,41.0f,0f,0f,0f,0f,0f,-685.0f,359.0f,-222.0f,-423.0f,-1108.0f,-846.0f,-257,10.948399f,61.661144f,65.931076f,-82.24672f,5.363187f,45.5812f ) ;
  }

  @Test
  public void test830() {
    TestDrivers.surfaceShade(29.0f,131.0f,1684.0f,0f,1481.0f,298.0f,0f,-231.0f,0f,0f,0f,0f,0f,798.0f,-86.0f,-437.0f,-152.0f,993.0f,858.0f,-514,13.526604f,-51.6478f,34.864853f,-86.73016f,84.08404f,-41.976196f ) ;
  }

  @Test
  public void test831() {
    TestDrivers.surfaceShade(-297.0f,885.0f,600.0f,0f,682.0f,-1389.0f,0f,-539.0f,0f,0f,0f,0f,0f,712.0f,175.0f,351.0f,0f,0f,0f,-64,14.4417095f,55.558826f,-56.995132f,-56.740387f,21.81579f,28.424011f ) ;
  }

  @Test
  public void test832() {
    TestDrivers.surfaceShade(-298.0f,757.0f,-817.0f,0f,40.0f,847.0f,0f,626.0f,0f,0f,0f,0f,0f,-420.0f,582.0f,799.0f,555.0f,-968.0f,-997.0f,-10,66.02348f,53.71665f,-86.7353f,9.729255f,4.446123f,-94.371376f ) ;
  }

  @Test
  public void test833() {
    TestDrivers.surfaceShade(-2995.0f,0f,0f,0f,38.881058f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,18.17609f,99.999825f,100.0f,0f,0f,0f,1528,0.69328374f,-0.68766284f,0.21559112f,87.585266f,0f,0f ) ;
  }

  @Test
  public void test834() {
    TestDrivers.surfaceShade(301.0f,0f,0f,0f,100.0f,-100.0f,0f,-100.0f,0f,0f,0f,0f,0f,100.0f,-100.0f,100.0f,0f,0f,0f,-824,100.0f,100.0f,-100.0f,100.0f,0f,0f ) ;
  }

  @Test
  public void test835() {
    TestDrivers.surfaceShade(-303.0f,429.0f,289.0f,0f,504.0f,-939.0f,0f,-962.0f,0f,0f,0f,0f,0f,-945.0f,732.0f,-162.0f,0f,0f,0f,372,42.578156f,27.886395f,48.132275f,-72.979706f,85.35965f,-6.5286574f ) ;
  }

  @Test
  public void test836() {
    TestDrivers.surfaceShade(304.0f,0f,0f,0f,17.158161f,0.0f,0f,-33.62334f,0f,0f,0f,0f,0f,-39.293835f,-85.023636f,-97.56493f,0f,0f,0f,663,-59.49189f,75.51582f,-41.848705f,80.28808f,0f,0f ) ;
  }

  @Test
  public void test837() {
    TestDrivers.surfaceShade(-305.0f,0f,0f,0f,442.0f,-267.0f,0f,325.0f,0f,0f,0f,0f,0f,-435.0f,117.0f,-81.0f,310.0f,-730.0f,91.0f,416,-10.310839f,-85.990685f,-50.75518f,3.6391976f,0f,0f ) ;
  }

  @Test
  public void test838() {
    TestDrivers.surfaceShade(306.0f,0f,857.0f,0f,380.0f,982.0f,0f,17.0f,0f,0f,0f,0f,0f,757.0f,896.0f,-593.0f,151.0f,-2224.0f,-1418.0f,415,27.178026f,32.539257f,83.85993f,95.985504f,0f,34.272537f ) ;
  }

  @Test
  public void test839() {
    TestDrivers.surfaceShade(-308.0f,910.0f,912.0f,0f,1268.0f,580.0f,0f,868.0f,0f,0f,0f,0f,0f,259.0f,925.0f,-907.0f,-700.0f,-1039.0f,-784.0f,119,-65.258736f,-30.128529f,-48.505856f,40.853672f,-40.85524f,-49.16009f ) ;
  }

  @Test
  public void test840() {
    TestDrivers.surfaceShade(-310.0f,-323.0f,497.0f,0f,189.0f,1377.0f,0f,16.0f,0f,0f,0f,0f,0f,356.0f,-893.0f,-936.0f,-625.0f,-349.0f,-91.0f,-749,76.07016f,-60.60383f,86.75234f,-91.42208f,-32.6102f,20.82668f ) ;
  }

  @Test
  public void test841() {
    TestDrivers.surfaceShade(310.0f,-736.0f,0f,0f,902.0f,-429.0f,0f,0.0f,0f,0f,0f,0f,0f,-293.0f,-431.0f,674.0f,0f,0f,0f,674,1.5527133f,110.80383f,-29.720385f,-84.71363f,72.127884f,0f ) ;
  }

  @Test
  public void test842() {
    TestDrivers.surfaceShade(-31.0f,941.0f,0f,401.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-8.044405E-5f,23.153372f,0f ) ;
  }

  @Test
  public void test843() {
    TestDrivers.surfaceShade(3117.0f,-2392.0f,-1650.0f,0f,2038.0f,1319.0f,0f,-50.0f,0f,0f,0f,0f,0f,99.0f,-399.0f,-633.0f,-429.0f,584.0f,72.0f,405,31.499847f,-99.29302f,67.51406f,52.769745f,0.9792148f,-100.0f ) ;
  }

  @Test
  public void test844() {
    TestDrivers.surfaceShade(-317.0f,753.0f,-753.0f,0f,36.0f,-1509.0f,0f,424.0f,0f,0f,0f,0f,0f,-954.0f,607.0f,-973.0f,-720.0f,-35.0f,-2187.0f,-519,-24.643393f,54.42895f,58.11734f,46.23145f,-85.39252f,19.767452f ) ;
  }

  @Test
  public void test845() {
    TestDrivers.surfaceShade(32.0f,228.0f,-76.0f,0f,508.0f,-600.0f,0f,319.0f,0f,0f,0f,0f,0f,-429.0f,15.0f,-399.0f,-942.0f,-430.0f,139.0f,530,100.0f,85.167175f,-68.04877f,100.0f,20.43908f,-100.0f ) ;
  }

  @Test
  public void test846() {
    TestDrivers.surfaceShade(-32.0f,-60.0f,-3089.0f,-13.0f,0f,0f,0f,1.9721523E-31f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,0.0024038462f,0.0012820513f,60.356483f ) ;
  }

  @Test
  public void test847() {
    TestDrivers.surfaceShade(-323.0f,0f,0f,0f,465.0f,432.0f,0f,-382.0f,0f,0f,0f,0f,0f,975.0f,-181.0f,1720.0f,-648.0f,-833.0f,-2103.0f,63,-0.52149886f,0.017219968f,-0.37904787f,-52.551025f,0f,0f ) ;
  }

  @Test
  public void test848() {
    TestDrivers.surfaceShade(327.0f,0f,0f,0f,22.748049f,0.0f,0f,-42.534187f,0f,0f,0f,0f,0f,20.09885f,-5.048011f,-35.951992f,0f,0f,0f,-2626,-0.43174165f,-0.5374828f,-0.16589548f,7.11921f,0f,0f ) ;
  }

  @Test
  public void test849() {
    TestDrivers.surfaceShade(327.0f,-795.0f,-1107.0f,0f,1165.0f,1207.0f,0f,806.0f,0f,0f,0f,0f,0f,-612.0f,996.0f,-500.0f,2074.0f,-1211.0f,-475.0f,571,-36.42781f,-4.188486f,36.244175f,27.23676f,-12.226875f,-2.33853f ) ;
  }

  @Test
  public void test850() {
    TestDrivers.surfaceShade(328.0f,-2230.0f,407.0f,0f,2.0f,0.0f,0f,-938.0f,0f,0f,0f,0f,0f,466.0f,-874.0f,320.0f,0f,0f,0f,906,12.230286f,-6.8012176f,-36.38618f,71.49615f,100.0f,6.1067066f ) ;
  }

  @Test
  public void test851() {
    TestDrivers.surfaceShade(-330.0f,-45.0f,713.0f,0f,557.0f,-592.0f,0f,7.0f,0f,0f,0f,0f,0f,37.0f,-742.0f,1722.0f,0f,0f,0f,102,-0.50596493f,-0.4791224f,-0.20396115f,20.666012f,100.0f,-2.3081632f ) ;
  }

  @Test
  public void test852() {
    TestDrivers.surfaceShade(-332.0f,0f,0f,0f,3.0f,-921.0f,0f,753.0f,0f,0f,0f,0f,0f,-182.0f,-86.0f,919.0f,529.0f,-97.0f,930.0f,-714,77.25973f,-1.5345632f,-10.972994f,-24.819174f,0f,0f ) ;
  }

  @Test
  public void test853() {
    TestDrivers.surfaceShade(332.0f,-2031.0f,0f,0f,1204.0f,-775.0f,0f,1913.0f,0f,0f,0f,0f,0f,1730.0f,-616.0f,843.0f,-1417.0f,1516.0f,-927.0f,-380,0.2130877f,-0.51497024f,-0.8303007f,-6.0186462f,-10.417903f,0f ) ;
  }

  @Test
  public void test854() {
    TestDrivers.surfaceShade(-332.0f,-519.0f,-955.0f,0f,148.0f,-579.0f,0f,873.0f,0f,0f,0f,0f,0f,633.0f,624.0f,794.0f,-178.0f,-149.0f,853.0f,831,-41.500256f,-95.80427f,-13.281464f,-10.415229f,49.73251f,1.1812321f ) ;
  }

  @Test
  public void test855() {
    TestDrivers.surfaceShade(-333.0f,300.0f,839.0f,0f,937.0f,1128.0f,0f,212.0f,0f,0f,0f,0f,0f,680.0f,-607.0f,-355.0f,1555.0f,-367.0f,-359.0f,-266,-74.347115f,-72.98662f,-17.614538f,131.31807f,17.247982f,-59.270683f ) ;
  }

  @Test
  public void test856() {
    TestDrivers.surfaceShade(-333.0f,86.0f,747.0f,0f,58.0f,-1579.0f,0f,2391.0f,0f,0f,0f,0f,0f,633.0f,-97.0f,450.0f,1131.0f,1721.0f,2050.0f,1295,0.10729578f,0.55023897f,-0.03232237f,61.33152f,100.0f,-11.910201f ) ;
  }

  @Test
  public void test857() {
    TestDrivers.surfaceShade(334.0f,258.0f,-118.0f,0f,203.0f,-1660.0f,0f,326.0f,0f,0f,0f,0f,0f,-637.0f,174.0f,-282.0f,-125.0f,180.0f,731.0f,88,32.552814f,-42.895733f,-100.0f,-12.764761f,92.62246f,-74.13711f ) ;
  }

  @Test
  public void test858() {
    TestDrivers.surfaceShade(-336.0f,381.0f,0f,0f,139.0f,-480.0f,0f,-432.0f,0f,0f,0f,0f,0f,-460.0f,204.0f,-585.0f,0f,0f,0f,-354,19.049372f,30.884876f,64.871864f,89.89766f,99.95713f,0f ) ;
  }

  @Test
  public void test859() {
    TestDrivers.surfaceShade(340.0f,0f,0f,0f,-233.0f,28.0f,447.0f,-201.0f,0f,0f,0f,0f,0f,613.0f,-235.0f,-930.0f,325.0f,553.0f,-977.0f,-925,20.467638f,2.775889f,-47.514084f,87.487595f,0f,0f ) ;
  }

  @Test
  public void test860() {
    TestDrivers.surfaceShade(340.0f,0f,0f,1.0f,0f,0f,0f,78.334435f,0f,0f,0f,0f,0f,35.445557f,-93.36574f,-100.0f,-1126.0f,-170.0f,1204.0f,0,0f,0f,0f,0.0029411765f,0f,0f ) ;
  }

  @Test
  public void test861() {
    TestDrivers.surfaceShade(340.0f,443.0f,0f,0f,1635.0f,-778.0f,0f,1110.0f,0f,0f,0f,0f,0f,88.0f,-6.0f,1683.0f,-55.0f,-827.0f,-564.0f,500,0.684681f,-0.08292946f,-0.6306981f,100.0f,40.59627f,0f ) ;
  }

  @Test
  public void test862() {
    TestDrivers.surfaceShade(343.0f,-94.0f,-1522.0f,0f,1264.0f,-1617.0f,0f,317.0f,0f,0f,0f,0f,0f,-28.0f,-126.0f,-351.0f,116.0f,240.0f,-292.0f,-174,-63.217514f,75.128975f,-21.926382f,-100.0f,-25.972961f,90.71876f ) ;
  }

  @Test
  public void test863() {
    TestDrivers.surfaceShade(347.0f,-783.0f,1885.0f,0f,171.0f,939.0f,0f,-733.0f,0f,0f,0f,0f,0f,369.0f,-115.0f,115.0f,1778.0f,-73.0f,-792.0f,-180,-31.666063f,-78.71526f,22.891495f,22.495361f,-131.12497f,100.0f ) ;
  }

  @Test
  public void test864() {
    TestDrivers.surfaceShade(-348.0f,306.0f,109.0f,0f,952.0f,-321.0f,0f,285.0f,0f,0f,0f,0f,0f,-130.0f,32.0f,-946.0f,-878.0f,534.0f,301.0f,639,-0.46807465f,-98.886086f,-3.2806606f,48.77338f,32.60462f,91.53238f ) ;
  }

  @Test
  public void test865() {
    TestDrivers.surfaceShade(-3483.0f,-210.0f,0f,0f,34.0f,5.0f,0f,4.0f,0f,0f,0f,0f,0f,300.0f,-755.0f,1363.0f,0f,0f,0f,2135,-98.77389f,100.0f,-100.0f,-68.9426f,-5.805206E-10f,0f ) ;
  }

  @Test
  public void test866() {
    TestDrivers.surfaceShade(-353.0f,242.0f,0f,0f,598.0f,-3.0f,0f,0.0f,0f,0f,0f,0f,0f,709.0f,-940.0f,-1432.0f,0f,0f,0f,-1369,0.11841822f,-0.39112443f,0.3707766f,0.4026314f,-49.358067f,0f ) ;
  }

  @Test
  public void test867() {
    TestDrivers.surfaceShade(359.0f,-118.0f,0f,0f,888.0f,0.0f,0f,-15.0f,0f,0f,0f,0f,0f,-450.0f,-155.0f,-497.0f,0f,0f,0f,17,-41.9522f,14.791537f,38.37179f,-28.637728f,-21.593115f,0f ) ;
  }

  @Test
  public void test868() {
    TestDrivers.surfaceShade(360.0f,-815.0f,0f,0f,124.0f,891.0f,0f,-2310.0f,0f,0f,0f,0f,0f,-9.0f,245.0f,-799.0f,-176.0f,422.0f,1145.0f,-1503,0.24470437f,0.022869747f,0.0042562652f,3.0851734f,40.39804f,0f ) ;
  }

  @Test
  public void test869() {
    TestDrivers.surfaceShade(-36.0f,0f,0f,0f,262.0f,-2459.0f,0f,2946.0f,0f,0f,0f,0f,0f,1882.0f,-261.0f,628.0f,1211.0f,896.0f,2863.0f,131,-0.2415838f,-0.13026929f,0.4886536f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test870() {
    TestDrivers.surfaceShade(-361.0f,0f,0f,17.0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-1.6219373f,-2.5615563f,0.6217595f,531.0f,-135.0f,829.0f,0,0f,0f,0f,48.042255f,0f,0f ) ;
  }

  @Test
  public void test871() {
    TestDrivers.surfaceShade(365.0f,-322.0f,0f,0f,1321.0f,-132.0f,0f,1362.0f,0f,0f,0f,0f,0f,659.0f,-803.0f,689.0f,-697.0f,360.0f,-24.0f,-165,50.85609f,-27.005703f,-80.11574f,100.0f,-95.63539f,0f ) ;
  }

  @Test
  public void test872() {
    TestDrivers.surfaceShade(366.0f,0f,0f,0f,173.0f,1060.0f,-690.0f,359.0f,0f,0f,0f,0f,0f,916.0f,-230.0f,804.0f,-590.0f,-395.0f,-354.0f,-396,32.004078f,-34.811134f,-46.420776f,12.528917f,0f,0f ) ;
  }

  @Test
  public void test873() {
    TestDrivers.surfaceShade(370.0f,536.0f,0f,0f,281.0f,521.0f,0f,23.0f,0f,0f,0f,0f,0f,-47.0f,-871.0f,1235.0f,881.0f,841.0f,3.0f,-792,9.184442f,-83.92253f,-88.59218f,21.985327f,-50.0855f,0f ) ;
  }

  @Test
  public void test874() {
    TestDrivers.surfaceShade(-37.0f,-1406.0f,-378.0f,0f,54.0f,-491.0f,0f,2.0f,0f,0f,0f,0f,0f,-628.0f,-290.0f,-22.0f,0f,0f,0f,404,92.21751f,-55.06581f,-100.0f,15.825134f,100.0f,53.937904f ) ;
  }

  @Test
  public void test875() {
    TestDrivers.surfaceShade(37.0f,-650.0f,0f,-141.0f,0f,0f,0f,-96.507324f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-1.9168104E-4f,1.0911075E-5f,0f ) ;
  }

  @Test
  public void test876() {
    TestDrivers.surfaceShade(373.0f,811.0f,-49.0f,0f,890.0f,-670.0f,0f,234.0f,0f,0f,0f,0f,0f,727.0f,393.0f,-220.0f,-364.0f,-29.0f,1819.0f,-2572,3.584235f,-5.53218f,1.9617827f,99.99088f,-6.288431f,-100.0f ) ;
  }

  @Test
  public void test877() {
    TestDrivers.surfaceShade(374.0f,-879.0f,0f,0f,1341.0f,-630.0f,0f,13.0f,0f,0f,0f,0f,0f,519.0f,752.0f,108.0f,0f,0f,0f,296,-2.3738549f,-32.180523f,-37.79415f,100.0f,13.771017f,0f ) ;
  }

  @Test
  public void test878() {
    TestDrivers.surfaceShade(-381.0f,-311.0f,169.0f,0f,249.0f,-1497.0f,0f,47.0f,0f,0f,0f,0f,0f,1554.0f,1407.0f,307.0f,342.0f,-525.0f,15.0f,966,-0.037260044f,0.012375013f,0.13189076f,-100.0f,-70.7587f,100.0f ) ;
  }

  @Test
  public void test879() {
    TestDrivers.surfaceShade(-381.0f,380.0f,0f,0f,212.0f,-636.0f,0f,637.0f,0f,0f,0f,0f,0f,-435.0f,348.0f,-635.0f,-876.0f,579.0f,-351.0f,1028,31.106405f,-42.19271f,-44.432045f,99.738014f,-100.0f,0f ) ;
  }

  @Test
  public void test880() {
    TestDrivers.surfaceShade(-385.0f,0f,0f,0f,-484.0f,386.0f,658.0f,383.0f,0f,0f,0f,0f,0f,771.0f,160.0f,-487.0f,186.0f,705.0f,-408.0f,468,-44.781303f,-39.271336f,-53.770603f,31.939598f,0f,0f ) ;
  }

  @Test
  public void test881() {
    TestDrivers.surfaceShade(389.0f,0f,124.0f,0f,258.0f,0.0f,0f,-420.0f,0f,0f,0f,0f,0f,956.0f,690.0f,-1634.0f,0f,0f,0f,1579,0.7902408f,-0.49412408f,0.2821654f,-29.041256f,0f,-50.039593f ) ;
  }

  @Test
  public void test882() {
    TestDrivers.surfaceShade(-390.0f,0f,0f,0f,176.0f,-577.0f,534.0f,-823.0f,0f,0f,0f,0f,0f,697.0f,563.0f,199.0f,865.0f,-240.0f,207.0f,-561,-55.670673f,-29.7123f,-36.475956f,89.8104f,0f,0f ) ;
  }

  @Test
  public void test883() {
    TestDrivers.surfaceShade(39.0f,277.0f,-124.0f,0f,48.0f,-731.0f,0f,-486.0f,0f,0f,0f,0f,0f,-376.0f,-1297.0f,1441.0f,0f,0f,0f,66,0.31607625f,-0.74216455f,-0.585526f,2.711088f,-90.07878f,3.9536626f ) ;
  }

  @Test
  public void test884() {
    TestDrivers.surfaceShade(-394.0f,296.0f,-687.0f,0f,617.0f,-402.0f,0f,-482.0f,0f,0f,0f,0f,0f,-475.0f,1081.0f,-746.0f,0f,0f,0f,-1171,0.6815159f,-0.10320022f,-0.58348453f,-100.0f,27.368937f,-57.953472f ) ;
  }

  @Test
  public void test885() {
    TestDrivers.surfaceShade(395.0f,-972.0f,-764.0f,0f,722.0f,-1674.0f,0f,944.0f,0f,0f,0f,0f,0f,326.0f,-690.0f,-346.0f,405.0f,17.0f,-402.0f,845,87.15244f,47.78287f,-13.174814f,-78.46971f,-100.0f,40.05664f ) ;
  }

  @Test
  public void test886() {
    TestDrivers.surfaceShade(-397.0f,0f,0f,0f,717.0f,400.0f,0f,-839.0f,0f,0f,0f,0f,0f,-47.0f,627.0f,-92.0f,-115.0f,-300.0f,-781.0f,57,-3.9230642f,-98.1271f,42.620472f,24.87048f,0f,0f ) ;
  }

  @Test
  public void test887() {
    TestDrivers.surfaceShade(-398.0f,0f,0f,0f,706.0f,335.0f,0f,283.0f,0f,0f,0f,0f,0f,-742.0f,1328.0f,-1364.0f,323.0f,943.0f,2194.0f,1248,0.903017f,-0.32243842f,0.06847312f,54.07567f,0f,0f ) ;
  }

  @Test
  public void test888() {
    TestDrivers.surfaceShade(-398.0f,1159.0f,321.0f,0f,994.0f,582.0f,0f,349.0f,0f,0f,0f,0f,0f,70.0f,264.0f,-301.0f,374.0f,1971.0f,-799.0f,-510,-16.958214f,-55.678654f,-52.778202f,42.440807f,-100.0f,-47.693165f ) ;
  }

  @Test
  public void test889() {
    TestDrivers.surfaceShade(-406.0f,679.0f,440.0f,-23.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,1.0708931E-4f,-6.4032785E-5f,99.99733f ) ;
  }

  @Test
  public void test890() {
    TestDrivers.surfaceShade(-409.0f,-414.0f,367.0f,0f,506.0f,-3.0f,0f,-351.0f,0f,0f,0f,0f,0f,127.0f,288.0f,1177.0f,0f,0f,0f,875,-36.217308f,-52.29276f,-31.027294f,-111.686966f,165.78928f,42.92826f ) ;
  }

  @Test
  public void test891() {
    TestDrivers.surfaceShade(-41.0f,-152.0f,164.0f,115.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,-29.753574f,-0.068085685f,5.3022268E-5f ) ;
  }

  @Test
  public void test892() {
    TestDrivers.surfaceShade(-411.0f,-819.0f,-565.0f,0f,992.0f,36.0f,0f,-354.0f,0f,0f,0f,0f,0f,2.0f,-720.0f,790.0f,-350.0f,448.0f,-896.0f,887,-0.016998604f,0.0766667f,-0.26827314f,-100.0f,-19.090794f,-9.522499f ) ;
  }

  @Test
  public void test893() {
    TestDrivers.surfaceShade(413.0f,-934.0f,503.0f,54.0f,0f,0f,0f,-35.408745f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,4.4839027E-5f,-1.9827108E-5f,3.681614E-5f ) ;
  }

  @Test
  public void test894() {
    TestDrivers.surfaceShade(-417.0f,-779.0f,1150.0f,0f,146.0f,-564.0f,0f,-773.0f,0f,0f,0f,0f,0f,-340.0f,-92.0f,-717.0f,0f,0f,0f,-289,-30.98564f,-14.331177f,67.683044f,-70.37292f,70.379295f,8.110172f ) ;
  }

  @Test
  public void test895() {
    TestDrivers.surfaceShade(-418.0f,-581.0f,0f,0f,130.0f,22.0f,0f,2793.0f,0f,0f,0f,0f,0f,1075.0f,-952.0f,480.0f,-959.0f,-84.0f,-282.0f,-699,2.2179348f,1.925514f,-3.6693873f,-2.898537f,-3.4844783E-5f,0f ) ;
  }

  @Test
  public void test896() {
    TestDrivers.surfaceShade(419.0f,0f,0f,0f,86.0f,-1601.0f,0f,258.0f,0f,0f,0f,0f,0f,181.0f,-185.0f,-714.0f,76.0f,294.0f,697.0f,959,1.08031396E-4f,0.37484264f,-0.09709568f,2.0939796f,0f,0f ) ;
  }

  @Test
  public void test897() {
    TestDrivers.surfaceShade(419.0f,-166.0f,863.0f,0f,138.0f,-893.0f,0f,1269.0f,0f,0f,0f,0f,0f,-121.0f,-864.0f,-723.0f,-490.0f,-418.0f,836.0f,-89,-64.98011f,-46.673233f,93.521866f,-54.407166f,-25.987244f,-20.196592f ) ;
  }

  @Test
  public void test898() {
    TestDrivers.surfaceShade(419.0f,-3942.0f,0f,0f,1420.0f,6.0f,0f,1.0f,0f,0f,0f,0f,0f,434.0f,-1065.0f,477.0f,0f,0f,0f,2186,0.34527948f,0.75599104f,-0.18732439f,-75.57619f,-60.500027f,0f ) ;
  }

  @Test
  public void test899() {
    TestDrivers.surfaceShade(-420.0f,-827.0f,0f,-45.0f,0f,0f,0f,1216.0f,0f,0f,0f,0f,0f,-539.0f,-204.0f,-321.0f,-32.0f,-477.0f,358.0f,1,0f,0f,0f,-41.209637f,3.6821428E-5f,0f ) ;
  }

  @Test
  public void test900() {
    TestDrivers.surfaceShade(425.0f,1852.0f,0f,0f,33.0f,263.0f,0f,-1336.0f,0f,0f,0f,0f,0f,-516.0f,-94.0f,-371.0f,-137.0f,585.0f,922.0f,-450,48.327084f,-59.951996f,-52.025036f,19.337997f,98.70132f,0f ) ;
  }

  @Test
  public void test901() {
    TestDrivers.surfaceShade(-425.0f,633.0f,-1546.0f,0f,681.0f,-524.0f,0f,0.0f,0f,0f,0f,0f,0f,-182.0f,1397.0f,-3.0f,0f,0f,0f,224,-94.936775f,-12.165889f,94.24874f,-56.754787f,-100.0f,-50.943146f ) ;
  }

  @Test
  public void test902() {
    TestDrivers.surfaceShade(427.0f,-1207.0f,0f,0f,437.0f,-1179.0f,0f,-1586.0f,0f,0f,0f,0f,0f,645.0f,-937.0f,131.0f,0f,0f,0f,-507,-0.26691547f,0.7568304f,-0.2898426f,34.43058f,-6.135744f,0f ) ;
  }

  @Test
  public void test903() {
    TestDrivers.surfaceShade(-43.0f,-778.0f,769.0f,0f,1250.0f,727.0f,0f,-1177.0f,0f,0f,0f,0f,0f,-889.0f,-302.0f,54.0f,389.0f,16.0f,-949.0f,1208,-22.087755f,75.73126f,59.904205f,-94.38043f,50.598686f,51.719807f ) ;
  }

  @Test
  public void test904() {
    TestDrivers.surfaceShade(441.0f,-503.0f,0f,0f,58.0f,96.0f,0f,-340.0f,0f,0f,0f,0f,0f,846.0f,162.0f,-122.0f,-336.0f,294.0f,935.0f,-1308,-54.072956f,25.881107f,-5.6597548f,-23.528555f,24.506435f,0f ) ;
  }

  @Test
  public void test905() {
    TestDrivers.surfaceShade(442.0f,0f,0f,0f,678.0f,581.0f,0f,287.0f,0f,0f,0f,0f,0f,-84.0f,204.0f,360.0f,-484.0f,-238.0f,-625.0f,-241,79.1439f,57.07084f,-13.873232f,62.575703f,0f,0f ) ;
  }

  @Test
  public void test906() {
    TestDrivers.surfaceShade(442.0f,1486.0f,0f,0f,923.0f,5.0f,0f,1.0f,0f,0f,0f,0f,0f,-438.0f,420.0f,1043.0f,0f,0f,0f,-494,-16.329187f,89.75157f,-42.998894f,27.151363f,-5.4848137f,0f ) ;
  }

  @Test
  public void test907() {
    TestDrivers.surfaceShade(444.0f,0f,0f,0f,99.316536f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-58.471855f,33.975174f,-36.300793f,0f,0f,0f,-177,-10.30126f,25.768944f,51.616535f,-30.330202f,0f,0f ) ;
  }

  @Test
  public void test908() {
    TestDrivers.surfaceShade(-448.0f,-1033.0f,-2919.0f,0f,348.0f,359.0f,0f,1245.0f,0f,0f,0f,0f,0f,-40.0f,516.0f,-161.0f,7.0f,-426.0f,-795.0f,-617,73.939835f,34.262665f,91.44063f,-16.009573f,-0.40704775f,-88.48654f ) ;
  }

  @Test
  public void test909() {
    TestDrivers.surfaceShade(-451.0f,-394.0f,481.0f,0f,3.0f,946.0f,0f,-106.0f,0f,0f,0f,0f,0f,-305.0f,351.0f,765.0f,1561.0f,-505.0f,585.0f,2462,-0.64106125f,0.055438895f,-0.2810232f,-63.046963f,100.0f,59.11472f ) ;
  }

  @Test
  public void test910() {
    TestDrivers.surfaceShade(-452.0f,1823.0f,0f,0f,145.0f,-351.0f,0f,474.0f,0f,0f,0f,0f,0f,-1586.0f,1202.0f,-1340.0f,-690.0f,402.0f,224.0f,751,0.21978514f,0.014245839f,0.20406185f,67.7896f,-91.005356f,0f ) ;
  }

  @Test
  public void test911() {
    TestDrivers.surfaceShade(453.0f,-12.0f,0f,0f,1748.0f,7.0f,0f,2.0f,0f,0f,0f,0f,0f,868.0f,160.0f,-785.0f,0f,0f,0f,649,79.66541f,-32.254147f,99.07669f,100.0f,-96.51052f,0f ) ;
  }

  @Test
  public void test912() {
    TestDrivers.surfaceShade(454.0f,-598.0f,-488.0f,0f,407.0f,905.0f,0f,288.0f,0f,0f,0f,0f,0f,230.0f,25.0f,648.0f,272.0f,992.0f,1502.0f,857,46.25045f,-51.887234f,-14.414232f,-29.213938f,15.699435f,21.26411f ) ;
  }

  @Test
  public void test913() {
    TestDrivers.surfaceShade(-454.0f,628.0f,0f,0f,48.0f,190.0f,0f,109.0f,0f,0f,0f,0f,0f,270.0f,-148.0f,-677.0f,886.0f,445.0f,642.0f,-645,0.78931296f,100.0f,-17.528463f,100.0f,-100.0f,0f ) ;
  }

  @Test
  public void test914() {
    TestDrivers.surfaceShade(455.0f,-1290.0f,0f,0f,1104.0f,0.0f,0f,-621.0f,0f,0f,0f,0f,0f,-504.0f,1217.0f,-1007.0f,0f,0f,0f,3075,-0.39133462f,-0.6357919f,-0.22642139f,-100.0f,-97.26437f,0f ) ;
  }

  @Test
  public void test915() {
    TestDrivers.surfaceShade(-455.0f,-541.0f,-731.0f,587.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-18.351267f,85.881355f,-84.65766f ) ;
  }

  @Test
  public void test916() {
    TestDrivers.surfaceShade(46.0f,374.0f,0f,0f,962.0f,-5.0f,0f,23.0f,0f,0f,0f,0f,0f,643.0f,-988.0f,37.0f,-844.0f,-91.0f,341.0f,-409,2.2116811f,50.795666f,47.99271f,116.33793f,19.912758f,0f ) ;
  }

  @Test
  public void test917() {
    TestDrivers.surfaceShade(-464.0f,0f,0f,0f,589.0f,419.0f,-275.0f,562.0f,0f,0f,0f,0f,0f,-83.0f,31.0f,-973.0f,-509.0f,-482.0f,-90.0f,-120,30.82062f,-58.988968f,61.02321f,43.149944f,0f,0f ) ;
  }

  @Test
  public void test918() {
    TestDrivers.surfaceShade(464.0f,-1455.0f,0f,-587.0f,0f,0f,0f,492.0f,0f,0f,0f,0f,0f,57.0f,700.0f,912.0f,-2057.0f,900.0f,-562.0f,29,0f,0f,0f,24.24681f,-99.87069f,0f ) ;
  }

  @Test
  public void test919() {
    TestDrivers.surfaceShade(-467.0f,-696.0f,1102.0f,0f,73.0f,-776.0f,0f,1933.0f,0f,0f,0f,0f,0f,-118.0f,675.0f,-1304.0f,1235.0f,745.0f,881.0f,-95,0.784216f,0.041621856f,0.22223614f,23.42689f,-0.046384826f,1.23023085E-8f ) ;
  }

  @Test
  public void test920() {
    TestDrivers.surfaceShade(-467.0f,973.0f,-1131.0f,0f,671.0f,236.0f,0f,2244.0f,0f,0f,0f,0f,0f,-164.0f,372.0f,1392.0f,-1323.0f,-1480.0f,-71.0f,-239,0.1379631f,0.29254282f,-0.27081373f,89.06757f,46.505547f,60.57422f ) ;
  }

  @Test
  public void test921() {
    TestDrivers.surfaceShade(-468.0f,0f,0f,0f,5.0f,-1153.0f,0f,662.0f,0f,0f,0f,0f,0f,861.0f,213.0f,214.0f,839.0f,1317.0f,1002.0f,-857,-1.2442268f,-0.67507946f,0.06050679f,-0.24473324f,0f,0f ) ;
  }

  @Test
  public void test922() {
    TestDrivers.surfaceShade(469.0f,230.0f,75.0f,0f,156.0f,-436.0f,0f,53.0f,0f,0f,0f,0f,0f,738.0f,769.0f,-656.0f,-531.0f,722.0f,65.0f,-578,9.231433f,-58.273792f,-54.190395f,19.049217f,-98.97622f,34.04513f ) ;
  }

  @Test
  public void test923() {
    TestDrivers.surfaceShade(474.0f,-25.0f,-228.0f,0f,516.0f,28.0f,-450.0f,444.0f,0f,0f,0f,0f,0f,-587.0f,299.0f,924.0f,523.0f,682.0f,149.0f,-347,-35.249138f,0.2455723f,-35.863266f,-63.71554f,81.59979f,4.1839204f ) ;
  }

  @Test
  public void test924() {
    TestDrivers.surfaceShade(474.0f,-357.0f,993.0f,0f,418.0f,-834.0f,0f,-590.0f,0f,0f,0f,0f,0f,-592.0f,589.0f,174.0f,0f,0f,0f,603,0.8461856f,-94.156235f,75.11271f,47.075027f,-59.622963f,54.173866f ) ;
  }

  @Test
  public void test925() {
    TestDrivers.surfaceShade(475.0f,0f,0f,0f,351.0f,226.0f,0f,114.0f,0f,0f,0f,0f,0f,204.0f,41.0f,597.0f,542.0f,-634.0f,156.0f,-687,-74.46494f,-29.824549f,27.493542f,-86.16876f,0f,0f ) ;
  }

  @Test
  public void test926() {
    TestDrivers.surfaceShade(-476.0f,443.0f,783.0f,0f,940.0f,1494.0f,0f,-1498.0f,0f,0f,0f,0f,0f,468.0f,-661.0f,977.0f,-341.0f,2541.0f,1298.0f,-80,100.0f,-44.449364f,-77.97444f,-55.62358f,11.716325f,100.0f ) ;
  }

  @Test
  public void test927() {
    TestDrivers.surfaceShade(480.0f,137.0f,0f,0f,29.0f,6.0f,0f,-378.0f,0f,0f,0f,0f,0f,1176.0f,-1278.0f,-246.0f,0f,0f,0f,-188,-0.13354547f,0.0087738f,-0.6839934f,65.989075f,11.9736395f,0f ) ;
  }

  @Test
  public void test928() {
    TestDrivers.surfaceShade(481.0f,-175.0f,467.0f,0f,640.0f,-794.0f,0f,213.0f,0f,0f,0f,0f,0f,152.0f,-246.0f,-552.0f,-966.0f,-50.0f,531.0f,-279,77.352135f,-64.41078f,74.28888f,-22.94166f,-89.6875f,59.204533f ) ;
  }

  @Test
  public void test929() {
    TestDrivers.surfaceShade(482.0f,-501.0f,-641.0f,0f,110.0f,244.0f,0f,138.0f,0f,0f,0f,0f,0f,-432.0f,-366.0f,171.0f,-1273.0f,-535.0f,263.0f,-902,25.504625f,-46.58386f,-35.27306f,50.765667f,-93.37697f,-71.45413f ) ;
  }

  @Test
  public void test930() {
    TestDrivers.surfaceShade(482.0f,-99.0f,-29.0f,0f,23.0f,-2170.0f,0f,144.0f,0f,0f,0f,0f,0f,997.0f,-1753.0f,933.0f,746.0f,-1937.0f,654.0f,443,-0.12086613f,0.3610163f,0.8074653f,-100.0f,6.482671f,-100.0f ) ;
  }

  @Test
  public void test931() {
    TestDrivers.surfaceShade(-487.0f,0f,661.0f,0f,725.0f,-1303.0f,0f,-5.0f,0f,0f,0f,0f,0f,-284.0f,-1737.0f,46.0f,0f,0f,0f,-613,28.589537f,23.465567f,-44.379116f,-65.929054f,0f,-51.351696f ) ;
  }

  @Test
  public void test932() {
    TestDrivers.surfaceShade(49.0f,1493.0f,0f,-41.0f,0f,0f,0f,1364.0f,0f,0f,0f,0f,0f,-171.0f,652.0f,94.0f,-60.0f,-497.0f,-155.0f,-4,0f,0f,0f,-4.977601E-4f,9.303941f,0f ) ;
  }

  @Test
  public void test933() {
    TestDrivers.surfaceShade(-491.0f,-1819.0f,806.0f,0f,531.0f,-447.0f,0f,860.0f,0f,0f,0f,0f,0f,187.0f,910.0f,579.0f,529.0f,307.0f,-905.0f,658,-25.983541f,9.561511f,-28.129164f,-16.124306f,-100.0f,-12.702436f ) ;
  }

  @Test
  public void test934() {
    TestDrivers.surfaceShade(-492.0f,-595.0f,0f,0f,64.0f,-501.0f,0f,631.0f,0f,0f,0f,0f,0f,-715.0f,6.0f,851.0f,322.0f,-514.0f,-615.0f,-242,-15.019419f,-6.802461f,-15.577625f,9.2971735f,-47.391315f,0f ) ;
  }

  @Test
  public void test935() {
    TestDrivers.surfaceShade(-492.0f,924.0f,605.0f,0f,261.0f,-515.0f,0f,-384.0f,0f,0f,0f,0f,0f,-17.0f,-371.0f,556.0f,0f,0f,0f,-984,4.6558075f,46.093117f,-51.318428f,60.256367f,-20.374096f,6.1823378f ) ;
  }

  @Test
  public void test936() {
    TestDrivers.surfaceShade(497.0f,0f,0f,0f,14.7697935f,0.0f,0f,-32.521927f,0f,0f,0f,0f,0f,50.868187f,60.658043f,42.42532f,0f,0f,0f,-717,5.791872f,18.419033f,-49.593884f,38.585354f,0f,0f ) ;
  }

  @Test
  public void test937() {
    TestDrivers.surfaceShade(500.0f,0f,0f,0f,58.594635f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,28.130789f,4.539058f,-58.60504f,0f,0f,0f,318,-0.069322415f,-0.2841161f,-0.054166637f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test938() {
    TestDrivers.surfaceShade(-50.0f,0f,0f,0f,5.0f,-1529.0f,0f,278.0f,0f,0f,0f,0f,0f,-135.0f,850.0f,734.0f,613.0f,-264.0f,-858.0f,-724,-94.11351f,0.24029091f,-17.587973f,-61.27218f,0f,0f ) ;
  }

  @Test
  public void test939() {
    TestDrivers.surfaceShade(-504.0f,852.0f,0f,-416.0f,0f,0f,0f,259.0f,0f,0f,0f,0f,0f,696.0f,181.0f,167.0f,-209.0f,-867.0f,1060.0f,-5,0f,0f,0f,-99.07099f,24.706703f,0f ) ;
  }

  @Test
  public void test940() {
    TestDrivers.surfaceShade(507.0f,0f,0f,456.0f,0f,0f,0f,57.87247f,0f,0f,0f,0f,0f,77.91236f,47.569912f,57.355656f,-982.0f,156.0f,-208.0f,-1,0f,0f,0f,6.7169223f,0f,0f ) ;
  }

  @Test
  public void test941() {
    TestDrivers.surfaceShade(513.0f,-414.0f,0f,0f,513.0f,782.0f,0f,-604.0f,0f,0f,0f,0f,0f,-420.0f,-219.0f,-726.0f,-459.0f,0.0f,807.0f,-827,-0.7172444f,0.08929473f,0.3879999f,82.226395f,78.69524f,0f ) ;
  }

  @Test
  public void test942() {
    TestDrivers.surfaceShade(-515.0f,0f,0f,0f,30.671438f,-1.0375693f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,-98.13303f,0f,0f,0f,-1525,-0.40256095f,0.89851797f,0.17495766f,-20.95581f,0f,0f ) ;
  }

  @Test
  public void test943() {
    TestDrivers.surfaceShade(-516.0f,52.0f,0f,0f,420.0f,-114.0f,0f,-855.0f,0f,0f,0f,0f,0f,943.0f,-862.0f,333.0f,0f,0f,0f,-623,-7.774446f,74.14554f,83.78257f,-27.064903f,78.274216f,0f ) ;
  }

  @Test
  public void test944() {
    TestDrivers.surfaceShade(516.0f,-735.0f,-587.0f,0f,15.0f,642.0f,0f,-395.0f,0f,0f,0f,0f,0f,777.0f,101.0f,428.0f,-196.0f,-207.0f,-414.0f,215,-63.38386f,-71.64758f,56.427574f,-100.0f,-56.33191f,41.007126f ) ;
  }

  @Test
  public void test945() {
    TestDrivers.surfaceShade(-518.0f,785.0f,-721.0f,0f,337.0f,-1219.0f,0f,789.0f,0f,0f,0f,0f,0f,-312.0f,-559.0f,849.0f,-1031.0f,-1695.0f,-593.0f,312,-91.74315f,83.93983f,21.553003f,95.03738f,-55.294056f,3.5172617f ) ;
  }

  @Test
  public void test946() {
    TestDrivers.surfaceShade(520.0f,-359.0f,0f,0f,1385.0f,-97.0f,0f,610.0f,0f,0f,0f,0f,0f,131.0f,-443.0f,412.0f,312.0f,454.0f,935.0f,418,-45.80603f,-50.025826f,-39.225365f,-1.7324169f,-91.13277f,0f ) ;
  }

  @Test
  public void test947() {
    TestDrivers.surfaceShade(-52.0f,0f,0f,0f,14.967349f,-31.1086f,0f,-22.755636f,0f,0f,0f,0f,0f,-8.699022f,-35.197582f,-8.854566f,0f,0f,0f,780,-0.54419655f,0.17213134f,0.073763125f,-6.496449E-4f,0f,0f ) ;
  }

  @Test
  public void test948() {
    TestDrivers.surfaceShade(52.0f,0f,0f,0f,796.0f,0.0f,0f,1480.0f,0f,0f,0f,0f,0f,-810.0f,-188.0f,33.0f,817.0f,701.0f,-197.0f,14,13.554638f,-54.598206f,21.660427f,9.0126095f,0f,0f ) ;
  }

  @Test
  public void test949() {
    TestDrivers.surfaceShade(52.0f,19.0f,494.0f,0f,678.0f,-278.0f,0f,53.0f,0f,0f,0f,0f,0f,471.0f,-371.0f,464.0f,81.0f,744.0f,-193.0f,385,-64.09064f,-31.09811f,4.5365667f,-50.464172f,-24.45585f,79.129326f ) ;
  }

  @Test
  public void test950() {
    TestDrivers.surfaceShade(-521.0f,-982.0f,-984.0f,0f,383.0f,921.0f,0f,408.0f,0f,0f,0f,0f,0f,307.0f,55.0f,-88.0f,-135.0f,-499.0f,680.0f,185,-77.84866f,-15.447607f,36.50714f,-47.95085f,46.76026f,65.58691f ) ;
  }

  @Test
  public void test951() {
    TestDrivers.surfaceShade(-523.0f,1.0f,7.0f,-8.0f,0f,0f,0f,-93.315384f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,3.7091988E-4f,-0.125f,-0.017857144f ) ;
  }

  @Test
  public void test952() {
    TestDrivers.surfaceShade(-528.0f,-267.0f,0f,0f,723.0f,281.0f,0f,-567.0f,0f,0f,0f,0f,0f,-589.0f,-652.0f,520.0f,841.0f,840.0f,884.0f,-305,54.986126f,-70.90734f,-92.34349f,-39.507545f,55.12837f,0f ) ;
  }

  @Test
  public void test953() {
    TestDrivers.surfaceShade(534.0f,0f,0f,0f,26.164377f,-3.1020923f,0f,-100.0f,0f,0f,0f,0f,0f,-36.069626f,37.87369f,-63.503098f,0f,0f,0f,245,-0.33890584f,0.25769907f,0.8720214f,-7.0077043f,0f,0f ) ;
  }

  @Test
  public void test954() {
    TestDrivers.surfaceShade(-536.0f,0f,-176.0f,0f,512.0f,185.0f,0f,644.0f,0f,0f,0f,0f,0f,-528.0f,-95.0f,368.0f,742.0f,-503.0f,-866.0f,337,36.97242f,45.427364f,64.77456f,-29.038496f,0f,-60.872593f ) ;
  }

  @Test
  public void test955() {
    TestDrivers.surfaceShade(540.0f,990.0f,1313.0f,0f,1084.0f,-865.0f,0f,52.0f,0f,0f,0f,0f,0f,989.0f,-941.0f,-491.0f,1081.0f,308.0f,365.0f,644,-40.575832f,-72.94305f,58.064995f,0.6106618f,-98.91172f,69.59952f ) ;
  }

  @Test
  public void test956() {
    TestDrivers.surfaceShade(54.0f,-466.0f,0f,0f,678.0f,6.0f,0f,1.0f,0f,0f,0f,0f,0f,122.0f,760.0f,399.0f,0f,0f,0f,931,-20.318394f,29.273996f,-49.54735f,29.385084f,-37.943977f,0f ) ;
  }

  @Test
  public void test957() {
    TestDrivers.surfaceShade(-542.0f,322.0f,0f,0f,665.0f,-1425.0f,0f,-522.0f,0f,0f,0f,0f,0f,280.0f,950.0f,-768.0f,0f,0f,0f,1489,0.20850694f,-0.0889565f,-0.034019176f,-47.025543f,70.93571f,0f ) ;
  }

  @Test
  public void test958() {
    TestDrivers.surfaceShade(-542.0f,672.0f,0f,0f,195.0f,-950.0f,0f,-506.0f,0f,0f,0f,0f,0f,57.0f,-585.0f,-925.0f,0f,0f,0f,492,94.46663f,69.75062f,-38.291367f,-39.86624f,-29.626198f,0f ) ;
  }

  @Test
  public void test959() {
    TestDrivers.surfaceShade(545.0f,0f,3608.0f,0f,192.0f,-3.0f,0f,-91.0f,0f,0f,0f,0f,0f,-406.0f,-646.0f,202.0f,0f,0f,0f,-543,0.56521606f,-0.24832234f,0.116492845f,-100.0f,0f,5.0697803f ) ;
  }

  @Test
  public void test960() {
    TestDrivers.surfaceShade(-547.0f,0f,0f,0f,100.0f,-27.316782f,0f,3.619528E-15f,0f,0f,0f,0f,0f,-100.0f,-74.68714f,-100.0f,0f,0f,0f,-899,-0.43203643f,0.5836383f,0.68753976f,13.436032f,0f,0f ) ;
  }

  @Test
  public void test961() {
    TestDrivers.surfaceShade(548.0f,379.0f,-50.0f,-574.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,36.758358f,43.278732f,13.424452f ) ;
  }

  @Test
  public void test962() {
    TestDrivers.surfaceShade(-549.0f,-23.0f,0f,305.0f,0f,0f,0f,-79.66112f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-24.796896f,-35.009354f,0f ) ;
  }

  @Test
  public void test963() {
    TestDrivers.surfaceShade(555.0f,639.0f,367.0f,8.0f,0f,0f,0f,-38.207283f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-11.984443f,1.9561815E-4f,3.4059945E-4f ) ;
  }

  @Test
  public void test964() {
    TestDrivers.surfaceShade(-558.0f,-648.0f,0f,0f,40.0f,4.0f,0f,-3.0f,0f,0f,0f,0f,0f,-304.0f,-87.0f,-1043.0f,0f,0f,0f,691,-5.99336f,-1.9727044f,2.6061935f,100.0f,-5.3239596E-8f,0f ) ;
  }

  @Test
  public void test965() {
    TestDrivers.surfaceShade(562.0f,769.0f,996.0f,0f,120.0f,1.0f,0f,-281.0f,0f,0f,0f,0f,0f,920.0f,933.0f,-404.0f,-964.0f,663.0f,-476.0f,1168,-97.92845f,100.0f,80.7866f,28.009228f,5.007044f,-11.5246935f ) ;
  }

  @Test
  public void test966() {
    TestDrivers.surfaceShade(-57.0f,-764.0f,984.0f,0f,770.0f,90.0f,0f,-269.0f,0f,0f,0f,0f,0f,949.0f,973.0f,100.0f,502.0f,-898.0f,-626.0f,551,-59.898655f,-27.214415f,100.0f,100.0f,-100.0f,59.756405f ) ;
  }

  @Test
  public void test967() {
    TestDrivers.surfaceShade(572.0f,-171.0f,-647.0f,0f,775.0f,-1116.0f,0f,766.0f,0f,0f,0f,0f,0f,-585.0f,452.0f,-233.0f,-946.0f,-700.0f,583.0f,985,60.274696f,39.67379f,-2.712674f,35.90368f,-77.015915f,2.659361f ) ;
  }

  @Test
  public void test968() {
    TestDrivers.surfaceShade(576.0f,-635.0f,718.0f,0f,565.0f,-933.0f,0f,184.0f,0f,0f,0f,0f,0f,-281.0f,-179.0f,425.0f,-979.0f,-846.0f,755.0f,789,-35.71415f,-99.23786f,-98.808426f,-100.0f,-100.0f,57.684135f ) ;
  }

  @Test
  public void test969() {
    TestDrivers.surfaceShade(577.0f,1316.0f,1211.0f,0f,3.0f,-327.0f,0f,1123.0f,0f,0f,0f,0f,0f,1162.0f,245.0f,-1367.0f,-125.0f,-470.0f,1385.0f,401,0.015285839f,0.5294317f,0.1078807f,-76.130295f,-70.26857f,89.81565f ) ;
  }

  @Test
  public void test970() {
    TestDrivers.surfaceShade(580.0f,-416.0f,0f,0f,305.0f,205.0f,0f,-152.0f,0f,0f,0f,0f,0f,-123.0f,-640.0f,604.0f,-377.0f,-869.0f,1017.0f,-456,-18.187527f,-82.78858f,-91.42676f,62.41406f,-83.17843f,0f ) ;
  }

  @Test
  public void test971() {
    TestDrivers.surfaceShade(58.0f,-697.0f,-57.0f,-261.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,100.0f,5.4970124E-6f,-31.532793f ) ;
  }

  @Test
  public void test972() {
    TestDrivers.surfaceShade(582.0f,0f,0f,0f,922.0f,-502.0f,0f,82.0f,0f,0f,0f,0f,0f,-711.0f,-672.0f,-87.0f,66.0f,255.0f,494.0f,544,28.870363f,74.4538f,5.2778316f,39.026848f,0f,0f ) ;
  }

  @Test
  public void test973() {
    TestDrivers.surfaceShade(-585.0f,1001.0f,-165.0f,9.0f,0f,0f,0f,-17.665398f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,100.0f,76.795784f,-6.7340065E-4f ) ;
  }

  @Test
  public void test974() {
    TestDrivers.surfaceShade(-59.0f,0f,-236.0f,0f,373.0f,-814.0f,0f,492.0f,0f,0f,0f,0f,0f,-765.0f,-1842.0f,675.0f,424.0f,960.0f,673.0f,139,0.60918444f,0.45223105f,0.652103f,81.67373f,0f,99.7129f ) ;
  }

  @Test
  public void test975() {
    TestDrivers.surfaceShade(59.0f,0f,970.0f,0f,41.0f,-36.0f,0f,2.0f,0f,0f,0f,0f,0f,-1921.0f,-90.0f,-905.0f,0f,0f,0f,-1225,0.4134768f,-0.10975208f,0.36981517f,29.036451f,0f,91.97314f ) ;
  }

  @Test
  public void test976() {
    TestDrivers.surfaceShade(591.0f,-392.0f,0f,0f,497.0f,-560.0f,0f,2.0f,0f,0f,0f,0f,0f,-841.0f,-441.0f,208.0f,0f,0f,0f,-671,7.363416f,9.746338f,50.436386f,29.678644f,-59.77646f,0f ) ;
  }

  @Test
  public void test977() {
    TestDrivers.surfaceShade(594.0f,-396.0f,0f,0f,637.0f,133.0f,0f,-450.0f,0f,0f,0f,0f,0f,139.0f,929.0f,793.0f,819.0f,-978.0f,18.0f,-510,-87.337234f,-43.69172f,66.493675f,93.471924f,89.95987f,0f ) ;
  }

  @Test
  public void test978() {
    TestDrivers.surfaceShade(600.0f,-1603.0f,0f,0f,987.0f,6.0f,0f,732.0f,0f,0f,0f,0f,0f,174.0f,-429.0f,-1367.0f,-532.0f,547.0f,712.0f,-1247,32.055458f,20.665268f,-2.4050844f,27.285707f,-100.0f,0f ) ;
  }

  @Test
  public void test979() {
    TestDrivers.surfaceShade(60.0f,1184.0f,0f,0f,862.0f,-1253.0f,0f,-5.0f,0f,0f,0f,0f,0f,-324.0f,446.0f,279.0f,0f,0f,0f,-1917,40.263638f,-32.20734f,98.24334f,84.63218f,52.8126f,0f ) ;
  }

  @Test
  public void test980() {
    TestDrivers.surfaceShade(-604.0f,679.0f,0f,0f,231.0f,783.0f,168.0f,604.0f,0f,0f,0f,0f,0f,142.0f,730.0f,39.0f,-663.0f,433.0f,-944.0f,-110,-100.0f,-100.0f,-100.0f,-100.0f,-100.0f,0f ) ;
  }

  @Test
  public void test981() {
    TestDrivers.surfaceShade(608.0f,1086.0f,552.0f,6.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,2.741228E-4f,94.25274f,-1.377921f ) ;
  }

  @Test
  public void test982() {
    TestDrivers.surfaceShade(616.0f,1921.0f,1065.0f,0f,893.0f,-197.0f,0f,261.0f,0f,0f,0f,0f,0f,472.0f,1879.0f,16.0f,1264.0f,-1215.0f,-638.0f,-561,-0.26535267f,-0.7277884f,-0.13619521f,-32.706764f,56.734646f,24.59487f ) ;
  }

  @Test
  public void test983() {
    TestDrivers.surfaceShade(620.0f,-15.0f,0f,0f,365.0f,-754.0f,0f,-3071.0f,0f,0f,0f,0f,0f,900.0f,360.0f,-258.0f,0f,0f,0f,-1101,-0.07050233f,0.3587658f,0.25466523f,100.0f,-5.855189f,0f ) ;
  }

  @Test
  public void test984() {
    TestDrivers.surfaceShade(625.0f,0f,0f,0f,642.0f,984.0f,-897.0f,310.0f,0f,0f,0f,0f,0f,259.0f,-775.0f,546.0f,896.0f,731.0f,367.0f,599,74.19829f,94.08401f,98.34753f,16.799294f,0f,0f ) ;
  }

  @Test
  public void test985() {
    TestDrivers.surfaceShade(63.0f,48.0f,889.0f,0f,97.0f,-736.0f,0f,-522.0f,0f,0f,0f,0f,0f,-965.0f,-540.0f,988.0f,0f,0f,0f,893,91.19193f,40.26047f,-67.73893f,-28.8144f,36.120773f,96.174416f ) ;
  }

  @Test
  public void test986() {
    TestDrivers.surfaceShade(-631.0f,591.0f,0f,0f,2171.0f,2516.0f,0f,257.0f,0f,0f,0f,0f,0f,-132.0f,-110.0f,730.0f,625.0f,-223.0f,82.0f,-3,-100.0f,-100.0f,-33.150684f,100.0f,-93.322685f,0f ) ;
  }

  @Test
  public void test987() {
    TestDrivers.surfaceShade(634.0f,-847.0f,0f,0f,222.0f,0.0f,0f,-284.0f,0f,0f,0f,0f,0f,4.0f,821.0f,-105.0f,0f,0f,0f,244,-94.25677f,-81.69339f,68.96672f,57.522633f,3.10363f,0f ) ;
  }

  @Test
  public void test988() {
    TestDrivers.surfaceShade(635.0f,-574.0f,535.0f,-260.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,100.0f,6.7006163E-6f,-7.1890727E-6f ) ;
  }

  @Test
  public void test989() {
    TestDrivers.surfaceShade(64.0f,-1049.0f,0f,908.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-36.919952f,-13.891293f,0f ) ;
  }

  @Test
  public void test990() {
    TestDrivers.surfaceShade(-641.0f,754.0f,0f,0f,675.0f,-962.0f,0f,-668.0f,0f,0f,0f,0f,0f,656.0f,992.0f,604.0f,0f,0f,0f,-449,-63.614647f,-57.165047f,99.33682f,37.28882f,-63.793736f,0f ) ;
  }

  @Test
  public void test991() {
    TestDrivers.surfaceShade(650.0f,-13.0f,638.0f,-326.0f,0f,0f,0f,-74.79471f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-3.0755112f,2.3596035E-4f,-57.20722f ) ;
  }

  @Test
  public void test992() {
    TestDrivers.surfaceShade(-653.0f,0f,0f,0f,619.0f,173.0f,0f,212.0f,0f,0f,0f,0f,0f,143.0f,37.0f,-71.0f,-981.0f,270.0f,-710.0f,-382,-52.94406f,73.60872f,21.58798f,16.774506f,0f,0f ) ;
  }

  @Test
  public void test993() {
    TestDrivers.surfaceShade(654.0f,1355.0f,-934.0f,0f,887.0f,-1290.0f,0f,-517.0f,0f,0f,0f,0f,0f,-693.0f,-791.0f,-710.0f,0f,0f,0f,369,-63.57069f,79.7626f,-26.813707f,50.852905f,-12.143581f,-53.709328f ) ;
  }

  @Test
  public void test994() {
    TestDrivers.surfaceShade(-657.0f,649.0f,419.0f,0f,1229.0f,328.0f,0f,37.0f,0f,0f,0f,0f,0f,69.0f,-548.0f,632.0f,-952.0f,-1649.0f,825.0f,-953,81.87377f,16.560501f,5.4206705f,-78.70582f,38.32558f,44.70099f ) ;
  }

  @Test
  public void test995() {
    TestDrivers.surfaceShade(-659.0f,961.0f,304.0f,0f,344.0f,-600.0f,0f,72.0f,0f,0f,0f,0f,0f,6.0f,-466.0f,518.0f,930.0f,-92.0f,138.0f,567,-18.012833f,58.694798f,31.424156f,95.77777f,-75.7847f,-7.441026f ) ;
  }

  @Test
  public void test996() {
    TestDrivers.surfaceShade(660.0f,-182.0f,-1300.0f,0f,1524.0f,-1642.0f,0f,-567.0f,0f,0f,0f,0f,0f,-778.0f,148.0f,304.0f,0f,0f,0f,-779,0.6259317f,0.70947945f,0.13550852f,-78.13348f,100.0f,-34.653156f ) ;
  }

  @Test
  public void test997() {
    TestDrivers.surfaceShade(660.0f,-619.0f,411.0f,0f,340.0f,395.0f,0f,241.0f,0f,0f,0f,0f,0f,-821.0f,-634.0f,578.0f,185.0f,9.0f,-744.0f,-78,66.37553f,-4.2716975f,89.59524f,-9.905572f,-79.12343f,23.695362f ) ;
  }

  @Test
  public void test998() {
    TestDrivers.surfaceShade(-661.0f,-805.0f,0f,0f,2504.0f,-1.0f,0f,2.0f,0f,0f,0f,0f,0f,2626.0f,-82.0f,-2160.0f,0f,0f,0f,-1163,-0.075760424f,0.7346289f,-0.113785446f,87.60978f,-3.6995154E-8f,0f ) ;
  }

  @Test
  public void test999() {
    TestDrivers.surfaceShade(-667.0f,-876.0f,0f,0f,206.0f,345.0f,0f,704.0f,0f,0f,0f,0f,0f,-976.0f,152.0f,173.0f,-926.0f,1591.0f,-895.0f,364,15.698437f,-3.0583801f,91.251724f,-71.294174f,63.20315f,0f ) ;
  }

  @Test
  public void test1000() {
    TestDrivers.surfaceShade(-670.0f,349.0f,-669.0f,0f,260.0f,415.0f,0f,986.0f,0f,0f,0f,0f,0f,-554.0f,-378.0f,-75.0f,148.0f,282.0f,763.0f,-703,81.77692f,-54.470592f,-23.758902f,-5.80752f,28.17783f,44.462814f ) ;
  }

  @Test
  public void test1001() {
    TestDrivers.surfaceShade(-67.0f,0f,830.0f,0f,726.0f,-754.0f,0f,783.0f,0f,0f,0f,0f,0f,-428.0f,559.0f,-570.0f,-475.0f,-179.0f,729.0f,547,9.648094f,-94.58071f,-100.0f,-19.519327f,0f,-6.4829364f ) ;
  }

  @Test
  public void test1002() {
    TestDrivers.surfaceShade(673.0f,-1235.0f,0f,-504.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-31.921598f,-19.0478f,0f ) ;
  }

  @Test
  public void test1003() {
    TestDrivers.surfaceShade(-68.0f,-685.0f,0f,0f,1046.0f,1230.0f,0f,375.0f,0f,0f,0f,0f,0f,89.0f,-873.0f,199.0f,1317.0f,-92.0f,-738.0f,-819,12.98002f,22.765377f,94.06509f,54.125713f,49.410175f,0f ) ;
  }

  @Test
  public void test1004() {
    TestDrivers.surfaceShade(682.0f,0f,0f,0f,97.06357f,4.9303807E-32f,0f,0.0f,0f,0f,0f,0f,0f,-82.75857f,-54.080006f,96.78846f,0f,0f,0f,-813,0.16684617f,0.6375523f,0.11148965f,3.6269364f,0f,0f ) ;
  }

  @Test
  public void test1005() {
    TestDrivers.surfaceShade(-683.0f,-31.0f,0f,0f,1.0f,2.0f,0f,0.0f,0f,0f,0f,0f,0f,-949.0f,-1263.0f,-926.0f,0f,0f,0f,351,41.62873f,42.038273f,-100.0f,-5.7952733f,-88.21916f,0f ) ;
  }

  @Test
  public void test1006() {
    TestDrivers.surfaceShade(-683.0f,-518.0f,0f,0f,885.0f,-829.0f,282.0f,300.0f,0f,0f,0f,0f,0f,-375.0f,-266.0f,911.0f,-498.0f,687.0f,-930.0f,73,97.694405f,-99.157745f,29.720499f,-97.9258f,-91.927414f,0f ) ;
  }

  @Test
  public void test1007() {
    TestDrivers.surfaceShade(-686.0f,0f,0f,0f,2.3512447f,-38.19264f,0f,0.0f,0f,0f,0f,0f,0f,-34.38419f,-7.0023537f,-11.156794f,0f,0f,0f,748,5.7343984f,-62.71199f,21.687138f,-93.39147f,0f,0f ) ;
  }

  @Test
  public void test1008() {
    TestDrivers.surfaceShade(-689.0f,706.0f,0f,0f,256.0f,-416.0f,0f,1337.0f,0f,0f,0f,0f,0f,-848.0f,76.0f,597.0f,-628.0f,-1443.0f,-3482.0f,44,1.266024f,-0.07841776f,1.8082883f,-25.08501f,41.099155f,0f ) ;
  }

  @Test
  public void test1009() {
    TestDrivers.surfaceShade(691.0f,0f,0f,0f,137.0f,608.0f,0f,973.0f,0f,0f,0f,0f,0f,278.0f,-583.0f,-644.0f,-23.0f,617.0f,-354.0f,400,-3.209005f,-2.5722096f,64.91328f,97.981575f,0f,0f ) ;
  }

  @Test
  public void test1010() {
    TestDrivers.surfaceShade(691.0f,13.0f,307.0f,0f,293.0f,687.0f,0f,-960.0f,0f,0f,0f,0f,0f,-60.0f,269.0f,58.0f,342.0f,-355.0f,-523.0f,-811,46.273888f,9.786076f,-91.06816f,66.95669f,-81.729416f,-69.43481f ) ;
  }

  @Test
  public void test1011() {
    TestDrivers.surfaceShade(691.0f,-929.0f,1151.0f,0f,112.0f,-6.0f,0f,438.0f,0f,0f,0f,0f,0f,1506.0f,240.0f,-937.0f,-221.0f,-881.0f,-516.0f,-195,-18.314865f,58.260754f,-13.042987f,8.26265f,1.7505153f,-31.366087f ) ;
  }

  @Test
  public void test1012() {
    TestDrivers.surfaceShade(-693.0f,-207.0f,-156.0f,0f,45.0f,-646.0f,0f,903.0f,0f,0f,0f,0f,0f,-11.0f,771.0f,210.0f,415.0f,451.0f,54.0f,767,100.0f,-100.0f,-100.0f,100.0f,-100.0f,66.49202f ) ;
  }

  @Test
  public void test1013() {
    TestDrivers.surfaceShade(697.0f,1656.0f,502.0f,0f,288.0f,-512.0f,0f,1834.0f,0f,0f,0f,0f,0f,1387.0f,74.0f,387.0f,-1023.0f,-209.0f,-948.0f,196,0.11688994f,0.31916162f,-0.5849179f,100.0f,59.15915f,79.22776f ) ;
  }

  @Test
  public void test1014() {
    TestDrivers.surfaceShade(704.0f,876.0f,0f,0f,1266.0f,811.0f,0f,86.0f,0f,0f,0f,0f,0f,1525.0f,83.0f,709.0f,65.0f,571.0f,-830.0f,922,0.10276495f,-0.05992441f,-0.34983674f,-35.029926f,62.876106f,0f ) ;
  }

  @Test
  public void test1015() {
    TestDrivers.surfaceShade(-709.0f,1659.0f,-155.0f,0f,264.0f,-1857.0f,0f,-820.0f,0f,0f,0f,0f,0f,474.0f,-14.0f,576.0f,0f,0f,0f,1355,-0.039090276f,0.6090064f,-0.04739111f,2.038007f,6.03311f,-32.624672f ) ;
  }

  @Test
  public void test1016() {
    TestDrivers.surfaceShade(-709.0f,197.0f,0f,0f,15.0f,1.0f,0f,-58.0f,0f,0f,0f,0f,0f,-864.0f,331.0f,-649.0f,0f,0f,0f,230,100.0f,-100.0f,56.413235f,84.89053f,-79.69175f,0f ) ;
  }

  @Test
  public void test1017() {
    TestDrivers.surfaceShade(7.0f,678.0f,-196.0f,0f,177.0f,282.0f,0f,-869.0f,0f,0f,0f,0f,0f,-655.0f,-1481.0f,108.0f,-489.0f,593.0f,329.0f,-101,0.42546982f,-0.06268695f,0.036589243f,-43.68483f,35.92053f,29.742895f ) ;
  }

  @Test
  public void test1018() {
    TestDrivers.surfaceShade(710.0f,-9.0f,0f,32.0f,0f,0f,0f,-30.43547f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-100.0f,-0.0034722222f,0f ) ;
  }

  @Test
  public void test1019() {
    TestDrivers.surfaceShade(714.0f,-483.0f,-1065.0f,0f,420.0f,-1734.0f,0f,114.0f,0f,0f,0f,0f,0f,413.0f,-430.0f,-761.0f,-2029.0f,-552.0f,-2004.0f,1678,57.513695f,88.51369f,-18.801222f,-44.736637f,-100.0f,-44.728676f ) ;
  }

  @Test
  public void test1020() {
    TestDrivers.surfaceShade(-714.0f,708.0f,0f,0f,1148.0f,69.0f,0f,-943.0f,0f,0f,0f,0f,0f,71.0f,790.0f,120.0f,-694.0f,-1007.0f,-506.0f,76,0.27351806f,-0.5786767f,-0.08925011f,-79.470795f,12.320784f,0f ) ;
  }

  @Test
  public void test1021() {
    TestDrivers.surfaceShade(718.0f,823.0f,1228.0f,-353.0f,0f,0f,0f,-6.9783325f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,3,0f,0f,0f,80.20714f,-17.478289f,42.49202f ) ;
  }

  @Test
  public void test1022() {
    TestDrivers.surfaceShade(-720.0f,583.0f,0f,0f,834.0f,1.0f,0f,-3026.0f,0f,0f,0f,0f,0f,-703.0f,-464.0f,-240.0f,0f,0f,0f,638,-100.0f,99.784485f,100.0f,-56.585518f,30.045399f,0f ) ;
  }

  @Test
  public void test1023() {
    TestDrivers.surfaceShade(721.0f,1012.0f,0f,0f,1223.0f,-1756.0f,0f,-76.0f,0f,0f,0f,0f,0f,922.0f,547.0f,-421.0f,0f,0f,0f,2645,36.795338f,-38.769325f,30.210163f,48.466076f,58.246372f,0f ) ;
  }

  @Test
  public void test1024() {
    TestDrivers.surfaceShade(-725.0f,0f,0f,0f,-192.0f,232.0f,572.0f,-606.0f,0f,0f,0f,0f,0f,-765.0f,-348.0f,-884.0f,815.0f,-543.0f,566.0f,473,-95.04322f,-78.55596f,33.997257f,-21.420673f,0f,0f ) ;
  }

  @Test
  public void test1025() {
    TestDrivers.surfaceShade(726.0f,344.0f,0f,-1.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-0.0013774105f,5.965796f,0f ) ;
  }

  @Test
  public void test1026() {
    TestDrivers.surfaceShade(-73.0f,-1120.0f,-905.0f,-832.0f,0f,0f,0f,-89.510574f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,-79.301506f,22.434818f,11.255414f ) ;
  }

  @Test
  public void test1027() {
    TestDrivers.surfaceShade(731.0f,-25.0f,-891.0f,45.0f,0f,0f,0f,-23.431814f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,3.0399757E-5f,-16.31636f,-44.897106f ) ;
  }

  @Test
  public void test1028() {
    TestDrivers.surfaceShade(733.0f,-887.0f,582.0f,0f,63.0f,-191.0f,0f,282.0f,0f,0f,0f,0f,0f,-1049.0f,-562.0f,-723.0f,-1191.0f,881.0f,149.0f,1847,-42.96996f,-35.642517f,90.0506f,-64.12742f,52.99772f,5.015144f ) ;
  }

  @Test
  public void test1029() {
    TestDrivers.surfaceShade(-735.0f,-110.0f,0f,0f,416.0f,-739.0f,0f,718.0f,0f,0f,0f,0f,0f,-413.0f,593.0f,132.0f,388.0f,1679.0f,-180.0f,791,76.66277f,-42.37906f,-51.956608f,9.329426E-11f,12.785162f,0f ) ;
  }

  @Test
  public void test1030() {
    TestDrivers.surfaceShade(-735.0f,-518.0f,-2016.0f,0f,44.0f,-117.0f,0f,781.0f,0f,0f,0f,0f,0f,1133.0f,978.0f,-897.0f,1393.0f,912.0f,-628.0f,1219,-0.08792196f,-0.24830784f,-0.3566395f,-29.441444f,18.601616f,-30.818012f ) ;
  }

  @Test
  public void test1031() {
    TestDrivers.surfaceShade(-736.0f,-425.0f,-366.0f,0f,352.0f,593.0f,0f,-488.0f,0f,0f,0f,0f,0f,-534.0f,867.0f,-599.0f,-298.0f,-1319.0f,39.0f,444,28.856554f,47.04553f,42.369072f,-68.293625f,-49.30954f,99.926125f ) ;
  }

  @Test
  public void test1032() {
    TestDrivers.surfaceShade(-737.0f,61.0f,-413.0f,0f,603.0f,1265.0f,0f,-56.0f,0f,0f,0f,0f,0f,178.0f,2955.0f,-23.0f,-778.0f,-568.0f,-208.0f,46,-0.32774606f,-0.07662629f,-0.5999378f,24.566751f,-94.26319f,81.670555f ) ;
  }

  @Test
  public void test1033() {
    TestDrivers.surfaceShade(742.0f,994.0f,414.0f,232.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,-27.027473f,-28.892109f,1.0411461E-5f ) ;
  }

  @Test
  public void test1034() {
    TestDrivers.surfaceShade(-746.0f,-1426.0f,0f,0f,974.0f,1393.0f,0f,589.0f,0f,0f,0f,0f,0f,-661.0f,580.0f,-964.0f,36.0f,-452.0f,706.0f,-208,25.159178f,13.977006f,-8.84186f,78.52119f,-84.77589f,0f ) ;
  }

  @Test
  public void test1035() {
    TestDrivers.surfaceShade(75.0f,-3565.0f,63.0f,0f,55.0f,173.0f,0f,114.0f,0f,0f,0f,0f,0f,162.0f,802.0f,616.0f,687.0f,-420.0f,897.0f,-657,-7.8610597f,21.371527f,-25.75726f,-100.0f,-0.6230943f,39.37749f ) ;
  }

  @Test
  public void test1036() {
    TestDrivers.surfaceShade(75.0f,434.0f,-125.0f,0f,873.0f,1335.0f,0f,412.0f,0f,0f,0f,0f,0f,191.0f,-158.0f,518.0f,-214.0f,-719.0f,1301.0f,323,100.0f,63.25449f,-17.578747f,94.3089f,-87.81648f,-70.16349f ) ;
  }

  @Test
  public void test1037() {
    TestDrivers.surfaceShade(-753.0f,207.0f,958.0f,0f,65.0f,18.0f,0f,709.0f,0f,0f,0f,0f,0f,213.0f,-1536.0f,156.0f,-1745.0f,203.0f,705.0f,-137,0.36695012f,0.37854818f,-0.09297801f,100.0f,65.475624f,100.0f ) ;
  }

  @Test
  public void test1038() {
    TestDrivers.surfaceShade(-755.0f,1079.0f,0f,0f,1606.0f,2.0f,0f,13.0f,0f,0f,0f,0f,0f,812.0f,1228.0f,132.0f,0f,0f,0f,1245,0.29818454f,-0.41106436f,-0.4662537f,37.818798f,-58.216618f,0f ) ;
  }

  @Test
  public void test1039() {
    TestDrivers.surfaceShade(-758.0f,0f,0f,0f,377.0f,848.0f,-89.0f,805.0f,0f,0f,0f,0f,0f,384.0f,-111.0f,-736.0f,874.0f,-429.0f,352.0f,-220,8.4123125f,-61.03527f,30.29483f,-67.51172f,0f,0f ) ;
  }

  @Test
  public void test1040() {
    TestDrivers.surfaceShade(758.0f,911.0f,0f,0f,73.0f,-259.0f,0f,-708.0f,0f,0f,0f,0f,0f,-285.0f,715.0f,846.0f,0f,0f,0f,-354,0.40230766f,0.715105f,-0.4688444f,-70.24525f,87.84043f,0f ) ;
  }

  @Test
  public void test1041() {
    TestDrivers.surfaceShade(761.0f,-1183.0f,577.0f,0f,906.0f,-194.0f,0f,-365.0f,0f,0f,0f,0f,0f,358.0f,920.0f,-20.0f,0f,0f,0f,59,-0.9074446f,0.26534986f,0.29051602f,-41.387833f,91.59816f,-96.4555f ) ;
  }

  @Test
  public void test1042() {
    TestDrivers.surfaceShade(761.0f,568.0f,798.0f,0f,890.0f,96.0f,-978.0f,124.0f,0f,0f,0f,0f,0f,-344.0f,839.0f,529.0f,-681.0f,586.0f,712.0f,953,16.61876f,-25.914345f,25.24716f,-94.88485f,-2.8754678f,85.92183f ) ;
  }

  @Test
  public void test1043() {
    TestDrivers.surfaceShade(-765.0f,1131.0f,0f,0f,796.0f,1155.0f,0f,-1773.0f,0f,0f,0f,0f,0f,839.0f,-545.0f,881.0f,-624.0f,-677.0f,-2222.0f,-321,-0.5890407f,0.17658162f,0.08187123f,61.280598f,92.58543f,0f ) ;
  }

  @Test
  public void test1044() {
    TestDrivers.surfaceShade(773.0f,3064.0f,617.0f,0f,532.0f,251.0f,0f,-350.0f,0f,0f,0f,0f,0f,11.0f,673.0f,-393.0f,-370.0f,-851.0f,-1553.0f,-1145,21.054022f,12.120917f,21.345984f,99.995346f,93.57778f,-4.5871534f ) ;
  }

  @Test
  public void test1045() {
    TestDrivers.surfaceShade(78.0f,-550.0f,841.0f,-380.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-2,0f,0f,0f,1.3296104E-5f,4.784689E-6f,-4.0521413E-6f ) ;
  }

  @Test
  public void test1046() {
    TestDrivers.surfaceShade(-782.0f,0f,0f,0f,27.34427f,0.0f,0f,-46.19426f,0f,0f,0f,0f,0f,36.4814f,57.501144f,-0.9693203f,0f,0f,0f,-123,63.019054f,-40.461178f,-28.412483f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test1047() {
    TestDrivers.surfaceShade(-782.0f,-333.0f,600.0f,0f,1404.0f,-1926.0f,0f,3.0f,0f,0f,0f,0f,0f,-1583.0f,-1499.0f,-385.0f,0f,0f,0f,598,-0.025928693f,0.6104972f,0.26372647f,184.78471f,100.0f,67.887566f ) ;
  }

  @Test
  public void test1048() {
    TestDrivers.surfaceShade(-784.0f,-438.0f,0f,0f,391.0f,-545.0f,0f,1491.0f,0f,0f,0f,0f,0f,98.0f,-650.0f,-252.0f,-1492.0f,-1052.0f,-322.0f,-420,-0.45656106f,-0.0937418f,0.38995868f,-43.297546f,14.409485f,0f ) ;
  }

  @Test
  public void test1049() {
    TestDrivers.surfaceShade(79.0f,0f,0f,0f,100.0f,-38.2527f,0f,-30.635893f,0f,0f,0f,0f,0f,-100.0f,-100.0f,92.73781f,0f,0f,0f,-113,0.36481923f,-0.70719945f,-0.36919162f,100.0f,0f,0f ) ;
  }

  @Test
  public void test1050() {
    TestDrivers.surfaceShade(-79.0f,-1023.0f,-112.0f,463.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,23.527954f,-100.0f,-1.928417E-5f ) ;
  }

  @Test
  public void test1051() {
    TestDrivers.surfaceShade(-793.0f,-315.0f,-79.0f,0f,72.0f,-1388.0f,0f,1789.0f,0f,0f,0f,0f,0f,423.0f,-310.0f,829.0f,108.0f,772.0f,-460.0f,1936,-0.7594267f,0.32705182f,0.50979924f,35.665806f,-7.8438535f,-27.40187f ) ;
  }

  @Test
  public void test1052() {
    TestDrivers.surfaceShade(798.0f,0f,0f,0f,2.6293705f,-15.411289f,0f,0.0f,0f,0f,0f,0f,0f,-26.742308f,-68.16314f,76.25091f,0f,0f,0f,-419,0.4018721f,-0.33346695f,-0.4376956f,35.629112f,0f,0f ) ;
  }

  @Test
  public void test1053() {
    TestDrivers.surfaceShade(799.0f,110.0f,-681.0f,596.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,83.69515f,129.8716f,-42.88505f ) ;
  }

  @Test
  public void test1054() {
    TestDrivers.surfaceShade(-799.0f,56.0f,1534.0f,0f,951.0f,-1016.0f,0f,1223.0f,0f,0f,0f,0f,0f,-538.0f,-479.0f,-485.0f,430.0f,733.0f,549.0f,-507,-79.85293f,63.38043f,25.982782f,-37.210968f,82.16964f,100.0f ) ;
  }

  @Test
  public void test1055() {
    TestDrivers.surfaceShade(-803.0f,0f,0f,0f,89.355194f,-100.0f,0f,-100.0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,100.0f,0f,0f,0f,-883,2.3879344f,14.30327f,-100.0f,9.589829f,0f,0f ) ;
  }

  @Test
  public void test1056() {
    TestDrivers.surfaceShade(805.0f,199.0f,-1181.0f,0f,1443.0f,-821.0f,0f,492.0f,0f,0f,0f,0f,0f,685.0f,166.0f,-1753.0f,-435.0f,-651.0f,935.0f,321,0.02541398f,0.23139203f,0.11552321f,-100.0f,-79.30639f,-50.98978f ) ;
  }

  @Test
  public void test1057() {
    TestDrivers.surfaceShade(-8.0f,534.0f,0f,-267.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,4.681648E-4f,-7.013705E-6f,0f ) ;
  }

  @Test
  public void test1058() {
    TestDrivers.surfaceShade(810.0f,76.0f,1100.0f,0f,41.0f,-1290.0f,0f,208.0f,0f,0f,0f,0f,0f,347.0f,28.0f,-148.0f,1137.0f,1637.0f,-368.0f,190,38.367138f,-4.5650287f,89.091736f,-60.65842f,16.377834f,-100.0f ) ;
  }

  @Test
  public void test1059() {
    TestDrivers.surfaceShade(814.0f,32.0f,0f,0f,358.0f,1185.0f,0f,-901.0f,0f,0f,0f,0f,0f,-432.0f,-704.0f,-649.0f,-1654.0f,865.0f,-213.0f,-575,27.281364f,4.0705585f,-22.575073f,-8.000579f,1.389109f,0f ) ;
  }

  @Test
  public void test1060() {
    TestDrivers.surfaceShade(-817.0f,-1017.0f,0f,0f,160.0f,-1001.0f,0f,758.0f,0f,0f,0f,0f,0f,-420.0f,-355.0f,705.0f,52.0f,181.0f,-845.0f,1137,-31.639097f,53.234848f,-38.96187f,-2.3126923E-10f,-1.87888E-10f,0f ) ;
  }

  @Test
  public void test1061() {
    TestDrivers.surfaceShade(-817.0f,-1465.0f,-971.0f,0f,324.0f,-1370.0f,0f,279.0f,0f,0f,0f,0f,0f,267.0f,990.0f,-492.0f,-883.0f,-696.0f,-828.0f,-1675,-24.514223f,-11.827202f,-37.10209f,-44.785713f,1.480425f,-3.4740348f ) ;
  }

  @Test
  public void test1062() {
    TestDrivers.surfaceShade(82.0f,38.0f,535.0f,0f,26.0f,-494.0f,0f,30.0f,0f,0f,0f,0f,0f,487.0f,-360.0f,-405.0f,1260.0f,267.0f,-80.0f,-1174,0.98264587f,-13.186425f,12.902869f,-95.98776f,100.0f,0.19238907f ) ;
  }

  @Test
  public void test1063() {
    TestDrivers.surfaceShade(824.0f,-204.0f,-1974.0f,145.0f,0f,0f,0f,-58.94604f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,85.815f,-75.3075f,-78.64468f ) ;
  }

  @Test
  public void test1064() {
    TestDrivers.surfaceShade(826.0f,0f,0f,0f,957.0f,-935.0f,0f,879.0f,0f,0f,0f,0f,0f,613.0f,162.0f,-883.0f,-738.0f,223.0f,-566.0f,-589,28.389956f,25.782005f,37.953987f,-8.925066f,0f,0f ) ;
  }

  @Test
  public void test1065() {
    TestDrivers.surfaceShade(831.0f,0f,602.0f,0f,949.0f,-601.0f,0f,0.0f,0f,0f,0f,0f,0f,400.0f,433.0f,-541.0f,0f,0f,0f,429,0.0046569332f,-0.09257378f,0.024015084f,169.37483f,0f,-67.931335f ) ;
  }

  @Test
  public void test1066() {
    TestDrivers.surfaceShade(834.0f,-448.0f,-296.0f,0f,492.0f,622.0f,-726.0f,991.0f,0f,0f,0f,0f,0f,8.0f,-408.0f,361.0f,1473.0f,-359.0f,80.0f,883,-100.0f,92.65709f,-83.5579f,-78.50469f,-93.48029f,-100.0f ) ;
  }

  @Test
  public void test1067() {
    TestDrivers.surfaceShade(840.0f,-1444.0f,-973.0f,0f,298.0f,-348.0f,0f,861.0f,0f,0f,0f,0f,0f,515.0f,60.0f,516.0f,-4.0f,-532.0f,-139.0f,-29,-94.094955f,-25.31501f,96.85621f,-8.4308f,-1.6882346f,-58.546543f ) ;
  }

  @Test
  public void test1068() {
    TestDrivers.surfaceShade(840.0f,-1729.0f,1074.0f,0f,1667.0f,5.0f,0f,-953.0f,0f,0f,0f,0f,0f,-786.0f,446.0f,723.0f,0f,0f,0f,-576,74.90942f,23.228308f,-59.787315f,34.3009f,67.76112f,-39.368916f ) ;
  }

  @Test
  public void test1069() {
    TestDrivers.surfaceShade(841.0f,-367.0f,0f,0f,7.0f,-5.0f,0f,-1170.0f,0f,0f,0f,0f,0f,2741.0f,-579.0f,-543.0f,0f,0f,0f,-70,-45.907494f,93.66023f,-53.422676f,-86.01838f,-54.180336f,0f ) ;
  }

  @Test
  public void test1070() {
    TestDrivers.surfaceShade(-845.0f,0f,0f,0f,220.0f,117.0f,0f,3.0f,0f,0f,0f,0f,0f,588.0f,-342.0f,695.0f,-1549.0f,-762.0f,-1631.0f,-544,-44.574432f,-100.0f,-13.366826f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test1071() {
    TestDrivers.surfaceShade(-846.0f,-375.0f,-1641.0f,0f,1668.0f,514.0f,0f,264.0f,0f,0f,0f,0f,0f,-343.0f,-410.0f,23.0f,-930.0f,781.0f,352.0f,-546,55.151592f,-41.242332f,87.12168f,-15.618356f,5.155066f,57.01167f ) ;
  }

  @Test
  public void test1072() {
    TestDrivers.surfaceShade(848.0f,-935.0f,0f,0f,1000.0f,-654.0f,0f,0.0f,0f,0f,0f,0f,0f,426.0f,545.0f,722.0f,0f,0f,0f,172,-0.046739936f,-0.12883294f,0.1248271f,74.713425f,-27.410755f,0f ) ;
  }

  @Test
  public void test1073() {
    TestDrivers.surfaceShade(-853.0f,0f,0f,289.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-4.0565155E-6f,0f,0f ) ;
  }

  @Test
  public void test1074() {
    TestDrivers.surfaceShade(-855.0f,-393.0f,0f,0f,193.0f,2.0f,0f,0.0f,0f,0f,0f,0f,0f,943.0f,574.0f,573.0f,0f,0f,0f,-1144,-249.67294f,65.61199f,-23.858713f,-42.126453f,100.0f,0f ) ;
  }

  @Test
  public void test1075() {
    TestDrivers.surfaceShade(855.0f,-581.0f,737.0f,0f,119.0f,1150.0f,0f,148.0f,0f,0f,0f,0f,0f,-204.0f,85.0f,757.0f,-788.0f,288.0f,-201.0f,-1055,99.971054f,58.256775f,20.399298f,25.046476f,-47.41755f,79.66829f ) ;
  }

  @Test
  public void test1076() {
    TestDrivers.surfaceShade(856.0f,0f,0f,-1116.0f,0f,0f,0f,1.4210855E-14f,0f,0f,0f,0f,0f,17.830824f,39.465797f,75.68146f,-233.0f,-587.0f,361.0f,-2,0f,0f,0f,0.0033783785f,0f,0f ) ;
  }

  @Test
  public void test1077() {
    TestDrivers.surfaceShade(-858.0f,174.0f,-1221.0f,0f,870.0f,-1538.0f,0f,288.0f,0f,0f,0f,0f,0f,960.0f,-872.0f,-600.0f,18.0f,-662.0f,1427.0f,12,-23.41048f,13.175663f,-56.6054f,-78.92212f,67.84538f,39.952442f ) ;
  }

  @Test
  public void test1078() {
    TestDrivers.surfaceShade(-858.0f,-67.0f,0f,0f,917.0f,-1699.0f,0f,2166.0f,0f,0f,0f,0f,0f,707.0f,361.0f,366.0f,-1615.0f,1474.0f,104.0f,-962,0.7043992f,0.59397507f,-1.9465444f,80.89084f,-95.28674f,0f ) ;
  }

  @Test
  public void test1079() {
    TestDrivers.surfaceShade(-861.0f,-1089.0f,0f,0f,2273.0f,534.0f,0f,-1554.0f,0f,0f,0f,0f,0f,949.0f,-1119.0f,996.0f,-1100.0f,2921.0f,-440.0f,-740,0.45985308f,-1.3626978f,-1.969136f,-68.65631f,-98.432106f,0f ) ;
  }

  @Test
  public void test1080() {
    TestDrivers.surfaceShade(-863.0f,-408.0f,0f,0f,870.0f,-910.0f,0f,-380.0f,0f,0f,0f,0f,0f,-443.0f,967.0f,179.0f,0f,0f,0f,-693,97.911964f,-75.94843f,4.475872f,-92.50543f,50.89393f,0f ) ;
  }

  @Test
  public void test1081() {
    TestDrivers.surfaceShade(868.0f,364.0f,0f,0f,728.0f,431.0f,0f,-991.0f,0f,0f,0f,0f,0f,690.0f,-766.0f,-67.0f,88.0f,653.0f,-895.0f,716,-28.8985f,17.693663f,49.727684f,-4.947535f,100.0f,0f ) ;
  }

  @Test
  public void test1082() {
    TestDrivers.surfaceShade(-870.0f,0f,0f,971.0f,0f,0f,0f,72.112465f,0f,0f,0f,0f,0f,20.965662f,-7.1156464f,-25.683407f,559.0f,533.0f,674.0f,0,0f,0f,0f,63.409004f,0f,0f ) ;
  }

  @Test
  public void test1083() {
    TestDrivers.surfaceShade(-87.0f,-1330.0f,-154.0f,0f,730.0f,1215.0f,0f,-1111.0f,0f,0f,0f,0f,0f,-376.0f,-329.0f,-490.0f,-29.0f,1463.0f,-190.0f,723,44.515923f,-61.625603f,7.218034f,-75.40875f,-11.687911f,-42.89382f ) ;
  }

  @Test
  public void test1084() {
    TestDrivers.surfaceShade(-871.0f,0f,0f,0f,2.6369968E-8f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,98.703445f,3.7827134f,90.03281f,0f,0f,0f,-2630,1.2826796f,96.82371f,-32.762077f,-21.145958f,0f,0f ) ;
  }

  @Test
  public void test1085() {
    TestDrivers.surfaceShade(-875.0f,-747.0f,696.0f,0f,-481.0f,-795.0f,102.0f,996.0f,0f,0f,0f,0f,0f,813.0f,-928.0f,-376.0f,786.0f,44.0f,246.0f,-990,84.059906f,28.729906f,-57.109013f,67.962975f,-17.965252f,24.316393f ) ;
  }

  @Test
  public void test1086() {
    TestDrivers.surfaceShade(876.0f,-582.0f,0f,-379.0f,0f,0f,0f,-155.95245f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,-28.07249f,-23.565445f,0f ) ;
  }

  @Test
  public void test1087() {
    TestDrivers.surfaceShade(876.0f,777.0f,-297.0f,0f,86.0f,100.0f,0f,1024.0f,0f,0f,0f,0f,0f,-356.0f,285.0f,885.0f,-1094.0f,984.0f,-802.0f,338,2.2280064f,-3.6039512f,2.056832f,89.350426f,71.117455f,-7.2913094f ) ;
  }

  @Test
  public void test1088() {
    TestDrivers.surfaceShade(-877.0f,494.0f,-1196.0f,6.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-100.0f,3.373819E-4f,-1.393534E-4f ) ;
  }

  @Test
  public void test1089() {
    TestDrivers.surfaceShade(-880.0f,429.0f,-137.0f,0f,615.0f,182.0f,0f,1182.0f,0f,0f,0f,0f,0f,206.0f,-867.0f,-629.0f,529.0f,-396.0f,-1050.0f,-830,3.854482f,-66.757f,93.27877f,-5.910763f,-52.2138f,31.209017f ) ;
  }

  @Test
  public void test1090() {
    TestDrivers.surfaceShade(885.0f,1042.0f,604.0f,0f,1566.0f,359.0f,0f,-184.0f,0f,0f,0f,0f,0f,660.0f,511.0f,167.0f,-1242.0f,-284.0f,1726.0f,-1085,2.6652493f,-2.7085333f,-2.245533f,-100.0f,100.0f,75.94216f ) ;
  }

  @Test
  public void test1091() {
    TestDrivers.surfaceShade(885.0f,872.0f,-54.0f,0f,374.0f,-398.0f,0f,-42.0f,0f,0f,0f,0f,0f,80.0f,931.0f,-976.0f,0f,0f,0f,507,88.53432f,88.82962f,97.742775f,81.86926f,-54.557167f,12.017611f ) ;
  }

  @Test
  public void test1092() {
    TestDrivers.surfaceShade(-890.0f,2813.0f,-47.0f,0f,689.0f,-1601.0f,0f,118.0f,0f,0f,0f,0f,0f,-870.0f,580.0f,-881.0f,-860.0f,-324.0f,-68.0f,-585,-1.3195766f,-24.582096f,-14.880344f,-78.57431f,88.13442f,-85.27066f ) ;
  }

  @Test
  public void test1093() {
    TestDrivers.surfaceShade(891.0f,83.0f,688.0f,-1.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,95.257935f,95.161156f,79.730354f ) ;
  }

  @Test
  public void test1094() {
    TestDrivers.surfaceShade(-893.0f,0f,0f,0f,99.0f,-58.0f,0f,1440.0f,0f,0f,0f,0f,0f,-515.0f,-1128.0f,-103.0f,-870.0f,39.0f,-637.0f,-219,0.501512f,0.34405574f,0.025764832f,3.4280915f,0f,0f ) ;
  }

  @Test
  public void test1095() {
    TestDrivers.surfaceShade(-894.0f,0f,0f,0f,844.0f,910.0f,598.0f,-124.0f,0f,0f,0f,0f,0f,162.0f,-357.0f,632.0f,651.0f,258.0f,244.0f,-927,1.9791874f,35.322636f,-86.99189f,94.813255f,0f,0f ) ;
  }

  @Test
  public void test1096() {
    TestDrivers.surfaceShade(897.0f,-409.0f,1093.0f,0f,741.0f,-1479.0f,0f,-1334.0f,0f,0f,0f,0f,0f,1466.0f,-696.0f,280.0f,0f,0f,0f,-346,-0.3407991f,-0.47447264f,0.6049233f,99.84157f,-56.41394f,11.008969f ) ;
  }

  @Test
  public void test1097() {
    TestDrivers.surfaceShade(898.0f,-559.0f,0f,0f,274.0f,-960.0f,0f,0.0f,0f,0f,0f,0f,0f,-689.0f,-459.0f,385.0f,0f,0f,0f,-1391,67.04203f,-19.273777f,-80.01023f,70.73893f,-100.0f,0f ) ;
  }

  @Test
  public void test1098() {
    TestDrivers.surfaceShade(898.0f,-735.0f,0f,0f,500.0f,-844.0f,0f,-1.0f,0f,0f,0f,0f,0f,692.0f,660.0f,1500.0f,0f,0f,0f,-461,66.66528f,-52.99012f,-54.355255f,-100.0f,-13.730156f,0f ) ;
  }

  @Test
  public void test1099() {
    TestDrivers.surfaceShade(-900.0f,1166.0f,0f,0f,582.0f,1.0f,0f,227.0f,0f,0f,0f,0f,0f,-186.0f,988.0f,-689.0f,-863.0f,-1318.0f,-153.0f,-455,12.89928f,-87.2143f,82.62962f,50.8876f,85.45601f,0f ) ;
  }

  @Test
  public void test1100() {
    TestDrivers.surfaceShade(900.0f,-425.0f,-365.0f,0f,129.0f,-731.0f,0f,1639.0f,0f,0f,0f,0f,0f,1152.0f,-1184.0f,-70.0f,-185.0f,-77.0f,480.0f,863,-0.941457f,-0.14445585f,0.2498914f,4.2921243f,18.812433f,-35.554504f ) ;
  }

  @Test
  public void test1101() {
    TestDrivers.surfaceShade(-90.0f,0f,0f,0f,10.420603f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-7.336015f,5.5830393f,18.74193f,0f,0f,0f,1738,-0.5433393f,-0.8203976f,0.031711f,-25.52828f,0f,0f ) ;
  }

  @Test
  public void test1102() {
    TestDrivers.surfaceShade(90.0f,-1197.0f,-287.0f,-21.0f,0f,0f,0f,-31.776571f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,-5.2910054E-4f,-0.17368655f,1.6592002E-4f ) ;
  }

  @Test
  public void test1103() {
    TestDrivers.surfaceShade(901.0f,-614.0f,-910.0f,0f,708.0f,334.0f,0f,1158.0f,0f,0f,0f,0f,0f,1256.0f,658.0f,489.0f,-491.0f,-569.0f,-59.0f,-653,-0.3895013f,0.3352891f,-0.28852826f,8.85631f,0.60127836f,-24.418514f ) ;
  }

  @Test
  public void test1104() {
    TestDrivers.surfaceShade(905.0f,0f,-213.0f,0f,145.0f,-302.0f,0f,1.0f,0f,0f,0f,0f,0f,436.0f,811.0f,427.0f,0f,0f,0f,-202,-0.32720792f,0.32404727f,-0.28135756f,88.13949f,0f,-47.396973f ) ;
  }

  @Test
  public void test1105() {
    TestDrivers.surfaceShade(-909.0f,496.0f,95.0f,0f,879.0f,136.0f,0f,914.0f,0f,0f,0f,0f,0f,123.0f,486.0f,595.0f,-58.0f,-798.0f,-287.0f,-541,60.0835f,-5.715593f,-16.603947f,-6.4377027f,-78.93627f,93.68173f ) ;
  }

  @Test
  public void test1106() {
    TestDrivers.surfaceShade(-909.0f,-675.0f,0f,179.0f,0f,0f,0f,964.0f,0f,0f,0f,0f,0f,200.0f,225.0f,315.0f,942.0f,-588.0f,-777.0f,1,0f,0f,0f,49.466225f,-39.562157f,0f ) ;
  }

  @Test
  public void test1107() {
    TestDrivers.surfaceShade(-9.0f,1906.0f,0f,0f,16.0f,-511.0f,0f,3.0f,0f,0f,0f,0f,0f,-1298.0f,-240.0f,-812.0f,0f,0f,0f,874,20.170702f,-71.32581f,-11.161792f,-44.762867f,-3.692857E-8f,0f ) ;
  }

  @Test
  public void test1108() {
    TestDrivers.surfaceShade(91.0f,-608.0f,-85.0f,17.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,29.848412f,-9.674922E-5f,-100.0f ) ;
  }

  @Test
  public void test1109() {
    TestDrivers.surfaceShade(-911.0f,0f,0f,0f,100.0f,-100.0f,0f,0.0f,0f,0f,0f,0f,0f,82.06397f,69.24182f,82.730156f,0f,0f,0f,1273,-22.788717f,-54.863148f,23.45475f,-36.02328f,0f,0f ) ;
  }

  @Test
  public void test1110() {
    TestDrivers.surfaceShade(-915.0f,-4.0f,1322.0f,0f,675.0f,-956.0f,0f,-86.0f,0f,0f,0f,0f,0f,-379.0f,-938.0f,-466.0f,0f,0f,0f,-1274,-10.70635f,9.895015f,-11.2099085f,-8.135188f,45.642868f,100.0f ) ;
  }

  @Test
  public void test1111() {
    TestDrivers.surfaceShade(916.0f,772.0f,-550.0f,0f,411.0f,359.0f,-897.0f,783.0f,0f,0f,0f,0f,0f,-380.0f,-324.0f,995.0f,-971.0f,-929.0f,937.0f,903,70.20292f,1.7499381f,-5.608493f,-6.5507393f,-84.12749f,89.052925f ) ;
  }

  @Test
  public void test1112() {
    TestDrivers.surfaceShade(-92.0f,0f,0f,0f,12.068187f,0.0f,0f,-39.281033f,0f,0f,0f,0f,0f,36.61018f,50.183674f,-45.782776f,0f,0f,0f,356,-1.3434571f,0.7220971f,-0.2827181f,-25.697218f,0f,0f ) ;
  }

  @Test
  public void test1113() {
    TestDrivers.surfaceShade(921.0f,-257.0f,0f,-249.0f,0f,0f,0f,2331.0f,0f,0f,0f,0f,0f,1456.0f,201.0f,-1501.0f,-1197.0f,809.0f,636.0f,-6,0f,0f,0f,29.878218f,1.5626709E-5f,0f ) ;
  }

  @Test
  public void test1114() {
    TestDrivers.surfaceShade(921.0f,310.0f,-415.0f,0f,445.0f,4436.0f,0f,2333.0f,0f,0f,0f,0f,0f,-207.0f,-681.0f,718.0f,994.0f,664.0f,-1398.0f,-735,-77.53149f,-6.7289453f,-28.734581f,64.90577f,43.083046f,-32.18216f ) ;
  }

  @Test
  public void test1115() {
    TestDrivers.surfaceShade(922.0f,812.0f,495.0f,0f,1123.0f,-1109.0f,0f,1163.0f,0f,0f,0f,0f,0f,-1437.0f,-3.0f,798.0f,54.0f,868.0f,1047.0f,-218,-0.45345384f,-0.12818652f,-0.8210591f,-85.68061f,-9.673268f,-0.9705407f ) ;
  }

  @Test
  public void test1116() {
    TestDrivers.surfaceShade(-924.0f,-1150.0f,1642.0f,0f,60.0f,26.0f,0f,556.0f,0f,0f,0f,0f,0f,422.0f,758.0f,-740.0f,-828.0f,1009.0f,-752.0f,135,77.75238f,-11.177304f,32.890686f,-17.902f,16.538252f,-71.57157f ) ;
  }

  @Test
  public void test1117() {
    TestDrivers.surfaceShade(-924.0f,-2424.0f,0f,0f,23.0f,-5.0f,0f,-225.0f,0f,0f,0f,0f,0f,1320.0f,40.0f,-882.0f,0f,0f,0f,325,-1.8827125f,-0.8798844f,-2.857569f,-100.0f,-65.05611f,0f ) ;
  }

  @Test
  public void test1118() {
    TestDrivers.surfaceShade(924.0f,520.0f,499.0f,-1366.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,141.84727f,-15.838485f,27.904861f ) ;
  }

  @Test
  public void test1119() {
    TestDrivers.surfaceShade(-925.0f,369.0f,0f,0f,788.0f,923.0f,0f,-456.0f,0f,0f,0f,0f,0f,-733.0f,-792.0f,-433.0f,-530.0f,602.0f,499.0f,-962,31.817636f,-24.156454f,45.38621f,-53.813927f,31.965284f,0f ) ;
  }

  @Test
  public void test1120() {
    TestDrivers.surfaceShade(929.0f,239.0f,0f,0f,141.0f,-896.0f,0f,382.0f,0f,0f,0f,0f,0f,-751.0f,-793.0f,-3.0f,79.0f,-358.0f,276.0f,-298,-43.790966f,42.762474f,79.46614f,-58.673187f,-21.791777f,0f ) ;
  }

  @Test
  public void test1121() {
    TestDrivers.surfaceShade(931.0f,359.0f,0f,0f,94.0f,-479.0f,0f,190.0f,0f,0f,0f,0f,0f,322.0f,-366.0f,373.0f,929.0f,-790.0f,-992.0f,886,-82.749176f,-36.7022f,13.89333f,31.93341f,21.105423f,0f ) ;
  }

  @Test
  public void test1122() {
    TestDrivers.surfaceShade(933.0f,1588.0f,-404.0f,0f,522.0f,-1297.0f,0f,-472.0f,0f,0f,0f,0f,0f,443.0f,301.0f,-1671.0f,0f,0f,0f,-550,-0.41080537f,0.10166846f,-0.09059519f,-78.34752f,-13.266653f,-100.0f ) ;
  }

  @Test
  public void test1123() {
    TestDrivers.surfaceShade(-934.0f,857.0f,0f,0f,8.0f,-3.0f,0f,240.0f,0f,0f,0f,0f,0f,-228.0f,-1086.0f,219.0f,477.0f,754.0f,-667.0f,724,-33.01915f,30.420895f,85.34319f,-66.36164f,-100.0f,0f ) ;
  }

  @Test
  public void test1124() {
    TestDrivers.surfaceShade(935.0f,-929.0f,0f,0f,380.0f,2142.0f,0f,1703.0f,0f,0f,0f,0f,0f,515.0f,-510.0f,302.0f,173.0f,1056.0f,-340.0f,179,-17.455162f,-45.95286f,-47.83626f,89.51807f,-90.09509f,0f ) ;
  }

  @Test
  public void test1125() {
    TestDrivers.surfaceShade(937.0f,-376.0f,-1137.0f,0f,226.0f,-1450.0f,0f,-119.0f,0f,0f,0f,0f,0f,-174.0f,-282.0f,-451.0f,0f,0f,0f,969,97.99812f,99.46215f,-100.0f,100.0f,-49.4009f,-17.623629f ) ;
  }

  @Test
  public void test1126() {
    TestDrivers.surfaceShade(-945.0f,-104.0f,162.0f,117.0f,0f,0f,0f,-34.967167f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-86.72212f,-6.4268193f,-61.458763f ) ;
  }

  @Test
  public void test1127() {
    TestDrivers.surfaceShade(945.0f,-1569.0f,0f,0f,354.0f,-1.0f,0f,-885.0f,0f,0f,0f,0f,0f,1183.0f,-809.0f,-2866.0f,0f,0f,0f,-457,-0.18484442f,-0.8076578f,0.25076252f,21.497562f,-100.0f,0f ) ;
  }

  @Test
  public void test1128() {
    TestDrivers.surfaceShade(-948.0f,-1926.0f,0f,0f,3.0f,0.0f,0f,1.0f,0f,0f,0f,0f,0f,535.0f,-775.0f,199.0f,0f,0f,0f,-459,4.330169f,7.015355f,4.588399f,-95.020805f,-54.18483f,0f ) ;
  }

  @Test
  public void test1129() {
    TestDrivers.surfaceShade(950.0f,-144.0f,0f,0f,384.0f,1.0f,0f,-471.0f,0f,0f,0f,0f,0f,1999.0f,-60.0f,411.0f,0f,0f,0f,-332,-0.11051928f,-0.7653906f,0.0034739003f,-0.9421957f,100.0f,0f ) ;
  }

  @Test
  public void test1130() {
    TestDrivers.surfaceShade(95.0f,749.0f,0f,0f,514.0f,-741.0f,0f,243.0f,0f,0f,0f,0f,0f,526.0f,-678.0f,544.0f,292.0f,-285.0f,621.0f,-200,-54.020412f,-46.008427f,-87.64125f,24.273777f,-52.558357f,0f ) ;
  }

  @Test
  public void test1131() {
    TestDrivers.surfaceShade(951.0f,165.0f,0f,0f,614.0f,4.0f,0f,1352.0f,0f,0f,0f,0f,0f,589.0f,416.0f,719.0f,-1301.0f,-1305.0f,1082.0f,-582,81.571365f,57.342464f,-100.0f,-15.475271f,79.217705f,0f ) ;
  }

  @Test
  public void test1132() {
    TestDrivers.surfaceShade(-959.0f,572.0f,0f,0f,140.0f,-642.0f,0f,1638.0f,0f,0f,0f,0f,0f,277.0f,27.0f,616.0f,137.0f,-918.0f,817.0f,-1625,-0.17193086f,0.053674627f,-0.2334545f,57.450836f,81.79803f,0f ) ;
  }

  @Test
  public void test1133() {
    TestDrivers.surfaceShade(961.0f,0f,0f,-1145.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-53.852608f,0f,0f ) ;
  }

  @Test
  public void test1134() {
    TestDrivers.surfaceShade(-97.0f,479.0f,0f,0f,1746.0f,-1841.0f,0f,-486.0f,0f,0f,0f,0f,0f,-255.0f,746.0f,2191.0f,0f,0f,0f,1425,0.37472114f,-0.4337971f,-0.43984511f,45.78082f,-6.256067f,0f ) ;
  }

  @Test
  public void test1135() {
    TestDrivers.surfaceShade(-97.0f,746.0f,17.0f,0f,1033.0f,-814.0f,0f,-833.0f,0f,0f,0f,0f,0f,-734.0f,-18.0f,92.0f,0f,0f,0f,710,-12.530732f,-0.13571437f,-100.0f,-30.78909f,99.61635f,99.999985f ) ;
  }

  @Test
  public void test1136() {
    TestDrivers.surfaceShade(-975.0f,1259.0f,0f,0f,42.0f,-6.0f,0f,571.0f,0f,0f,0f,0f,0f,530.0f,-77.0f,70.0f,-668.0f,726.0f,1000.0f,-531,-19.725048f,-100.0f,39.346798f,-84.688934f,38.967854f,0f ) ;
  }

  @Test
  public void test1137() {
    TestDrivers.surfaceShade(976.0f,-757.0f,0f,-189.0f,0f,0f,0f,-65.17905f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0.029681424f,18.869987f,0f ) ;
  }

  @Test
  public void test1138() {
    TestDrivers.surfaceShade(979.0f,1464.0f,974.0f,0f,1821.0f,-540.0f,0f,1380.0f,0f,0f,0f,0f,0f,-1662.0f,-861.0f,-281.0f,1126.0f,-881.0f,278.0f,-918,-0.19783074f,0.5355291f,0.50204897f,-3.4783714f,-8.979977f,-88.56251f ) ;
  }

  @Test
  public void test1139() {
    TestDrivers.surfaceShade(98.0f,80.0f,-180.0f,0f,2.0f,-1743.0f,0f,-781.0f,0f,0f,0f,0f,0f,105.0f,-470.0f,-326.0f,0f,0f,0f,-626,99.49623f,-42.49326f,93.309616f,99.99999f,39.735897f,-54.737087f ) ;
  }

  @Test
  public void test1140() {
    TestDrivers.surfaceShade(-983.0f,0f,400.0f,0f,216.0f,-111.0f,0f,504.0f,0f,0f,0f,0f,0f,573.0f,700.0f,-913.0f,85.0f,-1192.0f,469.0f,930,-22.081085f,100.0f,62.8122f,-23.84848f,0f,58.607635f ) ;
  }

  @Test
  public void test1141() {
    TestDrivers.surfaceShade(985.0f,-27.0f,0f,0f,125.0f,-762.0f,0f,857.0f,0f,0f,0f,0f,0f,663.0f,-575.0f,221.0f,236.0f,-306.0f,-162.0f,101,100.0f,79.64681f,-92.774124f,-30.18307f,99.99995f,0f ) ;
  }

  @Test
  public void test1142() {
    TestDrivers.surfaceShade(985.0f,-935.0f,0f,-434.0f,0f,0f,0f,643.0f,0f,0f,0f,0f,0f,355.0f,143.0f,-169.0f,-69.0f,-862.0f,-873.0f,7,0f,0f,0f,4.520214f,2.3684738f,0f ) ;
  }

  @Test
  public void test1143() {
    TestDrivers.surfaceShade(986.0f,763.0f,124.0f,0f,954.0f,-741.0f,0f,422.0f,0f,0f,0f,0f,0f,-917.0f,511.0f,-118.0f,774.0f,-538.0f,459.0f,892,46.487476f,35.850296f,-51.98777f,7.203466f,3.1758268f,34.640762f ) ;
  }

  @Test
  public void test1144() {
    TestDrivers.surfaceShade(990.0f,515.0f,0f,0f,732.0f,493.0f,0f,62.0f,0f,0f,0f,0f,0f,545.0f,-821.0f,-598.0f,-43.0f,28.0f,773.0f,659,-97.91802f,100.0f,35.294582f,-39.515762f,51.82978f,0f ) ;
  }

  @Test
  public void test1145() {
    TestDrivers.surfaceShade(-992.0f,-1603.0f,820.0f,0f,419.0f,-1410.0f,0f,-1149.0f,0f,0f,0f,0f,0f,-436.0f,-836.0f,793.0f,0f,0f,0f,571,0.45607963f,-0.38847214f,-0.1587793f,-99.99999f,-65.51666f,-64.48291f ) ;
  }

  @Test
  public void test1146() {
    TestDrivers.surfaceShade(993.0f,-524.0f,0f,0f,1865.0f,-793.0f,0f,0.0f,0f,0f,0f,0f,0f,-59.0f,-454.0f,-278.0f,0f,0f,0f,1010,-0.15559243f,0.85262394f,-0.031580903f,-14.726439f,70.57092f,0f ) ;
  }

  @Test
  public void test1147() {
    TestDrivers.surfaceShade(996.0f,349.0f,0f,0f,979.0f,385.0f,0f,115.0f,0f,0f,0f,0f,0f,-67.0f,423.0f,-546.0f,206.0f,-849.0f,183.0f,-220,68.36564f,-21.68564f,-20.973726f,26.338112f,90.148125f,0f ) ;
  }

  @Test
  public void test1148() {
    TestDrivers.surfaceShade(-999.0f,-839.0f,-997.0f,0f,71.0f,978.0f,0f,5.0f,0f,0f,0f,0f,0f,422.0f,-240.0f,-510.0f,-1151.0f,-1607.0f,-465.0f,-532,-64.61197f,96.44876f,-98.85089f,-68.6615f,-92.66245f,-100.0f ) ;
  }
}
