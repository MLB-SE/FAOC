import org.junit.Test;

public class JpfTargetRayTraceTest {

  @Test
  public void test0() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-0.050916884f,-0.23916543f,0.08366885f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-0.3957519f,0.3967383f,-0.8282386f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,0.65135354f,-0.64880323f,0.007706288f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-0.81686914f,-0.5755849f,0.037773494f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,28.104324f,-37.35214f,86.29014f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,38.69912f,75.85877f,98.61635f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-4.4807998E-4f,-4.864844E-4f,-1.6988243E-4f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-78.17904f,33.475597f,-40.11768f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,8.532674E-6f,3.710958E-5f,-7.2570125E-5f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,9.05989E-8f,3.7246195E-8f,-4.710421E-8f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.rayTrace(100.0f,100.0f,-100.0f,100.0f,-100.0f,-100.0f,-100.0f,-0.8485129f,-0.51859635f,-0.10527916f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.rayTrace(-100.0f,100.0f,100.0f,-24.164486f,-100.0f,61.964123f,100.0f,0.10511754f,0.42068523f,-0.9010961f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.rayTrace(-100.0f,-100.0f,-100.0f,-31.43117f,-97.217545f,-91.507034f,-3.325061f,0.11668476f,0.656884f,-0.2319544f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.rayTrace(100.0f,1.1387104f,74.254486f,100.0f,69.63273f,-100.0f,100.0f,0.49213782f,0.3482191f,0.07728769f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.rayTrace(-100.0f,4.18512f,-100.0f,50.87058f,-100.0f,100.0f,51.69566f,0.04808245f,0.35570323f,0.9333613f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.rayTrace(-100.0f,54.168045f,100.0f,35.327103f,-39.03918f,-63.11336f,99.29563f,-0.14686367f,-0.23380633f,-0.6368298f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.rayTrace(100.0f,-7.386639f,-100.0f,-59.30841f,100.0f,-40.73678f,-50.956593f,0.1338502f,-0.015003279f,-0.20992808f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.rayTrace(-100.0f,97.19276f,83.80607f,32.24278f,-100.0f,85.60481f,100.0f,0.6491395f,-0.049520753f,0.7590557f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.rayTrace(10.126912f,24.909433f,-62.41853f,-6.445952f,-61.00449f,-0.97770625f,-29.132008f,83.75099f,31.843435f,-31.43318f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.rayTrace(-12.006321f,39.406612f,-29.177101f,100.0f,78.86105f,100.0f,75.00336f,-0.6448266f,-0.23918746f,-0.6065463f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.rayTrace(13.269085f,14.132139f,17.280321f,-39.550488f,62.341938f,-62.63998f,7.4153433f,51.033405f,-97.28944f,-43.73443f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.rayTrace(13.364245f,100.0f,-100.0f,91.779724f,10.800355f,86.18525f,-98.25906f,-0.1821292f,-0.049900383f,0.32177123f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.rayTrace(-13.705933f,44.743916f,-19.621603f,25.282629f,-0.18429983f,41.476753f,14.426671f,42.377403f,19.916435f,27.808403f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.rayTrace(-15.20374f,1.2549456f,-57.608475f,49.28546f,8.518295f,20.745836f,9.884333f,37.818047f,-83.64217f,24.135666f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.rayTrace(-15.6554985f,-64.92319f,-34.26984f,62.76992f,-46.29656f,-55.077858f,16.264532f,0.29725274f,0.11833385f,0.6746219f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.rayTrace(-18.090322f,-60.170044f,-63.13777f,76.13951f,27.989222f,9.099775f,-72.098f,53.88215f,35.946045f,-20.540016f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.rayTrace(-18.48067f,100.0f,83.54531f,-100.0f,-15.407299f,100.0f,-9.640624f,0.36877432f,-0.45402688f,-0.81108886f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.rayTrace(-21.780802f,88.82108f,-65.92519f,25.093246f,31.072905f,20.480568f,-63.87253f,36.268494f,-83.0154f,17.213179f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.rayTrace(24.554495f,-10.17014f,5.4536247f,-60.668365f,54.673687f,27.931265f,-61.78081f,-1.2145262E-4f,0.8560339f,-0.16244939f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.rayTrace(-26.196648f,16.624554f,99.99348f,-82.94627f,88.8244f,100.0f,-44.535484f,-0.17321077f,0.8124756f,0.55666995f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.rayTrace(-27.12337f,21.048777f,8.158714f,-33.505875f,-20.679005f,-53.096004f,56.07732f,-95.81312f,92.43074f,41.844414f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.rayTrace(2.8648083f,1.5391518f,-24.592892f,23.696753f,77.26038f,-2.7001698f,-86.414986f,-2.2780807f,98.60879f,63.41758f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.rayTrace(-28.919617f,88.49977f,83.17549f,-57.526176f,-12.20884f,46.8201f,47.219746f,-6.579386f,-4.5610695f,81.78482f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.rayTrace(-30.093678f,7.7886257f,-36.014805f,33.502853f,-9.982564f,-12.590016f,-21.108212f,-0.7006224f,0.2211625f,-0.3151315f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.rayTrace(33.052326f,-100.0f,94.77987f,-2.8965392f,-100.0f,-100.0f,-100.0f,0.18909852f,0.18477802f,-0.38090008f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.rayTrace(-34.34812f,28.207453f,26.751507f,98.63952f,5.986308f,83.11206f,36.439144f,92.6069f,97.57796f,83.310814f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.rayTrace(-3.5998533f,15.357233f,35.029274f,-78.34483f,-17.916145f,-89.62553f,-55.414185f,-20.282742f,-71.33753f,-70.357475f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.rayTrace(47.292065f,50.711674f,-19.50466f,50.035316f,-74.42086f,-81.64913f,13.402648f,60.195633f,51.22626f,-24.434914f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.rayTrace(48.832733f,-18.283592f,-100.0f,-94.329704f,27.389963f,-12.732682f,-100.0f,0.55621725f,-0.16962793f,0.79221296f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.rayTrace(57.906063f,-20.219763f,5.3897495f,57.541718f,96.16915f,30.826004f,36.339382f,-96.16099f,-43.032047f,-52.584427f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.rayTrace(-6.0008802f,100.0f,43.629395f,-98.75502f,100.0f,-100.0f,91.28781f,0.0777444f,-0.95121515f,0.2985726f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.rayTrace(-62.19724f,-84.46939f,-21.205683f,-77.43166f,-57.39542f,-71.89336f,-100.0f,-0.064903f,0.99312717f,-0.09739599f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.rayTrace(70.72509f,-100.0f,-2.3837962f,-78.34972f,-58.935505f,-100.0f,-95.03862f,-0.5163084f,0.052379098f,-0.8547994f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.rayTrace(-74.535484f,13.220951f,0.44307593f,-63.049248f,-82.87614f,49.7951f,79.13046f,2.011136f,6.546309f,2.8430228f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.rayTrace(78.76317f,-14.38067f,99.99999f,-32.705894f,99.98683f,99.99517f,99.99977f,-35.852f,-80.3323f,-14.272271f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.rayTrace(88.56079f,83.63985f,14.902457f,-79.65705f,-35.18715f,61.096252f,-27.036743f,45.502365f,-4.729723f,60.049217f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.rayTrace(91.879845f,-35.80197f,51.723186f,-94.3704f,19.919968f,-96.952774f,38.477898f,-0.2250565f,0.36493176f,0.69353616f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.rayTrace(99.98153f,-100.0f,100.0f,99.99402f,35.663113f,99.98548f,-99.98161f,0.012687207f,-0.72660136f,0.6869421f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.rayTrace(-99.99995f,50.004646f,100.0f,99.999664f,-39.04596f,-18.131247f,59.477844f,-0.9365835f,0.34280846f,0.072757706f ) ;
  }
}
