import org.junit.Test;

public class JpfTargetVector3DNormalizeTest {

  @Test
  public void test0() {
    TestDrivers.vector3DNormalize(-0.32778677f,-0.9003774f,-0.25582948f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.vector3DNormalize(0.36019632f,0.7218854f,0.59088075f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.vector3DNormalize(-0.42973697f,-0.1589196f,-0.88520694f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.vector3DNormalize(-0.6790435f,-0.18419753f,-0.71061325f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.vector3DNormalize(-11.699477f,-52.226345f,-42.005653f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.vector3DNormalize(-1.4594659E-4f,1.6563364E-4f,-3.4960124E-4f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.vector3DNormalize(-1.8630933E-4f,-0.002888f,-0.006864222f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.vector3DNormalize(43.076046f,6.8650823f,36.519123f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.vector3DNormalize(-5.201033E-10f,3.213163E-8f,2.9324676E-8f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.vector3DNormalize(-71.96776f,-78.04963f,-71.90264f ) ;
  }
}
