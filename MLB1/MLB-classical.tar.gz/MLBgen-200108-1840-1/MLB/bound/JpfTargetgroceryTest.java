import org.junit.Test;

public class JpfTargetgroceryTest {

  @Test
  public void test0() {
    bound.grocery.solve(110,73,204,324 ) ;
  }

  @Test
  public void test1() {
    bound.grocery.solve(174,0,0,0 ) ;
  }

  @Test
  public void test2() {
    bound.grocery.solve(177,0,0,0 ) ;
  }

  @Test
  public void test3() {
    bound.grocery.solve(211,312,-761,0 ) ;
  }

  @Test
  public void test4() {
    bound.grocery.solve(265,219,194,33 ) ;
  }

  @Test
  public void test5() {
    bound.grocery.solve(272,951,0,0 ) ;
  }

  @Test
  public void test6() {
    bound.grocery.solve(299,392,122,0 ) ;
  }

  @Test
  public void test7() {
    bound.grocery.solve(338,778,0,0 ) ;
  }

  @Test
  public void test8() {
    bound.grocery.solve(360,287,62,2 ) ;
  }

  @Test
  public void test9() {
    bound.grocery.solve(415,302,248,0 ) ;
  }

  @Test
  public void test10() {
    bound.grocery.solve(456,-341,0,0 ) ;
  }

  @Test
  public void test11() {
    bound.grocery.solve(462,588,0,0 ) ;
  }

  @Test
  public void test12() {
    bound.grocery.solve(46,532,46,499 ) ;
  }

  @Test
  public void test13() {
    bound.grocery.solve(569,381,394,311 ) ;
  }

  @Test
  public void test14() {
    bound.grocery.solve(57,223,424,7 ) ;
  }

  @Test
  public void test15() {
    bound.grocery.solve(655,667,728,0 ) ;
  }

  @Test
  public void test16() {
    bound.grocery.solve(670,106,498,1348 ) ;
  }

  @Test
  public void test17() {
    bound.grocery.solve(692,387,446,425 ) ;
  }

  @Test
  public void test18() {
    bound.grocery.solve(692,698,632,-50 ) ;
  }

  @Test
  public void test19() {
    bound.grocery.solve(-751,0,0,0 ) ;
  }

  @Test
  public void test20() {
    bound.grocery.solve(954,0,0,0 ) ;
  }
}
