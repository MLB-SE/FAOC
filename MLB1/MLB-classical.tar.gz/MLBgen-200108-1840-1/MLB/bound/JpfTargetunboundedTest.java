import org.junit.Test;

public class JpfTargetunboundedTest {

  @Test
  public void test0() {
    bound.unbounded.solve(11,-414 ) ;
  }

  @Test
  public void test1() {
    bound.unbounded.solve(-1144,974 ) ;
  }

  @Test
  public void test2() {
    bound.unbounded.solve(-153,597 ) ;
  }

  @Test
  public void test3() {
    bound.unbounded.solve(378,-864 ) ;
  }
}
