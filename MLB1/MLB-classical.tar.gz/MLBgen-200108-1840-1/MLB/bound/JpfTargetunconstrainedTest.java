import org.junit.Test;

public class JpfTargetunconstrainedTest {

  @Test
  public void test0() {
    bound.unconstrained.solve(10,10,6,4 ) ;
  }

  @Test
  public void test1() {
    bound.unconstrained.solve(10,6,8,-404 ) ;
  }

  @Test
  public void test2() {
    bound.unconstrained.solve(141,0,0,0 ) ;
  }

  @Test
  public void test3() {
    bound.unconstrained.solve(-301,0,0,0 ) ;
  }

  @Test
  public void test4() {
    bound.unconstrained.solve(3,10,382,0 ) ;
  }

  @Test
  public void test5() {
    bound.unconstrained.solve(3,7,-325,0 ) ;
  }

  @Test
  public void test6() {
    bound.unconstrained.solve(3,9,1,10 ) ;
  }

  @Test
  public void test7() {
    bound.unconstrained.solve(5,0,0,0 ) ;
  }

  @Test
  public void test8() {
    bound.unconstrained.solve(5,1,10,408 ) ;
  }

  @Test
  public void test9() {
    bound.unconstrained.solve(5,247,0,0 ) ;
  }

  @Test
  public void test10() {
    bound.unconstrained.solve(6,2,827,0 ) ;
  }

  @Test
  public void test11() {
    bound.unconstrained.solve(7,9,0,0 ) ;
  }

  @Test
  public void test12() {
    bound.unconstrained.solve(8,-243,0,0 ) ;
  }

  @Test
  public void test13() {
    bound.unconstrained.solve(9,2,10,0 ) ;
  }

  @Test
  public void test14() {
    bound.unconstrained.solve(9,3,7,9 ) ;
  }

  @Test
  public void test15() {
    bound.unconstrained.solve(9,3,8,473 ) ;
  }

  @Test
  public void test16() {
    bound.unconstrained.solve(9,419,0,0 ) ;
  }

  @Test
  public void test17() {
    bound.unconstrained.solve(948,0,0,0 ) ;
  }
}
