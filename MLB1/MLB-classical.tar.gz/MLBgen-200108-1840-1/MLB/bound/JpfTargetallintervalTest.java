import org.junit.Test;

public class JpfTargetallintervalTest {

  @Test
  public void test0() {
    bound.allinterval.solve(108,0,0,0 ) ;
  }

  @Test
  public void test1() {
    bound.allinterval.solve(1,2,4,3 ) ;
  }

  @Test
  public void test2() {
    bound.allinterval.solve(2,152,0,0 ) ;
  }

  @Test
  public void test3() {
    bound.allinterval.solve(2,2,2,3 ) ;
  }

  @Test
  public void test4() {
    bound.allinterval.solve(2,4,-644,0 ) ;
  }

  @Test
  public void test5() {
    bound.allinterval.solve(3,0,0,0 ) ;
  }

  @Test
  public void test6() {
    bound.allinterval.solve(3,1,3,696 ) ;
  }

  @Test
  public void test7() {
    bound.allinterval.solve(3,3,1,905 ) ;
  }

  @Test
  public void test8() {
    bound.allinterval.solve(3,4,2,0 ) ;
  }

  @Test
  public void test9() {
    bound.allinterval.solve(3,715,0,0 ) ;
  }

  @Test
  public void test10() {
    bound.allinterval.solve(4,1,2,-1556 ) ;
  }

  @Test
  public void test11() {
    bound.allinterval.solve(4,-190,0,0 ) ;
  }

  @Test
  public void test12() {
    bound.allinterval.solve(4,2,196,0 ) ;
  }

  @Test
  public void test13() {
    bound.allinterval.solve(4,2,3,1 ) ;
  }

  @Test
  public void test14() {
    bound.allinterval.solve(4,3,0,0 ) ;
  }

  @Test
  public void test15() {
    bound.allinterval.solve(4,3,835,0 ) ;
  }

  @Test
  public void test16() {
    bound.allinterval.solve(866,0,0,0 ) ;
  }

  @Test
  public void test17() {
    bound.allinterval.solve(-875,0,0,0 ) ;
  }
}
