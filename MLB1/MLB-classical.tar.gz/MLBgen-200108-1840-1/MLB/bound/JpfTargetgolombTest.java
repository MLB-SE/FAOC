import org.junit.Test;

public class JpfTargetgolombTest {

  @Test
  public void test0() {
    bound.golomb.solve(0,0,0 ) ;
  }

  @Test
  public void test1() {
    bound.golomb.solve(0,0,1 ) ;
  }

  @Test
  public void test2() {
    bound.golomb.solve(0,0,3 ) ;
  }

  @Test
  public void test3() {
    bound.golomb.solve(0,1,0 ) ;
  }

  @Test
  public void test4() {
    bound.golomb.solve(0,3,4 ) ;
  }

  @Test
  public void test5() {
    bound.golomb.solve(0,5,5 ) ;
  }

  @Test
  public void test6() {
    bound.golomb.solve(1,0,1 ) ;
  }

  @Test
  public void test7() {
    bound.golomb.solve(1,1,400 ) ;
  }

  @Test
  public void test8() {
    bound.golomb.solve(1,2,3 ) ;
  }

  @Test
  public void test9() {
    bound.golomb.solve(1,2,5 ) ;
  }

  @Test
  public void test10() {
    bound.golomb.solve(1,3,5 ) ;
  }

  @Test
  public void test11() {
    bound.golomb.solve(2,4,526 ) ;
  }

  @Test
  public void test12() {
    bound.golomb.solve(3,0,0 ) ;
  }

  @Test
  public void test13() {
    bound.golomb.solve(3,4,0 ) ;
  }

  @Test
  public void test14() {
    bound.golomb.solve(44,0,0 ) ;
  }

  @Test
  public void test15() {
    bound.golomb.solve(4,5,-760 ) ;
  }

  @Test
  public void test16() {
    bound.golomb.solve(4,6,5 ) ;
  }

  @Test
  public void test17() {
    bound.golomb.solve(5,1,5 ) ;
  }

  @Test
  public void test18() {
    bound.golomb.solve(5,-263,0 ) ;
  }

  @Test
  public void test19() {
    bound.golomb.solve(5,6,0 ) ;
  }

  @Test
  public void test20() {
    bound.golomb.solve(6,190,0 ) ;
  }

  @Test
  public void test21() {
    bound.golomb.solve(6,92,0 ) ;
  }

  @Test
  public void test22() {
    bound.golomb.solve(822,0,0 ) ;
  }

  @Test
  public void test23() {
    bound.golomb.solve(-904,0,0 ) ;
  }
}
