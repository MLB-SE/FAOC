import org.junit.Test;

public class JpfTargetCollision2Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision2(-243,453,-215,360 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision2(-827,-554,-681,-656 ) ;
  }
}
