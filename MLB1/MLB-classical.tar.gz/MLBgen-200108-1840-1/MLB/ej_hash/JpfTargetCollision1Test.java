import org.junit.Test;

public class JpfTargetCollision1Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision1(460,-1867,252,520,-5,314 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision1(-509,197,-569,602,832,-753 ) ;
  }
}
