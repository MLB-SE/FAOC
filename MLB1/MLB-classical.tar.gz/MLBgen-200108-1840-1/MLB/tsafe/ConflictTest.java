import org.junit.Test;

public class ConflictTest {

  @Test
  public void test0() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,0.0 ) ;
  }

  @Test
  public void test2() {
    tsafe.Conflict.snippet(0.0,0.0,0,0,0,0,-23.43088878964886 ) ;
  }

  @Test
  public void test3() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,-100.0 ) ;
  }

  @Test
  public void test4() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,-3.24E-321 ) ;
  }

  @Test
  public void test5() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,-5.589179484929318 ) ;
  }

  @Test
  public void test6() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,73.28281518250684 ) ;
  }

  @Test
  public void test7() {
    tsafe.Conflict.snippet(0.0,-0.4510177691523438,0,0,0,0,-43.26189635845843 ) ;
  }

  @Test
  public void test8() {
    tsafe.Conflict.snippet(0.007480259826940727,-94.40325415486969,275.397276406209,-987.7817931536106,-151.26563150103988,-14.782025132582824,0.673474908998493 ) ;
  }

  @Test
  public void test9() {
    tsafe.Conflict.snippet(0.0,-100.0,73.80253106234322,1.4800838932504858,1.3451214327860828,-100.0,-99.99999960831538 ) ;
  }

  @Test
  public void test10() {
    tsafe.Conflict.snippet(0.0,105.22200999371674,81.22410512386804,-0.2117982888885792,1.482005815167971,-16.776456537898937,-91.13622275024767 ) ;
  }

  @Test
  public void test11() {
    tsafe.Conflict.snippet(0.0,114.34147063312714,124.05419509726238,-1004.3126988618823,66.71367238307599,136.52853958999586,-16.475466371885105 ) ;
  }

  @Test
  public void test12() {
    tsafe.Conflict.snippet(0.0,-18.005064932554887,-5.352034908689131,-46.34120493099033,45.329597982193945,-13.277003421126047,62.20056192107391 ) ;
  }

  @Test
  public void test13() {
    tsafe.Conflict.snippet(0.0,23.417423188493803,-42.63870194219267,0,0,0,-35.845923332676506 ) ;
  }

  @Test
  public void test14() {
    tsafe.Conflict.snippet(0.0,-45.61962716010554,23.738316222241593,-2.0994880149956714,25.41269563448739,39.83305250334615,-1.3588119100982503 ) ;
  }

  @Test
  public void test15() {
    tsafe.Conflict.snippet(0.0,-97.56191778712085,2.615559669762542E-22,0,0,0,-90.0 ) ;
  }

  @Test
  public void test16() {
    tsafe.Conflict.snippet(100.0,0.0,0,0,0,0,-32.98964476816061 ) ;
  }

  @Test
  public void test17() {
    tsafe.Conflict.snippet(-100.0,0,0,0,0,0,-4.6E-322 ) ;
  }

  @Test
  public void test18() {
    tsafe.Conflict.snippet(-100.0,-20.941500652454007,-4.574823251208577E-17,0,0,0,-90.0 ) ;
  }

  @Test
  public void test19() {
    tsafe.Conflict.snippet(-104.68518740520513,-72.06001321021421,-133.45517291281072,-100.0,1052.9227120283067,-100.0,-56.32921454685109 ) ;
  }

  @Test
  public void test20() {
    tsafe.Conflict.snippet(110.84790868370295,213.83716525162572,-145.34565978380516,-272.87506566270093,958.7548567233694,102.79235177975791,163.91664083191222 ) ;
  }

  @Test
  public void test21() {
    tsafe.Conflict.snippet(-12.911069990609974,44.85077055145217,-91.73407095069737,0,0,0,21.18119794127115 ) ;
  }

  @Test
  public void test22() {
    tsafe.Conflict.snippet(-1.53E-322,0,0,0,0,0,2.6259305467586667 ) ;
  }

  @Test
  public void test23() {
    tsafe.Conflict.snippet(15.446187469131488,0,0,0,0,0,19.303634472398173 ) ;
  }

  @Test
  public void test24() {
    tsafe.Conflict.snippet(-16.531311008190425,-77.1548147911655,-84.50396721752878,1.6617803860277531,-0.9305855255508624,33.88113018896989,22.614190829157263 ) ;
  }

  @Test
  public void test25() {
    tsafe.Conflict.snippet(-16.900552565013726,55.95925258207558,-91.78907377960033,-15.134883000012536,21.606461948756134,-35.092792896440244,-48.00712559078788 ) ;
  }

  @Test
  public void test26() {
    tsafe.Conflict.snippet(-1.8E-322,0,0,0,0,0,-66.08704046855672 ) ;
  }

  @Test
  public void test27() {
    tsafe.Conflict.snippet(-2.220446049250313E-16,0,0,0,0,0,-7.179388409295655 ) ;
  }

  @Test
  public void test28() {
    tsafe.Conflict.snippet(24.99061887696861,0,0,0,0,0,-4.980245736182184 ) ;
  }

  @Test
  public void test29() {
    tsafe.Conflict.snippet(2.57E-322,0,0,0,0,0,-8.653770063278513 ) ;
  }

  @Test
  public void test30() {
    tsafe.Conflict.snippet(-28.874734797090824,79.41229035114836,0,0,0,0,19.476161628994618 ) ;
  }

  @Test
  public void test31() {
    tsafe.Conflict.snippet(30.658812793443094,68.6227798350883,-77.24589424542054,0.46275627322221435,-0.2843403059594086,100.0,-54.08025877680376 ) ;
  }

  @Test
  public void test32() {
    tsafe.Conflict.snippet(-31.624968979396293,14.540445233850477,42.213684035683954,-1.094959405683716,0.8630481435301718,33.27230968424102,94.96118690547328 ) ;
  }

  @Test
  public void test33() {
    tsafe.Conflict.snippet(3.2379E-319,0,0,0,0,0,-60.11459253371656 ) ;
  }

  @Test
  public void test34() {
    tsafe.Conflict.snippet(34.102051433462975,73.43024061118732,-1.2577529258558968,35.126651901787795,-38.217590783984704,-81.64059820870035,-9.713025386056444 ) ;
  }

  @Test
  public void test35() {
    tsafe.Conflict.snippet(34.708343483107654,-71.3891792028218,52.676236892879956,0,0,0,85.66904346654783 ) ;
  }

  @Test
  public void test36() {
    tsafe.Conflict.snippet(42.296671877119394,0,0,0,0,0,0.0 ) ;
  }

  @Test
  public void test37() {
    tsafe.Conflict.snippet(-42.954499204872306,184.9748230641141,-23.315125763202364,-969.8191155878212,242.9640263711131,-331.993051533065,195.2054402344147 ) ;
  }

  @Test
  public void test38() {
    tsafe.Conflict.snippet(43.360996275552054,55.85602602412408,0,0,0,0,42.64772684070641 ) ;
  }

  @Test
  public void test39() {
    tsafe.Conflict.snippet(54.33039706428503,100.0,-9.93295047021715E-17,0,0,0,90.0 ) ;
  }

  @Test
  public void test40() {
    tsafe.Conflict.snippet(-54.343084086100156,0,0,0,0,0,53.432899440292886 ) ;
  }

  @Test
  public void test41() {
    tsafe.Conflict.snippet(56.59748971513548,0,0,0,0,0,5.06E-321 ) ;
  }

  @Test
  public void test42() {
    tsafe.Conflict.snippet(-6.162975822039155E-33,0,0,0,0,0,-3.4037731729307836 ) ;
  }

  @Test
  public void test43() {
    tsafe.Conflict.snippet(65.30082647983016,0,0,0,0,0,61.6150659177367 ) ;
  }

  @Test
  public void test44() {
    tsafe.Conflict.snippet(-6.593174425670227,0,0,0,0,0,-15.329465151687401 ) ;
  }

  @Test
  public void test45() {
    tsafe.Conflict.snippet(66.091444870374,-37.70588418767649,-65.86942428283669,4.908211818218362,-94.82444670445314,-52.00904636776416,-7.896711943710287 ) ;
  }

  @Test
  public void test46() {
    tsafe.Conflict.snippet(68.22259292332612,-74.94437526968281,2.2431882002703105,986.7571693207775,-207.17782239620615,-26.852917987770184,-28.419322283624155 ) ;
  }

  @Test
  public void test47() {
    tsafe.Conflict.snippet(-68.42947443559629,-19.464254337971653,-2.486194323591988,7.25344035005142,10.90312646246241,95.33524617507365,-69.72791410455665 ) ;
  }

  @Test
  public void test48() {
    tsafe.Conflict.snippet(71.3516682879548,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test49() {
    tsafe.Conflict.snippet(-73.04681067014997,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test50() {
    tsafe.Conflict.snippet(-84.26415724097345,0.0,0,0,0,0,100.0 ) ;
  }

  @Test
  public void test51() {
    tsafe.Conflict.snippet(84.27830308222505,-36.397010157744624,-157.7953527475573,-1.4832250755343162,-1.4239962903001242,61.86440933372427,-18.782412457455763 ) ;
  }

  @Test
  public void test52() {
    tsafe.Conflict.snippet(-91.79631195725926,0,0,0,0,0,63.14130135141451 ) ;
  }

  @Test
  public void test53() {
    tsafe.Conflict.snippet(-99.96664473982328,0,0,0,0,0,0.0 ) ;
  }
}
