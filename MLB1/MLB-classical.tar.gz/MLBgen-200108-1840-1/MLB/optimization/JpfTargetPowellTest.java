import org.junit.Test;

public class JpfTargetPowellTest {

  @Test
  public void test0() {
    Optimization.powell(-0.5044975350907208,-1.9821702395833826E-4 ) ;
  }

  @Test
  public void test1() {
    Optimization.powell(1.3174438825905104E-4,0.7590456134144283 ) ;
  }

  @Test
  public void test2() {
    Optimization.powell(-2.9571366864334843E-6,-33.816495686104744 ) ;
  }

  @Test
  public void test3() {
    Optimization.powell(-34.116549022108586,43.49744561168188 ) ;
  }

  @Test
  public void test4() {
    Optimization.powell(-53.494747251166984,-77.31200702074412 ) ;
  }

  @Test
  public void test5() {
    Optimization.powell(8.211472263248746,1.2178084123545038E-5 ) ;
  }
}
