import org.junit.Test;

public class JpfTargetHelicalValleyTest {

  @Test
  public void test0() {
    Optimization.theta(0.007079917713055264,0 ) ;
  }

  @Test
  public void test1() {
    Optimization.theta(-0.017087702509098857,179.320368192388 ) ;
  }

  @Test
  public void test2() {
    Optimization.theta(-0.13403803096087513,989.6764137085212 ) ;
  }

  @Test
  public void test3() {
    Optimization.theta(100.0,-100.0 ) ;
  }

  @Test
  public void test4() {
    Optimization.theta(100.0,100.0 ) ;
  }

  @Test
  public void test5() {
    Optimization.theta(100.0,2.071088442862934E-28 ) ;
  }

  @Test
  public void test6() {
    Optimization.theta(1.0967282755827341,0 ) ;
  }

  @Test
  public void test7() {
    Optimization.theta(11.861011081098425,-90.20664104037871 ) ;
  }

  @Test
  public void test8() {
    Optimization.theta(-1.3612922030581842,67.80925941031927 ) ;
  }

  @Test
  public void test9() {
    Optimization.theta(15.791433678245795,-90.43331547198433 ) ;
  }

  @Test
  public void test10() {
    Optimization.theta(1.734723475976807E-18,0 ) ;
  }

  @Test
  public void test11() {
    Optimization.theta(-19.730197470821963,0 ) ;
  }

  @Test
  public void test12() {
    Optimization.theta(-21.318462855008775,-58.398101418056015 ) ;
  }

  @Test
  public void test13() {
    Optimization.theta(-22.561581668101894,0 ) ;
  }

  @Test
  public void test14() {
    Optimization.theta(2.4463681356457556,0 ) ;
  }

  @Test
  public void test15() {
    Optimization.theta(-2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test16() {
    Optimization.theta(-27.045614268893594,40.053006368970124 ) ;
  }

  @Test
  public void test17() {
    Optimization.theta(-36.42688902284299,-53.20106920010523 ) ;
  }

  @Test
  public void test18() {
    Optimization.theta(3.9356454350133845,-17.555627974036497 ) ;
  }

  @Test
  public void test19() {
    Optimization.theta(-4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test20() {
    Optimization.theta(-55.21828203589869,0 ) ;
  }

  @Test
  public void test21() {
    Optimization.theta(-62.44478894046719,14.88222476379029 ) ;
  }

  @Test
  public void test22() {
    Optimization.theta(62.93447406226562,58.404754059392076 ) ;
  }

  @Test
  public void test23() {
    Optimization.theta(68.0070761060152,57.01326805052054 ) ;
  }

  @Test
  public void test24() {
    Optimization.theta(-70.94809064151744,66.39860927096494 ) ;
  }

  @Test
  public void test25() {
    Optimization.theta(-74.97701459133917,-98.80061507400421 ) ;
  }

  @Test
  public void test26() {
    Optimization.theta(81.24992048054469,3.5233327399756362 ) ;
  }

  @Test
  public void test27() {
    Optimization.theta(81.43924515263487,0 ) ;
  }
}
