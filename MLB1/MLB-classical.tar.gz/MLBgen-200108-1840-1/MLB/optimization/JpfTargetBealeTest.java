import org.junit.Test;

public class JpfTargetBealeTest {

  @Test
  public void test0() {
    Optimization.beale(0.07836828267282243,-18.140396456846048 ) ;
  }

  @Test
  public void test1() {
    Optimization.beale(-10.278522529669502,-24.62670162404315 ) ;
  }

  @Test
  public void test2() {
    Optimization.beale(-73.80002979710063,94.9926323950315 ) ;
  }
}
