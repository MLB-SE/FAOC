import org.junit.Test;

public class JpfTargetFreudensteinRothTest {

  @Test
  public void test0() {
    Optimization.freudensteinRoth(16.137837174498316,3.1768350880413863 ) ;
  }

  @Test
  public void test1() {
    Optimization.freudensteinRoth(23.023294339261085,2.3837362709517578 ) ;
  }

  @Test
  public void test2() {
    Optimization.freudensteinRoth(-24.205992458113727,-49.97166126750601 ) ;
  }
}
