import org.junit.Test;

public class JpfTargetRosenbrockTest {

  @Test
  public void test0() {
    Optimization.rosenbrock(4.286350311699364,18.372716740476715 ) ;
  }

  @Test
  public void test1() {
    Optimization.rosenbrock(78.91336801273388,-76.07807769852548 ) ;
  }

  @Test
  public void test2() {
    Optimization.rosenbrock(9.861580789975779,97.25194989539843 ) ;
  }
}
