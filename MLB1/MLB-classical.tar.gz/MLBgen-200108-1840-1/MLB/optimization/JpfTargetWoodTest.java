import org.junit.Test;

public class JpfTargetWoodTest {

  @Test
  public void test0() {
    Optimization.wood(1.0,1.0,0,0 ) ;
  }

  @Test
  public void test1() {
    Optimization.wood(1.0,1.0000000000000004,1.0,1.0 ) ;
  }

  @Test
  public void test2() {
    Optimization.wood(1.0,1.0,-0.7746664459883128,46.43314875052465 ) ;
  }

  @Test
  public void test3() {
    Optimization.wood(1.0,1.0,1.0,0.9999999999999998 ) ;
  }

  @Test
  public void test4() {
    Optimization.wood(1.0,1.0,1.0,1.0 ) ;
  }

  @Test
  public void test5() {
    Optimization.wood(1.0,1.0,3.8099271370237817,14.51554478943023 ) ;
  }

  @Test
  public void test6() {
    Optimization.wood(1.0,1.0,-4.289616630664691,18.400810838075095 ) ;
  }

  @Test
  public void test7() {
    Optimization.wood(1.0,1.0,-4.4769948047340415,20.043482481615598 ) ;
  }

  @Test
  public void test8() {
    Optimization.wood(1.0,1.0,-94.58715463756026,-63.05342476493545 ) ;
  }

  @Test
  public void test9() {
    Optimization.wood(1.0,56.838599716043184,1.0,-54.838599716043184 ) ;
  }

  @Test
  public void test10() {
    Optimization.wood(3.474516151386979,12.072262486248984,0,0 ) ;
  }

  @Test
  public void test11() {
    Optimization.wood(-3.6866119650282907,13.591107780689756,0,0 ) ;
  }

  @Test
  public void test12() {
    Optimization.wood(43.62270684779031,39.46327064212568,0,0 ) ;
  }

  @Test
  public void test13() {
    Optimization.wood(-5.932943989965381,73.97063054867604,0,0 ) ;
  }

  @Test
  public void test14() {
    Optimization.wood(7.109948067533622,50.55136152302509,0,0 ) ;
  }
}
