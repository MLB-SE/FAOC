import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(40.13318549344348,9.867075529948039,50.000261023391516 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(-59.99081627980682,-21.0966904718575,-49.58176295426979 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(96.07940209205722,-24.095269697311238,-94.63227633473666 ) ;
  }
}
