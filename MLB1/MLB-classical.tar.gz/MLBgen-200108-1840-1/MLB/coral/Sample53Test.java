import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark53(11.73242983033262,40.723262105096325,-21.33680517498415 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(21.11284290583599,94.20930221435302,21.895771374164184 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(24.506604886668867,95.96626978875628,19.686902199589753 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark53(30.554102611390828,2.7614350979723072,81.34894936680469 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark53(32.77671610545516,-47.3647135332554,-51.27075615427278 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark53(4.489586199501858,80.83674515762942,7.408488724799028 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark53(68.31468438776349,-93.314981143666,85.79550013149512 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark53(77.77398702160937,78.53997627438784,81.93259923730031 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark53(87.20292823621158,71.83059791171704,88.15410720290987 ) ;
  }
}
