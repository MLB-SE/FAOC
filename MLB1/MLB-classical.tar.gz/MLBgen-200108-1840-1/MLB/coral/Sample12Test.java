import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(0.21475128899135143,0.5810898495679453,-14.58076280812628,5.721659735032162 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(0.5304645222143023,0.12881400433357726,45.83449363751288,27.398584589581645 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(0.9523484722494686,-0.9078571342270082,-100.0,93.62828586288964 ) ;
  }
}
