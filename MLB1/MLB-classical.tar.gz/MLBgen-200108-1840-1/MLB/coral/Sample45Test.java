import org.junit.Test;

public class Sample45Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark45(0.0,-18.00351908224084,42.895392069569255 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark45(-11.831602266864419,-169.657020546055,48.77223709479529 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark45(1.3552527156068805E-20,1.0000000000000004,1.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark45(3.552713678800501E-15,1.0000000008671026,0.9879596642759949 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark45(39.99778470923886,17.544283812840362,20.445332493481388 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark45(44.148746848732344,25.463339323852225,53.26915721250185 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark45(-446.9365937166815,-249.08801930077573,44.67531518474817 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark45(-46.06802129050642,-93.1505450242852,25.82145235319338 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark45(66.93240703449595,69.18139982031644,42.41757930081002 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark45(68.69085304132005,72.6482598126612,69.09410107445319 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark45(69.18357558281062,-75.86228167483378,65.91102148357433 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark45(84.80068882675133,-2.971888636782637,17.601387834921596 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark45(86.07594221407149,88.07594221407149,67.4445632610555 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark45(88.13237059594667,49.635165624119395,78.89503947579061 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark45(93.23825032271132,1.0,33.600423140996476 ) ;
  }
}
