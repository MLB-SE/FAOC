import org.junit.Test;

public class Sample37Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark37(-4.631774037576378,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark37(-50.26548177305454,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark37(-61.7314424520071,96.73683652567149,86.14110671792957 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark37(75.40827219541853,-72.58938155905952,79.83965130627914 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark37(-86.47683539927651,-46.25931812617645,20.18664423172396 ) ;
  }
}
