import org.junit.Test;

public class Sample04Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark04(-670.628618651575 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark04(7.960223093637154 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark04(-98.6804029836095 ) ;
  }
}
