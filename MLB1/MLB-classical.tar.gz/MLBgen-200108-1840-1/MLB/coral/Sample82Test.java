import org.junit.Test;

public class Sample82Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark82(0.1287820001832948,7.765060323466827E-4 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark82(20.052674228886588,4.986866033855298E-6 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark82(34.700961167043886,-28.097817470070567 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark82(-4.634457470238885E-6,-21.577498691523317 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark82(-4.91599882337507,-2.03417461217668E-5 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark82(95.80708474777876,39.729173465505994 ) ;
  }
}
