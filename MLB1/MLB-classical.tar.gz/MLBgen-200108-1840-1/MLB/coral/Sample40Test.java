import org.junit.Test;

public class Sample40Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark40(-2.372132725597993,63.52181754793139 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark40(52.035214031051,7.555863529482792 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark40(5.370531558048768,23.472077657948958 ) ;
  }
}
