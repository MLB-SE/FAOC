import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(0.39833772191400385,-77.2838509838019,67.53226090664856,11.048790356738976 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(-0.4064537773634811,97.15562682181937,-21.8882385254376,-78.98501088234393 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(0.9883870739958951,0.5948076354038991,-15.318027878238142,-100.0 ) ;
  }
}
