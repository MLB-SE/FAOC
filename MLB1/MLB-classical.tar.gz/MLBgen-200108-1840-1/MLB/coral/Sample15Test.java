import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(0.13261339306680497,82.45261561013308,-99.49399649660808,53.04911838373411 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(-0.302309144832023,76.85519998019615,-74.98046600193243,-21.36734231267876 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(0.802475783376217,46.1893606862619,1.2591184623959908,-50.056495079414844 ) ;
  }
}
