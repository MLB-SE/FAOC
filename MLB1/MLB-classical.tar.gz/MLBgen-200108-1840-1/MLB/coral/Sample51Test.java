import org.junit.Test;

public class Sample51Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark51(0.0017359569432738675,0.0013266509928973867 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark51(0.5511435296689309,30.721132608580888 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark51(1.0857655405621644E-7,3.09199589692456E-7 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark51(1.1060860613378662,13.121416422693173 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark51(1.2084211321768492,43.03231546287631 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark51(12.14033011147302,23.16105213685782 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark51(21.58974543986605,23.445729475949847 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark51(24.33459124233795,43.77541042901305 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark51(3.521829389800729,30.753538792997574 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark51(65.30545949808953,76.06259709269938 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark51(9.083776615327857,40.91622338467214 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark51(96.58546065244559,95.05511052104174 ) ;
  }
}
