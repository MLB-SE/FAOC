import org.junit.Test;

public class Sample72Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark72(-100.0,100.0,-95.43583777593784,67.1615038936297,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark72(13.699608578639015,-62.26782274111675,84.38346753921027,62.522053041419696,-1.48166645476469,-64.31351952656055,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark72(1.4492074535979498,-30.349962757291465,-91.99477182174421,78.19089912415532,35.319294801803835,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark72(-23.779406161770524,-2.73872606633914,-65.25416310364238,60.50682411352503,30.047711837904416,80.20657186094084,41.82280695818034 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark72(-3.7674809855683833,-31.79280330264274,56.03074372931053,0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark72(-4.037441482647623,-96.35165127086833,64.19397856458917,0,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark72(-40.45612934319749,-63.68031858780514,0,0,0,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark72(-4.385572452730017,-100.0,72.62736094576084,100.0,4.278481706314508,-32.778648928020246,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark72(51.467249718750764,-79.7335367719079,-56.177784908538484,-33.84240472998618,-88.77956891387697,-90.2786039854797,98.60373184730301 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark72(58.45850826330155,-86.93328328119668,55.41167029704482,-44.61364718701244,0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark72(-61.31779263199053,76.8554216186916,32.82881567298608,-75.76720244354193,-95.40410629051368,68.13951529710792,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark72(63.90788528940311,-3.005957454286289,-6.89326335212273,-96.67425585190183,38.405862851204944,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark72(-67.14042664696207,25.983482353041875,-100.0,-30.960757157312795,56.650498546444226,100.0,100.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark72(-7.550991188040527,-34.57220208659821,0,0,0,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark72(8.217132984418793,-86.030646623275,0,0,0,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark72(84.26049477096726,-5.743274995394072,65.91900621085237,-71.02273368635319,42.74839980404505,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark72(94.70957932837247,100.0,100.0,0,0,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark72(97.16722217217878,62.48025968345618,-38.13624810470713,60.540982387866876,0,0,0 ) ;
  }
}
