import org.junit.Test;

public class Sample25Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark25(-100.0,-100.0,-99.99999820332246,81.33351212886159,96.51436990380813 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark25(-30.661237379748997,75.77618736075192,82.1049139989608,-38.69976488951159,13.73821837524818 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark25(-42.21133840366565,7.9162205942032156,-100.0,0,-69.23951635474765 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark25(-65.19550070096456,-30.570620265156307,-83.94682902529662,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark25(-67.31735461964523,-72.86237332171739,70.12475008270806,5.379971810808008,57.62551576728405 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark25(76.18067935815944,-89.21301993047443,-73.20786248980312,0,-40.49054598431563 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark25(85.19215550947911,-16.739862385252707,0.05690527513360166,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark25(-86.90642532065658,-18.654038475462478,-69.29085201030327,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark25(-87.79463042972165,63.64042897498271,91.0117037123322,-63.53108837537322,52.04379816831053 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark25(-99.02013730094367,98.27100643539316,-77.80375200163209,-69.68543956859014,64.3602529745936 ) ;
  }
}
