import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(38.54292580229398,39.77359856662696,84.23352901436246 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(-543.2345021731355,-78.80923545558215,-605.4372655820426 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(76.90317057059235,-2.2391829115188813,-39.36803005280232 ) ;
  }
}
