import org.junit.Test;

public class Sample84Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark84(0.8381681447992465,5.124864731813261,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark84(1.0,0.9999999999999998,1.0,1.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.000000000000009,1.0,0.9999999999999911 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,-0.5263055122461253,0.2769974922206564 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,-100.0,-100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,1.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,1.0000000000000004 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,3.1676893405823208,10.034255758438858 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,-6.93617619757281,51.483487592701586 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,-9.011573039349418,81.20844864352931 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark84(-2.1529828812330707,4.635335286882655,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark84(7.014132987778172,49.19806157023795,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark84(76.7998503066637,30.984813952371212,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark84(-9.829147844699596,96.61214735296272,0,0 ) ;
  }
}
