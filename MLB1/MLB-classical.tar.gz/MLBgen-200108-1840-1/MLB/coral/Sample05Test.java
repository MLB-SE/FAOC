import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark05(-1.0220190902461248,87.39246821894942,-21.700802509453442 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(46.240122115950015,-44.69454122760816,-33.93375806822041 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(-92.56675905763558,13.667589073838897,24.060842836848934 ) ;
  }
}
