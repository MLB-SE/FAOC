import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,-7.349334563713555 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,82.64327552006156 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(0.6609782970301552,1.9744607838060713,-46.717203984875496,49.35264362448185 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(13.312047853749895,1.5470650670820287,-46.64688187874225,4.606623835774798 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(20.610538265510357,63.57662779387917,82.44873738656875,4.981760111696218 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(21.360279805991272,-19.748407474379324,-91.27157571050957,70.77160321046486 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(22.733727849384337,75.42939183423479,52.72322757340103,47.465300990125144 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(25.26401803133118,1.0018173306012699,-28.383104701818354,-39.69032105717012 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(33.1251534517279,86.17193774905479,24.54703064853932,34.75806260109394 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(41.34380152479798,5.471962009904146,50.00538083123004,51.02495570705179 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(48.50330260971572,49.193621402370525,87.17094718669404,26.660201438392477 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(55.712149003936744,0.0,26.734415608152883,24.372007721968174 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(62.96736273838383,-61.66542322317565,-87.28745909441,-67.04417376905027 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(66.14534884974427,12.452774382054457,86.14052641950968,81.50710849623744 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(6.772839261848347,23.7124121479211,57.38262320630005,-7.4794260894015565 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(72.36378661047084,28.35054065754619,61.02606776718335,-51.07750961615256 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(73.34496790127619,-21.895141672520978,43.09170303126808,8.358123197487132 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(75.67332924120143,-100.0,100.0,-0.7567332924120143 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(76.24525980773257,92.29699656640821,3.5647667253853683,84.57547114202265 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(-7.666988128610484,-51.05901544983353,50.34592777314515,-41.48885274781138 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(76.95751307283197,65.68377122598682,80.59629596735815,-13.44575408514828 ) ;
  }
}
