import org.junit.Test;

public class Sample58Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark58(0,0.36704623003920744,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark58(0.4509664888271774,-61.69226281788418,-24.7823963969873,-29.376167192463924,-18.786017091010663 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark58(0,88.258291375972,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark58(20.182586396829727,32.50240100379477,-51.976585052139576,81.82854546397787,55.413329244918835 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark58(2.4661678602727473,31.36294092612572,-34.53031805749886,2.6445171157103147,33.545369444883846 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark58(39.991991212978434,53.91136352399221,26.876509092350105,47.71806351984594,60.104196809843245 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark58(40.997118488976106,15.053542161268982,-56.417238147559125,38.24673469872217,36.75090561841945 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark58(6.060339603525892,37.37033680892177,-43.93234259406316,90.60322136138504,-20.362937514587614 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark58(73.18437593293706,50.458709552426,-39.100319208327974,24.282197633715015,79.09839279427874 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark58(-73.6656849739435,-9.457861000896656,5.826966588770816,-54.46637077479279,58.261107939414615 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark58(73.80539598921217,12.162429686107927,-85.74955887298015,98.63167218285597,12.338964378195527 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark58(84.4650835527252,3.0565205752566555,-88.01807028620935,84.32296763266093,10.49395203542674 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark58(87.26801925920992,-79.4580110253844,56.71428727648373,-87.43790630518995,38.654628736043065 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark58(96.67412566632129,2.5511066000294136,44.493916453053885,-79.03107676940857,50.670633620318085 ) ;
  }
}
