import org.junit.Test;

public class Sample54Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark54(12.530018131979404,-7.210076799327354,-44.21516859538927 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark54(24.38795613055099,-37.195869290043674,-43.5518433174779 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark54(25.66968493080431,-48.691293558825734,-42.35920225343352 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark54(5.0390538652019075,-77.80761925572332,5.552384526925294 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark54(75.08955516113744,77.88456908855011,-43.69857644658441 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark54(7.925477269042375,-83.97676363382156,39.55796097261387 ) ;
  }
}
