import org.junit.Test;

public class Sample26Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark26(-100.0,100.0,-37.20279663072848,-57.44694439294955,-46.89813287570853 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark26(40.49172060228517,65.1572561921432,100.0,0,-32.925140091839644 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark26(-53.214590050501975,96.28886695999353,-89.10895110257833,-50.87011743284824,43.85490288484149 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark26(-57.766538879935545,-70.11993935008995,-30.632305873912784,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark26(-60.533686273127586,100.0,-87.32814692280598,9.531537898466992,100.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark26(-70.62178263172017,45.330207736855726,-6.68334812061353,0,68.4174868210709 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark26(-78.87893124463328,66.42091306452639,-15.069961425056349,-43.75474800130736,-21.369291046370947 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark26(-84.20258667138744,-42.0087372335096,-57.240907309669225,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark26(89.5724208811082,72.40836878104054,-91.94195307019623,-73.97359716685814,-83.63908643209821 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark26(95.71649013630551,-74.2410403579091,-92.50872127617234,0,0 ) ;
  }
}
