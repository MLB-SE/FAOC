import org.junit.Test;

public class Sample44Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark44(10.347257110316946,44.293282921180435 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark44(1.4363369786349942,1.4363369786349942 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark44(24.418937758569157,30.38592273278232 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark44(2.627054252257041,2.627054252257041 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark44(74.64838148326922,4.9441386176324045 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark44(95.67550584233143,0.667860134031244 ) ;
  }
}
