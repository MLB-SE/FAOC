import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(0.22071244339205975,90.93841411083983,-80.88378605968424 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(10.256273888748646,2.6882728880479236,11.204475707370534 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(11.373825846067902,-44.471610055317925,11.493695256158816 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark55(11.809930892082718,-78.91408489246226,-18.284931299928587 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark55(12.76508832011509,16.746101575543122,12.438000852398503 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark55(19.26406735046315,-64.3718207342647,-19.75435943302321 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark55(35.96815628436792,-78.53410268454286,49.87169434025324 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark55(42.31253013937334,94.23988619158706,43.30502478090861 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark55(42.85231021142641,-23.269210896797,57.29130411867134 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark55(51.79164845257506,-85.45314050361723,57.62714632286995 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark55(53.720591902690614,-0.6132637859007417,82.8354544511601 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark55(6.925017077373695,2.635531042294322,9.833832617201804 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark55(76.86362574873806,-77.85929372525035,62.7768339759526 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark55(81.65176255957971,-31.117090098223784,98.42636415781908 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark55(88.17104507006462,-48.03135731419887,89.44427221390873 ) ;
  }
}
