import org.junit.Test;

public class Sample39Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark39(0.9999999999999998,0.15772103704060925 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark39(45.39097789364919,49.35068639251028 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark39(89.74781676368346,-65.63336805911462 ) ;
  }
}
