import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(1.0430024899310553E-16,1.0211757890588223E-8 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(11.06938623022424,38.93061376977576 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(13.720121673925558,26.72012167392554 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(14.776883710884448,27.776883710884448 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(2.0537780687720348E-11,4.531862817326642E-6 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(2.7807842393800684,35.15618432134656 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(50.728234675726185,51.151194772306766 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(5.666707569121158,22.98332601187198 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(65.72732103692195,29.767039312133363 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(71.67443434578755,90.59798869265293 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(7.795297344800687,71.13250331698652 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(9.912352220477942,22.042909363960888 ) ;
  }
}
