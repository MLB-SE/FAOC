import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,-4.7735523849127475,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0,79.98822618251859,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(-2.322511711313843,-14.79501178768659,36.128137865093265,-36.955973231311326,30.03168123812344 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(34.67882691416523,-46.99865538916339,-4.586367843167977,34.901970461298134,74.86547481312542 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(-94.87729746678517,-12.987089568360346,-43.13913558219467,-43.00411866039153,-82.72405818909998 ) ;
  }
}
