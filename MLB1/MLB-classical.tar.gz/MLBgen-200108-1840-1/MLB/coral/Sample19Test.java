import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(-0.5700853058026638,94.10804716176722,-0.5644361251143408 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(0.7182050687874479,83.70418956651937,0.6815516446444718 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(0.7808729163915729,21.664499732327045,0.6389491771596596 ) ;
  }
}
