import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(100.0,-24.436139681800757,0,-12.129273222398988 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(-24.179164437384927,-40.037207502520914,-30.11359215839755,16.300355896229718 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(45.6762014376084,-94.08013151104349,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(-60.16627659380458,55.81772029015252,0,-47.85914218408707 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(7.222479590476354,59.99944257181053,-88.45304542598926,23.736270990859197 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(80.35734565644313,46.9778571951359,93.58576273405001,-1.70835905773869 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(-9.784613829611777,69.29495630848561,0,0 ) ;
  }
}
