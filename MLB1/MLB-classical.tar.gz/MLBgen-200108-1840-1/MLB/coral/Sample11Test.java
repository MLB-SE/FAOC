import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(0.07067210773756472,8.343266389295607,45.61240769790078,-74.98772491889262 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(0.26636455352375776,-9.098776638813291,36.79464149402415,9.486829285832215 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(-0.8581028545956924,100.0,17.779388905905385,7.936539513853688 ) ;
  }
}
