import org.junit.Test;

public class Sample81Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark81(-10.983834516611907,-0.45758613011000193 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark81(26.32728438156865,1.2884299119169782 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark81(76.64716572475879,-31.624111722411484 ) ;
  }
}
