import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(0.29255316516405117 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(-0.30876283370444924 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(-0.33179177664098347 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark31(2.8098551183472438 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark31(5.318862367839592 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark31(80.65305076024225 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark31(8.343224834814222 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark31(-87.87977786607517 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark31(-9.253589436609502 ) ;
  }
}
