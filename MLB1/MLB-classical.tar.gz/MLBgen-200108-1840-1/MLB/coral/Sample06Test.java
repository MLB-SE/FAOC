import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(18.733385002573883,-54.211373295103726,-92.04801247044003 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(-96.44310692060796,86.28822542666629,69.33191648359212 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(97.9436810589215,42.264212647916054,-32.70210827666841 ) ;
  }
}
