import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(43.27011741932668,-40.7060749351762,99.98547744257021 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(56.5943592113631,74.98092021984718,78.32256540911624 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(67.29250863371658,65.841719269079,18.476783591069434 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark52(79.10981842027056,27.184808570653963,80.60119188509186 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark52(88.15799852287935,-42.167562811355275,34.879295383658956 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark52(93.9425713467993,-29.281530051598438,34.97329364243342 ) ;
  }
}
