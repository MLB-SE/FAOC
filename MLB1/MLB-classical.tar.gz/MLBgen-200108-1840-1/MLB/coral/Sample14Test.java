import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(-0.08876404256498915,84.83988988326956,-94.43646380928965,18.273136607281003 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(0.2668785724261369,13.235719460959203,-59.587775002695494,100.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(-0.6397213353613722,43.44903375948073,-22.485805956451884,-91.0188906056091 ) ;
  }
}
