import org.junit.Test;

public class Sample29Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark29(1.6094379124341005 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark29(82.25803077611602 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark29(-8.840117501067297 ) ;
  }
}
