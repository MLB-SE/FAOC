import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(-35.10037467756988,53.54259470660503 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(-55.91223813686792,23.584132006994054 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(88.64360587113161,-95.2015716551675 ) ;
  }
}
