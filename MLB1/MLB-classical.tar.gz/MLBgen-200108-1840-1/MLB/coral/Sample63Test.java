import org.junit.Test;

public class Sample63Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,1.5736193082072276,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,15.774816646925487,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark63(0.6967771653237986,5.525076789687854,4.611957252070134,-0.007822488042072289,-3.106498434825161 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark63(1.2972665121196285,33.559267131133915,34.85942732367962,-0.002059206735284544,8.178376040206345 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark63(13.138373560124279,37.231496065309415,-40.81583681582788,95.72560245472062,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark63(14.135466451564312,27.54582543182221,74.61966992707053,-3.868781925257153,45.03090486964035 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark63(1.9973601883159091,61.12003936707836,86.37972555889596,-46.11091525802284,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark63(28.61119083607974,27.051837464574387,54.723533742359415,1.0576431591217195,100.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark63(32.874552167749016,29.942342479809682,-20.363609851509725,83.18050449906842,38.184292735280515 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark63(33.74880073014529,34.49306936181685,99.15875381070211,75.44493821404598,-76.70432139878528 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark63(35.47245186094817,2.3388836291030515,-100.0,68.4521480952004,85.23707653295534 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark63(38.60633560737347,48.26985585891083,175.36289584274726,-42.50659769478542,44.85888232067529 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark63(39.97686586870955,81.8852269651677,-12.318933678700688,79.63932415050539,-63.980694964516374 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark63(46.55983223169443,4.884877047174356,25.24073249815314,105.02307169376577,97.17525159697396 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark63(47.73291350549752,10.534211204387447,48.03310074109578,39.49075567611743,17.043690140195793 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark63(4.864696281995016,0.0,100.0,66.83184096188734,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark63(55.34065052004479,12.083870667782213,89.82444974131661,-20.00693450695981,82.61452714926966 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark63(58.35530409997841,-48.33927279831221,-32.04517902103099,29.899133080871763,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark63(58.389951201395945,13.95038581803999,89.6569802747122,3.094443060282784,44.1930459020237 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark63(66.28276714422333,63.112952878298074,-89.86702886381386,63.29487393971323,62.170098686709366 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark63(67.90378545761702,9.315639045154327,76.670165344346,1.126726540675051,523.5676756416638 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark63(70.44009774382823,-0.5769851098790184,-53.00008857391965,83.30078819009202,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark63(7.260104957968181,16.693345627105643,44.97952190637045,76.6323795835331,11.468470706224096 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark63(76.3455409229011,9.819008459422957,85.19317799619456,1.1612879284767352,608.5320317248782 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark63(77.97125657259377,-52.462317878168705,-66.07768589002403,-74.90843448583479,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark63(79.92616042103887,99.11869232963352,4.701625856010622,87.94223669432765,-45.33836614584719 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark63(-82.29285985710962,40.494831852364854,-16.951899259564883,-92.04155484465231,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark63(87.11763727996302,-88.40943340317644,-83.71119370435811,64.80217133344678,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark63(88.04268585788776,3.1165215505701447,19.071115987138,84.14710778129995,100.0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark63(99.99825318569359,3.1538054117759495,-7.977724373560424,100.0,99.99999999999993 ) ;
  }
}
