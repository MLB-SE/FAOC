import org.junit.Test;

public class Sample91Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark91(100.0,-100.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark91(41.44101280991353,-29.88138662199735 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark91(47.067657647272824,-88.79651933018997 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark91(97.3893722612836,6.861735959044708E-15 ) ;
  }
}
