import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(57.42732818337361,90.38560484179733,26.16157566281157 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(-64.76473677284127,45.2955567496598,-56.987361221761866 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(-77.29228468220725,-41.05393810476261,-72.59450176148741 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(-81.84471890261993,40.42112546589229,45.809334345215404 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(82.42433369429801,88.35907450245386,-88.40614192507812 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(89.27809618624602,50.01784158663747,55.95620279385349 ) ;
  }
}
