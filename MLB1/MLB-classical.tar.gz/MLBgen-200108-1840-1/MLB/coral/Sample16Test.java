import org.junit.Test;

public class Sample16Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,-0.1119914512229343 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,7.824598420694315 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark16(66.6053841837153,14.744039515080672,26.702259127272754,-74.07206451412412,-92.06440910651168 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark16(-68.02576710252436,14.679408708101576,62.562229569206494,-43.11654822967481,-38.55491225315812 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark16(-8.695282312707675,14.965667375433583,2.0418269198377748,66.14563290820868,6.186622482447073 ) ;
  }
}
