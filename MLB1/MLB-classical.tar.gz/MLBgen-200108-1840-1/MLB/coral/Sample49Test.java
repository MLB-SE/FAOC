import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(0.6012560372209106,26.084310820077647 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(14.272600608466064,78.34365133509229 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(2.5556432597580567,63.64274542940265 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(2.6173560802544986E-8,1.2263325211349001E-5 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(2.9572151995892394E-9,2.5176658987572224E-5 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(5.582996348003977,44.417003651996026 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(7.73836321170738,2.065470002872118 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(86.28854871309127,97.37221920422718 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(8.731355203875342,27.29785959362856 ) ;
  }
}
