import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(3.8528292935301316,14.84412544759359 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(9.224188810331867,85.08569045412693 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(-9.991852058606355,93.00723711262708 ) ;
  }
}
