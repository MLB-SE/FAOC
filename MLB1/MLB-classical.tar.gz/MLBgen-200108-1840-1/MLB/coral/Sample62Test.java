import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-0.30435200399972473 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,31.10363008788792 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(0.9449536637784919,-33.71074393256726,-32.75477142270303,0.022854866182206668 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(16.44404905692403,1.6566271782631157,-79.08941770814732,24.161261645622844 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(1.8715316858235498,9.291809482738687,9.297792054899721,1.8775142579845838 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(2.074279535967652,-1.8854957807015795,0.03476923688285494,1.154857867752219 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(21.299927735128353,-2.4074295433033477,35.92371831865004,-8.75561714434614 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(21.98813212150148,45.46213800939408,22.524197114459852,44.92607301643571 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(23.010527101776248,70.91443051706909,-1.8650428540915698,39.90794575996213 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(-26.92699988485181,64.4716198154041,41.265192238948515,41.077011587026874 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(33.67087782939225,-8.16968557355193,31.156514716181675,47.402124928844074 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(3.6792065515420482,0.0,35.89449897290672,-71.61324055742296 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(38.418031045614555,-14.820396724665379,-91.86019879353525,-91.48366716049121 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(41.22229043009327,-29.28585220634639,56.949503201506104,-20.82429408432806 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(49.83971896882073,-40.668044151585825,22.782948224935737,90.41968027092787 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(55.04412544923869,-27.567685254544898,53.46813224095004,-96.67566363509515 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(59.61871870734922,-32.98725775672804,72.01237133064163,-32.12428111898156 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(6.022271331234052,-34.088776766333154,90.58541608945328,15.53013007617821 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(64.11198943600203,-25.686242476503466,31.858586583241305,44.5636944331236 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(65.73160371780524,-66.71667353702406,57.271808965705844,-58.13984739794731 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(75.28081055744204,-64.13169484859566,90.65696544489637,-73.62865131081992 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(80.77078053913503,-100.0,100.0,-0.8077078053913503 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(83.09897532221171,-5.53029974046791,-52.8019046438452,-24.07335664261248 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(89.32190636669165,-37.429234554278956,90.44429572385451,14.60130640742014 ) ;
  }
}
