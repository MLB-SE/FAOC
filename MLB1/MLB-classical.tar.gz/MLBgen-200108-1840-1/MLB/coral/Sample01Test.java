import org.junit.Test;

public class Sample01Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark01(-42.33234024412105,-26.60022513114238 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark01(-88.65002370265023,94.78259059770025 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark01(89.16903268033745,61.32746736832173 ) ;
  }
}
