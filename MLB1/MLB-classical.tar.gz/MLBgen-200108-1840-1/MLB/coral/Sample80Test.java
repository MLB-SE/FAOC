import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(-36.9727417989131,1.040570429105804 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(45.880034248416365,0.019231328321183128 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(65.57928221672174,99.13233441827452 ) ;
  }
}
