import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(-29.493699743835222,-87.1053397895428 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(-49.54114758612944,63.09582584347544 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(61.13471661742993,16.09606476590198 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(-66.25590089253689,8.502942164243919 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(97.7712968977855,81.83633377700846 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(97.80531315499323,-89.89028057339432 ) ;
  }
}
