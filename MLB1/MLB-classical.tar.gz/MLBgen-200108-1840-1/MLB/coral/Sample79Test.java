import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(-1.3078879797100435E-6,100.0,-100.0,100.0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(5.570662128034694E-9,-100.0,-100.0,-100.0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(78.89132814871601,16.418716760230964,24.900970878924,85.48792570678563,0 ) ;
  }
}
