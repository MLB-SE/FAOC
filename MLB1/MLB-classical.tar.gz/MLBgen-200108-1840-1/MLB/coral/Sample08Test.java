import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(40.36686658661472,-50.56894497496216,8.542715339399749 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(-86.799808746466,-68.19091692906179,11.435973114305952 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(88.41172855311001,-67.61984986574119,-68.61589151839817 ) ;
  }
}
