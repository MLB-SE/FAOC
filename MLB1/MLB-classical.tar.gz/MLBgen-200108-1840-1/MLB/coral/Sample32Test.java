import org.junit.Test;

public class Sample32Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark32(16.202834789750284 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark32(24.999999999999932 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark32(98.95870181279813 ) ;
  }
}
