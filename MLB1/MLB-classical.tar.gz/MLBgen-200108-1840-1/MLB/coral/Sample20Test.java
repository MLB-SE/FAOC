import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(-10.08383599659579,-79.47974429044127 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(-1.9122768729560136,53.74969339656178 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(21.481579717855695,22.278948924555948 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(21.646333668963276,22.495581411304173 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(-21.750880336136063,-31.474477852817714 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(74.98991771705946,73.77762217369548 ) ;
  }
}
