import org.junit.Test;

public class Sample46Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark46(0.0,0,-67.88530063330624,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark46(100.0,0.9999999999999594,100.0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark46(10.335165968569427,80.093436937968,60.13230765185321,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark46(-128.21446150542087,0,0.32111485663524775,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark46(3.0814879110195774E-33,98.75629008421302,1.5765309079158794E-16,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark46(37.624914910965856,1.0000000000000002,17.69957776495511,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark46(45.17546454187254,-38.189620119521784,49.23983257904513,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark46(59.17638422291759,0,92.82306268906865,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark46(-70.94600168062537,0,39.35665000310618,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark46(-711.5551973684744,0,20.15254983691308,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark46(74.47354040429073,0,91.831672210931,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark46(7.888609052210118E-31,54.663554550756096,1.0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark46(9.09809389625029,88.9394616349353,58.35486738490067,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark46(93.21246450672402,1.0,27.694474340503696,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark46(94.72506529184449,76.92014997557092,31.992851922195854,0 ) ;
  }
}
