import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(33.88750352407121,-15.680200341690352 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(-66.593528225193,28.9644932022606 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(72.33244996662444,46.44413201600897 ) ;
  }
}
