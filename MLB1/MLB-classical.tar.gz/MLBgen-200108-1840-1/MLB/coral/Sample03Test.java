import org.junit.Test;

public class Sample03Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark03(17.98219522761586,-98.33473884969976 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark03(75.3450658329532,-41.31002886553637 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark03(77.53605612531982,-13.133406726729056 ) ;
  }
}
