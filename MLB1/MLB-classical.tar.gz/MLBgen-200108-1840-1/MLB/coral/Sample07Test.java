import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark07(0,-155.3179544881303,0,-91.2016278902624 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(0,-28.27433387959678,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(0,-51.118719559920244,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(0,-92.87815608106177,0,43.44449232465382 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(34.560197087998176,-92.46469881599633,46.167769397145946,46.74399424689116 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(52.64762406616779,38.74310437502578,-3.4105617398201673,91.2680403630973 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(-78.88279813529903,-29.185594172513856,-38.3715299466392,-57.66504037086297 ) ;
  }
}
