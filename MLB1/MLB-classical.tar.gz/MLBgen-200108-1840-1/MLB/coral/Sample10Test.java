import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(47.1019523890717,12.436076066472282,-12.780197726344625 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(-6.030942432882092,66.55156658761581,78.55968614409629 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(-96.67090483275744,38.66745604837266,-47.10565754550062 ) ;
  }
}
