import org.junit.Test;

public class Sample41Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999991,1.9999999999999973 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.0000000000000004 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,1.9999999999999534 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0000000000000004 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark41(-1.7066301829571415,4.619216764337468 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark41(26.833941584042705,-88.62674122096344 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark41(-3.9286432072799045,78.43261268304923 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark41(6.556523809449089,36.43148065442371 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark41(7.849023329271489,53.7581438941766 ) ;
  }
}
