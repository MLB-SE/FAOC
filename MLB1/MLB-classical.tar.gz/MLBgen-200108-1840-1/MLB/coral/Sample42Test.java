import org.junit.Test;

public class Sample42Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark42(0.4261524842108499,0.4261524842108499 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark42(1.0,0.9999999999999964 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark42(-1.0218847793464352,100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark42(17.18248545038125,67.12195280242142 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark42(3.073001992892827,10.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark42(5.16943018876637,6.915239577539168 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark42(54.267921110110535,94.93604077833888 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark42(79.16425912140556,55.73786876547217 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark42(92.72830369745247,94.2021356546579 ) ;
  }
}
