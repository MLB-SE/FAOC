import org.junit.Test;

public class Sample43Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark43(1.4402870906643273,8.403040002526922 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark43(1.8354518984379524,20.215393193399308 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark43(21.311363806288114,46.116978325726706 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark43(3.0684968893968683,3.0684968893968683 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark43(4.1229321151827065,16.998569226404946 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark43(5.507756092680054,91.87424821712585 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark43(61.76605705426803,0.9954851418600299 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark43(65.47876140037732,95.34763147042759 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark43(68.77346533081376,66.86822123948423 ) ;
  }
}
