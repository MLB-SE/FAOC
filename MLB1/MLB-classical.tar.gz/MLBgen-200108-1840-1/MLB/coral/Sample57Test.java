import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0,2.2867698022247964,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(0,-73.82202420312731,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(3.3963480606329446,-9.64428937236113,-37.49559841488579,-33.12453389830881,91.09441489925987 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(35.777589233190774,37.75321724468622,88.52649342292318,22.664971161324445,80.00888121684744 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(40.75029695240525,93.72153968649235,39.157867665460856,-80.23136673220681,43.51280223546297 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(55.39419397710117,25.684030605094193,67.89586392868128,35.34263897815279,-39.3479319895222 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(69.89559863954818,46.4725497866296,75.1854466044413,8.404546489139975,-31.100174753940692 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(97.78933685792552,-36.08806411117214,-88.06945756686262,-44.12783044180597,66.4826031357126 ) ;
  }
}
