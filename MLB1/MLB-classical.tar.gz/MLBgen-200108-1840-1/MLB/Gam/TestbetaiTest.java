import org.junit.Test;

public class TestbetaiTest {

  @Test
  public void test0() {
    beta.betai(0,0,0.6540436286252174 ) ;
  }

  @Test
  public void test1() {
    beta.betai(0,0,0.7223696255397845 ) ;
  }

  @Test
  public void test2() {
    beta.betai(0,0,0.9999999999999964 ) ;
  }

  @Test
  public void test3() {
    beta.betai(0,0,0.9999999999999996 ) ;
  }

  @Test
  public void test4() {
    beta.betai(0,0,0.9999999999999999 ) ;
  }

  @Test
  public void test5() {
    beta.betai(0,0,1.0 ) ;
  }

  @Test
  public void test6() {
    beta.betai(0,0,1.0000000000000002 ) ;
  }

  @Test
  public void test7() {
    beta.betai(0,0,1.000099130919902 ) ;
  }

  @Test
  public void test8() {
    beta.betai(0,0,1.0021252211722207 ) ;
  }

  @Test
  public void test9() {
    beta.betai(0,0,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test10() {
    beta.betai(0,0,14.378482667183775 ) ;
  }

  @Test
  public void test11() {
    beta.betai(0,0,-2.5745143263317516 ) ;
  }

  @Test
  public void test12() {
    beta.betai(0,0,2.74854916090878 ) ;
  }

  @Test
  public void test13() {
    beta.betai(0,0,35.12045633960696 ) ;
  }

  @Test
  public void test14() {
    beta.betai(0,0,-36.49685057257561 ) ;
  }

  @Test
  public void test15() {
    beta.betai(0,0,43.22635538306602 ) ;
  }

  @Test
  public void test16() {
    beta.betai(0,0,4.440892098500626E-16 ) ;
  }

  @Test
  public void test17() {
    beta.betai(0,0,-44.76719826463062 ) ;
  }

  @Test
  public void test18() {
    beta.betai(0,0,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test19() {
    beta.betai(0,0,4.930380657631324E-32 ) ;
  }

  @Test
  public void test20() {
    beta.betai(0,0,-6.162975822039155E-33 ) ;
  }

  @Test
  public void test21() {
    beta.betai(0,0,67.9470575838676 ) ;
  }

  @Test
  public void test22() {
    beta.betai(0,0,-69.76019061531689 ) ;
  }

  @Test
  public void test23() {
    beta.betai(0,0,9.629649721936179E-35 ) ;
  }

  @Test
  public void test24() {
    beta.betai(0,0,9.993907223439564 ) ;
  }
}
