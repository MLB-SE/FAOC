import org.junit.Test;

public class TestbetacfTest {

  @Test
  public void test0() {
    beta.betacf(-1.0,0,0 ) ;
  }

  @Test
  public void test1() {
    beta.betacf(11.81102070711124,0,0 ) ;
  }

  @Test
  public void test2() {
    beta.betacf(-49.744468128605575,-31.147220007151773,49.952237635268034 ) ;
  }

  @Test
  public void test3() {
    beta.betacf(57.83995036673806,-57.251498510914,99.99110340868793 ) ;
  }

  @Test
  public void test4() {
    beta.betacf(-61.15735859817646,50.68739261196647,5.7457071663279375 ) ;
  }

  @Test
  public void test5() {
    beta.betacf(6.193745525203624,12.157948987917308,-99.59661997114861 ) ;
  }

  @Test
  public void test6() {
    beta.betacf(69.58493104638086,-67.01096109517427,27.42259326426595 ) ;
  }

  @Test
  public void test7() {
    beta.betacf(70.78383394340767,-59.14972868764703,6.170120723969193 ) ;
  }

  @Test
  public void test8() {
    beta.betacf(-80.18690728464307,48.07040833885637,2.4656145558802085 ) ;
  }

  @Test
  public void test9() {
    beta.betacf(82.21647950134582,-60.333010918608295,-36.07240107146603 ) ;
  }

  @Test
  public void test10() {
    beta.betacf(-85.65525195125026,17.94987320024177,1.2503475131950177 ) ;
  }

  @Test
  public void test11() {
    beta.betacf(-87.64344622438726,-68.1457360638939,40.15947761714574 ) ;
  }

  @Test
  public void test12() {
    beta.betacf(-8.775541869778658,10.612146289183919,-4.233650854600785 ) ;
  }

  @Test
  public void test13() {
    beta.betacf(99.16738163104449,-91.79165819521096,13.580685678153348 ) ;
  }
}
