import org.junit.Test;

public class TestbicoTest {

  @Test
  public void test0() {
    gam.bico(0,0 ) ;
  }

  @Test
  public void test1() {
    gam.bico(0,636 ) ;
  }

  @Test
  public void test2() {
    gam.bico(1,-1 ) ;
  }

  @Test
  public void test3() {
    gam.bico(1,-296 ) ;
  }

  @Test
  public void test4() {
    gam.bico(-164,65 ) ;
  }

  @Test
  public void test5() {
    gam.bico(1,702 ) ;
  }

  @Test
  public void test6() {
    gam.bico(1,-898 ) ;
  }

  @Test
  public void test7() {
    gam.bico(2,0 ) ;
  }

  @Test
  public void test8() {
    gam.bico(319,0 ) ;
  }

  @Test
  public void test9() {
    gam.bico(327,0 ) ;
  }

  @Test
  public void test10() {
    gam.bico(-36,0 ) ;
  }

  @Test
  public void test11() {
    gam.bico(-368,2 ) ;
  }

  @Test
  public void test12() {
    gam.bico(-386,-424 ) ;
  }

  @Test
  public void test13() {
    gam.bico(-433,0 ) ;
  }

  @Test
  public void test14() {
    gam.bico(-582,966 ) ;
  }

  @Test
  public void test15() {
    gam.bico(-767,-835 ) ;
  }

  @Test
  public void test16() {
    gam.bico(838,0 ) ;
  }

  @Test
  public void test17() {
    gam.bico(-966,0 ) ;
  }

  @Test
  public void test18() {
    gam.bico(97,0 ) ;
  }
}
