import org.junit.Test;

public class TesterffcTest {

  @Test
  public void test0() {
    gam.erffc(-0.048459284614210674 ) ;
  }

  @Test
  public void test1() {
    gam.erffc(0.2642116536244864 ) ;
  }

  @Test
  public void test2() {
    gam.erffc(1.224744871391589 ) ;
  }

  @Test
  public void test3() {
    gam.erffc(-1.2247448713915892 ) ;
  }

  @Test
  public void test4() {
    gam.erffc(-1.232595164407831E-32 ) ;
  }

  @Test
  public void test5() {
    gam.erffc(-1.2634920662350609E-175 ) ;
  }

  @Test
  public void test6() {
    gam.erffc(-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test7() {
    gam.erffc(1.7763568394002505E-15 ) ;
  }

  @Test
  public void test8() {
    gam.erffc(18.279304117623838 ) ;
  }

  @Test
  public void test9() {
    gam.erffc(-2.220446049250313E-16 ) ;
  }

  @Test
  public void test10() {
    gam.erffc(-22.692980174969037 ) ;
  }

  @Test
  public void test11() {
    gam.erffc(-2.295640687790936 ) ;
  }

  @Test
  public void test12() {
    gam.erffc(-24.57257964755273 ) ;
  }

  @Test
  public void test13() {
    gam.erffc(3.556413999176124E-161 ) ;
  }

  @Test
  public void test14() {
    gam.erffc(4.3790577010150533E-47 ) ;
  }

  @Test
  public void test15() {
    gam.erffc(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test16() {
    gam.erffc(5.421010862427522E-20 ) ;
  }

  @Test
  public void test17() {
    gam.erffc(60.58269505592543 ) ;
  }

  @Test
  public void test18() {
    gam.erffc(67.23714731718061 ) ;
  }

  @Test
  public void test19() {
    gam.erffc(8.881784197001252E-16 ) ;
  }

  @Test
  public void test20() {
    gam.erffc(-98.3892927588307 ) ;
  }
}
