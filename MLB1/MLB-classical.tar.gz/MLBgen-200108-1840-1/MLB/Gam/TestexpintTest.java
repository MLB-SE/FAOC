import org.junit.Test;

public class TestexpintTest {

  @Test
  public void test0() {
    expint.expint(0,0.0 ) ;
  }

  @Test
  public void test1() {
    expint.expint(0,65.27365925948587 ) ;
  }

  @Test
  public void test2() {
    expint.expint(135,-7.9E-323 ) ;
  }

  @Test
  public void test3() {
    expint.expint(217,-56.793874737073644 ) ;
  }

  @Test
  public void test4() {
    expint.expint(269,0.0 ) ;
  }

  @Test
  public void test5() {
    expint.expint(280,11.741850994549537 ) ;
  }

  @Test
  public void test6() {
    expint.expint(334,0.0 ) ;
  }

  @Test
  public void test7() {
    expint.expint(455,4.9E-324 ) ;
  }

  @Test
  public void test8() {
    expint.expint(605,0.0 ) ;
  }

  @Test
  public void test9() {
    expint.expint(-615,0 ) ;
  }

  @Test
  public void test10() {
    expint.expint(652,0 ) ;
  }

  @Test
  public void test11() {
    expint.expint(741,3.5E-323 ) ;
  }

  @Test
  public void test12() {
    expint.expint(76,79.39932225348772 ) ;
  }

  @Test
  public void test13() {
    expint.expint(841,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test14() {
    expint.expint(94,0.1416782280274873 ) ;
  }
}
