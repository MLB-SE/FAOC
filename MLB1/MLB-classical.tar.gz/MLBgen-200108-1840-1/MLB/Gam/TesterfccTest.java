import org.junit.Test;

public class TesterfccTest {

  @Test
  public void test0() {
    erf.erfcc(-1.0E-323 ) ;
  }

  @Test
  public void test1() {
    erf.erfcc(-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2() {
    erf.erfcc(-12.954290170126995 ) ;
  }

  @Test
  public void test3() {
    erf.erfcc(-24.35609703516846 ) ;
  }

  @Test
  public void test4() {
    erf.erfcc(2.9568392741648637 ) ;
  }

  @Test
  public void test5() {
    erf.erfcc(3.469446951953614E-18 ) ;
  }

  @Test
  public void test6() {
    erf.erfcc(4.930380657631324E-32 ) ;
  }

  @Test
  public void test7() {
    erf.erfcc(55.59655570368324 ) ;
  }

  @Test
  public void test8() {
    erf.erfcc(6.4E-323 ) ;
  }

  @Test
  public void test9() {
    erf.erfcc(6.995996898975164 ) ;
  }

  @Test
  public void test10() {
    erf.erfcc(70.7205435939758 ) ;
  }

  @Test
  public void test11() {
    erf.erfcc(-82.88899275451809 ) ;
  }
}
