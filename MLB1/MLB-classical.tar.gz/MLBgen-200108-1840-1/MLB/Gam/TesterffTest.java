import org.junit.Test;

public class TesterffTest {

  @Test
  public void test0() {
    gam.erff(0.3458531006489389 ) ;
  }

  @Test
  public void test1() {
    gam.erff(0.5204620189744844 ) ;
  }

  @Test
  public void test2() {
    gam.erff(0.5218191880287391 ) ;
  }

  @Test
  public void test3() {
    gam.erff(-0.9894831757801121 ) ;
  }

  @Test
  public void test4() {
    gam.erff(-1.2247448713915892 ) ;
  }

  @Test
  public void test5() {
    gam.erff(1.2247448713915892 ) ;
  }

  @Test
  public void test6() {
    gam.erff(1.232595164407831E-32 ) ;
  }

  @Test
  public void test7() {
    gam.erff(-1.5170703278085256 ) ;
  }

  @Test
  public void test8() {
    gam.erff(1.7763568394002505E-15 ) ;
  }

  @Test
  public void test9() {
    gam.erff(-2.220446049250313E-16 ) ;
  }

  @Test
  public void test10() {
    gam.erff(-2.465190328815662E-32 ) ;
  }

  @Test
  public void test11() {
    gam.erff(-30.27259572482386 ) ;
  }

  @Test
  public void test12() {
    gam.erff(3.3881317890172014E-21 ) ;
  }

  @Test
  public void test13() {
    gam.erff(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test14() {
    gam.erff(5.0539682649402436E-175 ) ;
  }

  @Test
  public void test15() {
    gam.erff(-6.3174603311753045E-176 ) ;
  }

  @Test
  public void test16() {
    gam.erff(-65.20076171245223 ) ;
  }

  @Test
  public void test17() {
    gam.erff(-6.938893903907228E-18 ) ;
  }

  @Test
  public void test18() {
    gam.erff(71.3047689479722 ) ;
  }

  @Test
  public void test19() {
    gam.erff(71.70972015048838 ) ;
  }

  @Test
  public void test20() {
    gam.erff(96.3937748368734 ) ;
  }
}
