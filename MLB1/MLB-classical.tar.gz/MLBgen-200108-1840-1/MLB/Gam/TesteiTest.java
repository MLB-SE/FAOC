import org.junit.Test;

public class TesteiTest {

  @Test
  public void test0() {
    expint.ei(1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1() {
    expint.ei(-1.6764143568484258 ) ;
  }

  @Test
  public void test2() {
    expint.ei(-17.48485522475933 ) ;
  }

  @Test
  public void test3() {
    expint.ei(-18.328008559051412 ) ;
  }

  @Test
  public void test4() {
    expint.ei(19.85537751240112 ) ;
  }

  @Test
  public void test5() {
    expint.ei(-22.098965202910506 ) ;
  }

  @Test
  public void test6() {
    expint.ei(2.465190328815662E-32 ) ;
  }

  @Test
  public void test7() {
    expint.ei(25.378421442134027 ) ;
  }

  @Test
  public void test8() {
    expint.ei(29.416261570895387 ) ;
  }

  @Test
  public void test9() {
    expint.ei(32.23619130191664 ) ;
  }

  @Test
  public void test10() {
    expint.ei(3.675042021489471E-15 ) ;
  }

  @Test
  public void test11() {
    expint.ei(-3.944304526105059E-31 ) ;
  }

  @Test
  public void test12() {
    expint.ei(4.9E-324 ) ;
  }

  @Test
  public void test13() {
    expint.ei(6.102932900510567 ) ;
  }

  @Test
  public void test14() {
    expint.ei(83.25368472759283 ) ;
  }

  @Test
  public void test15() {
    expint.ei(84.58092169883136 ) ;
  }
}
