import org.junit.Test;

public class TestbetaTest {

  @Test
  public void test0() {
    beta.beta(-2.0,0 ) ;
  }

  @Test
  public void test1() {
    beta.beta(-3.0,0 ) ;
  }

  @Test
  public void test2() {
    beta.beta(30.329168648891283,0 ) ;
  }

  @Test
  public void test3() {
    beta.beta(-4.041502100811229,0 ) ;
  }

  @Test
  public void test4() {
    beta.beta(79.97689732215824,0 ) ;
  }

  @Test
  public void test5() {
    beta.beta(84.37558616804043,0 ) ;
  }
}
