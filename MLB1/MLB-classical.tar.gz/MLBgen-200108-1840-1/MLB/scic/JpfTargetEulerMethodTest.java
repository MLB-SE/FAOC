import org.junit.Test;

public class JpfTargetEulerMethodTest {

  @Test
  public void test0() {
    scic.EulerMethod.euler(-17.391688110931412 ) ;
  }

  @Test
  public void test1() {
    scic.EulerMethod.euler(-1.9946221946070215 ) ;
  }

  @Test
  public void test2() {
    scic.EulerMethod.euler(-61.81457792588223 ) ;
  }
}
