import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(-0.1022255115177444,-79.0463025364599 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(0.45825268778952477,0 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(-0.5107723177752064,0 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(-10.894137489123139,0 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(-1.439606457538602,0 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(-15.105659429978019,0 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonSimpson.newton(-17.059829250885272,81.88099523120184 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonSimpson.newton(1.7123080511978372,0.003981079326494719 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonSimpson.newton(2.005577285149826,90.45668061018426 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonSimpson.newton(-2.323502089046812,0 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonSimpson.newton(26.187256463888502,0 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonSimpson.newton(-27.371580487248437,21.900321995774092 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonSimpson.newton(2.747519533255229,0 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonSimpson.newton(34.13622131437185,-35.87709176352705 ) ;
  }

  @Test
  public void test14() {
    scic.NewtonSimpson.newton(-35.61831062399952,0 ) ;
  }

  @Test
  public void test15() {
    scic.NewtonSimpson.newton(-88.5995468432359,0 ) ;
  }
}
