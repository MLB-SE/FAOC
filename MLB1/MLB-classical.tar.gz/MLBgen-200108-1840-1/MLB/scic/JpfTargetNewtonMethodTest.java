import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(-12.249999619212312,0 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(-16.065245609476065,30.770124243095978 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(19.35981070976773,-4.4693117364866595 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(-27.750000000000075,-7.60979776134726 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(41.09613364569782,0 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(-43.221100309248214,0.03010116721452505 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonMethod.newton(-53.75,0.0 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonMethod.newton(-69.95233212120802,0 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonMethod.newton(73.54686811666906,0 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonMethod.newton(-7.390682111060443,17.94155665238621 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonMethod.newton(-89.25000000000001,32.910852487104 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonMethod.newton(92.47488038589157,0 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonMethod.newton(94.48331217903024,-14.07206804874616 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonMethod.newton(-96.33453465018455,0.08550270474580657 ) ;
  }
}
