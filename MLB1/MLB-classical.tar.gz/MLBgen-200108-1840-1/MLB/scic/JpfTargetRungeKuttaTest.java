import org.junit.Test;

public class JpfTargetRungeKuttaTest {

  @Test
  public void test0() {
    scic.RungeKutta.rungeKutta(19.25143387153338 ) ;
  }

  @Test
  public void test1() {
    scic.RungeKutta.rungeKutta(2703.3622114655072 ) ;
  }

  @Test
  public void test2() {
    scic.RungeKutta.rungeKutta(2712.2042495829987 ) ;
  }

  @Test
  public void test3() {
    scic.RungeKutta.rungeKutta(2726.105553229733 ) ;
  }

  @Test
  public void test4() {
    scic.RungeKutta.rungeKutta(2726.6659199404135 ) ;
  }

  @Test
  public void test5() {
    scic.RungeKutta.rungeKutta(2733.3475311535813 ) ;
  }

  @Test
  public void test6() {
    scic.RungeKutta.rungeKutta(2734.9467342523308 ) ;
  }

  @Test
  public void test7() {
    scic.RungeKutta.rungeKutta(-35.84776309487995 ) ;
  }

  @Test
  public void test8() {
    scic.RungeKutta.rungeKutta(42.35792297374263 ) ;
  }

  @Test
  public void test9() {
    scic.RungeKutta.rungeKutta(-48.73299938921611 ) ;
  }

  @Test
  public void test10() {
    scic.RungeKutta.rungeKutta(-64.2890574274083 ) ;
  }

  @Test
  public void test11() {
    scic.RungeKutta.rungeKutta(70.08165882172759 ) ;
  }

  @Test
  public void test12() {
    scic.RungeKutta.rungeKutta(78.37059533380315 ) ;
  }

  @Test
  public void test13() {
    scic.RungeKutta.rungeKutta(86.69324358818176 ) ;
  }

  @Test
  public void test14() {
    scic.RungeKutta.rungeKutta(89.85263059681728 ) ;
  }

  @Test
  public void test15() {
    scic.RungeKutta.rungeKutta(90.63326372170889 ) ;
  }

  @Test
  public void test16() {
    scic.RungeKutta.rungeKutta(94.67902109981165 ) ;
  }

  @Test
  public void test17() {
    scic.RungeKutta.rungeKutta(97.9391909256324 ) ;
  }
}
