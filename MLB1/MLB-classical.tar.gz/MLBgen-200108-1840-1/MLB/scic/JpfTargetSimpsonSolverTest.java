import org.junit.Test;

public class JpfTargetSimpsonSolverTest {

  @Test
  public void test0() {
    scic.SimpsonSolver.simpson(-13.025217708284458,50.520148505149706 ) ;
  }

  @Test
  public void test1() {
    scic.SimpsonSolver.simpson(50.14408521442718,-6.920428890532861 ) ;
  }

  @Test
  public void test2() {
    scic.SimpsonSolver.simpson(-5.527823338711209,16.229764743464585 ) ;
  }
}
