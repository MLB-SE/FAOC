import org.junit.Test;

public class TestjuldayTest {

  @Test
  public void test0() {
    caldat.julday(0,0,0 ) ;
  }

  @Test
  public void test1() {
    caldat.julday(0,0,154 ) ;
  }

  @Test
  public void test2() {
    caldat.julday(0,0,-183 ) ;
  }

  @Test
  public void test3() {
    caldat.julday(0,0,-490 ) ;
  }

  @Test
  public void test4() {
    caldat.julday(101,0,1 ) ;
  }

  @Test
  public void test5() {
    caldat.julday(1,0,1265 ) ;
  }

  @Test
  public void test6() {
    caldat.julday(-10,-178,591 ) ;
  }

  @Test
  public void test7() {
    caldat.julday(-103,294,509 ) ;
  }

  @Test
  public void test8() {
    caldat.julday(1,0,-92 ) ;
  }

  @Test
  public void test9() {
    caldat.julday(-11,752,1652 ) ;
  }

  @Test
  public void test10() {
    caldat.julday(1,19560,-4 ) ;
  }

  @Test
  public void test11() {
    caldat.julday(-1,199,0 ) ;
  }

  @Test
  public void test12() {
    caldat.julday(1,21023,1 ) ;
  }

  @Test
  public void test13() {
    caldat.julday(-13,0,0 ) ;
  }

  @Test
  public void test14() {
    caldat.julday(-13,0,1197 ) ;
  }

  @Test
  public void test15() {
    caldat.julday(-13,0,-2120 ) ;
  }

  @Test
  public void test16() {
    caldat.julday(-13,0,-23 ) ;
  }

  @Test
  public void test17() {
    caldat.julday(-13,0,367 ) ;
  }

  @Test
  public void test18() {
    caldat.julday(-13,-2531,-6 ) ;
  }

  @Test
  public void test19() {
    caldat.julday(-13,318,-824 ) ;
  }

  @Test
  public void test20() {
    caldat.julday(-13,-352,0 ) ;
  }

  @Test
  public void test21() {
    caldat.julday(-136,0,110 ) ;
  }

  @Test
  public void test22() {
    caldat.julday(-13,-741,685 ) ;
  }

  @Test
  public void test23() {
    caldat.julday(140,-718,474 ) ;
  }

  @Test
  public void test24() {
    caldat.julday(1,-4,529 ) ;
  }

  @Test
  public void test25() {
    caldat.julday(1,510,-976 ) ;
  }

  @Test
  public void test26() {
    caldat.julday(160,0,-1 ) ;
  }

  @Test
  public void test27() {
    caldat.julday(-16,17183,-3 ) ;
  }

  @Test
  public void test28() {
    caldat.julday(-17,20708,0 ) ;
  }

  @Test
  public void test29() {
    caldat.julday(-18,18994,0 ) ;
  }

  @Test
  public void test30() {
    caldat.julday(-18,19311,-12 ) ;
  }

  @Test
  public void test31() {
    caldat.julday(1914,717,1600 ) ;
  }

  @Test
  public void test32() {
    caldat.julday(-19,15136,-4 ) ;
  }

  @Test
  public void test33() {
    caldat.julday(192,0,-335 ) ;
  }

  @Test
  public void test34() {
    caldat.julday(19286,128,0 ) ;
  }

  @Test
  public void test35() {
    caldat.julday(19865,235,-36 ) ;
  }

  @Test
  public void test36() {
    caldat.julday(-2,0,0 ) ;
  }

  @Test
  public void test37() {
    caldat.julday(2,0,0 ) ;
  }

  @Test
  public void test38() {
    caldat.julday(20077,932,-85 ) ;
  }

  @Test
  public void test39() {
    caldat.julday(-2,0,-344 ) ;
  }

  @Test
  public void test40() {
    caldat.julday(-2,0,409 ) ;
  }

  @Test
  public void test41() {
    caldat.julday(-2,0,568 ) ;
  }

  @Test
  public void test42() {
    caldat.julday(-2,0,-637 ) ;
  }

  @Test
  public void test43() {
    caldat.julday(207,-873,1665 ) ;
  }

  @Test
  public void test44() {
    caldat.julday(209,0,438 ) ;
  }

  @Test
  public void test45() {
    caldat.julday(21,0,-261 ) ;
  }

  @Test
  public void test46() {
    caldat.julday(-23,-1785,327 ) ;
  }

  @Test
  public void test47() {
    caldat.julday(235,1000,-536 ) ;
  }

  @Test
  public void test48() {
    caldat.julday(248,387,0 ) ;
  }

  @Test
  public void test49() {
    caldat.julday(2,517,1665 ) ;
  }

  @Test
  public void test50() {
    caldat.julday(258,0,-128 ) ;
  }

  @Test
  public void test51() {
    caldat.julday(-268,-53,-449 ) ;
  }

  @Test
  public void test52() {
    caldat.julday(-2,-685,-482 ) ;
  }

  @Test
  public void test53() {
    caldat.julday(-28,-435,1703 ) ;
  }

  @Test
  public void test54() {
    caldat.julday(-318,0,-288 ) ;
  }

  @Test
  public void test55() {
    caldat.julday(-3,18178,-1 ) ;
  }

  @Test
  public void test56() {
    caldat.julday(-320,0,1713 ) ;
  }

  @Test
  public void test57() {
    caldat.julday(-3,2488,1857 ) ;
  }

  @Test
  public void test58() {
    caldat.julday(328,0,-1 ) ;
  }

  @Test
  public void test59() {
    caldat.julday(354,0,0 ) ;
  }

  @Test
  public void test60() {
    caldat.julday(-369,0,4 ) ;
  }

  @Test
  public void test61() {
    caldat.julday(4,0,0 ) ;
  }

  @Test
  public void test62() {
    caldat.julday(4,0,-1141 ) ;
  }

  @Test
  public void test63() {
    caldat.julday(4,0,-236 ) ;
  }

  @Test
  public void test64() {
    caldat.julday(4,0,429 ) ;
  }

  @Test
  public void test65() {
    caldat.julday(4,0,788 ) ;
  }

  @Test
  public void test66() {
    caldat.julday(408,0,677 ) ;
  }

  @Test
  public void test67() {
    caldat.julday(-464,429,-500 ) ;
  }

  @Test
  public void test68() {
    caldat.julday(-483,0,-1 ) ;
  }

  @Test
  public void test69() {
    caldat.julday(-493,0,2 ) ;
  }

  @Test
  public void test70() {
    caldat.julday(-515,762,1902 ) ;
  }

  @Test
  public void test71() {
    caldat.julday(-568,590,340 ) ;
  }

  @Test
  public void test72() {
    caldat.julday(-574,0,-900 ) ;
  }

  @Test
  public void test73() {
    caldat.julday(-6,0,452 ) ;
  }

  @Test
  public void test74() {
    caldat.julday(-67,382,1909 ) ;
  }

  @Test
  public void test75() {
    caldat.julday(712,0,0 ) ;
  }

  @Test
  public void test76() {
    caldat.julday(715,321,-361 ) ;
  }

  @Test
  public void test77() {
    caldat.julday(747,0,-825 ) ;
  }

  @Test
  public void test78() {
    caldat.julday(-753,0,0 ) ;
  }

  @Test
  public void test79() {
    caldat.julday(-756,366,0 ) ;
  }

  @Test
  public void test80() {
    caldat.julday(758,0,1 ) ;
  }

  @Test
  public void test81() {
    caldat.julday(-768,0,-883 ) ;
  }

  @Test
  public void test82() {
    caldat.julday(770,-952,252 ) ;
  }

  @Test
  public void test83() {
    caldat.julday(786,0,4 ) ;
  }

  @Test
  public void test84() {
    caldat.julday(-8,0,-722 ) ;
  }

  @Test
  public void test85() {
    caldat.julday(-808,0,-514 ) ;
  }

  @Test
  public void test86() {
    caldat.julday(-8,17443,-2 ) ;
  }

  @Test
  public void test87() {
    caldat.julday(821,0,0 ) ;
  }

  @Test
  public void test88() {
    caldat.julday(-825,0,585 ) ;
  }

  @Test
  public void test89() {
    caldat.julday(-842,0,0 ) ;
  }

  @Test
  public void test90() {
    caldat.julday(-851,0,1 ) ;
  }

  @Test
  public void test91() {
    caldat.julday(-856,0,345 ) ;
  }

  @Test
  public void test92() {
    caldat.julday(895,0,318 ) ;
  }

  @Test
  public void test93() {
    caldat.julday(-90,0,0 ) ;
  }

  @Test
  public void test94() {
    caldat.julday(927,0,516 ) ;
  }

  @Test
  public void test95() {
    caldat.julday(-960,0,-942 ) ;
  }

  @Test
  public void test96() {
    caldat.julday(982,0,-792 ) ;
  }

  @Test
  public void test97() {
    caldat.julday(-988,0,1 ) ;
  }
}
