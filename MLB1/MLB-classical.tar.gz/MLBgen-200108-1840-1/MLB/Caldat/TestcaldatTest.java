import org.junit.Test;

public class TestcaldatTest {

  @Test
  public void test0() {
    caldat.caldat(0 ) ;
  }

  @Test
  public void test1() {
    caldat.caldat(-1 ) ;
  }

  @Test
  public void test2() {
    caldat.caldat(-176 ) ;
  }

  @Test
  public void test3() {
    caldat.caldat(1873 ) ;
  }

  @Test
  public void test4() {
    caldat.caldat(202 ) ;
  }

  @Test
  public void test5() {
    caldat.caldat(-219 ) ;
  }

  @Test
  public void test6() {
    caldat.caldat(27078 ) ;
  }

  @Test
  public void test7() {
    caldat.caldat(-281 ) ;
  }

  @Test
  public void test8() {
    caldat.caldat(303 ) ;
  }

  @Test
  public void test9() {
    caldat.caldat(-324 ) ;
  }

  @Test
  public void test10() {
    caldat.caldat(-355 ) ;
  }

  @Test
  public void test11() {
    caldat.caldat(-362 ) ;
  }

  @Test
  public void test12() {
    caldat.caldat(399 ) ;
  }

  @Test
  public void test13() {
    caldat.caldat(400 ) ;
  }

  @Test
  public void test14() {
    caldat.caldat(49 ) ;
  }

  @Test
  public void test15() {
    caldat.caldat(572 ) ;
  }

  @Test
  public void test16() {
    caldat.caldat(65 ) ;
  }

  @Test
  public void test17() {
    caldat.caldat(-660 ) ;
  }

  @Test
  public void test18() {
    caldat.caldat(681 ) ;
  }

  @Test
  public void test19() {
    caldat.caldat(-711 ) ;
  }

  @Test
  public void test20() {
    caldat.caldat(-717 ) ;
  }

  @Test
  public void test21() {
    caldat.caldat(-727 ) ;
  }

  @Test
  public void test22() {
    caldat.caldat(732 ) ;
  }

  @Test
  public void test23() {
    caldat.caldat(-741 ) ;
  }

  @Test
  public void test24() {
    caldat.caldat(7749 ) ;
  }

  @Test
  public void test25() {
    caldat.caldat(778 ) ;
  }

  @Test
  public void test26() {
    caldat.caldat(801 ) ;
  }

  @Test
  public void test27() {
    caldat.caldat(-829 ) ;
  }

  @Test
  public void test28() {
    caldat.caldat(-917 ) ;
  }

  @Test
  public void test29() {
    caldat.caldat(994 ) ;
  }
}
