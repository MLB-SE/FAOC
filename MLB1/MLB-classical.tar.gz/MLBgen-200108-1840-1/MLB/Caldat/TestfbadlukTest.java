import org.junit.Test;

public class TestfbadlukTest {

  @Test
  public void test0() {
    caldat.badluk(0 ) ;
  }

  @Test
  public void test1() {
    caldat.badluk(-1 ) ;
  }

  @Test
  public void test2() {
    caldat.badluk(1 ) ;
  }

  @Test
  public void test3() {
    caldat.badluk(170 ) ;
  }

  @Test
  public void test4() {
    caldat.badluk(-171 ) ;
  }

  @Test
  public void test5() {
    caldat.badluk(2 ) ;
  }

  @Test
  public void test6() {
    caldat.badluk(-416 ) ;
  }

  @Test
  public void test7() {
    caldat.badluk(421 ) ;
  }

  @Test
  public void test8() {
    caldat.badluk(641 ) ;
  }

  @Test
  public void test9() {
    caldat.badluk(-65 ) ;
  }

  @Test
  public void test10() {
    caldat.badluk(76 ) ;
  }

  @Test
  public void test11() {
    caldat.badluk(-950 ) ;
  }

  @Test
  public void test12() {
    caldat.badluk(-979 ) ;
  }
}
