import org.junit.Test;

public class TestflmoonTest {

  @Test
  public void test0() {
    caldat.flmoon(0,0 ) ;
  }

  @Test
  public void test1() {
    caldat.flmoon(0,1 ) ;
  }

  @Test
  public void test2() {
    caldat.flmoon(0,2 ) ;
  }

  @Test
  public void test3() {
    caldat.flmoon(0,3 ) ;
  }

  @Test
  public void test4() {
    caldat.flmoon(0,-402 ) ;
  }

  @Test
  public void test5() {
    caldat.flmoon(0,-485 ) ;
  }

  @Test
  public void test6() {
    caldat.flmoon(0,538 ) ;
  }

  @Test
  public void test7() {
    caldat.flmoon(0,824 ) ;
  }

  @Test
  public void test8() {
    caldat.flmoon(-1,0 ) ;
  }

  @Test
  public void test9() {
    caldat.flmoon(1014,34 ) ;
  }

  @Test
  public void test10() {
    caldat.flmoon(-1,1 ) ;
  }

  @Test
  public void test11() {
    caldat.flmoon(1,1 ) ;
  }

  @Test
  public void test12() {
    caldat.flmoon(1112,24 ) ;
  }

  @Test
  public void test13() {
    caldat.flmoon(-113,3 ) ;
  }

  @Test
  public void test14() {
    caldat.flmoon(-1135,-741 ) ;
  }

  @Test
  public void test15() {
    caldat.flmoon(-1,2 ) ;
  }

  @Test
  public void test16() {
    caldat.flmoon(-1,3 ) ;
  }

  @Test
  public void test17() {
    caldat.flmoon(1,-3 ) ;
  }

  @Test
  public void test18() {
    caldat.flmoon(134,-112 ) ;
  }

  @Test
  public void test19() {
    caldat.flmoon(-1484,4 ) ;
  }

  @Test
  public void test20() {
    caldat.flmoon(157,3 ) ;
  }

  @Test
  public void test21() {
    caldat.flmoon(-161,1 ) ;
  }

  @Test
  public void test22() {
    caldat.flmoon(-1621,12 ) ;
  }

  @Test
  public void test23() {
    caldat.flmoon(-169,674 ) ;
  }

  @Test
  public void test24() {
    caldat.flmoon(182,864 ) ;
  }

  @Test
  public void test25() {
    caldat.flmoon(195,16 ) ;
  }

  @Test
  public void test26() {
    caldat.flmoon(227,2 ) ;
  }

  @Test
  public void test27() {
    caldat.flmoon(-2,3 ) ;
  }

  @Test
  public void test28() {
    caldat.flmoon(246,0 ) ;
  }

  @Test
  public void test29() {
    caldat.flmoon(-249,994 ) ;
  }

  @Test
  public void test30() {
    caldat.flmoon(-261,2 ) ;
  }

  @Test
  public void test31() {
    caldat.flmoon(277,3 ) ;
  }

  @Test
  public void test32() {
    caldat.flmoon(296,24 ) ;
  }

  @Test
  public void test33() {
    caldat.flmoon(-302,-40 ) ;
  }

  @Test
  public void test34() {
    caldat.flmoon(421,3 ) ;
  }

  @Test
  public void test35() {
    caldat.flmoon(-422,-223 ) ;
  }

  @Test
  public void test36() {
    caldat.flmoon(-441,1 ) ;
  }

  @Test
  public void test37() {
    caldat.flmoon(-491,6 ) ;
  }

  @Test
  public void test38() {
    caldat.flmoon(517,2 ) ;
  }

  @Test
  public void test39() {
    caldat.flmoon(526,0 ) ;
  }

  @Test
  public void test40() {
    caldat.flmoon(588,1 ) ;
  }

  @Test
  public void test41() {
    caldat.flmoon(593,1 ) ;
  }

  @Test
  public void test42() {
    caldat.flmoon(-664,3 ) ;
  }

  @Test
  public void test43() {
    caldat.flmoon(-756,0 ) ;
  }

  @Test
  public void test44() {
    caldat.flmoon(-787,2 ) ;
  }

  @Test
  public void test45() {
    caldat.flmoon(-913,0 ) ;
  }

  @Test
  public void test46() {
    caldat.flmoon(-995,-991 ) ;
  }
}
