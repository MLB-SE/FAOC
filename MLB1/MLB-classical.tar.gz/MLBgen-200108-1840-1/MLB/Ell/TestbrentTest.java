import org.junit.Test;

public class TestbrentTest {

  @Test
  public void test0() {
    ell.brent(0.0,0.0,0.0,0 ) ;
  }

  @Test
  public void test1() {
    ell.brent(-100.0,-100.0,-100.0,0 ) ;
  }

  @Test
  public void test2() {
    ell.brent(11.724445985025753,-51.53003246882133,12.068464334631713,0 ) ;
  }

  @Test
  public void test3() {
    ell.brent(12.164508363690315,0,12.164508363690317,0 ) ;
  }

  @Test
  public void test4() {
    ell.brent(13.06584443906762,0.0,-64.79069316211144,0 ) ;
  }

  @Test
  public void test5() {
    ell.brent(13.379353615997651,0.44447084284004745,13.379353615997651,0 ) ;
  }

  @Test
  public void test6() {
    ell.brent(15.491581084473331,0,15.491581084473333,0 ) ;
  }

  @Test
  public void test7() {
    ell.brent(15.756068589349454,83.42542623692557,98.21528691458593,0 ) ;
  }

  @Test
  public void test8() {
    ell.brent(20.55543315656169,0,36.93087527597751,0 ) ;
  }

  @Test
  public void test9() {
    ell.brent(23.5439465596389,0,23.543946559638904,0 ) ;
  }

  @Test
  public void test10() {
    ell.brent(2.4821590582015567,0.0,2.4821590582015567,0 ) ;
  }

  @Test
  public void test11() {
    ell.brent(25.910104254048207,-84.2908306176051,25.910104254048207,0 ) ;
  }

  @Test
  public void test12() {
    ell.brent(28.860013302347255,0,-3.441724872667521,0 ) ;
  }

  @Test
  public void test13() {
    ell.brent(-29.35615690353861,0.0,40.588320947743426,0 ) ;
  }

  @Test
  public void test14() {
    ell.brent(30.92742235593528,30.92742235593528,30.92742235593528,0 ) ;
  }

  @Test
  public void test15() {
    ell.brent(38.63777529349571,0.0,-68.4749302116697,0 ) ;
  }

  @Test
  public void test16() {
    ell.brent(4.282826298910166,0.0,4.282826298910166,0 ) ;
  }

  @Test
  public void test17() {
    ell.brent(-43.648462711950685,0,-36.26325937594228,0 ) ;
  }

  @Test
  public void test18() {
    ell.brent(-43.9731371889533,78.68777579480391,-51.92340305512773,0 ) ;
  }

  @Test
  public void test19() {
    ell.brent(45.58764622900995,-98.50033250432362,-99.80227813491811,0 ) ;
  }

  @Test
  public void test20() {
    ell.brent(48.13639852294334,0,48.13639852294333,0 ) ;
  }

  @Test
  public void test21() {
    ell.brent(4.934664515959334,29.00431336983319,53.07396222370705,0 ) ;
  }

  @Test
  public void test22() {
    ell.brent(-51.28807803003414,25.99665641320435,-0.9937423539393819,0 ) ;
  }

  @Test
  public void test23() {
    ell.brent(-53.442622200271316,-42.82457855482236,-95.27107062043736,0 ) ;
  }

  @Test
  public void test24() {
    ell.brent(-55.197538153400295,-82.0733360878237,62.13261403996722,0 ) ;
  }

  @Test
  public void test25() {
    ell.brent(-56.85795399853096,0,-56.85795399853096,0 ) ;
  }

  @Test
  public void test26() {
    ell.brent(58.655601143144644,0.0,-58.655601143144644,0 ) ;
  }

  @Test
  public void test27() {
    ell.brent(-59.88392876402316,0.0,59.88392876402316,0 ) ;
  }

  @Test
  public void test28() {
    ell.brent(63.11012712523478,0.0,7.677975326956485,0 ) ;
  }

  @Test
  public void test29() {
    ell.brent(-65.44858429608395,-50.96646426467783,-65.44858429608395,0 ) ;
  }

  @Test
  public void test30() {
    ell.brent(-70.329722358101,-9.242734537618198,51.8442532828646,0 ) ;
  }

  @Test
  public void test31() {
    ell.brent(-71.69359509881824,0,-71.69359509881824,0 ) ;
  }

  @Test
  public void test32() {
    ell.brent(7.2191963455135095,-17.03964632773807,7.2191963455135095,0 ) ;
  }

  @Test
  public void test33() {
    ell.brent(78.15694027566468,0,78.15694027566467,0 ) ;
  }

  @Test
  public void test34() {
    ell.brent(78.37147868893436,62.46763221956934,46.56378575020432,0 ) ;
  }

  @Test
  public void test35() {
    ell.brent(-7.852071363646703,0,-7.8520713636467026,0 ) ;
  }

  @Test
  public void test36() {
    ell.brent(79.53164604727766,-23.41926610329483,5.952782977139165,0 ) ;
  }

  @Test
  public void test37() {
    ell.brent(-8.100875582563802,0.0,-8.100875582563802,0 ) ;
  }

  @Test
  public void test38() {
    ell.brent(81.8099765848466,39.66242923267532,82.98552878539417,0 ) ;
  }

  @Test
  public void test39() {
    ell.brent(8.543839707600085,0.0,82.22853016125285,0 ) ;
  }

  @Test
  public void test40() {
    ell.brent(86.14100896487372,0,-77.83370864251307,0 ) ;
  }

  @Test
  public void test41() {
    ell.brent(-9.005507627871026,1.8683459526305057,-9.005507627871026,0 ) ;
  }

  @Test
  public void test42() {
    ell.brent(-90.78321486183899,0.0,24.548651379284742,0 ) ;
  }

  @Test
  public void test43() {
    ell.brent(9.325846937992356,-17.26640638810585,-43.85865971420406,0 ) ;
  }

  @Test
  public void test44() {
    ell.brent(93.88186498851766,37.1601403393222,26.532952362333944,0 ) ;
  }

  @Test
  public void test45() {
    ell.brent(98.55198986427004,70.56468936791873,-54.79425883249396,0 ) ;
  }

  @Test
  public void test46() {
    ell.brent(-99.10696112430544,-54.20347148254094,-30.487370877647763,0 ) ;
  }

  @Test
  public void test47() {
    ell.brent(99.4568461914649,94.40793251094087,99.4568461914649,0 ) ;
  }
}
