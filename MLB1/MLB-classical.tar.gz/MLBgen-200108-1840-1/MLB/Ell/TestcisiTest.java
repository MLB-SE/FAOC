import org.junit.Test;

public class TestcisiTest {

  @Test
  public void test0() {
    frenel.cisi(-0.08035979943390714 ) ;
  }

  @Test
  public void test1() {
    frenel.cisi(1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2() {
    frenel.cisi(-1.127343748604262 ) ;
  }

  @Test
  public void test3() {
    frenel.cisi(-12.137377988019637 ) ;
  }

  @Test
  public void test4() {
    frenel.cisi(-12.284833200514726 ) ;
  }

  @Test
  public void test5() {
    frenel.cisi(12.953221294529811 ) ;
  }

  @Test
  public void test6() {
    frenel.cisi(-18.998013177317645 ) ;
  }

  @Test
  public void test7() {
    frenel.cisi(1.9999999999999996 ) ;
  }

  @Test
  public void test8() {
    frenel.cisi(2.0 ) ;
  }

  @Test
  public void test9() {
    frenel.cisi(2.220446049250313E-16 ) ;
  }

  @Test
  public void test10() {
    frenel.cisi(-2.3361567350778785 ) ;
  }

  @Test
  public void test11() {
    frenel.cisi(42.621097113294326 ) ;
  }

  @Test
  public void test12() {
    frenel.cisi(-5.551115123125783E-17 ) ;
  }

  @Test
  public void test13() {
    frenel.cisi(5.584189132767165 ) ;
  }

  @Test
  public void test14() {
    frenel.cisi(-7.490682167507517E-96 ) ;
  }

  @Test
  public void test15() {
    frenel.cisi(7.490682167507517E-96 ) ;
  }

  @Test
  public void test16() {
    frenel.cisi(-76.92714239333154 ) ;
  }

  @Test
  public void test17() {
    frenel.cisi(-84.95561915598961 ) ;
  }

  @Test
  public void test18() {
    frenel.cisi(88.47887965547287 ) ;
  }

  @Test
  public void test19() {
    frenel.cisi(8.881784197001252E-16 ) ;
  }

  @Test
  public void test20() {
    frenel.cisi(9.860761315262648E-32 ) ;
  }
}
