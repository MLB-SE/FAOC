import org.junit.Test;

public class TestplgndrTest {

  @Test
  public void test0() {
    plgndr.plgndr(0,-1,0 ) ;
  }

  @Test
  public void test1() {
    plgndr.plgndr(0,-33,0 ) ;
  }

  @Test
  public void test2() {
    plgndr.plgndr(0,-370,0 ) ;
  }

  @Test
  public void test3() {
    plgndr.plgndr(0,806,0 ) ;
  }

  @Test
  public void test4() {
    plgndr.plgndr(-1,0,0 ) ;
  }

  @Test
  public void test5() {
    plgndr.plgndr(186,979,0 ) ;
  }

  @Test
  public void test6() {
    plgndr.plgndr(-223,100,0 ) ;
  }

  @Test
  public void test7() {
    plgndr.plgndr(-251,-251,0 ) ;
  }

  @Test
  public void test8() {
    plgndr.plgndr(-319,1,0 ) ;
  }

  @Test
  public void test9() {
    plgndr.plgndr(394,92,0.9886922921755996 ) ;
  }

  @Test
  public void test10() {
    plgndr.plgndr(441,219,1.0000000033828298 ) ;
  }

  @Test
  public void test11() {
    plgndr.plgndr(480,121,0.0 ) ;
  }

  @Test
  public void test12() {
    plgndr.plgndr(487,353,0.0 ) ;
  }

  @Test
  public void test13() {
    plgndr.plgndr(489,372,-23.686912652186322 ) ;
  }

  @Test
  public void test14() {
    plgndr.plgndr(546,134,1.0 ) ;
  }

  @Test
  public void test15() {
    plgndr.plgndr(612,255,-0.9400405297990254 ) ;
  }

  @Test
  public void test16() {
    plgndr.plgndr(-623,0,0 ) ;
  }

  @Test
  public void test17() {
    plgndr.plgndr(675,342,0.0 ) ;
  }

  @Test
  public void test18() {
    plgndr.plgndr(-726,934,0 ) ;
  }

  @Test
  public void test19() {
    plgndr.plgndr(743,-967,0 ) ;
  }

  @Test
  public void test20() {
    plgndr.plgndr(769,144,-1.0 ) ;
  }

  @Test
  public void test21() {
    plgndr.plgndr(-774,0,0 ) ;
  }

  @Test
  public void test22() {
    plgndr.plgndr(778,78,-49.41054902709596 ) ;
  }

  @Test
  public void test23() {
    plgndr.plgndr(815,300,27.47821511851241 ) ;
  }

  @Test
  public void test24() {
    plgndr.plgndr(819,595,0 ) ;
  }

  @Test
  public void test25() {
    plgndr.plgndr(879,70,1.3780698293532225 ) ;
  }

  @Test
  public void test26() {
    plgndr.plgndr(-977,-978,0 ) ;
  }

  @Test
  public void test27() {
    plgndr.plgndr(991,-605,0 ) ;
  }
}
