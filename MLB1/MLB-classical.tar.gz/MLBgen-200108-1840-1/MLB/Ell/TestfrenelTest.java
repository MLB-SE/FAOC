import org.junit.Test;

public class TestfrenelTest {

  @Test
  public void test0() {
    frenel.frenel(0.6848921406330106 ) ;
  }

  @Test
  public void test1() {
    frenel.frenel(1.0673309406676337 ) ;
  }

  @Test
  public void test2() {
    frenel.frenel(-1.17809727244686 ) ;
  }

  @Test
  public void test3() {
    frenel.frenel(-1.485908669103381 ) ;
  }

  @Test
  public void test4() {
    frenel.frenel(-1.4875748454706184 ) ;
  }

  @Test
  public void test5() {
    frenel.frenel(1.5 ) ;
  }

  @Test
  public void test6() {
    frenel.frenel(1.5407439555097887E-33 ) ;
  }

  @Test
  public void test7() {
    frenel.frenel(-2.465190328815662E-32 ) ;
  }

  @Test
  public void test8() {
    frenel.frenel(-2.966786668075841 ) ;
  }

  @Test
  public void test9() {
    frenel.frenel(32.15542336851743 ) ;
  }

  @Test
  public void test10() {
    frenel.frenel(3.958356925897718 ) ;
  }

  @Test
  public void test11() {
    frenel.frenel(4.8148248609680896E-35 ) ;
  }

  @Test
  public void test12() {
    frenel.frenel(-5.360167511807589 ) ;
  }

  @Test
  public void test13() {
    frenel.frenel(62.75976717606403 ) ;
  }

  @Test
  public void test14() {
    frenel.frenel(-80.60348800528614 ) ;
  }

  @Test
  public void test15() {
    frenel.frenel(84.18661067172741 ) ;
  }

  @Test
  public void test16() {
    frenel.frenel(-8.881784197001252E-16 ) ;
  }

  @Test
  public void test17() {
    frenel.frenel(8.881784197001252E-16 ) ;
  }

  @Test
  public void test18() {
    frenel.frenel(-92.3712811655627 ) ;
  }

  @Test
  public void test19() {
    frenel.frenel(-94.10229416766649 ) ;
  }
}
