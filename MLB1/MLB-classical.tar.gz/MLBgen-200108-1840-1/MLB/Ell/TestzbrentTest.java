import org.junit.Test;

public class TestzbrentTest {

  @Test
  public void test0() {
    ell.zbrent(-12.065718810277058,-34.55751918948773,0 ) ;
  }

  @Test
  public void test1() {
    ell.zbrent(13.004687612016767,25.0415931603614,0 ) ;
  }

  @Test
  public void test2() {
    ell.zbrent(144.51326206544,5.621393580067561,0 ) ;
  }

  @Test
  public void test3() {
    ell.zbrent(1.7475463045740014,-59.69026041820607,0 ) ;
  }

  @Test
  public void test4() {
    ell.zbrent(18.84955592153876,60.87792069257118,0 ) ;
  }

  @Test
  public void test5() {
    ell.zbrent(-20.952423931171055,43.98229715025842,0 ) ;
  }

  @Test
  public void test6() {
    ell.zbrent(-21.569514338017612,-1.6543612251060553E-24,0 ) ;
  }

  @Test
  public void test7() {
    ell.zbrent(-21.752482898366466,-26.74417994261185,0 ) ;
  }

  @Test
  public void test8() {
    ell.zbrent(-23.31367192757439,25.132741228718345,0 ) ;
  }

  @Test
  public void test9() {
    ell.zbrent(-30.162761035695624,56.548667764616276,0 ) ;
  }

  @Test
  public void test10() {
    ell.zbrent(-36.00754527832748,0,0 ) ;
  }

  @Test
  public void test11() {
    ell.zbrent(-36.59540215055124,46.55580996481214,0 ) ;
  }

  @Test
  public void test12() {
    ell.zbrent(39.385887805416075,75.39822368615503,0 ) ;
  }

  @Test
  public void test13() {
    ell.zbrent(-40.27539261972317,-12.939666540013974,0 ) ;
  }

  @Test
  public void test14() {
    ell.zbrent(-42.295487852138656,-30.315476652345083,0 ) ;
  }

  @Test
  public void test15() {
    ell.zbrent(47.53893148196275,0,0 ) ;
  }

  @Test
  public void test16() {
    ell.zbrent(4.793332518029229,-59.69026041820607,0 ) ;
  }

  @Test
  public void test17() {
    ell.zbrent(-50.2042324342989,10.767839006193825,0 ) ;
  }

  @Test
  public void test18() {
    ell.zbrent(-52.36635939860176,9.424777960769381,0 ) ;
  }

  @Test
  public void test19() {
    ell.zbrent(56.10446016478175,-3.141592653589793,0 ) ;
  }

  @Test
  public void test20() {
    ell.zbrent(-56.54866776461628,0,0 ) ;
  }

  @Test
  public void test21() {
    ell.zbrent(64.79152051413345,34.55751918948773,0 ) ;
  }

  @Test
  public void test22() {
    ell.zbrent(-69.11503837897546,0,0 ) ;
  }

  @Test
  public void test23() {
    ell.zbrent(76.86444721032001,-28.27433388230814,0 ) ;
  }

  @Test
  public void test24() {
    ell.zbrent(-8.137814778863245,21.02923342096419,0 ) ;
  }

  @Test
  public void test25() {
    ell.zbrent(83.96444389883612,-68.78097879261969,0 ) ;
  }

  @Test
  public void test26() {
    ell.zbrent(91.10618695410399,0,0 ) ;
  }

  @Test
  public void test27() {
    ell.zbrent(-9.411743754999364,0,0 ) ;
  }

  @Test
  public void test28() {
    ell.zbrent(98.56597220870361,31.882818778499086,0 ) ;
  }

  @Test
  public void test29() {
    ell.zbrent(-99.1234243281163,-65.06459048743467,0 ) ;
  }
}
