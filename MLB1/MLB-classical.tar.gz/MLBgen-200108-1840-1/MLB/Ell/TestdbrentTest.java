import org.junit.Test;

public class TestdbrentTest {

  @Test
  public void test0() {
    ell.dbrent(0.0,0.0,0.0,0 ) ;
  }

  @Test
  public void test1() {
    ell.dbrent(0.14570849035670866,0.0,0.14570849035670866,0 ) ;
  }

  @Test
  public void test2() {
    ell.dbrent(100.0,90.82810837050927,100.0,0 ) ;
  }

  @Test
  public void test3() {
    ell.dbrent(-12.972357327675027,-79.24916538162054,96.1196870770255,0 ) ;
  }

  @Test
  public void test4() {
    ell.dbrent(13.16995577263799,-24.674776924378094,13.16995577263799,0 ) ;
  }

  @Test
  public void test5() {
    ell.dbrent(-1.3282673173218267,0,-1.328267317321827,0 ) ;
  }

  @Test
  public void test6() {
    ell.dbrent(-13.823520232526107,-10.53233017776627,-77.0751795119271,0 ) ;
  }

  @Test
  public void test7() {
    ell.dbrent(-16.804104647225273,0.0,40.07098438161538,0 ) ;
  }

  @Test
  public void test8() {
    ell.dbrent(17.787803514066216,0,17.787803514066216,0 ) ;
  }

  @Test
  public void test9() {
    ell.dbrent(-19.450704886728097,-10.86629655773578,-19.450704886728097,0 ) ;
  }

  @Test
  public void test10() {
    ell.dbrent(-20.171331671976464,0,-20.17133167197646,0 ) ;
  }

  @Test
  public void test11() {
    ell.dbrent(20.529111191404482,3.734161654331089,66.79141464201317,0 ) ;
  }

  @Test
  public void test12() {
    ell.dbrent(-21.488331835337,0,-21.488331835337,0 ) ;
  }

  @Test
  public void test13() {
    ell.dbrent(23.92341718336634,0.0,-78.16890669304328,0 ) ;
  }

  @Test
  public void test14() {
    ell.dbrent(24.980838202872846,24.131037513936363,23.281236824999887,0 ) ;
  }

  @Test
  public void test15() {
    ell.dbrent(25.006799071819287,-49.297911436395346,-16.083354142856777,0 ) ;
  }

  @Test
  public void test16() {
    ell.dbrent(27.653314820985322,41.63207750364903,55.61084018631273,0 ) ;
  }

  @Test
  public void test17() {
    ell.dbrent(-34.2800442019768,0.0,-34.2800442019768,0 ) ;
  }

  @Test
  public void test18() {
    ell.dbrent(3.4353088220167827,0.0,3.4353088220167827,0 ) ;
  }

  @Test
  public void test19() {
    ell.dbrent(36.194272083372724,0.0,-47.0889645408708,0 ) ;
  }

  @Test
  public void test20() {
    ell.dbrent(36.46846007363226,67.4433273465938,36.46846007363226,0 ) ;
  }

  @Test
  public void test21() {
    ell.dbrent(-42.266448343150664,-63.411903389828,-84.55735843650533,0 ) ;
  }

  @Test
  public void test22() {
    ell.dbrent(42.398092348458384,18.224876642177605,42.398092348458384,0 ) ;
  }

  @Test
  public void test23() {
    ell.dbrent(42.77661577631818,-28.163349240777194,-41.33851215406585,0 ) ;
  }

  @Test
  public void test24() {
    ell.dbrent(44.95789919144162,0,44.95789919144161,0 ) ;
  }

  @Test
  public void test25() {
    ell.dbrent(-4.5027780298353655,0.0,4.5027780298353655,0 ) ;
  }

  @Test
  public void test26() {
    ell.dbrent(-45.186804392451286,6.823761618045026,-2.8105129767576784,0 ) ;
  }

  @Test
  public void test27() {
    ell.dbrent(-4.99257021851966,1.110291770008459,-96.02351857952162,0 ) ;
  }

  @Test
  public void test28() {
    ell.dbrent(-50.12672250006714,0,-50.12672250006713,0 ) ;
  }

  @Test
  public void test29() {
    ell.dbrent(51.393804974351895,0,-7.2703731937920395,0 ) ;
  }

  @Test
  public void test30() {
    ell.dbrent(52.24210384248386,71.73923002981311,37.59786200212389,0 ) ;
  }

  @Test
  public void test31() {
    ell.dbrent(-5.262996144482045,-31.19081663913994,31.997890481441402,0 ) ;
  }

  @Test
  public void test32() {
    ell.dbrent(-56.70493214333525,-47.90332439284926,-54.6771192638152,0 ) ;
  }

  @Test
  public void test33() {
    ell.dbrent(-57.40265938523858,0.0,46.59430719604953,0 ) ;
  }

  @Test
  public void test34() {
    ell.dbrent(59.207669749004964,0.0,-19.29046214826741,0 ) ;
  }

  @Test
  public void test35() {
    ell.dbrent(-59.28019145787664,-0.27810797623999406,58.72397550539665,0 ) ;
  }

  @Test
  public void test36() {
    ell.dbrent(60.705930946895435,0.0,-60.705930946895435,0 ) ;
  }

  @Test
  public void test37() {
    ell.dbrent(-61.26755784098245,-86.56054622988471,-61.26755784098245,0 ) ;
  }

  @Test
  public void test38() {
    ell.dbrent(62.76823402488801,0,62.768234024888,0 ) ;
  }

  @Test
  public void test39() {
    ell.dbrent(70.42966277072273,0,70.42966277072271,0 ) ;
  }

  @Test
  public void test40() {
    ell.dbrent(-70.56525003739634,0.0,2.822087885179883,0 ) ;
  }

  @Test
  public void test41() {
    ell.dbrent(-72.18067883543978,11.943861775542615,50.41298005777088,0 ) ;
  }

  @Test
  public void test42() {
    ell.dbrent(-78.98139784607602,0,40.8459940545259,0 ) ;
  }

  @Test
  public void test43() {
    ell.dbrent(79.85458031470688,79.85458031470688,79.85458031470688,0 ) ;
  }

  @Test
  public void test44() {
    ell.dbrent(-86.63873593953828,-86.63873593953828,-86.63873593953828,0 ) ;
  }

  @Test
  public void test45() {
    ell.dbrent(94.70742778676659,56.89431270738402,19.081197628001448,0 ) ;
  }

  @Test
  public void test46() {
    ell.dbrent(95.6965009584429,0,-99.71499618309174,0 ) ;
  }

  @Test
  public void test47() {
    ell.dbrent(-98.47353632161493,0,-85.36759165375518,0 ) ;
  }
}
