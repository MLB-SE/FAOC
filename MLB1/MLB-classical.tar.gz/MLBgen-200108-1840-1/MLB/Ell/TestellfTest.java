import org.junit.Test;

public class TestellfTest {

  @Test
  public void test0() {
    ell.ellf(-125.66370613137839,0.8516835835985297 ) ;
  }

  @Test
  public void test1() {
    ell.ellf(12.566370625190686,-1.1123093250083609 ) ;
  }

  @Test
  public void test2() {
    ell.ellf(13.007718406565251,2.3410514166187353 ) ;
  }

  @Test
  public void test3() {
    ell.ellf(-139.8008730847906,-1.0 ) ;
  }

  @Test
  public void test4() {
    ell.ellf(-14.13716693411743,-0.9912104251276657 ) ;
  }

  @Test
  public void test5() {
    ell.ellf(18.78064445068634,13.981899925209575 ) ;
  }

  @Test
  public void test6() {
    ell.ellf(20.420352239706283,-0.9999999999999685 ) ;
  }

  @Test
  public void test7() {
    ell.ellf(25.149314208604626,-60.34194125655703 ) ;
  }

  @Test
  public void test8() {
    ell.ellf(-28.271133004744076,0.48162331206183673 ) ;
  }

  @Test
  public void test9() {
    ell.ellf(2.891570655870197,0.4311019463455068 ) ;
  }

  @Test
  public void test10() {
    ell.ellf(3.1415926458081533,1.3815404508526399 ) ;
  }

  @Test
  public void test11() {
    ell.ellf(-3.1415926564790446,0.9600414220922338 ) ;
  }

  @Test
  public void test12() {
    ell.ellf(-33.98617669367778,0.35050549309743273 ) ;
  }

  @Test
  public void test13() {
    ell.ellf(40.65174798118582,-34.98526780307543 ) ;
  }

  @Test
  public void test14() {
    ell.ellf(-40.840704496787474,38.780649668651876 ) ;
  }

  @Test
  public void test15() {
    ell.ellf(53.40707512000429,-1.9927692103898575 ) ;
  }

  @Test
  public void test16() {
    ell.ellf(-56.54862740242433,1.0000000626100842 ) ;
  }

  @Test
  public void test17() {
    ell.ellf(-59.69026039104207,-0.8683433086721082 ) ;
  }

  @Test
  public void test18() {
    ell.ellf(-59.69026042446307,1.344851116956666 ) ;
  }

  @Test
  public void test19() {
    ell.ellf(-62.455806621659995,-0.18778329923449633 ) ;
  }

  @Test
  public void test20() {
    ell.ellf(65.97344572541134,31.473221813327807 ) ;
  }

  @Test
  public void test21() {
    ell.ellf(69.1298451122178,67.53930961398068 ) ;
  }

  @Test
  public void test22() {
    ell.ellf(-72.2350779395198,-12.60296074429452 ) ;
  }

  @Test
  public void test23() {
    ell.ellf(72.25663102800657,1.0000035449782958 ) ;
  }

  @Test
  public void test24() {
    ell.ellf(-75.39819017117982,-3.1668491530641065E-4 ) ;
  }

  @Test
  public void test25() {
    ell.ellf(75.39822367677485,-41.8236572481939 ) ;
  }

  @Test
  public void test26() {
    ell.ellf(75.39822370088314,0.15565043327777062 ) ;
  }

  @Test
  public void test27() {
    ell.ellf(-75.97469074186367,30.88674815176654 ) ;
  }

  @Test
  public void test28() {
    ell.ellf(81.68140898381782,1.005467178310661 ) ;
  }

  @Test
  public void test29() {
    ell.ellf(81.68365841750335,0.9999999999861525 ) ;
  }

  @Test
  public void test30() {
    ell.ellf(86.39379797371932,0.924573179609826 ) ;
  }

  @Test
  public void test31() {
    ell.ellf(-86.80307875850511,41.18237369578921 ) ;
  }

  @Test
  public void test32() {
    ell.ellf(-87.9645943000139,-9.791974309768776 ) ;
  }

  @Test
  public void test33() {
    ell.ellf(88.04621301935597,5.242650904810262E-8 ) ;
  }

  @Test
  public void test34() {
    ell.ellf(-9.035070441618771,2.632147763657503 ) ;
  }

  @Test
  public void test35() {
    ell.ellf(-9.424777382799634,0.834625050406558 ) ;
  }

  @Test
  public void test36() {
    ell.ellf(-94.24777961211532,-2.3546091885358322 ) ;
  }

  @Test
  public void test37() {
    ell.ellf(94.24777965105507,0.9741924250533395 ) ;
  }

  @Test
  public void test38() {
    ell.ellf(-97.38937227784824,-0.4772489303859828 ) ;
  }
}
