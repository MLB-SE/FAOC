import org.junit.Test;

public class TestelleTest {

  @Test
  public void test0() {
    ell.elle(114.66813185595821,-0.9999999999999999 ) ;
  }

  @Test
  public void test1() {
    ell.elle(-12.566370614134902,-19.51945304275021 ) ;
  }

  @Test
  public void test2() {
    ell.elle(18.849556140525852,-1.0000010405055675 ) ;
  }

  @Test
  public void test3() {
    ell.elle(21.991148571592326,-15.673820746715641 ) ;
  }

  @Test
  public void test4() {
    ell.elle(25.13274121571032,-1.4162279269059506 ) ;
  }

  @Test
  public void test5() {
    ell.elle(-30.700319817398913,-1.5242149939419158 ) ;
  }

  @Test
  public void test6() {
    ell.elle(-3.1415926373324976,0.7775996106638736 ) ;
  }

  @Test
  public void test7() {
    ell.elle(-3.14159265126312,1.3434443327598586 ) ;
  }

  @Test
  public void test8() {
    ell.elle(-3.1431478339574865,-1.0000000000181906 ) ;
  }

  @Test
  public void test9() {
    ell.elle(-3.1865775514177996,22.237181842103368 ) ;
  }

  @Test
  public void test10() {
    ell.elle(37.74382135090303,-2.3413045149787592 ) ;
  }

  @Test
  public void test11() {
    ell.elle(37.9079236558961,-25.892786086170275 ) ;
  }

  @Test
  public void test12() {
    ell.elle(-40.84070446986587,0.32154646094120387 ) ;
  }

  @Test
  public void test13() {
    ell.elle(41.17290917735522,0.2879875844466824 ) ;
  }

  @Test
  public void test14() {
    ell.elle(42.939993348439344,-0.5068825635688385 ) ;
  }

  @Test
  public void test15() {
    ell.elle(-47.123889811844265,-1.004272497846127 ) ;
  }

  @Test
  public void test16() {
    ell.elle(48.69468612185903,1.0 ) ;
  }

  @Test
  public void test17() {
    ell.elle(51.32676375935904,29.584903270486194 ) ;
  }

  @Test
  public void test18() {
    ell.elle(53.172843842613545,-4.308574703639232 ) ;
  }

  @Test
  public void test19() {
    ell.elle(53.29156931265035,-8.676855000191619 ) ;
  }

  @Test
  public void test20() {
    ell.elle(54.977871437821385,0.18049068678892277 ) ;
  }

  @Test
  public void test21() {
    ell.elle(56.18204939098158,-1.0 ) ;
  }

  @Test
  public void test22() {
    ell.elle(56.54865914694743,-6.009608678405121E-4 ) ;
  }

  @Test
  public void test23() {
    ell.elle(6.283185295857083,1.0271362173329184 ) ;
  }

  @Test
  public void test24() {
    ell.elle(62.83185307168454,61.82230323990706 ) ;
  }

  @Test
  public void test25() {
    ell.elle(65.97344573183051,13.189020398468017 ) ;
  }

  @Test
  public void test26() {
    ell.elle(69.11504371781857,-1.0000000647666536 ) ;
  }

  @Test
  public void test27() {
    ell.elle(70.68583470087412,-0.07468777329030152 ) ;
  }

  @Test
  public void test28() {
    ell.elle(72.25663451719966,0.003412507853071567 ) ;
  }

  @Test
  public void test29() {
    ell.elle(73.8510943545956,-0.5381159270329254 ) ;
  }

  @Test
  public void test30() {
    ell.elle(74.17727763316452,-0.028323676340619386 ) ;
  }

  @Test
  public void test31() {
    ell.elle(-75.18372097632346,-4.4752564964474 ) ;
  }

  @Test
  public void test32() {
    ell.elle(79.79602032289,-52.21735883043333 ) ;
  }

  @Test
  public void test33() {
    ell.elle(84.82300115379145,-0.9289975337526432 ) ;
  }

  @Test
  public void test34() {
    ell.elle(87.96459430304026,-4.755096524315178 ) ;
  }

  @Test
  public void test35() {
    ell.elle(-9.42477794741297,1.0191961734344224 ) ;
  }

  @Test
  public void test36() {
    ell.elle(94.24777960769757,25.478052978252826 ) ;
  }

  @Test
  public void test37() {
    ell.elle(-94.24777961665765,1.2304417431797638 ) ;
  }

  @Test
  public void test38() {
    ell.elle(-97.38937226173297,-15.531515574317677 ) ;
  }
}
