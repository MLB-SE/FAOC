import org.junit.Test;

public class TestellpiTest {

  @Test
  public void test0() {
    ell.ellpi(0.0879992414131443,0,11.37841412405949 ) ;
  }

  @Test
  public void test1() {
    ell.ellpi(-100.0,0,1.0589312493506462 ) ;
  }

  @Test
  public void test2() {
    ell.ellpi(-10.773156216159535,0,38.44512339418469 ) ;
  }

  @Test
  public void test3() {
    ell.ellpi(15.01564038446115,0,0.1551087983221464 ) ;
  }

  @Test
  public void test4() {
    ell.ellpi(-15.707963319787298,0,-1.031109751828878 ) ;
  }

  @Test
  public void test5() {
    ell.ellpi(-172.78739855220616,0,3.6150500703393065E-5 ) ;
  }

  @Test
  public void test6() {
    ell.ellpi(-21.85855176224183,0,0.9999999999999986 ) ;
  }

  @Test
  public void test7() {
    ell.ellpi(21.991148559035974,0,0.5189933152349226 ) ;
  }

  @Test
  public void test8() {
    ell.ellpi(21.991148575417196,0,-34.7554675872814 ) ;
  }

  @Test
  public void test9() {
    ell.ellpi(22.073566645775728,0,-12.147008696456812 ) ;
  }

  @Test
  public void test10() {
    ell.ellpi(-25.016696591757665,0,-0.99733857314361 ) ;
  }

  @Test
  public void test11() {
    ell.ellpi(25.132741228056883,0,-2.5890344183769263 ) ;
  }

  @Test
  public void test12() {
    ell.ellpi(-28.27433384847279,0,1.0103004746076183 ) ;
  }

  @Test
  public void test13() {
    ell.ellpi(-28.274333887893718,0,-100.0 ) ;
  }

  @Test
  public void test14() {
    ell.ellpi(-29.845130204709402,0,0.7844848813663136 ) ;
  }

  @Test
  public void test15() {
    ell.ellpi(3.141592649487934,0,0.24067791288280027 ) ;
  }

  @Test
  public void test16() {
    ell.ellpi(-31.4159265367912,0,5.638920387269431 ) ;
  }

  @Test
  public void test17() {
    ell.ellpi(-37.631244164142096,0,14.745871653904654 ) ;
  }

  @Test
  public void test18() {
    ell.ellpi(-40.64840719915794,0,5.232469447181658 ) ;
  }

  @Test
  public void test19() {
    ell.ellpi(-43.980587950518824,0,0.6715075257983543 ) ;
  }

  @Test
  public void test20() {
    ell.ellpi(-50.26548245722352,0,-24.74929320762725 ) ;
  }

  @Test
  public void test21() {
    ell.ellpi(-54.977871437821385,0,-1.0 ) ;
  }

  @Test
  public void test22() {
    ell.ellpi(-56.548667766028956,0,1.6548391249807504 ) ;
  }

  @Test
  public void test23() {
    ell.ellpi(-58.119464091411174,0,0.8169016201382322 ) ;
  }

  @Test
  public void test24() {
    ell.ellpi(-6.283185319758981,0,-1.0004641162641144 ) ;
  }

  @Test
  public void test25() {
    ell.ellpi(6.283185371760016,0,0.9712308547454772 ) ;
  }

  @Test
  public void test26() {
    ell.ellpi(-62.89167551295497,0,1.0000000000000175 ) ;
  }

  @Test
  public void test27() {
    ell.ellpi(-70.68583468873263,0,-1.0000000000000002 ) ;
  }

  @Test
  public void test28() {
    ell.ellpi(-75.39822369401276,0,1.9492346641785805 ) ;
  }

  @Test
  public void test29() {
    ell.ellpi(78.53981635906615,0,-0.9750450176006671 ) ;
  }

  @Test
  public void test30() {
    ell.ellpi(78.54087648443425,0,1.000000000097408 ) ;
  }

  @Test
  public void test31() {
    ell.ellpi(-79.60716482895606,0,51.808872131101026 ) ;
  }

  @Test
  public void test32() {
    ell.ellpi(80.11061266412862,0,-1.0 ) ;
  }

  @Test
  public void test33() {
    ell.ellpi(-84.8230016599806,0,0.7965469363363735 ) ;
  }

  @Test
  public void test34() {
    ell.ellpi(-88.02190920442352,0,-1.8573908484564896 ) ;
  }

  @Test
  public void test35() {
    ell.ellpi(-91.10670789779724,0,-2.6848797366916138E-5 ) ;
  }

  @Test
  public void test36() {
    ell.ellpi(-92.39999635828251,0,-20.739420955610342 ) ;
  }

  @Test
  public void test37() {
    ell.ellpi(9.424777960832381,0,-2.5404370219040686 ) ;
  }

  @Test
  public void test38() {
    ell.ellpi(96.8147679907901,0,0.30424362835814645 ) ;
  }
}
