import org.junit.Test;

public class TestsncndnTest {

  @Test
  public void test0() {
    ell.sncndn(0,0.6263908010955377 ) ;
  }

  @Test
  public void test1() {
    ell.sncndn(0,0.9999999799999999 ) ;
  }

  @Test
  public void test2() {
    ell.sncndn(0,0.99999998 ) ;
  }

  @Test
  public void test3() {
    ell.sncndn(0,0.9999999932622505 ) ;
  }

  @Test
  public void test4() {
    ell.sncndn(0,0.9999999999999993 ) ;
  }

  @Test
  public void test5() {
    ell.sncndn(0,1.0000000000000002 ) ;
  }

  @Test
  public void test6() {
    ell.sncndn(0,1.0000000029221996 ) ;
  }

  @Test
  public void test7() {
    ell.sncndn(0,1.00000002 ) ;
  }

  @Test
  public void test8() {
    ell.sncndn(0,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test9() {
    ell.sncndn(0,2.465190328815662E-32 ) ;
  }

  @Test
  public void test10() {
    ell.sncndn(0,-33.8244150254892 ) ;
  }

  @Test
  public void test11() {
    ell.sncndn(0,-4.055045528973139 ) ;
  }

  @Test
  public void test12() {
    ell.sncndn(0,-46.05880818719872 ) ;
  }

  @Test
  public void test13() {
    ell.sncndn(0,46.34647658796351 ) ;
  }

  @Test
  public void test14() {
    ell.sncndn(0,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test15() {
    ell.sncndn(0,4.930380657631324E-32 ) ;
  }

  @Test
  public void test16() {
    ell.sncndn(0,-6.183530507512813 ) ;
  }

  @Test
  public void test17() {
    ell.sncndn(0,68.83071940893475 ) ;
  }

  @Test
  public void test18() {
    ell.sncndn(0,74.52273419133698 ) ;
  }

  @Test
  public void test19() {
    ell.sncndn(0,-77.17844425906813 ) ;
  }

  @Test
  public void test20() {
    ell.sncndn(0,8.881784197001252E-16 ) ;
  }

  @Test
  public void test21() {
    ell.sncndn(0,91.81971588069149 ) ;
  }
}
