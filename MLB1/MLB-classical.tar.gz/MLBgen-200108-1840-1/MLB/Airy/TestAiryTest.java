import org.junit.Test;

public class TestAiryTest {

  @Test
  public void test0() {
    airy.main_airy(-0.9816308962185616 ) ;
  }

  @Test
  public void test1() {
    airy.main_airy(-1.0806454419566534E-224 ) ;
  }

  @Test
  public void test2() {
    airy.main_airy(1.1102230246251565E-16 ) ;
  }

  @Test
  public void test3() {
    airy.main_airy(1.7290327071306454E-223 ) ;
  }

  @Test
  public void test4() {
    airy.main_airy(-3.0814879110195774E-33 ) ;
  }

  @Test
  public void test5() {
    airy.main_airy(4.440892098500626E-16 ) ;
  }

  @Test
  public void test6() {
    airy.main_airy(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test7() {
    airy.main_airy(4.930380657631324E-32 ) ;
  }

  @Test
  public void test8() {
    airy.main_airy(-4.931796221121402 ) ;
  }

  @Test
  public void test9() {
    airy.main_airy(-49.42701677378021 ) ;
  }

  @Test
  public void test10() {
    airy.main_airy(52.06872280753461 ) ;
  }

  @Test
  public void test11() {
    airy.main_airy(60.92734260875807 ) ;
  }

  @Test
  public void test12() {
    airy.main_airy(6.188743933623741 ) ;
  }

  @Test
  public void test13() {
    airy.main_airy(-70.00143191257742 ) ;
  }

  @Test
  public void test14() {
    airy.main_airy(80.36898033462072 ) ;
  }

  @Test
  public void test15() {
    airy.main_airy(-8.881784197001252E-16 ) ;
  }

  @Test
  public void test16() {
    airy.main_airy(-97.22685898280254 ) ;
  }

  @Test
  public void test17() {
    airy.main_airy(9.860761315262648E-32 ) ;
  }
}
