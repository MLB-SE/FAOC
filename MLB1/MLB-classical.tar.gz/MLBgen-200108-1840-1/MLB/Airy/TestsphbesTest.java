import org.junit.Test;

public class TestsphbesTest {

  @Test
  public void test0() {
    airy.sphbes(0,27.34952533648203 ) ;
  }

  @Test
  public void test1() {
    airy.sphbes(0,78.40244592115994 ) ;
  }

  @Test
  public void test2() {
    airy.sphbes(0,95.93452686106804 ) ;
  }

  @Test
  public void test3() {
    airy.sphbes(106,3.5E-323 ) ;
  }

  @Test
  public void test4() {
    airy.sphbes(1237,2.0000000000000004 ) ;
  }

  @Test
  public void test5() {
    airy.sphbes(1293,-2.2E-322 ) ;
  }

  @Test
  public void test6() {
    airy.sphbes(1380,0.0 ) ;
  }

  @Test
  public void test7() {
    airy.sphbes(148,0.0 ) ;
  }

  @Test
  public void test8() {
    airy.sphbes(-15,-32.68665568638944 ) ;
  }

  @Test
  public void test9() {
    airy.sphbes(155,71.83574230003157 ) ;
  }

  @Test
  public void test10() {
    airy.sphbes(-1,79.74112884214873 ) ;
  }

  @Test
  public void test11() {
    airy.sphbes(195,0 ) ;
  }

  @Test
  public void test12() {
    airy.sphbes(271,-45.790165810889505 ) ;
  }

  @Test
  public void test13() {
    airy.sphbes(2760,2.0000000000023386 ) ;
  }

  @Test
  public void test14() {
    airy.sphbes(-294,0.0 ) ;
  }

  @Test
  public void test15() {
    airy.sphbes(-30,0.0 ) ;
  }

  @Test
  public void test16() {
    airy.sphbes(314,37.68644150414758 ) ;
  }

  @Test
  public void test17() {
    airy.sphbes(-402,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test18() {
    airy.sphbes(-43,-15.161374864688511 ) ;
  }

  @Test
  public void test19() {
    airy.sphbes(-470,76.8346758762103 ) ;
  }

  @Test
  public void test20() {
    airy.sphbes(517,3.0E-323 ) ;
  }

  @Test
  public void test21() {
    airy.sphbes(-520,5.795656738316524 ) ;
  }

  @Test
  public void test22() {
    airy.sphbes(-521,0.0 ) ;
  }

  @Test
  public void test23() {
    airy.sphbes(527,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test24() {
    airy.sphbes(58,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test25() {
    airy.sphbes(597,-4.0474E-320 ) ;
  }

  @Test
  public void test26() {
    airy.sphbes(-640,2.0 ) ;
  }

  @Test
  public void test27() {
    airy.sphbes(656,53.4754182766701 ) ;
  }

  @Test
  public void test28() {
    airy.sphbes(689,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test29() {
    airy.sphbes(719,0.0 ) ;
  }

  @Test
  public void test30() {
    airy.sphbes(-732,26.49300996388766 ) ;
  }

  @Test
  public void test31() {
    airy.sphbes(-748,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test32() {
    airy.sphbes(-794,0 ) ;
  }

  @Test
  public void test33() {
    airy.sphbes(805,0.0 ) ;
  }

  @Test
  public void test34() {
    airy.sphbes(-840,0.5379096166170569 ) ;
  }

  @Test
  public void test35() {
    airy.sphbes(840,-41.7504284530257 ) ;
  }

  @Test
  public void test36() {
    airy.sphbes(-909,2.000000000000001 ) ;
  }

  @Test
  public void test37() {
    airy.sphbes(966,-48.75378766947096 ) ;
  }
}
