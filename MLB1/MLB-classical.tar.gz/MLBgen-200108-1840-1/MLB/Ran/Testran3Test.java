import org.junit.Test;

public class Testran3Test {

  @Test
  public void test0() {
    ran.ran3(0 ) ;
  }

  @Test
  public void test1() {
    ran.ran3(-26186 ) ;
  }

  @Test
  public void test2() {
    ran.ran3(26254 ) ;
  }

  @Test
  public void test3() {
    ran.ran3(-26261 ) ;
  }

  @Test
  public void test4() {
    ran.ran3(27443 ) ;
  }

  @Test
  public void test5() {
    ran.ran3(37 ) ;
  }

  @Test
  public void test6() {
    ran.ran3(-374 ) ;
  }

  @Test
  public void test7() {
    ran.ran3(401 ) ;
  }

  @Test
  public void test8() {
    ran.ran3(-410 ) ;
  }

  @Test
  public void test9() {
    ran.ran3(428 ) ;
  }

  @Test
  public void test10() {
    ran.ran3(-554 ) ;
  }

  @Test
  public void test11() {
    ran.ran3(933 ) ;
  }

  @Test
  public void test12() {
    ran.ran3(-949 ) ;
  }
}
