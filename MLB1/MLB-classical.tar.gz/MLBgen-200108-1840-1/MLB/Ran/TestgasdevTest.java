import org.junit.Test;

public class TestgasdevTest {

  @Test
  public void test0() {
    dev.gasdev(0 ) ;
  }

  @Test
  public void test1() {
    dev.gasdev(-1 ) ;
  }

  @Test
  public void test2() {
    dev.gasdev(1 ) ;
  }

  @Test
  public void test3() {
    dev.gasdev(-103 ) ;
  }

  @Test
  public void test4() {
    dev.gasdev(-42 ) ;
  }

  @Test
  public void test5() {
    dev.gasdev(-551 ) ;
  }

  @Test
  public void test6() {
    dev.gasdev(-626 ) ;
  }

  @Test
  public void test7() {
    dev.gasdev(775 ) ;
  }

  @Test
  public void test8() {
    dev.gasdev(900 ) ;
  }

  @Test
  public void test9() {
    dev.gasdev(974 ) ;
  }
}
