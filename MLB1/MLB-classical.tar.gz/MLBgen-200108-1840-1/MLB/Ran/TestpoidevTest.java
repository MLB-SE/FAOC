import org.junit.Test;

public class TestpoidevTest {

  @Test
  public void test0() {
    dev.poidev(-0.32144831449167555,0 ) ;
  }

  @Test
  public void test1() {
    dev.poidev(-0.9999999999999964,0 ) ;
  }

  @Test
  public void test2() {
    dev.poidev(-1.0,0 ) ;
  }

  @Test
  public void test3() {
    dev.poidev(-1.0000000000000018,0 ) ;
  }

  @Test
  public void test4() {
    dev.poidev(10.0,872 ) ;
  }

  @Test
  public void test5() {
    dev.poidev(-1.0,-1 ) ;
  }

  @Test
  public void test6() {
    dev.poidev(-1.0,-573 ) ;
  }

  @Test
  public void test7() {
    dev.poidev(-1.0,-634 ) ;
  }

  @Test
  public void test8() {
    dev.poidev(-1.0,790 ) ;
  }

  @Test
  public void test9() {
    dev.poidev(-1.0,940 ) ;
  }

  @Test
  public void test10() {
    dev.poidev(11.0,-1 ) ;
  }

  @Test
  public void test11() {
    dev.poidev(15.155025986140515,0 ) ;
  }

  @Test
  public void test12() {
    dev.poidev(15.479094000261824,0 ) ;
  }

  @Test
  public void test13() {
    dev.poidev(-17.278066226283897,0 ) ;
  }

  @Test
  public void test14() {
    dev.poidev(-1.9999999999999964,0 ) ;
  }

  @Test
  public void test15() {
    dev.poidev(2.0,-522 ) ;
  }

  @Test
  public void test16() {
    dev.poidev(2.0,-887 ) ;
  }

  @Test
  public void test17() {
    dev.poidev(-217.0,-146 ) ;
  }

  @Test
  public void test18() {
    dev.poidev(-604.0,389 ) ;
  }

  @Test
  public void test19() {
    dev.poidev(-64.0,-1 ) ;
  }

  @Test
  public void test20() {
    dev.poidev(72.22632630545337,0 ) ;
  }

  @Test
  public void test21() {
    dev.poidev(78.96960914644279,0 ) ;
  }

  @Test
  public void test22() {
    dev.poidev(8.0,0 ) ;
  }

  @Test
  public void test23() {
    dev.poidev(8.0,965 ) ;
  }

  @Test
  public void test24() {
    dev.poidev(-834.0,0 ) ;
  }

  @Test
  public void test25() {
    dev.poidev(-87.0,-812 ) ;
  }

  @Test
  public void test26() {
    dev.poidev(-900.0,29 ) ;
  }
}
