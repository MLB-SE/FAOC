import org.junit.Test;

public class TestbnldevTest {

  @Test
  public void test0() {
    dev.bnldev(0.0,27,0 ) ;
  }

  @Test
  public void test1() {
    dev.bnldev(0.0,57,0 ) ;
  }

  @Test
  public void test2() {
    dev.bnldev(1.0,29,0 ) ;
  }

  @Test
  public void test3() {
    dev.bnldev(1.0,-384,0 ) ;
  }

  @Test
  public void test4() {
    dev.bnldev(1.0,-776,0 ) ;
  }

  @Test
  public void test5() {
    dev.bnldev(1.0,92,0 ) ;
  }

  @Test
  public void test6() {
    dev.bnldev(-118.0,-178,0 ) ;
  }

  @Test
  public void test7() {
    dev.bnldev(1.2322712146106767,0,0 ) ;
  }

  @Test
  public void test8() {
    dev.bnldev(127.0,1,-842 ) ;
  }

  @Test
  public void test9() {
    dev.bnldev(170.0,10,660 ) ;
  }

  @Test
  public void test10() {
    dev.bnldev(345.0,20,0 ) ;
  }

  @Test
  public void test11() {
    dev.bnldev(371.0,-97,0 ) ;
  }

  @Test
  public void test12() {
    dev.bnldev(376.0,119,0 ) ;
  }

  @Test
  public void test13() {
    dev.bnldev(-4.0,-971,0 ) ;
  }

  @Test
  public void test14() {
    dev.bnldev(-511.0,-289,0 ) ;
  }

  @Test
  public void test15() {
    dev.bnldev(-541.0,20,102 ) ;
  }

  @Test
  public void test16() {
    dev.bnldev(-542.0,-489,0 ) ;
  }

  @Test
  public void test17() {
    dev.bnldev(567.0,343,0 ) ;
  }

  @Test
  public void test18() {
    dev.bnldev(-580.0,16,-211 ) ;
  }

  @Test
  public void test19() {
    dev.bnldev(-581.0,372,0 ) ;
  }

  @Test
  public void test20() {
    dev.bnldev(-584.0,59,0 ) ;
  }

  @Test
  public void test21() {
    dev.bnldev(-600.0,6,0 ) ;
  }

  @Test
  public void test22() {
    dev.bnldev(-660.0,25,0 ) ;
  }

  @Test
  public void test23() {
    dev.bnldev(709.0,588,0 ) ;
  }

  @Test
  public void test24() {
    dev.bnldev(789.0,-544,0 ) ;
  }

  @Test
  public void test25() {
    dev.bnldev(79.0,-119,0 ) ;
  }

  @Test
  public void test26() {
    dev.bnldev(-83.20507385226861,0,0 ) ;
  }

  @Test
  public void test27() {
    dev.bnldev(88.8112835959646,0,0 ) ;
  }

  @Test
  public void test28() {
    dev.bnldev(-897.0,717,0 ) ;
  }

  @Test
  public void test29() {
    dev.bnldev(908.0,25,0 ) ;
  }

  @Test
  public void test30() {
    dev.bnldev(-972.0,-730,0 ) ;
  }
}
