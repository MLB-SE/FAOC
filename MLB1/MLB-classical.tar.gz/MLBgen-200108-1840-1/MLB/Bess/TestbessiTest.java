import org.junit.Test;

public class TestbessiTest {

  @Test
  public void test0() {
    bess.bessi(1468,1.0966466062263829E-18 ) ;
  }

  @Test
  public void test1() {
    bess.bessi(-202,0.0 ) ;
  }

  @Test
  public void test2() {
    bess.bessi(215,41.7245568806006 ) ;
  }

  @Test
  public void test3() {
    bess.bessi(339,53.70896854243307 ) ;
  }

  @Test
  public void test4() {
    bess.bessi(48,0.0 ) ;
  }

  @Test
  public void test5() {
    bess.bessi(-527,68.91373590383282 ) ;
  }

  @Test
  public void test6() {
    bess.bessi(-531,-1.3365855159897504E-34 ) ;
  }

  @Test
  public void test7() {
    bess.bessi(606,0 ) ;
  }

  @Test
  public void test8() {
    bess.bessi(-687,-65.79231956522776 ) ;
  }

  @Test
  public void test9() {
    bess.bessi(705,-5.828060525444798 ) ;
  }

  @Test
  public void test10() {
    bess.bessi(725,-7.560296208806153E-9 ) ;
  }

  @Test
  public void test11() {
    bess.bessi(-810,-3.3834260550290316E-9 ) ;
  }

  @Test
  public void test12() {
    bess.bessi(-842,0 ) ;
  }

  @Test
  public void test13() {
    bess.bessi(-933,65.2870434836588 ) ;
  }
}
