import org.junit.Test;

public class TestbessjTest {

  @Test
  public void test0() {
    bess.bessj(1,-0.08137940413747526 ) ;
  }

  @Test
  public void test1() {
    bess.bessj(102,-19.741050670142187 ) ;
  }

  @Test
  public void test2() {
    bess.bessj(-1034,-2.5269841324701218E-175 ) ;
  }

  @Test
  public void test3() {
    bess.bessj(1,0.6161104025936746 ) ;
  }

  @Test
  public void test4() {
    bess.bessj(1,-1.0 ) ;
  }

  @Test
  public void test5() {
    bess.bessj(1,1.0 ) ;
  }

  @Test
  public void test6() {
    bess.bessj(120,0.0 ) ;
  }

  @Test
  public void test7() {
    bess.bessj(-1282,2.2761049594726433E-159 ) ;
  }

  @Test
  public void test8() {
    bess.bessj(-131,-99.2974612489638 ) ;
  }

  @Test
  public void test9() {
    bess.bessj(-1376,1.2634920662350609E-175 ) ;
  }

  @Test
  public void test10() {
    bess.bessj(1495,6.480399768838967E-162 ) ;
  }

  @Test
  public void test11() {
    bess.bessj(-1,76.88473681918643 ) ;
  }

  @Test
  public void test12() {
    bess.bessj(207,26.20293939033813 ) ;
  }

  @Test
  public void test13() {
    bess.bessj(2780,5.556896873712694E-163 ) ;
  }

  @Test
  public void test14() {
    bess.bessj(31,-6.185950354680898 ) ;
  }

  @Test
  public void test15() {
    bess.bessj(-34,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test16() {
    bess.bessj(342,0 ) ;
  }

  @Test
  public void test17() {
    bess.bessj(38,-38.0 ) ;
  }

  @Test
  public void test18() {
    bess.bessj(-386,0.0 ) ;
  }

  @Test
  public void test19() {
    bess.bessj(39,39.0 ) ;
  }

  @Test
  public void test20() {
    bess.bessj(4,-91.8313056326738 ) ;
  }

  @Test
  public void test21() {
    bess.bessj(-51,0 ) ;
  }

  @Test
  public void test22() {
    bess.bessj(-511,15.21249539405143 ) ;
  }

  @Test
  public void test23() {
    bess.bessj(536,-1.1113793747425387E-162 ) ;
  }

  @Test
  public void test24() {
    bess.bessj(54,0.0 ) ;
  }

  @Test
  public void test25() {
    bess.bessj(546,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test26() {
    bess.bessj(54,84.4856100703523 ) ;
  }

  @Test
  public void test27() {
    bess.bessj(56,0.0 ) ;
  }

  @Test
  public void test28() {
    bess.bessj(603,63.293290430064246 ) ;
  }

  @Test
  public void test29() {
    bess.bessj(-655,-17.67976966295383 ) ;
  }

  @Test
  public void test30() {
    bess.bessj(837,90.75720996763746 ) ;
  }

  @Test
  public void test31() {
    bess.bessj(-867,70.90155811623123 ) ;
  }

  @Test
  public void test32() {
    bess.bessj(878,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test33() {
    bess.bessj(-890,0.0 ) ;
  }

  @Test
  public void test34() {
    bess.bessj(915,-79.81382165046465 ) ;
  }

  @Test
  public void test35() {
    bess.bessj(-941,0.0 ) ;
  }

  @Test
  public void test36() {
    bess.bessj(-966,-52.32623718102523 ) ;
  }

  @Test
  public void test37() {
    bess.bessj(-990,6.37E-322 ) ;
  }
}
