import org.junit.Test;

public class TestdawsonTest {

  @Test
  public void test0() {
    dawson.dawson(-0.0014063782348863185 ) ;
  }

  @Test
  public void test1() {
    dawson.dawson(0.1999999999999993 ) ;
  }

  @Test
  public void test2() {
    dawson.dawson(0.2 ) ;
  }

  @Test
  public void test3() {
    dawson.dawson(0.20000000000000004 ) ;
  }

  @Test
  public void test4() {
    dawson.dawson(0.20000000000000007 ) ;
  }

  @Test
  public void test5() {
    dawson.dawson(-0.20000000000000018 ) ;
  }

  @Test
  public void test6() {
    dawson.dawson(0.20000000000000018 ) ;
  }

  @Test
  public void test7() {
    dawson.dawson(-0.39999999999999997 ) ;
  }

  @Test
  public void test8() {
    dawson.dawson(0.39999999999999997 ) ;
  }

  @Test
  public void test9() {
    dawson.dawson(0.4 ) ;
  }

  @Test
  public void test10() {
    dawson.dawson(-0.43628448284552457 ) ;
  }

  @Test
  public void test11() {
    dawson.dawson(-0.4612391313952954 ) ;
  }

  @Test
  public void test12() {
    dawson.dawson(-0.4981915354151676 ) ;
  }

  @Test
  public void test13() {
    dawson.dawson(-0.6143256550276223 ) ;
  }

  @Test
  public void test14() {
    dawson.dawson(0.6859947268317765 ) ;
  }

  @Test
  public void test15() {
    dawson.dawson(-0.6914355469058906 ) ;
  }

  @Test
  public void test16() {
    dawson.dawson(0.7205165327338452 ) ;
  }

  @Test
  public void test17() {
    dawson.dawson(0.7275681691591274 ) ;
  }

  @Test
  public void test18() {
    dawson.dawson(0.7563177658112923 ) ;
  }

  @Test
  public void test19() {
    dawson.dawson(0.7565780446357795 ) ;
  }

  @Test
  public void test20() {
    dawson.dawson(0.7999999999998406 ) ;
  }

  @Test
  public void test21() {
    dawson.dawson(-0.7999999999999996 ) ;
  }

  @Test
  public void test22() {
    dawson.dawson(-0.7999999999999999 ) ;
  }

  @Test
  public void test23() {
    dawson.dawson(0.9774610486750446 ) ;
  }

  @Test
  public void test24() {
    dawson.dawson(-10.02316123489561 ) ;
  }

  @Test
  public void test25() {
    dawson.dawson(1.0807286949030453E-9 ) ;
  }

  @Test
  public void test26() {
    dawson.dawson(-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test27() {
    dawson.dawson(-1.1996735789406952 ) ;
  }

  @Test
  public void test28() {
    dawson.dawson(13.51733161106607 ) ;
  }

  @Test
  public void test29() {
    dawson.dawson(-13.752665259048612 ) ;
  }

  @Test
  public void test30() {
    dawson.dawson(1.599999987875024 ) ;
  }

  @Test
  public void test31() {
    dawson.dawson(17.231062578017827 ) ;
  }

  @Test
  public void test32() {
    dawson.dawson(1.9553051422926302 ) ;
  }

  @Test
  public void test33() {
    dawson.dawson(-1.996133281729571 ) ;
  }

  @Test
  public void test34() {
    dawson.dawson(-20.17328122954855 ) ;
  }

  @Test
  public void test35() {
    dawson.dawson(21.255192290040043 ) ;
  }

  @Test
  public void test36() {
    dawson.dawson(-2.220446049250313E-16 ) ;
  }

  @Test
  public void test37() {
    dawson.dawson(-2.304148541265832 ) ;
  }

  @Test
  public void test38() {
    dawson.dawson(-2.3597312478689503 ) ;
  }

  @Test
  public void test39() {
    dawson.dawson(-2.557132317704891 ) ;
  }

  @Test
  public void test40() {
    dawson.dawson(-27.123491574713682 ) ;
  }

  @Test
  public void test41() {
    dawson.dawson(2.7727735673353546 ) ;
  }

  @Test
  public void test42() {
    dawson.dawson(-27.854312222743104 ) ;
  }

  @Test
  public void test43() {
    dawson.dawson(-28.047819336646086 ) ;
  }

  @Test
  public void test44() {
    dawson.dawson(28.743346481052555 ) ;
  }

  @Test
  public void test45() {
    dawson.dawson(-32.75918049162665 ) ;
  }

  @Test
  public void test46() {
    dawson.dawson(3.563866116170251 ) ;
  }

  @Test
  public void test47() {
    dawson.dawson(-3.5986914295654104 ) ;
  }

  @Test
  public void test48() {
    dawson.dawson(40.37084066695482 ) ;
  }

  @Test
  public void test49() {
    dawson.dawson(40.65948346770611 ) ;
  }

  @Test
  public void test50() {
    dawson.dawson(4.287465004233865 ) ;
  }

  @Test
  public void test51() {
    dawson.dawson(-4.2915748832153895 ) ;
  }

  @Test
  public void test52() {
    dawson.dawson(-4.307032652035521 ) ;
  }

  @Test
  public void test53() {
    dawson.dawson(-45.79498536209377 ) ;
  }

  @Test
  public void test54() {
    dawson.dawson(46.1429033163825 ) ;
  }

  @Test
  public void test55() {
    dawson.dawson(-4.744866429391806 ) ;
  }

  @Test
  public void test56() {
    dawson.dawson(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test57() {
    dawson.dawson(53.25360521504328 ) ;
  }

  @Test
  public void test58() {
    dawson.dawson(54.24217788978339 ) ;
  }

  @Test
  public void test59() {
    dawson.dawson(-59.62574152590776 ) ;
  }

  @Test
  public void test60() {
    dawson.dawson(6.194371636668606 ) ;
  }

  @Test
  public void test61() {
    dawson.dawson(6.277780627286859 ) ;
  }

  @Test
  public void test62() {
    dawson.dawson(-65.78952506323324 ) ;
  }

  @Test
  public void test63() {
    dawson.dawson(-77.16864037230862 ) ;
  }

  @Test
  public void test64() {
    dawson.dawson(-81.52007989378762 ) ;
  }

  @Test
  public void test65() {
    dawson.dawson(-81.53762440565062 ) ;
  }

  @Test
  public void test66() {
    dawson.dawson(-82.1345657081076 ) ;
  }

  @Test
  public void test67() {
    dawson.dawson(82.61798170555744 ) ;
  }

  @Test
  public void test68() {
    dawson.dawson(-90.54903266570491 ) ;
  }

  @Test
  public void test69() {
    dawson.dawson(94.27798996152433 ) ;
  }

  @Test
  public void test70() {
    dawson.dawson(94.93623138031884 ) ;
  }

  @Test
  public void test71() {
    dawson.dawson(97.06555903355346 ) ;
  }

  @Test
  public void test72() {
    dawson.dawson(97.22690992097239 ) ;
  }

  @Test
  public void test73() {
    dawson.dawson(9.73173329141268 ) ;
  }

  @Test
  public void test74() {
    dawson.dawson(-98.0807362180105 ) ;
  }

  @Test
  public void test75() {
    dawson.dawson(9.80853115818094 ) ;
  }
}
