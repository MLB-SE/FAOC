import org.junit.Test;

public class TestbesskTest {

  @Test
  public void test0() {
    bess.bessk(1213,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test1() {
    bess.bessk(-142,2.465190328815662E-32 ) ;
  }

  @Test
  public void test2() {
    bess.bessk(176,2.0 ) ;
  }

  @Test
  public void test3() {
    bess.bessk(-189,-75.78392318429758 ) ;
  }

  @Test
  public void test4() {
    bess.bessk(213,-22.31466068090282 ) ;
  }

  @Test
  public void test5() {
    bess.bessk(-262,0 ) ;
  }

  @Test
  public void test6() {
    bess.bessk(-272,-1.0E-323 ) ;
  }

  @Test
  public void test7() {
    bess.bessk(-305,2.0 ) ;
  }

  @Test
  public void test8() {
    bess.bessk(306,97.59057172929099 ) ;
  }

  @Test
  public void test9() {
    bess.bessk(341,1.9999999999999982 ) ;
  }

  @Test
  public void test10() {
    bess.bessk(377,2.0 ) ;
  }

  @Test
  public void test11() {
    bess.bessk(-413,19.201790253361395 ) ;
  }

  @Test
  public void test12() {
    bess.bessk(-416,13.154427510064508 ) ;
  }

  @Test
  public void test13() {
    bess.bessk(435,0.0 ) ;
  }

  @Test
  public void test14() {
    bess.bessk(-509,2.0 ) ;
  }

  @Test
  public void test15() {
    bess.bessk(-557,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test16() {
    bess.bessk(629,59.29975862143655 ) ;
  }

  @Test
  public void test17() {
    bess.bessk(650,3.5E-323 ) ;
  }

  @Test
  public void test18() {
    bess.bessk(-660,0.0 ) ;
  }

  @Test
  public void test19() {
    bess.bessk(691,-33.54370572653961 ) ;
  }

  @Test
  public void test20() {
    bess.bessk(698,1.9999999999999971 ) ;
  }

  @Test
  public void test21() {
    bess.bessk(744,0 ) ;
  }

  @Test
  public void test22() {
    bess.bessk(-752,-85.36656071353386 ) ;
  }

  @Test
  public void test23() {
    bess.bessk(-82,1.9105873876485155 ) ;
  }
}
