import org.junit.Test;

public class TestpythagTest {

  @Test
  public void test0() {
    dawson.pythag(0.0033488376862268925,0.0041975412192865125 ) ;
  }

  @Test
  public void test1() {
    dawson.pythag(-0.008289301425713992,-0.008291456883589711 ) ;
  }

  @Test
  public void test2() {
    dawson.pythag(0.026190043383128,-0.026190047537552125 ) ;
  }

  @Test
  public void test3() {
    dawson.pythag(-0.043393480635840066,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test4() {
    dawson.pythag(-0.0434615647789911,-0.04348269492319622 ) ;
  }

  @Test
  public void test5() {
    dawson.pythag(0.0455079882939054,0.04552874829382589 ) ;
  }

  @Test
  public void test6() {
    dawson.pythag(-0.16871046114868904,0.16957223168461674 ) ;
  }

  @Test
  public void test7() {
    dawson.pythag(1.1836520184018854E-6,1.1823354131909887E-6 ) ;
  }

  @Test
  public void test8() {
    dawson.pythag(11.841753966139072,-11.841753966139072 ) ;
  }

  @Test
  public void test9() {
    dawson.pythag(-12.812008169086369,0.0 ) ;
  }

  @Test
  public void test10() {
    dawson.pythag(-13.926685195863953,24.962823315958715 ) ;
  }

  @Test
  public void test11() {
    dawson.pythag(1.4094613861239753E-17,-1.4094613861239756E-17 ) ;
  }

  @Test
  public void test12() {
    dawson.pythag(1.557374211108995E-207,1.557374211108995E-207 ) ;
  }

  @Test
  public void test13() {
    dawson.pythag(1.5869271222450095E-16,7.888609052210118E-31 ) ;
  }

  @Test
  public void test14() {
    dawson.pythag(1.5924219408380846E-19,4.2351647362715017E-22 ) ;
  }

  @Test
  public void test15() {
    dawson.pythag(-15.925479015811234,17.657746833833855 ) ;
  }

  @Test
  public void test16() {
    dawson.pythag(17.52328259978144,23.17071226606086 ) ;
  }

  @Test
  public void test17() {
    dawson.pythag(-1.8665272370064378E-301,0.0 ) ;
  }

  @Test
  public void test18() {
    dawson.pythag(18.691372334734368,18.691372334734368 ) ;
  }

  @Test
  public void test19() {
    dawson.pythag(-19.07016643144364,-45.087180483619726 ) ;
  }

  @Test
  public void test20() {
    dawson.pythag(2.2250738585072014E-308,0.0 ) ;
  }

  @Test
  public void test21() {
    dawson.pythag(22.573383353527504,10.890538354824812 ) ;
  }

  @Test
  public void test22() {
    dawson.pythag(2.265508447259052E-18,-2.2680997958698893E-18 ) ;
  }

  @Test
  public void test23() {
    dawson.pythag(-2.3E-322,0.0 ) ;
  }

  @Test
  public void test24() {
    dawson.pythag(-24.492073571310286,24.492073571310286 ) ;
  }

  @Test
  public void test25() {
    dawson.pythag(-2.5221623892247607,0 ) ;
  }

  @Test
  public void test26() {
    dawson.pythag(-26.494259160930163,-26.494259160930163 ) ;
  }

  @Test
  public void test27() {
    dawson.pythag(-2.669316513110516,-23.256757211990504 ) ;
  }

  @Test
  public void test28() {
    dawson.pythag(-2.7367051315423225,34.08290693042838 ) ;
  }

  @Test
  public void test29() {
    dawson.pythag(2.7450186315693026,-2.7450186315693026 ) ;
  }

  @Test
  public void test30() {
    dawson.pythag(3.0846974273316917E-179,-3.4247021078256297E-195 ) ;
  }

  @Test
  public void test31() {
    dawson.pythag(-31.784899304136083,-31.784899304136083 ) ;
  }

  @Test
  public void test32() {
    dawson.pythag(31.93472423834106,-80.18694845520031 ) ;
  }

  @Test
  public void test33() {
    dawson.pythag(-3.4211388289180104E-49,1.7105694144590052E-49 ) ;
  }

  @Test
  public void test34() {
    dawson.pythag(-3.4247021078256297E-195,-3.4247021078256297E-195 ) ;
  }

  @Test
  public void test35() {
    dawson.pythag(-3.506894958413445E-192,3.506894958413445E-192 ) ;
  }

  @Test
  public void test36() {
    dawson.pythag(37.56349436420524,-88.57324715744113 ) ;
  }

  @Test
  public void test37() {
    dawson.pythag(-3.761581923299223E-37,3.761581923299224E-37 ) ;
  }

  @Test
  public void test38() {
    dawson.pythag(3.902814937971397E-17,-3.8505981145523994E-17 ) ;
  }

  @Test
  public void test39() {
    dawson.pythag(-41.41956080043816,16.381582648118382 ) ;
  }

  @Test
  public void test40() {
    dawson.pythag(43.15688889040922,-43.04428744784148 ) ;
  }

  @Test
  public void test41() {
    dawson.pythag(4.43323506049083,65.93077309810366 ) ;
  }

  @Test
  public void test42() {
    dawson.pythag(4.450147717014403E-308,0.0 ) ;
  }

  @Test
  public void test43() {
    dawson.pythag(-44.62634176754301,77.26589460086748 ) ;
  }

  @Test
  public void test44() {
    dawson.pythag(-45.13393674729561,0.0 ) ;
  }

  @Test
  public void test45() {
    dawson.pythag(4.819839730205768E-181,4.819839730205768E-181 ) ;
  }

  @Test
  public void test46() {
    dawson.pythag(-48.53315865735668,-55.9032973005992 ) ;
  }

  @Test
  public void test47() {
    dawson.pythag(48.89980236703707,0.0 ) ;
  }

  @Test
  public void test48() {
    dawson.pythag(-4.930380657631324E-32,9.802876235428937E-17 ) ;
  }

  @Test
  public void test49() {
    dawson.pythag(4.935515883708368E-178,-5.4795233725210076E-194 ) ;
  }

  @Test
  public void test50() {
    dawson.pythag(-50.624444333287414,0 ) ;
  }

  @Test
  public void test51() {
    dawson.pythag(5.070787843895985,98.65952985408333 ) ;
  }

  @Test
  public void test52() {
    dawson.pythag(54.38721781941072,87.7246230697705 ) ;
  }

  @Test
  public void test53() {
    dawson.pythag(-5.4738221262688167E-48,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test54() {
    dawson.pythag(-5.551115123125783E-17,-5.561957144850638E-17 ) ;
  }

  @Test
  public void test55() {
    dawson.pythag(58.90262727814014,0.0 ) ;
  }

  @Test
  public void test56() {
    dawson.pythag(59.451609602054475,-52.06065263528039 ) ;
  }

  @Test
  public void test57() {
    dawson.pythag(-63.65787387006827,63.65787387006827 ) ;
  }

  @Test
  public void test58() {
    dawson.pythag(63.793612291685605,0.0 ) ;
  }

  @Test
  public void test59() {
    dawson.pythag(69.36960112724074,34.89893732345101 ) ;
  }

  @Test
  public void test60() {
    dawson.pythag(69.58701527123425,69.58701527123425 ) ;
  }

  @Test
  public void test61() {
    dawson.pythag(-71.38707223319751,-6.230702960221464 ) ;
  }

  @Test
  public void test62() {
    dawson.pythag(74.45692472559475,-74.72102289006381 ) ;
  }

  @Test
  public void test63() {
    dawson.pythag(-7.490682167507517E-96,3.395124196020537E-80 ) ;
  }

  @Test
  public void test64() {
    dawson.pythag(77.66134274522013,-77.66134274522013 ) ;
  }

  @Test
  public void test65() {
    dawson.pythag(-79.78423688871841,79.78423688871841 ) ;
  }

  @Test
  public void test66() {
    dawson.pythag(80.29351930977055,80.29351930977055 ) ;
  }

  @Test
  public void test67() {
    dawson.pythag(-80.61224785407781,-36.27374756648551 ) ;
  }

  @Test
  public void test68() {
    dawson.pythag(-80.87359525426308,-80.87359525426308 ) ;
  }

  @Test
  public void test69() {
    dawson.pythag(-82.33387756232091,-25.60215809309163 ) ;
  }

  @Test
  public void test70() {
    dawson.pythag(86.35665513508695,-2.6502596097334674 ) ;
  }

  @Test
  public void test71() {
    dawson.pythag(-8.673617379884035E-19,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test72() {
    dawson.pythag(-93.26054055859936,0.0 ) ;
  }

  @Test
  public void test73() {
    dawson.pythag(9.495567745759799E-66,7.245341790187543E-50 ) ;
  }

  @Test
  public void test74() {
    dawson.pythag(-96.30724334203971,76.39258375739138 ) ;
  }

  @Test
  public void test75() {
    dawson.pythag(9.677645511661059E-5,1.0020897685312047E-4 ) ;
  }

  @Test
  public void test76() {
    dawson.pythag(-9.871031767461413E-178,1.0959046745042015E-193 ) ;
  }

  @Test
  public void test77() {
    dawson.pythag(98.8445244886401,0 ) ;
  }

  @Test
  public void test78() {
    dawson.pythag(-9.996990623070368E-164,-3.9484127069845653E-177 ) ;
  }
}
