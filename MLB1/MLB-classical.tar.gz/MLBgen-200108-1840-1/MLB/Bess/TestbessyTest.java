import org.junit.Test;

public class TestbessyTest {

  @Test
  public void test0() {
    bess.bessy(-17,59.075479581220605 ) ;
  }

  @Test
  public void test1() {
    bess.bessy(182,0 ) ;
  }

  @Test
  public void test2() {
    bess.bessy(-336,-49.17071561681219 ) ;
  }

  @Test
  public void test3() {
    bess.bessy(355,98.99359742436357 ) ;
  }

  @Test
  public void test4() {
    bess.bessy(387,0.0 ) ;
  }

  @Test
  public void test5() {
    bess.bessy(-396,8.0 ) ;
  }

  @Test
  public void test6() {
    bess.bessy(-430,0.0 ) ;
  }

  @Test
  public void test7() {
    bess.bessy(457,-60.81435678292835 ) ;
  }

  @Test
  public void test8() {
    bess.bessy(586,-27.47778332973661 ) ;
  }

  @Test
  public void test9() {
    bess.bessy(641,8.0 ) ;
  }

  @Test
  public void test10() {
    bess.bessy(-72,0 ) ;
  }

  @Test
  public void test11() {
    bess.bessy(-834,84.98330847712893 ) ;
  }
}
