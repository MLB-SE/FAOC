import org.junit.Test;

public class TestprobksTest {

  @Test
  public void test0() {
    dawson.probks(-15.740274253030975 ) ;
  }

  @Test
  public void test1() {
    dawson.probks(19.063062202634313 ) ;
  }

  @Test
  public void test2() {
    dawson.probks(-19.288910003949464 ) ;
  }

  @Test
  public void test3() {
    dawson.probks(19.291232621361306 ) ;
  }

  @Test
  public void test4() {
    dawson.probks(-19.293094802390815 ) ;
  }

  @Test
  public void test5() {
    dawson.probks(-19.300209045045833 ) ;
  }

  @Test
  public void test6() {
    dawson.probks(2.1661763282448305 ) ;
  }

  @Test
  public void test7() {
    dawson.probks(-34.525830596997125 ) ;
  }

  @Test
  public void test8() {
    dawson.probks(-37.79199016395882 ) ;
  }

  @Test
  public void test9() {
    dawson.probks(-4.490730585348416 ) ;
  }

  @Test
  public void test10() {
    dawson.probks(4.70159599497741 ) ;
  }

  @Test
  public void test11() {
    dawson.probks(-70.89257985026005 ) ;
  }

  @Test
  public void test12() {
    dawson.probks(-81.4161694155561 ) ;
  }

  @Test
  public void test13() {
    dawson.probks(-9.63545014954974 ) ;
  }

  @Test
  public void test14() {
    dawson.probks(-9.862700397462064 ) ;
  }
}
