import org.junit.Test;

public class JpfTargetMysinTest {

  @Test
  public void test0() {
    JpfTargetMysin.static_mysin(-0.12326458623488179 ) ;
  }

  @Test
  public void test1() {
    JpfTargetMysin.static_mysin(0.26293815860320535 ) ;
  }

  @Test
  public void test2() {
    JpfTargetMysin.static_mysin(-0.602498009080989 ) ;
  }

  @Test
  public void test3() {
    JpfTargetMysin.static_mysin(0.9882113160267049 ) ;
  }

  @Test
  public void test4() {
    JpfTargetMysin.static_mysin(1.2888850226692333E-4 ) ;
  }

  @Test
  public void test5() {
    JpfTargetMysin.static_mysin(-14.660419689118157 ) ;
  }

  @Test
  public void test6() {
    JpfTargetMysin.static_mysin(-152.4156062993376 ) ;
  }

  @Test
  public void test7() {
    JpfTargetMysin.static_mysin(161.1817743185386 ) ;
  }

  @Test
  public void test8() {
    JpfTargetMysin.static_mysin(-16.398416981531966 ) ;
  }

  @Test
  public void test9() {
    JpfTargetMysin.static_mysin(-173.77099535924293 ) ;
  }

  @Test
  public void test10() {
    JpfTargetMysin.static_mysin(-1.8790578273825008E-23 ) ;
  }

  @Test
  public void test11() {
    JpfTargetMysin.static_mysin(22.776546738526 ) ;
  }

  @Test
  public void test12() {
    JpfTargetMysin.static_mysin(2.455738012553965E-4 ) ;
  }

  @Test
  public void test13() {
    JpfTargetMysin.static_mysin(2.45967985360563E-4 ) ;
  }

  @Test
  public void test14() {
    JpfTargetMysin.static_mysin(-2.4755958788702965E-17 ) ;
  }

  @Test
  public void test15() {
    JpfTargetMysin.static_mysin(-2.617411238374847E-4 ) ;
  }

  @Test
  public void test16() {
    JpfTargetMysin.static_mysin(-2.8602870179206394E-4 ) ;
  }

  @Test
  public void test17() {
    JpfTargetMysin.static_mysin(-2.9118094494142923 ) ;
  }

  @Test
  public void test18() {
    JpfTargetMysin.static_mysin(-30.376971131106785 ) ;
  }

  @Test
  public void test19() {
    JpfTargetMysin.static_mysin(-36.712084084543804 ) ;
  }

  @Test
  public void test20() {
    JpfTargetMysin.static_mysin(42.70351842722451 ) ;
  }

  @Test
  public void test21() {
    JpfTargetMysin.static_mysin(4.429945726353182 ) ;
  }

  @Test
  public void test22() {
    JpfTargetMysin.static_mysin(48.936826995405056 ) ;
  }

  @Test
  public void test23() {
    JpfTargetMysin.static_mysin(-51.0757197709915 ) ;
  }

  @Test
  public void test24() {
    JpfTargetMysin.static_mysin(-54.19247327442393 ) ;
  }

  @Test
  public void test25() {
    JpfTargetMysin.static_mysin(-5.497787143782139 ) ;
  }

  @Test
  public void test26() {
    JpfTargetMysin.static_mysin(7.0685834705770345 ) ;
  }

  @Test
  public void test27() {
    JpfTargetMysin.static_mysin(-72.69359078907951 ) ;
  }

  @Test
  public void test28() {
    JpfTargetMysin.static_mysin(85.72184244878716 ) ;
  }

  @Test
  public void test29() {
    JpfTargetMysin.static_mysin(90.41496909764263 ) ;
  }
}
