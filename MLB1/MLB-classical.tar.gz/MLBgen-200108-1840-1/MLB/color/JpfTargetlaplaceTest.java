import org.junit.Test;

public class JpfTargetlaplaceTest {

  @Test
  public void test0() {
    color.laplace.solve(-0.078638166f,-69.22582f,30.78381f,-31.088728f,-61.457203f,0f,-13.5478945f,-23.10285f,-17.406301f ) ;
  }

  @Test
  public void test1() {
    color.laplace.solve(-0.30058655f,-100.0f,0f,-21.707993f,-79.093056f,37.2619f,-7.43833f,-8.045327f,94.327644f ) ;
  }

  @Test
  public void test2() {
    color.laplace.solve(0.70822984f,-94.50039f,94.30373f,-2.6666934f,-26.10708f,-17.33301f,14.732078f,61.595f,0f ) ;
  }

  @Test
  public void test3() {
    color.laplace.solve(0.72436506f,-7.8293486f,-38.137383f,-89.27319f,39.950893f,-14.886206f,-16.283295f,24.14001f,72.89245f ) ;
  }

  @Test
  public void test4() {
    color.laplace.solve(-11.106777f,-19.434385f,-4.34766f,7.411638f,23.772392f,46.600212f,16.980936f,60.512104f,3.752926f ) ;
  }

  @Test
  public void test5() {
    color.laplace.solve(1.1613383f,-100.0f,0f,-12.865626f,-50.03885f,-91.008194f,-2.5849955f,2.525644f,-10.411661f ) ;
  }

  @Test
  public void test6() {
    color.laplace.solve(11.676454f,-61.142033f,49.633614f,7.847847f,60.34487f,0f,-31.163324f,-9.601743f,0f ) ;
  }

  @Test
  public void test7() {
    color.laplace.solve(11.830308f,-57.229244f,0f,-0.13570328f,-5.145069f,69.58883f,-7.2280517f,-32.804157f,0f ) ;
  }

  @Test
  public void test8() {
    color.laplace.solve(11.913486f,-100.0f,0f,21.857365f,60.310387f,-35.641666f,15.205588f,38.964985f,80.34397f ) ;
  }

  @Test
  public void test9() {
    color.laplace.solve(-1.2103186f,44.145485f,0f,-90.50123f,-1.5601878f,0f,-25.065573f,-9.761057f,-44.607464f ) ;
  }

  @Test
  public void test10() {
    color.laplace.solve(12.187895f,-65.66306f,-75.339935f,14.414647f,-24.627022f,23.433065f,70.09771f,-70.69273f,-62.699875f ) ;
  }

  @Test
  public void test11() {
    color.laplace.solve(-1.257254f,55.487686f,0f,8.61863f,77.06679f,9.311281f,-41.33501f,-56.09758f,0f ) ;
  }

  @Test
  public void test12() {
    color.laplace.solve(-127.544815f,-38.879898f,0f,-7.3918552f,90.86686f,139.16937f,7.1643186f,35.356316f,43.4109f ) ;
  }

  @Test
  public void test13() {
    color.laplace.solve(-12.919373f,33.534863f,0f,20.640326f,85.57009f,-100.0f,9.910582f,19.002f,-19.472675f ) ;
  }

  @Test
  public void test14() {
    color.laplace.solve(13.049204f,-42.901608f,99.89985f,-5.10047f,-30.152298f,-64.51243f,-3.2987874f,-8.094679f,1.0723683f ) ;
  }

  @Test
  public void test15() {
    color.laplace.solve(13.406165f,-40.475037f,70.70663f,-5.9003057f,-74.101685f,8.390943f,37.094296f,-48.67958f,0f ) ;
  }

  @Test
  public void test16() {
    color.laplace.solve(13.634294f,-4.364691f,9.072392f,-41.07909f,-140.14214f,-59.314205f,0f,0f,0f ) ;
  }

  @Test
  public void test17() {
    color.laplace.solve(14.022037f,-49.177906f,-74.56671f,5.266053f,-40.67816f,-74.72776f,47.720337f,-44.073036f,-4.7545033f ) ;
  }

  @Test
  public void test18() {
    color.laplace.solve(-14.699936f,-83.048065f,0f,-75.75168f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test19() {
    color.laplace.solve(14.82466f,38.866825f,98.820435f,-79.568184f,-58.17779f,90.12942f,9.983323f,96.25548f,0f ) ;
  }

  @Test
  public void test20() {
    color.laplace.solve(-14.942958f,13.613944f,0f,-16.705215f,-73.75994f,24.09657f,21.882036f,-48.79843f,0f ) ;
  }

  @Test
  public void test21() {
    color.laplace.solve(-150.37231f,-113.55263f,0f,-87.87007f,-166.13795f,21.636547f,-34.95335f,-52.097466f,-7.684879f ) ;
  }

  @Test
  public void test22() {
    color.laplace.solve(-1.5278288f,-99.14627f,-69.31253f,-6.965259f,-23.047503f,12.657485f,-3.285713f,-6.178358f,1.6197817f ) ;
  }

  @Test
  public void test23() {
    color.laplace.solve(-15.505364f,-153.49037f,148.70393f,-8.524014f,-10.286212f,-55.50337f,-8.151596f,-24.039034f,-13.473385f ) ;
  }

  @Test
  public void test24() {
    color.laplace.solve(15.629528f,-12.898628f,-98.31612f,-24.583261f,-68.90793f,-6.188986f,-45.054646f,89.19401f,0f ) ;
  }

  @Test
  public void test25() {
    color.laplace.solve(-15.796397f,7.009206f,0f,-80.89689f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test26() {
    color.laplace.solve(15.822707f,-23.177181f,100.0f,-13.53199f,44.778923f,0f,4.5638757f,31.787493f,75.382385f ) ;
  }

  @Test
  public void test27() {
    color.laplace.solve(15.830322f,-42.501995f,-99.99999f,5.8232827f,1.6411717f,100.0f,5.8216376f,17.463268f,62.390263f ) ;
  }

  @Test
  public void test28() {
    color.laplace.solve(-15.986007f,-11.122975f,0f,-28.842503f,8.38547f,0f,-8.075471f,-3.4593787f,0f ) ;
  }

  @Test
  public void test29() {
    color.laplace.solve(-1.6101018f,54.61098f,0f,40.80782f,-49.70393f,0f,18.690401f,33.95378f,-32.419014f ) ;
  }

  @Test
  public void test30() {
    color.laplace.solve(16.10931f,35.380573f,-64.74365f,-70.94334f,-15.256958f,0f,50.550293f,0f,0f ) ;
  }

  @Test
  public void test31() {
    color.laplace.solve(16.368187f,-35.13574f,-100.0f,0.60848045f,-5.3785477f,47.844414f,-8.5557165f,-34.83135f,-15.990087f ) ;
  }

  @Test
  public void test32() {
    color.laplace.solve(-16.607824f,16.415709f,0f,-47.0253f,90.496475f,0f,17.525644f,82.85956f,0f ) ;
  }

  @Test
  public void test33() {
    color.laplace.solve(16.6406f,22.896702f,23.577797f,-56.3343f,-55.648766f,0f,-16.998077f,-11.658005f,26.014822f ) ;
  }

  @Test
  public void test34() {
    color.laplace.solve(-16.773514f,37.372257f,0f,20.963514f,13.109545f,21.185759f,87.51803f,75.081604f,0f ) ;
  }

  @Test
  public void test35() {
    color.laplace.solve(172.56271f,100.0f,0f,13.708496f,-45.82194f,0f,-5.2108984f,-34.55209f,-87.17552f ) ;
  }

  @Test
  public void test36() {
    color.laplace.solve(17.384844f,27.329376f,34.053318f,-57.789997f,-42.12066f,2.1378503f,-4.8596163f,0f,0f ) ;
  }

  @Test
  public void test37() {
    color.laplace.solve(-173.8902f,-15.659983f,44.839638f,-47.309612f,-1.4633102f,74.552734f,-14.46212f,-17.614435f,-51.84582f ) ;
  }

  @Test
  public void test38() {
    color.laplace.solve(17.45559f,-49.83071f,-65.298744f,19.653072f,14.068619f,0f,46.32218f,-73.25434f,0f ) ;
  }

  @Test
  public void test39() {
    color.laplace.solve(17.62927f,21.58027f,-42.217823f,-51.06319f,-10.234656f,0f,-91.86508f,21.234058f,0f ) ;
  }

  @Test
  public void test40() {
    color.laplace.solve(17.822878f,-1.8542397f,-100.0f,-26.854092f,-25.239248f,-46.748188f,-100.0f,-25.500368f,0f ) ;
  }

  @Test
  public void test41() {
    color.laplace.solve(18.12722f,69.36429f,0f,-15.485389f,-73.301025f,48.088223f,-6.7677517f,-11.585619f,33.7263f ) ;
  }

  @Test
  public void test42() {
    color.laplace.solve(18.14768f,-13.824958f,-94.11223f,-13.584321f,-79.33528f,100.0f,6.850321f,40.985603f,100.0f ) ;
  }

  @Test
  public void test43() {
    color.laplace.solve(19.236649f,-3.9880989f,-112.70298f,-18.597672f,-22.78799f,-115.43838f,-71.05965f,-42.394024f,0f ) ;
  }

  @Test
  public void test44() {
    color.laplace.solve(-19.705984f,-2.418538f,0f,-17.058592f,-58.06324f,34.591217f,9.534859f,55.198025f,39.4013f ) ;
  }

  @Test
  public void test45() {
    color.laplace.solve(19.711393f,31.724985f,72.80978f,-52.87941f,-65.62123f,29.876963f,-9.829105f,13.562986f,0f ) ;
  }

  @Test
  public void test46() {
    color.laplace.solve(-1.9725158f,-81.97357f,0f,80.146706f,-45.94701f,0f,42.65256f,0f,0f ) ;
  }

  @Test
  public void test47() {
    color.laplace.solve(2.0991116f,84.51787f,-14.57774f,19.410048f,49.18448f,6.7936516f,26.3566f,86.01636f,17.10349f ) ;
  }

  @Test
  public void test48() {
    color.laplace.solve(21.064575f,-17.401117f,25.241903f,1.6594216f,29.261578f,0f,-43.23667f,0f,0f ) ;
  }

  @Test
  public void test49() {
    color.laplace.solve(21.202906f,-114.49589f,-23.609047f,-4.434195f,-35.5533f,-14.167017f,-3.3863866f,-9.111352f,2.494279f ) ;
  }

  @Test
  public void test50() {
    color.laplace.solve(21.628893f,11.70325f,-79.49568f,-25.187263f,-136.47432f,0f,-14.749023f,-33.814583f,-51.60459f ) ;
  }

  @Test
  public void test51() {
    color.laplace.solve(21.762556f,-8.656235f,0f,-29.50536f,-121.537f,182.79869f,-18.248686f,-43.88433f,-35.673756f ) ;
  }

  @Test
  public void test52() {
    color.laplace.solve(-21.931091f,6.925225f,0f,-43.165306f,49.679935f,0f,-11.728393f,-3.748265f,67.1451f ) ;
  }

  @Test
  public void test53() {
    color.laplace.solve(22.476175f,-1.2652448f,-50.271446f,-8.830054f,39.057785f,-38.72105f,-96.85418f,1.220634f,0f ) ;
  }

  @Test
  public void test54() {
    color.laplace.solve(22.536545f,-25.57624f,0f,6.538543f,-8.216679f,0f,10.615159f,35.922092f,0f ) ;
  }

  @Test
  public void test55() {
    color.laplace.solve(22.677038f,-100.0f,0f,-3.5358963f,-58.42967f,-99.849625f,21.609045f,89.97208f,0f ) ;
  }

  @Test
  public void test56() {
    color.laplace.solve(22.84186f,41.92457f,0f,-97.55904f,22.821505f,0f,-3.802494f,82.34906f,6.4476333f ) ;
  }

  @Test
  public void test57() {
    color.laplace.solve(22.875378f,37.96444f,-28.56227f,-46.46293f,17.57867f,0f,-12.728836f,-17.265059f,0f ) ;
  }

  @Test
  public void test58() {
    color.laplace.solve(22.984318f,-100.0f,0f,-10.180642f,-71.37928f,30.531998f,7.672393f,40.870213f,-28.36704f ) ;
  }

  @Test
  public void test59() {
    color.laplace.solve(-22.991175f,-188.02847f,-33.89716f,-3.9357822f,70.05936f,-18.304f,-62.77876f,103.36898f,0f ) ;
  }

  @Test
  public void test60() {
    color.laplace.solve(23.119246f,59.03315f,-68.880356f,-66.55617f,59.561623f,0f,-23.701002f,-28.247835f,-3.0905793f ) ;
  }

  @Test
  public void test61() {
    color.laplace.solve(23.365873f,-47.81132f,27.57594f,-2.5910823f,-28.736357f,-47.158722f,-4.993846f,-17.384302f,40.71954f ) ;
  }

  @Test
  public void test62() {
    color.laplace.solve(23.446865f,-99.08656f,-93.97219f,-0.38371152f,-30.892382f,-56.21614f,5.9106708f,32.116898f,-100.0f ) ;
  }

  @Test
  public void test63() {
    color.laplace.solve(25.10219f,-5.0108647f,-84.17825f,5.419625f,-2.6598167f,-12.764989f,-0.7638739f,-8.475121f,-30.476793f ) ;
  }

  @Test
  public void test64() {
    color.laplace.solve(25.365026f,-1.7340763f,100.0f,3.1941793f,-46.113647f,0f,33.525337f,0f,0f ) ;
  }

  @Test
  public void test65() {
    color.laplace.solve(25.73503f,-9.222931f,0f,34.45788f,82.147736f,100.0f,29.948746f,85.337105f,0f ) ;
  }

  @Test
  public void test66() {
    color.laplace.solve(26.126993f,24.10593f,27.418688f,-19.597956f,-57.12196f,51.96362f,-47.39685f,-82.622955f,0f ) ;
  }

  @Test
  public void test67() {
    color.laplace.solve(-26.292004f,-41.34068f,25.963516f,-20.328691f,-44.731297f,-96.41864f,-10.291468f,-20.837177f,1.1130759f ) ;
  }

  @Test
  public void test68() {
    color.laplace.solve(26.658588f,56.486874f,-27.508299f,-49.852516f,-48.44404f,0f,-3.3886209f,36.29803f,0f ) ;
  }

  @Test
  public void test69() {
    color.laplace.solve(27.352308f,-100.0f,0f,16.38395f,90.81595f,-85.63409f,9.346231f,21.000977f,-16.158278f ) ;
  }

  @Test
  public void test70() {
    color.laplace.solve(27.363836f,44.010708f,-47.13502f,10.946904f,0.44074133f,-13.39853f,15.983041f,-39.796116f,-6.8998413f ) ;
  }

  @Test
  public void test71() {
    color.laplace.solve(-27.472277f,-100.0f,0f,-29.327251f,-97.665215f,38.28694f,7.8284903f,60.641212f,0f ) ;
  }

  @Test
  public void test72() {
    color.laplace.solve(27.767733f,0.10785718f,-38.39531f,10.963073f,8.529474f,3.7841349f,7.5567565f,19.263954f,45.00077f ) ;
  }

  @Test
  public void test73() {
    color.laplace.solve(28.1824f,69.07011f,0f,14.180355f,23.845488f,21.492064f,4.6935325f,4.5937753f,-10.163919f ) ;
  }

  @Test
  public void test74() {
    color.laplace.solve(28.23491f,17.694792f,-10.198536f,-4.755157f,-47.257202f,-4.5233974f,0.0016672442f,4.7618265f,66.30285f ) ;
  }

  @Test
  public void test75() {
    color.laplace.solve(28.790134f,17.507034f,-27.19329f,-2.3464992f,-32.388226f,-21.473757f,-5.787905f,-20.80512f,-45.044353f ) ;
  }

  @Test
  public void test76() {
    color.laplace.solve(28.857246f,46.04073f,47.59153f,-30.611742f,-20.372593f,-57.548244f,-10.682406f,-12.117883f,-17.416533f ) ;
  }

  @Test
  public void test77() {
    color.laplace.solve(28.904617f,25.09625f,-11.801518f,-9.477779f,-87.55009f,62.071793f,20.734348f,92.41517f,24.373482f ) ;
  }

  @Test
  public void test78() {
    color.laplace.solve(28.953724f,24.13194f,-28.03588f,-8.317048f,-25.18847f,-49.016056f,-37.033443f,2.9600236f,0f ) ;
  }

  @Test
  public void test79() {
    color.laplace.solve(29.13206f,34.929726f,65.97905f,-18.401491f,-55.392212f,35.66962f,3.394478f,96.624306f,0f ) ;
  }

  @Test
  public void test80() {
    color.laplace.solve(29.282846f,37.106487f,34.750042f,-19.9751f,-15.606936f,-6.165687f,-93.57631f,-73.39345f,-43.80585f ) ;
  }

  @Test
  public void test81() {
    color.laplace.solve(29.607271f,26.489155f,-40.758507f,-8.060066f,17.107851f,-27.473427f,-78.95539f,-10.946271f,0f ) ;
  }

  @Test
  public void test82() {
    color.laplace.solve(29.614666f,31.601763f,23.947952f,-13.1431f,-27.155563f,-75.321754f,-6.7542596f,-13.8739395f,-32.92016f ) ;
  }

  @Test
  public void test83() {
    color.laplace.solve(29.799372f,19.08504f,-5.075913f,0.11244988f,-48.383305f,12.574203f,19.033733f,18.74139f,0f ) ;
  }

  @Test
  public void test84() {
    color.laplace.solve(29.87986f,42.769337f,-8.642498f,-23.249897f,-30.859493f,-38.124832f,-92.01995f,18.585215f,0f ) ;
  }

  @Test
  public void test85() {
    color.laplace.solve(30.028858f,37.234764f,0f,-23.003527f,71.765816f,0f,-2.433443f,13.269755f,-12.520478f ) ;
  }

  @Test
  public void test86() {
    color.laplace.solve(30.215927f,4.818922f,25.072811f,16.044786f,18.463154f,7.0334187f,15.500068f,45.955486f,81.76156f ) ;
  }

  @Test
  public void test87() {
    color.laplace.solve(30.359465f,22.903118f,-34.420807f,-1.4652574f,27.11506f,76.33048f,-63.335556f,10.691895f,0f ) ;
  }

  @Test
  public void test88() {
    color.laplace.solve(30.476177f,38.83456f,3.631729f,-16.929852f,21.230333f,-25.801214f,-11.681492f,-29.796114f,0f ) ;
  }

  @Test
  public void test89() {
    color.laplace.solve(30.628134f,-9.66935f,-77.313736f,32.181885f,83.62304f,-100.0f,14.476367f,-100.0f,0f ) ;
  }

  @Test
  public void test90() {
    color.laplace.solve(30.795757f,1.6386564f,-12.181307f,21.544376f,-16.24229f,0f,-42.800343f,0f,0f ) ;
  }

  @Test
  public void test91() {
    color.laplace.solve(30.908316f,2.4186351f,99.99982f,21.21463f,41.24028f,100.0f,12.70992f,29.625051f,64.55f ) ;
  }

  @Test
  public void test92() {
    color.laplace.solve(31.025005f,23.125744f,-19.758934f,0.97427756f,-18.763094f,-43.109444f,18.113317f,71.47899f,-38.639175f ) ;
  }

  @Test
  public void test93() {
    color.laplace.solve(-31.033972f,-38.231224f,62.56295f,-29.837757f,-5.4107985f,35.765747f,-82.906265f,10.660043f,-39.931614f ) ;
  }

  @Test
  public void test94() {
    color.laplace.solve(31.246418f,24.705685f,12.99567f,0.2799845f,-45.419353f,-100.0f,15.292872f,0f,0f ) ;
  }

  @Test
  public void test95() {
    color.laplace.solve(31.296856f,28.501238f,0f,0.37056226f,-20.898531f,26.751493f,-0.91578925f,-4.0337195f,5.6794434f ) ;
  }

  @Test
  public void test96() {
    color.laplace.solve(31.405338f,49.97766f,86.228935f,-24.356306f,-17.723633f,-29.663313f,0f,0f,0f ) ;
  }

  @Test
  public void test97() {
    color.laplace.solve(31.408293f,-11.512103f,0f,27.020473f,-14.461511f,-70.46516f,91.13511f,-66.731804f,0f ) ;
  }

  @Test
  public void test98() {
    color.laplace.solve(31.420462f,18.53057f,100.0f,7.1512766f,8.910441f,64.89142f,-11.725796f,-54.05446f,-96.639f ) ;
  }

  @Test
  public void test99() {
    color.laplace.solve(31.636465f,26.44334f,-10.795615f,0.10252259f,-15.0674925f,-28.542389f,-16.15889f,-58.273438f,-88.30645f ) ;
  }

  @Test
  public void test100() {
    color.laplace.solve(31.702532f,33.01066f,17.045988f,-6.2005363f,-17.952217f,-60.084976f,-4.4445224f,-11.577553f,-23.913473f ) ;
  }

  @Test
  public void test101() {
    color.laplace.solve(31.783537f,6.887396f,27.696259f,15.290686f,22.651087f,56.80482f,6.7280335f,11.6214485f,17.106567f ) ;
  }

  @Test
  public void test102() {
    color.laplace.solve(31.931847f,12.170716f,-97.48317f,15.556671f,14.234183f,-71.68281f,16.060654f,48.685944f,0f ) ;
  }

  @Test
  public void test103() {
    color.laplace.solve(3.207471f,-32.7669f,-39.586582f,-2.2208955f,-20.860582f,-7.977007f,8.76953f,-40.477528f,28.539137f ) ;
  }

  @Test
  public void test104() {
    color.laplace.solve(32.434788f,37.6357f,-22.386929f,-7.8965497f,40.494934f,39.85284f,8.1908455f,44.526287f,0f ) ;
  }

  @Test
  public void test105() {
    color.laplace.solve(32.824615f,33.96758f,21.731012f,-2.6691113f,-18.685307f,-100.0f,-24.815756f,72.15377f,0f ) ;
  }

  @Test
  public void test106() {
    color.laplace.solve(32.843407f,21.076193f,-84.313286f,10.297434f,0.12688819f,-90.2358f,8.21944f,59.369728f,0f ) ;
  }

  @Test
  public void test107() {
    color.laplace.solve(-32.954735f,43.813675f,0f,-25.117844f,20.290789f,-86.17107f,-87.807434f,-44.543053f,0f ) ;
  }

  @Test
  public void test108() {
    color.laplace.solve(33.033283f,19.802208f,0f,24.241642f,-6.597458f,-37.943f,70.53075f,-32.49068f,0f ) ;
  }

  @Test
  public void test109() {
    color.laplace.solve(33.092068f,38.901726f,-77.48517f,-6.5334544f,100.0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test110() {
    color.laplace.solve(33.29555f,0.9960798f,13.579438f,32.185196f,-142.91711f,-173.41527f,93.496704f,0f,0f ) ;
  }

  @Test
  public void test111() {
    color.laplace.solve(33.33047f,-31.417109f,-60.77891f,64.739f,-50.733627f,0f,18.292791f,71.59036f,0f ) ;
  }

  @Test
  public void test112() {
    color.laplace.solve(33.707287f,30.03754f,7.7102566f,4.791605f,-21.267384f,-19.379025f,2.043015f,3.3804555f,32.74619f ) ;
  }

  @Test
  public void test113() {
    color.laplace.solve(33.79526f,49.720745f,25.441837f,-14.539695f,39.64588f,100.0f,-1.6205282f,8.057582f,-5.6195006f ) ;
  }

  @Test
  public void test114() {
    color.laplace.solve(-34.19505f,-6.8255634f,0f,-72.66169f,-92.59166f,0f,-30.746397f,-50.323902f,-77.95754f ) ;
  }

  @Test
  public void test115() {
    color.laplace.solve(34.27176f,25.436323f,-17.4143f,11.650717f,11.959936f,24.340405f,0.37116984f,-10.166038f,-59.96254f ) ;
  }

  @Test
  public void test116() {
    color.laplace.solve(34.36191f,42.588795f,44.582108f,-5.14115f,-8.588839f,-23.579063f,4.7228746f,24.032648f,99.99656f ) ;
  }

  @Test
  public void test117() {
    color.laplace.solve(34.424713f,40.49387f,98.02597f,-2.795018f,33.26058f,70.1439f,-78.865364f,55.722603f,0f ) ;
  }

  @Test
  public void test118() {
    color.laplace.solve(3.446293f,-64.872154f,100.0f,-21.342676f,-27.6815f,100.0f,-61.1355f,-100.0f,0f ) ;
  }

  @Test
  public void test119() {
    color.laplace.solve(34.503975f,-99.25826f,-91.07994f,20.631453f,-46.068523f,-34.334778f,94.090355f,-71.31249f,-47.89735f ) ;
  }

  @Test
  public void test120() {
    color.laplace.solve(34.883533f,22.721933f,-41.813354f,16.812197f,-53.04658f,-27.865421f,-2.4741127f,-26.708649f,-51.3139f ) ;
  }

  @Test
  public void test121() {
    color.laplace.solve(35.142338f,36.312393f,18.752226f,4.2569656f,-8.644995f,-71.3353f,-9.469481f,-37.408825f,0f ) ;
  }

  @Test
  public void test122() {
    color.laplace.solve(35.152954f,30.757132f,-23.778164f,9.854682f,11.653737f,100.0f,-7.3879623f,-39.406532f,72.86562f ) ;
  }

  @Test
  public void test123() {
    color.laplace.solve(35.474575f,28.114992f,-60.55829f,10.146642f,4.9674916f,-8.8230295f,0.14450091f,-9.568638f,20.298681f ) ;
  }

  @Test
  public void test124() {
    color.laplace.solve(35.66377f,15.75687f,6.3378015f,26.898201f,-78.97409f,47.076103f,24.168074f,69.77409f,0f ) ;
  }

  @Test
  public void test125() {
    color.laplace.solve(35.68874f,28.943344f,-16.513927f,13.811613f,-3.4014344f,-71.28323f,13.694121f,40.964874f,47.10696f ) ;
  }

  @Test
  public void test126() {
    color.laplace.solve(35.914524f,37.094864f,20.4021f,6.5632324f,-7.937168f,-66.618904f,-1.724426f,-8.787862f,-6.7056584f ) ;
  }

  @Test
  public void test127() {
    color.laplace.solve(-35.98715f,-100.0f,0f,34.901695f,41.675182f,15.715595f,12.606102f,15.522716f,7.8095775f ) ;
  }

  @Test
  public void test128() {
    color.laplace.solve(36.011635f,46.2558f,39.06719f,-2.2092614f,9.944365f,-61.958935f,0.14964814f,2.807854f,11.472966f ) ;
  }

  @Test
  public void test129() {
    color.laplace.solve(36.170967f,23.887291f,-6.2175555f,20.79658f,40.300663f,57.16933f,6.714686f,59.349457f,41.003864f ) ;
  }

  @Test
  public void test130() {
    color.laplace.solve(-36.29833f,-8.982068f,0f,53.248253f,-8.390782f,-100.0f,13.109143f,-0.8116767f,-7.965068f ) ;
  }

  @Test
  public void test131() {
    color.laplace.solve(36.62405f,18.500526f,-56.67314f,27.995678f,-5.948799f,-43.60676f,81.307465f,-26.684645f,0f ) ;
  }

  @Test
  public void test132() {
    color.laplace.solve(36.629078f,58.525394f,-58.496346f,-12.009089f,-14.098565f,-87.380066f,-70.56687f,-100.0f,0f ) ;
  }

  @Test
  public void test133() {
    color.laplace.solve(36.958225f,27.39496f,-64.17442f,20.43794f,7.7272234f,15.34882f,37.066315f,-32.272827f,33.61832f ) ;
  }

  @Test
  public void test134() {
    color.laplace.solve(37.027405f,-21.576912f,0f,12.951787f,-58.83151f,0f,-5.507035f,0f,0f ) ;
  }

  @Test
  public void test135() {
    color.laplace.solve(37.123077f,43.293793f,0.42168805f,5.198523f,18.236092f,6.206791f,-34.56508f,18.245258f,6.868062f ) ;
  }

  @Test
  public void test136() {
    color.laplace.solve(37.276356f,43.470417f,37.636257f,5.633116f,-1.0320802f,7.2495804f,-13.711814f,-60.481434f,0f ) ;
  }

  @Test
  public void test137() {
    color.laplace.solve(37.426174f,16.778418f,-53.792027f,32.926285f,-16.520477f,-20.819399f,0f,0f,0f ) ;
  }

  @Test
  public void test138() {
    color.laplace.solve(37.481937f,28.69964f,22.263678f,21.228117f,32.177486f,29.292143f,15.253039f,39.78404f,-30.98488f ) ;
  }

  @Test
  public void test139() {
    color.laplace.solve(37.504288f,50.04702f,-10.746745f,-0.029876517f,13.649784f,18.765226f,-51.273575f,-14.183232f,72.15786f ) ;
  }

  @Test
  public void test140() {
    color.laplace.solve(37.61467f,-100.0f,0f,36.400936f,91.82795f,-8.302364f,16.161135f,28.243597f,4.985308f ) ;
  }

  @Test
  public void test141() {
    color.laplace.solve(37.659176f,30.65795f,-60.457096f,19.978754f,45.42972f,100.0f,-3.1738799f,0f,0f ) ;
  }

  @Test
  public void test142() {
    color.laplace.solve(38.007996f,40.74388f,24.834524f,11.288099f,0.13299954f,-45.776413f,7.0114036f,16.757515f,79.25252f ) ;
  }

  @Test
  public void test143() {
    color.laplace.solve(38.08321f,28.859491f,10.246085f,23.47335f,-32.89133f,64.96964f,12.261452f,0f,0f ) ;
  }

  @Test
  public void test144() {
    color.laplace.solve(38.086018f,43.909595f,31.32319f,8.434472f,6.2291756f,-100.0f,-10.577303f,-50.743687f,-100.0f ) ;
  }

  @Test
  public void test145() {
    color.laplace.solve(38.47008f,36.526207f,46.806236f,17.354116f,-39.251823f,99.99902f,3.6304193f,-2.8324397f,24.291645f ) ;
  }

  @Test
  public void test146() {
    color.laplace.solve(38.520008f,42.07692f,21.878935f,12.003114f,7.9095383f,-99.99704f,1.5858436f,-5.6597395f,-32.13434f ) ;
  }

  @Test
  public void test147() {
    color.laplace.solve(38.691586f,46.77818f,52.12397f,7.988164f,-3.7028422f,54.60706f,-3.036087f,-20.132513f,0f ) ;
  }

  @Test
  public void test148() {
    color.laplace.solve(38.941654f,77.59199f,58.186863f,-21.825373f,-63.811646f,0f,-88.28113f,53.03523f,0f ) ;
  }

  @Test
  public void test149() {
    color.laplace.solve(-38.99065f,37.20774f,0f,-88.68072f,6.317638f,99.396454f,-29.192472f,-28.089174f,-89.481865f ) ;
  }

  @Test
  public void test150() {
    color.laplace.solve(38.997063f,12.217311f,6.7035003f,14.73266f,13.050127f,12.4494f,6.8834496f,12.801138f,30.043972f ) ;
  }

  @Test
  public void test151() {
    color.laplace.solve(-39.128403f,-54.45164f,0f,69.82764f,-25.877487f,0f,7.9856195f,66.54624f,0f ) ;
  }

  @Test
  public void test152() {
    color.laplace.solve(39.19432f,46.82585f,51.499718f,9.951424f,-3.390631f,-14.37458f,4.002006f,6.0566006f,-38.292446f ) ;
  }

  @Test
  public void test153() {
    color.laplace.solve(39.289116f,58.08551f,95.0065f,-0.92904574f,35.09193f,17.885298f,-78.09723f,65.325966f,-38.185654f ) ;
  }

  @Test
  public void test154() {
    color.laplace.solve(39.3642f,61.356216f,61.602196f,-3.899424f,44.45847f,60.43806f,-99.420364f,59.939022f,-80.1611f ) ;
  }

  @Test
  public void test155() {
    color.laplace.solve(39.45748f,40.8582f,7.8130007f,16.971725f,5.457376f,1.680324f,22.972048f,-37.680748f,62.0372f ) ;
  }

  @Test
  public void test156() {
    color.laplace.solve(39.485306f,83.93719f,163.5191f,-25.329453f,9.3022995f,-30.483192f,-149.5427f,9.483652f,-2.4769247f ) ;
  }

  @Test
  public void test157() {
    color.laplace.solve(39.48655f,44.40073f,26.086504f,13.545467f,18.315542f,26.866554f,-3.6202223f,-11.55058f,56.57891f ) ;
  }

  @Test
  public void test158() {
    color.laplace.solve(39.73998f,47.431625f,-26.080309f,11.528293f,10.303059f,-54.70564f,-3.929866f,-10.298903f,0f ) ;
  }

  @Test
  public void test159() {
    color.laplace.solve(39.927147f,-95.53108f,-32.819874f,4.8208466f,-21.499224f,6.112343f,0.8554617f,-1.3989998f,77.666336f ) ;
  }

  @Test
  public void test160() {
    color.laplace.solve(-3.9950829f,-52.531f,0f,97.96952f,25.67574f,0f,24.959555f,1.8687001f,1.77374f ) ;
  }

  @Test
  public void test161() {
    color.laplace.solve(40.017864f,40.95998f,24.471392f,19.11148f,-0.6493383f,-33.601654f,37.0774f,-29.067158f,0f ) ;
  }

  @Test
  public void test162() {
    color.laplace.solve(40.2029f,28.802595f,22.641342f,32.009f,-47.63386f,2.591627f,2.1462626f,-23.42395f,-28.3327f ) ;
  }

  @Test
  public void test163() {
    color.laplace.solve(40.420677f,46.51936f,21.042284f,15.163355f,24.614475f,-29.318151f,-4.3817344f,66.09334f,43.49725f ) ;
  }

  @Test
  public void test164() {
    color.laplace.solve(40.527298f,84.20446f,243.87494f,-22.61619f,42.063282f,76.93436f,-3.68938f,7.866263f,-6.6895356f ) ;
  }

  @Test
  public void test165() {
    color.laplace.solve(40.6027f,33.54377f,0f,26.901651f,-39.24962f,-51.28491f,8.080828f,5.4216585f,52.855427f ) ;
  }

  @Test
  public void test166() {
    color.laplace.solve(40.861996f,-37.292633f,0f,38.70926f,76.95268f,0f,20.834478f,44.62866f,80.72747f ) ;
  }

  @Test
  public void test167() {
    color.laplace.solve(40.902157f,-4.7711134f,81.63911f,68.37973f,-17.526197f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test168() {
    color.laplace.solve(41.337574f,30.90037f,-69.91453f,34.44992f,52.17843f,-78.2417f,44.283688f,33.43145f,0f ) ;
  }

  @Test
  public void test169() {
    color.laplace.solve(41.45589f,39.777134f,47.718685f,26.046429f,19.607231f,39.639137f,43.122597f,-27.033777f,91.23063f ) ;
  }

  @Test
  public void test170() {
    color.laplace.solve(41.481724f,50.337906f,35.28821f,15.588994f,24.58168f,66.7378f,-3.70743f,-30.418715f,0f ) ;
  }

  @Test
  public void test171() {
    color.laplace.solve(42.500957f,53.7958f,52.322502f,16.208035f,20.359734f,-100.0f,1.9714469f,-36.468002f,0f ) ;
  }

  @Test
  public void test172() {
    color.laplace.solve(42.830364f,46.564247f,24.584969f,24.757204f,18.841658f,16.291422f,37.356796f,-12.246245f,-100.0f ) ;
  }

  @Test
  public void test173() {
    color.laplace.solve(42.833656f,23.804367f,-32.762894f,47.530254f,-28.947596f,0f,33.86442f,0f,0f ) ;
  }

  @Test
  public void test174() {
    color.laplace.solve(42.836895f,55.36716f,57.18752f,15.980413f,21.444227f,-38.271976f,-0.35946745f,-17.418283f,0f ) ;
  }

  @Test
  public void test175() {
    color.laplace.solve(43.364895f,100.0f,-100.0f,-26.540415f,26.812023f,0f,3.0822554f,38.869434f,35.25445f ) ;
  }

  @Test
  public void test176() {
    color.laplace.solve(43.75488f,51.24634f,18.727755f,23.773174f,42.404587f,-64.94464f,8.933234f,11.959763f,-3.5787654f ) ;
  }

  @Test
  public void test177() {
    color.laplace.solve(43.881947f,55.066975f,100.0f,20.460808f,36.148003f,-30.096403f,1.8132849f,-13.207669f,0f ) ;
  }

  @Test
  public void test178() {
    color.laplace.solve(43.883022f,67.51357f,58.106407f,8.019503f,3.9307513f,11.15248f,-15.735765f,-70.96258f,-17.427265f ) ;
  }

  @Test
  public void test179() {
    color.laplace.solve(44.05104f,56.840576f,61.110397f,19.363594f,22.200861f,71.06627f,11.202474f,25.4463f,68.381874f ) ;
  }

  @Test
  public void test180() {
    color.laplace.solve(44.269726f,-98.04749f,0f,21.423067f,52.207394f,-92.79374f,-10.784852f,-64.56248f,0f ) ;
  }

  @Test
  public void test181() {
    color.laplace.solve(44.38042f,3.990676f,0f,33.537384f,30.720373f,90.50949f,59.048737f,-31.17529f,0f ) ;
  }

  @Test
  public void test182() {
    color.laplace.solve(44.65074f,64.384895f,75.25751f,14.331193f,5.943715f,-67.531296f,6.730315f,12.590067f,-41.702644f ) ;
  }

  @Test
  public void test183() {
    color.laplace.solve(44.829918f,65.218956f,83.65238f,14.100712f,32.393536f,6.5302587f,-20.820604f,43.72421f,0f ) ;
  }

  @Test
  public void test184() {
    color.laplace.solve(44.865456f,59.95776f,-1.5352237f,19.50406f,29.414412f,-99.75177f,3.7363734f,-4.558566f,23.396208f ) ;
  }

  @Test
  public void test185() {
    color.laplace.solve(45.048733f,53.951824f,-100.0f,13.799454f,6.69334f,-41.00143f,3.4557416f,0.023513025f,-10.054546f ) ;
  }

  @Test
  public void test186() {
    color.laplace.solve(45.05068f,93.05471f,95.98181f,-12.851997f,-86.151825f,-57.21248f,-10.306838f,-28.375357f,0f ) ;
  }

  @Test
  public void test187() {
    color.laplace.solve(45.11965f,57.15442f,90.97345f,23.324188f,-7.4754276f,-67.682365f,55.65253f,71.72201f,0f ) ;
  }

  @Test
  public void test188() {
    color.laplace.solve(-45.26552f,-53.68248f,-71.863396f,-13.03367f,-5.051532f,40.94398f,-1.8176311f,5.566041f,-12.300979f ) ;
  }

  @Test
  public void test189() {
    color.laplace.solve(45.333836f,58.786583f,56.324055f,22.548765f,33.488434f,-99.99998f,11.372788f,22.942389f,-10.287146f ) ;
  }

  @Test
  public void test190() {
    color.laplace.solve(45.508007f,4.9043064f,0f,-52.022324f,-55.715755f,0f,-69.01924f,41.81199f,0f ) ;
  }

  @Test
  public void test191() {
    color.laplace.solve(45.529644f,52.730522f,0f,-56.763462f,-32.01235f,0f,-5.594754f,34.384445f,0f ) ;
  }

  @Test
  public void test192() {
    color.laplace.solve(45.59207f,26.144896f,22.37622f,56.22339f,-83.60714f,0f,34.47784f,81.68797f,0f ) ;
  }

  @Test
  public void test193() {
    color.laplace.solve(45.630856f,40.427876f,-66.90732f,42.09555f,39.78821f,81.99826f,82.96313f,-5.368843f,43.05231f ) ;
  }

  @Test
  public void test194() {
    color.laplace.solve(-45.79693f,-61.375427f,-56.995758f,-14.817505f,-8.494457f,47.312145f,-4.978637f,-5.097043f,-19.77249f ) ;
  }

  @Test
  public void test195() {
    color.laplace.solve(46.024937f,-9.38137f,0f,-7.498533f,-99.67814f,-67.74016f,23.659075f,73.686844f,0f ) ;
  }

  @Test
  public void test196() {
    color.laplace.solve(46.033443f,63.339947f,-81.04011f,20.793835f,42.667206f,-44.481457f,11.072565f,23.496428f,40.245937f ) ;
  }

  @Test
  public void test197() {
    color.laplace.solve(46.86018f,37.612316f,50.88019f,49.828403f,-47.291115f,85.256195f,43.45637f,71.51372f,0f ) ;
  }

  @Test
  public void test198() {
    color.laplace.solve(47.33224f,63.14109f,64.16797f,26.187878f,41.064148f,15.317657f,16.35512f,-29.2739f,0f ) ;
  }

  @Test
  public void test199() {
    color.laplace.solve(47.520542f,61.445045f,12.064705f,28.637129f,41.834854f,5.1219034f,25.19312f,72.135345f,18.946344f ) ;
  }

  @Test
  public void test200() {
    color.laplace.solve(-48.10019f,-113.6612f,21.53382f,-27.44765f,-44.612583f,5.6286783f,-17.615068f,-43.012627f,45.52143f ) ;
  }

  @Test
  public void test201() {
    color.laplace.solve(48.351864f,-44.654255f,0f,96.2484f,95.02428f,0f,20.082994f,26.049606f,0f ) ;
  }

  @Test
  public void test202() {
    color.laplace.solve(-48.741257f,74.64084f,0f,26.158016f,-92.5587f,0f,92.756744f,20.82697f,0f ) ;
  }

  @Test
  public void test203() {
    color.laplace.solve(4.929644f,-99.99996f,-50.41374f,19.71854f,64.17248f,-75.93694f,9.772038f,19.369614f,3.5339358f ) ;
  }

  @Test
  public void test204() {
    color.laplace.solve(49.60975f,74.83146f,-43.31952f,23.548841f,24.638422f,-34.667534f,19.947199f,34.840923f,-81.25148f ) ;
  }

  @Test
  public void test205() {
    color.laplace.solve(49.65762f,69.04735f,86.35665f,29.583134f,24.717133f,24.644735f,43.95778f,-24.406685f,-12.49484f ) ;
  }

  @Test
  public void test206() {
    color.laplace.solve(49.78221f,57.086384f,-45.273434f,42.04246f,99.99482f,18.62305f,18.392813f,31.528788f,7.727517f ) ;
  }

  @Test
  public void test207() {
    color.laplace.solve(49.842922f,-61.808777f,-5.416074f,10.733482f,-16.752161f,-44.572525f,9.843165f,28.63918f,-34.449642f ) ;
  }

  @Test
  public void test208() {
    color.laplace.solve(49.978714f,-57.567005f,70.31573f,-2.3006217f,-37.681396f,-23.472313f,-21.499805f,-67.38564f,-57.81485f ) ;
  }

  @Test
  public void test209() {
    color.laplace.solve(5.0007052f,-3.6590052f,-79.03099f,-76.33817f,-40.605732f,-18.257929f,51.54964f,-70.310265f,0f ) ;
  }

  @Test
  public void test210() {
    color.laplace.solve(50.07868f,100.0f,99.613884f,0.31470907f,42.041523f,33.67736f,-90.86137f,34.174015f,-6.94596f ) ;
  }

  @Test
  public void test211() {
    color.laplace.solve(50.50295f,65.5023f,-75.42438f,36.427975f,-181.79587f,-79.141205f,5.5661926f,-15.108134f,115.96876f ) ;
  }

  @Test
  public void test212() {
    color.laplace.solve(50.510593f,66.59863f,-71.80625f,35.443737f,58.33125f,34.993935f,32.933105f,96.28869f,40.10082f ) ;
  }

  @Test
  public void test213() {
    color.laplace.solve(-51.28223f,-8.973874f,0f,85.47491f,-67.55989f,0f,-1.8959769f,-93.058815f,0f ) ;
  }

  @Test
  public void test214() {
    color.laplace.solve(-51.40036f,53.901283f,0f,-22.650352f,22.656527f,-19.533192f,-1.3830911f,17.117989f,47.198517f ) ;
  }

  @Test
  public void test215() {
    color.laplace.solve(5.156513f,-6.322017f,33.86041f,-73.051926f,-52.082935f,-11.882324f,-23.499874f,-20.94757f,-8.207474f ) ;
  }

  @Test
  public void test216() {
    color.laplace.solve(51.73148f,-54.527454f,0f,-55.354527f,-24.093004f,0f,55.358196f,0f,0f ) ;
  }

  @Test
  public void test217() {
    color.laplace.solve(51.812183f,-51.595417f,193.74672f,158.85556f,-76.49416f,0f,24.3626f,-61.455906f,0f ) ;
  }

  @Test
  public void test218() {
    color.laplace.solve(52.39153f,90.900024f,-71.92325f,18.666094f,44.281563f,42.204098f,-22.008718f,25.356041f,38.23798f ) ;
  }

  @Test
  public void test219() {
    color.laplace.solve(52.403877f,95.58735f,18.38546f,14.028156f,-27.422997f,81.8039f,31.131744f,-32.336765f,0f ) ;
  }

  @Test
  public void test220() {
    color.laplace.solve(53.112114f,66.01857f,78.35474f,46.429882f,32.60742f,99.69637f,100.0f,1.9152938f,0f ) ;
  }

  @Test
  public void test221() {
    color.laplace.solve(53.73579f,18.520636f,88.18399f,27.025507f,32.320107f,22.57527f,22.046131f,61.159016f,-30.203022f ) ;
  }

  @Test
  public void test222() {
    color.laplace.solve(54.149235f,53.37215f,-29.00973f,63.22479f,87.53506f,0f,9.311557f,-25.978565f,60.283062f ) ;
  }

  @Test
  public void test223() {
    color.laplace.solve(54.446373f,58.822926f,-45.393604f,58.96257f,88.34602f,0f,93.05788f,0f,0f ) ;
  }

  @Test
  public void test224() {
    color.laplace.solve(54.72871f,-35.816376f,-13.776022f,4.877573f,-31.969423f,-79.06533f,-3.248997f,-17.87356f,-36.27582f ) ;
  }

  @Test
  public void test225() {
    color.laplace.solve(54.84545f,115.08985f,0f,48.111237f,63.616302f,24.528982f,73.983185f,-71.78814f,0f ) ;
  }

  @Test
  public void test226() {
    color.laplace.solve(54.96443f,44.10219f,-38.455772f,75.75555f,59.900085f,56.587715f,-19.74371f,-38.85999f,0f ) ;
  }

  @Test
  public void test227() {
    color.laplace.solve(-55.137745f,73.63139f,-17.95577f,-19.681917f,-14.0006275f,-85.87157f,-9.5893f,-24.080423f,55.986103f ) ;
  }

  @Test
  public void test228() {
    color.laplace.solve(55.31802f,98.41906f,2.464395f,22.853025f,32.42649f,86.17142f,3.6675885f,-8.182671f,-58.237164f ) ;
  }

  @Test
  public void test229() {
    color.laplace.solve(55.872864f,89.77446f,-20.64091f,33.716995f,90.87322f,20.248262f,-11.8781f,-81.2294f,0f ) ;
  }

  @Test
  public void test230() {
    color.laplace.solve(55.98192f,47.887535f,0f,61.080437f,89.35956f,0f,12.103833f,-76.977806f,0f ) ;
  }

  @Test
  public void test231() {
    color.laplace.solve(56.34595f,84.43685f,0f,-40.97915f,43.286404f,0f,27.348068f,30.673483f,0f ) ;
  }

  @Test
  public void test232() {
    color.laplace.solve(58.150158f,66.39169f,0f,11.3422785f,-36.487614f,-77.93834f,23.706568f,-13.101223f,0f ) ;
  }

  @Test
  public void test233() {
    color.laplace.solve(59.13155f,-71.0009f,0f,45.86858f,59.25778f,0f,29.269588f,71.20977f,-3.9242177f ) ;
  }

  @Test
  public void test234() {
    color.laplace.solve(5.978412f,8.254955f,-61.21878f,-84.34131f,-11.739811f,85.60898f,-18.233397f,11.407722f,75.604095f ) ;
  }

  @Test
  public void test235() {
    color.laplace.solve(-5.984842f,-87.17789f,0f,-28.796364f,-94.11785f,75.97378f,-15.082767f,-31.5347f,-16.938187f ) ;
  }

  @Test
  public void test236() {
    color.laplace.solve(60.324722f,95.14242f,-52.323288f,46.15647f,1.0989585f,0f,33.192623f,36.728004f,0f ) ;
  }

  @Test
  public void test237() {
    color.laplace.solve(60.73082f,91.41745f,-65.58702f,51.50583f,66.15143f,12.8579235f,79.14107f,-77.54769f,0f ) ;
  }

  @Test
  public void test238() {
    color.laplace.solve(-61.281742f,24.13673f,0f,-34.26807f,-45.761463f,10.601763f,-30.029068f,56.192738f,0f ) ;
  }

  @Test
  public void test239() {
    color.laplace.solve(62.759644f,50.536777f,0f,-79.4379f,24.789387f,37.524067f,-18.699398f,4.640305f,12.4712305f ) ;
  }

  @Test
  public void test240() {
    color.laplace.solve(-6.30844f,31.84454f,0f,-2.0283184f,0.7627768f,87.22971f,-2.56761f,-8.242122f,97.6591f ) ;
  }

  @Test
  public void test241() {
    color.laplace.solve(63.12744f,-50.969345f,40.568924f,16.908878f,0.13228025f,33.995308f,4.375789f,0.59427834f,-35.040363f ) ;
  }

  @Test
  public void test242() {
    color.laplace.solve(-6.3796606f,-68.83151f,-34.359188f,-56.68713f,-37.64961f,0f,10.832055f,-80.49449f,0f ) ;
  }

  @Test
  public void test243() {
    color.laplace.solve(63.83912f,-48.46991f,-42.668865f,13.933817f,-9.196621f,7.3123565f,1.0927672f,-9.562747f,-30.147135f ) ;
  }

  @Test
  public void test244() {
    color.laplace.solve(-65.388504f,-33.52277f,0f,29.58213f,-46.943264f,-6.200808f,1.3499503f,-24.182327f,-51.135998f ) ;
  }

  @Test
  public void test245() {
    color.laplace.solve(65.398026f,-79.52989f,-30.259317f,37.48817f,11.277598f,38.99343f,73.27706f,48.158684f,75.608986f ) ;
  }

  @Test
  public void test246() {
    color.laplace.solve(-65.678185f,-13.108162f,-42.600006f,-22.501883f,-9.283926f,36.15415f,-15.045423f,-37.67981f,57.922047f ) ;
  }

  @Test
  public void test247() {
    color.laplace.solve(-65.96892f,-73.32587f,0f,-12.885335f,22.195593f,-10.343903f,-7.7680106f,-18.186708f,-87.174416f ) ;
  }

  @Test
  public void test248() {
    color.laplace.solve(-66.07828f,-46.58712f,26.659746f,-9.6432295f,1.8027883f,-10.313256f,25.702572f,73.75476f,41.12091f ) ;
  }

  @Test
  public void test249() {
    color.laplace.solve(-6.652062f,-59.908047f,0f,52.246098f,47.394417f,0f,21.040018f,31.913975f,59.221466f ) ;
  }

  @Test
  public void test250() {
    color.laplace.solve(67.18887f,47.07397f,99.941505f,20.705109f,9.917504f,-30.260136f,5.7140455f,2.1510735f,-7.0272655f ) ;
  }

  @Test
  public void test251() {
    color.laplace.solve(67.46589f,93.25334f,-52.611217f,76.61021f,-49.43414f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test252() {
    color.laplace.solve(67.88092f,-111.52923f,-49.9081f,29.48679f,28.645687f,96.595215f,21.420551f,100.0f,-149.46872f ) ;
  }

  @Test
  public void test253() {
    color.laplace.solve(69.72419f,-23.485313f,0f,31.342268f,81.63213f,0f,-25.987253f,0f,0f ) ;
  }

  @Test
  public void test254() {
    color.laplace.solve(-70.354805f,34.519176f,0f,-89.07295f,-49.97603f,0f,-64.55354f,-97.509636f,0f ) ;
  }

  @Test
  public void test255() {
    color.laplace.solve(70.993675f,-74.622215f,100.0f,21.767544f,-33.717136f,17.434467f,49.79364f,-99.44834f,3.4550061f ) ;
  }

  @Test
  public void test256() {
    color.laplace.solve(71.466736f,-19.707706f,0f,64.39798f,23.590921f,81.18156f,20.384195f,17.138802f,24.58009f ) ;
  }

  @Test
  public void test257() {
    color.laplace.solve(72.16809f,-31.467913f,0f,8.011832f,-13.566204f,7.250124f,-26.554564f,-14.614596f,0f ) ;
  }

  @Test
  public void test258() {
    color.laplace.solve(-72.39609f,-95.11104f,5.2572675f,-28.28414f,-33.53467f,-74.85175f,-7.205802f,64.10824f,36.84644f ) ;
  }

  @Test
  public void test259() {
    color.laplace.solve(-72.45647f,55.326504f,0f,8.224765f,57.20075f,0f,48.154774f,0f,0f ) ;
  }

  @Test
  public void test260() {
    color.laplace.solve(72.98236f,-24.158073f,0f,42.210953f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test261() {
    color.laplace.solve(73.45768f,-100.0f,0f,9.312351f,-36.410587f,17.286737f,0.20231546f,-8.50309f,2.195912f ) ;
  }

  @Test
  public void test262() {
    color.laplace.solve(74.107254f,27.836226f,-71.52206f,23.98625f,13.354688f,-8.349725f,8.483062f,9.945998f,17.946245f ) ;
  }

  @Test
  public void test263() {
    color.laplace.solve(74.42661f,22.981314f,0f,3.7753425f,-2.0890212f,0.104133114f,-57.23622f,-90.727715f,0f ) ;
  }

  @Test
  public void test264() {
    color.laplace.solve(75.0f,100.0f,-99.98206f,100.0f,-9.659899f,0f,32.68934f,30.75736f,100.0f ) ;
  }

  @Test
  public void test265() {
    color.laplace.solve(77.357475f,19.544352f,0f,41.31996f,74.71161f,-28.231548f,13.2107725f,11.5231285f,-41.82987f ) ;
  }

  @Test
  public void test266() {
    color.laplace.solve(78.22394f,-51.483532f,0f,11.690241f,-33.647305f,-20.89868f,2.184334f,-2.9529047f,19.651352f ) ;
  }

  @Test
  public void test267() {
    color.laplace.solve(79.08648f,-59.526352f,0f,76.28518f,34.46429f,22.99434f,16.399195f,-10.688396f,-93.61707f ) ;
  }

  @Test
  public void test268() {
    color.laplace.solve(79.78969f,-24.036089f,0f,40.7053f,62.713165f,11.831863f,20.318338f,40.568054f,79.24071f ) ;
  }

  @Test
  public void test269() {
    color.laplace.solve(8.114973f,-57.766537f,5.5913525f,-9.773568f,-1.1396801f,-12.5728655f,-46.06957f,75.55425f,-54.743134f ) ;
  }

  @Test
  public void test270() {
    color.laplace.solve(8.251815f,-1.4705589f,-14.13405f,-65.52218f,-100.0f,-53.58893f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test271() {
    color.laplace.solve(-82.621895f,60.502884f,0f,-39.46439f,43.829857f,0f,-94.37229f,0f,0f ) ;
  }

  @Test
  public void test272() {
    color.laplace.solve(87.242805f,49.1148f,-31.04602f,26.143017f,19.923876f,40.959167f,-2.5946157f,-36.521477f,-19.475504f ) ;
  }

  @Test
  public void test273() {
    color.laplace.solve(8.735733f,-69.296074f,-18.022528f,4.239002f,-8.436438f,11.619969f,16.656713f,19.69135f,72.93884f ) ;
  }

  @Test
  public void test274() {
    color.laplace.solve(87.52033f,16.194336f,0f,44.0359f,76.3095f,25.374428f,13.125636f,8.466644f,-55.56856f ) ;
  }

  @Test
  public void test275() {
    color.laplace.solve(-87.97393f,44.768097f,-88.10081f,-34.21846f,13.20888f,5.311075f,-62.1088f,36.97481f,96.13623f ) ;
  }

  @Test
  public void test276() {
    color.laplace.solve(88.24037f,-15.889458f,17.398773f,26.73197f,6.5340357f,-8.967235f,12.153473f,24.260866f,-18.582943f ) ;
  }

  @Test
  public void test277() {
    color.laplace.solve(89.09723f,100.0f,24.573845f,28.830523f,20.15109f,-43.690716f,6.0737705f,-4.53544f,-51.70751f ) ;
  }

  @Test
  public void test278() {
    color.laplace.solve(-89.337135f,58.150784f,-8.578747f,-23.683401f,-3.647647f,-65.74608f,-1.7488232f,16.688108f,72.14891f ) ;
  }

  @Test
  public void test279() {
    color.laplace.solve(-89.607605f,-79.40643f,0f,-21.353539f,9.524499f,75.20404f,-5.331047f,0.029350292f,-56.63698f ) ;
  }

  @Test
  public void test280() {
    color.laplace.solve(9.155882f,-87.67589f,-0.34440848f,24.299417f,-9.276585f,-70.736755f,97.318375f,97.00689f,-29.534252f ) ;
  }

  @Test
  public void test281() {
    color.laplace.solve(-9.214321f,-51.095337f,-7.587845f,-85.76195f,100.0f,0f,-28.468325f,-28.111351f,-46.163475f ) ;
  }

  @Test
  public void test282() {
    color.laplace.solve(92.34118f,-98.71098f,0f,0.35784468f,-84.18563f,-52.078796f,-6.724171f,-27.254528f,-18.108315f ) ;
  }

  @Test
  public void test283() {
    color.laplace.solve(-93.65541f,-69.10395f,-23.557579f,-46.838867f,-42.11549f,-28.349678f,-51.58457f,-24.169462f,-67.37212f ) ;
  }

  @Test
  public void test284() {
    color.laplace.solve(95.82792f,96.87632f,0f,89.089714f,6.2330203f,0f,4.8351736f,-69.749016f,19.894493f ) ;
  }

  @Test
  public void test285() {
    color.laplace.solve(96.91704f,96.41979f,0f,46.95068f,85.86365f,90.138016f,5.0220313f,-26.862553f,-0.9381466f ) ;
  }

  @Test
  public void test286() {
    color.laplace.solve(-97.91254f,14.378371f,0f,-33.542305f,-21.205395f,-90.62954f,-15.051293f,-26.662867f,44.40131f ) ;
  }

  @Test
  public void test287() {
    color.laplace.solve(98.67634f,-27.95368f,28.210238f,34.382698f,-18.547693f,-5.994649f,57.40214f,-74.625145f,-33.64114f ) ;
  }

  @Test
  public void test288() {
    color.laplace.solve(9.887969f,5.1060495f,34.396133f,-65.55417f,15.897242f,0f,-12.388279f,16.001057f,0f ) ;
  }

  @Test
  public void test289() {
    color.laplace.solve(99.09244f,59.299316f,-5.524542f,36.056854f,31.836155f,14.850039f,13.298817f,17.138412f,23.418682f ) ;
  }

  @Test
  public void test290() {
    color.laplace.solve(-99.99922f,30.441614f,0f,-29.98865f,-8.748526f,-68.773674f,-11.206847f,-14.838739f,-39.399586f ) ;
  }
}
