import org.junit.Test;

public class JpfTargetloanTest {

  @Test
  public void test0() {
    color.loan.solve(-54.60728f ) ;
  }

  @Test
  public void test1() {
    color.loan.solve(67.223785f ) ;
  }

  @Test
  public void test2() {
    color.loan.solve(95.90074f ) ;
  }
}
