import org.junit.Test;

public class JpfTargetsendmoremoneyTest {

  @Test
  public void test0() {
    color.sendmoremoney.solve(1,1,674,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    color.sendmoremoney.solve(1,371,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test2() {
    color.sendmoremoney.solve(2,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    color.sendmoremoney.solve(2,7,2,0,0,0,0,0 ) ;
  }

  @Test
  public void test4() {
    color.sendmoremoney.solve(2,7,-675,0,0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    color.sendmoremoney.solve(2,8,6,11,7,0,0,0 ) ;
  }

  @Test
  public void test6() {
    color.sendmoremoney.solve(2,-949,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test7() {
    color.sendmoremoney.solve(2,9,7,-701,0,0,0,0 ) ;
  }

  @Test
  public void test8() {
    color.sendmoremoney.solve(3,9,2,671,0,0,0,0 ) ;
  }

  @Test
  public void test9() {
    color.sendmoremoney.solve(4,155,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test10() {
    color.sendmoremoney.solve(4,4,1,469,0,0,0,0 ) ;
  }

  @Test
  public void test11() {
    color.sendmoremoney.solve(451,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test12() {
    color.sendmoremoney.solve(-464,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test13() {
    color.sendmoremoney.solve(5,5,5,8,983,0,0,0 ) ;
  }

  @Test
  public void test14() {
    color.sendmoremoney.solve(6,4,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test15() {
    color.sendmoremoney.solve(6,4,1,5,-292,0,0,0 ) ;
  }

  @Test
  public void test16() {
    color.sendmoremoney.solve(7,6,5,8,0,0,0,0 ) ;
  }

  @Test
  public void test17() {
    color.sendmoremoney.solve(7,6,953,0,0,0,0,0 ) ;
  }

  @Test
  public void test18() {
    color.sendmoremoney.solve(8,9,5,8,422,0,0,0 ) ;
  }

  @Test
  public void test19() {
    color.sendmoremoney.solve(910,0,0,0,0,0,0,0 ) ;
  }
}
