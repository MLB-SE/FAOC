import org.junit.Test;

public class ConflictTest {

  @Test
  public void test0() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,0.0 ) ;
  }

  @Test
  public void test2() {
    tsafe.Conflict.snippet(0.0,0.0,0,0,0,0,-35.91142937158917 ) ;
  }

  @Test
  public void test3() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,12.575341794477865 ) ;
  }

  @Test
  public void test4() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,1.58E-322 ) ;
  }

  @Test
  public void test5() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,-20.01944165671004 ) ;
  }

  @Test
  public void test6() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,-59.59654008036884 ) ;
  }

  @Test
  public void test7() {
    tsafe.Conflict.snippet(0.0,-21.54865400446711,-5.662926531726839,0,0,0,98.55738734877195 ) ;
  }

  @Test
  public void test8() {
    tsafe.Conflict.snippet(0.0,30.364294269671362,34.67933084791122,-1.0647104734664001,1.4273700208272135,92.4957158835999,-100.0 ) ;
  }

  @Test
  public void test9() {
    tsafe.Conflict.snippet(0.0,-33.267412371020704,-27.79358537272684,51.850926124637915,-77.89195907002319,-91.1306532783756,-94.32814562879662 ) ;
  }

  @Test
  public void test10() {
    tsafe.Conflict.snippet(0.0,53.41083840822011,-99.95712836219549,1.4782037283298461,1.3471873431530383,-100.0,61.939864243827785 ) ;
  }

  @Test
  public void test11() {
    tsafe.Conflict.snippet(0.0,-7.100736806109225,0,0,0,0,-46.01463058603255 ) ;
  }

  @Test
  public void test12() {
    tsafe.Conflict.snippet(0.0,-83.53365589999744,28.646848793891024,-50.22402764147478,-22.566249313155936,-29.549094244133656,17.979953663670315 ) ;
  }

  @Test
  public void test13() {
    tsafe.Conflict.snippet(0.0,8.622907831164,-3.6049034565824005E-12,0,0,0,90.0 ) ;
  }

  @Test
  public void test14() {
    tsafe.Conflict.snippet(100.0,0,0,0,0,0,0.0 ) ;
  }

  @Test
  public void test15() {
    tsafe.Conflict.snippet(-100.0,0,0,0,0,0,-9.93E-322 ) ;
  }

  @Test
  public void test16() {
    tsafe.Conflict.snippet(-100.0,117.16277920950378,4.536225545207742,2.4641853023265163,-1.1309140835416756,100.0,-12.839402444862056 ) ;
  }

  @Test
  public void test17() {
    tsafe.Conflict.snippet(-100.0,170.5057126969283,-338.01735858736316,-18.254579873361582,375.4158200856156,-12.68664144548572,179.82384947400345 ) ;
  }

  @Test
  public void test18() {
    tsafe.Conflict.snippet(-100.0,-98.63794411787967,7.997116333953747E-20,0,0,0,-90.0 ) ;
  }

  @Test
  public void test19() {
    tsafe.Conflict.snippet(-100.0,-98.99754468241927,35.889945896648726,-1.5719547973817027,2.763739201132653,-3.898012052988342,-169.32572092994542 ) ;
  }

  @Test
  public void test20() {
    tsafe.Conflict.snippet(-1.7E-322,0,0,0,0,0,0.11158820450083606 ) ;
  }

  @Test
  public void test21() {
    tsafe.Conflict.snippet(1.7E-322,0,0,0,0,0,100.0 ) ;
  }

  @Test
  public void test22() {
    tsafe.Conflict.snippet(-18.235349721701283,0,0,0,0,0,55.533049432206695 ) ;
  }

  @Test
  public void test23() {
    tsafe.Conflict.snippet(-2.590327E-318,0,0,0,0,0,-12.270707867607385 ) ;
  }

  @Test
  public void test24() {
    tsafe.Conflict.snippet(3.2379E-319,0,0,0,0,0,12.46695810477175 ) ;
  }

  @Test
  public void test25() {
    tsafe.Conflict.snippet(34.76335544145249,0,0,0,0,0,99.3168821148081 ) ;
  }

  @Test
  public void test26() {
    tsafe.Conflict.snippet(35.98096369320126,-32.15506862043512,41.186015562868604,0.8434170929509213,-0.7642664946731301,-49.81591657697386,-62.04223582700945 ) ;
  }

  @Test
  public void test27() {
    tsafe.Conflict.snippet(43.342827138102194,-213.17745046978902,30.623504107575144,168.70069542913006,983.7148861999954,-82.39825997832565,-26.822825598779033 ) ;
  }

  @Test
  public void test28() {
    tsafe.Conflict.snippet(-4.440892098500626E-16,0,0,0,0,0,19.529383568278462 ) ;
  }

  @Test
  public void test29() {
    tsafe.Conflict.snippet(-45.02486208312315,0,0,0,0,0,-75.00054344552707 ) ;
  }

  @Test
  public void test30() {
    tsafe.Conflict.snippet(47.05122763700104,98.3028478775938,-0.9174365821264515,2.7936376310455464,7.9861111835021035,-55.36403303867326,0.6247382849194203 ) ;
  }

  @Test
  public void test31() {
    tsafe.Conflict.snippet(-49.20269801763277,33.01837203838018,-3.6566135119428793,-1030.7448199422893,-120.21202165107508,-61.17079801975494,-79.1316890198069 ) ;
  }

  @Test
  public void test32() {
    tsafe.Conflict.snippet(-49.65227477581182,55.648103695659074,-31.41602503849461,0,0,0,-41.989452686840245 ) ;
  }

  @Test
  public void test33() {
    tsafe.Conflict.snippet(-51.125917488234364,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test34() {
    tsafe.Conflict.snippet(53.24254049760495,33.99966019950537,0,0,0,0,-78.91384866367332 ) ;
  }

  @Test
  public void test35() {
    tsafe.Conflict.snippet(53.95205168704217,17.07659570307665,-55.406739857146235,0,0,0,98.74967463605054 ) ;
  }

  @Test
  public void test36() {
    tsafe.Conflict.snippet(55.77800454410266,0,0,0,0,0,12.775653880593808 ) ;
  }

  @Test
  public void test37() {
    tsafe.Conflict.snippet(-55.78647655713882,0,0,0,0,0,-80.51645055568275 ) ;
  }

  @Test
  public void test38() {
    tsafe.Conflict.snippet(-5.73802760120692E-16,-130.77806128462066,3.061546015526785,3.8994395968832936,81.91815705480698,-60.204519299302035,-5.72358911504656E-20 ) ;
  }

  @Test
  public void test39() {
    tsafe.Conflict.snippet(5.877352834060929,-56.42861438990505,-86.46897710886078,20.135366945339612,86.6709876540964,46.71204531231626,-22.885175510427842 ) ;
  }

  @Test
  public void test40() {
    tsafe.Conflict.snippet(62.07209289285916,-30.178699076101793,-51.29473484164437,-33.80710323176646,50.07103648539345,-54.500438623534706,-23.104265917949434 ) ;
  }

  @Test
  public void test41() {
    tsafe.Conflict.snippet(62.282380474896655,0.0,0,0,0,0,26.29797919575811 ) ;
  }

  @Test
  public void test42() {
    tsafe.Conflict.snippet(-67.23500314683528,1.3251225196891312,35.64268647731396,74.6406391913811,1.5231878303560933,97.55160838118536,51.81114212993336 ) ;
  }

  @Test
  public void test43() {
    tsafe.Conflict.snippet(74.16184087446169,0,0,0,0,0,53.30159844386944 ) ;
  }

  @Test
  public void test44() {
    tsafe.Conflict.snippet(-74.23426195902239,0,0,0,0,0,0.0 ) ;
  }

  @Test
  public void test45() {
    tsafe.Conflict.snippet(80.94665772393435,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test46() {
    tsafe.Conflict.snippet(86.29123688751397,-74.70378267177914,59.76012950281685,-308.6564852205002,961.9081953407933,101.06246172669537,-6.819071170864589 ) ;
  }

  @Test
  public void test47() {
    tsafe.Conflict.snippet(-87.71349835976498,-47.34488972621014,0,0,0,0,17.48775304277129 ) ;
  }

  @Test
  public void test48() {
    tsafe.Conflict.snippet(-8.881784197001252E-16,0,0,0,0,0,-25.8961762126583 ) ;
  }

  @Test
  public void test49() {
    tsafe.Conflict.snippet(-8.881784197001252E-16,-225.39695226084098,-136.40357120913552,-180.07992218132694,-982.5947926772182,27.302417960885407,-29.901440370554916 ) ;
  }

  @Test
  public void test50() {
    tsafe.Conflict.snippet(-91.0216102787651,0.0,0,0,0,0,40.98732380508224 ) ;
  }

  @Test
  public void test51() {
    tsafe.Conflict.snippet(93.64093109345315,-100.0,2.479747190325477E-10,0,0,0,-90.0 ) ;
  }

  @Test
  public void test52() {
    tsafe.Conflict.snippet(-98.97553182887071,50.857164528530376,48.905662387702534,67.5489836254678,99.16771906203292,33.750980882796625,-75.74508698358156 ) ;
  }

  @Test
  public void test53() {
    tsafe.Conflict.snippet(99.21205242266831,0,0,0,0,0,1.58E-322 ) ;
  }
}
