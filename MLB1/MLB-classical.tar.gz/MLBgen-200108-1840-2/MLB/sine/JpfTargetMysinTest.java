import org.junit.Test;

public class JpfTargetMysinTest {

  @Test
  public void test0() {
    JpfTargetMysin.static_mysin(0.053901076967328265 ) ;
  }

  @Test
  public void test1() {
    JpfTargetMysin.static_mysin(-0.22031952207670358 ) ;
  }

  @Test
  public void test2() {
    JpfTargetMysin.static_mysin(0.3389322319106185 ) ;
  }

  @Test
  public void test3() {
    JpfTargetMysin.static_mysin(-0.4214253957365468 ) ;
  }

  @Test
  public void test4() {
    JpfTargetMysin.static_mysin(-0.45690025575109416 ) ;
  }

  @Test
  public void test5() {
    JpfTargetMysin.static_mysin(-13.877531362794485 ) ;
  }

  @Test
  public void test6() {
    JpfTargetMysin.static_mysin(1.4153648726573125E-14 ) ;
  }

  @Test
  public void test7() {
    JpfTargetMysin.static_mysin(1.4206061856775372E-4 ) ;
  }

  @Test
  public void test8() {
    JpfTargetMysin.static_mysin(14.311481339093262 ) ;
  }

  @Test
  public void test9() {
    JpfTargetMysin.static_mysin(-144.00130314556628 ) ;
  }

  @Test
  public void test10() {
    JpfTargetMysin.static_mysin(-151.5975352557117 ) ;
  }

  @Test
  public void test11() {
    JpfTargetMysin.static_mysin(-2.4414062500003E-4 ) ;
  }

  @Test
  public void test12() {
    JpfTargetMysin.static_mysin(2.4415807039052524E-4 ) ;
  }

  @Test
  public void test13() {
    JpfTargetMysin.static_mysin(256.6742418648105 ) ;
  }

  @Test
  public void test14() {
    JpfTargetMysin.static_mysin(3.973183196314566E-4 ) ;
  }

  @Test
  public void test15() {
    JpfTargetMysin.static_mysin(44.270887476284884 ) ;
  }

  @Test
  public void test16() {
    JpfTargetMysin.static_mysin(-5.050591131606367E-4 ) ;
  }

  @Test
  public void test17() {
    JpfTargetMysin.static_mysin(5.492138639669772E-17 ) ;
  }

  @Test
  public void test18() {
    JpfTargetMysin.static_mysin(-63.312380977645155 ) ;
  }

  @Test
  public void test19() {
    JpfTargetMysin.static_mysin(-74.19038062716454 ) ;
  }

  @Test
  public void test20() {
    JpfTargetMysin.static_mysin(-74.61282552275759 ) ;
  }

  @Test
  public void test21() {
    JpfTargetMysin.static_mysin(-76.36923056818921 ) ;
  }

  @Test
  public void test22() {
    JpfTargetMysin.static_mysin(79.32521450314228 ) ;
  }

  @Test
  public void test23() {
    JpfTargetMysin.static_mysin(8.63937979737193 ) ;
  }

  @Test
  public void test24() {
    JpfTargetMysin.static_mysin(87.62218133138148 ) ;
  }

  @Test
  public void test25() {
    JpfTargetMysin.static_mysin(-88.74999246391165 ) ;
  }

  @Test
  public void test26() {
    JpfTargetMysin.static_mysin(-90.92986169316532 ) ;
  }

  @Test
  public void test27() {
    JpfTargetMysin.static_mysin(92.26776553811027 ) ;
  }

  @Test
  public void test28() {
    JpfTargetMysin.static_mysin(96.41801969760556 ) ;
  }

  @Test
  public void test29() {
    JpfTargetMysin.static_mysin(96.81138237130534 ) ;
  }
}
