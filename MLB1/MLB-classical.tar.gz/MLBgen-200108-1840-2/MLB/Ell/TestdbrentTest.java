import org.junit.Test;

public class TestdbrentTest {

  @Test
  public void test0() {
    ell.dbrent(0.0,0.0,0.0,0 ) ;
  }

  @Test
  public void test1() {
    ell.dbrent(-100.0,0.0,-100.0,0 ) ;
  }

  @Test
  public void test2() {
    ell.dbrent(100.0,0.0,100.0,0 ) ;
  }

  @Test
  public void test3() {
    ell.dbrent(100.0,15.671047751753775,100.0,0 ) ;
  }

  @Test
  public void test4() {
    ell.dbrent(13.571848080385607,20.8924410397046,28.213033999023594,0 ) ;
  }

  @Test
  public void test5() {
    ell.dbrent(139.00508421859206,32.347958527266144,-65.80651442375232,0 ) ;
  }

  @Test
  public void test6() {
    ell.dbrent(-16.375371720078036,4.942487557481726,27.810636919789886,0 ) ;
  }

  @Test
  public void test7() {
    ell.dbrent(18.38006848688131,0,18.380068486881314,0 ) ;
  }

  @Test
  public void test8() {
    ell.dbrent(-20.47817135263236,-20.47817135263236,-20.47817135263236,0 ) ;
  }

  @Test
  public void test9() {
    ell.dbrent(24.924486478164518,0,24.924486478164514,0 ) ;
  }

  @Test
  public void test10() {
    ell.dbrent(-27.621457686075317,38.268752035685736,-0.38947898267718983,0 ) ;
  }

  @Test
  public void test11() {
    ell.dbrent(-30.12325486496766,0.0,30.12325486496766,0 ) ;
  }

  @Test
  public void test12() {
    ell.dbrent(-3.2094595972925855,33.95393392505304,-3.2094595972925855,0 ) ;
  }

  @Test
  public void test13() {
    ell.dbrent(-33.45224475757853,0,-33.45224475757854,0 ) ;
  }

  @Test
  public void test14() {
    ell.dbrent(-36.9918054250437,-68.31817067203863,57.96790036636622,0 ) ;
  }

  @Test
  public void test15() {
    ell.dbrent(37.431229139458765,0,37.431229139458765,0 ) ;
  }

  @Test
  public void test16() {
    ell.dbrent(-37.699091311151605,-7.615148863208805,22.468793584733994,0 ) ;
  }

  @Test
  public void test17() {
    ell.dbrent(-40.1054762019301,-13.147767241708294,69.21472479426356,0 ) ;
  }

  @Test
  public void test18() {
    ell.dbrent(-42.078534789860065,0.0,-42.078534789860065,0 ) ;
  }

  @Test
  public void test19() {
    ell.dbrent(-42.166089857177134,0.0,-54.548017374464244,0 ) ;
  }

  @Test
  public void test20() {
    ell.dbrent(-43.08938470624644,0,-43.08938470624644,0 ) ;
  }

  @Test
  public void test21() {
    ell.dbrent(46.33760678931321,35.143521029385596,-51.934880880889224,0 ) ;
  }

  @Test
  public void test22() {
    ell.dbrent(4.725394959457162,0.0,-4.725394959457162,0 ) ;
  }

  @Test
  public void test23() {
    ell.dbrent(47.70417222965148,0.0,-44.9591062838672,0 ) ;
  }

  @Test
  public void test24() {
    ell.dbrent(4.77820275768789,0,4.778202757687889,0 ) ;
  }

  @Test
  public void test25() {
    ell.dbrent(-47.80096297654688,-22.449734246277274,-95.90667954436023,0 ) ;
  }

  @Test
  public void test26() {
    ell.dbrent(48.52441495612652,5.371554644947452,61.37303996246132,0 ) ;
  }

  @Test
  public void test27() {
    ell.dbrent(-54.664289712723956,-6.987719113508877,-54.664289712723956,0 ) ;
  }

  @Test
  public void test28() {
    ell.dbrent(5.73898118249774,0.0,-61.44286287583913,0 ) ;
  }

  @Test
  public void test29() {
    ell.dbrent(57.88319413793889,0,22.24017549536252,0 ) ;
  }

  @Test
  public void test30() {
    ell.dbrent(-58.03751079856052,32.72457558716155,-68.59797422716429,0 ) ;
  }

  @Test
  public void test31() {
    ell.dbrent(-59.0971488748284,0,93.21776567668522,0 ) ;
  }

  @Test
  public void test32() {
    ell.dbrent(59.78950257092794,-7.5517380518870425,-42.18911242843668,0 ) ;
  }

  @Test
  public void test33() {
    ell.dbrent(61.567276537228445,-4.044550198292459,-69.65637693381336,0 ) ;
  }

  @Test
  public void test34() {
    ell.dbrent(-63.29926648790615,0,-63.299266487906145,0 ) ;
  }

  @Test
  public void test35() {
    ell.dbrent(65.8407956693421,0.0,77.6804915341294,0 ) ;
  }

  @Test
  public void test36() {
    ell.dbrent(67.88727224075546,67.88727224075546,67.88727224075546,0 ) ;
  }

  @Test
  public void test37() {
    ell.dbrent(-71.88262708182677,-22.066377711550018,-71.88262708182677,0 ) ;
  }

  @Test
  public void test38() {
    ell.dbrent(-72.50028065092253,0.0,-4.435793303399972,0 ) ;
  }

  @Test
  public void test39() {
    ell.dbrent(74.51116456000554,77.13588990385324,74.51116456000554,0 ) ;
  }

  @Test
  public void test40() {
    ell.dbrent(-78.0915433920457,0,-90.5089115778784,0 ) ;
  }

  @Test
  public void test41() {
    ell.dbrent(-7.960988568715056,0.0,-6.230511015215379,0 ) ;
  }

  @Test
  public void test42() {
    ell.dbrent(-8.14096357336875,-42.24419534987869,-8.14096357336875,0 ) ;
  }

  @Test
  public void test43() {
    ell.dbrent(86.85557120005811,38.652359654221044,-9.55085189161602,0 ) ;
  }

  @Test
  public void test44() {
    ell.dbrent(93.48115524457793,-60.5470331772664,-86.1442562656648,0 ) ;
  }

  @Test
  public void test45() {
    ell.dbrent(-94.10930127130852,0,6.821191077893872,0 ) ;
  }

  @Test
  public void test46() {
    ell.dbrent(-9.808626563781113,0,-9.808626563781111,0 ) ;
  }

  @Test
  public void test47() {
    ell.dbrent(-99.72358562333756,-16.745659664326837,38.01151387069669,0 ) ;
  }
}
