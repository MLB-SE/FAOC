import org.junit.Test;

public class TestzbrentTest {

  @Test
  public void test0() {
    ell.zbrent(-11.535284317402201,0,0 ) ;
  }

  @Test
  public void test1() {
    ell.zbrent(-11.73395296888253,-21.991148575128555,0 ) ;
  }

  @Test
  public void test2() {
    ell.zbrent(-1.7107238243877276,144.51322937850517,0 ) ;
  }

  @Test
  public void test3() {
    ell.zbrent(18.346964435329653,52.829747543259884,0 ) ;
  }

  @Test
  public void test4() {
    ell.zbrent(21.29750846052793,53.40707511102649,0 ) ;
  }

  @Test
  public void test5() {
    ell.zbrent(21.67826377805281,-6.283185307179586,0 ) ;
  }

  @Test
  public void test6() {
    ell.zbrent(26.908563740144103,65.49828051653955,0 ) ;
  }

  @Test
  public void test7() {
    ell.zbrent(-31.415926535897935,-81.76605635790767,0 ) ;
  }

  @Test
  public void test8() {
    ell.zbrent(-35.35446674647706,61.87154203260232,0 ) ;
  }

  @Test
  public void test9() {
    ell.zbrent(-43.05433431169705,37.69911184307752,0 ) ;
  }

  @Test
  public void test10() {
    ell.zbrent(-43.94769550861339,91.33542910587292,0 ) ;
  }

  @Test
  public void test11() {
    ell.zbrent(-44.23097598883785,0,0 ) ;
  }

  @Test
  public void test12() {
    ell.zbrent(4.5609746862573814,69.11503837897546,0 ) ;
  }

  @Test
  public void test13() {
    ell.zbrent(50.2654824574367,-26.847278376734494,0 ) ;
  }

  @Test
  public void test14() {
    ell.zbrent(50.622901280733146,50.2654824574367,0 ) ;
  }

  @Test
  public void test15() {
    ell.zbrent(54.965802586781955,50.26548245743669,0 ) ;
  }

  @Test
  public void test16() {
    ell.zbrent(-56.457601503566735,-5.707873925727554,0 ) ;
  }

  @Test
  public void test17() {
    ell.zbrent(-57.42320719999894,0,0 ) ;
  }

  @Test
  public void test18() {
    ell.zbrent(-6.233929679986147,33.58577045403837,0 ) ;
  }

  @Test
  public void test19() {
    ell.zbrent(68.45519717187543,53.40707511102649,0 ) ;
  }

  @Test
  public void test20() {
    ell.zbrent(-71.4462851877457,97.99996049585963,0 ) ;
  }

  @Test
  public void test21() {
    ell.zbrent(72.25663103256524,0,0 ) ;
  }

  @Test
  public void test22() {
    ell.zbrent(75.39822368615503,0,0 ) ;
  }

  @Test
  public void test23() {
    ell.zbrent(75.47407842688689,3.141592653589793,0 ) ;
  }

  @Test
  public void test24() {
    ell.zbrent(81.68140899333461,0,0 ) ;
  }

  @Test
  public void test25() {
    ell.zbrent(81.84009542389452,-21.991148575128552,0 ) ;
  }

  @Test
  public void test26() {
    ell.zbrent(86.37289955988422,-83.96416467307583,0 ) ;
  }

  @Test
  public void test27() {
    ell.zbrent(-88.03106754394294,40.10212464711219,0 ) ;
  }

  @Test
  public void test28() {
    ell.zbrent(-89.46557382783583,-31.41592653589793,0 ) ;
  }

  @Test
  public void test29() {
    ell.zbrent(96.3055962420541,30.42266649285503,0 ) ;
  }
}
