import org.junit.Test;

public class TestbrentTest {

  @Test
  public void test0() {
    ell.brent(0.0,0.0,0.0,0 ) ;
  }

  @Test
  public void test1() {
    ell.brent(-0.8725113170051014,0.0,0.8725113170051014,0 ) ;
  }

  @Test
  public void test2() {
    ell.brent(-100.0,-100.0,-100.0,0 ) ;
  }

  @Test
  public void test3() {
    ell.brent(11.91268186643049,79.29976567180228,-86.25628852730061,0 ) ;
  }

  @Test
  public void test4() {
    ell.brent(11.954429940498443,0,11.954429940498443,0 ) ;
  }

  @Test
  public void test5() {
    ell.brent(13.898658006953983,0,13.898658006953985,0 ) ;
  }

  @Test
  public void test6() {
    ell.brent(-13.999469226976785,45.49058709526847,-13.999469226976785,0 ) ;
  }

  @Test
  public void test7() {
    ell.brent(14.386551306430992,0.0,53.52161210916172,0 ) ;
  }

  @Test
  public void test8() {
    ell.brent(15.015692465321202,-40.72855494012692,15.015692465321202,0 ) ;
  }

  @Test
  public void test9() {
    ell.brent(18.815225305645455,0,18.815225305645452,0 ) ;
  }

  @Test
  public void test10() {
    ell.brent(19.09955244753372,0.0,-19.09955244753372,0 ) ;
  }

  @Test
  public void test11() {
    ell.brent(196.71339691430538,0.0,100.0,0 ) ;
  }

  @Test
  public void test12() {
    ell.brent(-22.454450467979456,-12.627741500225625,-77.4029311870617,0 ) ;
  }

  @Test
  public void test13() {
    ell.brent(-22.867653548949534,0,-22.867653548949534,0 ) ;
  }

  @Test
  public void test14() {
    ell.brent(-24.80863107330304,0,-24.808631073303044,0 ) ;
  }

  @Test
  public void test15() {
    ell.brent(-25.60316790963148,4.361629365367477,34.326426640366435,0 ) ;
  }

  @Test
  public void test16() {
    ell.brent(-29.06403539213194,0.0,-29.06403539213194,0 ) ;
  }

  @Test
  public void test17() {
    ell.brent(30.76834194158613,0,58.31651720560066,0 ) ;
  }

  @Test
  public void test18() {
    ell.brent(34.23336096059134,16.208093046410397,42.7338801503428,0 ) ;
  }

  @Test
  public void test19() {
    ell.brent(-35.503074369103985,88.48411648122612,-35.503074369103985,0 ) ;
  }

  @Test
  public void test20() {
    ell.brent(40.22285305273007,0,-0.82421455331054,0 ) ;
  }

  @Test
  public void test21() {
    ell.brent(4.544322876915913,0,-42.7716731591564,0 ) ;
  }

  @Test
  public void test22() {
    ell.brent(-46.77503451206921,0,55.45197882978107,0 ) ;
  }

  @Test
  public void test23() {
    ell.brent(50.23760090189526,75.05056684472459,74.67662150981354,0 ) ;
  }

  @Test
  public void test24() {
    ell.brent(50.43872867468133,49.50075621177326,50.43872867468133,0 ) ;
  }

  @Test
  public void test25() {
    ell.brent(51.80511895808979,51.80511895808979,51.80511895808979,0 ) ;
  }

  @Test
  public void test26() {
    ell.brent(-5.216383906045803,0,-5.216383906045802,0 ) ;
  }

  @Test
  public void test27() {
    ell.brent(53.1582000905685,0.0,53.1582000905685,0 ) ;
  }

  @Test
  public void test28() {
    ell.brent(-60.26595838914916,-35.88577816792342,-60.26595838914916,0 ) ;
  }

  @Test
  public void test29() {
    ell.brent(62.29800480397985,0.0,-75.844497097704,0 ) ;
  }

  @Test
  public void test30() {
    ell.brent(62.692343415317254,-57.98022653609078,60.11810153017478,0 ) ;
  }

  @Test
  public void test31() {
    ell.brent(-65.45443223683225,-68.87878137060028,-72.30313050436833,0 ) ;
  }

  @Test
  public void test32() {
    ell.brent(-66.27149405847801,-42.46118710127382,-66.27149405847801,0 ) ;
  }

  @Test
  public void test33() {
    ell.brent(66.9185403003514,95.56406879328415,-42.33489251401259,0 ) ;
  }

  @Test
  public void test34() {
    ell.brent(-76.56542042281308,-52.81880964731984,-29.072198871826597,0 ) ;
  }

  @Test
  public void test35() {
    ell.brent(-78.12363790746863,0.0,74.73969654459748,0 ) ;
  }

  @Test
  public void test36() {
    ell.brent(-7.882736981209171,0,-7.882736981209172,0 ) ;
  }

  @Test
  public void test37() {
    ell.brent(-80.3653560148885,-43.14862289002348,72.84605821769779,0 ) ;
  }

  @Test
  public void test38() {
    ell.brent(-82.38586194060676,-26.628823325053673,64.62271877897598,0 ) ;
  }

  @Test
  public void test39() {
    ell.brent(83.69427699701069,0.0,-81.80208212027867,0 ) ;
  }

  @Test
  public void test40() {
    ell.brent(-87.03869780769801,-17.30928056181496,-26.56012988201408,0 ) ;
  }

  @Test
  public void test41() {
    ell.brent(89.36166435068682,40.069465028172544,-2.954856516067906,0 ) ;
  }

  @Test
  public void test42() {
    ell.brent(-92.10850616215404,53.55437842188536,-55.59692148841076,0 ) ;
  }

  @Test
  public void test43() {
    ell.brent(92.79978860558111,54.553998779841066,16.30820895410102,0 ) ;
  }

  @Test
  public void test44() {
    ell.brent(93.28717758450532,-17.99656673608068,8.987841403544223,0 ) ;
  }

  @Test
  public void test45() {
    ell.brent(95.22657237435531,0,95.22657237435533,0 ) ;
  }

  @Test
  public void test46() {
    ell.brent(9.727704324879907,0.0,27.99848083114678,0 ) ;
  }

  @Test
  public void test47() {
    ell.brent(98.60154356851854,0.0,98.60154356851854,0 ) ;
  }
}
