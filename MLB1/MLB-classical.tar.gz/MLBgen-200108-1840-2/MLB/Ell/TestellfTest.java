import org.junit.Test;

public class TestellfTest {

  @Test
  public void test0() {
    ell.ellf(-100.0,-0.9478809275236744 ) ;
  }

  @Test
  public void test1() {
    ell.ellf(-100.0,1.9748575314241001 ) ;
  }

  @Test
  public void test2() {
    ell.ellf(-14.137166943293913,1.0 ) ;
  }

  @Test
  public void test3() {
    ell.ellf(-15.707979808042337,-1.4247558898229624E-4 ) ;
  }

  @Test
  public void test4() {
    ell.ellf(18.93583203304871,-11.605085756011283 ) ;
  }

  @Test
  public void test5() {
    ell.ellf(-21.599954420675033,29.833561909119794 ) ;
  }

  @Test
  public void test6() {
    ell.ellf(21.991148574350174,6.4468535390897586 ) ;
  }

  @Test
  public void test7() {
    ell.ellf(29.845130209103036,-1.0 ) ;
  }

  @Test
  public void test8() {
    ell.ellf(-31.41592653590029,-3.8836264364809714 ) ;
  }

  @Test
  public void test9() {
    ell.ellf(31.41592653988319,-0.5986111099987994 ) ;
  }

  @Test
  public void test10() {
    ell.ellf(31.415926551169935,-0.5288217653152262 ) ;
  }

  @Test
  public void test11() {
    ell.ellf(-31.426424119887074,-1.000000000000089 ) ;
  }

  @Test
  public void test12() {
    ell.ellf(-37.69911184276174,36.0945584110387 ) ;
  }

  @Test
  public void test13() {
    ell.ellf(-40.84070447966112,1.520866629978883 ) ;
  }

  @Test
  public void test14() {
    ell.ellf(40.840704483744425,-0.8253435381475673 ) ;
  }

  @Test
  public void test15() {
    ell.ellf(-43.96711813320703,-65.88294868894226 ) ;
  }

  @Test
  public void test16() {
    ell.ellf(43.98229714896996,1.0768754512572798 ) ;
  }

  @Test
  public void test17() {
    ell.ellf(47.123458530521205,1.0000000000190716 ) ;
  }

  @Test
  public void test18() {
    ell.ellf(-49.2611965466905,-20.144301564939937 ) ;
  }

  @Test
  public void test19() {
    ell.ellf(-53.407075109092354,6.647716815574914 ) ;
  }

  @Test
  public void test20() {
    ell.ellf(-56.548667761336496,-2.8599137824559904 ) ;
  }

  @Test
  public void test21() {
    ell.ellf(-59.933562332636384,3.9669659867926015 ) ;
  }

  @Test
  public void test22() {
    ell.ellf(60.73899469924595,-32.34236909758256 ) ;
  }

  @Test
  public void test23() {
    ell.ellf(-65.97344572945141,-4.578442538197351 ) ;
  }

  @Test
  public void test24() {
    ell.ellf(-69.12344608837427,0.7999113060700598 ) ;
  }

  @Test
  public void test25() {
    ell.ellf(75.39822366933426,-0.878388577894481 ) ;
  }

  @Test
  public void test26() {
    ell.ellf(75.39822368539761,-5.068158901670268 ) ;
  }

  @Test
  public void test27() {
    ell.ellf(-76.96902001294994,-0.8376511732715778 ) ;
  }

  @Test
  public void test28() {
    ell.ellf(-7.8539820904632744,0.9999999999996724 ) ;
  }

  @Test
  public void test29() {
    ell.ellf(78.5398430841128,-2.0913689891746654E-4 ) ;
  }

  @Test
  public void test30() {
    ell.ellf(83.25220531041877,-0.5886569697247293 ) ;
  }

  @Test
  public void test31() {
    ell.ellf(84.82300171136501,-1.020480478747385 ) ;
  }

  @Test
  public void test32() {
    ell.ellf(-87.96459430174107,-2.0421941077867203 ) ;
  }

  @Test
  public void test33() {
    ell.ellf(-87.98340340561,-0.5497323850560798 ) ;
  }

  @Test
  public void test34() {
    ell.ellf(-88.06851109842239,-3.6105942387692664 ) ;
  }

  @Test
  public void test35() {
    ell.ellf(-89.13810655824746,0.9143830952925271 ) ;
  }

  @Test
  public void test36() {
    ell.ellf(91.14643237960487,-24.85425331242777 ) ;
  }

  @Test
  public void test37() {
    ell.ellf(97.38937227928064,-0.2458726241718653 ) ;
  }

  @Test
  public void test38() {
    ell.ellf(-97.38937229326797,-0.9945216679177533 ) ;
  }
}
