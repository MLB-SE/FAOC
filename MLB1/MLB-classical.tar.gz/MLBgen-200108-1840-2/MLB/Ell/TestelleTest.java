import org.junit.Test;

public class TestelleTest {

  @Test
  public void test0() {
    ell.elle(0.11381910110091553,8.272125739972687 ) ;
  }

  @Test
  public void test1() {
    ell.elle(100.0,-1.9748575314237398 ) ;
  }

  @Test
  public void test2() {
    ell.elle(-10.184868100438084,-1.4514066608895906 ) ;
  }

  @Test
  public void test3() {
    ell.elle(124.09290982401414,0.44180049719005376 ) ;
  }

  @Test
  public void test4() {
    ell.elle(14.137167681196185,-1.0 ) ;
  }

  @Test
  public void test5() {
    ell.elle(1.5707963296717398,0.9999999999999224 ) ;
  }

  @Test
  public void test6() {
    ell.elle(-1.6192836165020026,-0.5975897988923112 ) ;
  }

  @Test
  public void test7() {
    ell.elle(21.99114857481844,20.486457163781296 ) ;
  }

  @Test
  public void test8() {
    ell.elle(25.132741237831045,1.322533842108104 ) ;
  }

  @Test
  public void test9() {
    ell.elle(-25.270361362234055,7.289366120974092 ) ;
  }

  @Test
  public void test10() {
    ell.elle(-31.102931273010384,84.77816335670454 ) ;
  }

  @Test
  public void test11() {
    ell.elle(3.1415926421556457,1.5532283362196924 ) ;
  }

  @Test
  public void test12() {
    ell.elle(-3.141592662125065,1.3016917031862143 ) ;
  }

  @Test
  public void test13() {
    ell.elle(-32.98672286269283,0.9742267013519683 ) ;
  }

  @Test
  public void test14() {
    ell.elle(34.557519173868634,-0.5131749600426168 ) ;
  }

  @Test
  public void test15() {
    ell.elle(-46.62228349009367,-0.502576144304939 ) ;
  }

  @Test
  public void test16() {
    ell.elle(-47.123889798787026,-0.7729335920083509 ) ;
  }

  @Test
  public void test17() {
    ell.elle(50.23735679168041,1.0000000000000437 ) ;
  }

  @Test
  public void test18() {
    ell.elle(-50.25028916919438,0.9700774856500125 ) ;
  }

  @Test
  public void test19() {
    ell.elle(51.33250812355584,40.90593072617216 ) ;
  }

  @Test
  public void test20() {
    ell.elle(53.40707425453905,-0.01584560106110364 ) ;
  }

  @Test
  public void test21() {
    ell.elle(-59.75233379041004,16.120317572439895 ) ;
  }

  @Test
  public void test22() {
    ell.elle(62.83185307185874,54.083875361371575 ) ;
  }

  @Test
  public void test23() {
    ell.elle(-69.11634459158127,-1.000000000037787 ) ;
  }

  @Test
  public void test24() {
    ell.elle(72.25663102806749,-3.2207404264862496 ) ;
  }

  @Test
  public void test25() {
    ell.elle(72.2566310778259,-0.8635184174010582 ) ;
  }

  @Test
  public void test26() {
    ell.elle(-75.39803038950232,4.357718963727262E-5 ) ;
  }

  @Test
  public void test27() {
    ell.elle(75.39822368399571,8.57679017165917 ) ;
  }

  @Test
  public void test28() {
    ell.elle(-76.51366642413824,-0.6686987077367519 ) ;
  }

  @Test
  public void test29() {
    ell.elle(-84.82300163792769,-20.786688120267456 ) ;
  }

  @Test
  public void test30() {
    ell.elle(84.82300165555907,-15.6476466340425 ) ;
  }

  @Test
  public void test31() {
    ell.elle(-91.06425498310526,-85.51836540702429 ) ;
  }

  @Test
  public void test32() {
    ell.elle(91.10618694551444,1.0201976447054604 ) ;
  }

  @Test
  public void test33() {
    ell.elle(-9.424777945185605,-1.1273554086713489 ) ;
  }

  @Test
  public void test34() {
    ell.elle(-9.424777953056259,-1.2579905434820873 ) ;
  }

  @Test
  public void test35() {
    ell.elle(-94.24777960767743,-63.73608773483335 ) ;
  }

  @Test
  public void test36() {
    ell.elle(-94.24777961905,1.1729812732906795 ) ;
  }

  @Test
  public void test37() {
    ell.elle(-9.557884806591403,3.776039029079101 ) ;
  }

  @Test
  public void test38() {
    ell.elle(-95.81857593432426,1.0 ) ;
  }
}
