import org.junit.Test;

public class TestplgndrTest {

  @Test
  public void test0() {
    plgndr.plgndr(0,0,0 ) ;
  }

  @Test
  public void test1() {
    plgndr.plgndr(0,1,0 ) ;
  }

  @Test
  public void test2() {
    plgndr.plgndr(0,-205,0 ) ;
  }

  @Test
  public void test3() {
    plgndr.plgndr(0,461,0 ) ;
  }

  @Test
  public void test4() {
    plgndr.plgndr(0,-477,0 ) ;
  }

  @Test
  public void test5() {
    plgndr.plgndr(1382,1090,1.000000002733348 ) ;
  }

  @Test
  public void test6() {
    plgndr.plgndr(-143,-144,0 ) ;
  }

  @Test
  public void test7() {
    plgndr.plgndr(1530,615,1.0 ) ;
  }

  @Test
  public void test8() {
    plgndr.plgndr(186,79,0.0 ) ;
  }

  @Test
  public void test9() {
    plgndr.plgndr(241,48,-89.81670453325347 ) ;
  }

  @Test
  public void test10() {
    plgndr.plgndr(-315,-262,0 ) ;
  }

  @Test
  public void test11() {
    plgndr.plgndr(452,177,-0.9999999999999999 ) ;
  }

  @Test
  public void test12() {
    plgndr.plgndr(469,405,1.0 ) ;
  }

  @Test
  public void test13() {
    plgndr.plgndr(493,1000,0 ) ;
  }

  @Test
  public void test14() {
    plgndr.plgndr(-53,380,0 ) ;
  }

  @Test
  public void test15() {
    plgndr.plgndr(-551,0,0 ) ;
  }

  @Test
  public void test16() {
    plgndr.plgndr(-632,-632,0 ) ;
  }

  @Test
  public void test17() {
    plgndr.plgndr(637,147,0 ) ;
  }

  @Test
  public void test18() {
    plgndr.plgndr(677,594,0.0 ) ;
  }

  @Test
  public void test19() {
    plgndr.plgndr(716,806,0 ) ;
  }

  @Test
  public void test20() {
    plgndr.plgndr(-719,0,0 ) ;
  }

  @Test
  public void test21() {
    plgndr.plgndr(748,668,96.98681033138672 ) ;
  }

  @Test
  public void test22() {
    plgndr.plgndr(-80,0,0 ) ;
  }

  @Test
  public void test23() {
    plgndr.plgndr(893,238,-24.39190629640005 ) ;
  }

  @Test
  public void test24() {
    plgndr.plgndr(906,-368,0 ) ;
  }

  @Test
  public void test25() {
    plgndr.plgndr(949,288,0.9999999999999872 ) ;
  }

  @Test
  public void test26() {
    plgndr.plgndr(981,432,8.182783979074301 ) ;
  }

  @Test
  public void test27() {
    plgndr.plgndr(998,753,-1.0 ) ;
  }
}
