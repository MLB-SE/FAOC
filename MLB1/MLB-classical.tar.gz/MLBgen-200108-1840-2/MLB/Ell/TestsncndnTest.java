import org.junit.Test;

public class TestsncndnTest {

  @Test
  public void test0() {
    ell.sncndn(0,0.03650662577389596 ) ;
  }

  @Test
  public void test1() {
    ell.sncndn(0,0.13361370210867562 ) ;
  }

  @Test
  public void test2() {
    ell.sncndn(0,0.4723791449924022 ) ;
  }

  @Test
  public void test3() {
    ell.sncndn(0,0.99999998 ) ;
  }

  @Test
  public void test4() {
    ell.sncndn(0,0.9999999800022799 ) ;
  }

  @Test
  public void test5() {
    ell.sncndn(0,1.0 ) ;
  }

  @Test
  public void test6() {
    ell.sncndn(0,1.0000000000000002 ) ;
  }

  @Test
  public void test7() {
    ell.sncndn(0,1.0000000000138778 ) ;
  }

  @Test
  public void test8() {
    ell.sncndn(0,1.00000002 ) ;
  }

  @Test
  public void test9() {
    ell.sncndn(0,-14.433503473936653 ) ;
  }

  @Test
  public void test10() {
    ell.sncndn(0,-1.6129360561232886 ) ;
  }

  @Test
  public void test11() {
    ell.sncndn(0,17.4311584222973 ) ;
  }

  @Test
  public void test12() {
    ell.sncndn(0,18.160980634994914 ) ;
  }

  @Test
  public void test13() {
    ell.sncndn(0,1.9896089832403447 ) ;
  }

  @Test
  public void test14() {
    ell.sncndn(0,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test15() {
    ell.sncndn(0,2.465190328815662E-32 ) ;
  }

  @Test
  public void test16() {
    ell.sncndn(0,47.759814128066836 ) ;
  }

  @Test
  public void test17() {
    ell.sncndn(0,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test18() {
    ell.sncndn(0,6.509206643823703 ) ;
  }

  @Test
  public void test19() {
    ell.sncndn(0,-80.22546094768293 ) ;
  }

  @Test
  public void test20() {
    ell.sncndn(0,-82.56106525173664 ) ;
  }
}
