import org.junit.Test;

public class TestellpiTest {

  @Test
  public void test0() {
    ell.ellpi(-0.05834740401293217,0,-17.148451514327107 ) ;
  }

  @Test
  public void test1() {
    ell.ellpi(-135.08848408122154,0,0.6115301715009465 ) ;
  }

  @Test
  public void test2() {
    ell.ellpi(-153.9380400362443,0,-1.0022718233632641 ) ;
  }

  @Test
  public void test3() {
    ell.ellpi(-171.21664284644146,0,1.0 ) ;
  }

  @Test
  public void test4() {
    ell.ellpi(-18.83024902901273,0,44.09244843739933 ) ;
  }

  @Test
  public void test5() {
    ell.ellpi(-23.561944895087503,0,0.9999999999998064 ) ;
  }

  @Test
  public void test6() {
    ell.ellpi(25.132741237637653,0,1.4329241375580744 ) ;
  }

  @Test
  public void test7() {
    ell.ellpi(31.415926519935933,0,0.7558166208061385 ) ;
  }

  @Test
  public void test8() {
    ell.ellpi(31.41592652131485,0,-0.7627537241587395 ) ;
  }

  @Test
  public void test9() {
    ell.ellpi(-3.141592652540232,0,5.861246785017997 ) ;
  }

  @Test
  public void test10() {
    ell.ellpi(-31.415926545394967,0,1.6157467023120946 ) ;
  }

  @Test
  public void test11() {
    ell.ellpi(-34.55751918915676,0,-29.07897138748614 ) ;
  }

  @Test
  public void test12() {
    ell.ellpi(-34.55751918969528,0,-13.024510472966398 ) ;
  }

  @Test
  public void test13() {
    ell.ellpi(37.69911185484597,0,-0.7648672710168435 ) ;
  }

  @Test
  public void test14() {
    ell.ellpi(37.97481117900243,0,3.673500333430653 ) ;
  }

  @Test
  public void test15() {
    ell.ellpi(-39.26990897300166,0,-1.0000000000002374 ) ;
  }

  @Test
  public void test16() {
    ell.ellpi(40.840704556418466,0,-0.1426565750728147 ) ;
  }

  @Test
  public void test17() {
    ell.ellpi(40.91255137369956,0,-0.7185319570044584 ) ;
  }

  @Test
  public void test18() {
    ell.ellpi(-42.681131568904604,0,-3.823153579376765 ) ;
  }

  @Test
  public void test19() {
    ell.ellpi(43.982297150082104,0,-8.287016365591299 ) ;
  }

  @Test
  public void test20() {
    ell.ellpi(-44.459577223415536,0,0.9579928386351071 ) ;
  }

  @Test
  public void test21() {
    ell.ellpi(-4.713273929224513,0,-59.40929403667139 ) ;
  }

  @Test
  public void test22() {
    ell.ellpi(-50.93611293296085,0,37.33210603331344 ) ;
  }

  @Test
  public void test23() {
    ell.ellpi(56.54866777888355,0,-0.8651374186672957 ) ;
  }

  @Test
  public void test24() {
    ell.ellpi(56.7989003953171,0,0.9434910641814938 ) ;
  }

  @Test
  public void test25() {
    ell.ellpi(62.831853070686726,0,-1.4916406422423583 ) ;
  }

  @Test
  public void test26() {
    ell.ellpi(-62.83185312209359,0,-0.9782551619432464 ) ;
  }

  @Test
  public void test27() {
    ell.ellpi(-62.831853140500975,0,-0.8596611163493412 ) ;
  }

  @Test
  public void test28() {
    ell.ellpi(-64.40264939859077,0,0.1560827910831426 ) ;
  }

  @Test
  public void test29() {
    ell.ellpi(-65.97344573788482,0,1.1522319671652188 ) ;
  }

  @Test
  public void test30() {
    ell.ellpi(67.54424204808336,0,0.9876044839450184 ) ;
  }

  @Test
  public void test31() {
    ell.ellpi(-72.03645294297047,0,-4.578682946673539 ) ;
  }

  @Test
  public void test32() {
    ell.ellpi(-72.18640964841585,0,10.826878155062431 ) ;
  }

  @Test
  public void test33() {
    ell.ellpi(-72.25669154026342,0,-6.0110808239366865E-5 ) ;
  }

  @Test
  public void test34() {
    ell.ellpi(75.4060271994772,0,-0.5665673179812956 ) ;
  }

  @Test
  public void test35() {
    ell.ellpi(-78.53981632704708,0,0.1883255267281836 ) ;
  }

  @Test
  public void test36() {
    ell.ellpi(87.96459429094581,0,-25.745615138298646 ) ;
  }

  @Test
  public void test37() {
    ell.ellpi(-94.24777960962005,0,9.16486790328048 ) ;
  }

  @Test
  public void test38() {
    ell.ellpi(99.9999441930726,0,-1.9746698682068657 ) ;
  }
}
