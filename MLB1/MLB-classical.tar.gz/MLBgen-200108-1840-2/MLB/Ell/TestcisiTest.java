import org.junit.Test;

public class TestcisiTest {

  @Test
  public void test0() {
    frenel.cisi(0.0 ) ;
  }

  @Test
  public void test1() {
    frenel.cisi(0.24718523448281 ) ;
  }

  @Test
  public void test2() {
    frenel.cisi(10.475194862346001 ) ;
  }

  @Test
  public void test3() {
    frenel.cisi(-1.232595164407831E-32 ) ;
  }

  @Test
  public void test4() {
    frenel.cisi(-1.3549829049915019 ) ;
  }

  @Test
  public void test5() {
    frenel.cisi(-1.4981364335015035E-95 ) ;
  }

  @Test
  public void test6() {
    frenel.cisi(1.5602006504803967 ) ;
  }

  @Test
  public void test7() {
    frenel.cisi(-1.5756254969367092 ) ;
  }

  @Test
  public void test8() {
    frenel.cisi(17.00198305388723 ) ;
  }

  @Test
  public void test9() {
    frenel.cisi(1.999999999999997 ) ;
  }

  @Test
  public void test10() {
    frenel.cisi(-2.0 ) ;
  }

  @Test
  public void test11() {
    frenel.cisi(2.0 ) ;
  }

  @Test
  public void test12() {
    frenel.cisi(22.56652970695086 ) ;
  }

  @Test
  public void test13() {
    frenel.cisi(-23.657753093779647 ) ;
  }

  @Test
  public void test14() {
    frenel.cisi(29.29390683988683 ) ;
  }

  @Test
  public void test15() {
    frenel.cisi(4.062405641606119 ) ;
  }

  @Test
  public void test16() {
    frenel.cisi(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test17() {
    frenel.cisi(4.4455174989701545E-162 ) ;
  }

  @Test
  public void test18() {
    frenel.cisi(4.930380657631324E-32 ) ;
  }

  @Test
  public void test19() {
    frenel.cisi(-4.981750442201388 ) ;
  }

  @Test
  public void test20() {
    frenel.cisi(5.2710989716152616E-82 ) ;
  }

  @Test
  public void test21() {
    frenel.cisi(7.375048270082857 ) ;
  }

  @Test
  public void test22() {
    frenel.cisi(-86.81917793572802 ) ;
  }

  @Test
  public void test23() {
    frenel.cisi(-88.07581340914514 ) ;
  }
}
