import org.junit.Test;

public class TestStatCalcTest {

  @Test
  public void test0() {
    concolic.TestStatCalc.run(102 ) ;
  }

  @Test
  public void test1() {
    concolic.TestStatCalc.run(111 ) ;
  }

  @Test
  public void test2() {
    concolic.TestStatCalc.run(-122 ) ;
  }

  @Test
  public void test3() {
    concolic.TestStatCalc.run(-183 ) ;
  }

  @Test
  public void test4() {
    concolic.TestStatCalc.run(248 ) ;
  }

  @Test
  public void test5() {
    concolic.TestStatCalc.run(3 ) ;
  }

  @Test
  public void test6() {
    concolic.TestStatCalc.run(-319 ) ;
  }

  @Test
  public void test7() {
    concolic.TestStatCalc.run(332 ) ;
  }

  @Test
  public void test8() {
    concolic.TestStatCalc.run(-345 ) ;
  }

  @Test
  public void test9() {
    concolic.TestStatCalc.run(351 ) ;
  }

  @Test
  public void test10() {
    concolic.TestStatCalc.run(458 ) ;
  }

  @Test
  public void test11() {
    concolic.TestStatCalc.run(6 ) ;
  }

  @Test
  public void test12() {
    concolic.TestStatCalc.run(678 ) ;
  }

  @Test
  public void test13() {
    concolic.TestStatCalc.run(-803 ) ;
  }

  @Test
  public void test14() {
    concolic.TestStatCalc.run(-821 ) ;
  }

  @Test
  public void test15() {
    concolic.TestStatCalc.run(830 ) ;
  }

  @Test
  public void test16() {
    concolic.TestStatCalc.run(856 ) ;
  }
}
