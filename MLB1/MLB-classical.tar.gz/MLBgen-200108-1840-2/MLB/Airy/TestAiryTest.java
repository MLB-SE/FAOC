import org.junit.Test;

public class TestAiryTest {

  @Test
  public void test0() {
    airy.main_airy(0.23572205239130994 ) ;
  }

  @Test
  public void test1() {
    airy.main_airy(-10.374620973519782 ) ;
  }

  @Test
  public void test2() {
    airy.main_airy(1.232595164407831E-32 ) ;
  }

  @Test
  public void test3() {
    airy.main_airy(15.718095068857039 ) ;
  }

  @Test
  public void test4() {
    airy.main_airy(1.734723475976807E-18 ) ;
  }

  @Test
  public void test5() {
    airy.main_airy(-18.14724848355131 ) ;
  }

  @Test
  public void test6() {
    airy.main_airy(-2.220446049250313E-16 ) ;
  }

  @Test
  public void test7() {
    airy.main_airy(2.220446049250313E-16 ) ;
  }

  @Test
  public void test8() {
    airy.main_airy(-2.465190328815662E-32 ) ;
  }

  @Test
  public void test9() {
    airy.main_airy(-3.0814879110195774E-33 ) ;
  }

  @Test
  public void test10() {
    airy.main_airy(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test11() {
    airy.main_airy(5.403227209783267E-225 ) ;
  }

  @Test
  public void test12() {
    airy.main_airy(-6.162975822039155E-33 ) ;
  }

  @Test
  public void test13() {
    airy.main_airy(-7.578085396526291 ) ;
  }

  @Test
  public void test14() {
    airy.main_airy(75.87422871305117 ) ;
  }

  @Test
  public void test15() {
    airy.main_airy(-82.40122041320899 ) ;
  }

  @Test
  public void test16() {
    airy.main_airy(-8.645163535653227E-224 ) ;
  }

  @Test
  public void test17() {
    airy.main_airy(90.66828567621144 ) ;
  }
}
