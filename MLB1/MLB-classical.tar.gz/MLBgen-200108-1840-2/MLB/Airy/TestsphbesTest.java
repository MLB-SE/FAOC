import org.junit.Test;

public class TestsphbesTest {

  @Test
  public void test0() {
    airy.sphbes(0,27.758195807449866 ) ;
  }

  @Test
  public void test1() {
    airy.sphbes(0,38.30407301586692 ) ;
  }

  @Test
  public void test2() {
    airy.sphbes(0,85.5737750674279 ) ;
  }

  @Test
  public void test3() {
    airy.sphbes(113,0 ) ;
  }

  @Test
  public void test4() {
    airy.sphbes(-1,42.592152433076336 ) ;
  }

  @Test
  public void test5() {
    airy.sphbes(-221,39.84082713770832 ) ;
  }

  @Test
  public void test6() {
    airy.sphbes(-244,-69.85032915892518 ) ;
  }

  @Test
  public void test7() {
    airy.sphbes(26,-6.9E-323 ) ;
  }

  @Test
  public void test8() {
    airy.sphbes(296,0.0 ) ;
  }

  @Test
  public void test9() {
    airy.sphbes(298,89.60369707807726 ) ;
  }

  @Test
  public void test10() {
    airy.sphbes(-334,0.0 ) ;
  }

  @Test
  public void test11() {
    airy.sphbes(367,-4.742906768832867 ) ;
  }

  @Test
  public void test12() {
    airy.sphbes(-377,0.0 ) ;
  }

  @Test
  public void test13() {
    airy.sphbes(411,96.50494997964609 ) ;
  }

  @Test
  public void test14() {
    airy.sphbes(427,2.000000000000022 ) ;
  }

  @Test
  public void test15() {
    airy.sphbes(454,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test16() {
    airy.sphbes(491,1.8E-322 ) ;
  }

  @Test
  public void test17() {
    airy.sphbes(532,-81.72863234351315 ) ;
  }

  @Test
  public void test18() {
    airy.sphbes(547,0.0 ) ;
  }

  @Test
  public void test19() {
    airy.sphbes(-552,0 ) ;
  }

  @Test
  public void test20() {
    airy.sphbes(-553,58.14875901436085 ) ;
  }

  @Test
  public void test21() {
    airy.sphbes(-561,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test22() {
    airy.sphbes(57,-1.265E-321 ) ;
  }

  @Test
  public void test23() {
    airy.sphbes(588,0.0 ) ;
  }

  @Test
  public void test24() {
    airy.sphbes(646,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test25() {
    airy.sphbes(-65,2.0000000000000004 ) ;
  }

  @Test
  public void test26() {
    airy.sphbes(659,87.33130089778228 ) ;
  }

  @Test
  public void test27() {
    airy.sphbes(-66,4.440892098500626E-16 ) ;
  }

  @Test
  public void test28() {
    airy.sphbes(-695,1.164794471517496E-16 ) ;
  }

  @Test
  public void test29() {
    airy.sphbes(-751,2.0 ) ;
  }

  @Test
  public void test30() {
    airy.sphbes(762,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test31() {
    airy.sphbes(-788,-78.43876179673228 ) ;
  }

  @Test
  public void test32() {
    airy.sphbes(-804,33.998373733981055 ) ;
  }

  @Test
  public void test33() {
    airy.sphbes(-808,-2.7210567689796777E-17 ) ;
  }

  @Test
  public void test34() {
    airy.sphbes(886,0.0 ) ;
  }

  @Test
  public void test35() {
    airy.sphbes(897,1.58E-322 ) ;
  }

  @Test
  public void test36() {
    airy.sphbes(914,-92.18940721857632 ) ;
  }

  @Test
  public void test37() {
    airy.sphbes(935,4.3368086899420177E-19 ) ;
  }
}
