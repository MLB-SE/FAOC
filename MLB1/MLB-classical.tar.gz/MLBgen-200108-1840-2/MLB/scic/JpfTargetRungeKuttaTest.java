import org.junit.Test;

public class JpfTargetRungeKuttaTest {

  @Test
  public void test0() {
    scic.RungeKutta.rungeKutta(17.194208463394972 ) ;
  }

  @Test
  public void test1() {
    scic.RungeKutta.rungeKutta(2704.1332622238046 ) ;
  }

  @Test
  public void test2() {
    scic.RungeKutta.rungeKutta(2706.214875506416 ) ;
  }

  @Test
  public void test3() {
    scic.RungeKutta.rungeKutta(2710.5742716841305 ) ;
  }

  @Test
  public void test4() {
    scic.RungeKutta.rungeKutta(2725.019517364879 ) ;
  }

  @Test
  public void test5() {
    scic.RungeKutta.rungeKutta(2726.1869394456385 ) ;
  }

  @Test
  public void test6() {
    scic.RungeKutta.rungeKutta(2726.5023711685963 ) ;
  }

  @Test
  public void test7() {
    scic.RungeKutta.rungeKutta(-50.627159930309396 ) ;
  }

  @Test
  public void test8() {
    scic.RungeKutta.rungeKutta(58.297349939985196 ) ;
  }

  @Test
  public void test9() {
    scic.RungeKutta.rungeKutta(58.956409125703146 ) ;
  }

  @Test
  public void test10() {
    scic.RungeKutta.rungeKutta(71.0802606601591 ) ;
  }

  @Test
  public void test11() {
    scic.RungeKutta.rungeKutta(75.05912779502148 ) ;
  }

  @Test
  public void test12() {
    scic.RungeKutta.rungeKutta(-76.8258688969927 ) ;
  }

  @Test
  public void test13() {
    scic.RungeKutta.rungeKutta(87.16893942050402 ) ;
  }

  @Test
  public void test14() {
    scic.RungeKutta.rungeKutta(94.31119795207138 ) ;
  }

  @Test
  public void test15() {
    scic.RungeKutta.rungeKutta(95.36845862385564 ) ;
  }

  @Test
  public void test16() {
    scic.RungeKutta.rungeKutta(98.21525053858758 ) ;
  }

  @Test
  public void test17() {
    scic.RungeKutta.rungeKutta(99.53128944795097 ) ;
  }
}
