import org.junit.Test;

public class JpfTargetEulerMethodTest {

  @Test
  public void test0() {
    scic.EulerMethod.euler(-13.606945433114873 ) ;
  }

  @Test
  public void test1() {
    scic.EulerMethod.euler(-1.9946221946070242 ) ;
  }

  @Test
  public void test2() {
    scic.EulerMethod.euler(-85.8310583641032 ) ;
  }
}
