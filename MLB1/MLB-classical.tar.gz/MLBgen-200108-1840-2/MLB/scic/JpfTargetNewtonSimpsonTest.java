import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(0.42940876767087843,0 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(-0.8712907572059407,0.33517583673951545 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(1.1015794157629415,-92.4203422610317 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(-1.109612440954706,0 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(-1.1444108223018077,91.3080373496922 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(1.5085074264029004,-9.895848259245724 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonSimpson.newton(-15.413588404100054,-80.38828362924137 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonSimpson.newton(1.644853504967009,0 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonSimpson.newton(1.644854979934997,77.02688884160699 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonSimpson.newton(1.644854980114559,-5.098006068521219E-10 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonSimpson.newton(1.644938439429001,2.3398032178432413E-8 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonSimpson.newton(-19.697521683084076,0 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonSimpson.newton(-21.237886568026525,0 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonSimpson.newton(-2.1981719474825354,-26.21038553037687 ) ;
  }

  @Test
  public void test14() {
    scic.NewtonSimpson.newton(2.295356353556869,0 ) ;
  }

  @Test
  public void test15() {
    scic.NewtonSimpson.newton(-28.210836347942816,-24.761310311345724 ) ;
  }

  @Test
  public void test16() {
    scic.NewtonSimpson.newton(3.0933113497841447,-51.218573968659406 ) ;
  }

  @Test
  public void test17() {
    scic.NewtonSimpson.newton(3.098837966138575,-52.59976722345059 ) ;
  }

  @Test
  public void test18() {
    scic.NewtonSimpson.newton(-5.754702015869697,0 ) ;
  }

  @Test
  public void test19() {
    scic.NewtonSimpson.newton(-6.209595127676266,0 ) ;
  }

  @Test
  public void test20() {
    scic.NewtonSimpson.newton(66.30109520561595,0 ) ;
  }

  @Test
  public void test21() {
    scic.NewtonSimpson.newton(9.146345956372983,0 ) ;
  }
}
