import org.junit.Test;

public class JpfTargetSimpsonSolverTest {

  @Test
  public void test0() {
    scic.SimpsonSolver.simpson(-23.18214475909702,85.445259123271 ) ;
  }

  @Test
  public void test1() {
    scic.SimpsonSolver.simpson(-73.15702451332587,47.768349315500984 ) ;
  }

  @Test
  public void test2() {
    scic.SimpsonSolver.simpson(-93.11935463585321,-14.656870549152103 ) ;
  }
}
