import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(-14.357014974807441,14.26605189699815 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(-14.750000031256944,61.413264246760335 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(-181.25000000000003,-30.341040593871057 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(23.698872519181748,0 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(-27.513626206567064,2.1704183166873037 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(-38.23759444305335,19.61530359497752 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonMethod.newton(-41.25000000000001,0 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonMethod.newton(-43.63090873869062,0.1733721159786299 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonMethod.newton(-54.25,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonMethod.newton(674.3562768034285,0 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonMethod.newton(77.12802848816295,44.0693430237728 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonMethod.newton(77.75991427474727,0 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonMethod.newton(-94.22748607061615,0 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonMethod.newton(94.90428891155301,97.5763776066558 ) ;
  }
}
