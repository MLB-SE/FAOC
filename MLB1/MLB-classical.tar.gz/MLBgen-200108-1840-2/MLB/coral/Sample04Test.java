import org.junit.Test;

public class Sample04Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark04(-58.28420936197038 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark04(66.84004534896249 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark04(-673.2007926717638 ) ;
  }
}
