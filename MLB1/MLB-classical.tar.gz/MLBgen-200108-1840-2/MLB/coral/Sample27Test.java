import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(-27.426982941702178,-90.26761116550335,-78.10238020409552 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(-30.628823594655067,31.15860572238625,52.58359837711222 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(-44.54243068700203,-61.07113352960376,-70.55974740237396 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(62.70458878424719,91.60168346567858,12.265823294901807 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(-78.98099271052124,-40.033955711477475,63.520850947219344 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(8.38710203184654,85.32033993717793,51.607634230580445 ) ;
  }
}
