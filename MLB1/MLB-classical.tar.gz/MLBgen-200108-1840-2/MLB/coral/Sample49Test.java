import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(10.107898520247517,52.0656141510685 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(14.810140036132937,35.189859963867065 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(16.90841919904625,85.98473281247558 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(24.056800875315858,24.80603015049924 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(2.707952454565114E-5,2.9785864432613955E-7 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(2.7850857470951285E-12,1.6618406393498801E-6 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(-32.80448606202661,77.59337580765441 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(39.21394099483339,39.69594856131463 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(46.4788543248504,79.10298507030996 ) ;
  }
}
