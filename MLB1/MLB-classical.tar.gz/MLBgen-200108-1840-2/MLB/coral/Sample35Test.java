import org.junit.Test;

public class Sample35Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark35(-42.41150083137535,-30.913154129038656 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark35(47.12386603029407,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark35(7.713429568559832,-8.867658974810922 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark35(77.74644286941762,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark35(-86.39379798249254,-83.77211947396768 ) ;
  }
}
