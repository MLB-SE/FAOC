import org.junit.Test;

public class Sample72Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark72(15.147929085405586,67.77203363447575,55.14623514205846,-95.98693963872577,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark72(15.816847612222322,9.533662305042736,0,0,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark72(1.8438322837270675,-20.101309737094937,0,0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark72(42.59786886247119,-22.92308807131083,0,0,0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark72(43.97481476348861,97.78482194753062,4.407050178712751,0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark72(-54.42021589708905,2.785039627827814,-68.99818357401615,-97.41286859307803,-84.10657695726063,49.12353200743713,-76.94778547047048 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark72(57.62714634276571,73.37028868457531,63.95713167390653,0,0,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark72(66.67316479764085,10.128700468214944,-69.9367018674147,-32.34490584019571,104.9759188793952,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark72(-68.16969801417252,-21.999875872356654,-53.28179569367114,-19.219242103537383,0,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark72(70.64239209112162,-36.529554725121535,-46.66020010745684,-25.67570826661516,-14.850247763253279,-63.64165383817242,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark72(-73.83680627379314,51.534362371343974,-79.31868146695041,-96.56063692632509,35.94597543295396,74.00838542725401,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark72(-79.11217024593151,91.4776540327639,-84.45153456826452,0,0,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark72(-80.09916312367113,65.06701141356481,-100.0,12.051409647741515,100.0,100.0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark72(-80.64865516620436,71.7513650845848,59.5111832944323,-56.41487921902227,68.92718949981673,18.51092646201024,-90.76755749457548 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark72(83.18420697317444,-66.64113886113824,21.751802156491777,-66.24529562301112,0,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark72(88.91993678685319,-62.040800729198594,33.94954131683048,46.65798344747992,30.976318543480886,92.81680291990051,52.35917160188873 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark72(-91.66802248670257,28.610664979963758,-44.47189784256941,-51.28840068915752,-68.60123187262008,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark72(-93.03575373527548,-54.39864906796637,58.97297261048344,-100.0,-100.0,0,0 ) ;
  }
}
