import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(0.14105959864127726,-58.104674368070654,-34.615423451902586,8.998319971954345 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(0.7759495946987158,92.73240883513049,13.996624463905391,-16.197105349634583 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(0.9287350095275131,-64.98718018503206,-77.67954307751683,4.521916778621486 ) ;
  }
}
