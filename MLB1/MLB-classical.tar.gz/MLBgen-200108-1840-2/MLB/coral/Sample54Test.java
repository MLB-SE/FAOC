import org.junit.Test;

public class Sample54Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark54(14.336341092217795,19.629582490300116,6.343891122587181 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark54(24.015456135605945,-23.790846148857263,58.78502446824962 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark54(25.4461500368443,15.413420995803902,36.86967820167192 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark54(32.66252491804872,2.2075392429095047,29.3327604575303 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark54(39.95661912993799,2.7701363004125206,58.62377580692469 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark54(42.45720161829681,-57.882187031084584,-32.93852399071555 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark54(53.18581949629478,2.7771672205686952,54.145199414866376 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark54(54.56261160172846,-73.58258561591518,78.49020778049879 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark54(62.209616829586054,3.347279833302325,63.184139791471125 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark54(66.62238124789931,-6.975168355046321,64.7182302806541 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark54(67.39770345467184,-0.9869734220070683,98.14482953845567 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark54(7.485238023838619,-21.309014026298897,23.88662238898243 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark54(76.32292875651375,-40.95568503854676,77.31708835149843 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark54(88.42187205757918,-93.70429417240076,96.21593447336721 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark54(89.96756277390963,11.614031144077007,91.60787788308802 ) ;
  }
}
