import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(37.61291263868071,-31.2066023419232 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(-5.089951882390139,99.36563546107391 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(55.303319739723776,35.50985324153194 ) ;
  }
}
