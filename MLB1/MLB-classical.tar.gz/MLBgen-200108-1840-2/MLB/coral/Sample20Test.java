import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(21.894920970948434,-49.21535371655747 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(33.77391772731551,-75.35957764417888 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(4.866545970068188,-32.19427052170272 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(-50.610802897428876,-11.664772722823642 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(78.803155157742,-24.0177364129423 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(85.48205968275083,-94.1927640692681 ) ;
  }
}
