import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(0.02019344762537001,-73.28152080952621 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(-37.93294678723606,-66.40798962523051 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(69.7300594234411,-16.258558946216766 ) ;
  }
}
