import org.junit.Test;

public class Sample43Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark43(-0.9568903876943671,100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark43(1.1061034365392572,1.1061034365392572 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark43(1.6753079039554144,2.806656573055484 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark43(2.2967351957346835,64.59164164802226 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark43(3.009033918282242,36.52164134356261 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark43(34.28941514495813,40.469859477186276 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark43(61.23808959175315,8.54942156442307 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark43(7.6753542469691425,0.8132734285405405 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark43(9.808068607367733,104.4115915817728 ) ;
  }
}
