import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(3.043908271484243,9.265394801977978 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(-6.943451892619681,48.216975446531656 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(72.98566773802281,-53.16595744820107 ) ;
  }
}
