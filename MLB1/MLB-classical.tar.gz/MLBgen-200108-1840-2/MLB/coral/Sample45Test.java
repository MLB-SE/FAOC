import org.junit.Test;

public class Sample45Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark45(0.0,-100.0,30.63152013972049 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark45(10.611267447021213,12.611267447021213,8.605461330062854 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark45(-1.691535521933929,-98.38869794239207,15.568206161302143 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark45(-210.46615449328155,-437.6163078399699,15.593924816478946 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark45(21.13667011426348,-14.733943844301194,18.50825608803281 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark45(28.683320149007102,62.12164297375412,80.15060762651655 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark45(49.97321767650635,90.60912335772088,86.30110735670223 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark45(59.25288749730461,-48.54622315496427,50.724653250092814 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark45(6.088784882504086,15.492366880449751,47.497073735238814 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark45(63.86734109860234,60.642542348081406,89.50012643513384 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark45(64.27452450234227,96.51737066378209,50.41002983668329 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark45(6.938893903907228E-18,1.0000000003637142,0.9953895984439711 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark45(7.105427357601002E-15,1.0000000000005085,1.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark45(-81.85482605243507,41.89682769867048,9.666105749878213 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark45(84.92437020240638,1.0,7.765453106941154 ) ;
  }
}
