import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(0.09950191568380262,0.29140329811126264,-49.3728574829889,-98.3776224883048 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(0.13638036971843803,0.9628846953764452,91.56388975284538,-0.8205206916556733 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(-0.6759787006885603,-0.9931548169575137,25.735667286710267,-63.64873823158747 ) ;
  }
}
