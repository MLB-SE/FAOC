import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(45.2201830483576,-53.020437875424676 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(-4.754697270939872,65.92775920658624 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(-96.79558761738939,-6.159473693848156 ) ;
  }
}
