import org.junit.Test;

public class Sample01Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark01(15.82647740854624,-34.89828152156281 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark01(32.36287528224992,-74.01692254552773 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark01(76.65995830310263,18.92285963021361 ) ;
  }
}
