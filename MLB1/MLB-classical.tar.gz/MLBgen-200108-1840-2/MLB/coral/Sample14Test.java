import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(0.43134108489158507,-5.771410500632794,-65.33875556260796,76.97480423864619 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(0.8686333835074862,8.390187470824117,88.10692172369292,100.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(0.9602644373522935,-9.633125836275909,31.4252587141128,-97.35812506691168 ) ;
  }
}
