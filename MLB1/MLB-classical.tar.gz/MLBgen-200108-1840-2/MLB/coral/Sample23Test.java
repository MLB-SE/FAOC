import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(15.359529570595654,91.28040380105705,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(2.1900545888964853,-99.62080182574982,0,6.613501921256587 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(-42.01546679376478,-53.82832539792359,11.782789929381948,91.87020799723888 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(62.57547690717373,27.53263793483672,19.63158088370099,-49.91797886559604 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(65.14627047260947,-65.36076260959834,0,76.59146911311893 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(67.3102332184236,-77.32164123195824,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(-70.14067372626923,-71.55360966461026,37.27736210836318,48.786141224823666 ) ;
  }
}
