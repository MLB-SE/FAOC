import org.junit.Test;

public class Sample18Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark18(0.18331957657578357 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark18(0.7867029930090865 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark18(0.9595496299847907 ) ;
  }
}
