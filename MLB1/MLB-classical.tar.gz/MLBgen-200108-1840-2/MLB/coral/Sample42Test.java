import org.junit.Test;

public class Sample42Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark42(1.0553324414834202,1.0553324414834202 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark42(1.0,-73.12134811689884 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark42(12.941524025231189,22.959441560830513 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark42(14.55260541440471,78.52588115201306 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark42(2.1045624695204195,10.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark42(48.87339950607134,12.456279880498869 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark42(55.75272837493609,0.44319408048940545 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark42(-6.9214416332328375,100.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark42(81.84544628907184,97.0162860691396 ) ;
  }
}
