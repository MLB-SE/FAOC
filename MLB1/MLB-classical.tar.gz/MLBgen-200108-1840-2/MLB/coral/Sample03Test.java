import org.junit.Test;

public class Sample03Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark03(-21.336446206400254,34.65540924989446 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark03(44.21062798793085,-94.65917529254133 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark03(-80.07262512231704,69.07705083475275 ) ;
  }
}
