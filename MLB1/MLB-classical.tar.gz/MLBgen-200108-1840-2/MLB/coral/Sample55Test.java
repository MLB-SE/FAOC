import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(35.22361569059563,-95.08979901148813,-54.70380524431408 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(69.67417673391432,10.568399881564844,21.468950749637244 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(9.252094162087076,59.06253730862784,-7.122093967725235 ) ;
  }
}
