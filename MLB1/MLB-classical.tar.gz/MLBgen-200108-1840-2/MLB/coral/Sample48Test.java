import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(60.30902907531589,84.62822028507179,39.67939431104472 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(-72.07355371546487,16.546705019567426,-2.8162881575709378 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(-76.54612659165579,1.4710550964190663,-75.07507149523673 ) ;
  }
}
