import org.junit.Test;

public class Sample25Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark25(100.0,100.0,20.166575980001625,46.122124215263966,85.25573664490346 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark25(-100.0,-77.66727354248168,-100.0,0,-48.86897539533679 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark25(-1.4683074412476884,-2.713613048698164,12.437725339058673,2.5468466464654114,9.240043723663007 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark25(15.35251254184422,-90.87252548695209,27.955070251409907,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark25(21.485841703134966,82.89477745537323,-21.741243267943915,0,-97.85236118073908 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark25(25.78436808141133,44.00112344946848,56.37944433369822,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark25(-37.92433418766666,-89.30571708618862,-100.0,1.2430091581435403,71.32371660747751 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark25(-56.13659681368786,-73.63987799786801,-44.42188588381736,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark25(70.4436542397197,-92.21060410302506,71.30132660207698,-18.902579451290038,-22.855926811899536 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark25(95.59864646262395,-29.065479461917292,-95.50795450185663,86.2001818786598,-57.00658175806288 ) ;
  }
}
