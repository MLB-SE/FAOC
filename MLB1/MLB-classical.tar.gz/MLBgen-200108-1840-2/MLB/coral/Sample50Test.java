import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(0.5364930083478363,49.46350699165217 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(0.6479595495404435,29.338611481150444 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(11.57323004943494,15.990355000872796 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(1.1649544176539628E-12,3.183475614087933E-7 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(2.0426807145808214E-4,0.014323820856192663 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(20.757511108074624,21.506417536497178 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(22.17898039552457,27.821019604475424 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(27.452046739546006,32.96873698226136 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(38.05683214661207,38.54624986277538 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(48.7287727016153,93.65037553983103 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(-82.74347453638336,25.89003132106498 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(9.46564404473057,22.46564404473057 ) ;
  }
}
