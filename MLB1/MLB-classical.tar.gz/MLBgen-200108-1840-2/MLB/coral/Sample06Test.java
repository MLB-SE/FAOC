import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(37.80250272795437,15.120372423864419,-29.515912515422144 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(-73.25182699680938,80.9342189039721,-80.04625413487732 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(85.11382656845572,87.86506590516453,-20.542508624388176 ) ;
  }
}
