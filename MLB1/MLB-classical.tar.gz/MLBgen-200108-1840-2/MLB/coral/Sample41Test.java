import org.junit.Test;

public class Sample41Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark41(-0.42769063181115996,-8.876766579183368 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark41(0.7786957565729153,-0.17232867526825035 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,1.9999999999999998 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0000000000000004 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark41(-2.014293446030706,6.071671532752963 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark41(4.966829867287784,19.702569063294206 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark41(6.381558258918247,34.34272755304944 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark41(-8.378458294875045,82.3658278430764 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark41(8.93224479036244,70.85275220459451 ) ;
  }
}
