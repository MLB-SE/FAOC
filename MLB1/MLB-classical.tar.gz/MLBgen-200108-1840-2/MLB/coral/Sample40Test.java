import org.junit.Test;

public class Sample40Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark40(-2.2769267426201907,42.20596227657859 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark40(6.501229543020237,35.76475602801889 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark40(-77.73178646997908,13.706567283709674 ) ;
  }
}
