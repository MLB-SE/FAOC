import org.junit.Test;

public class Sample91Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark91(30.16771186235107,27.026119208761276 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark91(40.79417367834132,25.086210410392358 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark91(49.712614067471236,83.74227224974001 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark91(-83.141013537372,64.86126338912709 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark91(-84.82300164692441,150.79644719261185 ) ;
  }
}
