import org.junit.Test;

public class Sample28Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark28(55.03081554013849 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark28(7.079484875489953 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark28(7.389056098930651 ) ;
  }
}
