import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark07(0,35.870856359782444,0,-29.716400635476706 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(0,52.475324148923676,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(0,-7.330382861757113,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(0,-94.19138128113434,0,-95.97280864896425 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(-35.13935619823239,-70.91738699455969,4.845873612956581,45.25817002606277 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(59.897994705119046,40.039370806333395,-58.19306481412872,-70.79479532557009 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(78.96293025240402,-29.095765192713145,71.68586794587299,-94.85363154369428 ) ;
  }
}
