import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(10.702757555582053,22.85918760832928,-19.88074345916995 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(24.479445369092055,37.06975610995065,37.70570280668189 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(30.24761097676938,22.768743696610244,39.163049618932746 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark52(70.97543115925751,6.101289516162041,70.35675182298135 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark52(77.60011747718357,52.42500765014236,54.040651831021734 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark52(7.760716065095565,-79.77661935397136,-53.97267631539655 ) ;
  }
}
