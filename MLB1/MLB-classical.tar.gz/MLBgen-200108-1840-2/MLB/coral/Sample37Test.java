import org.junit.Test;

public class Sample37Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark37(15.664622692377492,49.857020987495446,92.1332858676605 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark37(15.707910236413518,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark37(-24.972945010406406,-7.779138823063119,82.87245638839903 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark37(-47.40166511378718,39.51062631696544,75.52104512603879 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark37(83.96084914146473,0,0 ) ;
  }
}
