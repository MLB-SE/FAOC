import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(-33.19747184376844,-89.15166458072777,59.665176991311114,55.16271988197764,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(-5.569653125342998E-8,100.0,100.0,100.0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(-9.337100546839112E-9,100.0,100.0,100.0,0 ) ;
  }
}
