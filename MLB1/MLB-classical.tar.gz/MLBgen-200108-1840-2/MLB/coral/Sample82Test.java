import org.junit.Test;

public class Sample82Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark82(-1.972288550255996E-5,-5.070252016978974 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark82(35.21862799306518,98.62503094554137 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark82(38.61392428889421,2.58973937100615E-6 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark82(4.7826000342254815E-5,2.0909128776058004 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark82(-48.89465296315556,55.73649361643044 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark82(-75.09003316349758,-1.3317346628714972E-6 ) ;
  }
}
