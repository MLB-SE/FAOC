import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(-13.837451382660774,-22.991525660440246 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(-15.652979808659381,-71.401043039128 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(-22.306645918391382,75.94636586782454 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(-76.37683911302031,-49.009721929093516 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(-78.38136491876404,-51.18039015077902 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(79.98427253896868,29.7171803791195 ) ;
  }
}
