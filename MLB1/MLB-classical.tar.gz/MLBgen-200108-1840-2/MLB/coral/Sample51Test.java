import org.junit.Test;

public class Sample51Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark51(0.5601835161376024,29.790012212024607 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark51(0.8558997041225416,30.51277346751354 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark51(11.484086921342794,49.44668875866313 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark51(1.4149257704945468,43.06194313573033 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark51(1.6456051565587158E-4,4.0825282575067084E-6 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark51(2.38427227238829,47.615727727611706 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark51(2.4424576198904015E-16,1.562836235071589E-8 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark51(-28.264794906589287,66.32464601294186 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark51(3.065553437758524,46.934446562241476 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark51(30.696287178272684,43.923751524045116 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark51(60.156390448203155,83.3899765051213 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark51(9.637604779520402,38.37358051679044 ) ;
  }
}
