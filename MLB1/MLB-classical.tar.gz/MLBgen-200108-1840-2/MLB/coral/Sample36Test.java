import org.junit.Test;

public class Sample36Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark36(-4.290101372239334,-10.041917105363595,7.632631714874833 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark36(44.43215362311528,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark36(62.95682865034641,-86.05087511998548,15.92040139875941 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark36(78.53980435029895,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark36(-80.83015438682774,-100.0,7.36616610366977 ) ;
  }
}
