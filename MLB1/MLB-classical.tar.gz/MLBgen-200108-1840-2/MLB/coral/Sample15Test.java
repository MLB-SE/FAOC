import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(0.11482093537689764,-4.798060846908328,28.671033961278226,39.53664173105827 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(0.17547047845229713,13.095924157302875,0.005246578676663479,98.03321822040273 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(-0.4159765785355347,71.34352514836613,-98.23893224258973,78.64547265480613 ) ;
  }
}
