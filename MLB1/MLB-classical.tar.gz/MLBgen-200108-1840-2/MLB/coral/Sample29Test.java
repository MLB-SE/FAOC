import org.junit.Test;

public class Sample29Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark29(1.6094379124341005 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark29(-38.96672545553683 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark29(58.77622495244276 ) ;
  }
}
