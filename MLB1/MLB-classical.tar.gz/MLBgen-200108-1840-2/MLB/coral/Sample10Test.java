import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(-12.52349037599312,26.872113850417705,-11.985861009079343 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(-22.917727423182626,-66.92614941103652,41.8892408904093 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(51.532738529057234,-4.827122882066396,-77.08704549408631 ) ;
  }
}
