import org.junit.Test;

public class Sample58Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark58(0,2.5459932411047106,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark58(0,-27.245515494924405,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark58(11.996956123066765,23.13061235749078,54.668714420156974,100.0,62.39324729618133 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark58(-14.042397662507568,20.223462639944884,98.02868026875996,-10.875973425099588,-44.102596136182036 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark58(1.637022800368132,63.521069862863214,-65.1759023422131,86.94726945274925,96.75978861169853 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark58(2.578492659068301,15.923161840511252,-19.0169296204584,93.07164924763501,41.87894011187687 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark58(26.44094161445811,26.829802801213702,-53.889197042354844,97.91923242772981,-39.05904334301504 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark58(43.31251544617106,47.22239048279195,-89.57900577192461,50.77856261429886,40.82007391502424 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark58(53.04508376629443,18.13421820257858,-70.19253524119725,62.44342498435856,74.82610652140114 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark58(57.780957469442036,1.5782212051114897,-58.55355800436235,35.53737702357589,66.83854806996064 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark58(69.97338790552669,58.64091889657715,78.80549008231836,43.98526766401693,71.06030751430171 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark58(72.14018274201251,75.18222094351884,57.37217551610465,63.66304982572484,-47.549121783806946 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark58(86.76129431534046,-0.9706991014056122,4.040010308913267,-21.695558626214257,-38.14196308944482 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark58(94.48425210372463,40.68933463935346,4.513308210418174,34.77675339997839,30.094675075156914 ) ;
  }
}
