import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(-1.2686373561941766,-49.36015497683814,63.64622118273663 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(24.61784458324597,-47.416829156550236,-8.030299948740478 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(47.30007015199925,11.545283674971046,85.44934876345113 ) ;
  }
}
