import org.junit.Test;

public class Sample26Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark26(-0.2958439326693707,-27.01751283284854,86.32185842205527,43.15374382994068,-8.847670583667067 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark26(1.316927615091899,22.040810593054957,77.86170237635193,70.57790171120126,70.47710700860193 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark26(-20.31567767787689,21.82751240860479,-11.886773551691363,0,95.85296048053343 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark26(45.98242715689676,-71.55931163877098,31.30290066054377,0,52.012436325477275 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark26(-49.88056460295576,-77.90132204246578,11.794115486340687,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark26(55.976140442106484,90.71321825102827,81.0715962072285,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark26(-59.530386223615196,-77.04366297807579,-84.27226728808255,19.35353179137992,96.13872836170742 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark26(75.0931758525625,6.098690328930175,-66.869397865108,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark26(85.04655365624134,0.5385327097898909,28.071718955517838,44.65837468422956,-96.978554040405 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark26(-98.3121590367699,98.95996511525496,-100.0,77.06782890732369,-8.05159943220628 ) ;
  }
}
