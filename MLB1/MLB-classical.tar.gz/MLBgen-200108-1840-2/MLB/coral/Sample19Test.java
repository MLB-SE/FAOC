import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(-0.7459080257293635,19.0397978437217,0.5348669006075966 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(0.8304474985099404,15.827870194216104,0.3831572518178774 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(0.9208034835154488,82.70914460827987,-0.34920643906097754 ) ;
  }
}
