import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,-18.339603002985584 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,6.409795942892885 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(100.0,-100.0,-100.0,100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(10.297687498113987,0.136541464018066,83.72813969575071,-71.75738662687522 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(1.325405234148164,-1.4989351750852684,97.00951055650472,-51.720945460701785 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(13.35135361703411,-2.090319744968986,53.396919922233394,-38.94404450595779 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(14.278026160531994,1.5956946981979723,-52.607466443988315,7.25897173249923 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(1.5973666240689632,-7.105427357601002E-15,-100.0,100.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(26.80530567867606,7.61991194857265,32.23834048495099,3.5177972999671194 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(3.126003463813134,18.567059054706107,32.82750273547127,-95.15466350170443 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(45.47485246800193,13.515876218443012,-48.60775636041217,-56.34292432776826 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(53.97301400741219,21.320195432312673,2.4558586585859103,89.82580297153612 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(69.49372552549438,0.0,100.0,-100.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(76.22084303112473,45.74346019322613,-61.635486729571284,-17.55210782934458 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(79.26065895283554,-78.37107909065695,90.43658865798824,-3.345612376636737 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(80.57531682099795,49.68320253867961,59.82599251744199,-54.86015775961768 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(87.14939622915281,41.15481591772786,30.704312250957656,-57.09248728752825 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(-88.58622696973424,14.295059373719909,-61.817625522197915,-99.75096226531312 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(92.88374418561432,-13.23817763370134,67.76537018344405,26.64332196862877 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(-9.391130949983335,8.230209845088893,-71.02757496127883,61.18208607098853 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(98.54846719807341,-97.71109040976368,87.78922303164757,-28.859156117599483 ) ;
  }
}
