import org.junit.Test;

public class Sample44Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark44(-0.9501686600108502,100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark44(3.953375946475674,70.47278776228754 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark44(45.82665495852592,13.628784252426883 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark44(49.47300667307462,67.87581524885854 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark44(72.2702820823014,0.9254950477570105 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark44(8.995080654476068,8.995080654476068 ) ;
  }
}
