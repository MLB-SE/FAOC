import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(-0.3829903152199279,48.56017669245409,20.442795590204653,-10.588601518470341 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(-0.525456122898403,59.83887232550552,88.42232079889492,-0.3469113476949559 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(-0.7107855459407801,91.62241508453448,13.980797976213566,18.17580732125205 ) ;
  }
}
