import org.junit.Test;

public class Sample02Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark02(11.466771824472161,73.80165821783544 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark02(-14.870332275327725,72.98979636658947 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark02(63.68554911308357,51.24225997365383 ) ;
  }
}
