import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark05(-26.216162298056716,-72.05956649928417,-31.246180683504193 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(-58.256846135824844,61.362081219805845,-63.006783352187036 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(80.80915271651786,47.60249208519906,-73.92897515744811 ) ;
  }
}
