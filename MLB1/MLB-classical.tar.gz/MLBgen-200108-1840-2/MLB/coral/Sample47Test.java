import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(38.096528539585705,-86.84093992656823,-39.48101591790299 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(-385.48124093978345,-215.2346868290157,-623.893994902048 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(84.35561413933465,27.654111633034887,-32.62213195452948 ) ;
  }
}
