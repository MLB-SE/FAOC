import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(-0.46806845083655446 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(0.4870307840260608 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark31(-45.16121898380392 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark31(5.09406685972196 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark31(69.8086022036099 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark31(88.78405167438822 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark31(8.881784197001252E-16 ) ;
  }
}
