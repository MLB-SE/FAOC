import org.junit.Test;

public class Sample63Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,-34.923297636616596,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,-7.23852672476211,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark63(10.235341122693924,0.0,-40.27201014571986,67.98629886102276,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark63(1.038441915441325,98.64533619862667,100.0,-6.938893903907228E-18,-100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark63(120.03516677412168,3.2197799443694763,-13.030791584842877,100.0,109.55034220925812 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark63(18.39194011942569,5.343431636110157,22.666972164603333,1.0947833030980536,73.74702053249273 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark63(20.16779162296973,16.76651826269746,-22.209635536750312,-30.530925173610086,75.38019835883173 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark63(20.191798060791342,40.80170374379469,76.80308211769392,61.694820531306874,-62.856490861904945 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark63(2.0391713731135326,38.840909301059014,55.464646759044186,88.81276927698262,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark63(2.0868645819666747,35.758822852430534,37.946335821793525,-1.3877787807814457E-17,33.483220200051726 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark63(2.16716517994188,35.66237138855108,33.4952062086092,-1.734723475976807E-18,37.86861948573278 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark63(25.074297606055268,41.12519908481187,83.94407315998345,-1.1768867042254385,-51.72396312858276 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark63(26.12795084410847,22.21346129191825,76.53278956336428,-28.19137742733755,27.775558558629957 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark63(2.853031100761555,45.92206768783623,88.49606663273715,14.889040841422641,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark63(28.65835319599865,13.126029872006644,54.10126257356339,1.8121449247499584,88.96338239766993 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark63(2.9134921058493006,96.35514245366596,95.83879615118401,90.00651632650872,94.88463441904774 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark63(41.1675628872498,51.722780042096986,151.0688111792713,-2.565899905164798,-1.7945674107748744 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark63(-45.71305852872403,33.97358266490426,-33.3316547418335,-94.74699872597154,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark63(49.82158169198032,20.06425148273141,61.94490524094964,7.940927933762095,-64.52272836528957 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark63(51.7693462681836,2.7947391566571707,-23.559883967447036,100.0,-36.26402723949147 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark63(61.83564768114322,3.301351687053552,50.04841787644727,15.088589898270682,135.6407033093208 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark63(63.95757099804294,68.70480770856253,-66.27977115781661,55.335326694958724,90.36647659423227 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark63(70.2820423721056,0.5982892744655288,-35.91402928270776,51.25966504522515,57.609112793478545 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark63(72.23818688543412,-36.67020220750692,35.834160642392646,97.92958954717898,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark63(75.31098756227553,26.073040975123803,81.7227850848229,84.29858167787688,-5.512007205208391 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark63(76.34385449318165,57.76734484375842,-80.38608897521479,68.22834218790817,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark63(78.3822427384606,3.1644269041744524,3.7094543739774144,100.0,100.0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark63(80.83241238621929,82.37649682187737,93.76275855992131,70.30773451267405,-18.00168550846162 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark63(90.75191945970741,85.11653571634287,-46.18019931289486,57.42521498577406,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark63(-96.39170505460413,95.65857882731109,37.52880573373897,-51.1901011539424,0 ) ;
  }
}
