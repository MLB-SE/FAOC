import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,25.24551237360791 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,2.564688572415676 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(0.8430724345171692,-1.8547138429312762,100.0,-99.37328550527715 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(1.0755551121772942,28.999263896326593,30.07482792437447,-1.3092981895103368E-17 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(14.949404308787573,-13.936255027032175,-78.2483676745214,-77.23281167307061 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(1.6422313604160212,2.866362203140704,2.9002612834590105,1.6909454753308464 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(20.354504979589123,56.798551927143166,-53.86614243401182,-52.989583342429604 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(24.123306523941594,95.23594337294597,78.35673897872142,41.00251091816614 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(26.772530241990538,-2.790627689641231,37.01052543559635,70.2880378459111 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(27.010674479549607,73.40848063246091,-81.66369231869885,68.05697869181469 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(28.14198968204812,-26.006133419320008,-17.33905460859934,88.36090120140071 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(37.876549224013786,20.708986734431534,43.304394416235766,96.05826690352006 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(37.97043620328472,47.86665547748453,167.70576492311199,-42.69026171063206 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(-38.09026162034981,97.13275974138128,33.07739169706315,9.987517139552637 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(39.865252424907,-15.555957059167014,-98.218657758138,-88.8120614797514 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(4.8996344191067465,31.49390603781464,-19.228396540894963,-57.3792987283231 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(52.13690388826697,35.80449330696368,88.65841255400414,68.33725838002931 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(8.090942742265554,0.0,17.380203877046043,-70.71016120076415 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(82.04800516037682,-49.97018492448297,65.94559736930125,-7.29332604309954 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(86.50316163075297,-82.41383722225862,68.75225968135221,-1.0496193909460376 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(89.61493432552149,-1.281427568828292,15.718296546702419,99.32647723812471 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(92.57749895502059,1.1265605679450204,64.05148333903588,78.34168912150034 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(-97.52518190763743,-62.67984334685064,7.68170365983319,-52.30380530223495 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(97.70432627549815,-84.57414345254497,77.55644562054238,-20.15901544255661 ) ;
  }
}
