import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0,1.2713876341254604,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(0,51.82273855037408,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(33.64104160248746,98.63770768936351,10.415947125288682,21.652881325600035,99.60186271507979 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(39.12140872490039,52.845986458821756,19.080055346908438,29.81986055221168,59.9346954844861 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(-48.167308471839235,-25.681341527224404,60.39062839066554,-23.56305369652256,-17.87839177253521 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(-5.199836863989732,-15.123760886483723,73.49876508166199,36.89234499960651,-60.700856657386026 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(76.84824071829412,35.01101988689306,28.713146152052758,7.824457574688594,4.5592670576808985 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(8.253328092367099,-39.04335380120085,96.33441894960359,70.14055653061752,73.89531172119365 ) ;
  }
}
