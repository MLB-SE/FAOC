import org.junit.Test;

public class Sample46Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark46(0.0,0,-17.25379968668011,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark46(2.1684043449710089E-19,74.97296451310761,1.0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark46(36.75532286584942,1.0000000000000002,12.282521362398668,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark46(38.33207117508442,0,54.07883634029932,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark46(-41.627677483661365,0,79.63802364442049,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark46(50.81787129062292,44.99371294309975,3.0809542139559767,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark46(56.80111400440239,-68.38429083999644,71.74704944896882,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark46(57.88337082626322,1.0,36.268998396036665,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark46(-60.95415350419098,0,1.434558801357369,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark46(6.162975822039155E-33,1.000000000000222,3.287364809070612E-16,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark46(62.014218940269956,47.690797895385515,72.20677201222256,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark46(-658.6258311868614,0,8.09426032397171,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark46(67.11277561046438,1.0000000000001859,32.95397995082034,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark46(70.61450682002021,27.929591943654614,52.72645244546638,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark46(97.1412861855508,0,73.18477315806439,0 ) ;
  }
}
