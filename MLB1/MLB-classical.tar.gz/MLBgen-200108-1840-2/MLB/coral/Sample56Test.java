import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,0.9751209097640583,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0,3.0353379567526986,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(10.939137544200776,-60.14935267976167,26.592284949193072,-25.692706015037814,52.82528608142238 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(-65.69394023310514,-96.28872560358785,33.84850074592501,-14.654298138779765,34.54396452252033 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(-6.789390059930325,-4.721657850987998,35.65699259301235,31.30441058567544,42.78289474636426 ) ;
  }
}
