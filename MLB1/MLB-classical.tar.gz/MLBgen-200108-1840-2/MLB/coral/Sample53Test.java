import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark53(10.525642314837881,-3.6977742649946492,12.846714079073607 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(11.969808727472,-57.355272440867665,-16.16918347112221 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(15.439393675683874,94.8539750631984,16.609150601796973 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark53(31.701200858303025,21.354413092000385,-98.76810060767565 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark53(52.88698083283845,63.40314652970608,-62.22971978265364 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark53(54.5080181654493,-59.49287699990735,55.484718078757865 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark53(59.036409547162236,-72.9658523462742,67.68795736819811 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark53(67.8202972327228,-57.13717017379511,75.00403171140127 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark53(91.5378659411583,2.7860608935178277,100.0 ) ;
  }
}
