import org.junit.Test;

public class Sample30Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark30(100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark30(178.5871408465804 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark30(72.64796872351272 ) ;
  }
}
