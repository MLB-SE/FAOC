import org.junit.Test;

public class Sample39Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark39(1.1443232631963838,5.501389437707663E-16 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark39(54.553522431101925,42.36401255092764 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark39(5.831962239225575,-98.36170205657169 ) ;
  }
}
