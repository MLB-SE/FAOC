import org.junit.Test;

public class Sample16Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,29.312151489800357 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,7.799708947670396 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark16(49.4983694150244,15.102226112532492,65.27975808432382,60.466554291631866,-64.54019017919259 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark16(-52.284078242883815,14.122482588749932,-67.6038403103407,56.36246347148506,9.692815870752597 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark16(5.827091538145629,15.037064666554896,80.139850209147,11.30934146752846,85.57871405289234 ) ;
  }
}
