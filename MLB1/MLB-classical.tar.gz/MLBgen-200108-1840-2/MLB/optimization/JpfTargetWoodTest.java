import org.junit.Test;

public class JpfTargetWoodTest {

  @Test
  public void test0() {
    Optimization.wood(1.0,0.9999999999997733,1.0,1.000000000000227 ) ;
  }

  @Test
  public void test1() {
    Optimization.wood(1.0,0.9999999999999998,1.0,1.0 ) ;
  }

  @Test
  public void test2() {
    Optimization.wood(1.0,1.0,0,0 ) ;
  }

  @Test
  public void test3() {
    Optimization.wood(1.0,1.0000000000000004,1.0,1.0 ) ;
  }

  @Test
  public void test4() {
    Optimization.wood(1.0,1.0000752695873094,11.19401166204238,125.30589691959305 ) ;
  }

  @Test
  public void test5() {
    Optimization.wood(1.0,1.0,1.0,1.0 ) ;
  }

  @Test
  public void test6() {
    Optimization.wood(1.0,1.0,-13.649554296220188,21.31971517955727 ) ;
  }

  @Test
  public void test7() {
    Optimization.wood(1.0,1.0,-2.6574776400442373,7.062187407335089 ) ;
  }

  @Test
  public void test8() {
    Optimization.wood(1.0,1.0,5.03566207314141,37.421779837662044 ) ;
  }

  @Test
  public void test9() {
    Optimization.wood(1.0,1.0,-5.175841610552307,26.789336377524695 ) ;
  }

  @Test
  public void test10() {
    Optimization.wood(-1.3742373517489814,1.8885282989420538,0,0 ) ;
  }

  @Test
  public void test11() {
    Optimization.wood(3.188426418279917,10.166063024785487,0,0 ) ;
  }

  @Test
  public void test12() {
    Optimization.wood(3.8343015112296115,14.701868079017682,0,0 ) ;
  }

  @Test
  public void test13() {
    Optimization.wood(-7.251274792590815,52.58098611766297,0,0 ) ;
  }

  @Test
  public void test14() {
    Optimization.wood(-78.79718691719972,72.73669665346696,0,0 ) ;
  }
}
