import org.junit.Test;

public class JpfTargetRosenbrockTest {

  @Test
  public void test0() {
    Optimization.rosenbrock(35.47168447197109,-51.63805670254889 ) ;
  }

  @Test
  public void test1() {
    Optimization.rosenbrock(6.154355014203988,37.87569552957626 ) ;
  }

  @Test
  public void test2() {
    Optimization.rosenbrock(6.414931078121687,41.15172374170926 ) ;
  }
}
