import org.junit.Test;

public class JpfTargetBealeTest {

  @Test
  public void test0() {
    Optimization.beale(-28.829595019802028,-66.82591377823502 ) ;
  }

  @Test
  public void test1() {
    Optimization.beale(-46.47646063821584,25.310854288952612 ) ;
  }

  @Test
  public void test2() {
    Optimization.beale(-4.991727832785784,1.300497152538639 ) ;
  }
}
