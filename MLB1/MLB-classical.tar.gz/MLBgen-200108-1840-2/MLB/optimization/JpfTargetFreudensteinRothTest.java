import org.junit.Test;

public class JpfTargetFreudensteinRothTest {

  @Test
  public void test0() {
    Optimization.freudensteinRoth(26.030023760921626,1.0153660538785088 ) ;
  }

  @Test
  public void test1() {
    Optimization.freudensteinRoth(75.7831925660669,-71.78362919276229 ) ;
  }

  @Test
  public void test2() {
    Optimization.freudensteinRoth(-96.76442946463715,-5.072335062651831 ) ;
  }
}
