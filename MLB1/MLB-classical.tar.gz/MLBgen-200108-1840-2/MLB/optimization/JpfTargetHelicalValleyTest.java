import org.junit.Test;

public class JpfTargetHelicalValleyTest {

  @Test
  public void test0() {
    Optimization.theta(-0.0036723256369622717,0 ) ;
  }

  @Test
  public void test1() {
    Optimization.theta(-0.0044202467564410175,1046.9133932787427 ) ;
  }

  @Test
  public void test2() {
    Optimization.theta(0.6439068165222608,1.7249333192572465 ) ;
  }

  @Test
  public void test3() {
    Optimization.theta(100.0,-100.0 ) ;
  }

  @Test
  public void test4() {
    Optimization.theta(-100.0,5.142501839091153 ) ;
  }

  @Test
  public void test5() {
    Optimization.theta(-100.0,81.6322515438228 ) ;
  }

  @Test
  public void test6() {
    Optimization.theta(-11.075697388088074,-84.29260713140106 ) ;
  }

  @Test
  public void test7() {
    Optimization.theta(1.232595164407831E-32,0 ) ;
  }

  @Test
  public void test8() {
    Optimization.theta(20.274541773785998,5.280846552886992 ) ;
  }

  @Test
  public void test9() {
    Optimization.theta(-2.049680645633174,-92.67847188221855 ) ;
  }

  @Test
  public void test10() {
    Optimization.theta(2.1165967749658563,-42.11352373060529 ) ;
  }

  @Test
  public void test11() {
    Optimization.theta(30.823952534195882,34.52468067423801 ) ;
  }

  @Test
  public void test12() {
    Optimization.theta(-32.76765758638793,0 ) ;
  }

  @Test
  public void test13() {
    Optimization.theta(-3.6987689193162225,0 ) ;
  }

  @Test
  public void test14() {
    Optimization.theta(-40.16012992158395,-39.156637137352405 ) ;
  }

  @Test
  public void test15() {
    Optimization.theta(-4.23773862190761,0 ) ;
  }

  @Test
  public void test16() {
    Optimization.theta(-43.72420865575768,-36.48327472134804 ) ;
  }

  @Test
  public void test17() {
    Optimization.theta(51.48890106474079,69.26758057595234 ) ;
  }

  @Test
  public void test18() {
    Optimization.theta(-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test19() {
    Optimization.theta(-6.162975822039155E-33,0 ) ;
  }

  @Test
  public void test20() {
    Optimization.theta(64.35315164958794,-94.0545469037421 ) ;
  }

  @Test
  public void test21() {
    Optimization.theta(-7.105427357601002E-15,100.0 ) ;
  }

  @Test
  public void test22() {
    Optimization.theta(-72.82800739705755,0 ) ;
  }

  @Test
  public void test23() {
    Optimization.theta(73.1771914059141,0 ) ;
  }

  @Test
  public void test24() {
    Optimization.theta(84.27175320288585,-8.470811032981885 ) ;
  }

  @Test
  public void test25() {
    Optimization.theta(-88.501713602319,26.802015646191734 ) ;
  }

  @Test
  public void test26() {
    Optimization.theta(89.5876163245407,0 ) ;
  }

  @Test
  public void test27() {
    Optimization.theta(99.99999987380501,-2.77633646141244E-15 ) ;
  }
}
