import org.junit.Test;

public class JpfTargetPowellTest {

  @Test
  public void test0() {
    Optimization.powell(-0.22249898623691422,-4.4944025000420094E-4 ) ;
  }

  @Test
  public void test1() {
    Optimization.powell(1.0144558335589693E-6,98.57501597597852 ) ;
  }

  @Test
  public void test2() {
    Optimization.powell(-1.1755466540031012E-5,-8.506680671453486 ) ;
  }

  @Test
  public void test3() {
    Optimization.powell(-2.408725031544101E-6,-41.51573911111618 ) ;
  }

  @Test
  public void test4() {
    Optimization.powell(-36.3010996661105,9.457704581595934 ) ;
  }

  @Test
  public void test5() {
    Optimization.powell(-67.95664457707423,-67.20346413168983 ) ;
  }
}
