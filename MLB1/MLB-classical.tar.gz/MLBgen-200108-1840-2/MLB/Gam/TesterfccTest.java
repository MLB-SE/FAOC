import org.junit.Test;

public class TesterfccTest {

  @Test
  public void test0() {
    erf.erfcc(1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1() {
    erf.erfcc(16.624984717499828 ) ;
  }

  @Test
  public void test2() {
    erf.erfcc(1.734723475976807E-18 ) ;
  }

  @Test
  public void test3() {
    erf.erfcc(26.522920971209658 ) ;
  }

  @Test
  public void test4() {
    erf.erfcc(-28.16332258406358 ) ;
  }

  @Test
  public void test5() {
    erf.erfcc(2.885598987405899 ) ;
  }

  @Test
  public void test6() {
    erf.erfcc(4.2351647362715017E-22 ) ;
  }

  @Test
  public void test7() {
    erf.erfcc(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test8() {
    erf.erfcc(4.9E-324 ) ;
  }

  @Test
  public void test9() {
    erf.erfcc(-5.9E-323 ) ;
  }

  @Test
  public void test10() {
    erf.erfcc(-61.24450043882994 ) ;
  }

  @Test
  public void test11() {
    erf.erfcc(-71.43155144847535 ) ;
  }

  @Test
  public void test12() {
    erf.erfcc(8.153078739505787 ) ;
  }
}
