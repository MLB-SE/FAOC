import org.junit.Test;

public class TestexpintTest {

  @Test
  public void test0() {
    expint.expint(0,0.0 ) ;
  }

  @Test
  public void test1() {
    expint.expint(0,19.709965369786644 ) ;
  }

  @Test
  public void test2() {
    expint.expint(13,-60.83808365979628 ) ;
  }

  @Test
  public void test3() {
    expint.expint(171,0.0 ) ;
  }

  @Test
  public void test4() {
    expint.expint(20,0.0 ) ;
  }

  @Test
  public void test5() {
    expint.expint(211,4.9E-323 ) ;
  }

  @Test
  public void test6() {
    expint.expint(329,2.03E-322 ) ;
  }

  @Test
  public void test7() {
    expint.expint(370,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test8() {
    expint.expint(473,0 ) ;
  }

  @Test
  public void test9() {
    expint.expint(-536,0 ) ;
  }

  @Test
  public void test10() {
    expint.expint(652,92.6685278745741 ) ;
  }

  @Test
  public void test11() {
    expint.expint(795,0.0 ) ;
  }

  @Test
  public void test12() {
    expint.expint(851,-1.3E-322 ) ;
  }

  @Test
  public void test13() {
    expint.expint(935,10.883321658888391 ) ;
  }

  @Test
  public void test14() {
    expint.expint(99,14.753103988958813 ) ;
  }
}
