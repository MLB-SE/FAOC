import org.junit.Test;

public class TestbetacfTest {

  @Test
  public void test0() {
    beta.betacf(-18.5108473341656,16.94008578520696,11.147998463404383 ) ;
  }

  @Test
  public void test1() {
    beta.betacf(2.208688569722142,59.14787143921714,-67.03074278648978 ) ;
  }

  @Test
  public void test2() {
    beta.betacf(2.633909736772864,0,0 ) ;
  }

  @Test
  public void test3() {
    beta.betacf(28.05078094191674,-46.961149221992905,-1.5362355989927732 ) ;
  }

  @Test
  public void test4() {
    beta.betacf(-31.227340126264224,90.13521956555394,40.072773062856555 ) ;
  }

  @Test
  public void test5() {
    beta.betacf(39.77073986994836,20.336571864756706,65.15145380906137 ) ;
  }

  @Test
  public void test6() {
    beta.betacf(-41.366157387112956,42.580067973833486,-33.25299064749499 ) ;
  }

  @Test
  public void test7() {
    beta.betacf(47.60331060460251,-65.96585000080859,-2.646873047125745 ) ;
  }

  @Test
  public void test8() {
    beta.betacf(48.09814653003941,-47.033685775272836,46.12490062238724 ) ;
  }

  @Test
  public void test9() {
    beta.betacf(58.866024353049056,0,0 ) ;
  }

  @Test
  public void test10() {
    beta.betacf(-74.13322872536925,-43.11704566133703,46.99986008697431 ) ;
  }

  @Test
  public void test11() {
    beta.betacf(82.70800906114019,-76.02110577812506,12.51820245011772 ) ;
  }

  @Test
  public void test12() {
    beta.betacf(-86.22789616591058,91.73736317054022,-15.46935413067961 ) ;
  }

  @Test
  public void test13() {
    beta.betacf(87.60400458457207,-91.72540114524585,-21.498538973421823 ) ;
  }
}
