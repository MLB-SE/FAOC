import org.junit.Test;

public class TesterffcTest {

  @Test
  public void test0() {
    gam.erffc(-1.0947644252537633E-47 ) ;
  }

  @Test
  public void test1() {
    gam.erffc(-1.2247448713915892 ) ;
  }

  @Test
  public void test2() {
    gam.erffc(1.2247448713915892 ) ;
  }

  @Test
  public void test3() {
    gam.erffc(12.761339636374245 ) ;
  }

  @Test
  public void test4() {
    gam.erffc(13.91768229090475 ) ;
  }

  @Test
  public void test5() {
    gam.erffc(1.7763568394002505E-15 ) ;
  }

  @Test
  public void test6() {
    gam.erffc(1.778206999588062E-161 ) ;
  }

  @Test
  public void test7() {
    gam.erffc(23.456948378772722 ) ;
  }

  @Test
  public void test8() {
    gam.erffc(-2.836728143543297 ) ;
  }

  @Test
  public void test9() {
    gam.erffc(-3.552713678800501E-15 ) ;
  }

  @Test
  public void test10() {
    gam.erffc(4.440892098500626E-16 ) ;
  }

  @Test
  public void test11() {
    gam.erffc(-56.74609405909459 ) ;
  }

  @Test
  public void test12() {
    gam.erffc(-6.3174603311753045E-176 ) ;
  }

  @Test
  public void test13() {
    gam.erffc(-66.90259766495697 ) ;
  }

  @Test
  public void test14() {
    gam.erffc(-8.245842122745557 ) ;
  }

  @Test
  public void test15() {
    gam.erffc(-8.881784197001252E-16 ) ;
  }

  @Test
  public void test16() {
    gam.erffc(9.860761315262648E-32 ) ;
  }
}
