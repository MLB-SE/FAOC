import org.junit.Test;

public class TestbetaTest {

  @Test
  public void test0() {
    beta.beta(15.802529564978258,0 ) ;
  }

  @Test
  public void test1() {
    beta.beta(-2.0,0 ) ;
  }

  @Test
  public void test2() {
    beta.beta(-3.0,0 ) ;
  }

  @Test
  public void test3() {
    beta.beta(-35.47173248328397,0 ) ;
  }

  @Test
  public void test4() {
    beta.beta(8.699497639641535,0 ) ;
  }

  @Test
  public void test5() {
    beta.beta(-93.0372697715078,0 ) ;
  }
}
