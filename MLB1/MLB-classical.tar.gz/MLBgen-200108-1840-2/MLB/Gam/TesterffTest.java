import org.junit.Test;

public class TesterffTest {

  @Test
  public void test0() {
    gam.erff(-0.3121822177080946 ) ;
  }

  @Test
  public void test1() {
    gam.erff(-1.224744871391589 ) ;
  }

  @Test
  public void test2() {
    gam.erff(1.2247448713915892 ) ;
  }

  @Test
  public void test3() {
    gam.erff(13.179506180413526 ) ;
  }

  @Test
  public void test4() {
    gam.erff(1.4225655996704496E-160 ) ;
  }

  @Test
  public void test5() {
    gam.erff(-1.659158428084723 ) ;
  }

  @Test
  public void test6() {
    gam.erff(-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test7() {
    gam.erff(1.7763568394002505E-15 ) ;
  }

  @Test
  public void test8() {
    gam.erff(-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test9() {
    gam.erff(-2.465190328815662E-32 ) ;
  }

  @Test
  public void test10() {
    gam.erff(-2.5269841324701218E-175 ) ;
  }

  @Test
  public void test11() {
    gam.erff(3.8518598887744717E-34 ) ;
  }

  @Test
  public void test12() {
    gam.erff(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test13() {
    gam.erff(4.440892098500626E-16 ) ;
  }

  @Test
  public void test14() {
    gam.erff(50.55543030843711 ) ;
  }

  @Test
  public void test15() {
    gam.erff(51.419450647501264 ) ;
  }

  @Test
  public void test16() {
    gam.erff(5.551115123125783E-17 ) ;
  }

  @Test
  public void test17() {
    gam.erff(-66.26010888535536 ) ;
  }

  @Test
  public void test18() {
    gam.erff(-72.31746134725539 ) ;
  }

  @Test
  public void test19() {
    gam.erff(8.881784197001252E-16 ) ;
  }

  @Test
  public void test20() {
    gam.erff(-92.93345613535355 ) ;
  }
}
