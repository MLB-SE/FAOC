import org.junit.Test;

public class TestbetaiTest {

  @Test
  public void test0() {
    beta.betai(0,0,0.9715925456344987 ) ;
  }

  @Test
  public void test1() {
    beta.betai(0,0,0.9999739515824952 ) ;
  }

  @Test
  public void test2() {
    beta.betai(0,0,0.9999999999999991 ) ;
  }

  @Test
  public void test3() {
    beta.betai(0,0,0.9999999999999996 ) ;
  }

  @Test
  public void test4() {
    beta.betai(0,0,0.9999999999999998 ) ;
  }

  @Test
  public void test5() {
    beta.betai(0,0,1.0000000000000009 ) ;
  }

  @Test
  public void test6() {
    beta.betai(0,0,1.0003410734048461 ) ;
  }

  @Test
  public void test7() {
    beta.betai(0,0,1.000484284642723 ) ;
  }

  @Test
  public void test8() {
    beta.betai(0,0,-10.117605263216205 ) ;
  }

  @Test
  public void test9() {
    beta.betai(0,0,11.228521888413482 ) ;
  }

  @Test
  public void test10() {
    beta.betai(0,0,-14.056995483280986 ) ;
  }

  @Test
  public void test11() {
    beta.betai(0,0,16.538806367277118 ) ;
  }

  @Test
  public void test12() {
    beta.betai(0,0,-27.43605885732056 ) ;
  }

  @Test
  public void test13() {
    beta.betai(0,0,3.0385816786431356E-64 ) ;
  }

  @Test
  public void test14() {
    beta.betai(0,0,-3.360962459801172 ) ;
  }

  @Test
  public void test15() {
    beta.betai(0,0,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test16() {
    beta.betai(0,0,52.95081442822317 ) ;
  }

  @Test
  public void test17() {
    beta.betai(0,0,5.551115123125783E-17 ) ;
  }

  @Test
  public void test18() {
    beta.betai(0,0,-68.0446695709892 ) ;
  }

  @Test
  public void test19() {
    beta.betai(0,0,69.57278796887127 ) ;
  }

  @Test
  public void test20() {
    beta.betai(0,0,7.914173442360848 ) ;
  }

  @Test
  public void test21() {
    beta.betai(0,0,9.860761315262648E-32 ) ;
  }
}
