import org.junit.Test;

public class TesteiTest {

  @Test
  public void test0() {
    expint.ei(1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1() {
    expint.ei(1.2753067497093014 ) ;
  }

  @Test
  public void test2() {
    expint.ei(12.814881207126817 ) ;
  }

  @Test
  public void test3() {
    expint.ei(14.010310458956354 ) ;
  }

  @Test
  public void test4() {
    expint.ei(17.203189345431767 ) ;
  }

  @Test
  public void test5() {
    expint.ei(19.289279890731947 ) ;
  }

  @Test
  public void test6() {
    expint.ei(-21.977491966291154 ) ;
  }

  @Test
  public void test7() {
    expint.ei(32.23619130191664 ) ;
  }

  @Test
  public void test8() {
    expint.ei(-33.244649795251206 ) ;
  }

  @Test
  public void test9() {
    expint.ei(4.207026452721905 ) ;
  }

  @Test
  public void test10() {
    expint.ei(4.440892098500626E-16 ) ;
  }

  @Test
  public void test11() {
    expint.ei(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test12() {
    expint.ei(4.930380657631324E-32 ) ;
  }

  @Test
  public void test13() {
    expint.ei(5.551115123125783E-17 ) ;
  }

  @Test
  public void test14() {
    expint.ei(7.9E-323 ) ;
  }

  @Test
  public void test15() {
    expint.ei(80.30213229570288 ) ;
  }

  @Test
  public void test16() {
    expint.ei(83.2128301958189 ) ;
  }
}
