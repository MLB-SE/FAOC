import org.junit.Test;

public class TestfactrlTest {

  @Test
  public void test0() {
    gam.factrl(0 ) ;
  }

  @Test
  public void test1() {
    gam.factrl(-1 ) ;
  }

  @Test
  public void test2() {
    gam.factrl(1 ) ;
  }

  @Test
  public void test3() {
    gam.factrl(20 ) ;
  }

  @Test
  public void test4() {
    gam.factrl(3 ) ;
  }

  @Test
  public void test5() {
    gam.factrl(304 ) ;
  }

  @Test
  public void test6() {
    gam.factrl(34 ) ;
  }

  @Test
  public void test7() {
    gam.factrl(-438 ) ;
  }

  @Test
  public void test8() {
    gam.factrl(456 ) ;
  }

  @Test
  public void test9() {
    gam.factrl(-56 ) ;
  }

  @Test
  public void test10() {
    gam.factrl(-651 ) ;
  }
}
