import org.junit.Test;

public class JpfTargetunboundedTest {

  @Test
  public void test0() {
    bound.unbounded.solve(188,-539 ) ;
  }

  @Test
  public void test1() {
    bound.unbounded.solve(215,-757 ) ;
  }

  @Test
  public void test2() {
    bound.unbounded.solve(823,-232 ) ;
  }

  @Test
  public void test3() {
    bound.unbounded.solve(-914,681 ) ;
  }
}
