import org.junit.Test;

public class JpfTargetgroceryTest {

  @Test
  public void test0() {
    bound.grocery.solve(100,90,104,417 ) ;
  }

  @Test
  public void test1() {
    bound.grocery.solve(132,171,32,376 ) ;
  }

  @Test
  public void test2() {
    bound.grocery.solve(239,398,549,0 ) ;
  }

  @Test
  public void test3() {
    bound.grocery.solve(240,590,641,876 ) ;
  }

  @Test
  public void test4() {
    bound.grocery.solve(247,612,99,669 ) ;
  }

  @Test
  public void test5() {
    bound.grocery.solve(279,890,0,0 ) ;
  }

  @Test
  public void test6() {
    bound.grocery.solve(293,98,-877,0 ) ;
  }

  @Test
  public void test7() {
    bound.grocery.solve(308,457,0,0 ) ;
  }

  @Test
  public void test8() {
    bound.grocery.solve(313,499,975,0 ) ;
  }

  @Test
  public void test9() {
    bound.grocery.solve(335,395,167,0 ) ;
  }

  @Test
  public void test10() {
    bound.grocery.solve(355,-174,0,0 ) ;
  }

  @Test
  public void test11() {
    bound.grocery.solve(420,0,0,0 ) ;
  }

  @Test
  public void test12() {
    bound.grocery.solve(6,20,295,390 ) ;
  }

  @Test
  public void test13() {
    bound.grocery.solve(6,526,0,0 ) ;
  }

  @Test
  public void test14() {
    bound.grocery.solve(66,0,0,0 ) ;
  }

  @Test
  public void test15() {
    bound.grocery.solve(707,115,330,356 ) ;
  }

  @Test
  public void test16() {
    bound.grocery.solve(73,512,96,30 ) ;
  }

  @Test
  public void test17() {
    bound.grocery.solve(77,242,658,44 ) ;
  }

  @Test
  public void test18() {
    bound.grocery.solve(875,0,0,0 ) ;
  }

  @Test
  public void test19() {
    bound.grocery.solve(94,11,472,-216 ) ;
  }

  @Test
  public void test20() {
    bound.grocery.solve(-98,0,0,0 ) ;
  }
}
