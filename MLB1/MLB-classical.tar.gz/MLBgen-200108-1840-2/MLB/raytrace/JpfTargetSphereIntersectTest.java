import org.junit.Test;

public class JpfTargetSphereIntersectTest {

  @Test
  public void test0() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.101944864f,0.061540075f,0.9928847f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.16790405f,-0.3826606f,-0.42298386f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.47655994f,0.16838117f,-0.8523032f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.9759135f,-0.04654525f,0.21313444f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1.0923322E-4f,-3.1236905E-4f,-1.5745227E-5f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1.6654683E-9f,-1.462853E-9f,5.12405E-10f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,3.2694914E-4f,-7.6854124E-4f,4.8416787E-5f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-35.43278f,32.193645f,49.170506f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-4.173331f,-57.854317f,-92.878204f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,45.442764f,82.134895f,63.835316f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-100.0f,100.0f,-100.0f,100.0f,-100.0f,-99.99999f,-0.29362714f,-0.088210516f,-0.95184135f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,-4.066203f,100.0f,-57.693764f,-100.0f,-15.314127f,-0.5764091f,0.5271511f,0.62439114f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-7.6580877f,100.0f,95.07387f,-100.0f,-100.0f,100.0f,-0.092138365f,0.48976496f,-0.86698246f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-90.33041f,2.3981357f,-100.0f,-100.0f,-2.9203813f,-100.0f,-0.26807013f,0.6422958f,-0.27460507f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,90.403305f,-62.305042f,61.612072f,96.335915f,81.25019f,-1.4869338f,0.21725541f,0.54186493f,-0.55820704f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-94.33627f,-100.0f,100.0f,-99.997795f,-100.0f,-100.0f,-0.59051144f,-0.80316836f,-0.07884702f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,11.370991f,-99.98165f,-100.0f,100.0f,-100.0f,-13.434541f,83.75359f,-0.100799866f,-0.9847979f,-0.14146535f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-16.32571f,-44.23374f,16.065924f,41.82834f,-24.3012f,-65.966736f,50.903812f,0.045961376f,1.2221946f,0.16472957f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,16.605873f,-19.026186f,-16.093023f,76.05184f,40.00121f,-75.40734f,-61.454983f,-0.41813695f,1.4516886f,-0.5218959f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-16.857119f,45.458633f,-56.05282f,92.68388f,-73.18733f,80.35142f,8.752296f,99.756836f,-68.90803f,-84.360214f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1.7831997f,38.473927f,-42.066124f,33.854984f,-36.701603f,36.73164f,-37.85879f,-43.05471f,-66.36752f,78.61886f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2.3672745f,-58.532394f,-99.99988f,36.188194f,21.3233f,-27.819565f,-97.365845f,-0.08744075f,-0.88119835f,-0.46458972f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,25.196812f,28.267878f,-4.05237f,50.878536f,44.472473f,-18.098646f,-12.164341f,-59.015347f,138.22508f,24.83982f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,29.00904f,-54.93044f,-62.69103f,66.29067f,14.784944f,-2.6334324f,-24.518377f,0.8711021f,-0.36640698f,0.1201049f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-31.54055f,-4.345388f,80.30285f,87.574844f,-7.1683636f,53.850975f,19.569557f,-136.92508f,63.43099f,100.0f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,33.179237f,-0.22971028f,-3.0389502f,93.226234f,-26.08607f,-23.475006f,95.42998f,-3.129351f,65.90594f,-98.826256f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,35.655468f,-5.620113f,7.564751f,69.18449f,-25.789232f,-35.05352f,-4.465078f,64.50363f,32.460682f,59.516937f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-35.904392f,-3.0243073f,68.42727f,47.173393f,-62.40252f,41.292618f,98.57356f,-20.876245f,-46.046745f,-70.597855f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-38.035446f,-4.875476f,31.025335f,14.847179f,-44.797142f,-10.7671f,12.8407755f,95.01348f,-21.635187f,69.31805f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,40.108154f,100.0f,-19.801794f,99.99937f,100.0f,-60.799614f,-61.202217f,-0.8714513f,0.17981504f,0.45633233f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,41.61408f,30.07135f,71.13197f,29.285622f,-0.039821636f,57.3284f,-59.053646f,87.54558f,91.03467f,-74.71968f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-42.146927f,78.79502f,30.857306f,7.0393534f,-14.059415f,72.975365f,51.588284f,-70.03736f,-85.6107f,31.780037f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-44.26222f,99.97608f,100.0f,36.637733f,-20.004404f,88.56053f,75.02867f,-0.601981f,-0.5673825f,0.5618683f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,46.562527f,0.8889648f,-49.2437f,58.180164f,99.99988f,-29.269577f,-28.132767f,-0.6449056f,-0.28923476f,-0.39640903f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,5.201534f,58.939995f,28.31798f,54.34925f,-30.066067f,17.802376f,32.529125f,28.421164f,73.11378f,-59.80684f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-56.42974f,-100.0f,-22.78196f,100.0f,-100.0f,47.960224f,-100.0f,0.16261941f,-0.15576628f,-0.97431606f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,56.81031f,87.96269f,-83.10465f,72.38406f,32.913403f,60.416386f,-20.577925f,-27.01096f,38.48621f,-94.73312f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-57.349915f,1.2181312f,97.261795f,93.483055f,-82.39475f,69.03452f,37.99304f,36.19086f,-100.0f,88.6824f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-57.984455f,99.82337f,16.82689f,83.8434f,33.546837f,92.63097f,5.3488765f,84.20247f,32.959877f,-26.96345f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-58.927456f,35.92192f,81.722466f,10.801821f,91.72866f,95.68991f,21.998495f,-0.043852977f,0.16957885f,0.59658605f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-59.059074f,61.7493f,12.388366f,-87.05225f,-92.514366f,-33.180397f,-8.337236f,-45.450733f,-82.74889f,32.71199f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,59.83224f,100.0f,80.76298f,28.354605f,-6.7631536f,2.8175354f,20.910395f,0.18165006f,-0.7616176f,0.16926388f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,60.322643f,66.236885f,100.0f,100.0f,-29.553587f,51.711487f,79.81475f,0.009356543f,-0.3067532f,-0.22545059f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-60.352024f,-69.48114f,-73.06915f,46.54419f,-81.700676f,-94.117744f,-87.345726f,0.7873463f,-91.2662f,18.357637f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,61.37579f,-99.966034f,-44.966858f,23.302622f,87.814926f,-100.0f,-45.201015f,1.0853124f,0.94404894f,1.745209f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,63.887848f,-86.03996f,-26.886705f,97.705605f,93.47169f,-91.77931f,66.055435f,-0.21069221f,-0.34184396f,-0.73684245f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-65.37474f,74.28277f,6.904074f,100.0f,-86.10362f,47.313442f,-100.0f,0.65717566f,-0.117057495f,0.7445923f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-66.447914f,-39.431458f,84.986465f,81.83161f,-90.94254f,13.110798f,51.846928f,0.64865625f,0.701117f,-0.2052023f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,68.36467f,71.61359f,89.42336f,100.0f,41.473835f,97.304016f,27.188662f,-0.54064375f,-0.04556697f,-0.84001666f ) ;
  }

  @Test
  public void test49() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-69.55828f,30.578772f,-46.803047f,-81.074005f,-13.300872f,100.0f,44.083023f,3.2567585f,4.4445915f,-0.47719356f ) ;
  }

  @Test
  public void test50() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-71.75193f,72.40604f,56.102707f,37.829678f,-68.44929f,-100.0f,34.497402f,-0.94717836f,0.22936746f,-0.2241511f ) ;
  }

  @Test
  public void test51() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-7.265958f,-83.218765f,-18.010715f,-3.6467712f,44.138523f,60.07706f,87.03067f,-91.61992f,80.48007f,-60.23132f ) ;
  }

  @Test
  public void test52() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-7.662632f,16.675123f,85.83549f,88.81416f,-29.180141f,78.01363f,25.316565f,35.880825f,-102.4572f,99.931435f ) ;
  }

  @Test
  public void test53() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-76.7986f,-11.837284f,16.6603f,31.340597f,-49.371452f,-0.5413359f,6.5416965f,59.49187f,-96.62012f,100.0f ) ;
  }

  @Test
  public void test54() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,82.60126f,-71.77999f,-82.76659f,-73.49168f,-39.264618f,-65.268295f,88.24663f,22.710398f,79.2862f,-8.016945f ) ;
  }

  @Test
  public void test55() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-82.81793f,82.774284f,10.806548f,69.65895f,-89.55603f,64.94018f,97.08365f,-20.789446f,2.9452288f,93.332214f ) ;
  }

  @Test
  public void test56() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,83.96121f,63.84999f,30.349768f,48.730965f,86.1195f,-68.073715f,-85.6221f,16.551155f,-61.788025f,56.409294f ) ;
  }

  @Test
  public void test57() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-90.37313f,71.23303f,-100.0f,10.041701f,-4.818625f,-85.97056f,28.327606f,-0.17651394f,-0.35773274f,-0.9169897f ) ;
  }

  @Test
  public void test58() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-90.574135f,-20.526272f,-65.495605f,-96.46882f,-61.27083f,78.32799f,-5.105193f,-25.556744f,96.59455f,15.9039755f ) ;
  }

  @Test
  public void test59() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-9.38954f,91.27983f,-50.351875f,-11.861719f,-10.064875f,93.02628f,-67.15463f,-84.24537f,36.99909f,-77.85611f ) ;
  }

  @Test
  public void test60() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-96.88544f,-111.53338f,-100.0f,87.358574f,-60.61216f,100.0f,-97.88738f,0.5306827f,0.834156f,0.15019898f ) ;
  }

  @Test
  public void test61() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,97.872345f,-52.596794f,-92.300354f,100.0f,100.0f,4.9518204f,100.0f,0.1136354f,0.32795233f,0.068844326f ) ;
  }

  @Test
  public void test62() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.452034f,-51.775352f,-4.3837013f,88.3745f,-76.317665f,-19.682426f,74.64095f,0.07689208f,0.028139738f,-6.5555f ) ;
  }

  @Test
  public void test63() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.99976f,-100.0f,100.0f,-99.99986f,-72.994606f,14.575132f,100.0f,0.13910697f,0.8400012f,0.5244494f ) ;
  }
}
