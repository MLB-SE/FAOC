import org.junit.Test;

public class JpfTargetSurfaceShadeTest {

  @Test
  public void test0() {
    TestDrivers.surfaceShade(0.0f,0f,0f,0f,1083.0f,619.0f,0f,-1.0f,0f,0f,0f,0f,0f,1100.0f,-991.0f,1265.0f,-1201.0f,2019.0f,-205.0f,-752,0.14111882f,0.2802053f,-0.5903946f,0.810481f,0f,0f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.surfaceShade(0.0f,0f,0f,0f,7.3697867f,-100.0f,0f,0.0f,0f,0f,0f,0f,0f,-25.56276f,-44.98402f,100.0f,0f,0f,0f,1,0.007636425f,0.015670873f,0.2670423f,6.4594626f,0f,0f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.surfaceShade(0.0f,389.0f,-604.0f,0f,1095.0f,1138.0f,0f,-465.0f,0f,0f,0f,0f,0f,-141.0f,-190.0f,-173.0f,-1256.0f,-874.0f,-1359.0f,880,69.407524f,11.829902f,-69.561516f,-72.77968f,70.90684f,-48.402378f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.4008686f,0.30598888f,-0.24447238f,0f,0f,0f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-0.0f,0f,0.0f,0f,0f,0f,0f,0f,-2.0248578f,35.512386f,30.18329f,0f,0f,0f,-857,-0.20137857f,-0.75416195f,-0.39060286f,0f,0f,0f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,28.657997f,100.0f,21.500341f,0f,0f,0f,895,-100.0f,-100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.0039445274f,3.926686f,0.8287108f,0f,0f,0f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.025372274f,0.19494484f,-0.24851425f,0f,0f,0f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.050095618f,-0.34308827f,0.22396773f,0f,0f,0f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,13.266108f,63.532795f,0f,0f,0f,-2645,0.39701357f,-0.19047177f,-0.8151182f,0f,0f,0f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-2.8117638f,57.333794f,11.884347f,0f,0f,0f,-852,-47.50371f,-66.65183f,56.763798f,0f,0f,0f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,10.192225f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.19828199f,0.32765305f,2.4204834f,0f,0f,0f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,-26.416126f,0f,0f,0f,0f,0f,0.6457608f,-31.785364f,21.570116f,0f,0f,0f,-839,-86.3014f,-0.22643621f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,46.21992f,0f,0f,0f,0f,0f,16.930376f,-100.0f,44.368263f,0f,0f,0f,-310,81.50521f,84.81106f,-88.9061f,0f,0f,0f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,512.0f,0f,0f,0f,0f,0f,585.0f,227.0f,1436.0f,-365.0f,-365.0f,1056.0f,-915,-37.05418f,-33.03362f,-3.397752f,0f,0f,0f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,-59.798573f,0f,0f,0f,0f,0f,-15.924163f,55.22296f,-100.0f,0f,0f,0f,634,-0.02809078f,-0.7505646f,-0.32873806f,0f,0f,0f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,-6.5618277f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0.85349226f,1.1835555f,-2.2617686f,0f,0f,0f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,-74.65745f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.13954554f,-1.3136582f,-2.1350832f,0f,0f,0f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,85.6808f,0f,0f,0f,0f,0f,-100.0f,-13.943068f,76.57954f,0f,0f,0f,-1699,0.2672907f,0.08462354f,-0.34715742f,0f,0f,0f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.030321818f,-0.66388446f,0.35848764f,0f,0f,0f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.033321816f,0.09560518f,-0.16861725f,0f,0f,0f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.32080534f,0.8167138f,-0.45318115f,0f,0f,0f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-65.48201f,100.0f,0f,0f,0f,1,-0.07285167f,0.33826244f,-0.93822765f,0f,0f,0f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,-18.12872f,-37.93999f,20.625689f,0f,0f,0f,2938,0.28899407f,0.19465576f,0.025143726f,0f,0f,0f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,-54.928406f,-16.248856f,-21.511501f,0f,0f,0f,-1987,0.7382235f,-0.41037285f,-0.5353692f,0f,0f,0f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,-60.52303f,-73.6651f,19.473633f,0f,0f,0f,121,97.61914f,66.770424f,-81.46833f,0f,0f,0f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-100.0f,0f,0.0f,0f,0f,0f,0f,0f,-85.9435f,100.0f,-100.0f,0f,0f,0f,-1319,-100.0f,-100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0.0027876508f,-1.9402474f,-0.94665456f,0f,0f,0f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-100.0f,-14.289159f,436.0f,-171.0f,-309.0f,292,0.09758887f,0.70780003f,-0.69963956f,0f,0f,0f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,100.0f,100.0f,18.116344f,0f,0f,0f,-838,-0.24666049f,0.048652623f,0.9678799f,0f,0f,0f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,-3.5749235f,-39.757572f,47.876743f,-87.0f,-586.0f,1152.0f,-3,-0.11359433f,1.2229578f,-0.17055492f,0f,0f,0f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,37.725197f,34.918995f,-91.015686f,0f,0f,0f,-288,100.0f,-100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,-42.95507f,-73.43308f,-54.447914f,2797.0f,122.0f,1227.0f,681,0.7131936f,0.31725195f,0.2758534f,0f,0f,0f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,-48.359978f,28.080194f,16.793596f,-761.0f,-490.0f,-2301.0f,-4,-0.41485825f,-0.56652683f,-0.5884821f,0f,0f,0f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,113.0f,0f,-307.0f,0f,0f,0f,0f,0f,-653.0f,761.0f,-885.0f,-102.0f,1114.0f,237.0f,1885,0.6815255f,-0.55287135f,0.062010236f,0f,0f,0f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,11.567597f,0f,0f,0f,0f,0f,0f,0f,-27.085806f,-19.932383f,33.677715f,800.0f,28.0f,660.0f,737,-23.103893f,100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,123.9006f,0f,0f,0f,0f,0f,0f,0f,100.0f,61.84461f,-100.0f,714.0f,-2165.0f,1733.0f,-3,-0.75209814f,-7.2665424f,0.6629729f,0f,0f,0f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,1348.0f,0f,818.0f,0f,0f,0f,0f,0f,-440.0f,539.0f,645.0f,369.0f,791.0f,686.0f,40,-100.0f,-71.10611f,-8.796599f,0f,0f,0f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,1.5103072f,0f,0f,0f,0f,0f,0f,0f,-3.6650922f,60.875557f,-80.914665f,-206.0f,921.0f,702.0f,-877,20.797537f,-33.3712f,-12.114367f,0f,0f,0f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,151.0f,-8.0f,-1012.0f,0f,0f,0f,0f,0f,101.0f,-1660.0f,985.0f,609.0f,-641.0f,-614.0f,-711,33.155075f,53.74847f,49.472473f,71.74124f,0f,0f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-15.770079f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,-0.22823653f,-0.41239798f,0.64102733f,0f,0f,0f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-18.73382f,0f,-40.288315f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.35258937f,0.56252635f,0.1977175f,0f,0f,0f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-2.127245f,0f,0.0f,0f,0f,0f,0f,0f,-8.063277f,-22.602427f,66.10752f,0f,0f,0f,-1605,-0.07659492f,-0.25912493f,-0.8406826f,0f,0f,0f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-2217.0f,0f,220.0f,0f,0f,0f,0f,0f,344.0f,-1924.0f,158.0f,-699.0f,45.0f,2069.0f,892,0.2857601f,-0.0127627235f,-0.7775757f,0f,0f,0f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,29.447264f,0f,0f,0f,0f,0f,0f,0f,68.93598f,-2.959685f,66.86686f,185.0f,536.0f,-167.0f,1410,-152.73665f,-21.66152f,58.09332f,0f,0f,0f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-3.1549716f,0f,0f,0f,0f,0f,0f,0f,52.07683f,-75.329544f,20.451073f,0f,0f,0f,373,36.490726f,23.641775f,-87.65167f,0f,0f,0f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-3168.0f,0f,252.0f,0f,0f,0f,0f,0f,175.0f,-33.0f,-1209.0f,-1054.0f,-931.0f,-750.0f,754,-0.30874357f,-0.06848741f,-0.019243129f,0f,0f,0f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-330.0f,0f,1586.0f,0f,0f,0f,0f,0f,2233.0f,-971.0f,2341.0f,-438.0f,-131.0f,756.0f,-138,0.010490706f,-0.114585385f,-0.99498504f,0f,0f,0f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,33.781345f,0f,0f,0f,0f,0f,0f,0f,-29.22001f,54.05392f,23.373236f,-260.0f,-272.0f,304.0f,-831,92.66977f,-41.488297f,-12.102033f,0f,0f,0f ) ;
  }

  @Test
  public void test49() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-37.145306f,0f,-78.25598f,0f,0f,0f,0f,0f,100.0f,-32.654263f,18.223858f,0f,0f,0f,1248,0.2706581f,0.45313692f,-0.8235478f,0f,0f,0f ) ;
  }

  @Test
  public void test50() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,38.753002f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.6395259f,-0.48742354f,-0.4945831f,0f,0f,0f ) ;
  }

  @Test
  public void test51() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-39.099525f,0f,0.0f,0f,0f,0f,0f,0f,-9.402478f,100.0f,-100.0f,0f,0f,0f,1189,0.63277996f,-0.32993206f,0.70052433f,0f,0f,0f ) ;
  }

  @Test
  public void test52() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-40.24613f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.3576896f,-0.22121581f,0.70662946f,0f,0f,0f ) ;
  }

  @Test
  public void test53() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,44.53996f,0f,0f,0f,0f,0f,0f,0f,-83.43891f,-60.550625f,-2.4128144f,729.0f,606.0f,784.0f,918,76.16373f,-1.7497692f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test54() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-45.006027f,0f,26.471998f,0f,0f,0f,0f,0f,23.647175f,64.447716f,100.0f,0f,0f,0f,-1490,-0.08090061f,-0.27686045f,-0.9065153f,0f,0f,0f ) ;
  }

  @Test
  public void test55() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,45.09579f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.37448964f,-0.8811249f,-0.031724513f,0f,0f,0f ) ;
  }

  @Test
  public void test56() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,500.0f,0f,-508.0f,0f,0f,0f,0f,0f,-426.0f,-369.0f,-1461.0f,-1277.0f,1923.0f,340.0f,391,-0.11883719f,0.6615185f,0.48577896f,0f,0f,0f ) ;
  }

  @Test
  public void test57() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,5.033091f,0f,0f,0f,0f,0f,0f,0f,70.462616f,-50.31292f,-82.87371f,604.0f,896.0f,-619.0f,347,14.233793f,-50.964725f,43.047104f,0f,0f,0f ) ;
  }

  @Test
  public void test58() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,515.0f,-926.0f,-1399.0f,0f,0f,0f,0f,0f,-837.0f,-1672.0f,-517.0f,-381.0f,-1586.0f,-52.0f,806,0.49478966f,0.33106598f,0.68935025f,42.306274f,0f,0f ) ;
  }

  @Test
  public void test59() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-517.0f,0f,629.0f,0f,0f,0f,0f,0f,338.0f,560.0f,-68.0f,1021.0f,-401.0f,736.0f,1057,-0.32367334f,-0.64356256f,0.6630092f,0f,0f,0f ) ;
  }

  @Test
  public void test60() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,5.214109f,0f,0f,0f,0f,0f,0f,0f,26.004286f,21.141495f,0.31037045f,432.0f,-491.0f,471.0f,-356,0.47607225f,-0.7295544f,0.32918203f,0f,0f,0f ) ;
  }

  @Test
  public void test61() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,54.999313f,0f,0f,0f,0f,0f,0f,0f,22.572819f,16.247011f,-2.7402184f,132.0f,140.0f,66.0f,432,-0.075364664f,0.074549824f,-0.17840502f,0f,0f,0f ) ;
  }

  @Test
  public void test62() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,55.74048f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0.720956f,0.22957505f,0.3250804f,0f,0f,0f ) ;
  }

  @Test
  public void test63() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,55.885036f,0f,0f,0f,0f,0f,0f,0f,-9.874721f,14.808625f,100.0f,-2426.0f,-1096.0f,914.0f,1,3.6924438f,0.1060438f,0.008079763f,0f,0f,0f ) ;
  }

  @Test
  public void test64() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,57.751934f,0f,0f,0f,0f,0f,0f,0f,33.896465f,-66.4461f,-24.771456f,231.0f,-1148.0f,952.0f,-1092,14.99051f,26.106981f,-49.5159f,0f,0f,0f ) ;
  }

  @Test
  public void test65() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-58.6902f,0f,1.7915636f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.035986077f,0.1471269f,1.0387336f,0f,0f,0f ) ;
  }

  @Test
  public void test66() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,59.94677f,0f,0f,0f,0f,0f,0f,0f,-99.00725f,-58.566887f,-62.09351f,-333.0f,-1423.0f,106.0f,587,3.26132f,97.38921f,-97.0581f,0f,0f,0f ) ;
  }

  @Test
  public void test67() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,643.0f,0f,1.0f,0f,0f,0f,0f,0f,687.0f,-475.0f,396.0f,-245.0f,1762.0f,-114.0f,-402,-68.11759f,17.354534f,63.105854f,0f,0f,0f ) ;
  }

  @Test
  public void test68() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,66.675606f,0f,0f,0f,0f,0f,0f,0f,100.0f,-73.19227f,36.04921f,-1501.0f,927.0f,-1161.0f,-694,-0.5245138f,0.22485793f,0.8211725f,0f,0f,0f ) ;
  }

  @Test
  public void test69() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-68.05203f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.28804228f,0.24807547f,0.9107203f,0f,0f,0f ) ;
  }

  @Test
  public void test70() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,71.50761f,0f,0f,0f,0f,0f,0f,0f,-27.343603f,-6.364335f,-21.236536f,592.0f,-181.0f,-708.0f,528,4.199864f,99.845245f,-3.8446715f,0f,0f,0f ) ;
  }

  @Test
  public void test71() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-723.0f,0f,1148.0f,0f,0f,0f,0f,0f,147.0f,-1229.0f,-333.0f,-594.0f,-688.0f,1218.0f,-988,-0.74873865f,0.50671196f,0.07524994f,0f,0f,0f ) ;
  }

  @Test
  public void test72() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-73.98693f,0f,38.601597f,0f,0f,0f,0f,0f,53.518818f,40.468906f,-76.94923f,0f,0f,0f,-642,39.86758f,-54.123074f,73.55029f,0f,0f,0f ) ;
  }

  @Test
  public void test73() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,77.36735f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-6.8014445f,-4.8668127f,0f,0f,0f,-162,-0.013687633f,-0.09038792f,0.46966344f,0f,0f,0f ) ;
  }

  @Test
  public void test74() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,77.41204f,0f,0f,0f,0f,0f,0f,0f,-17.11278f,-100.0f,43.562267f,208.0f,221.0f,640.0f,-849,60.69481f,33.090775f,76.98393f,0f,0f,0f ) ;
  }

  @Test
  public void test75() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,77.729576f,0f,0f,0f,0f,0f,0f,0f,39.759064f,-8.6318035f,23.414434f,-612.0f,-1818.0f,369.0f,449,-100.0f,100.0f,-12.483066f,0f,0f,0f ) ;
  }

  @Test
  public void test76() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-781.0f,0f,2990.0f,0f,0f,0f,0f,0f,1749.0f,922.0f,905.0f,-778.0f,761.0f,-1114.0f,-203,-0.34125364f,0.055385392f,0.44769773f,0f,0f,0f ) ;
  }

  @Test
  public void test77() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-8.0f,0f,583.0f,0f,0f,0f,0f,0f,171.0f,-361.0f,-541.0f,437.0f,-413.0f,414.0f,-768,-165.23628f,42.247013f,250.4111f,0f,0f,0f ) ;
  }

  @Test
  public void test78() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,81.14455f,0f,0f,0f,0f,0f,0f,0f,1.6350951f,-37.92092f,-18.524578f,-709.0f,850.0f,-18.0f,366,-25.525835f,46.593906f,-47.605984f,0f,0f,0f ) ;
  }

  @Test
  public void test79() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,82.07656f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-69.79992f,80.83048f,2.0f,641.0f,556.0f,-493,95.67645f,66.45135f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test80() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-84.17176f,0f,0f,0f,0f,0f,0f,0f,-42.225296f,100.0f,75.44753f,0f,0f,0f,823,0.11439836f,-0.30739677f,0.09308499f,0f,0f,0f ) ;
  }

  @Test
  public void test81() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,847.0f,0f,-1364.0f,0f,0f,0f,0f,0f,929.0f,1519.0f,422.0f,744.0f,554.0f,-937.0f,-11,-106.797356f,-2.325526f,32.460434f,0f,0f,0f ) ;
  }

  @Test
  public void test82() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-87.15789f,0f,-5.7354517f,0f,0f,0f,0f,0f,-51.830956f,-35.510803f,-45.915302f,0f,0f,0f,-284,-79.0978f,31.580036f,71.646095f,0f,0f,0f ) ;
  }

  @Test
  public void test83() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,879.0f,0f,89.0f,0f,0f,0f,0f,0f,191.0f,-954.0f,-1821.0f,-705.0f,-751.0f,403.0f,-575,-41.8236f,98.42908f,92.66766f,0f,0f,0f ) ;
  }

  @Test
  public void test84() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,91.05087f,0f,0f,0f,0f,0f,0f,0f,-10.356057f,-54.083652f,32.828125f,1413.0f,317.0f,968.0f,-448,35.865578f,7.3515096f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test85() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,940.0f,0f,521.0f,0f,0f,0f,0f,0f,-425.0f,-953.0f,1492.0f,546.0f,-515.0f,824.0f,-469,-10.56788f,-8.235651f,-8.270726f,0f,0f,0f ) ;
  }

  @Test
  public void test86() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,95.06591f,0f,0f,0f,0f,0f,0f,0f,-99.24222f,7.1905966f,34.80082f,-1004.0f,666.0f,251.0f,1184,-0.63852125f,-0.31878832f,-1.7550172f,0f,0f,0f ) ;
  }

  @Test
  public void test87() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-97.97863f,0f,36.438152f,0f,0f,0f,0f,0f,-42.920925f,100.0f,100.0f,0f,0f,0f,-446,-0.47034457f,-0.8784801f,0.08395667f,0f,0f,0f ) ;
  }

  @Test
  public void test88() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-995.0f,0f,923.0f,0f,0f,0f,0f,0f,-635.0f,-997.0f,-682.0f,1327.0f,-174.0f,-978.0f,-1178,0.4194617f,-0.4754656f,0.78406465f,0f,0f,0f ) ;
  }

  @Test
  public void test89() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-99.86524f,0f,-100.0f,0f,0f,0f,0f,0f,100.0f,100.0f,23.00266f,0f,0f,0f,-165,0.04371347f,-0.733568f,-0.67820877f,0f,0f,0f ) ;
  }

  @Test
  public void test90() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-99.99999f,0f,0f,0f,0f,0f,0f,0f,57.455544f,0.0912592f,99.05837f,0f,0f,0f,895,-0.98912954f,-0.015968002f,-0.1461772f,0f,0f,0f ) ;
  }

  @Test
  public void test91() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.49949163f,27.537313f,0f,0f,0f,0f,0f,0f,0f,44.441208f,25.170513f,-47.570633f,646.0f,-323.0f,-819.0f,1,-2.698468f,-1.0942652f,-3.10016f,0f,0f,0f ) ;
  }

  @Test
  public void test92() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-0.871586f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-4.261557f,6.220071f,-8.964041f,0f,0f,0f,264,0.897011f,0.41904724f,-0.13567096f,0f,0f,0f ) ;
  }

  @Test
  public void test93() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,-188.1273f,-48.659595f,0f,0f,0f,-1,0.76473784f,0.23412958f,0.6002994f,0f,0f,0f ) ;
  }

  @Test
  public void test94() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,100.0f,100.0f,7.959725f,-661.0f,-274.0f,10.0f,6,0.046757407f,0.02703056f,-0.99854046f,0f,0f,0f ) ;
  }

  @Test
  public void test95() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,31.408802f,89.00687f,-167.0f,1555.0f,73.0f,1,0.5677892f,-0.7579949f,-0.32102826f,0f,0f,0f ) ;
  }

  @Test
  public void test96() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-92.88388f,100.0f,-99.999054f,0f,0f,0f,1,0.03830799f,-0.733848f,0.6782327f,0f,0f,0f ) ;
  }

  @Test
  public void test97() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0.0f,0f,20.169737f,0f,0f,0f,0f,0f,-99.988235f,-100.0f,-31.535084f,0f,0f,0f,1,0.65190035f,-0.03296236f,0.7575879f,0f,0f,0f ) ;
  }

  @Test
  public void test98() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0.0f,0f,-87.17065f,0f,0f,0f,0f,0f,59.822075f,-75.1614f,36.94859f,0f,0f,0f,3,-0.97813416f,0.09383516f,0.18560372f,0f,0f,0f ) ;
  }

  @Test
  public void test99() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test100() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,89.55364f,-66.046776f,0f,0f,0f,-208,-0.26286876f,0.071524434f,-0.368499f,0f,0f,0f ) ;
  }

  @Test
  public void test101() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-34.09707f,-13.845721f,-50.20212f,0f,0f,0f,931,41.35113f,72.03025f,-52.828823f,0f,0f,0f ) ;
  }

  @Test
  public void test102() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,35.25312f,61.843204f,-92.24478f,0f,0f,0f,-557,91.90437f,-4.2340927f,32.28439f,0f,0f,0f ) ;
  }

  @Test
  public void test103() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,44.493484f,-19.959406f,56.076756f,0f,0f,0f,1,0.7855934f,-0.09213396f,-0.611845f,0f,0f,0f ) ;
  }

  @Test
  public void test104() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test105() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.0032331287f,0.9482452f,-0.06494216f,0f,0f,0f ) ;
  }

  @Test
  public void test106() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.0033166653f,0.051446788f,0.9986702f,0f,0f,0f ) ;
  }

  @Test
  public void test107() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.005843603f,-0.007551042f,0.9999544f,0f,0f,0f ) ;
  }

  @Test
  public void test108() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.02512102f,0.014250907f,-0.0015028248f,0f,0f,0f ) ;
  }

  @Test
  public void test109() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.029789472f,0.127217f,-0.33523586f,0f,0f,0f ) ;
  }

  @Test
  public void test110() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.091010734f,0.41163185f,-0.545431f,0f,0f,0f ) ;
  }

  @Test
  public void test111() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.16720639f,-0.2446817f,0.9550774f,0f,0f,0f ) ;
  }

  @Test
  public void test112() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.18161866f,0.80080336f,0.23013163f,0f,0f,0f ) ;
  }

  @Test
  public void test113() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.20311877f,-0.30086437f,-0.052684184f,0f,0f,0f ) ;
  }

  @Test
  public void test114() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.21138895f,0.042965073f,0.42974445f,0f,0f,0f ) ;
  }

  @Test
  public void test115() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.21702394f,-0.10799984f,0.97017354f,0f,0f,0f ) ;
  }

  @Test
  public void test116() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.24248445f,0.54383796f,-0.101495616f,0f,0f,0f ) ;
  }

  @Test
  public void test117() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.24907063f,0.32845527f,0.9110878f,0f,0f,0f ) ;
  }

  @Test
  public void test118() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.28163856f,0.26169342f,0.92314476f,0f,0f,0f ) ;
  }

  @Test
  public void test119() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.29739946f,-0.78353995f,0.029142028f,0f,0f,0f ) ;
  }

  @Test
  public void test120() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.3756135f,-0.040752076f,0.80159587f,0f,0f,0f ) ;
  }

  @Test
  public void test121() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.50000787f,0.74831676f,-0.16128372f,0f,0f,0f ) ;
  }

  @Test
  public void test122() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.58115494f,-0.31812105f,-0.31637728f,0f,0f,0f ) ;
  }

  @Test
  public void test123() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.5841798f,-0.08503387f,0.80715746f,0f,0f,0f ) ;
  }

  @Test
  public void test124() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.67569405f,0.13370915f,0.24601872f,0f,0f,0f ) ;
  }

  @Test
  public void test125() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.7432362f,0.03566697f,-0.506948f,0f,0f,0f ) ;
  }

  @Test
  public void test126() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.83300126f,0.19168404f,0.069329955f,0f,0f,0f ) ;
  }

  @Test
  public void test127() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.89888173f,-0.41439f,-0.14245203f,0f,0f,0f ) ;
  }

  @Test
  public void test128() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.9190381f,-0.3566237f,-0.16789407f,0f,0f,0f ) ;
  }

  @Test
  public void test129() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.91963154f,0.2088362f,0.33266383f,0f,0f,0f ) ;
  }

  @Test
  public void test130() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.968513f,0.031971123f,0.24690148f,0f,0f,0f ) ;
  }

  @Test
  public void test131() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test132() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test133() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-1.7370984E-6f,5.7747314E-7f,-3.523411E-6f,0f,0f,0f ) ;
  }

  @Test
  public void test134() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,34.230984f,-56.446304f,-7.4793935f,0f,0f,0f ) ;
  }

  @Test
  public void test135() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-3.679581E-4f,-0.016132616f,-2.6262086E-4f,0f,0f,0f ) ;
  }

  @Test
  public void test136() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-42.056324f,-96.092545f,-121.08426f,0f,0f,0f ) ;
  }

  @Test
  public void test137() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-5.851662E-4f,-0.0055841557f,-0.08103883f,0f,0f,0f ) ;
  }

  @Test
  public void test138() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,184,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test139() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0.7569308f,0.6358507f,-0.1225977f,0f,0f,0f ) ;
  }

  @Test
  public void test140() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test141() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-2399,-9.096711E-7f,1.6888454E-5f,-2.8239706E-4f,0f,0f,0f ) ;
  }

  @Test
  public void test142() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-3487,-0.5505326f,-0.35048586f,-0.7576764f,0f,0f,0f ) ;
  }

  @Test
  public void test143() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-369,-0.044593353f,-0.07117621f,0.99646646f,0f,0f,0f ) ;
  }

  @Test
  public void test144() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,519,5.9000955f,-33.88221f,9.779333f,0f,0f,0f ) ;
  }

  @Test
  public void test145() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-689,0.046967827f,-0.2020603f,-0.6867294f,0f,0f,0f ) ;
  }

  @Test
  public void test146() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,694,56.31001f,-24.647755f,-81.91169f,0f,0f,0f ) ;
  }

  @Test
  public void test147() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,736,0.0045784405f,-0.0017040977f,-4.997533E-4f,0f,0f,0f ) ;
  }

  @Test
  public void test148() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-769,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test149() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-775,18.365063f,98.63098f,85.52843f,0f,0f,0f ) ;
  }

  @Test
  public void test150() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-821,0.62481356f,-0.12652725f,0.13015567f,0f,0f,0f ) ;
  }

  @Test
  public void test151() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-923,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test152() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,941,-3.1115214E-5f,4.9331284E-5f,-2.5761732E-5f,0f,0f,0f ) ;
  }

  @Test
  public void test153() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-989,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test154() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-15.345843f,9.675487f,0f,0f,0f,-689,-0.37156525f,-2.378518f,0.06781486f,0f,0f,0f ) ;
  }

  @Test
  public void test155() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-19.847527f,-40.560158f,0f,0f,0f,-424,0.6210325f,0.4593928f,0.6350409f,0f,0f,0f ) ;
  }

  @Test
  public void test156() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-16.342056f,15.152506f,-22.698141f,0f,0f,0f,1,4.3671966f,20.919966f,10.821191f,0f,0f,0f ) ;
  }

  @Test
  public void test157() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-181.13423f,85.60682f,-79.60727f,0f,0f,0f,1,0.012521768f,1.7552814f,0.16232425f,0f,0f,0f ) ;
  }

  @Test
  public void test158() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,22.31716f,29.120697f,8.047093f,0f,0f,0f,-738,-21.643152f,18.133871f,-5.5991974f,0f,0f,0f ) ;
  }

  @Test
  public void test159() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-23.694773f,70.99172f,12.760771f,0f,0f,0f,-747,-30.108032f,-67.47242f,-68.854126f,0f,0f,0f ) ;
  }

  @Test
  public void test160() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,26.747677f,16.50067f,-22.108469f,0f,0f,0f,-779,0.5054682f,-2.0867455f,-0.9459089f,0f,0f,0f ) ;
  }

  @Test
  public void test161() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,31.751768f,-13.952403f,-10.069667f,0f,0f,0f,1,1.0208392f,0.90996885f,-0.57298446f,0f,0f,0f ) ;
  }

  @Test
  public void test162() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-33.229637f,-21.129707f,-34.234486f,0f,0f,0f,1,-6.482089f,5.3642817f,2.9809635f,0f,0f,0f ) ;
  }

  @Test
  public void test163() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-36.30464f,87.31243f,-64.75419f,0f,0f,0f,-556,-82.32858f,6.6525507f,-78.37001f,0f,0f,0f ) ;
  }

  @Test
  public void test164() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,43.606796f,-72.56709f,-100.0f,0f,0f,0f,792,-0.31633988f,-0.16434573f,0.874935f,0f,0f,0f ) ;
  }

  @Test
  public void test165() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,45.77805f,-71.91488f,10.000493f,0f,0f,0f,1,-0.29139426f,0.053531744f,0.035018474f,0f,0f,0f ) ;
  }

  @Test
  public void test166() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-54.2316f,-100.0f,-59.662945f,0f,0f,0f,959,-0.69560635f,-0.71495336f,0.070523344f,0f,0f,0f ) ;
  }

  @Test
  public void test167() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,6.0990415f,-7.0337806f,9.429833f,0f,0f,0f,2,0.88748914f,0.25450206f,-0.38417664f,0f,0f,0f ) ;
  }

  @Test
  public void test168() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-6.694556f,95.019714f,-100.0f,0f,0f,0f,1,0.5085313f,0.49901426f,0.7016985f,0f,0f,0f ) ;
  }

  @Test
  public void test169() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-67.700325f,100.0f,-55.806145f,0f,0f,0f,-956,-0.45295203f,-0.053418096f,-0.3178181f,0f,0f,0f ) ;
  }

  @Test
  public void test170() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,75.8928f,55.226913f,54.15843f,0f,0f,0f,1,5.576338f,28.517824f,-36.889595f,0f,0f,0f ) ;
  }

  @Test
  public void test171() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,77.00822f,100.0f,-75.460175f,0f,0f,0f,1,0.1193152f,-0.70176494f,-0.35960218f,0f,0f,0f ) ;
  }

  @Test
  public void test172() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-79.81549f,74.26863f,-44.87645f,0f,0f,0f,2,-0.19629972f,0.39968932f,0.64407414f,0f,0f,0f ) ;
  }

  @Test
  public void test173() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,85.842926f,65.805046f,58.288216f,0f,0f,0f,1,0.8310877f,-0.19211316f,-0.5219059f,0f,0f,0f ) ;
  }

  @Test
  public void test174() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,99.52861f,100.0f,-54.382717f,0f,0f,0f,1,0.42229885f,-0.62642443f,0.51463777f,0f,0f,0f ) ;
  }

  @Test
  public void test175() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,-100.0f,0f,0f,0f,0f,0f,0f,2,-100.0f,-100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test176() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-100.0f,100.0f,0f,0f,0f,0f,0f,0f,2,100.0f,-100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test177() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,-3.9777074f,0f,0f,0f,0f,0f,0f,8,-100.0f,-100.0f,-3.97743f,0f,0f,0f ) ;
  }

  @Test
  public void test178() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,99.99002f,100.0f,0f,0f,0f,0f,0f,0f,2,-100.0f,98.9871f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test179() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-20.629568f,-80.75273f,-14.621506f,0f,0f,0f,0f,0f,0f,16,19.33217f,167.35846f,-39.179817f,0f,0f,0f ) ;
  }

  @Test
  public void test180() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-23.961706f,18.636148f,-5.274148f,0f,0f,0f,0f,0f,0f,2,-23.947857f,18.62938f,-5.3104568f,0f,0f,0f ) ;
  }

  @Test
  public void test181() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,35.364483f,65.96268f,97.94586f,0f,0f,0f,0f,0f,0f,2,36.766476f,-3.861093f,-27.375242f,0f,0f,0f ) ;
  }

  @Test
  public void test182() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,4.3111477f,45.183666f,14.637716f,0f,0f,0f,0f,0f,0f,4,4.21946f,45.06636f,14.094542f,0f,0f,0f ) ;
  }

  @Test
  public void test183() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,11.192274f,-39.14983f,-66.69534f,915.0f,-261.0f,1928.0f,915,-0.7740608f,0.13460377f,-0.61863697f,0f,0f,0f ) ;
  }

  @Test
  public void test184() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-41.463326f,-4.2776027f,11.285908f,-1019.0f,943.0f,800.0f,682,0.22297013f,-0.28998083f,0.70926154f,0f,0f,0f ) ;
  }

  @Test
  public void test185() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,-43.300777f,67.2286f,-100.0f,0f,0f,0f,-369,0.84663504f,0.35807973f,-0.3936852f,0f,0f,0f ) ;
  }

  @Test
  public void test186() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,82.76771f,-51.492775f,-81.946205f,817.0f,196.0f,702.0f,784,67.61085f,-56.30281f,-48.484013f,0f,0f,0f ) ;
  }

  @Test
  public void test187() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-99.999985f,73.43568f,-87.14797f,579.0f,417.0f,-313.0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test188() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-11.563432f,0f,0f,0f,0f,0f,-49.27916f,-0.15211758f,-49.214417f,0f,0f,0f,-421,85.920166f,-37.373642f,-85.91768f,0f,0f,0f ) ;
  }

  @Test
  public void test189() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,11.594714f,0f,0f,0f,0f,0f,-1.6873518f,-2.7984796f,33.84167f,488.0f,1292.0f,1520.0f,-739,0.3513995f,0.5272927f,0.5724845f,0f,0f,0f ) ;
  }

  @Test
  public void test190() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,125.21265f,0f,0f,0f,0f,0f,71.97049f,-84.559074f,-96.67308f,916.0f,748.0f,-291.0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test191() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,12.849571f,0f,0f,0f,0f,0f,-48.38501f,94.0145f,-17.394733f,604.0f,726.0f,266.0f,19,-74.71405f,10.273627f,74.09109f,0f,0f,0f ) ;
  }

  @Test
  public void test192() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,13.745802f,0f,0f,0f,0f,0f,1.3082339f,-95.27514f,4.9593916f,-39.0f,-341.0f,-223.0f,-2,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test193() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,15.707743f,0f,0f,0f,0f,0f,61.321297f,-10.624422f,-17.608385f,304.0f,-899.0f,728.0f,973,47.244453f,-11.413587f,31.729105f,0f,0f,0f ) ;
  }

  @Test
  public void test194() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,16.736055f,0f,0f,0f,0f,0f,40.462563f,0.94461274f,-27.275578f,-769.0f,-61.0f,-1143.0f,-1114,47.931408f,-19.548063f,70.427925f,0f,0f,0f ) ;
  }

  @Test
  public void test195() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,174.04213f,0f,0f,0f,0f,0f,-7.7591815f,-0.43885738f,5.478266f,-310.0f,1615.0f,-308.0f,-169,-59.396378f,-30.82453f,-86.5958f,0f,0f,0f ) ;
  }

  @Test
  public void test196() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,19.82018f,0f,0f,0f,0f,0f,-4.5458727f,72.63326f,38.420677f,0f,0f,0f,-678,-44.566353f,53.739895f,-49.82662f,0f,0f,0f ) ;
  }

  @Test
  public void test197() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,21.43539f,0f,0f,0f,0f,0f,-33.459736f,21.486498f,-49.35367f,213.0f,1007.0f,294.0f,818,-0.40115753f,-0.030356297f,-0.18966994f,0f,0f,0f ) ;
  }

  @Test
  public void test198() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,248.44675f,0f,0f,0f,0f,0f,-142.724f,18.109688f,97.5389f,-1402.0f,1299.0f,485.0f,79,-115.57692f,-95.93837f,78.98005f,0f,0f,0f ) ;
  }

  @Test
  public void test199() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,250.73494f,0f,0f,0f,0f,0f,-43.134785f,-64.68651f,-4.0922866f,-415.0f,-571.0f,434.0f,709,-41.968136f,15.576391f,196.28247f,0f,0f,0f ) ;
  }

  @Test
  public void test200() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,251.31584f,0f,0f,0f,0f,0f,-100.0f,30.230997f,60.999622f,-584.0f,131.0f,912.0f,-644,-37.67278f,61.586853f,-92.297066f,0f,0f,0f ) ;
  }

  @Test
  public void test201() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,251.51492f,0f,0f,0f,0f,0f,-5.286839f,52.844746f,-76.53611f,-940.0f,383.0f,-342.0f,-696,-0.30836973f,0.4670863f,0.32725453f,0f,0f,0f ) ;
  }

  @Test
  public void test202() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,252.0711f,0f,0f,0f,0f,0f,3.9816813f,-18.10026f,-48.798756f,1498.0f,-226.0f,190.0f,388,-0.41937467f,-0.049542114f,-2.0054498f,0f,0f,0f ) ;
  }

  @Test
  public void test203() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,252.10867f,0f,0f,0f,0f,0f,-77.37424f,-42.973698f,-97.79679f,-882.0f,-685.0f,-951.0f,367,-12.951107f,14.569502f,3.8775406f,0f,0f,0f ) ;
  }

  @Test
  public void test204() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,252.52434f,0f,0f,0f,0f,0f,76.41831f,141.67525f,-135.49089f,-981.0f,214.0f,-711.0f,-1586,0.013428001f,0.115554675f,-1.103655f,0f,0f,0f ) ;
  }

  @Test
  public void test205() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,252.67554f,0f,0f,0f,0f,0f,-54.829018f,-5.0031586f,67.92049f,-79.0f,20.0f,1160.0f,115,-66.53527f,126.021164f,69.46997f,0f,0f,0f ) ;
  }

  @Test
  public void test206() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,252.69724f,0f,0f,0f,0f,0f,-81.15796f,-6.533235f,-39.29556f,-945.0f,1111.0f,-1205.0f,-3034,1.6471993f,-0.40482056f,-4.873544f,0f,0f,0f ) ;
  }

  @Test
  public void test207() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,252.9357f,0f,0f,0f,0f,0f,100.0f,15.572009f,-8.021861f,2338.0f,-1534.0f,112.0f,939,137.4873f,-5.2517605f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test208() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.0078f,0f,0f,0f,0f,0f,76.36192f,10.512697f,92.2069f,-615.0f,904.0f,2475.0f,999,-50.962868f,-64.48003f,49.57318f,0f,0f,0f ) ;
  }

  @Test
  public void test209() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.05547f,0f,0f,0f,0f,0f,85.44279f,40.98349f,24.10274f,1601.0f,450.0f,-1119.0f,453,-34.368076f,28.026814f,74.2277f,0f,0f,0f ) ;
  }

  @Test
  public void test210() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.16026f,0f,0f,0f,0f,0f,-33.112648f,25.655945f,-39.68916f,-784.0f,-448.0f,-590.0f,914,74.44413f,55.343296f,-38.201824f,0f,0f,0f ) ;
  }

  @Test
  public void test211() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.29018f,0f,0f,0f,0f,0f,60.068756f,3.5300696f,44.71655f,288.0f,897.0f,-153.0f,904,58.249557f,-37.3228f,-4.5777006f,0f,0f,0f ) ;
  }

  @Test
  public void test212() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.31108f,0f,0f,0f,0f,0f,-18.20126f,-71.43189f,-36.61154f,614.0f,-1638.0f,851.0f,-936,-17.467686f,-40.924706f,-73.23694f,0f,0f,0f ) ;
  }

  @Test
  public void test213() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.99887f,0f,0f,0f,0f,0f,106.254944f,51.726376f,-68.44132f,1658.0f,-497.0f,19.0f,-1311,35.902317f,-94.244095f,-46.072945f,0f,0f,0f ) ;
  }

  @Test
  public void test214() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.03578f,0f,0f,0f,0f,0f,-123.01968f,5.460414f,-105.9588f,-1999.0f,-63.0f,554.0f,673,-100.54187f,5.188411f,-60.436176f,0f,0f,0f ) ;
  }

  @Test
  public void test215() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,256.26242f,0f,0f,0f,0f,0f,100.0f,100.0f,100.0f,852.0f,245.0f,-728.0f,-1916,21.206682f,168.23866f,-12.488853f,0f,0f,0f ) ;
  }

  @Test
  public void test216() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,256.9275f,0f,0f,0f,0f,0f,171.38979f,92.62375f,87.4706f,1222.0f,331.0f,-1139.0f,-328,-0.025476895f,-0.17078172f,1.3953807f,0f,0f,0f ) ;
  }

  @Test
  public void test217() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,258.44803f,0f,0f,0f,0f,0f,117.659134f,8.757987f,54.614292f,829.0f,1003.0f,-45.0f,-797,0.908303f,0.11169115f,1.2491527f,0f,0f,0f ) ;
  }

  @Test
  public void test218() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,264.85895f,0f,0f,0f,0f,0f,41.355564f,-31.88129f,67.69842f,46.0f,175.0f,321.0f,287,16.846159f,-80.74971f,43.427204f,0f,0f,0f ) ;
  }

  @Test
  public void test219() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,274.18268f,0f,0f,0f,0f,0f,-54.672527f,83.639f,72.819176f,-917.0f,731.0f,-22.0f,-812,-137.54163f,48.37402f,21.32439f,0f,0f,0f ) ;
  }

  @Test
  public void test220() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,274.24615f,0f,0f,0f,0f,0f,100.0f,-27.47247f,100.0f,667.0f,-458.0f,572.0f,-723,78.33332f,-100.0f,85.44753f,0f,0f,0f ) ;
  }

  @Test
  public void test221() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,27.533903f,0f,0f,0f,0f,0f,-29.59484f,20.761292f,-7.828645f,118.0f,40.0f,-340.0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test222() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,28.457119f,0f,0f,0f,0f,0f,-40.703873f,-32.82476f,-0.11049008f,-356.0f,-810.0f,-676.0f,740,6.072941f,-7.7940106f,78.23613f,0f,0f,0f ) ;
  }

  @Test
  public void test223() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,30.427307f,0f,0f,0f,0f,0f,-20.39281f,-7.795168f,31.074392f,-630.0f,225.0f,-357.0f,-872,-0.07493434f,0.19959207f,0.75446683f,0f,0f,0f ) ;
  }

  @Test
  public void test224() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,308.9114f,0f,0f,0f,0f,0f,81.52718f,81.608955f,27.714212f,1140.0f,-55.0f,1243.0f,-131,-23.285704f,13.535839f,28.645836f,0f,0f,0f ) ;
  }

  @Test
  public void test225() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,32.56009f,0f,0f,0f,0f,0f,-8.648368f,45.995808f,21.356792f,992.0f,-27.0f,460.0f,-673,33.46864f,25.966047f,-42.36967f,0f,0f,0f ) ;
  }

  @Test
  public void test226() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,33.392155f,0f,0f,0f,0f,0f,49.228996f,2.7654548f,86.9929f,-746.0f,5.0f,422.0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test227() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,34.002064f,0f,0f,0f,0f,0f,-5.68355f,-7.853385f,-8.670165f,-1411.0f,328.0f,132.0f,-977,78.86917f,-64.47311f,6.698287f,0f,0f,0f ) ;
  }

  @Test
  public void test228() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,35.997494f,0f,0f,0f,0f,0f,-71.0557f,-2.6305654f,34.035122f,890.0f,-1006.0f,806.0f,-260,-41.72367f,84.23407f,-80.59679f,0f,0f,0f ) ;
  }

  @Test
  public void test229() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,36.181206f,0f,0f,0f,0f,0f,46.415066f,-42.60536f,-27.09028f,1000.0f,713.0f,592.0f,694,-0.83235145f,-1.4287635f,-0.5994318f,0f,0f,0f ) ;
  }

  @Test
  public void test230() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,38.291695f,0f,0f,0f,0f,0f,27.407751f,78.69698f,-77.80557f,205.0f,1767.0f,255.0f,-466,0.1804769f,-0.040763136f,-0.0091371965f,0f,0f,0f ) ;
  }

  @Test
  public void test231() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,38.3373f,0f,0f,0f,0f,0f,-0.65281636f,21.570541f,-60.013565f,1627.0f,-375.0f,-153.0f,-1436,29.270432f,110.12535f,39.26321f,0f,0f,0f ) ;
  }

  @Test
  public void test232() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,39.6407f,0f,0f,0f,0f,0f,22.308386f,31.822674f,21.467047f,298.0f,323.0f,396.0f,-776,26.959177f,-15.572669f,89.30048f,0f,0f,0f ) ;
  }

  @Test
  public void test233() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-4.122763E-18f,0f,0f,0f,0f,0f,100.0f,-99.238205f,100.0f,0f,0f,0f,885,-0.019855645f,0.68561095f,0.7276973f,0f,0f,0f ) ;
  }

  @Test
  public void test234() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,42.81557f,0f,0f,0f,0f,0f,36.03146f,-75.21226f,96.68652f,0f,0f,0f,-390,-32.18862f,62.588085f,60.682644f,0f,0f,0f ) ;
  }

  @Test
  public void test235() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-44.3484f,0f,0f,0f,0f,0f,-100.0f,-100.0f,-100.0f,0f,0f,0f,566,0.17933325f,-0.053608064f,-0.8918636f,0f,0f,0f ) ;
  }

  @Test
  public void test236() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,44.93926f,0f,0f,0f,0f,0f,55.39438f,21.634111f,-35.420525f,-679.0f,324.0f,-864.0f,518,-26.45859f,-45.37447f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test237() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,46.34437f,0f,0f,0f,0f,0f,-100.0f,-100.0f,99.66455f,234.0f,359.0f,595.0f,2665,-100.0f,-56.74176f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test238() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,47.634983f,0f,0f,0f,0f,0f,24.894566f,28.745554f,30.989235f,365.0f,-1051.0f,-897.0f,-150,-0.49849427f,-0.05687268f,0.45321012f,0f,0f,0f ) ;
  }

  @Test
  public void test239() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,48.028725f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test240() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,50.418846f,0f,0f,0f,0f,0f,29.546059f,44.279823f,-21.288555f,254.0f,156.0f,677.0f,926,-44.2996f,63.118317f,69.80227f,0f,0f,0f ) ;
  }

  @Test
  public void test241() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,51.653507f,0f,0f,0f,0f,0f,-31.88347f,16.035967f,-19.318975f,252.0f,642.0f,117.0f,-655,-0.5312509f,-0.02053035f,0.85971946f,0f,0f,0f ) ;
  }

  @Test
  public void test242() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,52.723568f,0f,0f,0f,0f,0f,9.590084f,6.9856963f,7.88293f,-33.0f,192.0f,-130.0f,199,0.06336289f,-0.27276886f,0.4857638f,0f,0f,0f ) ;
  }

  @Test
  public void test243() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,53.47029f,0f,0f,0f,0f,0f,4.578406f,8.763364f,-31.364113f,658.0f,-890.0f,-438.0f,799,0.0074738003f,0.47060916f,-0.02166282f,0f,0f,0f ) ;
  }

  @Test
  public void test244() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,54.30423f,0f,0f,0f,0f,0f,-92.939125f,-47.901745f,90.98738f,-557.0f,-1208.0f,963.0f,512,-0.0019004791f,-0.4208298f,0.8433199f,0f,0f,0f ) ;
  }

  @Test
  public void test245() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,55.3744f,0f,0f,0f,0f,0f,-22.355768f,-77.405014f,74.012375f,-695.0f,-472.0f,46.0f,375,81.05899f,50.391838f,77.185974f,0f,0f,0f ) ;
  }

  @Test
  public void test246() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-57.403904f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test247() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,63.60291f,0f,0f,0f,0f,0f,67.158226f,-88.10967f,11.238499f,-417.0f,-534.0f,-1694.0f,-322,99.99987f,86.84639f,83.30231f,0f,0f,0f ) ;
  }

  @Test
  public void test248() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,63.88103f,0f,0f,0f,0f,0f,-17.963465f,41.96647f,-69.53331f,1280.0f,-428.0f,-589.0f,-558,-0.6441404f,0.5703256f,-0.19043463f,0f,0f,0f ) ;
  }

  @Test
  public void test249() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-63.906204f,0f,0f,0f,0f,0f,-52.126514f,-80.86436f,-86.06944f,0f,0f,0f,-460,-60.735394f,66.66281f,-58.812714f,0f,0f,0f ) ;
  }

  @Test
  public void test250() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,64.533424f,0f,0f,0f,0f,0f,30.45958f,49.56929f,80.72176f,232.0f,-408.0f,163.0f,-267,-98.60761f,94.86637f,80.83763f,0f,0f,0f ) ;
  }

  @Test
  public void test251() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,64.6242f,0f,0f,0f,0f,0f,100.0f,-18.427446f,32.60691f,262.0f,334.0f,170.0f,1549,-0.033691045f,-0.11467966f,0.99283105f,0f,0f,0f ) ;
  }

  @Test
  public void test252() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,69.79272f,0f,0f,0f,0f,0f,-68.89014f,66.89385f,84.525f,818.0f,1719.0f,496.0f,701,-0.26017258f,0.62962174f,-0.58462554f,0f,0f,0f ) ;
  }

  @Test
  public void test253() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,72.12174f,0f,0f,0f,0f,0f,-22.962727f,-30.560505f,-3.010022f,323.0f,-236.0f,-68.0f,1270,-0.80747104f,0.25182888f,-0.53345364f,0f,0f,0f ) ;
  }

  @Test
  public void test254() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,72.463615f,0f,0f,0f,0f,0f,-87.96866f,40.55433f,-66.07249f,-287.0f,295.0f,-178.0f,-677,53.974228f,71.333f,-28.077927f,0f,0f,0f ) ;
  }

  @Test
  public void test255() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,74.46396f,0f,0f,0f,0f,0f,25.491135f,-66.99422f,-19.350813f,331.0f,-101.0f,876.0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test256() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,75.80577f,0f,0f,0f,0f,0f,-2.9852264f,5.6976376f,-24.177662f,-234.0f,-513.0f,-92.0f,-955,-0.40414223f,0.4311951f,-0.55768627f,0f,0f,0f ) ;
  }

  @Test
  public void test257() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,81.338f,0f,0f,0f,0f,0f,34.65406f,-65.73084f,-51.544357f,193.0f,604.0f,-627.0f,-860,72.080635f,74.67324f,-54.84718f,0f,0f,0f ) ;
  }

  @Test
  public void test258() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,81.78778f,0f,0f,0f,0f,0f,100.0f,-36.632515f,-100.0f,0f,0f,0f,-1517,0.9961434f,-0.062568605f,-0.06151037f,0f,0f,0f ) ;
  }

  @Test
  public void test259() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,81.92918f,0f,0f,0f,0f,0f,33.681286f,-73.150024f,-35.997837f,-600.0f,-707.0f,-782.0f,169,10.552134f,-31.74961f,-30.480103f,0f,0f,0f ) ;
  }

  @Test
  public void test260() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,82.55682f,0f,0f,0f,0f,0f,27.27806f,26.600304f,49.69997f,458.0f,756.0f,-656.0f,171,51.71989f,46.16886f,-53.088783f,0f,0f,0f ) ;
  }

  @Test
  public void test261() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,83.734535f,0f,0f,0f,0f,0f,-87.38406f,-61.22574f,93.49321f,-177.0f,613.0f,236.0f,-904,30.29953f,-88.778854f,68.2594f,0f,0f,0f ) ;
  }

  @Test
  public void test262() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,84.7306f,0f,0f,0f,0f,0f,-4.5200896f,11.018677f,8.250171f,-806.0f,505.0f,-644.0f,-1204,53.805073f,-16.081472f,50.95656f,0f,0f,0f ) ;
  }

  @Test
  public void test263() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,85.1855f,0f,0f,0f,0f,0f,-84.056114f,-94.67055f,-45.3171f,-286.0f,-531.0f,95.0f,897,45.035507f,-35.95122f,-55.357803f,0f,0f,0f ) ;
  }

  @Test
  public void test264() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,88.874405f,0f,0f,0f,0f,0f,-30.32459f,-51.209652f,59.96996f,-259.0f,782.0f,667.0f,751,-0.31707162f,-25.674854f,-22.084646f,0f,0f,0f ) ;
  }

  @Test
  public void test265() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,89.86723f,0f,0f,0f,0f,0f,100.0f,-44.367794f,55.631668f,0f,0f,0f,1,-1.480511f,-0.3864664f,0.5002057f,0f,0f,0f ) ;
  }

  @Test
  public void test266() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,91.92758f,0f,0f,0f,0f,0f,-100.0f,100.0f,100.0f,-349.0f,-706.0f,1412.0f,-1353,-0.70167387f,0.6381463f,-0.31689608f,0f,0f,0f ) ;
  }

  @Test
  public void test267() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,92.1501f,0f,0f,0f,0f,0f,-98.16934f,-4.762554f,97.96065f,-129.0f,35.0f,-52.0f,-527,-93.85293f,-51.17337f,44.77153f,0f,0f,0f ) ;
  }

  @Test
  public void test268() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,92.76061f,0f,0f,0f,0f,0f,-68.86972f,70.507774f,33.642647f,-779.0f,-858.0f,346.0f,311,44.757282f,27.845528f,36.010654f,0f,0f,0f ) ;
  }

  @Test
  public void test269() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,94.90928f,0f,0f,0f,0f,0f,-0.12964402f,-9.378766f,28.17183f,-713.0f,917.0f,302.0f,753,0.25641692f,-0.35828915f,0.76528823f,0f,0f,0f ) ;
  }

  @Test
  public void test270() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,9.535369f,0f,0f,0f,0f,0f,-51.326782f,66.59534f,55.493294f,-158.0f,-513.0f,502.0f,-923,-95.367744f,-15.26707f,-69.88599f,0f,0f,0f ) ;
  }

  @Test
  public void test271() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,97.68152f,0f,0f,0f,0f,0f,-100.0f,100.0f,100.0f,0f,0f,0f,788,-0.46669316f,-0.5198306f,0.053313714f,0f,0f,0f ) ;
  }

  @Test
  public void test272() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,97.965294f,0f,0f,0f,0f,0f,74.93149f,-100.0f,12.481231f,1184.0f,-871.0f,18.0f,-1129,0.40072292f,0.2726794f,-0.22103804f,0f,0f,0f ) ;
  }

  @Test
  public void test273() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-99.993675f,0f,0f,0f,0f,0f,-40.70607f,-22.554686f,41.700245f,0f,0f,0f,1,-0.547567f,0.8366666f,0.01262386f,0f,0f,0f ) ;
  }

  @Test
  public void test274() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,0f,0f,-21.00282f,-28.582506f,100.0f,-1289.0f,98.0f,534.0f,-3,-0.3664825f,-0.7339091f,-0.5718686f,0f,0f,0f ) ;
  }

  @Test
  public void test275() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,0f,0f,98.61739f,-7.6964445f,75.5369f,-668.0f,2776.0f,-883.0f,5,-0.3705706f,0.038350116f,-0.92801225f,0f,0f,0f ) ;
  }

  @Test
  public void test276() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,149.25914f,0f,0f,0f,0f,0f,0f,0f,-30.617157f,20.572979f,87.52845f,0f,0f,0f,1,0.20634744f,0.7400347f,-0.6401323f,0f,0f,0f ) ;
  }

  @Test
  public void test277() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,24.590393f,0f,0f,0f,0f,0f,0f,0f,23.810976f,-4.116703f,9.886693f,306.0f,682.0f,-430.0f,2,-0.33530113f,-0.90049875f,0.27690285f,0f,0f,0f ) ;
  }

  @Test
  public void test278() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,-97.32072f,0f,0f,0f,0f,0f,0f,0f,90.903114f,-100.0f,-100.0f,0f,0f,0f,2,0.016445683f,0.8960437f,0.44366118f,0f,0f,0f ) ;
  }

  @Test
  public void test279() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,-9.8196555E-15f,0f,0f,0f,0f,0f,0f,0f,-27.964487f,75.18981f,32.66626f,388.0f,-26.0f,392.0f,11,0.27126285f,1.4403608f,2.3146043f,0f,0f,0f ) ;
  }

  @Test
  public void test280() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.000015f,0.0f,0f,-25.250349f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.83959717f,0.29758748f,-0.36294696f,0f,0f,0f ) ;
  }

  @Test
  public void test281() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,100.0f,-83.934616f,0f,0f,0f,638,0.41885728f,-0.54275775f,0.7279922f,0f,0f,0f ) ;
  }

  @Test
  public void test282() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0.0f,0f,100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.24087732f,0.45920312f,0.27504793f,0f,0f,0f ) ;
  }

  @Test
  public void test283() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,100.0f,-100.0f,89.89996f,0f,0f,0f,156,-100.0f,100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test284() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,100.0f,91.9667f,-100.0f,0f,0f,0f,305,0.20009f,0.24567246f,0.9484772f,0f,0f,0f ) ;
  }

  @Test
  public void test285() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0.0f,0f,-1.6127453f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.49347126f,-0.5203589f,0.14285496f,0f,0f,0f ) ;
  }

  @Test
  public void test286() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0.0f,0f,2.7209542f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.8537257f,0.36005497f,-0.31108564f,0f,0f,0f ) ;
  }

  @Test
  public void test287() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0.0f,0f,45.106796f,0f,0f,0f,0f,0f,-98.552635f,-56.15658f,72.50778f,0f,0f,0f,1048,0.04985327f,0.14233814f,0.1780001f,0f,0f,0f ) ;
  }

  @Test
  public void test288() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0.0f,0f,-68.40603f,0f,0f,0f,0f,0f,100.0f,100.0f,-60.664066f,0f,0f,0f,-891,-0.9241746f,0.13045314f,-0.35900325f,0f,0f,0f ) ;
  }

  @Test
  public void test289() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.666056f,0.2499239f,-0.050888635f,0f,0f,0f ) ;
  }

  @Test
  public void test290() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0f,0f,20.371769f,0f,0f,0f,0f,0f,-9.458563f,-64.51979f,-60.245148f,-795.0f,-1141.0f,-585.0f,2,0.9218796f,-0.35832307f,0.1088396f,0f,0f,0f ) ;
  }

  @Test
  public void test291() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0f,0f,28.459587f,0f,0f,0f,0f,0f,56.065243f,-0.1537193f,-23.125233f,290.0f,614.0f,699.0f,2,-0.52581257f,0.25806397f,-0.11264952f,0f,0f,0f ) ;
  }

  @Test
  public void test292() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.42542422f,0.27159926f,-0.851336f,0f,0f,0f ) ;
  }

  @Test
  public void test293() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,75.79019f,5.1128635f,495.0f,755.0f,111.0f,3,0.14204206f,0.9442337f,0.16932087f,0f,0f,0f ) ;
  }

  @Test
  public void test294() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,10.160817f,-38.408207f,11.32304f,1092.0f,61.0f,-631.0f,-2,-1.2836162f,0.6693902f,3.3473544f,0f,0f,0f ) ;
  }

  @Test
  public void test295() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,22.22505f,46.671543f,85.703384f,-788.0f,888.0f,914.0f,1,0.1692191f,1.4742856f,0.11434834f,0f,0f,0f ) ;
  }

  @Test
  public void test296() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-16.267128f,0f,0.0f,0f,0f,0f,0f,0f,-93.19587f,100.0f,-71.59394f,0f,0f,0f,-65,0.35516012f,-0.7816916f,0.4264101f,0f,0f,0f ) ;
  }

  @Test
  public void test297() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,-17.272964f,0f,0f,0f,0f,0f,0f,0f,1.3162385f,12.715345f,39.854824f,-401.0f,706.0f,-212.0f,1597,0.93045235f,-0.3590192f,0.073205635f,0f,0f,0f ) ;
  }

  @Test
  public void test298() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,17.539717f,0f,0f,0f,0f,0f,0f,0f,-86.70574f,100.0f,-34.26914f,1088.0f,-1307.0f,70.0f,660,0.10782308f,-0.13019085f,-0.65269905f,0f,0f,0f ) ;
  }

  @Test
  public void test299() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-24.79414f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0.52401435f,-0.79106617f,-0.26197794f,0f,0f,0f ) ;
  }

  @Test
  public void test300() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-30.284708f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-16.709118f,-49.604664f,0f,0f,0f,-1217,0.03433597f,0.8169608f,-0.3401224f,0f,0f,0f ) ;
  }

  @Test
  public void test301() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-35.146168f,0f,-15.000429f,0f,0f,0f,0f,0f,34.267635f,26.00598f,45.903805f,0f,0f,0f,1161,-0.7805358f,-0.61761016f,0.09654832f,0f,0f,0f ) ;
  }

  @Test
  public void test302() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,-41.163944f,0f,0f,0f,0f,0f,0f,0f,48.239864f,99.88903f,100.0f,1378.0f,618.0f,1156.0f,886,0.62526256f,-0.7802274f,0.01708357f,0f,0f,0f ) ;
  }

  @Test
  public void test303() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,-42.658382f,0f,0.0f,0f,0f,0f,0f,0f,-0.74805295f,24.611784f,-6.104414f,0f,0f,0f,-509,0.093622126f,-0.6340963f,-0.7675655f,0f,0f,0f ) ;
  }

  @Test
  public void test304() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,55.957355f,0f,0f,0f,0f,0f,0f,0f,52.819725f,72.72857f,-5.447151f,302.0f,391.0f,-1380.0f,2,-1.8444358f,-1.5963126f,-0.255765f,0f,0f,0f ) ;
  }

  @Test
  public void test305() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,6.1716914f,0f,0f,0f,0f,0f,0f,0f,-82.66873f,11.211415f,-100.0f,0f,0f,0f,-1728,-0.5205438f,-0.7319735f,0.43960086f,0f,0f,0f ) ;
  }

  @Test
  public void test306() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,-63.407787f,0f,0f,0f,0f,0f,0f,0f,43.61099f,83.74877f,-100.0f,0f,0f,0f,569,-0.7941187f,-0.3212108f,-0.5159449f,0f,0f,0f ) ;
  }

  @Test
  public void test307() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,-63.961708f,0f,-1.9869149f,0f,0f,0f,0f,0f,100.0f,17.306717f,-52.159016f,0f,0f,0f,426,-0.16404927f,0.92882544f,0.33222148f,0f,0f,0f ) ;
  }

  @Test
  public void test308() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,-64.02166f,0f,-27.053488f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.113906115f,-0.24112318f,-0.37294254f,0f,0f,0f ) ;
  }

  @Test
  public void test309() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-68.1979f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.42717952f,0.009708802f,0.71383303f,0f,0f,0f ) ;
  }

  @Test
  public void test310() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,8.149366f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.03858584f,-0.42345014f,0.26453456f,0f,0f,0f ) ;
  }

  @Test
  public void test311() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-91.53272f,0f,0f,0f,0f,0f,0f,0f,-4.0317335f,100.0f,100.0f,0f,0f,0f,754,-0.10247552f,-0.8999201f,-0.42384258f,0f,0f,0f ) ;
  }

  @Test
  public void test312() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,99.04559f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.02846209f,-0.0644549f,0.43056026f,0f,0f,0f ) ;
  }

  @Test
  public void test313() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-99.78392f,0f,0.0f,0f,0f,0f,0f,0f,-99.78619f,99.98149f,-100.0f,0f,0f,0f,-438,0.59759307f,-0.5664612f,-0.56745416f,0f,0f,0f ) ;
  }

  @Test
  public void test314() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1005.0f,1517.0f,3.0f,247.0f,0f,0f,0f,0f,0f,-858.0f,-1651.0f,-1592.0f,-90.0f,-1064.0f,391.0f,403,-0.5450689f,0.7206333f,-0.0023063489f,0f,-16.853075f,0f ) ;
  }

  @Test
  public void test315() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-10.0f,1462.0f,0f,254.0f,0f,0f,0f,0f,0f,-274.0f,-788.0f,205.0f,1313.0f,-712.0f,682.0f,213,-100.0f,60.67116f,99.5555f,0f,0f,0f ) ;
  }

  @Test
  public void test316() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1012.0f,-290.0f,0f,1291.0f,0f,0f,0f,0f,0f,2236.0f,389.0f,-313.0f,-1.0f,-403.0f,-508.0f,-800,-100.0f,-20.554867f,74.663475f,0f,0f,0f ) ;
  }

  @Test
  public void test317() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1012.0f,-9.0f,0f,101.0f,0f,0f,0f,0f,0f,-13.0f,-5.0f,-59.0f,-2122.0f,-1359.0f,607.0f,18,-1.6264042f,4.329541f,2.0592372f,0f,0f,0f ) ;
  }

  @Test
  public void test318() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-102.0f,612.0f,0f,631.0f,0f,0f,0f,0f,0f,-28.0f,1393.0f,-42.0f,1044.0f,9.0f,-398.0f,-300,0.07795995f,-0.052432097f,0.4362195f,0f,0f,0f ) ;
  }

  @Test
  public void test319() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1028.0f,814.0f,0f,710.0f,0f,0f,0f,0f,0f,-808.0f,-369.0f,-699.0f,221.0f,-642.0f,-607.0f,971,-15.016215f,6.717205f,13.811831f,0f,0f,0f ) ;
  }

  @Test
  public void test320() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1033.0f,-249.0f,0f,1469.0f,0f,0f,0f,0f,0f,379.0f,-440.0f,-786.0f,-621.0f,531.0f,-597.0f,-929,96.76597f,-27.899372f,94.87214f,0f,0f,0f ) ;
  }

  @Test
  public void test321() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1037.0f,1339.0f,0f,923.0f,0f,0f,0f,0f,0f,-926.0f,-190.0f,-2446.0f,-1047.0f,-609.0f,-1706.0f,-707,0.13764398f,-0.85657895f,0.2975542f,0f,0f,0f ) ;
  }

  @Test
  public void test322() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1049.0f,-730.0f,0f,1034.0f,0f,0f,0f,0f,0f,-625.0f,103.0f,-64.0f,-144.0f,-345.0f,818.0f,-212,4.1280465f,-0.40783954f,-1.3309007f,0f,0f,0f ) ;
  }

  @Test
  public void test323() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0515615f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.025392445f,-0.04975011f,-0.061535493f,0f,0f,0f ) ;
  }

  @Test
  public void test324() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1068.0f,760.0f,-338.0f,690.0f,0f,0f,0f,0f,0f,1519.0f,-1577.0f,-617.0f,-126.0f,-1836.0f,529.0f,1520,-0.7258838f,0.07260532f,0.2763093f,100.0f,0f,0f ) ;
  }

  @Test
  public void test325() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-106.88597f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.17913222f,0.43397728f,0.19671972f,0f,0f,0f ) ;
  }

  @Test
  public void test326() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1070.0f,833.0f,0f,432.0f,0f,0f,0f,0f,0f,269.0f,-169.0f,-124.0f,578.0f,867.0f,74.0f,-174,0.24399523f,-0.251069f,0.871495f,0f,0f,0f ) ;
  }

  @Test
  public void test327() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-107.434586f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.008569333f,-0.12592348f,-0.05545479f,0f,0f,0f ) ;
  }

  @Test
  public void test328() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1087.0f,-1542.0f,0f,332.0f,0f,0f,0f,0f,0f,-149.0f,-621.0f,-58.0f,-35.0f,114.0f,-1131.0f,-1017,100.0f,112.33842f,91.960655f,0f,0f,0f ) ;
  }

  @Test
  public void test329() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,0.0f,0f,703.0f,0f,0f,0f,0f,0f,-99.0f,-2026.0f,685.0f,173.0f,1571.0f,1129.0f,-963,87.22576f,168.28555f,-34.84625f,0f,0f,0f ) ;
  }

  @Test
  public void test330() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,1842.0f,-46.0f,-393.0f,0f,0f,0f,0f,0f,939.0f,45.0f,-2400.0f,-2543.0f,-873.0f,-1082.0f,19,-0.9704304f,-0.09668226f,-0.20146419f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test331() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,227.0f,0f,2.0f,0f,0f,0f,0f,0f,892.0f,507.0f,-985.0f,287.0f,-1496.0f,-627.0f,-620,80.3988f,-65.45296f,47.034103f,0f,0f,0f ) ;
  }

  @Test
  public void test332() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,-305.0f,0f,738.0f,0f,0f,0f,0f,0f,1238.0f,-899.0f,180.0f,574.0f,-280.0f,623.0f,-363,0.0556141f,0.67717355f,0.54688585f,0f,0f,0f ) ;
  }

  @Test
  public void test333() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,31.0f,0f,-116.0f,0f,0f,0f,0f,0f,58.0f,-568.0f,256.0f,-349.0f,-748.0f,-797.0f,771,95.6926f,29.401234f,43.55312f,0f,0f,0f ) ;
  }

  @Test
  public void test334() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,39.0f,0f,-1023.0f,0f,0f,0f,0f,0f,970.0f,-359.0f,535.0f,706.0f,-54.0f,202.0f,1143,-86.854836f,-99.83062f,90.485954f,0f,0f,0f ) ;
  }

  @Test
  public void test335() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,4.0f,0f,1062.0f,0f,0f,0f,0f,0f,10.0f,855.0f,104.0f,-821.0f,92.0f,-679.0f,-1394,-109.78797f,-57.38855f,169.89273f,0f,0f,0f ) ;
  }

  @Test
  public void test336() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,448.0f,0f,178.0f,0f,0f,0f,0f,0f,-957.0f,-857.0f,436.0f,-772.0f,-719.0f,-560.0f,-975,156.48247f,15.550038f,-97.782326f,0f,0f,0f ) ;
  }

  @Test
  public void test337() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,-452.0f,0f,184.0f,0f,0f,0f,0f,0f,914.0f,-447.0f,284.0f,-406.0f,-1145.0f,-477.0f,-453,-0.73495615f,-1.0003375f,0.79084194f,0f,0f,0f ) ;
  }

  @Test
  public void test338() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,487.0f,0f,1377.0f,0f,0f,0f,0f,0f,159.0f,-855.0f,470.0f,-1217.0f,-1463.0f,-1141.0f,659,0.0038873204f,0.4177885f,0.089303695f,0f,0f,0f ) ;
  }

  @Test
  public void test339() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,576.0f,-370.0f,-131.0f,0f,0f,0f,0f,0f,1762.0f,-1189.0f,272.0f,768.0f,386.0f,479.0f,-484,-18.382967f,23.715073f,-92.454094f,94.1026f,-98.79764f,0f ) ;
  }

  @Test
  public void test340() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,730.0f,-438.0f,-399.0f,0f,0f,0f,0f,0f,-98.0f,905.0f,-678.0f,-880.0f,-377.0f,-477.0f,-624,66.399826f,2.9168925f,19.49219f,9.606192f,69.738716f,0f ) ;
  }

  @Test
  public void test341() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,-79.0f,0f,270.0f,0f,0f,0f,0f,0f,63.0f,60.0f,-1216.0f,-801.0f,-134.0f,525.0f,865,-30.397398f,-80.67607f,96.70813f,0f,0f,0f ) ;
  }

  @Test
  public void test342() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-110.0f,-2.0f,0f,259.0f,0f,0f,0f,0f,0f,531.0f,-858.0f,296.0f,-849.0f,-61.0f,-985.0f,220,92.58775f,133.11661f,-14.379593f,0f,0f,0f ) ;
  }

  @Test
  public void test343() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-110.0f,940.0f,0f,4.0f,0f,0f,0f,0f,0f,1485.0f,-460.0f,-772.0f,-425.0f,413.0f,-467.0f,-227,-100.0f,62.87049f,-68.94566f,0f,0f,0f ) ;
  }

  @Test
  public void test344() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1101.0f,457.0f,0f,-2.0f,0f,0f,0f,0f,0f,180.0f,-948.0f,340.0f,109.0f,-1735.0f,297.0f,-288,-23.342794f,55.432175f,-14.529117f,0f,0f,0f ) ;
  }

  @Test
  public void test345() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-11.039601f,-97.03424f,0f,-42.29634f,0f,0f,0f,0f,0f,34.429844f,-75.18558f,97.009315f,0f,0f,0f,-743,50.764652f,99.25906f,-42.53409f,0f,0f,0f ) ;
  }

  @Test
  public void test346() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1105.0f,-2394.0f,0f,301.0f,0f,0f,0f,0f,0f,1031.0f,-588.0f,-60.0f,-34.0f,-34.0f,-251.0f,-766,22.301737f,55.544613f,-53.53954f,0f,0f,0f ) ;
  }

  @Test
  public void test347() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1106.0f,1362.0f,0f,240.0f,0f,0f,0f,0f,0f,-892.0f,151.0f,-766.0f,315.0f,1728.0f,-91.0f,22,-25.7428f,-28.686417f,24.322828f,0f,0f,0f ) ;
  }

  @Test
  public void test348() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1109.0f,-914.0f,0f,730.0f,0f,0f,0f,0f,0f,-563.0f,670.0f,-732.0f,-529.0f,2733.0f,-348.0f,823,0.31634983f,0.34833103f,0.6902923f,0f,0f,0f ) ;
  }

  @Test
  public void test349() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1112.0f,208.0f,0f,1700.0f,0f,0f,0f,0f,0f,-37.0f,-597.0f,-71.0f,988.0f,-48.0f,-112.0f,883,-9.633744f,100.0f,25.158075f,0f,0f,0f ) ;
  }

  @Test
  public void test350() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1116.0f,149.0f,0f,546.0f,0f,0f,0f,0f,0f,23.0f,203.0f,1412.0f,747.0f,-286.0f,29.0f,1254,153.4031f,110.72766f,-18.420094f,0f,0f,0f ) ;
  }

  @Test
  public void test351() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,11.485944f,35.882694f,0f,0f,0f,0f,0f,0f,0f,14.816341f,72.55772f,50.02115f,-541.0f,122.0f,35.0f,-1045,-0.09214238f,-0.48793173f,0.723562f,0f,0f,0f ) ;
  }

  @Test
  public void test352() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-115.0f,-808.0f,0f,461.0f,0f,0f,0f,0f,0f,1.0f,31.0f,-716.0f,-219.0f,-142.0f,-423.0f,192,54.424515f,-34.784714f,50.5692f,0f,0f,0f ) ;
  }

  @Test
  public void test353() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1160.0f,-2.0f,0f,185.0f,0f,0f,0f,0f,0f,-1005.0f,-927.0f,-820.0f,-452.0f,-582.0f,1214.0f,-3527,0.74314433f,2.7010374f,0.114840105f,0f,0f,0f ) ;
  }

  @Test
  public void test354() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1176.0f,1736.0f,0f,-547.0f,0f,0f,0f,0f,0f,-2297.0f,-859.0f,-719.0f,175.0f,-919.0f,746.0f,-1,2.1162605f,-0.08452376f,-0.0036994603f,0f,0f,0f ) ;
  }

  @Test
  public void test355() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1177.0f,1627.0f,0f,524.0f,0f,0f,0f,0f,0f,169.0f,-139.0f,343.0f,-1208.0f,484.0f,792.0f,-672,81.58512f,-48.830177f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test356() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1178.0f,1027.0f,0f,255.0f,0f,0f,0f,0f,0f,152.0f,1213.0f,-344.0f,-1166.0f,369.0f,148.0f,-559,27.22367f,-10.602058f,-25.35552f,0f,0f,0f ) ;
  }

  @Test
  public void test357() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1181.0f,616.0f,0f,112.0f,0f,0f,0f,0f,0f,-37.0f,-72.0f,-357.0f,915.0f,682.0f,-234.0f,1277,-43.265827f,-64.46596f,17.491089f,0f,0f,0f ) ;
  }

  @Test
  public void test358() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1183.0f,-1.0f,0f,416.0f,0f,0f,0f,0f,0f,229.0f,436.0f,-127.0f,1252.0f,-867.0f,-721.0f,-647,102.423386f,-80.983986f,66.76395f,0f,0f,0f ) ;
  }

  @Test
  public void test359() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,11.85523f,-12.474243f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,-28.98102f,0f,0f,0f,-975,-0.34717944f,0.41178194f,-0.15677789f,0f,0f,0f ) ;
  }

  @Test
  public void test360() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1202.0f,372.0f,0f,129.0f,0f,0f,0f,0f,0f,-22.0f,358.0f,202.0f,215.0f,-180.0f,366.0f,1537,-0.1883631f,-0.8377795f,0.3277863f,0f,0f,0f ) ;
  }

  @Test
  public void test361() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,12.174979f,0.0f,0f,-65.859116f,0f,0f,0f,0f,0f,-92.42064f,-100.0f,86.8643f,0f,0f,0f,1633,-0.72935516f,0.087862775f,-0.6748594f,0f,0f,0f ) ;
  }

  @Test
  public void test362() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.2189583f,-35.405552f,0f,0f,0f,0f,0f,0f,0f,-44.452015f,-1.5016066f,-76.62185f,191.0f,-1155.0f,-88.0f,-474,-0.6131161f,-0.4427602f,0.65428644f,0f,0f,0f ) ;
  }

  @Test
  public void test363() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-122.0f,-1304.0f,0f,740.0f,0f,0f,0f,0f,0f,-351.0f,-104.0f,-66.0f,-1551.0f,-540.0f,-1360.0f,-179,-0.21851832f,0.49905488f,0.37573063f,0f,0f,0f ) ;
  }

  @Test
  public void test364() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.2280626E-32f,-3.5954474E-17f,0f,100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,3,-0.9465887f,-0.3451072f,0.052216668f,0f,0f,0f ) ;
  }

  @Test
  public void test365() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,123.0f,849.0f,0f,-351.0f,0f,0f,0f,0f,0f,-374.0f,986.0f,764.0f,439.0f,-145.0f,598.0f,-761,-93.22683f,-24.663696f,-16.87611f,0f,0f,0f ) ;
  }

  @Test
  public void test366() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,124.0f,32.0f,240.0f,-492.0f,0f,0f,0f,0f,0f,859.0f,-13.0f,619.0f,-675.0f,-482.0f,597.0f,-927,20.710121f,12.466262f,-60.14595f,55.960983f,0f,0f ) ;
  }

  @Test
  public void test367() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-125.0f,-15.0f,0f,983.0f,0f,0f,0f,0f,0f,533.0f,809.0f,150.0f,-939.0f,401.0f,1299.0f,3,-6.379881f,9.152754f,-0.43938965f,0f,0f,0f ) ;
  }

  @Test
  public void test368() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-126.713135f,-93.753876f,0f,14.767862f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.21376218f,0.18693607f,-0.21686743f,0f,0f,0f ) ;
  }

  @Test
  public void test369() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1271.0f,191.0f,0f,260.0f,0f,0f,0f,0f,0f,412.0f,-670.0f,-295.0f,-276.0f,-222.0f,113.0f,1317,73.88574f,56.92237f,-26.09174f,0f,0f,0f ) ;
  }

  @Test
  public void test370() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1273.0f,-597.0f,0f,789.0f,0f,0f,0f,0f,0f,640.0f,-1735.0f,643.0f,1036.0f,-1450.0f,-621.0f,-2,0.37188464f,-0.14509232f,-0.6287361f,0f,0f,0f ) ;
  }

  @Test
  public void test371() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1275.0f,878.0f,0f,1068.0f,0f,0f,0f,0f,0f,142.0f,-478.0f,98.0f,-1223.0f,-401.0f,-188.0f,236,0.66811514f,0.18950804f,-0.043750126f,0f,0f,0f ) ;
  }

  @Test
  public void test372() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1279.0f,1648.0f,0f,709.0f,0f,0f,0f,0f,0f,-354.0f,146.0f,-356.0f,-398.0f,-991.0f,-11.0f,-242,0.380208f,0.27973956f,-0.085568085f,0f,0f,0f ) ;
  }

  @Test
  public void test373() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,12.957124f,98.91231f,0f,0f,0f,0f,0f,0f,0f,74.35082f,-58.89138f,100.0f,-640.0f,779.0f,-613.0f,6,0.04326452f,-0.80484354f,-0.3492836f,0f,0f,0f ) ;
  }

  @Test
  public void test374() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-130.0f,-1555.0f,0f,667.0f,0f,0f,0f,0f,0f,228.0f,-1746.0f,-101.0f,1219.0f,-602.0f,-1569.0f,-954,-0.32136452f,0.46636093f,-0.5217776f,0f,0f,0f ) ;
  }

  @Test
  public void test375() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-130.0f,-418.0f,0f,481.0f,0f,0f,0f,0f,0f,909.0f,-838.0f,859.0f,-629.0f,-354.0f,820.0f,31,-53.677925f,28.707563f,9.742969f,0f,0f,0f ) ;
  }

  @Test
  public void test376() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1306.0f,-121.0f,0f,202.0f,0f,0f,0f,0f,0f,1350.0f,-1057.0f,809.0f,-792.0f,182.0f,-688.0f,-995,-0.08131857f,-0.19854635f,-0.708773f,0f,0f,0f ) ;
  }

  @Test
  public void test377() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1324.0f,-1104.0f,0f,672.0f,0f,0f,0f,0f,0f,200.0f,1170.0f,398.0f,161.0f,930.0f,-554.0f,6,-0.9585091f,1.350243f,2.412327f,0f,0f,0f ) ;
  }

  @Test
  public void test378() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1338.0f,2.0f,0f,919.0f,0f,0f,0f,0f,0f,131.0f,-867.0f,2373.0f,416.0f,-174.0f,931.0f,-583,-0.37727445f,0.64003414f,-0.40472835f,0f,0f,0f ) ;
  }

  @Test
  public void test379() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1340.0f,-1178.0f,0f,173.0f,0f,0f,0f,0f,0f,-974.0f,-1203.0f,826.0f,722.0f,-365.0f,774.0f,216,0.1288972f,-0.31735477f,-0.69010824f,0f,0f,0f ) ;
  }

  @Test
  public void test380() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1341.0f,-1036.0f,0f,2263.0f,0f,0f,0f,0f,0f,-183.0f,-2213.0f,365.0f,246.0f,-306.0f,732.0f,1459,0.03043263f,0.7739776f,-0.23867714f,0f,0f,0f ) ;
  }

  @Test
  public void test381() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1346.0f,345.0f,0f,1046.0f,0f,0f,0f,0f,0f,-182.0f,-177.0f,-533.0f,638.0f,-233.0f,-142.0f,482,-22.670933f,47.719727f,-8.090755f,0f,0f,0f ) ;
  }

  @Test
  public void test382() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1348.0f,-1130.0f,0f,125.0f,0f,0f,0f,0f,0f,-738.0f,703.0f,97.0f,717.0f,798.0f,-328.0f,101,0.5870831f,0.6322101f,-0.13879597f,0f,0f,0f ) ;
  }

  @Test
  public void test383() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,13.562897f,-99.74442f,0f,99.999985f,0f,0f,0f,0f,0f,-99.16271f,-30.769577f,99.99997f,0f,0f,0f,-152,0.78093463f,0.6197732f,-0.07760353f,0f,0f,0f ) ;
  }

  @Test
  public void test384() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1357.0f,-1244.0f,0f,2148.0f,0f,0f,0f,0f,0f,-314.0f,174.0f,215.0f,-1274.0f,-178.0f,-1713.0f,-2,-5.160311f,-0.8562245f,0.81399137f,0f,0f,0f ) ;
  }

  @Test
  public void test385() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-137.0f,-93.0f,0f,494.0f,0f,0f,0f,0f,0f,-761.0f,243.0f,1872.0f,-417.0f,590.0f,175.0f,421,0.63595164f,0.14553945f,-0.75788116f,0f,0f,0f ) ;
  }

  @Test
  public void test386() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1376.0f,7.0f,0f,486.0f,0f,0f,0f,0f,0f,1082.0f,41.0f,-16.0f,50.0f,-689.0f,1514.0f,308,-4.549492f,100.0f,-50.72216f,0f,0f,0f ) ;
  }

  @Test
  public void test387() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.3938416E-22f,0.0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-100.0f,100.0f,0f,0f,0f,-414,0.015811054f,0.82045007f,0.57150275f,0f,0f,0f ) ;
  }

  @Test
  public void test388() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-140.0f,102.0f,0f,251.0f,0f,0f,0f,0f,0f,-243.0f,868.0f,-584.0f,-368.0f,86.0f,127.0f,-823,-9.409546f,-22.556246f,-29.610086f,0f,0f,0f ) ;
  }

  @Test
  public void test389() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1417.0f,2.0f,0f,1569.0f,0f,0f,0f,0f,0f,-427.0f,1647.0f,1386.0f,739.0f,-781.0f,-925.0f,24,-1.5034361f,0.68458503f,1.337931f,0f,0f,0f ) ;
  }

  @Test
  public void test390() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1421.0f,826.0f,790.0f,895.0f,0f,0f,0f,0f,0f,-104.0f,-227.0f,-275.0f,-90.0f,-377.0f,617.0f,75,-16.732319f,100.0f,-76.2176f,-100.0f,48.477688f,0f ) ;
  }

  @Test
  public void test391() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1424.0f,921.0f,-846.0f,446.0f,0f,0f,0f,0f,0f,-742.0f,891.0f,185.0f,271.0f,-694.0f,1626.0f,882,66.18687f,51.094444f,19.381123f,14.638376f,0f,0f ) ;
  }

  @Test
  public void test392() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1427.0f,-1327.0f,0f,1507.0f,0f,0f,0f,0f,0f,131.0f,-357.0f,-422.0f,173.0f,-96.0f,134.0f,-632,-0.49293634f,0.27608716f,0.45834446f,0f,0f,0f ) ;
  }

  @Test
  public void test393() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1439.0f,475.0f,0f,1567.0f,0f,0f,0f,0f,0f,1954.0f,1975.0f,208.0f,-1052.0f,-553.0f,-2659.0f,4,0.053762227f,-0.6763231f,-0.1069123f,0f,0f,0f ) ;
  }

  @Test
  public void test394() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1453.0f,2476.0f,0f,680.0f,0f,0f,0f,0f,0f,-869.0f,-47.0f,-416.0f,217.0f,-1232.0f,-323.0f,296,-0.31181303f,0.57345617f,0.58688307f,0f,0f,0f ) ;
  }

  @Test
  public void test395() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-147.0f,-405.0f,0f,486.0f,0f,0f,0f,0f,0f,613.0f,-870.0f,-1040.0f,1157.0f,-424.0f,-749.0f,1327,0.16921905f,0.19554254f,-0.040726073f,0f,0f,0f ) ;
  }

  @Test
  public void test396() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.4773984f,44.28622f,0f,0f,0f,0f,0f,0f,0f,8.867853f,24.105593f,28.118235f,0f,0f,0f,-388,-0.12017319f,-0.53859895f,0.1413013f,0f,0f,0f ) ;
  }

  @Test
  public void test397() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.4874074f,0f,0f,0f,0f,0f,0f,0f,0f,-18.372805f,100.0f,-16.104485f,0f,0f,0f,144,0.28385207f,-0.50138843f,-0.12173409f,0f,0f,0f ) ;
  }

  @Test
  public void test398() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1488.0f,2191.0f,0f,1850.0f,0f,0f,0f,0f,0f,-1288.0f,-263.0f,1063.0f,109.0f,185.0f,178.0f,-140,0.16572209f,0.20639472f,0.2518644f,0f,0f,0f ) ;
  }

  @Test
  public void test399() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-149.21812f,-123.423256f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.62547404f,-0.3509688f,-0.41662177f,0f,0f,0f ) ;
  }

  @Test
  public void test400() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,150.0f,1413.0f,0f,198.0f,0f,0f,0f,0f,0f,641.0f,233.0f,-309.0f,325.0f,191.0f,817.0f,-216,-53.264893f,100.0f,-34.974377f,0f,0f,0f ) ;
  }

  @Test
  public void test401() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-150.87024f,163.54633f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.05649125f,-0.7335053f,0.22515562f,0f,0f,0f ) ;
  }

  @Test
  public void test402() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-15.0f,825.0f,690.0f,-212.0f,0f,0f,0f,0f,0f,36.0f,-811.0f,250.0f,-599.0f,-609.0f,819.0f,131,24.117151f,90.73877f,49.686058f,-31.495567f,0f,0f ) ;
  }

  @Test
  public void test403() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1529.0f,1584.0f,0f,1.0f,0f,0f,0f,0f,0f,-1297.0f,557.0f,-1058.0f,-589.0f,-2277.0f,691.0f,2862,-0.31647173f,-0.6065638f,0.068628f,0f,0f,0f ) ;
  }

  @Test
  public void test404() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1545.0f,420.0f,0f,894.0f,0f,0f,0f,0f,0f,642.0f,-1642.0f,-45.0f,1534.0f,-725.0f,736.0f,-873,0.07544384f,0.23590638f,-0.8734089f,0f,0f,0f ) ;
  }

  @Test
  public void test405() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1581.0f,-3031.0f,0f,1590.0f,0f,0f,0f,0f,0f,160.0f,979.0f,-911.0f,-1644.0f,-894.0f,-281.0f,4,0.15163396f,-0.10743061f,1.2847978f,0f,0f,0f ) ;
  }

  @Test
  public void test406() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-159.0f,-2053.0f,0f,209.0f,0f,0f,0f,0f,0f,-275.0f,-716.0f,-508.0f,-2543.0f,283.0f,-787.0f,-258,0.31081903f,0.24903499f,-0.5192604f,0f,0f,0f ) ;
  }

  @Test
  public void test407() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-15.986528f,13.082983f,0f,0f,0f,0f,0f,0f,0f,-44.444344f,29.16555f,54.10374f,25.0f,14.0f,-726.0f,33,-64.849724f,-98.072845f,-19.766743f,0f,0f,0f ) ;
  }

  @Test
  public void test408() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1625.0f,1112.0f,0f,862.0f,0f,0f,0f,0f,0f,257.0f,1215.0f,938.0f,515.0f,21.0f,-595.0f,-1993,-0.056794617f,-0.6043812f,-0.21044098f,0f,0f,0f ) ;
  }

  @Test
  public void test409() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1628.0f,849.0f,-547.0f,284.0f,0f,0f,0f,0f,0f,112.0f,-1122.0f,789.0f,-962.0f,-1359.0f,-945.0f,-492,0.43850258f,0.81952673f,0.3495926f,38.707302f,0f,0f ) ;
  }

  @Test
  public void test410() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,163.0f,997.0f,0f,1705.0f,0f,0f,0f,0f,0f,996.0f,-586.0f,348.0f,499.0f,-229.0f,-14.0f,719,0.59264994f,5.842747f,8.142444f,0f,0f,0f ) ;
  }

  @Test
  public void test411() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1634.0f,2021.0f,0f,251.0f,0f,0f,0f,0f,0f,-275.0f,-261.0f,-195.0f,-412.0f,-17.0f,73.0f,-978,95.4121f,-55.36572f,-60.45021f,0f,0f,0f ) ;
  }

  @Test
  public void test412() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1644.0f,-1698.0f,0f,259.0f,0f,0f,0f,0f,0f,1348.0f,107.0f,726.0f,1173.0f,-1121.0f,-956.0f,663,-0.7077033f,-0.3058907f,-0.20896831f,0f,0f,0f ) ;
  }

  @Test
  public void test413() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1655.0f,-358.0f,0f,1520.0f,0f,0f,0f,0f,0f,802.0f,56.0f,-73.0f,-10.0f,-265.0f,-313.0f,470,-0.18539074f,0.94224507f,0.57300425f,0f,0f,0f ) ;
  }

  @Test
  public void test414() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1656.0f,-1.0f,0f,1482.0f,0f,0f,0f,0f,0f,-312.0f,190.0f,532.0f,202.0f,62.0f,40.0f,199,2.582833f,1.8068997f,0.17144297f,0f,0f,0f ) ;
  }

  @Test
  public void test415() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1664.0f,-580.0f,0f,162.0f,0f,0f,0f,0f,0f,199.0f,-122.0f,369.0f,49.0f,-525.0f,-200.0f,-204,-69.98011f,139.86139f,-181.59097f,0f,0f,0f ) ;
  }

  @Test
  public void test416() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-166.73744f,-76.91461f,0f,54.0424f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.15891838f,0.094354644f,-0.556664f,0f,0f,0f ) ;
  }

  @Test
  public void test417() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1688.0f,-1175.0f,0f,1651.0f,0f,0f,0f,0f,0f,346.0f,8.0f,354.0f,-71.0f,-423.0f,79.0f,483,-79.092575f,34.968296f,-66.48861f,0f,0f,0f ) ;
  }

  @Test
  public void test418() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1702.0f,1564.0f,0f,277.0f,0f,0f,0f,0f,0f,-77.0f,1063.0f,-157.0f,-1107.0f,-81.0f,-6.0f,72,0.6110912f,-0.34846857f,0.4306302f,0f,0f,0f ) ;
  }

  @Test
  public void test419() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-173.0f,688.0f,724.0f,739.0f,0f,0f,0f,0f,0f,494.0f,963.0f,1000.0f,-48.0f,-916.0f,-20.0f,197,-50.953175f,27.187548f,-83.94957f,-55.464497f,34.413246f,0f ) ;
  }

  @Test
  public void test420() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,179.0f,1200.0f,0f,74.0f,0f,0f,0f,0f,0f,-6.0f,-605.0f,649.0f,-112.0f,651.0f,606.0f,-690,-31.030556f,36.857822f,-96.33003f,0f,0f,0f ) ;
  }

  @Test
  public void test421() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1792.0f,952.0f,0f,1257.0f,0f,0f,0f,0f,0f,-1119.0f,311.0f,-932.0f,1308.0f,-729.0f,398.0f,-1856,-0.26744273f,-0.24138139f,0.68914217f,0f,0f,0f ) ;
  }

  @Test
  public void test422() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,182.0f,-459.0f,0f,170.0f,0f,0f,0f,0f,0f,-145.0f,193.0f,363.0f,89.0f,233.0f,-88.0f,451,17.140575f,-35.287f,15.537776f,0f,0f,0f ) ;
  }

  @Test
  public void test423() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,18.258709f,0.0f,0f,-47.771572f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.21793371f,-0.32398483f,0.5420559f,0f,0f,0f ) ;
  }

  @Test
  public void test424() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.829802f,-100.0f,0f,0f,0f,0f,0f,0f,0f,67.308235f,-99.958595f,25.516556f,826.0f,-532.0f,464.0f,-457,-0.95909864f,-0.20327467f,0.19700043f,0f,0f,0f ) ;
  }

  @Test
  public void test425() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-184.0f,-3638.0f,0f,1597.0f,0f,0f,0f,0f,0f,-418.0f,556.0f,-169.0f,-317.0f,181.0f,1355.0f,655,0.17416018f,-0.27676272f,-1.3412961f,0f,0f,0f ) ;
  }

  @Test
  public void test426() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1854.0f,-1568.0f,0f,253.0f,0f,0f,0f,0f,0f,-627.0f,-374.0f,742.0f,92.0f,-69.0f,96.0f,-783,19.175209f,-21.983568f,-83.4572f,0f,0f,0f ) ;
  }

  @Test
  public void test427() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,186.0f,-464.0f,0f,952.0f,0f,0f,0f,0f,0f,-439.0f,158.0f,-234.0f,44.0f,112.0f,984.0f,411,61.490505f,-67.18018f,-6.31623f,0f,0f,0f ) ;
  }

  @Test
  public void test428() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,189.0f,792.0f,0f,601.0f,0f,0f,0f,0f,0f,-347.0f,-127.0f,103.0f,-479.0f,740.0f,208.0f,-618,5.5865755f,-68.93517f,-74.52859f,0f,0f,0f ) ;
  }

  @Test
  public void test429() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,19.0f,1124.0f,0f,153.0f,0f,0f,0f,0f,0f,461.0f,-333.0f,681.0f,661.0f,870.0f,-22.0f,-996,-82.24973f,100.0f,34.174374f,0f,0f,0f ) ;
  }

  @Test
  public void test430() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-19.597387f,0.0f,0f,0f,0f,0f,0f,0f,0f,-5.236229f,-21.971918f,0.74485576f,0f,0f,0f,-497,0.6591628f,0.15584876f,-0.038641226f,0f,0f,0f ) ;
  }

  @Test
  public void test431() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,19.75272f,0.0f,0f,-55.234833f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.2593575f,0.17665154f,-0.17274341f,0f,0f,0f ) ;
  }

  @Test
  public void test432() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-198.0f,-2179.0f,0f,254.0f,0f,0f,0f,0f,0f,2026.0f,-571.0f,-1598.0f,984.0f,-2131.0f,727.0f,-634,0.20232019f,-0.206128f,0.93605065f,0f,0f,0f ) ;
  }

  @Test
  public void test433() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,19.901941f,2.2448506f,0f,0f,0f,0f,0f,0f,0f,-5.7765193f,7.6057086f,5.1215935f,333.0f,-210.0f,1200.0f,7,-0.65353197f,0.3751376f,-1.3660756f,0f,0f,0f ) ;
  }

  @Test
  public void test434() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-199.0f,876.0f,0f,254.0f,0f,0f,0f,0f,0f,181.0f,186.0f,-167.0f,-275.0f,-89.0f,-1735.0f,-466,100.0f,-86.89601f,11.601745f,0f,0f,0f ) ;
  }

  @Test
  public void test435() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2025.0f,1215.0f,1404.0f,-155.0f,0f,0f,0f,0f,0f,482.0f,681.0f,-182.0f,380.0f,892.0f,518.0f,915,-0.7954279f,0.33537608f,-0.11874048f,31.227121f,0f,0f ) ;
  }

  @Test
  public void test436() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2037.0f,388.0f,0f,985.0f,0f,0f,0f,0f,0f,1418.0f,-988.0f,1198.0f,-3103.0f,486.0f,-1192.0f,1558,-0.49915162f,0.17008099f,0.7310826f,0f,0f,0f ) ;
  }

  @Test
  public void test437() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-207.0f,-301.0f,0f,688.0f,0f,0f,0f,0f,0f,889.0f,-393.0f,-305.0f,893.0f,888.0f,914.0f,-316,-86.02632f,12.289881f,-28.845917f,0f,0f,0f ) ;
  }

  @Test
  public void test438() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2099.0f,3.0f,0f,3159.0f,0f,0f,0f,0f,0f,-1512.0f,1006.0f,531.0f,1158.0f,-44.0f,827.0f,5,-1.392071f,0.14965077f,-0.42248246f,0f,0f,0f ) ;
  }

  @Test
  public void test439() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,0.0f,0f,22.0f,0f,0f,0f,0f,0f,-1188.0f,872.0f,498.0f,-74.0f,-779.0f,32.0f,1145,0.59868866f,0.14664079f,0.018778335f,0f,0f,0f ) ;
  }

  @Test
  public void test440() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,1090.0f,0f,7.0f,0f,0f,0f,0f,0f,818.0f,24.0f,606.0f,1915.0f,1497.0f,856.0f,534,0.7433021f,-5.514753f,-0.6262011f,0f,0f,0f ) ;
  }

  @Test
  public void test441() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,-1.0f,0f,2520.0f,0f,0f,0f,0f,0f,533.0f,-415.0f,-221.0f,-508.0f,-744.0f,182.0f,525,-100.0f,37.33503f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test442() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,-1.0f,0f,785.0f,0f,0f,0f,0f,0f,2631.0f,836.0f,565.0f,-928.0f,-1188.0f,520.0f,-48,-57.19646f,46.626488f,80.92625f,0f,0f,0f ) ;
  }

  @Test
  public void test443() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,-1216.0f,0f,495.0f,0f,0f,0f,0f,0f,181.0f,19.0f,303.0f,-275.0f,-500.0f,197.0f,239,1.1503508f,-0.63832104f,-1.5826528f,0f,0f,0f ) ;
  }

  @Test
  public void test444() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,-1221.0f,0f,2149.0f,0f,0f,0f,0f,0f,-1080.0f,-225.0f,13.0f,-135.0f,746.0f,-205.0f,226,-0.03033291f,0.9620931f,-0.2710291f,0f,0f,0f ) ;
  }

  @Test
  public void test445() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,227.0f,-460.0f,-312.0f,0f,0f,0f,0f,0f,43.0f,-484.0f,811.0f,533.0f,-3016.0f,-1475.0f,-40,56.079468f,95.94824f,1.4240652f,-57.976223f,0f,0f ) ;
  }

  @Test
  public void test446() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,-247.0f,0f,151.0f,0f,0f,0f,0f,0f,-516.0f,-1183.0f,853.0f,-883.0f,425.0f,15.0f,-991,1.5787561f,-0.9799967f,-1.124703f,0f,0f,0f ) ;
  }

  @Test
  public void test447() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,509.0f,0f,-83.0f,0f,0f,0f,0f,0f,1999.0f,565.0f,1085.0f,-793.0f,65.0f,133.0f,456,-34.244267f,-254.66269f,-48.611263f,0f,0f,0f ) ;
  }

  @Test
  public void test448() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,54.0f,0f,241.0f,0f,0f,0f,0f,0f,35.0f,-649.0f,763.0f,-1485.0f,-826.0f,1501.0f,-3583,99.608955f,81.51981f,64.770676f,0f,0f,0f ) ;
  }

  @Test
  public void test449() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,734.0f,0f,608.0f,0f,0f,0f,0f,0f,200.0f,170.0f,-303.0f,-1846.0f,-77.0f,1841.0f,-770,-0.71032774f,0.18987031f,0.57080954f,0f,0f,0f ) ;
  }

  @Test
  public void test450() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,-750.0f,0f,2517.0f,0f,0f,0f,0f,0f,1530.0f,-1731.0f,-1500.0f,-1793.0f,-24.0f,431.0f,-110,0.6276096f,0.7690178f,-0.09342278f,0f,0f,0f ) ;
  }

  @Test
  public void test451() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,-806.0f,0f,1481.0f,0f,0f,0f,0f,0f,276.0f,-821.0f,-367.0f,1344.0f,643.0f,-429.0f,-296,137.4933f,49.706f,48.464752f,0f,0f,0f ) ;
  }

  @Test
  public void test452() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-214.0f,-201.0f,0f,255.0f,0f,0f,0f,0f,0f,209.0f,-125.0f,-287.0f,596.0f,-356.0f,-644.0f,-122,-82.488106f,91.64216f,-65.879616f,0f,0f,0f ) ;
  }

  @Test
  public void test453() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-216.0f,2.0f,0f,2053.0f,0f,0f,0f,0f,0f,384.0f,-110.0f,-164.0f,362.0f,688.0f,385.0f,509,-100.0f,44.130844f,-103.506424f,0f,0f,0f ) ;
  }

  @Test
  public void test454() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-216.0f,-307.0f,489.0f,187.0f,0f,0f,0f,0f,0f,716.0f,995.0f,-414.0f,-527.0f,-952.0f,317.0f,-406,30.258797f,13.287094f,-69.27497f,-7.7823863f,0f,0f ) ;
  }

  @Test
  public void test455() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2187.0f,1049.0f,-795.0f,-1.0f,0f,0f,0f,0f,0f,146.0f,1048.0f,-1330.0f,-1379.0f,765.0f,-451.0f,2056,79.03349f,35.69178f,100.0f,55.79799f,0f,0f ) ;
  }

  @Test
  public void test456() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,219.0f,311.0f,0f,1303.0f,0f,0f,0f,0f,0f,-913.0f,-288.0f,418.0f,449.0f,-131.0f,891.0f,-446,29.801348f,-23.965494f,-90.33471f,0f,0f,0f ) ;
  }

  @Test
  public void test457() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-221.0f,884.0f,-902.0f,67.0f,0f,0f,0f,0f,0f,-478.0f,-297.0f,343.0f,-820.0f,-510.0f,122.0f,733,-41.75163f,8.605782f,-88.67709f,0f,53.022846f,0f ) ;
  }

  @Test
  public void test458() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,222.0f,505.0f,0f,0.0f,0f,0f,0f,0f,0f,-1666.0f,471.0f,921.0f,-1364.0f,56.0f,128.0f,-664,0.25726062f,0.60605f,-0.0823148f,0f,0f,0f ) ;
  }

  @Test
  public void test459() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-223.0f,261.0f,0f,81.0f,0f,0f,0f,0f,0f,634.0f,-934.0f,-746.0f,858.0f,466.0f,112.0f,-606,-65.01686f,84.486496f,93.639626f,0f,0f,0f ) ;
  }

  @Test
  public void test460() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2238.0f,-601.0f,0f,251.0f,0f,0f,0f,0f,0f,-2771.0f,-12.0f,1356.0f,-957.0f,888.0f,729.0f,305,-0.041723687f,0.12789795f,-0.3070333f,0f,0f,0f ) ;
  }

  @Test
  public void test461() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2242.0f,-1546.0f,0f,255.0f,0f,0f,0f,0f,0f,1908.0f,-1311.0f,-1217.0f,-195.0f,168.0f,-1660.0f,335,-0.2544639f,0.59547293f,-0.56625503f,0f,0f,0f ) ;
  }

  @Test
  public void test462() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-225.0f,-2.0f,0f,1035.0f,0f,0f,0f,0f,0f,543.0f,-806.0f,-309.0f,1213.0f,710.0f,273.0f,-846,-0.56208587f,0.43035057f,1.5816171f,0f,0f,0f ) ;
  }

  @Test
  public void test463() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-228.0f,1015.0f,101.0f,1372.0f,0f,0f,0f,0f,0f,-686.0f,-2202.0f,674.0f,-1137.0f,434.0f,2334.0f,-468,0.33686832f,0.38583118f,-0.12105315f,0f,0f,-93.73359f ) ;
  }

  @Test
  public void test464() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2291.0f,1750.0f,0f,-3.0f,0f,0f,0f,0f,0f,45.0f,555.0f,-373.0f,140.0f,1777.0f,1163.0f,1497,0.46880028f,0.19327337f,0.75840706f,0f,0f,0f ) ;
  }

  @Test
  public void test465() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2309.0f,1582.0f,0f,397.0f,0f,0f,0f,0f,0f,-336.0f,-868.0f,86.0f,218.0f,-1555.0f,-157.0f,-740,-0.15756118f,0.7680492f,-0.4561397f,0f,0f,0f ) ;
  }

  @Test
  public void test466() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-232.0f,408.0f,-335.0f,331.0f,0f,0f,0f,0f,0f,638.0f,360.0f,-58.0f,497.0f,775.0f,309.0f,674,-85.08563f,-32.50849f,-28.357975f,-90.19662f,0f,0f ) ;
  }

  @Test
  public void test467() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-23.321938f,-70.233086f,0f,-17.603615f,0f,0f,0f,0f,0f,26.836985f,41.19318f,59.476307f,0f,0f,0f,866,-0.057144444f,-0.64607286f,0.47325367f,0f,0f,0f ) ;
  }

  @Test
  public void test468() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,23.524464f,-6.512247f,0f,-1.3877788E-17f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,1.8300108f,0.06598844f,-1.3188852f,0f,0f,0f ) ;
  }

  @Test
  public void test469() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2357.0f,344.0f,0f,741.0f,0f,0f,0f,0f,0f,-155.0f,43.0f,-156.0f,-376.0f,758.0f,572.0f,-587,-44.31695f,100.0f,71.67807f,0f,0f,0f ) ;
  }

  @Test
  public void test470() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-238.0f,951.0f,0f,332.0f,0f,0f,0f,0f,0f,-1055.0f,1409.0f,933.0f,-966.0f,-684.0f,95.0f,-2128,0.3239102f,2.002341f,-2.6576347f,0f,0f,0f ) ;
  }

  @Test
  public void test471() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-23.848911f,0.0016042823f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.69009787f,0.27355063f,0.18096375f,0f,0f,0f ) ;
  }

  @Test
  public void test472() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-240.0f,912.0f,152.0f,-410.0f,0f,0f,0f,0f,0f,831.0f,-584.0f,494.0f,206.0f,786.0f,331.0f,-514,71.95701f,-8.691577f,-99.173195f,97.09074f,0f,0f ) ;
  }

  @Test
  public void test473() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2407.0f,628.0f,0f,-4.0f,0f,0f,0f,0f,0f,961.0f,795.0f,-895.0f,1325.0f,-1152.0f,964.0f,-1,-0.10166127f,-5.208725f,-0.45898208f,0f,0f,0f ) ;
  }

  @Test
  public void test474() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,241.0f,184.0f,741.0f,-128.0f,0f,0f,0f,0f,0f,-556.0f,-96.0f,369.0f,4.0f,-356.0f,-969.0f,153,-76.22038f,-12.927796f,42.27122f,-91.78862f,-15.276539f,0f ) ;
  }

  @Test
  public void test475() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-241.0f,-808.0f,0f,254.0f,0f,0f,0f,0f,0f,-1025.0f,684.0f,-131.0f,175.0f,1198.0f,-294.0f,4,-0.30094272f,-0.66606516f,-0.8250185f,0f,0f,0f ) ;
  }

  @Test
  public void test476() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2456.0f,1845.0f,0f,2937.0f,0f,0f,0f,0f,0f,176.0f,77.0f,61.0f,-966.0f,1376.0f,952.0f,524,-2.864327f,-0.24595802f,3.221906f,0f,0f,0f ) ;
  }

  @Test
  public void test477() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-247.0f,5.0f,0f,2041.0f,0f,0f,0f,0f,0f,732.0f,726.0f,88.0f,-380.0f,632.0f,-291.0f,870,-0.5253518f,-0.8046223f,-0.27674627f,0f,0f,0f ) ;
  }

  @Test
  public void test478() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,247.0f,666.0f,0f,827.0f,0f,0f,0f,0f,0f,216.0f,-74.0f,97.0f,237.0f,-157.0f,-628.0f,-340,-36.37766f,24.924105f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test479() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-250.0f,31.0f,0f,1083.0f,0f,0f,0f,0f,0f,-77.0f,-498.0f,-1899.0f,-148.0f,-508.0f,-1917.0f,-1336,-0.605551f,0.7739608f,0.13179465f,0f,0f,0f ) ;
  }

  @Test
  public void test480() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-251.0f,450.0f,0f,-110.0f,0f,0f,0f,0f,0f,-401.0f,-402.0f,-693.0f,-208.0f,225.0f,-386.0f,589,-2.9270222f,54.45137f,65.76221f,0f,0f,0f ) ;
  }

  @Test
  public void test481() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,25.741096f,0.0f,0f,-69.90109f,0f,0f,0f,0f,0f,31.742174f,0.25421283f,4.6486607f,0f,0f,0f,77,-14.068729f,16.9427f,46.011116f,0f,0f,0f ) ;
  }

  @Test
  public void test482() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-259.0f,1011.0f,-1212.0f,1476.0f,0f,0f,0f,0f,0f,-517.0f,-1459.0f,502.0f,230.0f,-648.0f,863.0f,-540,-0.34045526f,0.7660966f,-0.39381012f,-47.993496f,0f,0f ) ;
  }

  @Test
  public void test483() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-259.0f,782.0f,-23.0f,-604.0f,0f,0f,0f,0f,0f,-526.0f,494.0f,600.0f,-895.0f,713.0f,-960.0f,625,87.12761f,42.487385f,-51.284878f,20.731977f,4.693703f,-36.90001f ) ;
  }

  @Test
  public void test484() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-261.0f,577.0f,0f,751.0f,0f,0f,0f,0f,0f,-39.0f,864.0f,188.0f,-841.0f,166.0f,959.0f,227,-47.608696f,-23.200027f,86.63652f,0f,0f,0f ) ;
  }

  @Test
  public void test485() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,262.0f,-77.0f,844.0f,923.0f,0f,0f,0f,0f,0f,545.0f,-728.0f,132.0f,838.0f,688.0f,837.0f,370,87.78519f,80.78828f,12.505392f,0f,0f,29.400078f ) ;
  }

  @Test
  public void test486() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2625.0f,490.0f,-1374.0f,-524.0f,0f,0f,0f,0f,0f,205.0f,360.0f,-311.0f,-197.0f,614.0f,-774.0f,-224,0.23140913f,0.049649328f,0.5089861f,-41.129093f,63.66336f,40.10169f ) ;
  }

  @Test
  public void test487() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-263.0f,82.0f,0f,854.0f,0f,0f,0f,0f,0f,-748.0f,-392.0f,-303.0f,-666.0f,-244.0f,-831.0f,168,72.16572f,63.625732f,57.54937f,0f,0f,0f ) ;
  }

  @Test
  public void test488() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,265.0f,-714.0f,794.0f,462.0f,0f,0f,0f,0f,0f,708.0f,391.0f,-332.0f,-147.0f,481.0f,760.0f,-35,31.270369f,-25.445402f,72.671326f,-28.332376f,-0.88423246f,0f ) ;
  }

  @Test
  public void test489() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2655.0f,-958.0f,0f,1918.0f,0f,0f,0f,0f,0f,272.0f,82.0f,-1716.0f,-24.0f,-1264.0f,-1580.0f,-1719,0.08915473f,0.96890783f,0.2308008f,0f,0f,0f ) ;
  }

  @Test
  public void test490() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-266.0f,1181.0f,0f,2031.0f,0f,0f,0f,0f,0f,868.0f,-2.0f,-1182.0f,538.0f,-388.0f,-800.0f,-997,-0.59327805f,-0.771679f,-0.07398917f,0f,0f,0f ) ;
  }

  @Test
  public void test491() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-26.688677f,100.0f,0f,0f,0f,0f,0f,0f,0f,-8.692041f,-43.340214f,-18.304565f,-257.0f,-974.0f,-941.0f,6,0.37370938f,0.60168f,0.55154294f,0f,0f,0f ) ;
  }

  @Test
  public void test492() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-27.0f,7.0f,0f,1601.0f,0f,0f,0f,0f,0f,-1648.0f,-1372.0f,772.0f,-103.0f,-1261.0f,-713.0f,3,-3.25852f,-0.9396878f,3.7992435f,0f,0f,0f ) ;
  }

  @Test
  public void test493() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-274.0f,320.0f,-128.0f,-181.0f,0f,0f,0f,0f,0f,-980.0f,-384.0f,-117.0f,-751.0f,-194.0f,743.0f,382,2.0652745f,-4.4853773f,50.195446f,99.7618f,0f,0f ) ;
  }

  @Test
  public void test494() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-276.0f,1248.0f,0f,259.0f,0f,0f,0f,0f,0f,-776.0f,-934.0f,381.0f,-368.0f,175.0f,-270.0f,-720,74.43419f,-21.050243f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test495() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,27.850233f,-21.192896f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.091364674f,-0.82147056f,0.44624645f,0f,0f,0f ) ;
  }

  @Test
  public void test496() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-285.0f,-235.0f,0f,355.0f,0f,0f,0f,0f,0f,-109.0f,190.0f,-2.0f,500.0f,752.0f,190.0f,914,82.60851f,-81.33686f,-55.070084f,0f,0f,0f ) ;
  }

  @Test
  public void test497() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,28.664991f,-16.892664f,0f,3.4116433f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.76265824f,0.17772189f,-0.054526165f,0f,0f,0f ) ;
  }

  @Test
  public void test498() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-292.0f,176.0f,0f,1093.0f,0f,0f,0f,0f,0f,-762.0f,38.0f,-277.0f,249.0f,-384.0f,-738.0f,-540,0.07865389f,0.5466376f,0.4364072f,0f,0f,0f ) ;
  }

  @Test
  public void test499() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,293.0f,34.0f,0f,1076.0f,0f,0f,0f,0f,0f,-627.0f,614.0f,-848.0f,37.0f,813.0f,561.0f,-13,34.062428f,-61.47586f,40.88259f,0f,0f,0f ) ;
  }

  @Test
  public void test500() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,296.0f,-5.0f,88.0f,991.0f,0f,0f,0f,0f,0f,-563.0f,-352.0f,319.0f,183.0f,377.0f,-226.0f,-868,92.113625f,48.9519f,-50.798992f,-41.86134f,0f,0f ) ;
  }

  @Test
  public void test501() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-29.675226f,0.0f,0f,21.944681f,0f,0f,0f,0f,0f,-39.709557f,28.499784f,-7.99955f,0f,0f,0f,-742,24.108793f,-17.767595f,1.9978949f,0f,0f,0f ) ;
  }

  @Test
  public void test502() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2994.0f,-843.0f,0f,429.0f,0f,0f,0f,0f,0f,-858.0f,859.0f,-456.0f,474.0f,-732.0f,910.0f,2,0.8745852f,-3.547119f,0.44582024f,0f,0f,0f ) ;
  }

  @Test
  public void test503() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,300.0f,124.0f,182.0f,392.0f,0f,0f,0f,0f,0f,575.0f,505.0f,88.0f,-268.0f,-844.0f,-632.0f,-7,-61.191353f,-26.962132f,55.800514f,98.14309f,-94.97283f,0f ) ;
  }

  @Test
  public void test504() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-302.0f,987.0f,0f,1266.0f,0f,0f,0f,0f,0f,734.0f,586.0f,-870.0f,103.0f,608.0f,-358.0f,44,-32.575714f,-63.0295f,-69.93777f,0f,0f,0f ) ;
  }

  @Test
  public void test505() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,3047.0f,-1.0f,0f,815.0f,0f,0f,0f,0f,0f,-183.0f,947.0f,940.0f,-166.0f,1715.0f,291.0f,46,0.19804482f,2.3411476E-5f,-0.9801722f,0f,0f,0f ) ;
  }

  @Test
  public void test506() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-306.0f,1561.0f,0f,-1423.0f,0f,0f,0f,0f,0f,-260.0f,-500.0f,-1547.0f,-1327.0f,-1038.0f,-316.0f,-370,-0.4529647f,-0.31332386f,0.3043685f,0f,0f,0f ) ;
  }

  @Test
  public void test507() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3099.0f,2.0f,0f,486.0f,0f,0f,0f,0f,0f,-378.0f,328.0f,-920.0f,2154.0f,61.0f,-466.0f,7,-3.5777087f,11.058277f,0.32937473f,0f,0f,0f ) ;
  }

  @Test
  public void test508() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,3.0f,2.0f,0f,410.0f,0f,0f,0f,0f,0f,540.0f,-1200.0f,-835.0f,1101.0f,975.0f,-889.0f,-2090,0.11284952f,0.40480596f,-0.503336f,0f,0f,0f ) ;
  }

  @Test
  public void test509() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,310.0f,3.0f,0f,807.0f,0f,0f,0f,0f,0f,-92.0f,-143.0f,17.0f,-750.0f,809.0f,2699.0f,298,-0.26613772f,-0.033953667f,-1.7258849f,0f,0f,0f ) ;
  }

  @Test
  public void test510() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,315.0f,1684.0f,0f,1087.0f,0f,0f,0f,0f,0f,721.0f,189.0f,-888.0f,-375.0f,-446.0f,-399.0f,955,-0.54234445f,-0.7295694f,-0.5944214f,0f,0f,0f ) ;
  }

  @Test
  public void test511() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-31.64712f,0.0f,0f,6.938894E-18f,0f,0f,0f,0f,0f,100.0f,99.87455f,-100.0f,0f,0f,0f,-573,-0.74619424f,-0.64753854f,-0.15455744f,0f,0f,0f ) ;
  }

  @Test
  public void test512() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3165.0f,-1305.0f,0f,941.0f,0f,0f,0f,0f,0f,-283.0f,-384.0f,-761.0f,1013.0f,-1069.0f,-852.0f,1780,0.538862f,-0.577247f,0.56459796f,0f,0f,0f ) ;
  }

  @Test
  public void test513() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-317.0f,-141.0f,0f,248.0f,0f,0f,0f,0f,0f,-877.0f,-1090.0f,-540.0f,-1572.0f,-1026.0f,-1305.0f,750,62.69952f,109.55671f,-8.990089f,0f,0f,0f ) ;
  }

  @Test
  public void test514() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,317.0f,43.0f,0f,2275.0f,0f,0f,0f,0f,0f,-208.0f,-50.0f,102.0f,-576.0f,1714.0f,-335.0f,-496,0.3928028f,-0.29061356f,-0.48437762f,0f,0f,0f ) ;
  }

  @Test
  public void test515() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-319.0f,487.0f,0f,251.0f,0f,0f,0f,0f,0f,-431.0f,30.0f,-934.0f,-1215.0f,1432.0f,-1260.0f,-655,97.07812f,-100.0f,-48.00928f,0f,0f,0f ) ;
  }

  @Test
  public void test516() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-324.0f,999.0f,0f,284.0f,0f,0f,0f,0f,0f,107.0f,-617.0f,-330.0f,72.0f,766.0f,207.0f,-926,-90.06082f,-4.7841845f,-1.5986981f,0f,0f,0f ) ;
  }

  @Test
  public void test517() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-326.0f,565.0f,-1361.0f,-1287.0f,0f,0f,0f,0f,0f,2427.0f,541.0f,-565.0f,965.0f,-331.0f,-520.0f,730,-0.88563985f,0.016388992f,0.15187743f,-7.2520146f,51.061836f,0f ) ;
  }

  @Test
  public void test518() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-32.779453f,100.0f,0f,0f,0f,0f,0f,0f,0f,2.694882f,-48.470222f,83.56468f,821.0f,361.0f,3.0f,-207,49.489746f,-2.267486f,-2.927054f,0f,0f,0f ) ;
  }

  @Test
  public void test519() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-329.0f,490.0f,-66.0f,-403.0f,0f,0f,0f,0f,0f,-1690.0f,-882.0f,-1031.0f,-162.0f,-791.0f,-841.0f,-1380,-0.024724754f,0.00778069f,0.4988895f,88.06042f,30.84783f,0f ) ;
  }

  @Test
  public void test520() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,334.0f,0.0f,0f,1278.0f,0f,0f,0f,0f,0f,49.0f,459.0f,71.0f,-673.0f,296.0f,383.0f,832,13.223225f,-88.962715f,145.43073f,0f,0f,0f ) ;
  }

  @Test
  public void test521() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,33.420452f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.1772803f,-0.60098535f,-0.37548986f,0f,0f,0f ) ;
  }

  @Test
  public void test522() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,33.838795f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.2631297f,-0.057870597f,-0.20077136f,0f,0f,0f ) ;
  }

  @Test
  public void test523() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-33.905865f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.2943832f,0.2181647f,0.537964f,0f,0f,0f ) ;
  }

  @Test
  public void test524() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-348.0f,1.0f,0f,159.0f,0f,0f,0f,0f,0f,-452.0f,220.0f,316.0f,-513.0f,936.0f,-858.0f,272,96.30962f,53.152805f,-72.54531f,0f,0f,0f ) ;
  }

  @Test
  public void test525() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,348.0f,-2392.0f,0f,1528.0f,0f,0f,0f,0f,0f,-458.0f,-1007.0f,-1408.0f,-152.0f,528.0f,-329.0f,1142,0.3904598f,2.5342503f,-0.22802994f,0f,0f,0f ) ;
  }

  @Test
  public void test526() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,349.0f,485.0f,0f,-826.0f,0f,0f,0f,0f,0f,702.0f,-558.0f,-697.0f,-607.0f,51.0f,245.0f,-721,34.860718f,-4.9989905f,45.34916f,0f,0f,0f ) ;
  }

  @Test
  public void test527() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,3498.0f,1198.0f,0f,272.0f,0f,0f,0f,0f,0f,-485.0f,452.0f,-663.0f,337.0f,532.0f,116.0f,735,38.29836f,-29.790735f,-48.267937f,0f,0f,0f ) ;
  }

  @Test
  public void test528() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,34.986553f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-64.55804f,-100.0f,15.475601f,0f,0f,0f,1145,-0.05840149f,0.2657142f,-0.7372663f,0f,0f,0f ) ;
  }

  @Test
  public void test529() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,35.151924f,-57.42318f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.1567813f,-0.5540951f,0.052147247f,0f,0f,0f ) ;
  }

  @Test
  public void test530() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-353.0f,468.0f,0f,776.0f,0f,0f,0f,0f,0f,-250.0f,-980.0f,-929.0f,-628.0f,-406.0f,596.0f,-129,-2.327171f,-67.17881f,85.03546f,0f,0f,0f ) ;
  }

  @Test
  public void test531() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,3577.0f,-4.0f,0f,1805.0f,0f,0f,0f,0f,0f,-842.0f,535.0f,-1475.0f,-1071.0f,-915.0f,-1833.0f,-1,1.2947056f,-0.4709351f,0.41102335f,0f,0f,0f ) ;
  }

  @Test
  public void test532() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3585.0f,-1007.0f,0f,55.0f,0f,0f,0f,0f,0f,-698.0f,-1223.0f,608.0f,106.0f,-998.0f,-940.0f,62,0.8523495f,-0.032583382f,0.5200695f,0f,0f,0f ) ;
  }

  @Test
  public void test533() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-359.0f,-572.0f,0f,254.0f,0f,0f,0f,0f,0f,31.0f,10.0f,553.0f,-1612.0f,1144.0f,891.0f,290,43.158382f,-73.15485f,-6.418845f,0f,0f,0f ) ;
  }

  @Test
  public void test534() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-362.0f,968.0f,0f,728.0f,0f,0f,0f,0f,0f,-613.0f,119.0f,556.0f,430.0f,-564.0f,-41.0f,-862,-100.0f,-100.0f,-88.84892f,0f,0f,0f ) ;
  }

  @Test
  public void test535() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,364.0f,45.0f,0f,-2.0f,0f,0f,0f,0f,0f,335.0f,-799.0f,232.0f,-497.0f,-26.0f,-781.0f,-352,-0.49293792f,55.768757f,57.044937f,0f,0f,0f ) ;
  }

  @Test
  public void test536() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,365.0f,-2453.0f,0f,833.0f,0f,0f,0f,0f,0f,628.0f,-1694.0f,1011.0f,385.0f,422.0f,-1658.0f,284,0.09862267f,-0.011758594f,-0.1813779f,0f,0f,0f ) ;
  }

  @Test
  public void test537() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,369.0f,-1185.0f,0f,1553.0f,0f,0f,0f,0f,0f,3108.0f,31.0f,-868.0f,1911.0f,451.0f,-105.0f,17,-0.015740685f,0.4833507f,-0.14934362f,0f,0f,0f ) ;
  }

  @Test
  public void test538() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,375.0f,-1005.0f,0f,957.0f,0f,0f,0f,0f,0f,-473.0f,-564.0f,-1921.0f,-682.0f,570.0f,87.0f,15,1.5157924f,0.5273914f,1.7539427f,0f,0f,0f ) ;
  }

  @Test
  public void test539() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,37.776146f,-100.0f,0f,0.0f,0f,0f,0f,0f,0f,70.72983f,46.672253f,26.34962f,0f,0f,0f,233,-0.6750555f,0.18972456f,-0.66272265f,0f,0f,0f ) ;
  }

  @Test
  public void test540() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,379.0f,637.0f,706.0f,864.0f,0f,0f,0f,0f,0f,182.0f,-718.0f,773.0f,-175.0f,-828.0f,-178.0f,793,29.468424f,70.37344f,-65.302765f,71.867966f,-13.754231f,-59.455013f ) ;
  }

  @Test
  public void test541() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,38.571766f,-43.20392f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,3,0.10151287f,-0.03769596f,-0.87968f,0f,0f,0f ) ;
  }

  @Test
  public void test542() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-387.0f,-989.0f,0f,109.0f,0f,0f,0f,0f,0f,1052.0f,-243.0f,-1372.0f,-470.0f,2922.0f,-1998.0f,-97,-0.8885313f,0.20257373f,0.083368674f,0f,0f,0f ) ;
  }

  @Test
  public void test543() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-390.0f,840.0f,0f,444.0f,0f,0f,0f,0f,0f,-900.0f,-142.0f,-247.0f,-443.0f,-385.0f,-608.0f,-966,-15.363274f,-69.38773f,95.870544f,0f,0f,0f ) ;
  }

  @Test
  public void test544() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,3.9104178f,27.462261f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.31980643f,0.8132631f,0.12565026f,0f,0f,0f ) ;
  }

  @Test
  public void test545() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-391.0f,-1094.0f,0f,2291.0f,0f,0f,0f,0f,0f,1071.0f,-1029.0f,225.0f,802.0f,-629.0f,1362.0f,-1,0.50751233f,-0.15814051f,0.27598044f,0f,0f,0f ) ;
  }

  @Test
  public void test546() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,40.0f,-838.0f,267.0f,-394.0f,0f,0f,0f,0f,0f,770.0f,284.0f,-546.0f,713.0f,883.0f,-293.0f,308,-29.9267f,-93.23734f,-32.26357f,88.153175f,-90.09201f,-4.9536433f ) ;
  }

  @Test
  public void test547() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-403.0f,-966.0f,0f,644.0f,0f,0f,0f,0f,0f,-918.0f,150.0f,1063.0f,636.0f,216.0f,519.0f,283,127.04021f,-100.0f,59.488743f,0f,0f,0f ) ;
  }

  @Test
  public void test548() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,4.0f,1144.0f,0f,8.0f,0f,0f,0f,0f,0f,175.0f,-652.0f,-217.0f,-998.0f,154.0f,2744.0f,-1001,-0.18826401f,-0.070613876f,0.8194773f,0f,0f,0f ) ;
  }

  @Test
  public void test549() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-4.0f,-263.0f,0f,553.0f,0f,0f,0f,0f,0f,238.0f,504.0f,-15.0f,233.0f,211.0f,361.0f,-720,78.14154f,-55.229504f,-7.327427f,0f,0f,0f ) ;
  }

  @Test
  public void test550() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,4.0f,-537.0f,0f,763.0f,0f,0f,0f,0f,0f,-201.0f,-103.0f,435.0f,435.0f,-838.0f,3.0f,32,-0.26545203f,0.4286961f,-0.49871317f,0f,0f,0f ) ;
  }

  @Test
  public void test551() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-4.0f,-6.0f,0f,1502.0f,0f,0f,0f,0f,0f,-973.0f,40.0f,-352.0f,-80.0f,793.0f,304.0f,363,-1.4391701f,1.2518611f,4.518302f,0f,0f,0f ) ;
  }

  @Test
  public void test552() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,414.0f,649.0f,0f,498.0f,0f,0f,0f,0f,0f,-119.0f,-88.0f,-610.0f,-508.0f,-103.0f,-91.0f,-947,29.863867f,86.73861f,74.281395f,0f,0f,0f ) ;
  }

  @Test
  public void test553() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,414.0f,9.0f,0f,1461.0f,0f,0f,0f,0f,0f,626.0f,719.0f,-794.0f,1092.0f,733.0f,-894.0f,-1464,-0.02646448f,-0.43991452f,-0.32601893f,0f,0f,0f ) ;
  }

  @Test
  public void test554() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,418.0f,1283.0f,0f,-582.0f,0f,0f,0f,0f,0f,-504.0f,-1523.0f,-180.0f,588.0f,-1476.0f,554.0f,-1901,0.3130469f,0.58492374f,0.2601676f,0f,0f,0f ) ;
  }

  @Test
  public void test555() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-425.0f,-1307.0f,0f,482.0f,0f,0f,0f,0f,0f,-66.0f,1547.0f,1267.0f,-1957.0f,-651.0f,-833.0f,-1811,0.89247507f,0.1412828f,-0.428401f,0f,0f,0f ) ;
  }

  @Test
  public void test556() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,43.0f,-2.0f,0f,717.0f,0f,0f,0f,0f,0f,646.0f,-63.0f,192.0f,698.0f,-220.0f,266.0f,815,-78.32531f,67.945465f,-83.1821f,0f,0f,0f ) ;
  }

  @Test
  public void test557() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-43.0f,873.0f,0f,310.0f,0f,0f,0f,0f,0f,-1436.0f,875.0f,-656.0f,-373.0f,-724.0f,-149.0f,-181,-0.025378106f,-0.02974371f,1.9213151f,0f,0f,0f ) ;
  }

  @Test
  public void test558() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,433.0f,-917.0f,0f,36.0f,0f,0f,0f,0f,0f,198.0f,676.0f,310.0f,435.0f,-204.0f,168.0f,1552,-4.1985292f,-60.715107f,40.641f,0f,0f,0f ) ;
  }

  @Test
  public void test559() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,4.352598f,0.0f,0f,0f,0f,0f,0f,0f,0f,92.97293f,-31.826f,-87.76167f,0f,0f,0f,481,0.5331769f,0.6327899f,0.33536106f,0f,0f,0f ) ;
  }

  @Test
  public void test560() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,43.857628f,-89.83987f,0f,72.98906f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.30446127f,-0.36162117f,-0.6258966f,0f,0f,0f ) ;
  }

  @Test
  public void test561() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-444.0f,525.0f,0f,925.0f,0f,0f,0f,0f,0f,718.0f,675.0f,852.0f,378.0f,-845.0f,351.0f,924,-3.0804262f,-88.55081f,9.908602f,0f,0f,0f ) ;
  }

  @Test
  public void test562() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-444.0f,-968.0f,0f,249.0f,0f,0f,0f,0f,0f,-217.0f,336.0f,883.0f,317.0f,-641.0f,997.0f,-462,10.17709f,-36.461094f,-70.47834f,0f,0f,0f ) ;
  }

  @Test
  public void test563() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-44.611156f,-74.79272f,0f,-92.382256f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.47377858f,0.3739383f,0.65120274f,0f,0f,0f ) ;
  }

  @Test
  public void test564() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,44.70487f,0.0f,0f,100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0.051433884f,-0.93324167f,0.12120594f,0f,0f,0f ) ;
  }

  @Test
  public void test565() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-447.0f,42.0f,0f,955.0f,0f,0f,0f,0f,0f,-272.0f,178.0f,-469.0f,129.0f,867.0f,-1100.0f,-532,-10.816536f,-0.9504085f,5.9124203f,0f,0f,0f ) ;
  }

  @Test
  public void test566() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,44.884823f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-91.814674f,-51.286404f,-36.625793f,0f,0f,0f,-128,-22.810535f,67.144936f,44.20487f,0f,0f,0f ) ;
  }

  @Test
  public void test567() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-450.0f,-152.0f,0f,150.0f,0f,0f,0f,0f,0f,594.0f,-616.0f,106.0f,-222.0f,-396.0f,-316.0f,-791,-43.692696f,-27.71622f,63.6295f,0f,0f,0f ) ;
  }

  @Test
  public void test568() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,4.5015116f,0f,0f,0f,0f,0f,0f,0f,0f,-66.232994f,-19.966688f,67.51038f,0f,0f,0f,-878,53.14141f,-2.327061f,-29.562624f,0f,0f,0f ) ;
  }

  @Test
  public void test569() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,4.5436716f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.21616884f,0.74764836f,-0.38577765f,0f,0f,0f ) ;
  }

  @Test
  public void test570() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,455.0f,1251.0f,0f,787.0f,0f,0f,0f,0f,0f,886.0f,-367.0f,613.0f,1921.0f,127.0f,-715.0f,756,-0.12460786f,-0.02568869f,-0.23871371f,0f,0f,0f ) ;
  }

  @Test
  public void test571() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-459.0f,1329.0f,-1665.0f,-157.0f,0f,0f,0f,0f,0f,-713.0f,-603.0f,693.0f,-847.0f,823.0f,-719.0f,736,-0.40228206f,0.0680826f,-0.3546512f,96.88847f,-39.032417f,68.88532f ) ;
  }

  @Test
  public void test572() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-461.0f,-446.0f,0f,894.0f,0f,0f,0f,0f,0f,-297.0f,-255.0f,552.0f,112.0f,997.0f,954.0f,-202,-84.307335f,39.187927f,-71.22489f,0f,0f,0f ) ;
  }

  @Test
  public void test573() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-465.0f,-503.0f,0f,258.0f,0f,0f,0f,0f,0f,1703.0f,-1756.0f,-52.0f,383.0f,-750.0f,-7.0f,717,-165.09146f,-59.125515f,-170.46826f,0f,0f,0f ) ;
  }

  @Test
  public void test574() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-466.0f,309.0f,0f,94.0f,0f,0f,0f,0f,0f,995.0f,495.0f,727.0f,-272.0f,421.0f,926.0f,-681,39.464268f,-45.197815f,-23.238033f,0f,0f,0f ) ;
  }

  @Test
  public void test575() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,47.14878f,-4.3711863f,0f,60.954323f,0f,0f,0f,0f,0f,-57.71039f,95.050606f,-13.172854f,0f,0f,0f,28,-13.3570175f,-6.4199133f,69.23355f,0f,0f,0f ) ;
  }

  @Test
  public void test576() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,473.0f,0.0f,0f,804.0f,0f,0f,0f,0f,0f,-338.0f,-691.0f,-1685.0f,-246.0f,305.0f,-1037.0f,-607,0.9317794f,0.13655035f,0.2799927f,0f,0f,0f ) ;
  }

  @Test
  public void test577() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-473.0f,53.0f,-828.0f,-972.0f,0f,0f,0f,0f,0f,-179.0f,-931.0f,861.0f,574.0f,-924.0f,636.0f,370,-65.371475f,-59.86874f,-95.64192f,12.066755f,30.553171f,51.393353f ) ;
  }

  @Test
  public void test578() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-475.0f,-376.0f,0f,535.0f,0f,0f,0f,0f,0f,269.0f,326.0f,-312.0f,715.0f,766.0f,-284.0f,786,-91.76205f,-40.373417f,99.54151f,0f,0f,0f ) ;
  }

  @Test
  public void test579() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,476.0f,-1900.0f,0f,774.0f,0f,0f,0f,0f,0f,-229.0f,382.0f,-28.0f,-772.0f,-505.0f,-578.0f,-18,-1.1473675f,11.2919f,2.725463f,0f,0f,0f ) ;
  }

  @Test
  public void test580() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-478.0f,900.0f,-953.0f,918.0f,0f,0f,0f,0f,0f,45.0f,1003.0f,-296.0f,-3266.0f,923.0f,-494.0f,285,-0.23931934f,-0.2769072f,-0.6015335f,0f,-31.038069f,0f ) ;
  }

  @Test
  public void test581() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-480.0f,1219.0f,0f,343.0f,0f,0f,0f,0f,0f,528.0f,-221.0f,128.0f,-389.0f,-795.0f,230.0f,769,3.4718232f,-36.986053f,-97.16248f,0f,0f,0f ) ;
  }

  @Test
  public void test582() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,494.0f,-1.0f,0f,1068.0f,0f,0f,0f,0f,0f,-651.0f,-13.0f,-294.0f,-494.0f,1589.0f,1022.0f,250,-0.35201478f,8.793998f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test583() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-49.51997f,0f,0f,0f,0f,0f,0f,0f,0f,34.04174f,-100.0f,-7.737324f,0f,0f,0f,-901,-0.1842696f,0.22158849f,-0.04652828f,0f,0f,0f ) ;
  }

  @Test
  public void test584() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,500.0f,113.0f,0f,1415.0f,0f,0f,0f,0f,0f,-184.0f,-555.0f,722.0f,-285.0f,-797.0f,-684.0f,-411,17.92165f,-92.59914f,-66.61349f,0f,0f,0f ) ;
  }

  @Test
  public void test585() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,50.10656f,0.0f,0f,62.155624f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.055882f,-0.24600011f,-0.9539915f,0f,0f,0f ) ;
  }

  @Test
  public void test586() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-50.3856f,0.0f,0f,75.20787f,0f,0f,0f,0f,0f,67.06362f,-5.23943f,100.0f,0f,0f,0f,-191,-0.029003946f,0.8697332f,-0.06809148f,0f,0f,0f ) ;
  }

  @Test
  public void test587() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-504.0f,39.0f,0f,562.0f,0f,0f,0f,0f,0f,-1292.0f,662.0f,701.0f,48.0f,-8.0f,96.0f,379,-39.298645f,-100.0f,19.421122f,0f,0f,0f ) ;
  }

  @Test
  public void test588() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-50.95327f,0f,0f,100.0f,0f,0f,0f,0f,0f,100.0f,-19.471228f,100.0f,-257.0f,-1826.0f,-300.0f,1,0.22199328f,-0.77817255f,0.5816988f,0f,0f,0f ) ;
  }

  @Test
  public void test589() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-51.40068f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.077329f,-0.0395243f,0.26947197f,0f,0f,0f ) ;
  }

  @Test
  public void test590() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-526.0f,-699.0f,0f,457.0f,0f,0f,0f,0f,0f,-877.0f,-830.0f,292.0f,607.0f,-181.0f,993.0f,295,25.596296f,15.804267f,-38.52145f,0f,0f,0f ) ;
  }

  @Test
  public void test591() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,528.0f,319.0f,0f,486.0f,0f,0f,0f,0f,0f,735.0f,65.0f,162.0f,-466.0f,677.0f,668.0f,-649,-31.516039f,-24.000011f,68.294914f,0f,0f,0f ) ;
  }

  @Test
  public void test592() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-528.0f,759.0f,-840.0f,421.0f,0f,0f,0f,0f,0f,-976.0f,451.0f,713.0f,-978.0f,-931.0f,529.0f,806,63.02214f,25.25073f,-26.503109f,-93.52862f,0f,0f ) ;
  }

  @Test
  public void test593() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-529.0f,-1293.0f,0f,864.0f,0f,0f,0f,0f,0f,-971.0f,1199.0f,518.0f,240.0f,265.0f,-2263.0f,3,-0.051546767f,-0.010333431f,0.17761403f,0f,0f,0f ) ;
  }

  @Test
  public void test594() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,532.0f,752.0f,0f,408.0f,0f,0f,0f,0f,0f,159.0f,760.0f,-797.0f,673.0f,491.0f,-536.0f,-782,-54.274982f,-97.72241f,-85.29827f,0f,0f,0f ) ;
  }

  @Test
  public void test595() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-546.0f,594.0f,0f,236.0f,0f,0f,0f,0f,0f,669.0f,-755.0f,-385.0f,947.0f,1133.0f,-575.0f,-535,-147.87836f,48.414505f,-45.17059f,0f,0f,0f ) ;
  }

  @Test
  public void test596() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-55.31238f,45.60733f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0.116843134f,0.6490243f,0.093489185f,0f,0f,0f ) ;
  }

  @Test
  public void test597() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-556.0f,907.0f,0f,-795.0f,0f,0f,0f,0f,0f,-361.0f,-434.0f,-227.0f,177.0f,182.0f,933.0f,-321,76.31873f,69.165146f,87.70531f,0f,0f,0f ) ;
  }

  @Test
  public void test598() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,56.426975f,17.014538f,0f,0f,0f,0f,0f,0f,0f,51.397915f,32.47234f,-32.43891f,0f,0f,0f,-736,0.13285485f,-0.7398868f,-0.33558315f,0f,0f,0f ) ;
  }

  @Test
  public void test599() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-56.926003f,100.0f,0f,0f,0f,0f,0f,0f,0f,55.57939f,-43.095665f,71.92004f,-770.0f,866.0f,-1184.0f,-2,0.9739451f,-0.10672933f,0.14729793f,0f,0f,0f ) ;
  }

  @Test
  public void test600() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,57.09896f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.0121064875f,0.0580818f,0.2444684f,0f,0f,0f ) ;
  }

  @Test
  public void test601() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-57.0f,-96.0f,0f,1409.0f,0f,0f,0f,0f,0f,1406.0f,-164.0f,-589.0f,413.0f,1153.0f,656.0f,-7,-15.4079f,-2.4368415f,-1.4387555f,0f,0f,0f ) ;
  }

  @Test
  public void test602() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,573.0f,603.0f,0f,229.0f,0f,0f,0f,0f,0f,-952.0f,-324.0f,175.0f,-173.0f,1461.0f,-16.0f,-1247,-0.7012525f,2.0732214f,0.023585854f,0f,0f,0f ) ;
  }

  @Test
  public void test603() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-577.0f,-1127.0f,0f,1122.0f,0f,0f,0f,0f,0f,100.0f,-493.0f,82.0f,-1664.0f,-193.0f,883.0f,-139,-1.3139625f,-0.22081423f,0.029064467f,0f,0f,0f ) ;
  }

  @Test
  public void test604() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-580.0f,1126.0f,0f,253.0f,0f,0f,0f,0f,0f,402.0f,-817.0f,-950.0f,1930.0f,-1641.0f,1630.0f,1106,-100.0f,65.69719f,-98.81538f,0f,0f,0f ) ;
  }

  @Test
  public void test605() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,581.0f,862.0f,0f,894.0f,0f,0f,0f,0f,0f,-704.0f,356.0f,608.0f,391.0f,924.0f,120.0f,-82,-10.235509f,-89.79077f,40.723217f,0f,0f,0f ) ;
  }

  @Test
  public void test606() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-58.223465f,0.0f,0f,0f,0f,0f,0f,0f,0f,-29.667088f,80.938835f,-90.07921f,0f,0f,0f,-140,-16.13662f,88.295166f,87.97289f,0f,0f,0f ) ;
  }

  @Test
  public void test607() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,58.42254f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.97523785f,0.121355616f,0.159096f,0f,0f,0f ) ;
  }

  @Test
  public void test608() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-588.0f,1472.0f,0f,1125.0f,0f,0f,0f,0f,0f,-71.0f,120.0f,128.0f,-892.0f,-861.0f,321.0f,962,-0.66996807f,-0.34701896f,-0.37826794f,0f,0f,0f ) ;
  }

  @Test
  public void test609() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,59.1012f,-93.5447f,0f,0.0f,0f,0f,0f,0f,0f,53.395638f,37.118717f,-61.183334f,0f,0f,0f,376,-4.3951178f,23.212332f,90.82088f,0f,0f,0f ) ;
  }

  @Test
  public void test610() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-591.0f,795.0f,-7.0f,-1903.0f,0f,0f,0f,0f,0f,983.0f,392.0f,2426.0f,201.0f,747.0f,1094.0f,-118,0.0056067617f,-0.32479176f,0.025636077f,-100.0f,93.358315f,0f ) ;
  }

  @Test
  public void test611() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,5.9499416f,0.0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,72.9476f,-100.0f,0f,0f,0f,-2610,-0.2508759f,-0.78410614f,0.56766087f,0f,0f,0f ) ;
  }

  @Test
  public void test612() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-596.0f,379.0f,0f,287.0f,0f,0f,0f,0f,0f,520.0f,42.0f,478.0f,-46.0f,-632.0f,107.0f,-255,-43.000187f,34.08851f,-56.393818f,0f,0f,0f ) ;
  }

  @Test
  public void test613() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-596.0f,566.0f,0f,36.0f,0f,0f,0f,0f,0f,906.0f,-826.0f,-134.0f,607.0f,-173.0f,-32.0f,-229,-2.0764816f,13.037925f,-94.4076f,0f,0f,0f ) ;
  }

  @Test
  public void test614() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,597.0f,-124.0f,0f,282.0f,0f,0f,0f,0f,0f,-2181.0f,-568.0f,-73.0f,2338.0f,469.0f,-367.0f,-16,-0.26589277f,0.9317316f,-0.22848602f,0f,0f,0f ) ;
  }

  @Test
  public void test615() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,59.715885f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.34527478f,-0.038874786f,0.16167338f,0f,0f,0f ) ;
  }

  @Test
  public void test616() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-599.0f,-696.0f,0f,255.0f,0f,0f,0f,0f,0f,-493.0f,-164.0f,640.0f,-977.0f,-426.0f,-160.0f,-40,17.510542f,152.24185f,-94.39423f,0f,0f,0f ) ;
  }

  @Test
  public void test617() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-612.0f,888.0f,372.0f,-644.0f,0f,0f,0f,0f,0f,284.0f,-851.0f,943.0f,511.0f,-60.0f,-270.0f,53,-65.68187f,-22.284868f,26.226414f,0f,29.002563f,0f ) ;
  }

  @Test
  public void test618() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,6.125834f,-100.0f,0f,-61.92137f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.19839716f,0.34985188f,-0.5075559f,0f,0f,0f ) ;
  }

  @Test
  public void test619() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,6.12591E-8f,0.0f,0f,3.0340338E-5f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,1.62273f,0.5396073f,-0.3375885f,0f,0f,0f ) ;
  }

  @Test
  public void test620() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-613.0f,-111.0f,0f,257.0f,0f,0f,0f,0f,0f,121.0f,-648.0f,-750.0f,885.0f,35.0f,-90.0f,240,8.878616f,-90.00639f,80.85554f,0f,0f,0f ) ;
  }

  @Test
  public void test621() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-616.0f,-368.0f,0f,255.0f,0f,0f,0f,0f,0f,-34.0f,706.0f,-215.0f,722.0f,-109.0f,-795.0f,157,-0.13610938f,-0.34179637f,-3.0220044E-4f,0f,0f,0f ) ;
  }

  @Test
  public void test622() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-619.0f,16.0f,0f,3432.0f,0f,0f,0f,0f,0f,-857.0f,241.0f,1124.0f,163.0f,288.0f,56.0f,5,-1.1369644f,0.9591579f,0.4611613f,0f,0f,0f ) ;
  }

  @Test
  public void test623() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-620.0f,459.0f,822.0f,-794.0f,0f,0f,0f,0f,0f,781.0f,733.0f,-944.0f,475.0f,-232.0f,-431.0f,985,2.1812212f,-79.85069f,-10.360026f,-85.78635f,46.412468f,0f ) ;
  }

  @Test
  public void test624() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-62.0f,379.0f,0f,889.0f,0f,0f,0f,0f,0f,238.0f,982.0f,346.0f,212.0f,-215.0f,-867.0f,995,-0.71815515f,0.1394927f,-0.61800754f,0f,0f,0f ) ;
  }

  @Test
  public void test625() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,623.0f,1.0f,0f,1617.0f,0f,0f,0f,0f,0f,-1412.0f,-2008.0f,12.0f,-31.0f,25.0f,555.0f,1222,0.009283167f,0.75852877f,0.45784634f,0f,0f,0f ) ;
  }

  @Test
  public void test626() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,629.0f,653.0f,0f,373.0f,0f,0f,0f,0f,0f,-510.0f,-951.0f,304.0f,397.0f,581.0f,-975.0f,-864,55.446068f,-27.761265f,-57.494415f,0f,0f,0f ) ;
  }

  @Test
  public void test627() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-6.3087907f,0f,0f,0f,0f,0f,0f,0f,0f,72.1202f,32.025604f,-63.769062f,0f,0f,0f,-667,-80.96598f,-82.18751f,-85.05591f,0f,0f,0f ) ;
  }

  @Test
  public void test628() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-631.0f,812.0f,0f,704.0f,0f,0f,0f,0f,0f,-958.0f,-277.0f,795.0f,378.0f,712.0f,731.0f,-143,-13.129302f,-76.4742f,-42.46956f,0f,0f,0f ) ;
  }

  @Test
  public void test629() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,632.0f,-804.0f,0f,885.0f,0f,0f,0f,0f,0f,-388.0f,-912.0f,362.0f,-64.0f,-338.0f,-113.0f,-220,-9.748487f,59.170425f,-77.3893f,0f,0f,0f ) ;
  }

  @Test
  public void test630() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,63.285698f,-100.0f,0f,0f,0f,0f,0f,0f,0f,-92.86704f,100.0f,100.0f,639.0f,-1487.0f,83.0f,-1020,0.64699495f,-0.75085294f,-0.1322726f,0f,0f,0f ) ;
  }

  @Test
  public void test631() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,636.0f,0.0f,0f,500.0f,0f,0f,0f,0f,0f,-269.0f,71.0f,259.0f,-506.0f,341.0f,-616.0f,1022,94.65308f,2.9889805f,-55.12826f,0f,0f,0f ) ;
  }

  @Test
  public void test632() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-63.92698f,0.0f,0f,-31.420223f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.3067249f,-0.28178978f,-0.21783906f,0f,0f,0f ) ;
  }

  @Test
  public void test633() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,64.05028f,35.721073f,0f,0f,0f,0f,0f,0f,0f,-52.883034f,52.586884f,-1.2051824f,821.0f,-320.0f,95.0f,-539,34.235603f,32.3019f,-92.72626f,0f,0f,0f ) ;
  }

  @Test
  public void test634() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,642.0f,-5.0f,0f,1758.0f,0f,0f,0f,0f,0f,-135.0f,1.0f,-1554.0f,411.0f,-2164.0f,599.0f,-1154,0.5260051f,0.2269536f,0.6847351f,0f,0f,0f ) ;
  }

  @Test
  public void test635() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,644.0f,0.0f,0f,212.0f,0f,0f,0f,0f,0f,-424.0f,-941.0f,499.0f,893.0f,952.0f,582.0f,704,84.2383f,9.41586f,-94.83516f,0f,0f,0f ) ;
  }

  @Test
  public void test636() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,6.447719f,7.177527f,0f,0f,0f,0f,0f,0f,0f,81.48694f,96.342766f,78.72605f,1735.0f,216.0f,1119.0f,1,0.82295245f,0.30268988f,0.14193483f,0f,0f,0f ) ;
  }

  @Test
  public void test637() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,6.5400586f,64.69044f,0f,0f,0f,0f,0f,0f,0f,-50.044292f,68.10484f,7.726491f,-144.0f,-952.0f,740.0f,773,47.141346f,-66.04552f,55.811016f,0f,0f,0f ) ;
  }

  @Test
  public void test638() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-664.0f,901.0f,-1140.0f,-259.0f,0f,0f,0f,0f,0f,457.0f,-988.0f,399.0f,-560.0f,130.0f,1091.0f,-756,-0.0058928668f,-0.045799874f,-0.29911107f,-78.12249f,0f,0f ) ;
  }

  @Test
  public void test639() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-669.0f,-490.0f,0f,70.0f,0f,0f,0f,0f,0f,783.0f,335.0f,134.0f,342.0f,940.0f,464.0f,-188,-26.27361f,25.734955f,35.364544f,0f,0f,0f ) ;
  }

  @Test
  public void test640() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-6.6959496E-5f,216.81395f,0f,0f,0f,0f,0f,0f,0f,-15.449934f,78.03097f,66.650024f,867.0f,-200.0f,280.0f,3,-6.867119f,-0.12002916f,-1.4495599f,0f,0f,0f ) ;
  }

  @Test
  public void test641() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,67.370636f,75.03948f,0f,0f,0f,0f,0f,0f,0f,-100.0f,77.771f,-30.847765f,-1453.0f,-791.0f,-54.0f,4,0.83932513f,0.058162615f,0.28256133f,0f,0f,0f ) ;
  }

  @Test
  public void test642() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-674.0f,-139.0f,0f,578.0f,0f,0f,0f,0f,0f,442.0f,790.0f,832.0f,-516.0f,392.0f,524.0f,141,-76.87298f,-65.327f,47.633778f,0f,0f,0f ) ;
  }

  @Test
  public void test643() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,674.0f,-688.0f,0f,908.0f,0f,0f,0f,0f,0f,-400.0f,-475.0f,-628.0f,-273.0f,-888.0f,-269.0f,771,-29.506298f,-36.025238f,66.1904f,0f,0f,0f ) ;
  }

  @Test
  public void test644() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-677.0f,197.0f,0f,0.0f,0f,0f,0f,0f,0f,103.0f,-420.0f,-348.0f,571.0f,-649.0f,45.0f,-102,15.987169f,1.7674879f,81.00972f,0f,0f,0f ) ;
  }

  @Test
  public void test645() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-6.79967f,-28.771904f,0f,0f,0f,0f,0f,0f,0f,-27.355974f,-27.4759f,-53.23407f,0f,0f,0f,-73,26.49518f,3.1125102f,41.615494f,0f,0f,0f ) ;
  }

  @Test
  public void test646() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-681.0f,423.0f,-506.0f,-12.0f,0f,0f,0f,0f,0f,479.0f,-948.0f,-538.0f,-292.0f,33.0f,-380.0f,806,-100.0f,-100.0f,100.0f,100.0f,-56.663967f,100.0f ) ;
  }

  @Test
  public void test647() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,684.0f,116.0f,0f,-392.0f,0f,0f,0f,0f,0f,-1297.0f,-622.0f,453.0f,955.0f,109.0f,1634.0f,-1103,0.9166691f,0.018526873f,-0.0704269f,0f,0f,0f ) ;
  }

  @Test
  public void test648() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-68.96607f,-12.458633f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,-0.005097026f,0.0031108146f,-0.079375505f,0f,0f,0f ) ;
  }

  @Test
  public void test649() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-69.0f,111.0f,-224.0f,-290.0f,0f,0f,0f,0f,0f,-506.0f,437.0f,-841.0f,542.0f,974.0f,-321.0f,-461,13.474236f,-76.25181f,-31.211988f,-69.56213f,34.04586f,-1.2607458f ) ;
  }

  @Test
  public void test650() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-69.0f,-1910.0f,0f,252.0f,0f,0f,0f,0f,0f,-1014.0f,77.0f,-925.0f,-372.0f,-719.0f,-972.0f,454,0.6374607f,-0.73405665f,-0.20089978f,0f,0f,0f ) ;
  }

  @Test
  public void test651() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-69.34104f,-76.207886f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.23805697f,0.20734578f,-0.43270308f,0f,0f,0f ) ;
  }

  @Test
  public void test652() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,699.0f,1189.0f,0f,1987.0f,0f,0f,0f,0f,0f,-41.0f,-778.0f,-615.0f,921.0f,554.0f,-763.0f,2474,0.5653091f,0.03288859f,-0.07929268f,0f,0f,0f ) ;
  }

  @Test
  public void test653() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-702.0f,946.0f,0f,522.0f,0f,0f,0f,0f,0f,12.0f,-69.0f,-447.0f,-962.0f,-465.0f,-787.0f,-605,-53.468773f,77.16432f,27.846018f,0f,0f,0f ) ;
  }

  @Test
  public void test654() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,70.35612f,0.0f,0f,47.521473f,0f,0f,0f,0f,0f,-30.394957f,-19.318459f,-16.54295f,0f,0f,0f,-74,-23.452137f,29.889378f,26.449848f,0f,0f,0f ) ;
  }

  @Test
  public void test655() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,7.0f,40.0f,0f,967.0f,0f,0f,0f,0f,0f,-965.0f,-70.0f,-1073.0f,177.0f,-674.0f,-116.0f,428,18.237976f,109.047295f,35.182514f,0f,0f,0f ) ;
  }

  @Test
  public void test656() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,71.04651f,-11.001196f,0f,0f,0f,0f,0f,0f,0f,-97.03526f,74.21573f,-84.31135f,0f,0f,0f,234,16.150358f,-38.728226f,-51.231052f,0f,0f,0f ) ;
  }

  @Test
  public void test657() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-717.0f,-1123.0f,0f,268.0f,0f,0f,0f,0f,0f,2891.0f,1021.0f,-173.0f,766.0f,1109.0f,-1090.0f,2322,-0.5778323f,-0.051209934f,-0.48148096f,0f,0f,0f ) ;
  }

  @Test
  public void test658() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,718.0f,-387.0f,0f,896.0f,0f,0f,0f,0f,0f,-812.0f,-419.0f,-472.0f,235.0f,-856.0f,-818.0f,-721,55.76414f,-96.49715f,-1.1719055f,0f,0f,0f ) ;
  }

  @Test
  public void test659() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-722.0f,142.0f,-715.0f,744.0f,0f,0f,0f,0f,0f,-224.0f,1602.0f,-17.0f,737.0f,795.0f,964.0f,555,0.22158256f,-0.4981674f,0.25832883f,0f,-56.125843f,0f ) ;
  }

  @Test
  public void test660() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-72.60363f,0.0f,0f,-28.135387f,0f,0f,0f,0f,0f,25.543898f,-100.0f,34.431774f,0f,0f,0f,501,-0.31661645f,0.67589396f,-0.16152547f,0f,0f,0f ) ;
  }

  @Test
  public void test661() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-72.6077f,-31.492472f,0f,100.0f,0f,0f,0f,0f,0f,-99.97759f,54.936348f,22.631561f,0f,0f,0f,-722,0.6383039f,0.05190333f,-0.76803267f,0f,0f,0f ) ;
  }

  @Test
  public void test662() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,727.0f,963.0f,0f,38.0f,0f,0f,0f,0f,0f,-175.0f,-791.0f,-707.0f,494.0f,575.0f,-766.0f,750,30.09897f,-6.4657445f,1.2967873f,0f,0f,0f ) ;
  }

  @Test
  public void test663() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-730.0f,319.0f,-536.0f,990.0f,0f,0f,0f,0f,0f,-763.0f,-487.0f,-1270.0f,-861.0f,-74.0f,-354.0f,1462,0.43335912f,0.0026512782f,-0.16247486f,0f,0f,100.0f ) ;
  }

  @Test
  public void test664() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,73.0f,465.0f,0f,187.0f,0f,0f,0f,0f,0f,-252.0f,-308.0f,391.0f,-728.0f,-218.0f,-639.0f,-733,-31.25582f,-48.114166f,-99.86455f,0f,0f,0f ) ;
  }

  @Test
  public void test665() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,734.0f,39.0f,0f,34.0f,0f,0f,0f,0f,0f,312.0f,314.0f,1780.0f,861.0f,889.0f,-508.0f,-799,60.511353f,-48.034946f,-2.132912f,0f,0f,0f ) ;
  }

  @Test
  public void test666() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-73.48684f,0f,0f,27.07956f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.27710694f,0.17929053f,-0.91936934f,0f,0f,0f ) ;
  }

  @Test
  public void test667() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,73.59502f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.060574472f,0.8799383f,0.08891299f,0f,0f,0f ) ;
  }

  @Test
  public void test668() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-738.0f,774.0f,-879.0f,-210.0f,0f,0f,0f,0f,0f,-406.0f,18.0f,-367.0f,75.0f,-829.0f,-836.0f,-311,18.980045f,-10.238049f,86.48074f,94.59772f,0f,0f ) ;
  }

  @Test
  public void test669() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,74.07145f,0.0f,0f,0f,0f,0f,0f,0f,0f,100.107765f,-4.2814074f,-1.9289509f,0f,0f,0f,-51,-32.77225f,30.346508f,-33.379574f,0f,0f,0f ) ;
  }

  @Test
  public void test670() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-743.0f,-337.0f,0f,945.0f,0f,0f,0f,0f,0f,-12.0f,113.0f,32.0f,-705.0f,343.0f,-1474.0f,342,89.83233f,-100.0f,-72.385895f,0f,0f,0f ) ;
  }

  @Test
  public void test671() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,74.41862f,0.0f,0f,64.10828f,0f,0f,0f,0f,0f,98.50594f,77.1807f,100.0f,0f,0f,0f,1280,0.38200113f,-0.40038756f,-0.83292556f,0f,0f,0f ) ;
  }

  @Test
  public void test672() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-747.0f,2011.0f,0f,194.0f,0f,0f,0f,0f,0f,-531.0f,-296.0f,1714.0f,-108.0f,-574.0f,427.0f,-1241,-96.382065f,19.296549f,-26.526896f,0f,0f,0f ) ;
  }

  @Test
  public void test673() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,755.0f,-1044.0f,0f,309.0f,0f,0f,0f,0f,0f,428.0f,423.0f,1906.0f,1099.0f,975.0f,972.0f,1444,-1.2081786f,1.244936f,-0.0049881977f,0f,0f,0f ) ;
  }

  @Test
  public void test674() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-755.0f,-728.0f,0f,1375.0f,0f,0f,0f,0f,0f,923.0f,482.0f,-128.0f,-37.0f,-197.0f,-1009.0f,-716,-90.14923f,100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test675() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-763.0f,-662.0f,0f,255.0f,0f,0f,0f,0f,0f,-2401.0f,1038.0f,-2206.0f,-1379.0f,760.0f,1.0f,939,0.37413558f,0.02990917f,-0.24425487f,0f,0f,0f ) ;
  }

  @Test
  public void test676() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-763.0f,891.0f,71.0f,-873.0f,0f,0f,0f,0f,0f,915.0f,957.0f,-847.0f,-780.0f,-151.0f,-28.0f,679,43.950623f,-98.53519f,-19.711794f,0f,-33.96056f,0f ) ;
  }

  @Test
  public void test677() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-768.0f,341.0f,-945.0f,12.0f,0f,0f,0f,0f,0f,420.0f,-128.0f,168.0f,-378.0f,744.0f,-1123.0f,-508,13.223724f,40.176804f,-2.4484138f,-38.194065f,0f,0f ) ;
  }

  @Test
  public void test678() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-771.0f,1139.0f,0f,316.0f,0f,0f,0f,0f,0f,538.0f,-1575.0f,-176.0f,830.0f,-1649.0f,-1262.0f,-813,-0.6203923f,-0.2311505f,0.21046817f,0f,0f,0f ) ;
  }

  @Test
  public void test679() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-771.0f,1204.0f,-523.0f,-541.0f,0f,0f,0f,0f,0f,-1322.0f,-1161.0f,2180.0f,328.0f,397.0f,2396.0f,73,0.56620336f,0.010873531f,0.074700125f,-100.0f,-100.0f,0f ) ;
  }

  @Test
  public void test680() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,774.0f,296.0f,0f,387.0f,0f,0f,0f,0f,0f,789.0f,58.0f,-610.0f,849.0f,88.0f,981.0f,465,-89.19133f,58.245735f,2.9515667f,0f,0f,0f ) ;
  }

  @Test
  public void test681() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,78.26053f,0f,0f,0f,0f,0f,0f,0f,0f,19.367895f,73.3762f,100.0f,0f,0f,0f,408,-0.2800008f,-0.12673861f,-0.95159703f,0f,0f,0f ) ;
  }

  @Test
  public void test682() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-783.0f,316.0f,23.0f,-733.0f,0f,0f,0f,0f,0f,546.0f,837.0f,-600.0f,677.0f,547.0f,361.0f,890,-67.048615f,-100.0f,41.065617f,-80.393f,-15.515402f,-94.62399f ) ;
  }

  @Test
  public void test683() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-78.31603f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-40.185772f,-95.7679f,43.76892f,0f,0f,0f,438,100.0f,70.57114f,-60.688377f,0f,0f,0f ) ;
  }

  @Test
  public void test684() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,7.862754f,60.07932f,0f,0f,0f,0f,0f,0f,0f,-91.51382f,117.79669f,53.08978f,0f,0f,0f,-28,-91.01627f,-97.31708f,-1.8831229f,0f,0f,0f ) ;
  }

  @Test
  public void test685() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-79.668846f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-52.57099f,11.537048f,0f,0f,0f,973,-0.1519501f,0.3490702f,-0.9246952f,0f,0f,0f ) ;
  }

  @Test
  public void test686() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,79.68876f,-34.79389f,0f,-1.0903425f,0f,0f,0f,0f,0f,-77.231155f,15.178688f,45.55497f,0f,0f,0f,115,-0.013964318f,-0.7792441f,-0.240774f,0f,0f,0f ) ;
  }

  @Test
  public void test687() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,803.0f,0.0f,0f,1147.0f,0f,0f,0f,0f,0f,-1632.0f,1493.0f,-1013.0f,1462.0f,-904.0f,192.0f,922,0.6617391f,0.17152633f,0.72984934f,0f,0f,0f ) ;
  }

  @Test
  public void test688() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,803.0f,-9.0f,0f,924.0f,0f,0f,0f,0f,0f,148.0f,770.0f,-375.0f,-252.0f,-167.0f,-445.0f,11,-145.98686f,-90.984924f,83.87177f,0f,0f,0f ) ;
  }

  @Test
  public void test689() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-815.0f,-1725.0f,0f,76.0f,0f,0f,0f,0f,0f,2027.0f,-1424.0f,344.0f,169.0f,-857.0f,1055.0f,-3,0.31259045f,0.08080344f,-0.9700818f,0f,0f,0f ) ;
  }

  @Test
  public void test690() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,81.824844f,-10.852051f,0f,0f,0f,0f,0f,0f,0f,26.768396f,68.35569f,29.543118f,-1081.0f,455.0f,-68.0f,423,-1.459603f,0.32063925f,0.53977495f,0f,0f,0f ) ;
  }

  @Test
  public void test691() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-81.8584f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,24.460901f,8.134981f,0f,0f,0f,2,-0.06668265f,-0.2429937f,-0.96773314f,0f,0f,0f ) ;
  }

  @Test
  public void test692() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-826.0f,1.0f,0f,124.0f,0f,0f,0f,0f,0f,849.0f,1412.0f,-1202.0f,2892.0f,372.0f,-730.0f,17,-1.6726729f,-3.2435014f,-6.09916f,0f,0f,0f ) ;
  }

  @Test
  public void test693() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-826.0f,116.0f,0f,693.0f,0f,0f,0f,0f,0f,114.0f,-302.0f,183.0f,-511.0f,-940.0f,-749.0f,348,2.299376f,12.259556f,18.798393f,0f,0f,0f ) ;
  }

  @Test
  public void test694() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-827.0f,1290.0f,-744.0f,4.0f,0f,0f,0f,0f,0f,210.0f,1428.0f,-156.0f,327.0f,502.0f,-79.0f,-734,-17.274412f,-171.94061f,43.555843f,-100.13133f,0f,0f ) ;
  }

  @Test
  public void test695() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-82.791115f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.72560215f,-0.3979099f,-0.26521266f,0f,0f,0f ) ;
  }

  @Test
  public void test696() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-830.0f,1295.0f,0f,956.0f,0f,0f,0f,0f,0f,318.0f,365.0f,-470.0f,1036.0f,-362.0f,425.0f,986,0.2557446f,-0.14399381f,0.061210733f,0f,0f,0f ) ;
  }

  @Test
  public void test697() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-83.06716f,-17.961426f,0f,84.91726f,0f,0f,0f,0f,0f,59.693417f,-43.03756f,47.58052f,0f,0f,0f,-738,-65.21274f,30.404652f,-50.649708f,0f,0f,0f ) ;
  }

  @Test
  public void test698() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-835.0f,-867.0f,0f,250.0f,0f,0f,0f,0f,0f,-530.0f,-334.0f,667.0f,-420.0f,1010.0f,516.0f,42,8.0121355f,71.99009f,-93.52372f,0f,0f,0f ) ;
  }

  @Test
  public void test699() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,84.51141f,-39.22378f,0f,-46.795307f,0f,0f,0f,0f,0f,-92.540855f,23.002712f,89.473434f,0f,0f,0f,-877,-77.93171f,-55.803066f,-82.299866f,0f,0f,0f ) ;
  }

  @Test
  public void test700() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-84.63391f,1.4349501f,0f,0f,0f,0f,0f,0f,0f,-22.020693f,-21.591866f,-81.124954f,-578.0f,843.0f,-76.0f,-30,-20.83837f,35.667343f,66.68982f,0f,0f,0f ) ;
  }

  @Test
  public void test701() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-849.0f,92.0f,0f,437.0f,0f,0f,0f,0f,0f,-327.0f,-281.0f,1094.0f,900.0f,-130.0f,991.0f,-570,72.94905f,-57.424744f,-73.84941f,0f,0f,0f ) ;
  }

  @Test
  public void test702() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-850.0f,-1868.0f,0f,425.0f,0f,0f,0f,0f,0f,-691.0f,-392.0f,175.0f,-569.0f,623.0f,-852.0f,-2020,1.0315764f,0.006403553f,-0.10516033f,0f,0f,0f ) ;
  }

  @Test
  public void test703() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-850.0f,477.0f,0f,899.0f,0f,0f,0f,0f,0f,-79.0f,1.0f,74.0f,-973.0f,-2513.0f,-1004.0f,-805,-44.882153f,27.678205f,-48.28876f,0f,0f,0f ) ;
  }

  @Test
  public void test704() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-851.0f,217.0f,0f,414.0f,0f,0f,0f,0f,0f,832.0f,564.0f,1171.0f,-1097.0f,-257.0f,1620.0f,536,-0.07566387f,-0.7269178f,-0.30174068f,0f,0f,0f ) ;
  }

  @Test
  public void test705() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-85.239334f,91.15171f,0f,0f,0f,0f,0f,0f,0f,-100.0f,5.4515047f,-21.040844f,-270.0f,-992.0f,890.0f,7,-0.1347982f,-5.9568925f,-1.0280572f,0f,0f,0f ) ;
  }

  @Test
  public void test706() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-8.6008215f,0.0f,0f,100.0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,-28.376076f,0f,0f,0f,-1347,0.8875958f,0.38480666f,-0.25317502f,0f,0f,0f ) ;
  }

  @Test
  public void test707() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-861.0f,103.0f,0f,409.0f,0f,0f,0f,0f,0f,-439.0f,-801.0f,584.0f,790.0f,910.0f,691.0f,-221,67.2525f,-50.815346f,-27.263119f,0f,0f,0f ) ;
  }

  @Test
  public void test708() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-861.0f,1.0f,0f,6.0f,0f,0f,0f,0f,0f,181.0f,1618.0f,534.0f,-1348.0f,131.0f,-914.0f,-613,0.22582196f,0.052927494f,-0.66848004f,0f,0f,0f ) ;
  }

  @Test
  public void test709() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-867.0f,493.0f,0f,-1723.0f,0f,0f,0f,0f,0f,-463.0f,1073.0f,-558.0f,930.0f,-731.0f,1216.0f,-916,-0.018391754f,-0.32855555f,-0.576153f,0f,0f,0f ) ;
  }

  @Test
  public void test710() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,87.0165f,49.05824f,0f,0f,0f,0f,0f,0f,0f,-99.05101f,91.319824f,86.117035f,-350.0f,561.0f,-84.0f,-486,-0.20060582f,-43.781586f,-95.56077f,0f,0f,0f ) ;
  }

  @Test
  public void test711() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,87.26172f,-11.196813f,0f,96.18578f,0f,0f,0f,0f,0f,100.0f,7.2465343f,45.697037f,0f,0f,0f,1132,-0.6396098f,0.085997574f,-0.14823553f,0f,0f,0f ) ;
  }

  @Test
  public void test712() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,873.0f,409.0f,109.0f,-264.0f,0f,0f,0f,0f,0f,-227.0f,-753.0f,474.0f,526.0f,-825.0f,-219.0f,854,-6.386441f,86.179245f,-73.75767f,-48.62085f,12.766893f,0f ) ;
  }

  @Test
  public void test713() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,875.0f,-268.0f,0f,260.0f,0f,0f,0f,0f,0f,987.0f,87.0f,221.0f,135.0f,-922.0f,724.0f,-688,-26.714796f,39.779835f,78.82056f,0f,0f,0f ) ;
  }

  @Test
  public void test714() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-886.0f,-803.0f,0f,161.0f,0f,0f,0f,0f,0f,415.0f,1255.0f,-477.0f,-426.0f,543.0f,1056.0f,-1381,0.70318764f,-0.0062263673f,0.59540623f,0f,0f,0f ) ;
  }

  @Test
  public void test715() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-887.0f,1.0f,0f,24.0f,0f,0f,0f,0f,0f,915.0f,606.0f,-667.0f,112.0f,651.0f,747.0f,131,1.0205115f,-0.12908913f,1.2826687f,0f,0f,0f ) ;
  }

  @Test
  public void test716() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-889.0f,771.0f,-966.0f,1.0f,0f,0f,0f,0f,0f,-913.0f,-396.0f,0.0f,-1065.0f,407.0f,-1392.0f,-519,-40.828266f,122.38666f,-100.0f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test717() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-89.38882f,-1.4121836f,0f,54.53481f,0f,0f,0f,0f,0f,-73.87542f,-42.63914f,-83.36236f,0f,0f,0f,-793,0.68148243f,0.047645718f,-0.57177263f,0f,0f,0f ) ;
  }

  @Test
  public void test718() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,896.0f,-4.0f,0f,118.0f,0f,0f,0f,0f,0f,912.0f,994.0f,1033.0f,237.0f,-716.0f,1821.0f,-2523,-0.02938234f,0.1727227f,-0.42340556f,0f,0f,0f ) ;
  }

  @Test
  public void test719() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-898.0f,-963.0f,0f,60.0f,0f,0f,0f,0f,0f,-269.0f,-249.0f,-962.0f,780.0f,-762.0f,-226.0f,-332,79.28775f,55.47347f,46.55638f,0f,0f,0f ) ;
  }

  @Test
  public void test720() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,90.078224f,0.39337453f,0f,0f,0f,0f,0f,0f,0f,-99.987236f,-68.600494f,-2.821114f,602.0f,607.0f,413.0f,752,0.22850817f,-0.29190812f,0.068406895f,0f,0f,0f ) ;
  }

  @Test
  public void test721() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,908.0f,-3977.0f,0f,571.0f,0f,0f,0f,0f,0f,517.0f,245.0f,-187.0f,578.0f,-1584.0f,-470.0f,-12,-1.4350337f,10.360389f,10.988041f,0f,0f,0f ) ;
  }

  @Test
  public void test722() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-909.0f,1403.0f,0f,491.0f,0f,0f,0f,0f,0f,600.0f,-869.0f,-511.0f,720.0f,238.0f,428.0f,763,-73.40931f,-68.503784f,30.301758f,0f,0f,0f ) ;
  }

  @Test
  public void test723() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,910.0f,868.0f,0f,421.0f,0f,0f,0f,0f,0f,-369.0f,543.0f,-691.0f,-310.0f,-268.0f,-45.0f,1194,-59.460438f,-33.993607f,5.1211357f,0f,0f,0f ) ;
  }

  @Test
  public void test724() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,916.0f,-1405.0f,0f,964.0f,0f,0f,0f,0f,0f,-45.0f,598.0f,-426.0f,593.0f,330.0f,401.0f,-5,-3.3864336f,6.3442273f,-4.8254533f,0f,0f,0f ) ;
  }

  @Test
  public void test725() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-91.829895f,100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,-0.18705064f,-1.3276737f,0.09323547f,0f,0f,0f ) ;
  }

  @Test
  public void test726() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-9.1997265E-8f,67.78744f,0f,0f,0f,0f,0f,0f,0f,44.999252f,81.975586f,-11.365697f,-635.0f,458.0f,790.0f,1,1.8028339f,-0.0146741895f,-0.39949718f,0f,0f,0f ) ;
  }

  @Test
  public void test727() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,92.10576f,0.0f,0f,51.658066f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0.007673466f,0.9374937f,-0.19417186f,0f,0f,0f ) ;
  }

  @Test
  public void test728() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-929.0f,39.0f,0f,847.0f,0f,0f,0f,0f,0f,-311.0f,841.0f,224.0f,851.0f,939.0f,636.0f,986,-49.879612f,-16.721352f,-6.4727826f,0f,0f,0f ) ;
  }

  @Test
  public void test729() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-93.04026f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.122914694f,0.2560144f,0.02572167f,0f,0f,0f ) ;
  }

  @Test
  public void test730() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-93.86379f,84.1245f,0f,0f,0f,0f,0f,0f,0f,100.0f,-44.375355f,-98.453354f,-145.0f,-838.0f,877.0f,1,0.37233493f,0.15174861f,1.8039669f,0f,0f,0f ) ;
  }

  @Test
  public void test731() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,94.79601f,73.96667f,0f,0f,0f,0f,0f,0f,0f,51.900208f,80.85881f,-68.48829f,-324.0f,884.0f,785.0f,403,-1.2709029f,0.22061804f,-0.70261955f,0f,0f,0f ) ;
  }

  @Test
  public void test732() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-94.810555f,-36.06625f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0.2762954f,-0.67400897f,0.11185691f,0f,0f,0f ) ;
  }

  @Test
  public void test733() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,95.03245f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.21474001f,-0.60768867f,-0.67096967f,0f,0f,0f ) ;
  }

  @Test
  public void test734() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-95.30939f,0f,0f,-1.4210855E-14f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.0017724254f,-0.759784f,0.32958877f,0f,0f,0f ) ;
  }

  @Test
  public void test735() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,960.0f,450.0f,0f,88.0f,0f,0f,0f,0f,0f,1105.0f,-370.0f,-270.0f,771.0f,294.0f,579.0f,801,-0.20610511f,-0.5483411f,0.027148673f,0f,0f,0f ) ;
  }

  @Test
  public void test736() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-962.0f,427.0f,254.0f,-532.0f,0f,0f,0f,0f,0f,189.0f,889.0f,-256.0f,817.0f,993.0f,-69.0f,813,23.542616f,55.60311f,-61.25157f,77.630585f,0f,0f ) ;
  }

  @Test
  public void test737() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-964.0f,20.0f,-886.0f,392.0f,0f,0f,0f,0f,0f,108.0f,175.0f,-744.0f,-584.0f,430.0f,32.0f,1036,28.451944f,1.0754408f,4.3832817f,31.369429f,-61.082443f,0f ) ;
  }

  @Test
  public void test738() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,968.0f,901.0f,0f,0.0f,0f,0f,0f,0f,0f,-619.0f,-1955.0f,480.0f,452.0f,1983.0f,667.0f,1006,-0.6151144f,0.4771824f,-0.47170746f,0f,0f,0f ) ;
  }

  @Test
  public void test739() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-97.36464f,42.676266f,0f,0f,0f,0f,0f,0f,0f,10.759351f,51.552788f,-28.652231f,-563.0f,-573.0f,710.0f,838,-0.24966809f,0.3903632f,0.6087192f,0f,0f,0f ) ;
  }

  @Test
  public void test740() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-979.0f,-1.0f,0f,1646.0f,0f,0f,0f,0f,0f,817.0f,-299.0f,659.0f,-1404.0f,-735.0f,-137.0f,192,-1.0000775f,0.061389767f,0.19425036f,0f,0f,0f ) ;
  }

  @Test
  public void test741() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,98.04484f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.116488904f,0.265884f,0.9556344f,0f,0f,0f ) ;
  }

  @Test
  public void test742() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,98.26068f,0f,0f,0f,0f,0f,0f,0f,0f,-56.771534f,100.0f,-24.872326f,0f,0f,0f,2,0.73293704f,-0.65407556f,-0.18705215f,0f,0f,0f ) ;
  }

  @Test
  public void test743() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-98.54392f,54.356842f,0f,0f,0f,0f,0f,0f,0f,89.51421f,-64.22759f,41.78858f,0f,0f,0f,823,-63.914055f,-0.6973914f,-5.2042108f,0f,0f,0f ) ;
  }

  @Test
  public void test744() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,98.89112f,-23.979813f,0f,19.361387f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.45248502f,0.090672836f,-0.11869703f,0f,0f,0f ) ;
  }

  @Test
  public void test745() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-992.0f,-2.0f,0f,1277.0f,0f,0f,0f,0f,0f,845.0f,563.0f,659.0f,-405.0f,-145.0f,646.0f,237,-0.5798812f,0.20798475f,0.5658637f,0f,0f,0f ) ;
  }

  @Test
  public void test746() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-996.0f,1.0f,-433.0f,-152.0f,0f,0f,0f,0f,0f,956.0f,740.0f,-793.0f,578.0f,-568.0f,-678.0f,679,-87.84945f,-80.395424f,-91.12892f,32.080864f,-47.371403f,0f ) ;
  }

  @Test
  public void test747() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-99.6346f,-22.422379f,0f,0.0f,0f,0f,0f,0f,0f,46.3464f,-4.3326797f,-100.0f,0f,0f,0f,920,70.39882f,-30.188967f,57.130466f,0f,0f,0f ) ;
  }

  @Test
  public void test748() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-99.90496f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.04074318f,-0.4584285f,-0.52019924f,0f,0f,0f ) ;
  }

  @Test
  public void test749() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,99.98387f,-36.234543f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.029397678f,-0.2665314f,-0.21922262f,0f,0f,0f ) ;
  }

  @Test
  public void test750() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-99.995766f,100.0f,0f,0f,0f,0f,0f,0f,0f,-54.701687f,-100.0f,64.05748f,0f,0f,0f,870,0.86250484f,0.36525184f,0.35025206f,0f,0f,0f ) ;
  }

  @Test
  public void test751() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-99.99968f,0.0f,0f,0f,0f,0f,0f,0f,0f,-19.43867f,29.557577f,5.18353f,0f,0f,0f,2597,0.7885026f,0.38420594f,-0.48025978f,0f,0f,0f ) ;
  }

  @Test
  public void test752() {
    TestDrivers.surfaceShade(0f,0f,-176.0f,0f,38.0f,167.0f,-449.0f,-64.0f,0f,0f,0f,0f,0f,-14.0f,420.0f,-191.0f,-566.0f,-64.0f,-399.0f,-708,-13.835549f,-18.300623f,-3.8936415f,0f,0f,84.72651f ) ;
  }

  @Test
  public void test753() {
    TestDrivers.surfaceShade(0f,0f,-187.0f,0f,674.0f,-3.0f,0f,604.0f,0f,0f,0f,0f,0f,-423.0f,336.0f,92.0f,858.0f,765.0f,597.0f,-1025,9.087576f,26.595495f,-55.348286f,0f,0f,-81.026634f ) ;
  }

  @Test
  public void test754() {
    TestDrivers.surfaceShade(0f,0f,-230.0f,0f,-978.0f,259.0f,361.0f,-234.0f,0f,0f,0f,0f,0f,-94.0f,-350.0f,394.0f,-270.0f,-537.0f,-918.0f,-780,14.926755f,94.38846f,-70.29505f,0f,0f,-98.73924f ) ;
  }

  @Test
  public void test755() {
    TestDrivers.surfaceShade(0f,0f,579.0f,0f,-100.0f,192.0f,849.0f,556.0f,0f,0f,0f,0f,0f,-74.0f,366.0f,949.0f,-161.0f,708.0f,754.0f,537,-34.092815f,26.91723f,74.11667f,0f,0f,4.1681466f ) ;
  }

  @Test
  public void test756() {
    TestDrivers.surfaceShade(0f,0f,-583.0f,0f,-630.0f,-626.0f,441.0f,-234.0f,0f,0f,0f,0f,0f,999.0f,-516.0f,-737.0f,-468.0f,525.0f,889.0f,162,46.034515f,31.73813f,78.35657f,0f,0f,51.630486f ) ;
  }

  @Test
  public void test757() {
    TestDrivers.surfaceShade(0f,0f,-714.0f,0f,532.0f,1.0f,0f,932.0f,0f,0f,0f,0f,0f,-328.0f,685.0f,-702.0f,-682.0f,-426.0f,844.0f,-82,8.769391f,-92.80068f,51.514267f,0f,0f,50.48306f ) ;
  }

  @Test
  public void test758() {
    TestDrivers.surfaceShade(0f,0f,-945.0f,0f,1017.0f,0.0f,0f,424.0f,0f,0f,0f,0f,0f,193.0f,109.0f,499.0f,528.0f,1823.0f,-975.0f,611,34.52237f,9.4150305f,-31.995275f,0f,0f,-60.890415f ) ;
  }

  @Test
  public void test759() {
    TestDrivers.surfaceShade(0f,0f,957.0f,0f,866.0f,650.0f,516.0f,219.0f,0f,0f,0f,0f,0f,163.0f,-803.0f,-465.0f,323.0f,-1585.0f,969.0f,-216,-85.44838f,71.29522f,118.050125f,0f,0f,27.954382f ) ;
  }

  @Test
  public void test760() {
    TestDrivers.surfaceShade(0f,0f,990.0f,0f,711.0f,153.0f,-318.0f,-944.0f,0f,0f,0f,0f,0f,665.0f,166.0f,-4.0f,412.0f,947.0f,-898.0f,-508,14.492486f,-109.50905f,60.83412f,0f,0f,-31.404629f ) ;
  }

  @Test
  public void test761() {
    TestDrivers.surfaceShade(0f,1123.0f,0f,0f,58.395924f,0.0f,0f,-76.94641f,0f,0f,0f,0f,0f,58.27671f,-80.71397f,9.028758f,0f,0f,0f,2,0.64138305f,0.37577376f,0.33622313f,0f,33.774986f,0f ) ;
  }

  @Test
  public void test762() {
    TestDrivers.surfaceShade(0f,-2.0f,0f,0f,0.033475433f,0.0f,0f,-61.97728f,0f,0f,0f,0f,0f,43.155346f,15.29289f,18.492987f,0f,0f,0f,1,0.6384391f,-0.42959246f,-1.1824547f,0f,-23.816595f,0f ) ;
  }

  @Test
  public void test763() {
    TestDrivers.surfaceShade(0f,2380.0f,0f,0f,4.315864f,0.0f,0f,-2.6124709f,0f,0f,0f,0f,0f,4.4903474f,95.90924f,100.0f,0f,0f,0f,2,0.090923265f,-0.8948011f,3.2913651f,0f,-43.35807f,0f ) ;
  }

  @Test
  public void test764() {
    TestDrivers.surfaceShade(0f,-2495.0f,0f,0f,728.0f,0.0f,0f,955.0f,0f,0f,0f,0f,0f,-536.0f,-201.0f,-34.0f,193.0f,577.0f,565.0f,1483,71.78066f,1.3368107f,67.102196f,0f,-35.550484f,0f ) ;
  }

  @Test
  public void test765() {
    TestDrivers.surfaceShade(0f,-27.0f,0f,0f,13.0f,-3.0f,0f,947.0f,0f,0f,0f,0f,0f,-567.0f,-278.0f,-881.0f,-39.0f,829.0f,617.0f,119,-113.51136f,-83.06769f,100.0f,0f,1.8791873f,0f ) ;
  }

  @Test
  public void test766() {
    TestDrivers.surfaceShade(0f,285.0f,0f,0f,548.0f,687.0f,644.0f,813.0f,0f,0f,0f,0f,0f,60.0f,164.0f,-162.0f,181.0f,56.0f,-761.0f,-305,44.90395f,-62.892735f,32.05473f,0f,24.619415f,0f ) ;
  }

  @Test
  public void test767() {
    TestDrivers.surfaceShade(0f,-3.0f,0f,0f,-966.0f,849.0f,357.0f,-670.0f,0f,0f,0f,0f,0f,868.0f,277.0f,-947.0f,-687.0f,-231.0f,132.0f,284,-97.64803f,37.22496f,-62.342987f,0f,-62.29336f,0f ) ;
  }

  @Test
  public void test768() {
    TestDrivers.surfaceShade(0f,479.0f,0f,0f,356.0f,527.0f,-958.0f,596.0f,0f,0f,0f,0f,0f,102.0f,-103.0f,122.0f,163.0f,190.0f,997.0f,-829,-75.96056f,40.61847f,-54.61936f,0f,74.78807f,0f ) ;
  }

  @Test
  public void test769() {
    TestDrivers.surfaceShade(0f,550.0f,0f,0f,592.0f,26.0f,-913.0f,-748.0f,0f,0f,0f,0f,0f,-918.0f,-662.0f,-712.0f,-141.0f,-990.0f,542.0f,168,-79.21441f,27.407936f,81.00069f,0f,47.8427f,0f ) ;
  }

  @Test
  public void test770() {
    TestDrivers.surfaceShade(0f,833.0f,0f,0f,-949.0f,-97.0f,608.0f,849.0f,0f,0f,0f,0f,0f,-277.0f,809.0f,-870.0f,26.0f,830.0f,976.0f,-829,89.596085f,-81.071526f,-72.77178f,0f,-71.61219f,0f ) ;
  }

  @Test
  public void test771() {
    TestDrivers.surfaceShade(0f,-866.0f,0f,0f,186.0f,-3.0f,0f,328.0f,0f,0f,0f,0f,0f,271.0f,-59.0f,-323.0f,-228.0f,751.0f,915.0f,836,14.672566f,-85.27455f,61.361996f,0f,79.92235f,0f ) ;
  }

  @Test
  public void test772() {
    TestDrivers.surfaceShade(0f,-91.0f,0f,0f,660.0f,491.0f,-641.0f,-433.0f,0f,0f,0f,0f,0f,174.0f,26.0f,-279.0f,-165.0f,-42.0f,-365.0f,448,11.457509f,43.369118f,47.108295f,0f,-24.412426f,0f ) ;
  }

  @Test
  public void test773() {
    TestDrivers.surfaceShade(1000.0f,0f,0f,0f,97.0f,940.0f,-1692.0f,132.0f,0f,0f,0f,0f,0f,786.0f,690.0f,-252.0f,114.0f,-302.0f,-525.0f,-1600,-0.17942087f,0.005331161f,-0.093496464f,-11.422366f,0f,0f ) ;
  }

  @Test
  public void test774() {
    TestDrivers.surfaceShade(-10.0f,-231.0f,0f,0f,119.0f,926.0f,0f,-690.0f,0f,0f,0f,0f,0f,-474.0f,860.0f,-323.0f,-701.0f,-522.0f,-262.0f,717,43.05038f,33.668934f,62.65028f,-8.027153f,-42.632553f,0f ) ;
  }

  @Test
  public void test775() {
    TestDrivers.surfaceShade(-102.0f,0f,0f,0f,100.0f,0.0f,0f,-35.29f,0f,0f,0f,0f,0f,167.46237f,8.46356f,100.0f,0f,0f,0f,2,2.1205246f,0.8414142f,0.276334f,-28.849005f,0f,0f ) ;
  }

  @Test
  public void test776() {
    TestDrivers.surfaceShade(1043.0f,655.0f,-1613.0f,0f,544.0f,-1468.0f,0f,216.0f,0f,0f,0f,0f,0f,-668.0f,481.0f,776.0f,1701.0f,-1501.0f,682.0f,849,5.63336f,-2.6444364f,6.488477f,100.0f,92.416374f,-32.121117f ) ;
  }

  @Test
  public void test777() {
    TestDrivers.surfaceShade(1048.0f,0f,-405.0f,0f,109.0f,1.0f,0f,-760.0f,0f,0f,0f,0f,0f,-307.0f,-546.0f,993.0f,0f,0f,0f,-1199,-65.62533f,34.19874f,-1.4848578f,12.025523f,0f,-32.95042f ) ;
  }

  @Test
  public void test778() {
    TestDrivers.surfaceShade(1052.0f,0f,0f,0f,462.0f,-155.0f,0f,1702.0f,0f,0f,0f,0f,0f,300.0f,847.0f,-1470.0f,944.0f,-1471.0f,1401.0f,-1334,40.33909f,72.87794f,50.22404f,0.7689858f,0f,0f ) ;
  }

  @Test
  public void test779() {
    TestDrivers.surfaceShade(1056.0f,-791.0f,434.0f,0f,84.0f,7.0f,0f,-554.0f,0f,0f,0f,0f,0f,-550.0f,-856.0f,664.0f,0f,0f,0f,-403,-11.7979145f,20.504568f,16.66123f,40.23002f,-59.15304f,70.07213f ) ;
  }

  @Test
  public void test780() {
    TestDrivers.surfaceShade(-1071.0f,556.0f,0f,0f,616.0f,1.0f,0f,-1443.0f,0f,0f,0f,0f,0f,-17.0f,-124.0f,-207.0f,0f,0f,0f,485,-91.60826f,-68.99637f,48.85454f,62.24859f,20.252665f,0f ) ;
  }

  @Test
  public void test781() {
    TestDrivers.surfaceShade(-109.0f,710.0f,0f,0f,520.0f,-429.0f,0f,294.0f,0f,0f,0f,0f,0f,-445.0f,442.0f,737.0f,1714.0f,868.0f,-1824.0f,-225,-74.18785f,63.94499f,-83.1442f,-15.371128f,19.407711f,0f ) ;
  }

  @Test
  public void test782() {
    TestDrivers.surfaceShade(1.0f,-293.0f,0f,-4.0f,0f,0f,0f,-22.548407f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-0.25f,8.532423E-4f,0f ) ;
  }

  @Test
  public void test783() {
    TestDrivers.surfaceShade(1100.0f,-1053.0f,-537.0f,0f,76.0f,56.0f,0f,705.0f,0f,0f,0f,0f,0f,17.0f,-608.0f,-467.0f,-1104.0f,1579.0f,1671.0f,-28,86.74968f,75.95102f,-95.724785f,91.82146f,-33.040806f,-65.648445f ) ;
  }

  @Test
  public void test784() {
    TestDrivers.surfaceShade(1100.0f,-18.0f,0f,-329.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-33.659203f,-2.4738586f,0f ) ;
  }

  @Test
  public void test785() {
    TestDrivers.surfaceShade(110.0f,-864.0f,0f,0f,225.0f,75.0f,0f,-285.0f,0f,0f,0f,0f,0f,-49.0f,-793.0f,242.0f,1093.0f,-747.0f,-125.0f,345,-31.301378f,32.265255f,99.39083f,59.846092f,-100.0f,0f ) ;
  }

  @Test
  public void test786() {
    TestDrivers.surfaceShade(1102.0f,194.0f,365.0f,0f,29.0f,793.0f,0f,-832.0f,0f,0f,0f,0f,0f,-431.0f,211.0f,1192.0f,230.0f,-811.0f,-845.0f,61,-88.12307f,49.099537f,-45.670757f,40.18728f,95.059135f,47.968643f ) ;
  }

  @Test
  public void test787() {
    TestDrivers.surfaceShade(-11.0f,-8.0f,0f,0f,33.0f,-1122.0f,0f,352.0f,0f,0f,0f,0f,0f,-410.0f,1567.0f,285.0f,96.0f,78.0f,-846.0f,-685,-0.8797565f,-0.21139863f,-0.10329304f,-100.0f,72.87416f,0f ) ;
  }

  @Test
  public void test788() {
    TestDrivers.surfaceShade(-1111.0f,0f,0f,0f,952.0f,219.0f,-1618.0f,-2.0f,0f,0f,0f,0f,0f,-346.0f,81.0f,-328.0f,469.0f,-1680.0f,-920.0f,-2170,-0.1140969f,0.14394991f,0.49323672f,12.336466f,0f,0f ) ;
  }

  @Test
  public void test789() {
    TestDrivers.surfaceShade(1120.0f,158.0f,0f,0f,580.0f,1672.0f,0f,-2265.0f,0f,0f,0f,0f,0f,-581.0f,617.0f,-147.0f,-672.0f,1453.0f,-532.0f,-934,-97.802124f,-77.414566f,61.62074f,32.22259f,88.84895f,0f ) ;
  }

  @Test
  public void test790() {
    TestDrivers.surfaceShade(-1123.0f,263.0f,-169.0f,0f,325.0f,917.0f,0f,439.0f,0f,0f,0f,0f,0f,-226.0f,-616.0f,-314.0f,646.0f,-424.0f,-77.0f,705,-100.0f,37.40461f,-1.4052228f,-60.135784f,30.214926f,37.77684f ) ;
  }

  @Test
  public void test791() {
    TestDrivers.surfaceShade(-1125.0f,-1696.0f,568.0f,0f,344.0f,756.0f,0f,645.0f,0f,0f,0f,0f,0f,-823.0f,1535.0f,823.0f,-1268.0f,-335.0f,-1385.0f,-2524,-0.12598053f,-0.6167279f,-0.22507384f,-23.494572f,-67.25362f,100.0f ) ;
  }

  @Test
  public void test792() {
    TestDrivers.surfaceShade(1143.0f,-613.0f,-279.0f,0f,86.0f,809.0f,0f,842.0f,0f,0f,0f,0f,0f,1052.0f,421.0f,-812.0f,-415.0f,-585.0f,1096.0f,-1103,-31.963968f,61.113605f,-9.725699f,100.0f,-17.34289f,-77.15344f ) ;
  }

  @Test
  public void test793() {
    TestDrivers.surfaceShade(1150.0f,0f,0f,0f,12.146301f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,-6.959721f,-52.136288f,0f,0f,0f,234,-0.8551278f,-0.005898681f,-0.4492797f,100.0f,0f,0f ) ;
  }

  @Test
  public void test794() {
    TestDrivers.surfaceShade(-1150.0f,44.0f,2581.0f,0f,165.0f,-638.0f,0f,-2135.0f,0f,0f,0f,0f,0f,-873.0f,-1468.0f,-1056.0f,0f,0f,0f,899,-0.29152358f,0.83303183f,-0.16907893f,-100.0f,1.7439035E-7f,89.475235f ) ;
  }

  @Test
  public void test795() {
    TestDrivers.surfaceShade(-115.0f,-49.0f,0f,0f,23.0f,1672.0f,0f,-873.0f,0f,0f,0f,0f,0f,720.0f,792.0f,289.0f,169.0f,-1153.0f,215.0f,303,-0.7747501f,0.28509557f,1.0431846f,-99.99018f,-67.214424f,0f ) ;
  }

  @Test
  public void test796() {
    TestDrivers.surfaceShade(1156.0f,-1239.0f,-1349.0f,0f,1269.0f,2030.0f,0f,1732.0f,0f,0f,0f,0f,0f,-40.0f,-1101.0f,-906.0f,-1683.0f,-410.0f,-121.0f,1040,28.129183f,-53.733166f,64.05634f,-88.39732f,43.479855f,34.180935f ) ;
  }

  @Test
  public void test797() {
    TestDrivers.surfaceShade(1156.0f,-550.0f,-1063.0f,0f,721.0f,-535.0f,0f,269.0f,0f,0f,0f,0f,0f,1227.0f,1220.0f,-38.0f,0.0f,-929.0f,1376.0f,355,-0.30859524f,0.22730081f,0.77130896f,57.171448f,-100.0f,13.182839f ) ;
  }

  @Test
  public void test798() {
    TestDrivers.surfaceShade(-1158.0f,-945.0f,0f,-1.0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-100.0f,0.0010582011f,0f ) ;
  }

  @Test
  public void test799() {
    TestDrivers.surfaceShade(116.0f,0f,0f,0f,19.42966f,0.0f,0f,-99.85064f,0f,0f,0f,0f,0f,-69.61449f,98.4355f,100.0f,0f,0f,0f,1,0.03810749f,0.14848071f,1.9325817f,-1.897023E-4f,0f,0f ) ;
  }

  @Test
  public void test800() {
    TestDrivers.surfaceShade(-1170.0f,-655.0f,-387.0f,432.0f,0f,0f,0f,-139.45079f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,76.07653f,27.458899f,-5.981434E-6f ) ;
  }

  @Test
  public void test801() {
    TestDrivers.surfaceShade(117.0f,-337.0f,0f,0f,289.0f,5.0f,0f,-592.0f,0f,0f,0f,0f,0f,-486.0f,123.0f,-860.0f,0f,0f,0f,1327,0.24957483f,0.028576797f,0.03272585f,61.14948f,-1.2164133f,0f ) ;
  }

  @Test
  public void test802() {
    TestDrivers.surfaceShade(-1176.0f,-375.0f,0f,0f,587.0f,538.0f,0f,253.0f,0f,0f,0f,0f,0f,-451.0f,90.0f,-1102.0f,-335.0f,-475.0f,113.0f,149,-55.19584f,9.376847f,73.176155f,44.66215f,-48.14685f,0f ) ;
  }

  @Test
  public void test803() {
    TestDrivers.surfaceShade(-1184.0f,890.0f,1323.0f,0f,229.0f,964.0f,0f,207.0f,0f,0f,0f,0f,0f,-469.0f,325.0f,627.0f,1123.0f,-605.0f,-238.0f,-335,0.3928011f,0.8911577f,-0.17294541f,86.89206f,95.64767f,77.36736f ) ;
  }

  @Test
  public void test804() {
    TestDrivers.surfaceShade(1200.0f,-1091.0f,770.0f,0f,567.0f,-170.0f,0f,-276.0f,0f,0f,0f,0f,0f,87.0f,-601.0f,767.0f,0f,0f,0f,-474,-0.18809676f,0.48500088f,0.15613194f,0.95579636f,60.20817f,-10.337071f ) ;
  }

  @Test
  public void test805() {
    TestDrivers.surfaceShade(-1204.0f,688.0f,-1526.0f,0f,954.0f,-242.0f,0f,-936.0f,0f,0f,0f,0f,0f,402.0f,712.0f,-136.0f,0f,0f,0f,-2191,98.95775f,-66.976166f,-58.132465f,100.0f,100.0f,-90.309784f ) ;
  }

  @Test
  public void test806() {
    TestDrivers.surfaceShade(1207.0f,0f,0f,0f,1754.0f,1165.0f,-351.0f,-3.0f,0f,0f,0f,0f,0f,-1569.0f,382.0f,-411.0f,-425.0f,1518.0f,700.0f,-480,-0.004067817f,0.015448618f,0.65692043f,39.14699f,0f,0f ) ;
  }

  @Test
  public void test807() {
    TestDrivers.surfaceShade(-1207.0f,530.0f,0f,0f,807.0f,-2667.0f,0f,-662.0f,0f,0f,0f,0f,0f,-486.0f,-423.0f,-192.0f,0f,0f,0f,1027,0.5278788f,-0.4204297f,-0.23718098f,-10.354623f,-41.574497f,0f ) ;
  }

  @Test
  public void test808() {
    TestDrivers.surfaceShade(-122.0f,-1297.0f,0f,0f,995.0f,2.0f,0f,-2719.0f,0f,0f,0f,0f,0f,641.0f,-1649.0f,1503.0f,0f,0f,0f,1544,0.42863154f,-0.30358055f,-0.5290426f,1.2187624f,-64.76097f,0f ) ;
  }

  @Test
  public void test809() {
    TestDrivers.surfaceShade(-123.0f,918.0f,880.0f,0f,718.0f,941.0f,0f,332.0f,0f,0f,0f,0f,0f,144.0f,-146.0f,106.0f,-77.0f,-1073.0f,1543.0f,-160,47.357456f,83.23361f,50.307865f,68.158875f,-34.394573f,-100.0f ) ;
  }

  @Test
  public void test810() {
    TestDrivers.surfaceShade(1242.0f,-1387.0f,0f,0f,798.0f,-337.0f,0f,-2524.0f,0f,0f,0f,0f,0f,752.0f,-263.0f,-443.0f,0f,0f,0f,-4,0.042110622f,-0.4683115f,1.4810289f,-90.16486f,-59.62887f,0f ) ;
  }

  @Test
  public void test811() {
    TestDrivers.surfaceShade(1250.0f,647.0f,0f,0f,102.0f,191.0f,0f,330.0f,0f,0f,0f,0f,0f,314.0f,-151.0f,-348.0f,-1843.0f,109.0f,-440.0f,2057,1.7209438f,0.40255067f,1.3781357f,82.80458f,-3.1758652f,0f ) ;
  }

  @Test
  public void test812() {
    TestDrivers.surfaceShade(-125.0f,0f,0f,0f,519.0f,-539.0f,0f,934.0f,0f,0f,0f,0f,0f,-921.0f,659.0f,-341.0f,-414.0f,959.0f,776.0f,-293,75.771866f,-0.7083597f,30.646595f,-63.726006f,0f,0f ) ;
  }

  @Test
  public void test813() {
    TestDrivers.surfaceShade(1254.0f,1077.0f,0f,0f,202.0f,-934.0f,0f,1344.0f,0f,0f,0f,0f,0f,-456.0f,119.0f,1343.0f,496.0f,-2178.0f,-1873.0f,765,-0.76006764f,-0.24536873f,-0.23633058f,100.0f,68.00029f,0f ) ;
  }

  @Test
  public void test814() {
    TestDrivers.surfaceShade(-1260.0f,1570.0f,577.0f,0f,66.0f,-631.0f,0f,1283.0f,0f,0f,0f,0f,0f,257.0f,8.0f,-379.0f,-1349.0f,1142.0f,507.0f,1330,-0.7875708f,-0.5301073f,0.044194207f,-32.40814f,-100.0f,-29.820791f ) ;
  }

  @Test
  public void test815() {
    TestDrivers.surfaceShade(-127.0f,0f,0f,-738.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,28.905403f,0f,0f ) ;
  }

  @Test
  public void test816() {
    TestDrivers.surfaceShade(128.0f,-355.0f,620.0f,0f,661.0f,423.0f,0f,402.0f,0f,0f,0f,0f,0f,225.0f,-173.0f,244.0f,856.0f,-1545.0f,-1265.0f,1086,-68.52423f,-14.689135f,52.773495f,-100.0f,52.119095f,-29.841772f ) ;
  }

  @Test
  public void test817() {
    TestDrivers.surfaceShade(-128.0f,852.0f,0f,0f,751.0f,-645.0f,0f,-283.0f,0f,0f,0f,0f,0f,927.0f,-455.0f,290.0f,0f,0f,0f,527,-38.487698f,-20.958364f,90.14496f,-89.161514f,23.973637f,0f ) ;
  }

  @Test
  public void test818() {
    TestDrivers.surfaceShade(-1283.0f,0f,0f,0f,100.0f,0.0f,0f,-0.0018267375f,0f,0f,0f,0f,0f,-60.92859f,100.0f,-100.0f,0f,0f,0f,2,0.43001378f,0.7250418f,0.57776904f,98.867714f,0f,0f ) ;
  }

  @Test
  public void test819() {
    TestDrivers.surfaceShade(1286.0f,338.0f,-19.0f,-372.0f,0f,0f,0f,-7.888609E-31f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,100.0f,-10.170062f,1.4148274E-4f ) ;
  }

  @Test
  public void test820() {
    TestDrivers.surfaceShade(130.0f,0f,0f,0f,40.0f,1319.0f,0f,3541.0f,0f,0f,0f,0f,0f,351.0f,-123.0f,-783.0f,-826.0f,106.0f,-1263.0f,670,96.26222f,-66.49936f,53.598293f,-1.0572972f,0f,0f ) ;
  }

  @Test
  public void test821() {
    TestDrivers.surfaceShade(1314.0f,589.0f,135.0f,0f,20.0f,-1966.0f,0f,181.0f,0f,0f,0f,0f,0f,556.0f,-172.0f,-664.0f,98.0f,-190.0f,872.0f,-749,17.803188f,89.05107f,-8.159957f,43.199066f,27.145456f,100.0f ) ;
  }

  @Test
  public void test822() {
    TestDrivers.surfaceShade(132.0f,-1250.0f,0f,0f,547.0f,520.0f,0f,1534.0f,0f,0f,0f,0f,0f,-145.0f,-406.0f,-483.0f,169.0f,136.0f,810.0f,-952,1.8410121f,26.23956f,-22.609125f,81.85149f,-100.0f,0f ) ;
  }

  @Test
  public void test823() {
    TestDrivers.surfaceShade(-1332.0f,344.0f,0f,0f,204.0f,-801.0f,0f,-3.0f,0f,0f,0f,0f,0f,-969.0f,2084.0f,-429.0f,0f,0f,0f,-1917,0.49862954f,0.08036745f,-0.648183f,-17.230001f,22.12895f,0f ) ;
  }

  @Test
  public void test824() {
    TestDrivers.surfaceShade(1335.0f,1807.0f,-596.0f,0f,37.0f,-587.0f,0f,-708.0f,0f,0f,0f,0f,0f,188.0f,-843.0f,-452.0f,0f,0f,0f,-787,-0.95795965f,-0.099726625f,-0.2124488f,-97.60615f,90.14129f,-4.373277f ) ;
  }

  @Test
  public void test825() {
    TestDrivers.surfaceShade(1339.0f,0f,0f,0f,84.85282f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-49.445576f,100.0f,-78.4068f,0f,0f,0f,4,-0.9166797f,-0.12090495f,1.3325149f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test826() {
    TestDrivers.surfaceShade(-1352.0f,356.0f,0f,0f,8.0f,-1.0f,0f,-444.0f,0f,0f,0f,0f,0f,243.0f,138.0f,343.0f,0f,0f,0f,846,-0.4321293f,0.11574062f,0.25957322f,105.89778f,-29.97323f,0f ) ;
  }

  @Test
  public void test827() {
    TestDrivers.surfaceShade(1353.0f,-844.0f,0f,0f,146.0f,-66.0f,0f,317.0f,0f,0f,0f,0f,0f,-646.0f,-120.0f,398.0f,-12.0f,60.0f,46.0f,864,-43.573425f,64.359505f,-81.55012f,-0.3992826f,2.7601228f,0f ) ;
  }

  @Test
  public void test828() {
    TestDrivers.surfaceShade(1381.0f,493.0f,0f,0f,36.0f,-44.0f,0f,-491.0f,0f,0f,0f,0f,0f,-771.0f,-764.0f,-865.0f,0f,0f,0f,-531,-0.73701197f,0.9487506f,-0.18105114f,27.38644f,93.39088f,0f ) ;
  }

  @Test
  public void test829() {
    TestDrivers.surfaceShade(1392.0f,1094.0f,0f,0f,1031.0f,-176.0f,0f,243.0f,0f,0f,0f,0f,0f,1405.0f,332.0f,-415.0f,-1169.0f,392.0f,-843.0f,883,-0.60910505f,0.20018457f,0.37258762f,49.4585f,48.945076f,0f ) ;
  }

  @Test
  public void test830() {
    TestDrivers.surfaceShade(1394.0f,-2154.0f,-1303.0f,-3.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,99.57885f,-114.25931f,2.558199E-4f ) ;
  }

  @Test
  public void test831() {
    TestDrivers.surfaceShade(140.0f,-215.0f,0f,0f,1285.0f,1.0f,0f,-1.0f,0f,0f,0f,0f,0f,-507.0f,536.0f,17.0f,0f,0f,0f,831,15.758075f,-83.589745f,94.79787f,19.87188f,100.0f,0f ) ;
  }

  @Test
  public void test832() {
    TestDrivers.surfaceShade(-1405.0f,0f,639.0f,0f,740.0f,-4.0f,0f,-3694.0f,0f,0f,0f,0f,0f,-116.0f,-4.0f,-106.0f,0f,0f,0f,-7,-24.851175f,-81.01797f,30.252909f,-39.131733f,0f,100.0f ) ;
  }

  @Test
  public void test833() {
    TestDrivers.surfaceShade(-1423.0f,0f,0f,0f,8.716986f,0.0f,0f,-65.3502f,0f,0f,0f,0f,0f,0.12990174f,30.605612f,4.538758f,0f,0f,0f,-1,-0.6910457f,0.036826167f,-1.8858596f,-76.152626f,0f,0f ) ;
  }

  @Test
  public void test834() {
    TestDrivers.surfaceShade(-144.0f,-45.0f,0f,0f,228.0f,1018.0f,-711.0f,2244.0f,0f,0f,0f,0f,0f,1062.0f,-362.0f,-682.0f,-520.0f,110.0f,626.0f,392,11.653946f,22.557665f,6.173924f,-111.51655f,95.72281f,0f ) ;
  }

  @Test
  public void test835() {
    TestDrivers.surfaceShade(1448.0f,-156.0f,0f,0f,2773.0f,-953.0f,0f,-827.0f,0f,0f,0f,0f,0f,1640.0f,-1065.0f,-261.0f,0f,0f,0f,2,-1.5275844f,-7.5520906f,3.7814465f,76.25248f,-30.625444f,0f ) ;
  }

  @Test
  public void test836() {
    TestDrivers.surfaceShade(-1458.0f,-1974.0f,-15.0f,0f,68.0f,3227.0f,0f,-901.0f,0f,0f,0f,0f,0f,-333.0f,678.0f,-914.0f,864.0f,-533.0f,1094.0f,471,-100.0f,-62.926785f,-10.24547f,100.0f,100.0f,-14.051616f ) ;
  }

  @Test
  public void test837() {
    TestDrivers.surfaceShade(-1463.0f,-708.0f,0f,0f,176.0f,-2.0f,0f,-633.0f,0f,0f,0f,0f,0f,-560.0f,-617.0f,-1116.0f,0f,0f,0f,-176,0.67766124f,0.24498904f,0.1426944f,83.17702f,-76.93195f,0f ) ;
  }

  @Test
  public void test838() {
    TestDrivers.surfaceShade(-147.0f,357.0f,-37.0f,5.0f,0f,0f,0f,-63.043354f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-0.0013605442f,-26.693016f,-0.0054054055f ) ;
  }

  @Test
  public void test839() {
    TestDrivers.surfaceShade(148.0f,-74.0f,398.0f,0f,1864.0f,-962.0f,0f,288.0f,0f,0f,0f,0f,0f,969.0f,833.0f,-408.0f,894.0f,-2181.0f,761.0f,-1824,-0.6585919f,0.58869815f,0.29034883f,-100.0f,-99.95092f,100.0f ) ;
  }

  @Test
  public void test840() {
    TestDrivers.surfaceShade(148.0f,955.0f,174.0f,0f,763.0f,717.0f,0f,-119.0f,0f,0f,0f,0f,0f,-687.0f,-44.0f,-211.0f,664.0f,-550.0f,1411.0f,785,23.733667f,-16.113094f,-73.91495f,66.55024f,89.531456f,-25.024511f ) ;
  }

  @Test
  public void test841() {
    TestDrivers.surfaceShade(1486.0f,0f,0f,0f,1436.0f,-1011.0f,0f,999.0f,0f,0f,0f,0f,0f,62.0f,841.0f,1166.0f,925.0f,-1042.0f,-197.0f,294,0.30778605f,-0.25349373f,0.046163235f,7.3031077f,0f,0f ) ;
  }

  @Test
  public void test842() {
    TestDrivers.surfaceShade(-1494.0f,647.0f,-606.0f,0f,659.0f,507.0f,0f,343.0f,0f,0f,0f,0f,0f,302.0f,995.0f,-2248.0f,764.0f,-797.0f,244.0f,-542,-0.7173605f,-0.29716927f,0.3279029f,-1.8483452f,-100.0f,6.780293f ) ;
  }

  @Test
  public void test843() {
    TestDrivers.surfaceShade(-1499.0f,0f,0f,0f,100.0f,-33.276985f,0f,-26.080032f,0f,0f,0f,0f,0f,78.789276f,-71.20083f,76.99529f,0f,0f,0f,98,-0.27507487f,-0.079146035f,0.09037201f,42.276077f,0f,0f ) ;
  }

  @Test
  public void test844() {
    TestDrivers.surfaceShade(-150.0f,462.0f,0f,0f,544.0f,-1.0f,0f,-1.0f,0f,0f,0f,0f,0f,-422.0f,308.0f,305.0f,0f,0f,0f,560,99.38932f,60.977325f,75.938614f,-96.59883f,100.0f,0f ) ;
  }

  @Test
  public void test845() {
    TestDrivers.surfaceShade(-1505.0f,605.0f,0f,0f,2451.0f,0.0f,0f,-415.0f,0f,0f,0f,0f,0f,458.0f,234.0f,-264.0f,0f,0f,0f,-77,-44.61402f,43.54429f,-38.802494f,-100.0f,99.998116f,0f ) ;
  }

  @Test
  public void test846() {
    TestDrivers.surfaceShade(-1507.0f,-1088.0f,0f,0f,821.0f,-30.0f,0f,-1.0f,0f,0f,0f,0f,0f,448.0f,-312.0f,-314.0f,0f,0f,0f,956,-0.17125884f,0.77755076f,0.08782116f,-100.0f,-7.834621f,0f ) ;
  }

  @Test
  public void test847() {
    TestDrivers.surfaceShade(15.0f,278.0f,992.0f,10.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,100.0f,3.5971223E-4f,-73.4977f ) ;
  }

  @Test
  public void test848() {
    TestDrivers.surfaceShade(-1513.0f,0f,0f,-407.0f,0f,0f,0f,3.3300383f,0f,0f,0f,0f,0f,-41.72161f,62.71213f,27.895756f,-524.0f,-676.0f,736.0f,0,0f,0f,0f,-17.48919f,0f,0f ) ;
  }

  @Test
  public void test849() {
    TestDrivers.surfaceShade(152.0f,-582.0f,0f,0f,157.0f,-1.0f,0f,-488.0f,0f,0f,0f,0f,0f,341.0f,-272.0f,-1540.0f,0f,0f,0f,-967,-0.37781808f,0.38980755f,0.6649455f,38.93125f,73.961464f,0f ) ;
  }

  @Test
  public void test850() {
    TestDrivers.surfaceShade(-153.0f,-235.0f,-796.0f,0f,1.0f,872.0f,0f,-205.0f,0f,0f,0f,0f,0f,-845.0f,824.0f,670.0f,-103.0f,-1245.0f,132.0f,482,63.676632f,21.244564f,31.636337f,100.0f,-2.8171806E-7f,45.729248f ) ;
  }

  @Test
  public void test851() {
    TestDrivers.surfaceShade(153.0f,-472.0f,0f,0f,250.0f,-942.0f,0f,3.0f,0f,0f,0f,0f,0f,-954.0f,770.0f,23.0f,0f,0f,0f,398,19.907614f,-10.217133f,161.9106f,0.07728139f,-39.107433f,0f ) ;
  }

  @Test
  public void test852() {
    TestDrivers.surfaceShade(-1534.0f,0f,0f,0f,199.0f,605.0f,-444.0f,885.0f,0f,0f,0f,0f,0f,-183.0f,-54.0f,718.0f,-1324.0f,-76.0f,-319.0f,-652,-75.37443f,25.738134f,-24.480537f,-55.313362f,0f,0f ) ;
  }

  @Test
  public void test853() {
    TestDrivers.surfaceShade(-1534.0f,-207.0f,-843.0f,0f,1237.0f,-2602.0f,0f,76.0f,0f,0f,0f,0f,0f,480.0f,26.0f,340.0f,1359.0f,547.0f,310.0f,-137,44.319855f,16.323576f,-63.817482f,-33.85465f,-13.790527f,-3.402457f ) ;
  }

  @Test
  public void test854() {
    TestDrivers.surfaceShade(1546.0f,1209.0f,960.0f,0f,817.0f,-1297.0f,0f,567.0f,0f,0f,0f,0f,0f,-959.0f,-946.0f,703.0f,-1753.0f,-580.0f,1154.0f,-2281,96.405205f,-93.84895f,5.22259f,-55.630737f,-99.99702f,-100.0f ) ;
  }

  @Test
  public void test855() {
    TestDrivers.surfaceShade(-155.0f,581.0f,-922.0f,0f,389.0f,-209.0f,0f,194.0f,0f,0f,0f,0f,0f,706.0f,-200.0f,-344.0f,125.0f,275.0f,-861.0f,-220,-63.333126f,13.0716915f,9.0393505f,-24.120785f,-49.35966f,50.92618f ) ;
  }

  @Test
  public void test856() {
    TestDrivers.surfaceShade(1557.0f,0f,0f,0f,789.0f,476.0f,0f,1303.0f,0f,0f,0f,0f,0f,1352.0f,-2073.0f,1663.0f,-206.0f,-103.0f,-1142.0f,1128,-0.21692228f,-0.37252727f,-0.4461047f,75.32334f,0f,0f ) ;
  }

  @Test
  public void test857() {
    TestDrivers.surfaceShade(1572.0f,0f,0f,0f,1.090911E-5f,-39.62892f,0f,1.3877788E-17f,0f,0f,0f,0f,0f,-100.0f,100.0f,46.263916f,0f,0f,0f,1,-0.35120118f,-0.12226001f,-0.62190586f,9.291464f,0f,0f ) ;
  }

  @Test
  public void test858() {
    TestDrivers.surfaceShade(-1594.0f,0f,0f,0f,43.44348f,-31.87712f,0f,-36.38619f,0f,0f,0f,0f,0f,11.201322f,18.999182f,-2.3570645f,0f,0f,0f,-283,0.19567838f,-0.04445074f,0.57163525f,-0.27564546f,0f,0f ) ;
  }

  @Test
  public void test859() {
    TestDrivers.surfaceShade(-1600.0f,0f,0f,0f,33.44566f,0.0f,0f,-91.65595f,0f,0f,0f,0f,0f,-60.970528f,23.34278f,-100.0f,0f,0f,0f,-1036,0.03188487f,-0.9993404f,-0.017379925f,-49.533916f,0f,0f ) ;
  }

  @Test
  public void test860() {
    TestDrivers.surfaceShade(-1618.0f,557.0f,-182.0f,0f,1991.0f,93.0f,0f,-1381.0f,0f,0f,0f,0f,0f,-137.0f,-396.0f,-313.0f,-1465.0f,1330.0f,-567.0f,102,86.81811f,7.828233f,-47.90435f,46.456554f,52.063953f,-78.57193f ) ;
  }

  @Test
  public void test861() {
    TestDrivers.surfaceShade(1623.0f,476.0f,1501.0f,0f,474.0f,-377.0f,0f,175.0f,0f,0f,0f,0f,0f,-899.0f,555.0f,728.0f,639.0f,136.0f,-678.0f,-117,75.8453f,35.534393f,66.57051f,5.445277f,-24.797962f,-17.633287f ) ;
  }

  @Test
  public void test862() {
    TestDrivers.surfaceShade(1624.0f,-494.0f,588.0f,0f,1048.0f,-85.0f,0f,810.0f,0f,0f,0f,0f,0f,539.0f,605.0f,78.0f,1505.0f,703.0f,-1534.0f,-420,-98.70856f,100.0f,-93.539604f,-100.0f,2.7796352f,-58.163532f ) ;
  }

  @Test
  public void test863() {
    TestDrivers.surfaceShade(1642.0f,0f,0f,0f,69.39229f,-100.0f,0f,0.0f,0f,0f,0f,0f,0f,-78.74976f,100.0f,76.01925f,0f,0f,0f,-1,1.0688722f,-0.070217125f,0.28900477f,-37.1252f,0f,0f ) ;
  }

  @Test
  public void test864() {
    TestDrivers.surfaceShade(1649.0f,-239.0f,0f,0f,1300.0f,-745.0f,0f,-58.0f,0f,0f,0f,0f,0f,769.0f,-822.0f,623.0f,0f,0f,0f,-1086,5.0250263f,56.86876f,68.83126f,92.70445f,-75.34536f,0f ) ;
  }

  @Test
  public void test865() {
    TestDrivers.surfaceShade(-1680.0f,0f,0f,0f,98.34064f,-49.982754f,0f,0.0f,0f,0f,0f,0f,0f,-47.22613f,-19.738636f,42.076096f,0f,0f,0f,-262,0.9355524f,-0.26095748f,0.15209204f,-29.780489f,0f,0f ) ;
  }

  @Test
  public void test866() {
    TestDrivers.surfaceShade(-1684.0f,-796.0f,269.0f,0f,742.0f,-922.0f,0f,1081.0f,0f,0f,0f,0f,0f,-155.0f,-1445.0f,-246.0f,1334.0f,1198.0f,-90.0f,1112,-0.123259f,0.27280715f,-0.03388653f,100.0f,-23.694164f,-29.515835f ) ;
  }

  @Test
  public void test867() {
    TestDrivers.surfaceShade(-170.0f,-546.0f,-105.0f,0f,106.0f,-881.0f,0f,393.0f,0f,0f,0f,0f,0f,-683.0f,-14.0f,35.0f,1380.0f,-827.0f,-659.0f,-743,19.296864f,-57.54845f,42.088707f,-78.66367f,88.102745f,34.07725f ) ;
  }

  @Test
  public void test868() {
    TestDrivers.surfaceShade(-1708.0f,-554.0f,779.0f,0f,687.0f,-3479.0f,0f,1015.0f,0f,0f,0f,0f,0f,1020.0f,-627.0f,372.0f,-432.0f,-1631.0f,327.0f,-860,-25.015038f,-35.99236f,7.925079f,93.25712f,7.2068563f,-70.96459f ) ;
  }

  @Test
  public void test869() {
    TestDrivers.surfaceShade(1709.0f,889.0f,0f,155.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-7.9823403f,7.2571574E-6f,0f ) ;
  }

  @Test
  public void test870() {
    TestDrivers.surfaceShade(171.0f,-667.0f,0f,0f,4.0f,1175.0f,0f,1153.0f,0f,0f,0f,0f,0f,-539.0f,105.0f,204.0f,-313.0f,-282.0f,-518.0f,-246,50.752968f,92.22637f,86.62785f,-87.52229f,-25.717848f,0f ) ;
  }

  @Test
  public void test871() {
    TestDrivers.surfaceShade(-1714.0f,-1282.0f,-402.0f,-513.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,42.611103f,-23.676441f,4.849049E-6f ) ;
  }

  @Test
  public void test872() {
    TestDrivers.surfaceShade(1722.0f,857.0f,0f,0f,893.0f,-788.0f,0f,2.0f,0f,0f,0f,0f,0f,738.0f,1006.0f,-1834.0f,0f,0f,0f,-1559,0.97245145f,0.20482093f,0.6118316f,-12.338543f,53.583817f,0f ) ;
  }

  @Test
  public void test873() {
    TestDrivers.surfaceShade(1724.0f,833.0f,2062.0f,0f,463.0f,-464.0f,0f,115.0f,0f,0f,0f,0f,0f,-920.0f,689.0f,143.0f,814.0f,993.0f,1152.0f,-316,41.13644f,67.45068f,-60.33563f,7.3631105f,-74.5111f,46.71116f ) ;
  }

  @Test
  public void test874() {
    TestDrivers.surfaceShade(-173.0f,-2204.0f,-687.0f,837.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,-100.0f,82.04442f,-17.172407f ) ;
  }

  @Test
  public void test875() {
    TestDrivers.surfaceShade(1734.0f,-699.0f,-2799.0f,0f,141.0f,-1329.0f,0f,-1073.0f,0f,0f,0f,0f,0f,401.0f,108.0f,219.0f,0f,0f,0f,-423,-6.780587f,-3.477586f,14.130569f,73.551575f,55.064148f,-96.106415f ) ;
  }

  @Test
  public void test876() {
    TestDrivers.surfaceShade(1739.0f,1257.0f,997.0f,0f,8.0f,-537.0f,0f,906.0f,0f,0f,0f,0f,0f,-195.0f,840.0f,-524.0f,-569.0f,-508.0f,462.0f,-536,50.294544f,-73.1556f,-133.76424f,88.30786f,42.77559f,-29.431442f ) ;
  }

  @Test
  public void test877() {
    TestDrivers.surfaceShade(-174.0f,658.0f,0f,0f,739.0f,-603.0f,0f,891.0f,0f,0f,0f,0f,0f,1701.0f,22.0f,-725.0f,-221.0f,936.0f,12.0f,808,-17.594156f,60.414825f,30.853626f,92.09487f,99.40264f,0f ) ;
  }

  @Test
  public void test878() {
    TestDrivers.surfaceShade(1772.0f,0f,0f,0f,85.06415f,0.0f,0f,-23.358156f,0f,0f,0f,0f,0f,100.0f,73.239746f,-3.9511695f,0f,0f,0f,1,0.15876056f,-1.7171137f,0.74646574f,-92.48526f,0f,0f ) ;
  }

  @Test
  public void test879() {
    TestDrivers.surfaceShade(-1776.0f,-264.0f,56.0f,0f,202.0f,1358.0f,0f,45.0f,0f,0f,0f,0f,0f,535.0f,272.0f,228.0f,-915.0f,-401.0f,531.0f,1104,17.948305f,-28.919209f,-7.6154346f,-13.188335f,-7.5750484f,-23.67129f ) ;
  }

  @Test
  public void test880() {
    TestDrivers.surfaceShade(-179.0f,0f,0f,0f,66.425865f,-4.252283f,0f,0.0f,0f,0f,0f,0f,0f,2.1078992f,-55.719467f,19.42492f,0f,0f,0f,3,-0.12440924f,0.29901633f,-0.5221501f,65.29844f,0f,0f ) ;
  }

  @Test
  public void test881() {
    TestDrivers.surfaceShade(-179.0f,-1413.0f,-972.0f,0f,10.0f,-358.0f,0f,-1032.0f,0f,0f,0f,0f,0f,-532.0f,859.0f,-194.0f,0f,0f,0f,312,-98.89469f,-49.50371f,52.00149f,-99.999985f,-57.10488f,-26.40953f ) ;
  }

  @Test
  public void test882() {
    TestDrivers.surfaceShade(1804.0f,0f,0f,0f,17.24395f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,81.87639f,35.193356f,0f,0f,0f,-2,-0.054720864f,-0.5442894f,-2.0273035f,85.52269f,0f,0f ) ;
  }

  @Test
  public void test883() {
    TestDrivers.surfaceShade(18.0f,-493.0f,0f,0f,540.0f,-118.0f,0f,-1.0f,0f,0f,0f,0f,0f,-684.0f,261.0f,-1212.0f,0f,0f,0f,-1806,144.25389f,-5.1485605f,92.76586f,-11.210839f,167.4243f,0f ) ;
  }

  @Test
  public void test884() {
    TestDrivers.surfaceShade(-182.0f,0f,0f,0f,118.0f,842.0f,-283.0f,-696.0f,0f,0f,0f,0f,0f,1450.0f,-912.0f,-937.0f,118.0f,-2016.0f,885.0f,-254,-0.63083917f,0.38191512f,0.28077063f,42.647476f,0f,0f ) ;
  }

  @Test
  public void test885() {
    TestDrivers.surfaceShade(1826.0f,411.0f,915.0f,0f,19.0f,-480.0f,0f,-401.0f,0f,0f,0f,0f,0f,911.0f,-22.0f,-761.0f,0f,0f,0f,579,-0.4563164f,0.48953396f,-0.5138706f,64.41779f,3.615552E-6f,-86.57234f ) ;
  }

  @Test
  public void test886() {
    TestDrivers.surfaceShade(-1827.0f,-494.0f,1212.0f,0f,994.0f,10.0f,0f,-937.0f,0f,0f,0f,0f,0f,-554.0f,-589.0f,-755.0f,1764.0f,437.0f,-759.0f,-438,0.63232964f,0.66865796f,-0.17944044f,20.93436f,-0.031024102f,8.303714f ) ;
  }

  @Test
  public void test887() {
    TestDrivers.surfaceShade(-1832.0f,-25.0f,0f,895.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-1.102735f,-4.4692737E-5f,0f ) ;
  }

  @Test
  public void test888() {
    TestDrivers.surfaceShade(-1868.0f,863.0f,-439.0f,0f,286.0f,1.0f,0f,-54.0f,0f,0f,0f,0f,0f,496.0f,-488.0f,-281.0f,0f,0f,0f,-1506,-19.10526f,148.4441f,-93.464745f,-20.650145f,81.65656f,67.06935f ) ;
  }

  @Test
  public void test889() {
    TestDrivers.surfaceShade(-188.0f,280.0f,218.0f,0f,10.0f,692.0f,0f,-896.0f,0f,0f,0f,0f,0f,436.0f,-504.0f,316.0f,-651.0f,770.0f,688.0f,184,-10.001506f,13.927616f,1.5072378f,43.32003f,-57.252056f,-3.9450166f ) ;
  }

  @Test
  public void test890() {
    TestDrivers.surfaceShade(193.0f,0f,0f,0f,57.464027f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,-2.5112195f,26.825092f,-8.336694f,0f,0f,0f,2,0.1476489f,0.12980688f,0.5016049f,-4.778014f,0f,0f ) ;
  }

  @Test
  public void test891() {
    TestDrivers.surfaceShade(193.0f,-1085.0f,-1025.0f,0f,211.0f,1179.0f,0f,216.0f,0f,0f,0f,0f,0f,398.0f,311.0f,-612.0f,-916.0f,702.0f,288.0f,-312,83.35866f,-76.11776f,15.529611f,-80.03492f,-87.526886f,-74.972115f ) ;
  }

  @Test
  public void test892() {
    TestDrivers.surfaceShade(193.0f,254.0f,-1272.0f,0f,233.0f,906.0f,0f,602.0f,0f,0f,0f,0f,0f,-368.0f,-1456.0f,123.0f,1237.0f,98.0f,-186.0f,509,-0.23076211f,18.37221f,66.85028f,0.27564716f,65.97532f,-31.491064f ) ;
  }

  @Test
  public void test893() {
    TestDrivers.surfaceShade(-193.0f,352.0f,0f,0f,265.0f,-23.0f,0f,-1264.0f,0f,0f,0f,0f,0f,-350.0f,-436.0f,-65.0f,0f,0f,0f,288,0.0240905f,-0.02838414f,0.060674246f,-86.481285f,0.6450064f,0f ) ;
  }

  @Test
  public void test894() {
    TestDrivers.surfaceShade(1941.0f,-72.0f,1665.0f,895.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,55.957977f,-61.278435f,-3.0265577f ) ;
  }

  @Test
  public void test895() {
    TestDrivers.surfaceShade(-197.0f,1105.0f,471.0f,-5.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,85.30029f,-100.0f,-50.373756f ) ;
  }

  @Test
  public void test896() {
    TestDrivers.surfaceShade(197.0f,-243.0f,828.0f,0f,365.0f,-615.0f,0f,11.0f,0f,0f,0f,0f,0f,227.0f,-124.0f,-149.0f,-1262.0f,138.0f,938.0f,-1834,-0.2576963f,-0.07154489f,0.2754215f,57.923084f,33.790882f,76.67832f ) ;
  }

  @Test
  public void test897() {
    TestDrivers.surfaceShade(-199.0f,-487.0f,0f,0f,1077.0f,2.0f,0f,-1723.0f,0f,0f,0f,0f,0f,-201.0f,705.0f,-408.0f,0f,0f,0f,-705,0.023045164f,-0.3883195f,-0.68234634f,-0.6580591f,27.035017f,0f ) ;
  }

  @Test
  public void test898() {
    TestDrivers.surfaceShade(-20.0f,-235.0f,-971.0f,53.0f,0f,0f,0f,-99.12495f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-9.4339624E-4f,82.70683f,44.562073f ) ;
  }

  @Test
  public void test899() {
    TestDrivers.surfaceShade(-20.0f,-437.0f,674.0f,0f,20.0f,1628.0f,0f,1730.0f,0f,0f,0f,0f,0f,373.0f,135.0f,985.0f,-418.0f,590.0f,-473.0f,326,100.0f,49.25452f,-44.65269f,-7.4537274E-5f,100.0f,-0.65412825f ) ;
  }

  @Test
  public void test900() {
    TestDrivers.surfaceShade(202.0f,0f,0f,0f,439.0f,513.0f,-650.0f,296.0f,0f,0f,0f,0f,0f,-902.0f,640.0f,350.0f,-549.0f,-801.0f,-1020.0f,-940,-16.129623f,-12.639609f,-18.455914f,59.818672f,0f,0f ) ;
  }

  @Test
  public void test901() {
    TestDrivers.surfaceShade(202.0f,-142.0f,0f,0f,700.0f,285.0f,0f,-728.0f,0f,0f,0f,0f,0f,243.0f,463.0f,68.0f,-899.0f,174.0f,371.0f,-7,97.900856f,-37.75042f,-95.47864f,-57.324738f,-32.7423f,0f ) ;
  }

  @Test
  public void test902() {
    TestDrivers.surfaceShade(202.0f,-30.0f,0f,0f,726.0f,-1424.0f,0f,532.0f,0f,0f,0f,0f,0f,-534.0f,813.0f,1285.0f,356.0f,782.0f,204.0f,1035,88.38951f,-100.0f,100.0f,100.0f,8.851082f,0f ) ;
  }

  @Test
  public void test903() {
    TestDrivers.surfaceShade(-202.0f,-508.0f,728.0f,0f,100.0f,-871.0f,0f,-692.0f,0f,0f,0f,0f,0f,956.0f,-421.0f,933.0f,0f,0f,0f,-691,-52.197445f,-40.328415f,-8.260354f,22.863258f,-72.76844f,-17.639002f ) ;
  }

  @Test
  public void test904() {
    TestDrivers.surfaceShade(-203.0f,1091.0f,643.0f,0f,1326.0f,971.0f,0f,227.0f,0f,0f,0f,0f,0f,855.0f,-281.0f,-634.0f,-999.0f,225.0f,-726.0f,-1919,-0.16159518f,-0.052628487f,0.588295f,1.0814551f,-100.0f,8.845851f ) ;
  }

  @Test
  public void test905() {
    TestDrivers.surfaceShade(2037.0f,0f,0f,0f,1420.0f,1144.0f,0f,138.0f,0f,0f,0f,0f,0f,-169.0f,-552.0f,121.0f,-520.0f,258.0f,-893.0f,-235,-15.341174f,14.130652f,43.036873f,62.029987f,0f,0f ) ;
  }

  @Test
  public void test906() {
    TestDrivers.surfaceShade(204.0f,0f,0f,0f,1.9392238f,-80.353264f,0f,0.0f,0f,0f,0f,0f,0f,-53.613503f,70.82515f,-35.34379f,0f,0f,0f,-655,62.13608f,-42.230038f,-62.093197f,77.30952f,0f,0f ) ;
  }

  @Test
  public void test907() {
    TestDrivers.surfaceShade(2067.0f,493.0f,0f,0f,44.0f,-1575.0f,0f,0.0f,0f,0f,0f,0f,0f,838.0f,518.0f,-729.0f,0f,0f,0f,237,1.8307618f,-1.2268004f,1.2327788f,-100.0f,-28.444235f,0f ) ;
  }

  @Test
  public void test908() {
    TestDrivers.surfaceShade(-2091.0f,0f,0f,0f,100.0f,-48.69852f,0f,-19.076593f,0f,0f,0f,0f,0f,-19.89165f,34.759537f,-16.739964f,0f,0f,0f,-6,2.72878f,2.408149f,0.12851529f,12.294198f,0f,0f ) ;
  }

  @Test
  public void test909() {
    TestDrivers.surfaceShade(2.0f,0f,0f,0f,80.96614f,-14.47454f,0f,-44.72441f,0f,0f,0f,0f,0f,-36.566605f,-66.3736f,-56.25391f,0f,0f,0f,442,-34.568153f,-19.4448f,54.689957f,-42.69498f,0f,0f ) ;
  }

  @Test
  public void test910() {
    TestDrivers.surfaceShade(-21.0f,0f,0f,0f,8.911002f,0.0f,0f,-80.92669f,0f,0f,0f,0f,0f,-42.622055f,55.1211f,19.208118f,0f,0f,0f,8,3.4557f,3.4989219f,-2.5654457f,20.52883f,0f,0f ) ;
  }

  @Test
  public void test911() {
    TestDrivers.surfaceShade(21.0f,0f,173.0f,153.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,3.112356E-4f,0f,3.7780046E-5f ) ;
  }

  @Test
  public void test912() {
    TestDrivers.surfaceShade(-211.0f,0f,0f,0f,236.0f,-619.0f,0f,131.0f,0f,0f,0f,0f,0f,-974.0f,328.0f,765.0f,-964.0f,-158.0f,216.0f,278,58.63321f,15.651398f,67.94129f,-10.011415f,0f,0f ) ;
  }

  @Test
  public void test913() {
    TestDrivers.surfaceShade(-2123.0f,382.0f,0f,0f,182.0f,-1555.0f,0f,11.0f,0f,0f,0f,0f,0f,170.0f,-81.0f,-413.0f,0f,0f,0f,472,-46.6054f,59.61917f,-30.876684f,-44.87084f,46.505325f,0f ) ;
  }

  @Test
  public void test914() {
    TestDrivers.surfaceShade(-2128.0f,-190.0f,0f,68.0f,0f,0f,0f,2121.0f,0f,0f,0f,0f,0f,-340.0f,144.0f,-278.0f,932.0f,1114.0f,-567.0f,-19,0f,0f,0f,100.0f,-7.739938E-5f,0f ) ;
  }

  @Test
  public void test915() {
    TestDrivers.surfaceShade(-214.0f,1241.0f,0f,0f,586.0f,-355.0f,0f,251.0f,0f,0f,0f,0f,0f,-880.0f,780.0f,-15.0f,-267.0f,1792.0f,411.0f,-772,3.2144578f,5.408576f,92.66444f,-41.072674f,17.3895f,0f ) ;
  }

  @Test
  public void test916() {
    TestDrivers.surfaceShade(214.0f,40.0f,0f,0f,502.0f,-1.0f,0f,-602.0f,0f,0f,0f,0f,0f,685.0f,-632.0f,682.0f,0f,0f,0f,-450,20.034723f,12.107243f,-80.26388f,-60.058376f,-29.135628f,0f ) ;
  }

  @Test
  public void test917() {
    TestDrivers.surfaceShade(216.0f,-41.0f,-134.0f,-364.0f,0f,0f,0f,-59.78995f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-2,0f,0f,0f,70.82983f,6.700616E-5f,-36.408836f ) ;
  }

  @Test
  public void test918() {
    TestDrivers.surfaceShade(-216.0f,634.0f,0f,0f,876.0f,-880.0f,0f,374.0f,0f,0f,0f,0f,0f,-250.0f,322.0f,557.0f,-734.0f,677.0f,-564.0f,239,-34.163147f,-19.430382f,-4.112702f,-8.362924f,15.626497f,0f ) ;
  }

  @Test
  public void test919() {
    TestDrivers.surfaceShade(219.0f,-1331.0f,680.0f,0f,642.0f,1765.0f,0f,-524.0f,0f,0f,0f,0f,0f,489.0f,-338.0f,45.0f,190.0f,31.0f,317.0f,-2706,-0.31317544f,-0.43957683f,0.10146266f,90.83261f,-100.0f,100.0f ) ;
  }

  @Test
  public void test920() {
    TestDrivers.surfaceShade(-220.0f,-489.0f,0f,0f,76.0f,-965.0f,0f,137.0f,0f,0f,0f,0f,0f,945.0f,479.0f,-781.0f,-53.0f,680.0f,-859.0f,73,-19.384956f,-95.89931f,-82.272156f,-14.290345f,-6.429159f,0f ) ;
  }

  @Test
  public void test921() {
    TestDrivers.surfaceShade(-22.0f,902.0f,0f,0f,1821.0f,0.0f,0f,-2.0f,0f,0f,0f,0f,0f,382.0f,454.0f,51.0f,0f,0f,0f,-1336,95.89516f,-100.0f,100.0f,100.0f,21.634455f,0f ) ;
  }

  @Test
  public void test922() {
    TestDrivers.surfaceShade(-2220.0f,366.0f,99.0f,0f,143.0f,74.0f,0f,-204.0f,0f,0f,0f,0f,0f,-2262.0f,1754.0f,853.0f,15.0f,-1330.0f,79.0f,-966,0.45788825f,-0.55913246f,-0.48112947f,-100.0f,-74.30728f,-12.611921f ) ;
  }

  @Test
  public void test923() {
    TestDrivers.surfaceShade(-224.0f,-68.0f,296.0f,0f,379.0f,-312.0f,0f,268.0f,0f,0f,0f,0f,0f,647.0f,325.0f,246.0f,1989.0f,1237.0f,214.0f,742,-23.970568f,97.491005f,-65.75455f,93.493385f,67.41722f,70.001274f ) ;
  }

  @Test
  public void test924() {
    TestDrivers.surfaceShade(2256.0f,0f,0f,0f,49.10361f,0.0f,0f,-99.71219f,0f,0f,0f,0f,0f,93.83695f,-12.928716f,-95.45828f,0f,0f,0f,2625,0.24330851f,0.9388107f,0.24379371f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test925() {
    TestDrivers.surfaceShade(228.0f,944.0f,-493.0f,0f,111.0f,1078.0f,0f,230.0f,0f,0f,0f,0f,0f,685.0f,-603.0f,93.0f,2692.0f,696.0f,382.0f,157,-88.970375f,-86.40367f,95.08916f,100.0f,32.475224f,-62.184303f ) ;
  }

  @Test
  public void test926() {
    TestDrivers.surfaceShade(229.0f,0f,0f,0f,83.24607f,-78.61384f,0f,-100.0f,0f,0f,0f,0f,0f,-100.0f,41.81788f,55.329556f,0f,0f,0f,-3,0.40302938f,0.4478165f,0.1489298f,56.303364f,0f,0f ) ;
  }

  @Test
  public void test927() {
    TestDrivers.surfaceShade(2294.0f,1523.0f,1010.0f,0f,756.0f,784.0f,0f,227.0f,0f,0f,0f,0f,0f,-284.0f,-499.0f,-949.0f,-135.0f,-914.0f,212.0f,-2064,92.053276f,-4.89939f,-24.9719f,100.0f,71.04236f,100.0f ) ;
  }

  @Test
  public void test928() {
    TestDrivers.surfaceShade(2302.0f,-816.0f,-1071.0f,0f,131.0f,1915.0f,0f,1057.0f,0f,0f,0f,0f,0f,1360.0f,940.0f,831.0f,-169.0f,-1178.0f,-1518.0f,-297,-3.2566652f,4.1493793f,0.63615876f,59.295506f,67.05899f,-12.841412f ) ;
  }

  @Test
  public void test929() {
    TestDrivers.surfaceShade(240.0f,0f,0f,0f,761.0f,2.0f,0f,76.0f,0f,0f,0f,0f,0f,431.0f,-242.0f,-690.0f,533.0f,-157.0f,528.0f,753,-47.80931f,22.301739f,20.662027f,-12.078109f,0f,0f ) ;
  }

  @Test
  public void test930() {
    TestDrivers.surfaceShade(241.0f,0f,0f,0f,499.0f,972.0f,-817.0f,275.0f,0f,0f,0f,0f,0f,-575.0f,-161.0f,595.0f,-892.0f,-116.0f,53.0f,-429,55.07645f,-28.313768f,23.300213f,80.827576f,0f,0f ) ;
  }

  @Test
  public void test931() {
    TestDrivers.surfaceShade(242.0f,0f,0f,0f,29.275503f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,13.897118f,13.563832f,-1.5036339f,0f,0f,0f,28,25.954605f,-33.321087f,-60.697906f,37.69572f,0f,0f ) ;
  }

  @Test
  public void test932() {
    TestDrivers.surfaceShade(242.0f,-7.0f,808.0f,-119.0f,0f,0f,0f,-38.29666f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-2.8005082E-4f,0.0012004802f,-1.0400199E-5f ) ;
  }

  @Test
  public void test933() {
    TestDrivers.surfaceShade(-243.0f,0f,0f,0f,0.34887224f,0.0f,0f,-3.9443045E-31f,0f,0f,0f,0f,0f,-93.55483f,10.663356f,-99.99712f,0f,0f,0f,4,-1.4139544f,-0.12688193f,1.178402f,54.90828f,0f,0f ) ;
  }

  @Test
  public void test934() {
    TestDrivers.surfaceShade(-243.0f,-786.0f,0f,0f,338.0f,-2.0f,0f,-1869.0f,0f,0f,0f,0f,0f,-997.0f,-719.0f,-748.0f,0f,0f,0f,422,-0.42388842f,0.19582187f,0.8027482f,62.709282f,76.671135f,0f ) ;
  }

  @Test
  public void test935() {
    TestDrivers.surfaceShade(-2467.0f,-923.0f,0f,0f,114.0f,3.0f,0f,-1397.0f,0f,0f,0f,0f,0f,829.0f,-1858.0f,1230.0f,0f,0f,0f,-568,-0.30455783f,-0.06347149f,-0.5875138f,-77.07763f,-39.591633f,0f ) ;
  }

  @Test
  public void test936() {
    TestDrivers.surfaceShade(-2474.0f,732.0f,-734.0f,0f,34.0f,-1523.0f,0f,172.0f,0f,0f,0f,0f,0f,-431.0f,639.0f,-4.0f,-379.0f,21.0f,144.0f,-66,29.429596f,19.91536f,10.439722f,60.189884f,100.0f,-100.0f ) ;
  }

  @Test
  public void test937() {
    TestDrivers.surfaceShade(-249.0f,-133.0f,-976.0f,0f,615.0f,-1987.0f,0f,-443.0f,0f,0f,0f,0f,0f,-482.0f,-498.0f,-187.0f,0f,0f,0f,-1039,99.2876f,-6.438206f,-96.66953f,-94.77754f,-3.1257198f,28.22549f ) ;
  }

  @Test
  public void test938() {
    TestDrivers.surfaceShade(251.0f,-842.0f,0f,0f,610.0f,0.0f,0f,-345.0f,0f,0f,0f,0f,0f,803.0f,-826.0f,-468.0f,0f,0f,0f,-126,-116.2287f,-69.750984f,68.10787f,95.6956f,74.97025f,0f ) ;
  }

  @Test
  public void test939() {
    TestDrivers.surfaceShade(2516.0f,944.0f,739.0f,0f,490.0f,1932.0f,0f,988.0f,0f,0f,0f,0f,0f,1317.0f,575.0f,955.0f,118.0f,78.0f,-264.0f,1341,-0.5741742f,0.6592546f,0.39488596f,51.769867f,85.28715f,49.01084f ) ;
  }

  @Test
  public void test940() {
    TestDrivers.surfaceShade(252.0f,114.0f,0f,0f,188.0f,-736.0f,0f,-3.0f,0f,0f,0f,0f,0f,-95.0f,998.0f,-500.0f,0f,0f,0f,859,-0.2827126f,-0.7492188f,-0.113810994f,3.1790805E-8f,77.66121f,0f ) ;
  }

  @Test
  public void test941() {
    TestDrivers.surfaceShade(253.0f,-1464.0f,0f,0f,822.0f,941.0f,0f,674.0f,0f,0f,0f,0f,0f,-400.0f,123.0f,-287.0f,185.0f,-479.0f,-541.0f,979,-45.883957f,48.98898f,84.945045f,-84.64352f,97.52309f,0f ) ;
  }

  @Test
  public void test942() {
    TestDrivers.surfaceShade(-253.0f,-179.0f,0f,0f,130.0f,93.0f,0f,-179.0f,0f,0f,0f,0f,0f,-167.0f,646.0f,-47.0f,800.0f,538.0f,-750.0f,-63,-0.2814015f,-0.034190238f,0.529961f,-78.529495f,-32.03975f,0f ) ;
  }

  @Test
  public void test943() {
    TestDrivers.surfaceShade(2538.0f,878.0f,-27.0f,0f,172.0f,2433.0f,0f,-1325.0f,0f,0f,0f,0f,0f,917.0f,401.0f,512.0f,-1841.0f,-815.0f,-313.0f,653,55.543407f,-85.2868f,-32.682224f,-100.0f,2.755831f,-89.61555f ) ;
  }

  @Test
  public void test944() {
    TestDrivers.surfaceShade(2559.0f,-57.0f,-187.0f,0f,13.0f,-1347.0f,0f,-810.0f,0f,0f,0f,0f,0f,-307.0f,-745.0f,907.0f,0f,0f,0f,-2867,-22.480686f,39.14011f,24.540033f,46.39279f,-41.36317f,-12.605113f ) ;
  }

  @Test
  public void test945() {
    TestDrivers.surfaceShade(-2578.0f,-809.0f,-898.0f,0f,439.0f,-1027.0f,0f,787.0f,0f,0f,0f,0f,0f,826.0f,1402.0f,379.0f,-1611.0f,10.0f,-184.0f,-928,41.3863f,-2.6659994f,-80.33602f,-2.8491502f,-45.486492f,17.605068f ) ;
  }

  @Test
  public void test946() {
    TestDrivers.surfaceShade(258.0f,0f,0f,0f,525.0f,-99.0f,0f,201.0f,0f,0f,0f,0f,0f,-774.0f,878.0f,419.0f,-342.0f,721.0f,-446.0f,124,-100.0f,-100.0f,-100.0f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test947() {
    TestDrivers.surfaceShade(259.0f,0f,0f,0f,94.6273f,0.0f,0f,-26.128439f,0f,0f,0f,0f,0f,-44.19612f,-100.0f,-100.0f,0f,0f,0f,-4,-1.1359738f,-1.3811736f,-2.3827434f,-4.8256145f,0f,0f ) ;
  }

  @Test
  public void test948() {
    TestDrivers.surfaceShade(259.0f,14.0f,-196.0f,0f,1550.0f,-367.0f,0f,156.0f,0f,0f,0f,0f,0f,693.0f,-392.0f,-818.0f,-695.0f,-779.0f,8.0f,-966,-49.631107f,-98.77342f,65.34372f,12.126027f,-90.335434f,-19.985691f ) ;
  }

  @Test
  public void test949() {
    TestDrivers.surfaceShade(260.0f,12.0f,0f,0f,132.0f,1457.0f,0f,259.0f,0f,0f,0f,0f,0f,-71.0f,-554.0f,1274.0f,870.0f,406.0f,-1084.0f,-934,0.036515724f,0.2396177f,0.10623298f,17.312263f,-4.284613f,0f ) ;
  }

  @Test
  public void test950() {
    TestDrivers.surfaceShade(-2604.0f,0f,0f,0f,305.0f,-8.0f,0f,765.0f,0f,0f,0f,0f,0f,-133.0f,1380.0f,-253.0f,-269.0f,91.0f,902.0f,-647,-0.17359659f,-0.192501f,0.96580184f,-73.35671f,0f,0f ) ;
  }

  @Test
  public void test951() {
    TestDrivers.surfaceShade(26.0f,677.0f,0f,0f,25.0f,0.0f,0f,-1095.0f,0f,0f,0f,0f,0f,-440.0f,44.0f,42.0f,0f,0f,0f,-448,-18.743172f,-100.0f,-96.94615f,6.8454387E-6f,99.259415f,0f ) ;
  }

  @Test
  public void test952() {
    TestDrivers.surfaceShade(265.0f,102.0f,241.0f,624.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,-100.0f,1.5711414E-5f,92.18454f ) ;
  }

  @Test
  public void test953() {
    TestDrivers.surfaceShade(-267.0f,0f,0f,0f,97.87006f,0.0f,0f,-46.27467f,0f,0f,0f,0f,0f,-56.849308f,-66.67224f,53.599026f,0f,0f,0f,392,1.6186721f,69.00466f,-38.146553f,-33.271263f,0f,0f ) ;
  }

  @Test
  public void test954() {
    TestDrivers.surfaceShade(-270.0f,0f,0f,0f,34.77316f,-13.80158f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,14.660935f,18.170958f,0f,0f,0f,1,-2.783833f,-1.0844543f,2.3973782f,35.06638f,0f,0f ) ;
  }

  @Test
  public void test955() {
    TestDrivers.surfaceShade(2715.0f,-871.0f,0f,0f,701.0f,-4.0f,0f,1.0f,0f,0f,0f,0f,0f,-256.0f,396.0f,-348.0f,0f,0f,0f,-2831,-96.3154f,25.614285f,100.0f,25.665058f,-42.66251f,0f ) ;
  }

  @Test
  public void test956() {
    TestDrivers.surfaceShade(-274.0f,0f,-776.0f,0f,377.0f,-10.0f,0f,-845.0f,0f,0f,0f,0f,0f,-85.0f,-813.0f,365.0f,0f,0f,0f,-980,-34.327892f,-39.677563f,-96.371864f,-56.172062f,0f,21.141611f ) ;
  }

  @Test
  public void test957() {
    TestDrivers.surfaceShade(276.0f,-422.0f,0f,250.0f,0f,0f,0f,-39.280663f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,11.438011f,-9.478673E-6f,0f ) ;
  }

  @Test
  public void test958() {
    TestDrivers.surfaceShade(278.0f,0f,696.0f,0f,618.0f,-2481.0f,0f,470.0f,0f,0f,0f,0f,0f,-93.0f,78.0f,999.0f,-202.0f,137.0f,752.0f,-943,56.55708f,-89.44113f,12.248465f,-3.2617888f,0f,7.996683f ) ;
  }

  @Test
  public void test959() {
    TestDrivers.surfaceShade(-281.0f,28.0f,363.0f,-3.0f,0f,0f,0f,-7.780428f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0.0011862396f,-0.011904762f,100.0f ) ;
  }

  @Test
  public void test960() {
    TestDrivers.surfaceShade(-283.0f,-10.0f,-638.0f,0f,289.0f,759.0f,0f,361.0f,0f,0f,0f,0f,0f,166.0f,843.0f,132.0f,4.0f,-768.0f,757.0f,4,99.04079f,-70.58925f,90.50149f,-26.576923f,74.09776f,2.207862f ) ;
  }

  @Test
  public void test961() {
    TestDrivers.surfaceShade(285.0f,0f,0f,0f,726.0f,1231.0f,0f,-10.0f,0f,0f,0f,0f,0f,570.0f,-278.0f,-785.0f,-1695.0f,934.0f,939.0f,907,45.703106f,-49.402367f,50.681053f,16.226429f,0f,0f ) ;
  }

  @Test
  public void test962() {
    TestDrivers.surfaceShade(-286.0f,686.0f,-170.0f,0f,826.0f,3.0f,0f,758.0f,0f,0f,0f,0f,0f,200.0f,-461.0f,117.0f,498.0f,336.0f,491.0f,247,-79.176285f,-29.439337f,19.348063f,100.0f,-16.854885f,-9.300895f ) ;
  }

  @Test
  public void test963() {
    TestDrivers.surfaceShade(-288.0f,-879.0f,-445.0f,0f,347.0f,-171.0f,0f,369.0f,0f,0f,0f,0f,0f,-982.0f,536.0f,-214.0f,-660.0f,-826.0f,-938.0f,-445,68.320564f,12.897835f,-8.579658f,-33.31607f,26.100733f,4.9624305E-11f ) ;
  }

  @Test
  public void test964() {
    TestDrivers.surfaceShade(29.0f,-36.0f,1129.0f,-5.0f,0f,0f,0f,-44.470406f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0.6702747f,0.0055555557f,-42.82396f ) ;
  }

  @Test
  public void test965() {
    TestDrivers.surfaceShade(-2952.0f,0f,0f,0f,6.363604E-5f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-73.448975f,-12.92583f,14.553862f,0f,0f,0f,8,-0.075160004f,0.01898692f,-0.4160871f,-2.8860679f,0f,0f ) ;
  }

  @Test
  public void test966() {
    TestDrivers.surfaceShade(-298.0f,-476.0f,0f,0f,1041.0f,1520.0f,0f,84.0f,0f,0f,0f,0f,0f,277.0f,-160.0f,391.0f,-793.0f,866.0f,-239.0f,645,52.841938f,19.257746f,-29.55493f,-0.07923577f,-4.2265673f,0f ) ;
  }

  @Test
  public void test967() {
    TestDrivers.surfaceShade(298.0f,-799.0f,-767.0f,0f,666.0f,744.0f,0f,9.0f,0f,0f,0f,0f,0f,-68.0f,-175.0f,-227.0f,-882.0f,2328.0f,-1946.0f,-1035,-19.251032f,-99.999115f,82.859245f,-51.211796f,80.94553f,100.0f ) ;
  }

  @Test
  public void test968() {
    TestDrivers.surfaceShade(30.0f,-274.0f,0f,0f,48.0f,-89.0f,0f,166.0f,0f,0f,0f,0f,0f,-803.0f,-746.0f,-95.0f,537.0f,588.0f,200.0f,287,-52.36215f,79.90909f,129.13022f,47.786983f,43.665733f,0f ) ;
  }

  @Test
  public void test969() {
    TestDrivers.surfaceShade(301.0f,0f,0f,516.0f,0f,0f,0f,10.82013f,0f,0f,0f,0f,0f,49.309757f,-61.22607f,100.0f,617.0f,447.0f,-1481.0f,1,0f,0f,0f,6.4384867E-6f,0f,0f ) ;
  }

  @Test
  public void test970() {
    TestDrivers.surfaceShade(-301.0f,1087.0f,-1698.0f,0f,28.0f,-692.0f,0f,-703.0f,0f,0f,0f,0f,0f,-87.0f,744.0f,844.0f,0f,0f,0f,780,-85.67496f,21.553606f,-27.831284f,-47.74477f,73.95647f,-47.474957f ) ;
  }

  @Test
  public void test971() {
    TestDrivers.surfaceShade(-301.0f,554.0f,0f,0f,1651.0f,-646.0f,0f,1618.0f,0f,0f,0f,0f,0f,-791.0f,269.0f,-965.0f,944.0f,-716.0f,-496.0f,944,0.32040036f,0.018379597f,-0.251725f,-93.04201f,-100.0f,0f ) ;
  }

  @Test
  public void test972() {
    TestDrivers.surfaceShade(-3011.0f,0f,0f,0f,18.526756f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,53.94523f,-75.80623f,16.857172f,0f,0f,0f,-1,1.1974115f,0.11726631f,-0.31113514f,-71.27445f,0f,0f ) ;
  }

  @Test
  public void test973() {
    TestDrivers.surfaceShade(305.0f,-648.0f,0f,0f,863.0f,2.0f,0f,-2.0f,0f,0f,0f,0f,0f,607.0f,-351.0f,375.0f,0f,0f,0f,1640,1.2601534f,0.58103323f,-1.4959213f,100.0f,0.9789244f,0f ) ;
  }

  @Test
  public void test974() {
    TestDrivers.surfaceShade(-306.0f,302.0f,0f,757.0f,0f,0f,0f,-28.361546f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-4.3170066E-6f,88.45097f,0f ) ;
  }

  @Test
  public void test975() {
    TestDrivers.surfaceShade(-307.0f,-155.0f,-628.0f,0f,25.0f,358.0f,0f,1472.0f,0f,0f,0f,0f,0f,267.0f,440.0f,237.0f,-337.0f,544.0f,-995.0f,-630,-0.8513044f,0.15106119f,-0.155819f,100.0f,63.99264f,100.0f ) ;
  }

  @Test
  public void test976() {
    TestDrivers.surfaceShade(-3.0f,362.0f,-265.0f,0f,519.0f,410.0f,0f,371.0f,0f,0f,0f,0f,0f,538.0f,192.0f,-68.0f,-73.0f,786.0f,-329.0f,-496,5.0769506f,8.979356f,65.52111f,86.27389f,-56.52583f,-65.17734f ) ;
  }

  @Test
  public void test977() {
    TestDrivers.surfaceShade(-310.0f,0f,0f,0f,25.244972f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,100.0f,0f,0f,0f,1716,-0.12523139f,0.854875f,0.0035607927f,8.822463f,0f,0f ) ;
  }

  @Test
  public void test978() {
    TestDrivers.surfaceShade(-312.0f,278.0f,662.0f,0f,533.0f,1979.0f,0f,-111.0f,0f,0f,0f,0f,0f,265.0f,767.0f,-250.0f,324.0f,-1268.0f,635.0f,-1015,-64.5526f,54.89757f,100.0f,-99.99659f,-16.223278f,48.59767f ) ;
  }

  @Test
  public void test979() {
    TestDrivers.surfaceShade(-313.0f,0f,0f,0f,3.740345E-6f,-9.674216f,0f,-35.158775f,0f,0f,0f,0f,0f,-144.38199f,77.60162f,-100.0f,0f,0f,0f,1,-0.08817542f,-0.19371377f,0.8294011f,-3.7357569f,0f,0f ) ;
  }

  @Test
  public void test980() {
    TestDrivers.surfaceShade(318.0f,-328.0f,0f,0f,66.0f,-341.0f,0f,-2514.0f,0f,0f,0f,0f,0f,1998.0f,-1778.0f,-243.0f,0f,0f,0f,4,0.007587962f,0.2918483f,0.8826618f,-22.752605f,-5.979375E-8f,0f ) ;
  }

  @Test
  public void test981() {
    TestDrivers.surfaceShade(-319.0f,-740.0f,1193.0f,392.0f,0f,0f,0f,-18.266813f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,3,0f,0f,0f,62.573803f,60.867527f,31.867937f ) ;
  }

  @Test
  public void test982() {
    TestDrivers.surfaceShade(-319.0f,-76.0f,0f,0f,176.0f,-2201.0f,0f,2411.0f,0f,0f,0f,0f,0f,-1920.0f,-525.0f,-533.0f,231.0f,2436.0f,772.0f,-669,0.20720987f,0.72945577f,-0.6209417f,58.390247f,-63.889896f,0f ) ;
  }

  @Test
  public void test983() {
    TestDrivers.surfaceShade(320.0f,-342.0f,-101.0f,0f,419.0f,146.0f,0f,897.0f,0f,0f,0f,0f,0f,-643.0f,-1010.0f,633.0f,-131.0f,651.0f,-964.0f,240,-37.8738f,-2.360305f,-95.15442f,-19.240585f,-49.990887f,-30.226936f ) ;
  }

  @Test
  public void test984() {
    TestDrivers.surfaceShade(322.0f,0f,-409.0f,-22.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-1.4116318E-4f,0f,100.0f ) ;
  }

  @Test
  public void test985() {
    TestDrivers.surfaceShade(-324.0f,-71.0f,0f,0f,46.0f,-2476.0f,0f,558.0f,0f,0f,0f,0f,0f,1202.0f,238.0f,-2729.0f,233.0f,-884.0f,1261.0f,1631,-0.23153518f,-0.03486763f,-0.10482899f,34.96339f,25.508633f,0f ) ;
  }

  @Test
  public void test986() {
    TestDrivers.surfaceShade(326.0f,199.0f,0f,0f,1174.0f,2.0f,0f,-6.0f,0f,0f,0f,0f,0f,-367.0f,-55.0f,-148.0f,0f,0f,0f,-1688,22.423157f,-94.29022f,-20.563086f,-32.267685f,100.0f,0f ) ;
  }

  @Test
  public void test987() {
    TestDrivers.surfaceShade(-328.0f,-873.0f,0f,0f,261.0f,-852.0f,0f,757.0f,0f,0f,0f,0f,0f,857.0f,-942.0f,-1396.0f,101.0f,-891.0f,2919.0f,-591,0.935004f,-0.41291735f,0.85262644f,-59.773552f,-48.219116f,0f ) ;
  }

  @Test
  public void test988() {
    TestDrivers.surfaceShade(-330.0f,162.0f,-410.0f,0f,37.0f,-714.0f,0f,-162.0f,0f,0f,0f,0f,0f,-112.0f,-728.0f,154.0f,0f,0f,0f,377,-34.135048f,26.405392f,100.0f,43.590794f,62.749676f,-12.6823845f ) ;
  }

  @Test
  public void test989() {
    TestDrivers.surfaceShade(-33.0f,0f,0f,0f,5.501464f,0.0f,0f,-99.02872f,0f,0f,0f,0f,0f,-97.67643f,100.0f,-73.65612f,0f,0f,0f,1969,0.73878765f,0.6704875f,-0.069421664f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test990() {
    TestDrivers.surfaceShade(33.0f,343.0f,0f,0f,196.0f,0.0f,0f,-723.0f,0f,0f,0f,0f,0f,602.0f,-333.0f,670.0f,0f,0f,0f,-934,-41.447098f,12.108568f,-58.08278f,-80.31554f,40.816563f,0f ) ;
  }

  @Test
  public void test991() {
    TestDrivers.surfaceShade(-333.0f,-913.0f,903.0f,0f,688.0f,-319.0f,0f,822.0f,0f,0f,0f,0f,0f,834.0f,902.0f,479.0f,-316.0f,-799.0f,-287.0f,841,-12.18701f,-39.249073f,44.95789f,-73.59434f,-46.07413f,80.691475f ) ;
  }

  @Test
  public void test992() {
    TestDrivers.surfaceShade(336.0f,-1609.0f,-399.0f,0f,8.0f,-1986.0f,0f,1594.0f,0f,0f,0f,0f,0f,546.0f,-285.0f,877.0f,-1633.0f,-852.0f,-3198.0f,-252,-8.24405f,-45.734646f,-9.729901f,1.0975878f,16.034327f,-0.92428446f ) ;
  }

  @Test
  public void test993() {
    TestDrivers.surfaceShade(338.0f,351.0f,541.0f,2.0f,0f,0f,0f,-4.9303807E-32f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,-109.87063f,-74.87904f,9.2421443E-4f ) ;
  }

  @Test
  public void test994() {
    TestDrivers.surfaceShade(339.0f,1029.0f,359.0f,0f,810.0f,-33.0f,0f,-263.0f,0f,0f,0f,0f,0f,-90.0f,-52.0f,177.0f,0f,0f,0f,945,-7.3153753f,66.58864f,15.843081f,51.63139f,33.720978f,31.286152f ) ;
  }

  @Test
  public void test995() {
    TestDrivers.surfaceShade(-34.0f,0f,0f,0f,16.578539f,0.0f,0f,-16.12178f,0f,0f,0f,0f,0f,53.393764f,4.021784f,35.524933f,0f,0f,0f,760,1.3118743f,78.0425f,-56.26251f,70.086655f,0f,0f ) ;
  }

  @Test
  public void test996() {
    TestDrivers.surfaceShade(-346.0f,-175.0f,-1089.0f,0f,927.0f,-1277.0f,0f,-304.0f,0f,0f,0f,0f,0f,-218.0f,907.0f,-1035.0f,0f,0f,0f,-385,0.78926855f,0.036342964f,0.38732153f,26.460257f,-0.38168284f,-7.0318103f ) ;
  }

  @Test
  public void test997() {
    TestDrivers.surfaceShade(-349.0f,96.0f,-518.0f,0f,36.0f,-90.0f,0f,720.0f,0f,0f,0f,0f,0f,-257.0f,504.0f,525.0f,497.0f,-83.0f,-380.0f,-198,68.6863f,53.219166f,-17.466818f,22.315296f,80.318214f,-69.395546f ) ;
  }

  @Test
  public void test998() {
    TestDrivers.surfaceShade(35.0f,0f,0f,0f,10.927782f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,85.14396f,79.78101f,100.0f,0f,0f,0f,-384,-1.0313522f,0.129771f,0.7745945f,33.675434f,0f,0f ) ;
  }

  @Test
  public void test999() {
    TestDrivers.surfaceShade(-35.0f,568.0f,0f,262.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,-1.0905125E-4f,-57.369213f,0f ) ;
  }

  @Test
  public void test1000() {
    TestDrivers.surfaceShade(-353.0f,0f,0f,0f,747.0f,599.0f,0f,723.0f,0f,0f,0f,0f,0f,259.0f,695.0f,-450.0f,-991.0f,103.0f,881.0f,-52,2.533037f,-20.747484f,25.322493f,-1.5066348E-10f,0f,0f ) ;
  }

  @Test
  public void test1001() {
    TestDrivers.surfaceShade(-354.0f,-328.0f,0f,0f,25.0f,-656.0f,0f,545.0f,0f,0f,0f,0f,0f,352.0f,-908.0f,235.0f,795.0f,-83.0f,342.0f,901,50.228477f,85.72684f,-56.76178f,-21.313828f,15.897153f,0f ) ;
  }

  @Test
  public void test1002() {
    TestDrivers.surfaceShade(358.0f,-23.0f,0f,0f,666.0f,950.0f,0f,90.0f,0f,0f,0f,0f,0f,909.0f,-156.0f,-714.0f,567.0f,63.0f,-100.0f,882,-17.718052f,-36.703697f,-14.537712f,23.754292f,73.79121f,0f ) ;
  }

  @Test
  public void test1003() {
    TestDrivers.surfaceShade(-359.0f,127.0f,0f,0f,665.0f,-1847.0f,0f,1284.0f,0f,0f,0f,0f,0f,154.0f,238.0f,925.0f,-309.0f,-555.0f,-474.0f,146,-31.266363f,17.2666f,0.7627777f,-52.736908f,148.63295f,0f ) ;
  }

  @Test
  public void test1004() {
    TestDrivers.surfaceShade(361.0f,0f,0f,0f,88.2324f,0.0f,0f,1.2901571E-19f,0f,0f,0f,0f,0f,-9.17829f,-58.02901f,-100.0f,0f,0f,0f,-3,-2.7381504f,-0.10395112f,-6.1403f,-35.174355f,0f,0f ) ;
  }

  @Test
  public void test1005() {
    TestDrivers.surfaceShade(363.0f,389.0f,0f,0f,1208.0f,-88.0f,0f,327.0f,0f,0f,0f,0f,0f,559.0f,-177.0f,-876.0f,-705.0f,-1106.0f,-669.0f,-615,75.42853f,-9.926143f,50.138668f,-100.0f,-4.676173f,0f ) ;
  }

  @Test
  public void test1006() {
    TestDrivers.surfaceShade(-363.0f,797.0f,-2.0f,411.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-73.42428f,28.628159f,-0.001216545f ) ;
  }

  @Test
  public void test1007() {
    TestDrivers.surfaceShade(364.0f,790.0f,669.0f,0f,46.0f,-654.0f,0f,347.0f,0f,0f,0f,0f,0f,689.0f,301.0f,-502.0f,-740.0f,-598.0f,602.0f,253,-47.71365f,-39.770435f,-89.33388f,22.618805f,16.287395f,24.344755f ) ;
  }

  @Test
  public void test1008() {
    TestDrivers.surfaceShade(375.0f,151.0f,0f,0f,159.0f,181.0f,0f,53.0f,0f,0f,0f,0f,0f,-513.0f,590.0f,48.0f,975.0f,887.0f,-488.0f,818,12.799002f,-22.351648f,77.94372f,24.629272f,-9.602406f,0f ) ;
  }

  @Test
  public void test1009() {
    TestDrivers.surfaceShade(-376.0f,-595.0f,905.0f,0f,577.0f,-274.0f,0f,562.0f,0f,0f,0f,0f,0f,907.0f,-438.0f,163.0f,487.0f,-216.0f,94.0f,169,16.149347f,27.9344f,-14.79872f,-33.6811f,100.0f,-100.0f ) ;
  }

  @Test
  public void test1010() {
    TestDrivers.surfaceShade(-376.0f,885.0f,-637.0f,0f,1103.0f,-274.0f,0f,-1044.0f,0f,0f,0f,0f,0f,-5.0f,651.0f,806.0f,0f,0f,0f,-689,58.431473f,-22.59512f,18.612383f,-98.87235f,95.5507f,100.0f ) ;
  }

  @Test
  public void test1011() {
    TestDrivers.surfaceShade(-377.0f,-129.0f,0f,0f,1150.0f,-358.0f,0f,1.0f,0f,0f,0f,0f,0f,-2242.0f,20.0f,480.0f,0f,0f,0f,1145,0.44498295f,0.11268892f,0.6022643f,17.291523f,18.182638f,0f ) ;
  }

  @Test
  public void test1012() {
    TestDrivers.surfaceShade(-38.0f,-51.0f,0f,0f,1416.0f,701.0f,0f,-97.0f,0f,0f,0f,0f,0f,582.0f,-10.0f,609.0f,-365.0f,-27.0f,1944.0f,-618,28.622042f,-98.89215f,-28.976929f,-44.827812f,-33.376415f,0f ) ;
  }

  @Test
  public void test1013() {
    TestDrivers.surfaceShade(-3812.0f,-304.0f,-2522.0f,0f,205.0f,-2020.0f,0f,-901.0f,0f,0f,0f,0f,0f,488.0f,2.0f,783.0f,0f,0f,0f,493,-0.3735947f,-0.17431906f,0.23328589f,100.0f,100.0f,-85.287704f ) ;
  }

  @Test
  public void test1014() {
    TestDrivers.surfaceShade(-382.0f,-292.0f,0f,0f,5.0f,-22.0f,0f,-572.0f,0f,0f,0f,0f,0f,-537.0f,-421.0f,-865.0f,0f,0f,0f,35,27.449358f,-41.74269f,44.15578f,73.92077f,52.23163f,0f ) ;
  }

  @Test
  public void test1015() {
    TestDrivers.surfaceShade(382.0f,-988.0f,0f,0f,1183.0f,-4.0f,0f,0.0f,0f,0f,0f,0f,0f,-155.0f,639.0f,-80.0f,0f,0f,0f,-177,-69.32793f,-63.94219f,86.15524f,165.65663f,-23.34805f,0f ) ;
  }

  @Test
  public void test1016() {
    TestDrivers.surfaceShade(386.0f,548.0f,720.0f,0f,80.0f,327.0f,0f,-19.0f,0f,0f,0f,0f,0f,37.0f,-567.0f,941.0f,-1181.0f,-438.0f,-870.0f,833,7.409368f,90.4357f,54.20074f,19.841743f,85.70857f,79.214f ) ;
  }

  @Test
  public void test1017() {
    TestDrivers.surfaceShade(-386.0f,877.0f,0f,0f,828.0f,0.0f,0f,-547.0f,0f,0f,0f,0f,0f,504.0f,-1091.0f,-921.0f,0f,0f,0f,-256,73.69783f,11.728965f,26.435839f,-52.53105f,19.304298f,0f ) ;
  }

  @Test
  public void test1018() {
    TestDrivers.surfaceShade(-389.0f,0f,0f,0f,8.43132f,-6.8437777f,0f,-81.17013f,0f,0f,0f,0f,0f,25.01052f,43.108513f,-58.377068f,0f,0f,0f,-2407,-0.50448847f,0.098368056f,0.7949946f,-2.5626435f,0f,0f ) ;
  }

  @Test
  public void test1019() {
    TestDrivers.surfaceShade(389.0f,-526.0f,0f,-105.0f,0f,0f,0f,-34.217995f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,3.974068f,97.45921f,0f ) ;
  }

  @Test
  public void test1020() {
    TestDrivers.surfaceShade(390.0f,0f,32.0f,0f,952.0f,0.0f,0f,-382.0f,0f,0f,0f,0f,0f,524.0f,-493.0f,915.0f,0f,0f,0f,540,-27.84537f,71.09252f,-56.848526f,-57.528095f,0f,-68.7395f ) ;
  }

  @Test
  public void test1021() {
    TestDrivers.surfaceShade(-390.0f,-1026.0f,0f,0f,295.0f,494.0f,0f,277.0f,0f,0f,0f,0f,0f,-723.0f,-1127.0f,525.0f,684.0f,826.0f,973.0f,67,37.935898f,11.415811f,55.873642f,-2.8041806f,-73.65729f,0f ) ;
  }

  @Test
  public void test1022() {
    TestDrivers.surfaceShade(-390.0f,38.0f,0f,0f,9.0f,1280.0f,0f,2826.0f,0f,0f,0f,0f,0f,734.0f,995.0f,68.0f,-1384.0f,154.0f,160.0f,-966,59.927494f,-48.050953f,56.234074f,-8.535875f,83.55877f,0f ) ;
  }

  @Test
  public void test1023() {
    TestDrivers.surfaceShade(39.0f,563.0f,41.0f,1176.0f,0f,0f,0f,-28.157072f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,70.96657f,16.460342f,19.742563f ) ;
  }

  @Test
  public void test1024() {
    TestDrivers.surfaceShade(393.0f,-525.0f,0f,0f,1621.0f,-2417.0f,0f,10.0f,0f,0f,0f,0f,0f,-1874.0f,253.0f,-702.0f,0f,0f,0f,898,-2.3039258f,0.23706898f,6.235805f,100.0f,-74.7239f,0f ) ;
  }

  @Test
  public void test1025() {
    TestDrivers.surfaceShade(-398.0f,-714.0f,0f,0f,1.0f,-607.0f,0f,241.0f,0f,0f,0f,0f,0f,519.0f,165.0f,-143.0f,-563.0f,698.0f,905.0f,-351,35.810085f,-58.14999f,62.87193f,-9.285381f,46.567005f,0f ) ;
  }

  @Test
  public void test1026() {
    TestDrivers.surfaceShade(398.0f,-96.0f,0f,0f,1419.0f,1268.0f,0f,-1246.0f,0f,0f,0f,0f,0f,424.0f,-471.0f,1028.0f,-2032.0f,31.0f,-1942.0f,1644,-0.22568427f,0.6078386f,0.22027273f,-98.69033f,-22.943575f,0f ) ;
  }

  @Test
  public void test1027() {
    TestDrivers.surfaceShade(-399.0f,282.0f,0f,0f,107.0f,490.0f,0f,368.0f,0f,0f,0f,0f,0f,-549.0f,122.0f,431.0f,-126.0f,498.0f,467.0f,-60,-64.5036f,-53.607212f,-66.989494f,-57.31534f,5.9170065f,0f ) ;
  }

  @Test
  public void test1028() {
    TestDrivers.surfaceShade(400.0f,78.0f,-971.0f,0f,52.0f,-429.0f,0f,882.0f,0f,0f,0f,0f,0f,944.0f,460.0f,-824.0f,604.0f,-114.0f,626.0f,-372,-21.282803f,-74.92749f,20.70571f,-48.838165f,48.459057f,85.62847f ) ;
  }

  @Test
  public void test1029() {
    TestDrivers.surfaceShade(40.0f,1079.0f,-1539.0f,0f,368.0f,452.0f,0f,-106.0f,0f,0f,0f,0f,0f,-310.0f,-232.0f,-177.0f,-781.0f,-235.0f,-107.0f,928,41.96138f,19.022085f,-98.42459f,26.052704f,88.06567f,-95.63541f ) ;
  }

  @Test
  public void test1030() {
    TestDrivers.surfaceShade(-411.0f,986.0f,-554.0f,0f,957.0f,1512.0f,0f,-345.0f,0f,0f,0f,0f,0f,29.0f,523.0f,-167.0f,-165.0f,-72.0f,686.0f,-396,0.70953166f,-0.38466647f,0.10244489f,-53.877872f,21.613447f,34.6758f ) ;
  }

  @Test
  public void test1031() {
    TestDrivers.surfaceShade(-413.0f,-1420.0f,-152.0f,0f,32.0f,-1025.0f,0f,335.0f,0f,0f,0f,0f,0f,380.0f,737.0f,-169.0f,913.0f,-748.0f,802.0f,859,0.13216183f,-0.2875155f,-0.64619815f,67.505745f,59.646553f,-71.71035f ) ;
  }

  @Test
  public void test1032() {
    TestDrivers.surfaceShade(-417.0f,-14.0f,0f,-628.0f,0f,0f,0f,-47.00854f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,29.93893f,40.850933f,0f ) ;
  }

  @Test
  public void test1033() {
    TestDrivers.surfaceShade(418.0f,-485.0f,1718.0f,0f,113.0f,-1124.0f,0f,-219.0f,0f,0f,0f,0f,0f,51.0f,-60.0f,48.0f,0f,0f,0f,-642,0.012421746f,0.6089819f,0.74802923f,12.020941f,-77.139854f,12.225619f ) ;
  }

  @Test
  public void test1034() {
    TestDrivers.surfaceShade(-42.0f,-30.0f,11.0f,-10.0f,0f,0f,0f,-3.243841E-16f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,3,0f,0f,0f,-99.992226f,0.0033333334f,-0.009090909f ) ;
  }

  @Test
  public void test1035() {
    TestDrivers.surfaceShade(-429.0f,-114.0f,266.0f,0f,2232.0f,384.0f,0f,-452.0f,0f,0f,0f,0f,0f,572.0f,-465.0f,123.0f,-526.0f,55.0f,107.0f,1293,-0.14733931f,-0.14498924f,0.045804422f,-72.50336f,78.15326f,54.97412f ) ;
  }

  @Test
  public void test1036() {
    TestDrivers.surfaceShade(431.0f,0f,0f,0f,177.0f,109.0f,0f,697.0f,0f,0f,0f,0f,0f,564.0f,-290.0f,672.0f,-50.0f,-137.0f,-228.0f,-54,-75.35938f,71.97334f,-36.57048f,9.25594f,0f,0f ) ;
  }

  @Test
  public void test1037() {
    TestDrivers.surfaceShade(-435.0f,-419.0f,0f,0f,108.0f,-411.0f,0f,-97.0f,0f,0f,0f,0f,0f,-389.0f,405.0f,-103.0f,0f,0f,0f,-1194,80.79989f,90.83097f,51.994064f,-17.69878f,52.716488f,0f ) ;
  }

  @Test
  public void test1038() {
    TestDrivers.surfaceShade(437.0f,-45.0f,1099.0f,0f,168.0f,484.0f,0f,535.0f,0f,0f,0f,0f,0f,390.0f,346.0f,-53.0f,-936.0f,687.0f,426.0f,-838,-17.871428f,-57.13059f,-20.766338f,-63.76649f,31.670277f,-10.376079f ) ;
  }

  @Test
  public void test1039() {
    TestDrivers.surfaceShade(438.0f,1195.0f,828.0f,0f,590.0f,1.0f,0f,-234.0f,0f,0f,0f,0f,0f,331.0f,125.0f,1793.0f,0f,0f,0f,-907,-14.397523f,-100.0f,-94.54436f,110.89395f,-30.162378f,-8.619503f ) ;
  }

  @Test
  public void test1040() {
    TestDrivers.surfaceShade(-440.0f,0.0f,0f,0f,169.0f,-861.0f,0f,-1.0f,0f,0f,0f,0f,0f,125.0f,25.0f,468.0f,0f,0f,0f,661,-58.10347f,100.0f,7.329705f,35.217888f,-71.70604f,0f ) ;
  }

  @Test
  public void test1041() {
    TestDrivers.surfaceShade(44.0f,0f,0f,112.0f,0f,0f,0f,-78.41091f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,2.0292208E-4f,0f,0f ) ;
  }

  @Test
  public void test1042() {
    TestDrivers.surfaceShade(444.0f,0f,0f,0f,129.0f,1100.0f,0f,103.0f,0f,0f,0f,0f,0f,732.0f,-657.0f,440.0f,-233.0f,-893.0f,-497.0f,-370,39.493034f,97.7528f,80.26066f,22.096746f,0f,0f ) ;
  }

  @Test
  public void test1043() {
    TestDrivers.surfaceShade(-444.0f,97.0f,-863.0f,0f,421.0f,-670.0f,0f,14.0f,0f,0f,0f,0f,0f,480.0f,-815.0f,104.0f,-902.0f,850.0f,-665.0f,-133,-68.17792f,-23.315256f,57.341267f,2.6102746f,68.55629f,1.5064462f ) ;
  }

  @Test
  public void test1044() {
    TestDrivers.surfaceShade(447.0f,1606.0f,354.0f,0f,237.0f,591.0f,0f,-552.0f,0f,0f,0f,0f,0f,205.0f,321.0f,868.0f,-7.0f,411.0f,533.0f,-553,0.12738484f,-0.3145396f,0.086236544f,2.8525193f,-100.0f,5.2545915f ) ;
  }

  @Test
  public void test1045() {
    TestDrivers.surfaceShade(-447.0f,649.0f,0f,0f,2044.0f,0.0f,0f,3.0f,0f,0f,0f,0f,0f,-1096.0f,-284.0f,-201.0f,0f,0f,0f,24,19.895634f,-0.20719883f,29.56357f,5.4451723f,-51.059185f,0f ) ;
  }

  @Test
  public void test1046() {
    TestDrivers.surfaceShade(449.0f,0f,0f,-101.0f,0f,0f,0f,35.441f,0f,0f,0f,0f,0f,-100.0f,84.165764f,-41.7898f,87.0f,-272.0f,-756.0f,1,0f,0f,0f,-2.2051203E-5f,0f,0f ) ;
  }

  @Test
  public void test1047() {
    TestDrivers.surfaceShade(-449.0f,87.0f,-415.0f,0f,266.0f,-116.0f,0f,226.0f,0f,0f,0f,0f,0f,-690.0f,-662.0f,-52.0f,162.0f,-73.0f,104.0f,-162,92.62743f,-92.38342f,26.36536f,-30.719225f,-13.237807f,-2.1954847E-9f ) ;
  }

  @Test
  public void test1048() {
    TestDrivers.surfaceShade(-45.0f,478.0f,0f,0f,479.0f,-436.0f,0f,-15.0f,0f,0f,0f,0f,0f,1251.0f,-346.0f,55.0f,0f,0f,0f,116,-1.5864772f,0.95684814f,-0.81673646f,-7.5893383f,-4.388198f,0f ) ;
  }

  @Test
  public void test1049() {
    TestDrivers.surfaceShade(-451.0f,-468.0f,0f,0f,1038.0f,-2.0f,0f,-2033.0f,0f,0f,0f,0f,0f,-501.0f,-459.0f,-549.0f,0f,0f,0f,1851,-76.5429f,-10.025302f,78.23244f,-82.99951f,-99.99656f,0f ) ;
  }

  @Test
  public void test1050() {
    TestDrivers.surfaceShade(-452.0f,0f,0f,0f,236.0f,-991.0f,0f,16.0f,0f,0f,0f,0f,0f,-220.0f,-747.0f,-324.0f,-436.0f,699.0f,-665.0f,-1779,-0.46108913f,-0.1521907f,0.68053466f,-1.746646E-6f,0f,0f ) ;
  }

  @Test
  public void test1051() {
    TestDrivers.surfaceShade(-452.0f,0f,0f,0f,5.439319f,-42.813324f,0f,-6.371698f,0f,0f,0f,0f,0f,-100.0f,38.949406f,-33.206707f,0f,0f,0f,1,-0.08914561f,-0.4048585f,0.15173422f,33.0662f,0f,0f ) ;
  }

  @Test
  public void test1052() {
    TestDrivers.surfaceShade(-452.0f,-955.0f,526.0f,0f,503.0f,694.0f,0f,885.0f,0f,0f,0f,0f,0f,616.0f,1856.0f,-1456.0f,509.0f,-534.0f,1897.0f,712,-93.743866f,28.129902f,-3.8029704f,-10.948499f,93.18155f,21.797876f ) ;
  }

  @Test
  public void test1053() {
    TestDrivers.surfaceShade(453.0f,-936.0f,-757.0f,0f,59.0f,753.0f,0f,699.0f,0f,0f,0f,0f,0f,838.0f,-894.0f,-544.0f,-386.0f,141.0f,-781.0f,-896,-0.8632337f,0.039000075f,0.21042107f,-23.679796f,-28.60863f,19.551939f ) ;
  }

  @Test
  public void test1054() {
    TestDrivers.surfaceShade(-454.0f,0f,0f,0f,539.0f,1034.0f,0f,7.0f,0f,0f,0f,0f,0f,-509.0f,-619.0f,-85.0f,1383.0f,-1119.0f,640.0f,-180,0.68841785f,0.10297165f,0.6881029f,33.726883f,0f,0f ) ;
  }

  @Test
  public void test1055() {
    TestDrivers.surfaceShade(-454.0f,3222.0f,619.0f,0f,1729.0f,-340.0f,0f,-1.0f,0f,0f,0f,0f,0f,-157.0f,521.0f,-99.0f,0f,0f,0f,797,-92.4098f,-10.245125f,92.632614f,-97.339294f,65.777756f,71.390465f ) ;
  }

  @Test
  public void test1056() {
    TestDrivers.surfaceShade(-460.0f,0f,0f,0f,-85.0f,142.0f,694.0f,-115.0f,0f,0f,0f,0f,0f,766.0f,704.0f,995.0f,864.0f,206.0f,-502.0f,786,-5.0718637f,33.468456f,80.86429f,-6.7335043f,0f,0f ) ;
  }

  @Test
  public void test1057() {
    TestDrivers.surfaceShade(462.0f,-237.0f,-1696.0f,0f,384.0f,655.0f,0f,2660.0f,0f,0f,0f,0f,0f,658.0f,-665.0f,-393.0f,-1954.0f,-962.0f,-247.0f,-1001,38.721806f,-7.0148883f,76.701904f,61.62817f,-63.738445f,-39.15642f ) ;
  }

  @Test
  public void test1058() {
    TestDrivers.surfaceShade(-467.0f,-366.0f,0f,0f,238.0f,-5.0f,0f,3.0f,0f,0f,0f,0f,0f,1142.0f,153.0f,-1724.0f,0f,0f,0f,-452,0.5102913f,0.046773426f,0.8251866f,98.6613f,0.0093330555f,0f ) ;
  }

  @Test
  public void test1059() {
    TestDrivers.surfaceShade(467.0f,-941.0f,0f,0f,1282.0f,99.0f,0f,-75.0f,0f,0f,0f,0f,0f,-1276.0f,-670.0f,594.0f,1282.0f,126.0f,-145.0f,-612,0.019420365f,0.38222423f,0.47284618f,-26.333824f,100.0f,0f ) ;
  }

  @Test
  public void test1060() {
    TestDrivers.surfaceShade(47.0f,-9.0f,350.0f,0f,501.0f,-1.0f,0f,-120.0f,0f,0f,0f,0f,0f,509.0f,762.0f,918.0f,0f,0f,0f,325,43.292717f,-34.137226f,1.8992983f,85.83478f,40.3935f,68.19174f ) ;
  }

  @Test
  public void test1061() {
    TestDrivers.surfaceShade(476.0f,0f,0f,0f,714.0f,-390.0f,0f,786.0f,0f,0f,0f,0f,0f,594.0f,-285.0f,-988.0f,-36.0f,-285.0f,442.0f,-619,-90.09331f,100.0f,100.0f,100.0f,0f,0f ) ;
  }

  @Test
  public void test1062() {
    TestDrivers.surfaceShade(-477.0f,343.0f,-74.0f,0f,538.0f,-737.0f,0f,-490.0f,0f,0f,0f,0f,0f,736.0f,-859.0f,-881.0f,0f,0f,0f,728,-72.56019f,-24.14272f,90.90555f,51.492218f,73.651306f,-2.2276965E-10f ) ;
  }

  @Test
  public void test1063() {
    TestDrivers.surfaceShade(477.0f,-919.0f,0f,0f,1983.0f,-6.0f,0f,1.0f,0f,0f,0f,0f,0f,51.0f,-671.0f,-566.0f,0f,0f,0f,1251,0.35188666f,0.6851136f,0.24575683f,88.812805f,84.74711f,0f ) ;
  }

  @Test
  public void test1064() {
    TestDrivers.surfaceShade(48.0f,931.0f,237.0f,0f,287.0f,-228.0f,0f,-9.0f,0f,0f,0f,0f,0f,-396.0f,-926.0f,-652.0f,0f,0f,0f,226,-56.30286f,70.53465f,-65.9803f,0.12645279f,-26.87972f,0.026024956f ) ;
  }

  @Test
  public void test1065() {
    TestDrivers.surfaceShade(-48.0f,952.0f,0f,0f,312.0f,-533.0f,0f,714.0f,0f,0f,0f,0f,0f,652.0f,2094.0f,378.0f,-17.0f,-705.0f,263.0f,523,-0.16033143f,-0.47634384f,0.2250348f,95.37788f,-100.0f,0f ) ;
  }

  @Test
  public void test1066() {
    TestDrivers.surfaceShade(481.0f,-109.0f,-677.0f,0f,606.0f,-489.0f,0f,456.0f,0f,0f,0f,0f,0f,-28.0f,514.0f,-415.0f,-364.0f,-828.0f,136.0f,295,-81.57963f,-55.91254f,50.86756f,-44.137093f,42.15147f,59.4177f ) ;
  }

  @Test
  public void test1067() {
    TestDrivers.surfaceShade(-483.0f,-314.0f,0f,0f,985.0f,-797.0f,0f,-32.0f,0f,0f,0f,0f,0f,408.0f,-135.0f,-613.0f,0f,0f,0f,-1318,47.50307f,48.120228f,21.019611f,18.86022f,-34.425877f,0f ) ;
  }

  @Test
  public void test1068() {
    TestDrivers.surfaceShade(485.0f,488.0f,0f,0f,1211.0f,740.0f,0f,1012.0f,0f,0f,0f,0f,0f,-491.0f,-1720.0f,175.0f,-755.0f,923.0f,1031.0f,636,0.37065542f,0.49872392f,0.43609536f,100.0f,-84.50441f,0f ) ;
  }

  @Test
  public void test1069() {
    TestDrivers.surfaceShade(-485.0f,552.0f,-2188.0f,0f,62.0f,-730.0f,0f,-25.0f,0f,0f,0f,0f,0f,-115.0f,-454.0f,184.0f,0f,0f,0f,-2617,-47.25763f,36.390217f,60.252888f,-81.158905f,36.39355f,91.29459f ) ;
  }

  @Test
  public void test1070() {
    TestDrivers.surfaceShade(-485.0f,820.0f,0f,0f,188.0f,-601.0f,0f,792.0f,0f,0f,0f,0f,0f,361.0f,-939.0f,93.0f,-932.0f,581.0f,752.0f,255,-91.734505f,100.0f,100.0f,100.0f,-100.0f,0f ) ;
  }

  @Test
  public void test1071() {
    TestDrivers.surfaceShade(488.0f,-257.0f,-565.0f,0f,284.0f,-337.0f,0f,916.0f,0f,0f,0f,0f,0f,-246.0f,480.0f,920.0f,-189.0f,1245.0f,-681.0f,483,81.44891f,103.58498f,-91.10451f,-89.632095f,26.031816f,-13.359519f ) ;
  }

  @Test
  public void test1072() {
    TestDrivers.surfaceShade(-491.0f,325.0f,0f,0f,687.0f,880.0f,0f,-625.0f,0f,0f,0f,0f,0f,-999.0f,1318.0f,37.0f,758.0f,-1885.0f,1264.0f,1636,0.9025863f,-0.2884309f,0.104707316f,-100.0f,-40.757874f,0f ) ;
  }

  @Test
  public void test1073() {
    TestDrivers.surfaceShade(-496.0f,798.0f,0f,0f,1103.0f,57.0f,0f,-668.0f,0f,0f,0f,0f,0f,966.0f,664.0f,-957.0f,-370.0f,-673.0f,-331.0f,-433,25.080492f,96.59028f,92.33407f,-44.732746f,-32.913567f,0f ) ;
  }

  @Test
  public void test1074() {
    TestDrivers.surfaceShade(-499.0f,0f,0f,0f,235.0f,846.0f,-86.0f,-178.0f,0f,0f,0f,0f,0f,280.0f,222.0f,-200.0f,-17.0f,956.0f,455.0f,-477,-15.700473f,-100.0f,-100.0f,-12.18441f,0f,0f ) ;
  }

  @Test
  public void test1075() {
    TestDrivers.surfaceShade(502.0f,748.0f,-6.0f,0f,319.0f,455.0f,0f,17.0f,0f,0f,0f,0f,0f,984.0f,-275.0f,955.0f,-1683.0f,-197.0f,-460.0f,-1319,-17.34355f,-78.46057f,-4.72316f,100.0f,89.53604f,-0.039710328f ) ;
  }

  @Test
  public void test1076() {
    TestDrivers.surfaceShade(504.0f,-561.0f,0f,0f,107.0f,20.0f,0f,-271.0f,0f,0f,0f,0f,0f,-355.0f,-132.0f,-280.0f,998.0f,-672.0f,-719.0f,-550,20.410818f,-71.927605f,67.99897f,-48.989594f,34.36922f,0f ) ;
  }

  @Test
  public void test1077() {
    TestDrivers.surfaceShade(505.0f,0f,0f,0f,9.3538065f,0.0f,0f,-94.42796f,0f,0f,0f,0f,0f,-100.0f,-41.64218f,85.87085f,0f,0f,0f,8,3.2374582f,-0.07011009f,0.3320545f,6.5589575E-6f,0f,0f ) ;
  }

  @Test
  public void test1078() {
    TestDrivers.surfaceShade(-5.0f,1274.0f,0f,0f,469.0f,3634.0f,0f,1363.0f,0f,0f,0f,0f,0f,902.0f,93.0f,164.0f,-801.0f,666.0f,-819.0f,659,-0.058126453f,-0.5917188f,0.65524334f,-79.420845f,32.215042f,0f ) ;
  }

  @Test
  public void test1079() {
    TestDrivers.surfaceShade(51.0f,0f,0f,0f,68.79249f,-67.90698f,0f,0.0f,0f,0f,0f,0f,0f,-32.331917f,0.84424305f,-18.980963f,0f,0f,0f,-416,43.366833f,3.145192f,58.05578f,-17.902603f,0f,0f ) ;
  }

  @Test
  public void test1080() {
    TestDrivers.surfaceShade(518.0f,1966.0f,0f,720.0f,0f,0f,0f,394.0f,0f,0f,0f,0f,0f,859.0f,-652.0f,2.0f,-274.0f,-360.0f,559.0f,-1,0f,0f,0f,-32.03821f,74.379364f,0f ) ;
  }

  @Test
  public void test1081() {
    TestDrivers.surfaceShade(-518.0f,-469.0f,0f,0f,1976.0f,123.0f,-37.0f,-1224.0f,0f,0f,0f,0f,0f,723.0f,-593.0f,-1301.0f,-32.0f,1663.0f,-1040.0f,-426,-0.29437438f,0.17827651f,-0.08355937f,-94.06591f,84.746086f,0f ) ;
  }

  @Test
  public void test1082() {
    TestDrivers.surfaceShade(-518.0f,-79.0f,419.0f,0f,374.0f,196.0f,0f,-376.0f,0f,0f,0f,0f,0f,559.0f,-997.0f,932.0f,941.0f,890.0f,366.0f,-68,6.9148426f,43.595276f,-58.919956f,0.58729696f,-23.384666f,-33.866154f ) ;
  }

  @Test
  public void test1083() {
    TestDrivers.surfaceShade(-521.0f,499.0f,0f,0f,173.0f,-1499.0f,0f,-66.0f,0f,0f,0f,0f,0f,-313.0f,-964.0f,-98.0f,0f,0f,0f,893,-0.13167939f,0.07135335f,0.15844247f,5.9893975f,6.829175f,0f ) ;
  }

  @Test
  public void test1084() {
    TestDrivers.surfaceShade(-522.0f,0f,0f,0f,22.862036f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,100.0f,100.0f,100.0f,0f,0f,0f,1,0.00505861f,0.27506742f,-0.8449977f,-18.34844f,0f,0f ) ;
  }

  @Test
  public void test1085() {
    TestDrivers.surfaceShade(522.0f,0f,0f,0f,542.0f,573.0f,0f,2913.0f,0f,0f,0f,0f,0f,1275.0f,955.0f,-560.0f,-1499.0f,390.0f,-798.0f,513,-0.08597108f,-0.15725653f,-0.40119538f,-19.124262f,0f,0f ) ;
  }

  @Test
  public void test1086() {
    TestDrivers.surfaceShade(-528.0f,-18.0f,0f,0f,738.0f,541.0f,0f,228.0f,0f,0f,0f,0f,0f,-589.0f,-159.0f,187.0f,-839.0f,430.0f,-849.0f,-917,35.218266f,-74.69062f,47.421127f,-96.67591f,-37.639923f,0f ) ;
  }

  @Test
  public void test1087() {
    TestDrivers.surfaceShade(534.0f,-1138.0f,0f,0f,1486.0f,9.0f,0f,4.0f,0f,0f,0f,0f,0f,3.0f,35.0f,1793.0f,0f,0f,0f,1355,0.8160341f,-0.42112327f,-0.21014386f,1.0552061f,-43.39477f,0f ) ;
  }

  @Test
  public void test1088() {
    TestDrivers.surfaceShade(-543.0f,216.0f,152.0f,0f,993.0f,1086.0f,0f,1109.0f,0f,0f,0f,0f,0f,-188.0f,149.0f,-340.0f,884.0f,-577.0f,-808.0f,-240,-99.67514f,-49.102352f,33.596107f,43.300766f,45.490852f,-48.56073f ) ;
  }

  @Test
  public void test1089() {
    TestDrivers.surfaceShade(546.0f,0f,0f,0f,34.0f,0.0f,0f,1344.0f,0f,0f,0f,0f,0f,871.0f,772.0f,-685.0f,-1810.0f,68.0f,-37.0f,-31,46.565636f,-66.12985f,18.136675f,2.3505358E-9f,0f,0f ) ;
  }

  @Test
  public void test1090() {
    TestDrivers.surfaceShade(-550.0f,0f,0f,-1024.0f,0f,0f,0f,-51.800682f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-85.03217f,0f,0f ) ;
  }

  @Test
  public void test1091() {
    TestDrivers.surfaceShade(550.0f,-191.0f,269.0f,704.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-100.0f,51.305172f,-2.444253f ) ;
  }

  @Test
  public void test1092() {
    TestDrivers.surfaceShade(556.0f,194.0f,530.0f,-123.0f,0f,0f,0f,-13.07145f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-68.39083f,-4.1907635E-5f,12.423974f ) ;
  }

  @Test
  public void test1093() {
    TestDrivers.surfaceShade(-558.0f,732.0f,-72.0f,0f,866.0f,-690.0f,0f,1130.0f,0f,0f,0f,0f,0f,282.0f,-697.0f,-452.0f,-1178.0f,48.0f,-63.0f,-680,5.631951f,1.1879468f,2.8029575f,100.0f,100.0f,20.431005f ) ;
  }

  @Test
  public void test1094() {
    TestDrivers.surfaceShade(56.0f,-1307.0f,0f,0f,994.0f,878.0f,0f,1119.0f,0f,0f,0f,0f,0f,789.0f,3190.0f,1108.0f,-9.0f,-973.0f,1049.0f,962,0.019214142f,-0.034340095f,-0.1662336f,-6.186544f,-44.888397f,0f ) ;
  }

  @Test
  public void test1095() {
    TestDrivers.surfaceShade(-562.0f,1021.0f,391.0f,0f,427.0f,-820.0f,0f,534.0f,0f,0f,0f,0f,0f,59.0f,884.0f,-129.0f,838.0f,-1807.0f,-916.0f,40,-6.563994f,11.265042f,74.19397f,-66.985306f,100.0f,96.46526f ) ;
  }

  @Test
  public void test1096() {
    TestDrivers.surfaceShade(-562.0f,-1767.0f,0f,598.0f,0f,0f,0f,238.0f,0f,0f,0f,0f,0f,-905.0f,-1197.0f,651.0f,-110.0f,-316.0f,-735.0f,13,0f,0f,0f,58.83044f,72.86186f,0f ) ;
  }

  @Test
  public void test1097() {
    TestDrivers.surfaceShade(565.0f,1102.0f,274.0f,0f,965.0f,767.0f,0f,-341.0f,0f,0f,0f,0f,0f,308.0f,-135.0f,-910.0f,888.0f,-323.0f,751.0f,-994,12.236708f,-92.44718f,56.34688f,5.236353E-11f,-39.064754f,-57.55708f ) ;
  }

  @Test
  public void test1098() {
    TestDrivers.surfaceShade(568.0f,-707.0f,-165.0f,-240.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,-22.497133f,5.8934465E-6f,51.07815f ) ;
  }

  @Test
  public void test1099() {
    TestDrivers.surfaceShade(572.0f,-458.0f,0f,-603.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-2.8992567E-6f,3.6209058E-6f,0f ) ;
  }

  @Test
  public void test1100() {
    TestDrivers.surfaceShade(573.0f,-934.0f,-61.0f,0f,278.0f,49.0f,0f,-331.0f,0f,0f,0f,0f,0f,-996.0f,-101.0f,-917.0f,-182.0f,-914.0f,469.0f,-597,41.948704f,-16.74755f,7.2268724f,20.570772f,81.82544f,-9.381545f ) ;
  }

  @Test
  public void test1101() {
    TestDrivers.surfaceShade(-577.0f,-810.0f,-252.0f,0f,258.0f,326.0f,0f,992.0f,0f,0f,0f,0f,0f,361.0f,234.0f,-29.0f,1213.0f,693.0f,928.0f,294,-4.1811595f,-3.2723331f,-78.45257f,85.26674f,-90.973724f,65.794304f ) ;
  }

  @Test
  public void test1102() {
    TestDrivers.surfaceShade(578.0f,1635.0f,751.0f,0f,2330.0f,-705.0f,0f,-1195.0f,0f,0f,0f,0f,0f,-192.0f,280.0f,-27.0f,0f,0f,0f,980,-39.127926f,-19.638432f,74.58521f,182.31134f,-72.19096f,121.00035f ) ;
  }

  @Test
  public void test1103() {
    TestDrivers.surfaceShade(579.0f,0f,0f,0f,0.82586765f,-7.1054274E-15f,0f,2.8646346E-18f,0f,0f,0f,0f,0f,-17.078514f,12.579656f,-25.369955f,0f,0f,0f,-15,2.5600917f,-2.2171838f,-1.6988654f,0.6427717f,0f,0f ) ;
  }

  @Test
  public void test1104() {
    TestDrivers.surfaceShade(58.0f,-1307.0f,960.0f,24.0f,0f,0f,0f,-84.16762f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,4,0f,0f,0f,7.183908E-4f,14.5439f,114.576546f ) ;
  }

  @Test
  public void test1105() {
    TestDrivers.surfaceShade(58.0f,-1920.0f,1856.0f,0f,67.0f,-751.0f,0f,-784.0f,0f,0f,0f,0f,0f,-459.0f,-479.0f,-52.0f,0f,0f,0f,618,69.325645f,26.612453f,6.3784685f,-71.50845f,91.191734f,-61.806805f ) ;
  }

  @Test
  public void test1106() {
    TestDrivers.surfaceShade(-581.0f,0f,1134.0f,0f,179.0f,-745.0f,0f,520.0f,0f,0f,0f,0f,0f,348.0f,996.0f,-1290.0f,115.0f,1612.0f,-2120.0f,976,-92.31465f,37.20724f,3.8239644f,25.569538f,0f,-48.949978f ) ;
  }

  @Test
  public void test1107() {
    TestDrivers.surfaceShade(582.0f,0f,0f,0f,35.422256f,-21.699259f,0f,-6.5133443f,0f,0f,0f,0f,0f,-93.842094f,48.660168f,-85.86538f,0f,0f,0f,462,5.9311366f,22.5825f,6.315444f,55.149036f,0f,0f ) ;
  }

  @Test
  public void test1108() {
    TestDrivers.surfaceShade(582.0f,-1687.0f,-1235.0f,0f,321.0f,-239.0f,0f,-842.0f,0f,0f,0f,0f,0f,929.0f,3.0f,755.0f,0f,0f,0f,-672,-0.03573806f,0.16597818f,-0.964107f,-50.58891f,60.46126f,77.69632f ) ;
  }

  @Test
  public void test1109() {
    TestDrivers.surfaceShade(586.0f,0f,0f,0f,100.0f,-78.5553f,0f,-53.132904f,0f,0f,0f,0f,0f,-39.867245f,100.0f,-88.75387f,0f,0f,0f,4,-7.0946403f,0.34646422f,5.1688147f,-98.7464f,0f,0f ) ;
  }

  @Test
  public void test1110() {
    TestDrivers.surfaceShade(587.0f,16.0f,0f,0f,745.0f,271.0f,0f,186.0f,0f,0f,0f,0f,0f,-259.0f,535.0f,-359.0f,798.0f,-123.0f,-374.0f,1359,-0.37091565f,0.2812555f,0.6867573f,-100.0f,0.011927239f,0f ) ;
  }

  @Test
  public void test1111() {
    TestDrivers.surfaceShade(-589.0f,-71.0f,0f,0f,924.0f,966.0f,777.0f,-971.0f,0f,0f,0f,0f,0f,462.0f,7.0f,-52.0f,178.0f,-247.0f,-849.0f,226,23.561308f,68.18615f,8.429143f,58.69675f,49.740124f,0f ) ;
  }

  @Test
  public void test1112() {
    TestDrivers.surfaceShade(-59.0f,0f,0f,0f,0.27678528f,-35.22596f,0f,-81.25421f,0f,0f,0f,0f,0f,42.23771f,-96.083f,94.14137f,0f,0f,0f,9,-1.6162641f,0.701349f,-0.34825042f,2.91311f,0f,0f ) ;
  }

  @Test
  public void test1113() {
    TestDrivers.surfaceShade(-592.0f,0f,0f,0f,372.0f,487.0f,0f,-119.0f,0f,0f,0f,0f,0f,-337.0f,769.0f,139.0f,383.0f,-318.0f,-753.0f,-449,-36.591778f,-24.07392f,-0.3951448f,3.6267643f,0f,0f ) ;
  }

  @Test
  public void test1114() {
    TestDrivers.surfaceShade(-592.0f,-153.0f,-1416.0f,0f,449.0f,2354.0f,0f,-1174.0f,0f,0f,0f,0f,0f,-279.0f,-1460.0f,100.0f,-341.0f,542.0f,455.0f,1511,-0.49151707f,0.20058177f,-0.7231371f,90.66717f,49.06522f,-30.541489f ) ;
  }

  @Test
  public void test1115() {
    TestDrivers.surfaceShade(-593.0f,971.0f,1335.0f,0f,97.0f,-805.0f,0f,313.0f,0f,0f,0f,0f,0f,-477.0f,208.0f,-482.0f,97.0f,982.0f,706.0f,578,-52.983887f,46.03513f,72.30004f,50.38435f,-0.8837503f,50.7722f ) ;
  }

  @Test
  public void test1116() {
    TestDrivers.surfaceShade(-595.0f,0f,-1211.0f,0f,1175.0f,6.0f,0f,-726.0f,0f,0f,0f,0f,0f,267.0f,-333.0f,-348.0f,0f,0f,0f,48,-100.0f,16.572142f,-92.58196f,-25.758266f,0f,-89.49297f ) ;
  }

  @Test
  public void test1117() {
    TestDrivers.surfaceShade(-60.0f,0f,0f,0f,891.0f,532.0f,754.0f,-839.0f,0f,0f,0f,0f,0f,-966.0f,95.0f,-440.0f,-594.0f,-110.0f,152.0f,840,1.5242963f,31.919113f,41.8153f,84.47613f,0f,0f ) ;
  }

  @Test
  public void test1118() {
    TestDrivers.surfaceShade(-602.0f,-341.0f,333.0f,0f,882.0f,-117.0f,0f,1184.0f,0f,0f,0f,0f,0f,-1.0f,254.0f,695.0f,-775.0f,-640.0f,710.0f,-655,-84.51153f,20.631306f,-45.394596f,-55.921703f,-26.74258f,-37.091312f ) ;
  }

  @Test
  public void test1119() {
    TestDrivers.surfaceShade(608.0f,66.0f,-80.0f,0f,863.0f,1398.0f,0f,391.0f,0f,0f,0f,0f,0f,160.0f,424.0f,-191.0f,-293.0f,-795.0f,-81.0f,1265,0.2702848f,-0.0659077f,0.080108926f,-15.066769f,75.85901f,1.6436827f ) ;
  }

  @Test
  public void test1120() {
    TestDrivers.surfaceShade(-609.0f,321.0f,-449.0f,0f,190.0f,625.0f,0f,8.0f,0f,0f,0f,0f,0f,684.0f,364.0f,193.0f,-956.0f,254.0f,-477.0f,802,-18.097157f,-92.44324f,-9.650238f,15.029005f,-34.598183f,-0.53477484f ) ;
  }

  @Test
  public void test1121() {
    TestDrivers.surfaceShade(611.0f,0f,0f,0f,91.96419f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,-37.08944f,32.555923f,10.956747f,0f,0f,0f,-1531,-0.4356454f,-0.44735232f,-0.14546992f,9.023349f,0f,0f ) ;
  }

  @Test
  public void test1122() {
    TestDrivers.surfaceShade(611.0f,-819.0f,-362.0f,0f,713.0f,-687.0f,0f,91.0f,0f,0f,0f,0f,0f,938.0f,195.0f,-486.0f,-964.0f,-684.0f,724.0f,-1306,0.11177348f,-0.84955746f,0.11450457f,100.0f,-100.0f,-14.8657465f ) ;
  }

  @Test
  public void test1123() {
    TestDrivers.surfaceShade(-616.0f,-499.0f,0f,0f,290.0f,1307.0f,0f,795.0f,0f,0f,0f,0f,0f,878.0f,-987.0f,-652.0f,812.0f,-827.0f,173.0f,58,-62.518238f,-50.718502f,-7.410812f,100.0f,15.622267f,0f ) ;
  }

  @Test
  public void test1124() {
    TestDrivers.surfaceShade(618.0f,975.0f,0f,0f,522.0f,-1169.0f,0f,-702.0f,0f,0f,0f,0f,0f,-125.0f,-695.0f,838.0f,0f,0f,0f,717,0.6817323f,-0.0010023209f,-0.32441828f,84.445404f,28.425467f,0f ) ;
  }

  @Test
  public void test1125() {
    TestDrivers.surfaceShade(-62.0f,-375.0f,0f,0f,807.0f,-264.0f,0f,893.0f,0f,0f,0f,0f,0f,-143.0f,32.0f,399.0f,914.0f,725.0f,-1381.0f,-188,-75.06676f,47.42539f,-30.707165f,-56.549313f,-16.280184f,0f ) ;
  }

  @Test
  public void test1126() {
    TestDrivers.surfaceShade(-624.0f,1567.0f,250.0f,0f,1558.0f,527.0f,0f,-1012.0f,0f,0f,0f,0f,0f,469.0f,-319.0f,-428.0f,512.0f,-374.0f,-861.0f,-638,-2.3948858f,-2.5403092f,-0.7309412f,-100.0f,100.0f,-100.0f ) ;
  }

  @Test
  public void test1127() {
    TestDrivers.surfaceShade(626.0f,261.0f,0f,0f,85.0f,-1439.0f,0f,-473.0f,0f,0f,0f,0f,0f,359.0f,-579.0f,378.0f,0f,0f,0f,-1008,-72.7752f,-13.76908f,48.026455f,41.693153f,100.0f,0f ) ;
  }

  @Test
  public void test1128() {
    TestDrivers.surfaceShade(628.0f,0f,0f,-874.0f,0f,0f,0f,14.405943f,0f,0f,0f,0f,0f,39.889084f,-9.674196f,-31.794363f,-506.0f,-6.0f,-633.0f,6,0f,0f,0f,-23.153776f,0f,0f ) ;
  }

  @Test
  public void test1129() {
    TestDrivers.surfaceShade(63.0f,0f,0f,0f,4.36149f,-77.839905f,0f,-53.02537f,0f,0f,0f,0f,0f,68.94164f,52.673347f,-88.57102f,0f,0f,0f,-188,-11.8038435f,-43.24635f,-19.131481f,5.437886f,0f,0f ) ;
  }

  @Test
  public void test1130() {
    TestDrivers.surfaceShade(631.0f,250.0f,1797.0f,811.0f,0f,0f,0f,-90.37876f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,100.0f,47.065117f,-91.16674f ) ;
  }

  @Test
  public void test1131() {
    TestDrivers.surfaceShade(-634.0f,-107.0f,0f,0f,16.0f,413.0f,0f,-70.0f,0f,0f,0f,0f,0f,-462.0f,447.0f,-362.0f,1129.0f,909.0f,503.0f,-1013,-29.622845f,-52.943413f,-27.568922f,55.514263f,-99.999985f,0f ) ;
  }

  @Test
  public void test1132() {
    TestDrivers.surfaceShade(-634.0f,-721.0f,518.0f,0f,711.0f,-620.0f,0f,-452.0f,0f,0f,0f,0f,0f,-852.0f,-644.0f,-207.0f,0f,0f,0f,987,86.74709f,-24.029987f,-85.699295f,-46.49297f,48.006855f,-16.557924f ) ;
  }

  @Test
  public void test1133() {
    TestDrivers.surfaceShade(-635.0f,50.0f,-902.0f,-260.0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,6.056935E-6f,-7.6923076E-5f,100.0f ) ;
  }

  @Test
  public void test1134() {
    TestDrivers.surfaceShade(636.0f,963.0f,0f,0f,487.0f,-630.0f,0f,447.0f,0f,0f,0f,0f,0f,-891.0f,897.0f,117.0f,-574.0f,-817.0f,-340.0f,106,43.347042f,-70.46258f,50.07794f,70.500946f,95.24809f,0f ) ;
  }

  @Test
  public void test1135() {
    TestDrivers.surfaceShade(638.0f,-700.0f,-957.0f,0f,844.0f,1429.0f,0f,438.0f,0f,0f,0f,0f,0f,-395.0f,1414.0f,-826.0f,-491.0f,-862.0f,-700.0f,368,-0.2914497f,-0.5021112f,-0.117628075f,51.116684f,32.538654f,-13.591178f ) ;
  }

  @Test
  public void test1136() {
    TestDrivers.surfaceShade(-64.0f,175.0f,-213.0f,0f,513.0f,-381.0f,0f,-360.0f,0f,0f,0f,0f,0f,200.0f,-414.0f,571.0f,0f,0f,0f,-430,-8.563668f,-7.50909f,-11.0085535f,-100.0f,90.51842f,-96.500145f ) ;
  }

  @Test
  public void test1137() {
    TestDrivers.surfaceShade(-647.0f,0f,0f,0f,-220.0f,-582.0f,975.0f,321.0f,0f,0f,0f,0f,0f,-71.0f,48.0f,-106.0f,358.0f,498.0f,-220.0f,-238,73.89454f,21.888557f,35.581963f,-51.025913f,0f,0f ) ;
  }

  @Test
  public void test1138() {
    TestDrivers.surfaceShade(-648.0f,-1097.0f,0f,0f,928.0f,-678.0f,0f,-3.0f,0f,0f,0f,0f,0f,-105.0f,1247.0f,934.0f,0f,0f,0f,-1056,8.780254f,-46.319855f,62.829536f,-1.4944252f,-100.0f,0f ) ;
  }

  @Test
  public void test1139() {
    TestDrivers.surfaceShade(-651.0f,0f,0f,0f,72.27131f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-12.227117f,29.308052f,-14.158238f,0f,0f,0f,703,56.06794f,39.10024f,32.518356f,-24.070139f,0f,0f ) ;
  }

  @Test
  public void test1140() {
    TestDrivers.surfaceShade(651.0f,-689.0f,-571.0f,0f,349.0f,1150.0f,0f,463.0f,0f,0f,0f,0f,0f,-283.0f,239.0f,474.0f,60.0f,496.0f,189.0f,-934,-32.080177f,-41.05319f,1.5464594f,72.64026f,80.27239f,57.273746f ) ;
  }

  @Test
  public void test1141() {
    TestDrivers.surfaceShade(653.0f,0f,0f,0f,13.0f,311.0f,0f,1.0f,0f,0f,0f,0f,0f,1309.0f,530.0f,76.0f,-2130.0f,-86.0f,-361.0f,-2236,-0.068248264f,-0.2203251f,-0.3374571f,99.168f,0f,0f ) ;
  }

  @Test
  public void test1142() {
    TestDrivers.surfaceShade(658.0f,-100.0f,0f,-407.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,53.331593f,61.914772f,0f ) ;
  }

  @Test
  public void test1143() {
    TestDrivers.surfaceShade(661.0f,0f,0f,0f,493.0f,667.0f,400.0f,-870.0f,0f,0f,0f,0f,0f,-742.0f,-800.0f,-540.0f,68.0f,-507.0f,512.0f,711,-36.091213f,68.34416f,-18.04115f,-65.34833f,0f,0f ) ;
  }

  @Test
  public void test1144() {
    TestDrivers.surfaceShade(-662.0f,-464.0f,371.0f,0f,378.0f,-1606.0f,0f,165.0f,0f,0f,0f,0f,0f,1172.0f,-751.0f,423.0f,-535.0f,1630.0f,-480.0f,-323,-0.43158713f,-0.22485422f,0.7185695f,4.2626195f,25.597017f,-2.3936899f ) ;
  }

  @Test
  public void test1145() {
    TestDrivers.surfaceShade(-662.0f,-94.0f,0f,0f,24.0f,-1.0f,0f,3.0f,0f,0f,0f,0f,0f,-160.0f,996.0f,-164.0f,0f,0f,0f,812,62.724445f,9.288868f,-4.7817006f,-12.755084f,-100.0f,0f ) ;
  }

  @Test
  public void test1146() {
    TestDrivers.surfaceShade(-663.0f,-773.0f,0f,0f,1276.0f,517.0f,-286.0f,532.0f,0f,0f,0f,0f,0f,88.0f,345.0f,-655.0f,-1203.0f,860.0f,2545.0f,750,61.77356f,91.83037f,56.66809f,-138.59482f,-7.355231f,0f ) ;
  }

  @Test
  public void test1147() {
    TestDrivers.surfaceShade(665.0f,0f,0f,0f,83.0f,415.0f,593.0f,-952.0f,0f,0f,0f,0f,0f,883.0f,-265.0f,-179.0f,-229.0f,410.0f,-86.0f,-967,58.095913f,-65.0403f,-48.330994f,86.40334f,0f,0f ) ;
  }

  @Test
  public void test1148() {
    TestDrivers.surfaceShade(-667.0f,1227.0f,0f,90.0f,0f,0f,0f,-57.89688f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-1.6658338E-5f,-39.350014f,0f ) ;
  }

  @Test
  public void test1149() {
    TestDrivers.surfaceShade(-667.0f,135.0f,643.0f,0f,255.0f,-1913.0f,0f,-784.0f,0f,0f,0f,0f,0f,-633.0f,400.0f,234.0f,0f,0f,0f,369,-31.12517f,-43.904057f,-9.147907f,-3.0133622f,44.003696f,22.508215f ) ;
  }

  @Test
  public void test1150() {
    TestDrivers.surfaceShade(-670.0f,-445.0f,0f,0f,608.0f,-330.0f,0f,-1.0f,0f,0f,0f,0f,0f,587.0f,-750.0f,521.0f,0f,0f,0f,-1474,23.670858f,-48.961376f,-128.11945f,96.02442f,-81.793594f,0f ) ;
  }

  @Test
  public void test1151() {
    TestDrivers.surfaceShade(67.0f,0f,0f,678.0f,0f,0f,0f,29.03378f,0f,0f,0f,0f,0f,100.0f,60.89094f,-39.86755f,-2037.0f,728.0f,-9.0f,5,0f,0f,0f,100.0f,0f,0f ) ;
  }

  @Test
  public void test1152() {
    TestDrivers.surfaceShade(671.0f,-636.0f,0f,0f,27.0f,-935.0f,0f,181.0f,0f,0f,0f,0f,0f,-301.0f,288.0f,-700.0f,-52.0f,-991.0f,-136.0f,-127,0.46803406f,0.5471771f,0.02386967f,2.5281625f,-2.667291f,0f ) ;
  }

  @Test
  public void test1153() {
    TestDrivers.surfaceShade(-689.0f,324.0f,504.0f,0f,108.0f,447.0f,0f,-796.0f,0f,0f,0f,0f,0f,845.0f,701.0f,-504.0f,558.0f,-234.0f,914.0f,-35,-121.831604f,35.2778f,31.161234f,-67.72736f,-25.958563f,-17.302067f ) ;
  }

  @Test
  public void test1154() {
    TestDrivers.surfaceShade(-690.0f,0f,336.0f,0f,1378.0f,2.0f,0f,-124.0f,0f,0f,0f,0f,0f,-333.0f,-975.0f,-386.0f,0f,0f,0f,606,62.00161f,68.61505f,-90.90141f,34.89416f,0f,113.50262f ) ;
  }

  @Test
  public void test1155() {
    TestDrivers.surfaceShade(690.0f,396.0f,0f,0f,304.0f,0.0f,0f,-2507.0f,0f,0f,0f,0f,0f,282.0f,-606.0f,-824.0f,0f,0f,0f,-1449,0.30291224f,3.9377334f,-2.7922878f,1.5116905f,9.580965f,0f ) ;
  }

  @Test
  public void test1156() {
    TestDrivers.surfaceShade(-695.0f,1014.0f,944.0f,0f,181.0f,-566.0f,0f,-1487.0f,0f,0f,0f,0f,0f,-94.0f,-579.0f,66.0f,0f,0f,0f,-1331,62.233124f,-1.56856f,74.874504f,-70.19808f,-81.37935f,-7.7618384f ) ;
  }

  @Test
  public void test1157() {
    TestDrivers.surfaceShade(699.0f,0f,0f,0f,12.732414f,-10.401913f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,-8.747535f,-76.69433f,0f,0f,0f,2,-0.7284775f,-0.44547492f,-0.34787124f,43.188877f,0f,0f ) ;
  }

  @Test
  public void test1158() {
    TestDrivers.surfaceShade(699.0f,-383.0f,0f,-1035.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-8.599402f,85.46209f,0f ) ;
  }

  @Test
  public void test1159() {
    TestDrivers.surfaceShade(-699.0f,-769.0f,320.0f,0f,321.0f,959.0f,0f,993.0f,0f,0f,0f,0f,0f,-738.0f,-481.0f,1190.0f,-598.0f,864.0f,-156.0f,-179,-68.55397f,48.25277f,-86.65585f,66.6678f,-55.531094f,-11.545756f ) ;
  }

  @Test
  public void test1160() {
    TestDrivers.surfaceShade(70.0f,-2016.0f,0f,0f,283.0f,775.0f,0f,566.0f,0f,0f,0f,0f,0f,594.0f,852.0f,-337.0f,-1942.0f,319.0f,-621.0f,-1739,0.22811322f,0.16929597f,0.8300873f,4.901045f,100.0f,0f ) ;
  }

  @Test
  public void test1161() {
    TestDrivers.surfaceShade(702.0f,566.0f,344.0f,0f,905.0f,898.0f,0f,-272.0f,0f,0f,0f,0f,0f,538.0f,628.0f,951.0f,973.0f,-152.0f,745.0f,869,-94.18145f,-2.543333f,54.959866f,47.255066f,83.549126f,96.433304f ) ;
  }

  @Test
  public void test1162() {
    TestDrivers.surfaceShade(-702.0f,669.0f,573.0f,0f,737.0f,148.0f,0f,-1284.0f,0f,0f,0f,0f,0f,-204.0f,-1834.0f,261.0f,428.0f,602.0f,-816.0f,919,0.30147213f,0.27181908f,-0.9064561f,55.026344f,-7.2241955f,-64.67049f ) ;
  }

  @Test
  public void test1163() {
    TestDrivers.surfaceShade(-708.0f,-704.0f,0f,0f,0.0f,-287.0f,0f,140.0f,0f,0f,0f,0f,0f,-829.0f,14.0f,-311.0f,925.0f,867.0f,385.0f,-315,100.0f,-85.879135f,12.167653f,-76.3879f,-15.048049f,0f ) ;
  }

  @Test
  public void test1164() {
    TestDrivers.surfaceShade(7.0f,-348.0f,-1135.0f,-9.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-2,0f,0f,0f,91.280594f,69.40478f,113.86826f ) ;
  }

  @Test
  public void test1165() {
    TestDrivers.surfaceShade(71.0f,0f,35.0f,-131.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-1.0751532E-4f,0f,87.530754f ) ;
  }

  @Test
  public void test1166() {
    TestDrivers.surfaceShade(-714.0f,-1380.0f,0f,0f,201.0f,-859.0f,0f,-72.0f,0f,0f,0f,0f,0f,-972.0f,-403.0f,814.0f,0f,0f,0f,484,54.84437f,48.53811f,39.43704f,-20.423613f,-96.6458f,0f ) ;
  }

  @Test
  public void test1167() {
    TestDrivers.surfaceShade(-715.0f,-77.0f,-2070.0f,-10.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,69.39979f,0.0012987013f,4.830918E-5f ) ;
  }

  @Test
  public void test1168() {
    TestDrivers.surfaceShade(-719.0f,-15.0f,1318.0f,0f,2951.0f,563.0f,-198.0f,-1241.0f,0f,0f,0f,0f,0f,426.0f,-594.0f,-1606.0f,-392.0f,-1420.0f,-697.0f,398,-0.5826971f,0.4651329f,-0.3031964f,97.6001f,94.5933f,-100.0f ) ;
  }

  @Test
  public void test1169() {
    TestDrivers.surfaceShade(72.0f,-504.0f,0f,0f,401.0f,-1367.0f,0f,-1491.0f,0f,0f,0f,0f,0f,-67.0f,-300.0f,27.0f,0f,0f,0f,-669,-0.43069905f,0.07201951f,-0.41929823f,8.50984E-6f,-48.979286f,0f ) ;
  }

  @Test
  public void test1170() {
    TestDrivers.surfaceShade(-722.0f,-1006.0f,-554.0f,0f,77.0f,730.0f,0f,-2533.0f,0f,0f,0f,0f,0f,-693.0f,-907.0f,377.0f,-704.0f,-809.0f,-810.0f,919,26.530567f,-15.325777f,11.89709f,-71.13923f,-41.244198f,-56.984585f ) ;
  }

  @Test
  public void test1171() {
    TestDrivers.surfaceShade(723.0f,1202.0f,-948.0f,0f,456.0f,153.0f,0f,2211.0f,0f,0f,0f,0f,0f,-126.0f,597.0f,1645.0f,1424.0f,-372.0f,807.0f,662,-95.332016f,-49.447887f,10.643472f,52.015224f,-100.0f,22.000418f ) ;
  }

  @Test
  public void test1172() {
    TestDrivers.surfaceShade(-727.0f,-148.0f,71.0f,266.0f,0f,0f,0f,-78.32233f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,70.967674f,32.025356f,-13.570803f ) ;
  }

  @Test
  public void test1173() {
    TestDrivers.surfaceShade(727.0f,-872.0f,927.0f,0f,17.0f,846.0f,0f,-1076.0f,0f,0f,0f,0f,0f,831.0f,-587.0f,-990.0f,-56.0f,1057.0f,-632.0f,-153,-62.3866f,-75.15187f,-7.8071904f,66.60858f,91.446304f,50.22405f ) ;
  }

  @Test
  public void test1174() {
    TestDrivers.surfaceShade(-73.0f,-610.0f,-1528.0f,-16.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,-100.0f,1.0245902E-4f,-14.086925f ) ;
  }

  @Test
  public void test1175() {
    TestDrivers.surfaceShade(-735.0f,653.0f,0f,0f,941.0f,268.0f,0f,632.0f,0f,0f,0f,0f,0f,-105.0f,-714.0f,-945.0f,620.0f,448.0f,1349.0f,-1447,0.7994795f,0.5806137f,0.012950654f,-52.21055f,0.084451266f,0f ) ;
  }

  @Test
  public void test1176() {
    TestDrivers.surfaceShade(736.0f,-167.0f,-431.0f,-98.0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-1.3864242E-5f,68.0835f,57.430134f ) ;
  }

  @Test
  public void test1177() {
    TestDrivers.surfaceShade(-736.0f,-59.0f,908.0f,0f,357.0f,-404.0f,0f,-186.0f,0f,0f,0f,0f,0f,62.0f,932.0f,-66.0f,0f,0f,0f,-514,6.0867643f,4.4715104f,68.86102f,-100.0f,-99.999985f,100.0f ) ;
  }

  @Test
  public void test1178() {
    TestDrivers.surfaceShade(737.0f,544.0f,217.0f,74.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,54.626804f,2.4841018E-5f,-1.2635993f ) ;
  }

  @Test
  public void test1179() {
    TestDrivers.surfaceShade(738.0f,1174.0f,0f,0f,810.0f,568.0f,0f,209.0f,0f,0f,0f,0f,0f,876.0f,-603.0f,130.0f,-851.0f,-629.0f,-723.0f,140,-25.535156f,-0.11503975f,25.730711f,-100.0f,-100.0f,0f ) ;
  }

  @Test
  public void test1180() {
    TestDrivers.surfaceShade(74.0f,-1040.0f,0f,0f,703.0f,-200.0f,0f,27.0f,0f,0f,0f,0f,0f,-281.0f,-61.0f,277.0f,460.0f,175.0f,806.0f,1244,-47.96592f,-4.4562883f,-49.63992f,8.622351f,3.2256677f,0f ) ;
  }

  @Test
  public void test1181() {
    TestDrivers.surfaceShade(-741.0f,-1586.0f,0f,0f,1238.0f,-2.0f,0f,-19.0f,0f,0f,0f,0f,0f,715.0f,419.0f,-415.0f,0f,0f,0f,901,-90.6015f,55.56104f,-100.0f,-100.0f,-43.140217f,0f ) ;
  }

  @Test
  public void test1182() {
    TestDrivers.surfaceShade(-744.0f,56.0f,-131.0f,0f,50.0f,-787.0f,0f,-419.0f,0f,0f,0f,0f,0f,-793.0f,-874.0f,-217.0f,0f,0f,0f,-376,39.29842f,-26.308584f,-6.7757735f,42.68325f,-84.44561f,-97.93068f ) ;
  }

  @Test
  public void test1183() {
    TestDrivers.surfaceShade(-748.0f,-993.0f,-504.0f,0f,388.0f,-425.0f,0f,1229.0f,0f,0f,0f,0f,0f,-611.0f,-527.0f,145.0f,-1277.0f,561.0f,241.0f,-482,19.436398f,-22.254507f,1.0173326f,-100.0f,34.009434f,-40.342037f ) ;
  }

  @Test
  public void test1184() {
    TestDrivers.surfaceShade(-749.0f,0f,0f,866.0f,0f,0f,0f,165.2039f,0f,0f,0f,0f,0f,-69.5123f,93.49085f,-16.698677f,933.0f,238.0f,118.0f,-2,0f,0f,0f,84.57455f,0f,0f ) ;
  }

  @Test
  public void test1185() {
    TestDrivers.surfaceShade(750.0f,-151.0f,-854.0f,0f,170.0f,687.0f,0f,87.0f,0f,0f,0f,0f,0f,-225.0f,479.0f,-159.0f,1453.0f,326.0f,-567.0f,-257,97.862175f,28.40421f,47.402966f,83.64228f,34.475773f,-43.740818f ) ;
  }

  @Test
  public void test1186() {
    TestDrivers.surfaceShade(75.0f,-607.0f,49.0f,-14.0f,0f,0f,0f,-73.36434f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-9.5238094E-4f,1.1767475E-4f,-0.001457726f ) ;
  }

  @Test
  public void test1187() {
    TestDrivers.surfaceShade(75.0f,-738.0f,0f,92.0f,0f,0f,0f,-55.379726f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-76.486824f,21.168873f,0f ) ;
  }

  @Test
  public void test1188() {
    TestDrivers.surfaceShade(-751.0f,-385.0f,-995.0f,0f,28.0f,514.0f,0f,-660.0f,0f,0f,0f,0f,0f,-702.0f,218.0f,-435.0f,-64.0f,-352.0f,-10.0f,231,30.9591f,-65.776115f,30.291922f,-77.27678f,-66.06446f,88.512474f ) ;
  }

  @Test
  public void test1189() {
    TestDrivers.surfaceShade(-751.0f,-91.0f,-56.0f,0f,55.0f,490.0f,0f,1434.0f,0f,0f,0f,0f,0f,386.0f,-123.0f,819.0f,-299.0f,-935.0f,863.0f,359,37.909065f,22.838974f,-14.436784f,27.826572f,-69.61256f,145.36682f ) ;
  }

  @Test
  public void test1190() {
    TestDrivers.surfaceShade(759.0f,-576.0f,590.0f,0f,458.0f,295.0f,-1384.0f,-840.0f,0f,0f,0f,0f,0f,-1272.0f,-201.0f,-565.0f,-1473.0f,-824.0f,1726.0f,-890,0.16844577f,0.02559589f,0.0824746f,-1.8132721f,57.298004f,-100.0f ) ;
  }

  @Test
  public void test1191() {
    TestDrivers.surfaceShade(760.0f,760.0f,190.0f,0f,567.0f,379.0f,0f,1301.0f,0f,0f,0f,0f,0f,1036.0f,-154.0f,-1187.0f,-764.0f,462.0f,182.0f,168,-0.32474104f,0.78580856f,0.51899767f,50.228516f,21.687668f,-87.774574f ) ;
  }

  @Test
  public void test1192() {
    TestDrivers.surfaceShade(-76.0f,87.0f,0f,0f,959.0f,801.0f,0f,-343.0f,0f,0f,0f,0f,0f,-270.0f,22.0f,-474.0f,306.0f,-627.0f,768.0f,-648,-65.027626f,16.355179f,44.9132f,-98.040924f,-35.973564f,0f ) ;
  }

  @Test
  public void test1193() {
    TestDrivers.surfaceShade(-763.0f,-251.0f,936.0f,0f,1309.0f,-275.0f,0f,-323.0f,0f,0f,0f,0f,0f,-909.0f,-1028.0f,683.0f,0f,0f,0f,605,0.009741029f,0.8911243f,-0.030874293f,-57.50663f,-100.0f,85.296005f ) ;
  }

  @Test
  public void test1194() {
    TestDrivers.surfaceShade(-768.0f,1405.0f,1016.0f,0f,811.0f,652.0f,0f,1451.0f,0f,0f,0f,0f,0f,-643.0f,577.0f,-693.0f,1489.0f,1686.0f,-703.0f,1605,-95.60485f,-63.698315f,35.670986f,9.399215f,-81.30251f,78.376236f ) ;
  }

  @Test
  public void test1195() {
    TestDrivers.surfaceShade(775.0f,268.0f,0f,0.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-142.94308f,-100.0f,0f ) ;
  }

  @Test
  public void test1196() {
    TestDrivers.surfaceShade(-775.0f,-680.0f,0f,0f,256.0f,392.0f,-948.0f,1295.0f,0f,0f,0f,0f,0f,744.0f,104.0f,-446.0f,-256.0f,841.0f,-168.0f,403,24.933336f,74.1124f,58.874645f,54.084743f,-8.645177f,0f ) ;
  }

  @Test
  public void test1197() {
    TestDrivers.surfaceShade(778.0f,62.0f,0f,-9.0f,0f,0f,0f,-98.51732f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,-37.2466f,153.45747f,0f ) ;
  }

  @Test
  public void test1198() {
    TestDrivers.surfaceShade(-779.0f,-43.0f,-1374.0f,0f,95.0f,-604.0f,0f,971.0f,0f,0f,0f,0f,0f,636.0f,94.0f,458.0f,-272.0f,1331.0f,79.0f,1601,19.636787f,-23.242462f,-33.50459f,53.452732f,-26.600864f,-88.53762f ) ;
  }

  @Test
  public void test1199() {
    TestDrivers.surfaceShade(-783.0f,0f,0f,-124.0f,0f,0f,0f,-78.65528f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,97.991776f,0f,0f ) ;
  }

  @Test
  public void test1200() {
    TestDrivers.surfaceShade(-784.0f,-18.0f,-1773.0f,0f,2307.0f,-1267.0f,0f,1146.0f,0f,0f,0f,0f,0f,876.0f,-756.0f,-996.0f,189.0f,773.0f,643.0f,-1597,1.2380955f,1.5598478f,-0.09505352f,50.514423f,-43.03335f,-15.779329f ) ;
  }

  @Test
  public void test1201() {
    TestDrivers.surfaceShade(-788.0f,0f,0f,417.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-3.0432507E-6f,0f,0f ) ;
  }

  @Test
  public void test1202() {
    TestDrivers.surfaceShade(790.0f,-1251.0f,647.0f,0f,1095.0f,-1526.0f,0f,-2636.0f,0f,0f,0f,0f,0f,1283.0f,456.0f,122.0f,0f,0f,0f,525,0.88117564f,-0.8978307f,-5.9109635f,100.0f,-51.09355f,99.9984f ) ;
  }

  @Test
  public void test1203() {
    TestDrivers.surfaceShade(-790.0f,-400.0f,1411.0f,0f,1166.0f,575.0f,0f,2072.0f,0f,0f,0f,0f,0f,-429.0f,313.0f,-925.0f,-66.0f,313.0f,776.0f,478,-54.53867f,-87.99873f,-4.4827175f,-100.0f,9.169256f,100.0f ) ;
  }

  @Test
  public void test1204() {
    TestDrivers.surfaceShade(-79.0f,0f,0f,0f,1212.0f,-647.0f,0f,93.0f,0f,0f,0f,0f,0f,-176.0f,-243.0f,-876.0f,998.0f,-752.0f,571.0f,849,-0.090944976f,-0.099423f,0.31878975f,99.07031f,0f,0f ) ;
  }

  @Test
  public void test1205() {
    TestDrivers.surfaceShade(-793.0f,1822.0f,177.0f,0f,601.0f,453.0f,0f,285.0f,0f,0f,0f,0f,0f,418.0f,-88.0f,-735.0f,780.0f,447.0f,-1138.0f,-390,-76.872696f,-75.962006f,-34.623306f,56.79619f,28.004932f,-92.4005f ) ;
  }

  @Test
  public void test1206() {
    TestDrivers.surfaceShade(-794.0f,1323.0f,511.0f,0f,521.0f,-122.0f,0f,1517.0f,0f,0f,0f,0f,0f,307.0f,-529.0f,239.0f,-860.0f,1868.0f,224.0f,730,87.12658f,5.383477f,-100.0f,43.88299f,100.0f,56.250557f ) ;
  }

  @Test
  public void test1207() {
    TestDrivers.surfaceShade(795.0f,181.0f,0f,0f,15.0f,740.0f,0f,707.0f,0f,0f,0f,0f,0f,-778.0f,493.0f,-726.0f,1451.0f,687.0f,5.0f,2359,-73.642006f,-8.249814f,73.31449f,99.99982f,100.0f,0f ) ;
  }

  @Test
  public void test1208() {
    TestDrivers.surfaceShade(799.0f,0f,0f,0f,1050.0f,1.0f,0f,789.0f,0f,0f,0f,0f,0f,-952.0f,-29.0f,-1252.0f,733.0f,651.0f,-98.0f,42,-0.034743585f,0.99907494f,0.025340473f,-53.992664f,0f,0f ) ;
  }

  @Test
  public void test1209() {
    TestDrivers.surfaceShade(-802.0f,-67.0f,172.0f,811.0f,0f,0f,0f,-74.32267f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,-1.5374634E-6f,-100.0f,-78.64951f ) ;
  }

  @Test
  public void test1210() {
    TestDrivers.surfaceShade(803.0f,72.0f,555.0f,0f,490.0f,1003.0f,-1287.0f,-2182.0f,0f,0f,0f,0f,0f,-513.0f,-240.0f,-954.0f,-454.0f,-228.0f,-490.0f,134,-0.20049109f,0.108091936f,0.12820596f,-88.10949f,-28.521317f,-18.52645f ) ;
  }

  @Test
  public void test1211() {
    TestDrivers.surfaceShade(-805.0f,0f,0f,0f,837.0f,-452.0f,0f,225.0f,0f,0f,0f,0f,0f,-81.0f,932.0f,152.0f,706.0f,49.0f,-213.0f,-970,26.430882f,-65.9166f,93.63335f,3.2795317f,0f,0f ) ;
  }

  @Test
  public void test1212() {
    TestDrivers.surfaceShade(-809.0f,-797.0f,-734.0f,0f,274.0f,-695.0f,0f,30.0f,0f,0f,0f,0f,0f,-532.0f,-1507.0f,-55.0f,-551.0f,-651.0f,-367.0f,-63,-79.67136f,45.88767f,69.36242f,78.499374f,67.01846f,64.75534f ) ;
  }

  @Test
  public void test1213() {
    TestDrivers.surfaceShade(812.0f,0f,0f,0f,1009.0f,706.0f,737.0f,-678.0f,0f,0f,0f,0f,0f,-1871.0f,834.0f,891.0f,-665.0f,1022.0f,1220.0f,928,-0.17617914f,0.46300328f,-0.80334f,-0.54173446f,0f,0f ) ;
  }

  @Test
  public void test1214() {
    TestDrivers.surfaceShade(813.0f,0f,0f,0f,28.446543f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,24.558527f,-7.1454144f,-36.903248f,0f,0f,0f,-1371,-17.810547f,-36.516483f,72.57238f,66.151535f,0f,0f ) ;
  }

  @Test
  public void test1215() {
    TestDrivers.surfaceShade(-814.0f,265.0f,720.0f,0f,939.0f,174.0f,0f,-881.0f,0f,0f,0f,0f,0f,-469.0f,-710.0f,-981.0f,1353.0f,1754.0f,134.0f,-686,-61.70779f,-60.063625f,72.97261f,-5.3417196f,9.282851f,39.022263f ) ;
  }

  @Test
  public void test1216() {
    TestDrivers.surfaceShade(816.0f,0f,0f,0f,3.6408724E-6f,0.0f,0f,-14.572345f,0f,0f,0f,0f,0f,80.79688f,14.107966f,19.582426f,0f,0f,0f,-18,-0.4351283f,-0.11090579f,-0.72640693f,6.6067863f,0f,0f ) ;
  }

  @Test
  public void test1217() {
    TestDrivers.surfaceShade(816.0f,0f,0f,0f,49.766445f,0.0f,0f,-60.61672f,0f,0f,0f,0f,0f,72.247406f,78.17578f,-66.277954f,0f,0f,0f,-982,-51.52233f,49.039917f,1.7346283f,6.8623576E-6f,0f,0f ) ;
  }

  @Test
  public void test1218() {
    TestDrivers.surfaceShade(-818.0f,-1187.0f,-21.0f,0f,1825.0f,246.0f,0f,-1628.0f,0f,0f,0f,0f,0f,-1131.0f,-1589.0f,487.0f,-153.0f,184.0f,-1609.0f,610,0.3837349f,-0.10134155f,0.5605184f,-53.765656f,28.164639f,-10.662629f ) ;
  }

  @Test
  public void test1219() {
    TestDrivers.surfaceShade(818.0f,242.0f,0f,0f,316.0f,-592.0f,0f,-593.0f,0f,0f,0f,0f,0f,629.0f,-843.0f,-576.0f,0f,0f,0f,777,-2.150451f,-0.8906139f,-1.0448718f,36.753437f,6.303108f,0f ) ;
  }

  @Test
  public void test1220() {
    TestDrivers.surfaceShade(822.0f,2327.0f,-126.0f,0f,853.0f,6.0f,0f,-1049.0f,0f,0f,0f,0f,0f,802.0f,-529.0f,631.0f,-1617.0f,-316.0f,630.0f,776,0.31226814f,2.4549854f,1.661249f,97.479126f,72.24671f,-100.0f ) ;
  }

  @Test
  public void test1221() {
    TestDrivers.surfaceShade(823.0f,0f,0f,0f,29.175467f,-0.0058248276f,0f,0.0f,0f,0f,0f,0f,0f,36.683784f,-63.616558f,-29.605186f,0f,0f,0f,2828,-52.455105f,-28.097591f,-4.62013f,37.08903f,0f,0f ) ;
  }

  @Test
  public void test1222() {
    TestDrivers.surfaceShade(-825.0f,-602.0f,0f,0f,1571.0f,-5.0f,0f,-1450.0f,0f,0f,0f,0f,0f,678.0f,422.0f,-774.0f,0f,0f,0f,195,-0.19255987f,-0.1719732f,-0.16818802f,100.0f,42.17746f,0f ) ;
  }

  @Test
  public void test1223() {
    TestDrivers.surfaceShade(826.0f,957.0f,0f,0f,41.0f,-227.0f,0f,-386.0f,0f,0f,0f,0f,0f,719.0f,419.0f,752.0f,0f,0f,0f,-1506,-0.21485823f,0.5460929f,-0.0988429f,1.3828723f,62.71632f,0f ) ;
  }

  @Test
  public void test1224() {
    TestDrivers.surfaceShade(-827.0f,-685.0f,885.0f,0f,216.0f,-1148.0f,0f,-1975.0f,0f,0f,0f,0f,0f,1106.0f,1666.0f,273.0f,0f,0f,0f,28,-0.060710795f,-0.5987772f,0.6493932f,35.43731f,-98.35286f,-98.48353f ) ;
  }

  @Test
  public void test1225() {
    TestDrivers.surfaceShade(-828.0f,-1025.0f,1021.0f,0f,485.0f,-118.0f,0f,-1208.0f,0f,0f,0f,0f,0f,-371.0f,-231.0f,601.0f,0f,0f,0f,-897,0.59206635f,0.38224536f,-0.5384889f,-66.70682f,-32.59205f,-27.57598f ) ;
  }

  @Test
  public void test1226() {
    TestDrivers.surfaceShade(83.0f,-121.0f,0f,0f,992.0f,-877.0f,0f,-746.0f,0f,0f,0f,0f,0f,-949.0f,899.0f,-770.0f,0f,0f,0f,134,-8.784376f,-86.602974f,17.541927f,-65.43354f,-82.26638f,0f ) ;
  }

  @Test
  public void test1227() {
    TestDrivers.surfaceShade(83.0f,-2053.0f,-204.0f,0f,1462.0f,-361.0f,0f,76.0f,0f,0f,0f,0f,0f,-1091.0f,263.0f,-371.0f,-200.0f,-2034.0f,-653.0f,-793,-22.905144f,-27.22008f,48.061f,51.412636f,93.20746f,-41.52755f ) ;
  }

  @Test
  public void test1228() {
    TestDrivers.surfaceShade(83.0f,29.0f,-165.0f,0f,1340.0f,655.0f,0f,135.0f,0f,0f,0f,0f,0f,-7.0f,-686.0f,-184.0f,-758.0f,-216.0f,1394.0f,-297,-13.57014f,23.67655f,-87.7561f,39.336613f,-68.787254f,-19.7875f ) ;
  }

  @Test
  public void test1229() {
    TestDrivers.surfaceShade(-838.0f,1181.0f,0f,0f,14.0f,-1515.0f,0f,0.0f,0f,0f,0f,0f,0f,-866.0f,-206.0f,62.0f,0f,0f,0f,-22,6.7280364f,-33.89643f,-18.648148f,-57.035873f,-80.284645f,0f ) ;
  }

  @Test
  public void test1230() {
    TestDrivers.surfaceShade(838.0f,875.0f,-3.0f,0f,714.0f,-960.0f,0f,-486.0f,0f,0f,0f,0f,0f,697.0f,-1464.0f,-202.0f,0f,0f,0f,-667,0.5030415f,0.26972586f,-0.21910247f,97.38163f,28.250011f,-20.236404f ) ;
  }

  @Test
  public void test1231() {
    TestDrivers.surfaceShade(-847.0f,284.0f,0f,0f,15.0f,1354.0f,0f,474.0f,0f,0f,0f,0f,0f,324.0f,101.0f,160.0f,-900.0f,-229.0f,-87.0f,-733,14.657404f,7.1825304f,-34.215214f,-93.867805f,53.20211f,0f ) ;
  }

  @Test
  public void test1232() {
    TestDrivers.surfaceShade(855.0f,300.0f,-974.0f,0f,1476.0f,0.0f,0f,-538.0f,0f,0f,0f,0f,0f,311.0f,-94.0f,-51.0f,0f,0f,0f,230,21.118551f,95.326294f,47.48959f,69.95715f,1.9963428f,-31.824478f ) ;
  }

  @Test
  public void test1233() {
    TestDrivers.surfaceShade(863.0f,0f,0f,0f,984.0f,624.0f,0f,-1431.0f,0f,0f,0f,0f,0f,-553.0f,-373.0f,169.0f,1200.0f,-1432.0f,-625.0f,-976,-0.13970588f,0.55571437f,0.7693734f,100.0f,0f,0f ) ;
  }

  @Test
  public void test1234() {
    TestDrivers.surfaceShade(-866.0f,-629.0f,0f,0f,847.0f,-709.0f,0f,927.0f,0f,0f,0f,0f,0f,452.0f,576.0f,-374.0f,-506.0f,418.0f,-601.0f,460,-94.89216f,89.19139f,37.755604f,61.504883f,-19.451862f,0f ) ;
  }

  @Test
  public void test1235() {
    TestDrivers.surfaceShade(-870.0f,2365.0f,0f,0f,811.0f,1533.0f,-480.0f,-899.0f,0f,0f,0f,0f,0f,969.0f,524.0f,-1241.0f,1163.0f,-1654.0f,-1042.0f,-652,-0.039047644f,-0.68306446f,-0.1229589f,8.089441f,-36.87764f,0f ) ;
  }

  @Test
  public void test1236() {
    TestDrivers.surfaceShade(872.0f,562.0f,-834.0f,0f,330.0f,1695.0f,0f,1028.0f,0f,0f,0f,0f,0f,394.0f,-763.0f,257.0f,85.0f,-716.0f,-901.0f,-1186,-11.748816f,-4.7697663f,3.8509786f,-70.76108f,-75.95183f,79.51512f ) ;
  }

  @Test
  public void test1237() {
    TestDrivers.surfaceShade(-876.0f,0f,0f,0f,132.0f,0.0f,0f,1992.0f,0f,0f,0f,0f,0f,-386.0f,-894.0f,1129.0f,806.0f,371.0f,-1645.0f,-343,0.23098277f,1.3900038f,1.1796482f,1.9105555E-6f,0f,0f ) ;
  }

  @Test
  public void test1238() {
    TestDrivers.surfaceShade(-88.0f,-768.0f,0f,0f,129.0f,-731.0f,0f,-4.0f,0f,0f,0f,0f,0f,-362.0f,-275.0f,578.0f,0f,0f,0f,-510,68.76611f,36.090866f,-96.78466f,-100.0f,156.10406f,0f ) ;
  }

  @Test
  public void test1239() {
    TestDrivers.surfaceShade(881.0f,1165.0f,-162.0f,0f,907.0f,697.0f,0f,-1564.0f,0f,0f,0f,0f,0f,934.0f,1354.0f,945.0f,354.0f,-699.0f,-1365.0f,-909,-0.40152487f,-0.8987114f,-0.11300852f,93.13992f,11.307659f,-3.837806f ) ;
  }

  @Test
  public void test1240() {
    TestDrivers.surfaceShade(-882.0f,363.0f,0f,0f,511.0f,-960.0f,0f,-292.0f,0f,0f,0f,0f,0f,545.0f,-863.0f,401.0f,0f,0f,0f,-110,-27.697674f,10.624078f,-80.36753f,-18.9317f,-34.177753f,0f ) ;
  }

  @Test
  public void test1241() {
    TestDrivers.surfaceShade(-886.0f,0f,113.0f,0f,98.0f,-2666.0f,0f,206.0f,0f,0f,0f,0f,0f,665.0f,17.0f,-802.0f,874.0f,160.0f,-514.0f,-120,-26.848166f,-78.86412f,-23.933567f,-0.049328383f,0f,0.38676918f ) ;
  }

  @Test
  public void test1242() {
    TestDrivers.surfaceShade(-886.0f,347.0f,-215.0f,-82.0f,0f,0f,0f,-52.237698f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,100.0f,-3.5144443E-5f,76.19991f ) ;
  }

  @Test
  public void test1243() {
    TestDrivers.surfaceShade(-886.0f,84.0f,1431.0f,0f,1203.0f,-367.0f,0f,-230.0f,0f,0f,0f,0f,0f,-94.0f,446.0f,735.0f,0f,0f,0f,-237,-0.11099499f,0.26381302f,-0.17427774f,-30.858181f,-21.813995f,100.0f ) ;
  }

  @Test
  public void test1244() {
    TestDrivers.surfaceShade(887.0f,819.0f,2856.0f,0f,1192.0f,194.0f,0f,500.0f,0f,0f,0f,0f,0f,-43.0f,1565.0f,-59.0f,681.0f,-781.0f,1044.0f,-771,-2.7367651f,-0.008994969f,1.7559962f,-77.07403f,-99.50397f,154.81754f ) ;
  }

  @Test
  public void test1245() {
    TestDrivers.surfaceShade(89.0f,-705.0f,819.0f,664.0f,0f,0f,0f,-71.01466f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,1.6921618E-5f,-100.0f,1.8388573E-6f ) ;
  }

  @Test
  public void test1246() {
    TestDrivers.surfaceShade(891.0f,266.0f,132.0f,-1173.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,40.145233f,-5.5986025E-6f,90.7719f ) ;
  }

  @Test
  public void test1247() {
    TestDrivers.surfaceShade(896.0f,0f,0f,0f,727.0f,1.0f,0f,1422.0f,0f,0f,0f,0f,0f,329.0f,-37.0f,1072.0f,495.0f,316.0f,-693.0f,-1070,19.79868f,93.19113f,-100.0f,0.716826f,0f,0f ) ;
  }

  @Test
  public void test1248() {
    TestDrivers.surfaceShade(896.0f,-670.0f,954.0f,0f,854.0f,543.0f,0f,-742.0f,0f,0f,0f,0f,0f,-725.0f,404.0f,-80.0f,959.0f,796.0f,-1801.0f,-262,-8.734112f,-97.22297f,21.733786f,-151.10414f,44.565533f,45.296303f ) ;
  }

  @Test
  public void test1249() {
    TestDrivers.surfaceShade(-90.0f,0f,0f,0f,169.0f,191.0f,0f,-619.0f,0f,0f,0f,0f,0f,-312.0f,16.0f,-71.0f,655.0f,-576.0f,211.0f,-766,58.089573f,70.51501f,92.25839f,-84.829865f,0f,0f ) ;
  }

  @Test
  public void test1250() {
    TestDrivers.surfaceShade(901.0f,279.0f,-347.0f,0f,63.0f,709.0f,0f,-1952.0f,0f,0f,0f,0f,0f,-159.0f,-473.0f,792.0f,932.0f,-915.0f,-1323.0f,-404,60.09936f,31.1877f,30.691391f,4.555729f,3.5721896f,15.352517f ) ;
  }

  @Test
  public void test1251() {
    TestDrivers.surfaceShade(902.0f,-1947.0f,-27.0f,0f,984.0f,0.0f,0f,-1989.0f,0f,0f,0f,0f,0f,-644.0f,-960.0f,-1110.0f,0f,0f,0f,466,-88.49526f,83.18875f,-19.869379f,59.033253f,9.534553f,54.867332f ) ;
  }

  @Test
  public void test1252() {
    TestDrivers.surfaceShade(905.0f,1673.0f,-292.0f,0f,888.0f,-107.0f,0f,-428.0f,0f,0f,0f,0f,0f,553.0f,180.0f,857.0f,0f,0f,0f,990,-52.789913f,82.85486f,-90.10994f,48.737576f,-37.440083f,-1.5585044E-9f ) ;
  }

  @Test
  public void test1253() {
    TestDrivers.surfaceShade(908.0f,0f,0f,0f,1392.0f,1345.0f,0f,-1258.0f,0f,0f,0f,0f,0f,-2032.0f,802.0f,-1801.0f,301.0f,422.0f,-974.0f,1033,-0.034117404f,-0.23571879f,-0.066474125f,100.0f,0f,0f ) ;
  }

  @Test
  public void test1254() {
    TestDrivers.surfaceShade(-9.0f,183.0f,-1691.0f,0f,358.0f,-176.0f,0f,410.0f,0f,0f,0f,0f,0f,-326.0f,340.0f,525.0f,-670.0f,226.0f,451.0f,-357,-82.31414f,-32.511444f,-70.84097f,-60.214848f,9.490007f,-6.460923f ) ;
  }

  @Test
  public void test1255() {
    TestDrivers.surfaceShade(-917.0f,-695.0f,-304.0f,0f,236.0f,1525.0f,0f,-424.0f,0f,0f,0f,0f,0f,680.0f,-782.0f,-324.0f,738.0f,833.0f,-1176.0f,-312,-58.22368f,-77.02576f,63.710003f,-95.48714f,-39.31592f,-89.88344f ) ;
  }

  @Test
  public void test1256() {
    TestDrivers.surfaceShade(918.0f,447.0f,681.0f,0f,89.0f,195.0f,0f,690.0f,0f,0f,0f,0f,0f,-259.0f,21.0f,859.0f,908.0f,-961.0f,175.0f,284,57.864006f,85.013435f,-75.744675f,30.633644f,84.344124f,-92.467285f ) ;
  }

  @Test
  public void test1257() {
    TestDrivers.surfaceShade(922.0f,-328.0f,0f,-24.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,100.0f,-15.0533285f,0f ) ;
  }

  @Test
  public void test1258() {
    TestDrivers.surfaceShade(924.0f,802.0f,0f,0f,577.0f,-1080.0f,0f,-8.0f,0f,0f,0f,0f,0f,841.0f,20.0f,894.0f,0f,0f,0f,-757,-0.7541679f,-0.48826417f,-0.35167986f,10.472922f,-100.0f,0f ) ;
  }

  @Test
  public void test1259() {
    TestDrivers.surfaceShade(-927.0f,0f,0f,0f,525.0f,1187.0f,-734.0f,367.0f,0f,0f,0f,0f,0f,119.0f,-464.0f,-182.0f,377.0f,459.0f,1612.0f,-590,60.030525f,0.16737078f,38.824337f,94.60614f,0f,0f ) ;
  }

  @Test
  public void test1260() {
    TestDrivers.surfaceShade(-93.0f,0f,0f,0f,30.223011f,-75.8246f,0f,0.0f,0f,0f,0f,0f,0f,5.1701627f,25.21033f,10.659383f,0f,0f,0f,-662,-0.04280412f,-0.2798637f,0.11853618f,-5.9165835E-5f,0f,0f ) ;
  }

  @Test
  public void test1261() {
    TestDrivers.surfaceShade(936.0f,-45.0f,200.0f,129.0f,0f,0f,0f,-34.98552f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,-100.0f,-1.0683761E-4f,9.6153846E-5f ) ;
  }

  @Test
  public void test1262() {
    TestDrivers.surfaceShade(936.0f,-767.0f,0f,0f,877.0f,0.0f,0f,-558.0f,0f,0f,0f,0f,0f,272.0f,218.0f,297.0f,0f,0f,0f,253,-24.92969f,89.17668f,-95.860886f,68.717155f,-36.345543f,0f ) ;
  }

  @Test
  public void test1263() {
    TestDrivers.surfaceShade(-939.0f,486.0f,0f,0f,559.0f,814.0f,0f,31.0f,0f,0f,0f,0f,0f,2030.0f,881.0f,-425.0f,-1044.0f,373.0f,-521.0f,-1198,0.22930406f,-0.9100472f,-0.23844159f,18.084587f,-17.394447f,0f ) ;
  }

  @Test
  public void test1264() {
    TestDrivers.surfaceShade(94.0f,-2127.0f,0f,0f,407.0f,140.0f,0f,-2730.0f,0f,0f,0f,0f,0f,833.0f,819.0f,833.0f,169.0f,-112.0f,-976.0f,-586,-1.3058385f,-0.64018047f,1.3905827f,-100.0f,-0.016040938f,0f ) ;
  }

  @Test
  public void test1265() {
    TestDrivers.surfaceShade(-941.0f,0f,0f,0f,724.0f,518.0f,-705.0f,-729.0f,0f,0f,0f,0f,0f,-489.0f,691.0f,-850.0f,-794.0f,935.0f,-304.0f,-864,38.59299f,-5.538659f,53.407894f,-14.822274f,0f,0f ) ;
  }

  @Test
  public void test1266() {
    TestDrivers.surfaceShade(944.0f,0f,0f,0f,99.514145f,-46.49371f,0f,0.0f,0f,0f,0f,0f,0f,23.300499f,11.845013f,-18.926477f,0f,0f,0f,-873,-0.4063128f,0.18126552f,-0.38677022f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test1267() {
    TestDrivers.surfaceShade(-946.0f,1940.0f,0f,0f,1800.0f,-1700.0f,0f,5.0f,0f,0f,0f,0f,0f,-357.0f,337.0f,50.0f,0f,0f,0f,1678,91.43018f,84.72225f,81.7835f,-170.88013f,95.05331f,0f ) ;
  }

  @Test
  public void test1268() {
    TestDrivers.surfaceShade(946.0f,-985.0f,576.0f,0f,888.0f,-508.0f,0f,396.0f,0f,0f,0f,0f,0f,288.0f,139.0f,-176.0f,-510.0f,1265.0f,-355.0f,239,3.004241f,-41.45454f,-27.823635f,100.0f,1.7070413f,-47.291573f ) ;
  }

  @Test
  public void test1269() {
    TestDrivers.surfaceShade(95.0f,263.0f,-62.0f,-77.0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-11.41188f,-46.0733f,2.0946795E-4f ) ;
  }

  @Test
  public void test1270() {
    TestDrivers.surfaceShade(955.0f,0f,0f,0f,315.0f,1215.0f,0f,888.0f,0f,0f,0f,0f,0f,-202.0f,491.0f,-353.0f,-466.0f,107.0f,-318.0f,-532,2.1935391f,61.3608f,84.09365f,30.116882f,0f,0f ) ;
  }

  @Test
  public void test1271() {
    TestDrivers.surfaceShade(955.0f,0f,0f,-696.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,2.607589E-6f,0f,0f ) ;
  }

  @Test
  public void test1272() {
    TestDrivers.surfaceShade(-957.0f,-556.0f,-195.0f,0f,292.0f,-598.0f,0f,227.0f,0f,0f,0f,0f,0f,934.0f,-649.0f,-93.0f,-14.0f,-481.0f,-120.0f,83,-68.8537f,77.95507f,36.396294f,82.78742f,-15.592574f,-36.848083f ) ;
  }

  @Test
  public void test1273() {
    TestDrivers.surfaceShade(958.0f,0f,0f,0f,6.2442727f,0.0f,0f,-88.30779f,0f,0f,0f,0f,0f,-10.0823765f,97.86535f,-60.99015f,0f,0f,0f,99,0.30337954f,-0.42162076f,-0.5820799f,-35.661613f,0f,0f ) ;
  }

  @Test
  public void test1274() {
    TestDrivers.surfaceShade(963.0f,1358.0f,360.0f,0f,342.0f,-1607.0f,0f,-3069.0f,0f,0f,0f,0f,0f,-378.0f,-828.0f,640.0f,0f,0f,0f,844,0.79826623f,-0.04308353f,-0.009589548f,-21.000557f,-6.4300475f,39.752155f ) ;
  }

  @Test
  public void test1275() {
    TestDrivers.surfaceShade(-973.0f,0f,0f,0f,14.0f,1728.0f,-1564.0f,-413.0f,0f,0f,0f,0f,0f,646.0f,-434.0f,1896.0f,-341.0f,1186.0f,768.0f,-1455,-0.05148536f,0.68819916f,-0.18443426f,41.107082f,0f,0f ) ;
  }

  @Test
  public void test1276() {
    TestDrivers.surfaceShade(-975.0f,-1132.0f,-18.0f,0f,1274.0f,-86.0f,0f,2397.0f,0f,0f,0f,0f,0f,452.0f,669.0f,-594.0f,483.0f,-200.0f,610.0f,-1279,-2.36872f,0.59304684f,-1.1345338f,-9.984734f,100.0f,-202.75732f ) ;
  }

  @Test
  public void test1277() {
    TestDrivers.surfaceShade(975.0f,1879.0f,-347.0f,0f,852.0f,901.0f,0f,885.0f,0f,0f,0f,0f,0f,252.0f,-709.0f,-420.0f,2283.0f,-130.0f,-622.0f,-449,-16.247911f,25.42877f,-52.674934f,-116.406f,-64.5608f,99.331276f ) ;
  }

  @Test
  public void test1278() {
    TestDrivers.surfaceShade(-98.0f,0f,0f,0f,100.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,92.72616f,49.208084f,30.603275f,0f,0f,0f,1,-1.0440488f,-1.2927014f,0.31736997f,-34.01864f,0f,0f ) ;
  }

  @Test
  public void test1279() {
    TestDrivers.surfaceShade(981.0f,0f,0f,0f,50.0f,1099.0f,0f,222.0f,0f,0f,0f,0f,0f,-619.0f,1257.0f,-590.0f,1544.0f,1185.0f,2047.0f,1770,-0.3347427f,0.22943415f,0.8400097f,0.016182356f,0f,0f ) ;
  }

  @Test
  public void test1280() {
    TestDrivers.surfaceShade(983.0f,-1327.0f,0f,0f,1774.0f,-1.0f,0f,-4.0f,0f,0f,0f,0f,0f,261.0f,730.0f,146.0f,0f,0f,0f,1796,-0.3369073f,0.1393861f,-0.8497915f,-1.0843124E-8f,100.0f,0f ) ;
  }

  @Test
  public void test1281() {
    TestDrivers.surfaceShade(988.0f,693.0f,-128.0f,0f,650.0f,-451.0f,0f,-353.0f,0f,0f,0f,0f,0f,215.0f,-926.0f,-104.0f,0f,0f,0f,738,-71.18911f,-22.124466f,67.679985f,-67.13584f,33.219437f,-36.88782f ) ;
  }

  @Test
  public void test1282() {
    TestDrivers.surfaceShade(991.0f,0f,0f,0f,1586.0f,662.0f,-1519.0f,-6.0f,0f,0f,0f,0f,0f,402.0f,-543.0f,510.0f,976.0f,-217.0f,441.0f,534,0.21435148f,0.7749429f,0.3623443f,-98.2638f,0f,0f ) ;
  }

  @Test
  public void test1283() {
    TestDrivers.surfaceShade(-991.0f,-107.0f,-913.0f,0f,27.0f,1636.0f,0f,-825.0f,0f,0f,0f,0f,0f,-919.0f,641.0f,-422.0f,38.0f,484.0f,-216.0f,641,-37.659718f,-47.953228f,9.173603f,-12.206706f,60.8906f,-46.768223f ) ;
  }

  @Test
  public void test1284() {
    TestDrivers.surfaceShade(994.0f,0f,0f,0f,417.0f,829.0f,0f,-209.0f,0f,0f,0f,0f,0f,714.0f,-356.0f,114.0f,-199.0f,550.0f,977.0f,423,-0.39320943f,-0.0834469f,-0.39853537f,-39.38778f,0f,0f ) ;
  }

  @Test
  public void test1285() {
    TestDrivers.surfaceShade(-995.0f,-731.0f,0f,0f,940.0f,-2.0f,0f,-3.0f,0f,0f,0f,0f,0f,-454.0f,2015.0f,-948.0f,0f,0f,0f,-606,0.071500555f,-0.9480679f,-0.005958266f,97.15557f,-60.67613f,0f ) ;
  }
}
