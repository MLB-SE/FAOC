import org.junit.Test;

public class JpfTargetRayTraceTest {

  @Test
  public void test0() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,0.014830757f,-0.65580964f,0.22529735f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,0.16539603f,-0.1270285f,0.45043218f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-0.28917587f,0.2523802f,-0.92340755f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,0.6258225f,0.547355f,-0.5556516f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,23.473618f,-80.33406f,3.6552896f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-2.8388363E-9f,-5.307843E-9f,-1.3404966E-9f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-5.135105E-5f,-2.726436E-4f,6.074261E-4f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-5.4396172E-5f,3.266664E-5f,-8.125682E-5f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,80.90614f,-77.19438f,-6.907212f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,89.52527f,-6.2801175f,79.64612f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.rayTrace(-100.0f,100.0f,100.0f,100.0f,-100.0f,72.25099f,95.59356f,-0.5725515f,0.75180453f,0.32706985f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.rayTrace(100.0f,-100.0f,-100.0f,-100.0f,-27.132643f,-100.0f,100.0f,-0.9693149f,0.24261245f,-0.0395959f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.rayTrace(-100.0f,100.0f,50.173077f,-100.0f,-99.650604f,39.88409f,92.20714f,-0.9975615f,0.047482755f,0.051151145f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.rayTrace(100.0f,15.235891f,55.909267f,-99.99997f,81.71039f,-1.9351478f,100.0f,-0.9957467f,-0.045451853f,0.08014134f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.rayTrace(100.0f,3.706482f,-8.299227f,100.0f,-70.05162f,24.33316f,-6.762115f,-0.9449425f,0.307396f,0.11221172f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.rayTrace(-100.0f,-49.02161f,-25.537767f,14.08486f,76.41441f,29.887655f,-81.086815f,-0.11739111f,-0.7942853f,-0.52623624f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.rayTrace(11.057076f,41.099636f,-65.548065f,-50.3385f,-21.797298f,-52.24744f,-7.163973f,33.671112f,91.48246f,-7.7877846f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.rayTrace(12.526339f,-9.297354f,35.76251f,-80.25032f,-12.049124f,45.484356f,71.8859f,0.60866445f,-0.080523096f,0.49662063f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.rayTrace(-16.39361f,16.909298f,84.07829f,-89.84199f,74.75325f,-7.067958f,-34.820972f,-31.415907f,-73.608986f,-53.86151f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.rayTrace(17.98636f,-79.15106f,-100.0f,-15.287549f,-10.844959f,100.0f,-25.023306f,-0.253761f,0.78840685f,0.4661322f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.rayTrace(-18.341295f,74.66919f,95.956856f,30.245394f,42.72531f,25.555433f,16.704428f,21.359564f,-80.21267f,69.823685f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.rayTrace(19.374617f,9.970712f,12.046185f,67.618675f,27.671453f,-20.40941f,-37.30487f,-0.3583757f,-0.41593477f,0.39221182f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.rayTrace(-19.446838f,-12.25314f,-99.98732f,-99.81142f,100.0f,-33.245274f,-100.0f,-12.523881f,-5.1540084f,-14.908633f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.rayTrace(-19.621908f,-8.393437f,30.372835f,-99.17941f,-85.97655f,35.760395f,-29.155012f,11.508126f,-14.272717f,31.078497f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.rayTrace(-20.145956f,70.94403f,-90.82171f,-33.833656f,-7.966582f,100.0f,-71.42841f,-0.043059524f,0.13856721f,-0.83326864f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.rayTrace(22.382347f,-100.0f,95.67958f,100.0f,100.0f,-83.25512f,-76.62022f,0.53681993f,0.8258741f,0.17250025f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.rayTrace(23.950905f,60.828747f,-12.618761f,95.550224f,67.72506f,10.939413f,-81.35538f,-83.13774f,20.744864f,95.57659f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.rayTrace(-25.307579f,-35.81855f,-99.3952f,83.592964f,-86.217674f,47.42141f,-47.33541f,79.792366f,-86.11578f,-34.521626f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.rayTrace(-2.6215332f,-76.012436f,-33.740818f,-59.684196f,-23.359125f,-69.16187f,25.889013f,55.88613f,-87.36935f,76.31197f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.rayTrace(27.054773f,-94.57728f,-54.762157f,76.14396f,-12.597912f,-44.278965f,-95.940384f,0.35232502f,-0.53914416f,0.5515734f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.rayTrace(33.67082f,65.314964f,90.58391f,72.19662f,75.77889f,65.07587f,88.637505f,84.56845f,-32.02571f,-87.76205f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.rayTrace(34.127827f,-10.030708f,-100.0f,-30.876554f,-33.187977f,-47.749348f,-62.46733f,0.73235273f,0.6576493f,-0.15037253f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.rayTrace(-34.237087f,48.113586f,1.8911648f,-84.22894f,31.946583f,-5.638458f,12.946257f,0.6026185f,-0.10670697f,0.7564645f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.rayTrace(-38.365135f,169.97041f,100.0f,78.39406f,-21.36421f,98.61104f,31.023933f,-0.13457069f,0.0904643f,0.3034694f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.rayTrace(4.072236f,-18.185596f,13.519774f,-86.22595f,63.388046f,94.79959f,-36.53542f,-2.4272869f,75.40958f,6.184439f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.rayTrace(-44.172527f,-56.982758f,83.11817f,90.07017f,-59.73224f,-39.28726f,92.96166f,0.37554163f,-0.80739194f,0.31020114f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.rayTrace(45.128036f,53.51018f,80.282326f,-59.411343f,-5.3836737f,-0.15372993f,4.703849f,27.544537f,7.0045624f,44.24335f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.rayTrace(-50.049706f,50.392056f,-45.89094f,49.97033f,-73.96261f,9.383833f,-58.477528f,-0.04767167f,0.516153f,0.51390696f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.rayTrace(-50.10467f,69.39291f,-14.513642f,-56.284466f,4.968663f,73.30706f,-127.47847f,13.463995f,1.4431939f,-10.352754f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.rayTrace(-56.186295f,100.0f,59.17468f,100.0f,71.42936f,70.28422f,-19.204731f,0.29836726f,0.23036624f,0.054200545f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.rayTrace(-56.36663f,41.05997f,42.491653f,66.26546f,-54.132137f,-44.736732f,15.583084f,-93.628494f,36.07479f,36.25027f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.rayTrace(-63.392544f,-99.306496f,64.23461f,95.247765f,32.85427f,-94.94015f,41.59568f,56.496956f,-39.934338f,93.93461f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.rayTrace(63.78121f,11.375981f,-66.86904f,83.9194f,30.327293f,11.282453f,-56.20925f,26.981895f,48.47869f,-60.774803f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.rayTrace(-64.751175f,20.634304f,20.43924f,58.62836f,-11.707264f,45.22558f,-2.950255f,-64.05131f,61.4806f,6.878238f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.rayTrace(66.52889f,-63.921932f,53.355038f,-17.994545f,52.521435f,-48.88277f,42.570393f,1.2537197f,0.0945703f,0.24448933f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.rayTrace(68.52058f,37.88415f,-100.0f,100.0f,-100.0f,-41.183655f,71.641396f,0.7374863f,0.31256974f,-0.598677f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.rayTrace(-70.188225f,69.98456f,-4.0674076f,74.48944f,-90.85435f,6.1267376f,82.42634f,94.6878f,12.831339f,-89.08847f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.rayTrace(82.59285f,170.816f,25.07865f,123.87823f,-34.359924f,100.0f,100.0f,0.012345603f,-1.7032663f,0.011871641f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.rayTrace(-84.1146f,58.373924f,27.636679f,68.2623f,-58.63281f,66.203125f,-35.2025f,100.0f,188.07913f,69.00718f ) ;
  }

  @Test
  public void test49() {
    TestDrivers.rayTrace(86.77469f,-32.92105f,-99.99077f,-70.82636f,84.0506f,-100.0f,-74.761604f,0.9297815f,-0.29076302f,-0.22575028f ) ;
  }

  @Test
  public void test50() {
    TestDrivers.rayTrace(86.799805f,14.967006f,-90.2051f,-1.2171243f,37.46936f,80.481125f,53.087936f,-0.017381784f,-67.35858f,18.039902f ) ;
  }

  @Test
  public void test51() {
    TestDrivers.rayTrace(89.26252f,-92.75821f,73.90644f,99.06003f,4.586705f,24.549595f,-26.80202f,80.91641f,-34.507706f,48.93277f ) ;
  }
}
