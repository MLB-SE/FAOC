import org.junit.Test;

public class JpfTargetVector3DNormalizeTest {

  @Test
  public void test0() {
    TestDrivers.vector3DNormalize(-0.0033733617f,-0.0033739293f,0.0047891964f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.vector3DNormalize(0.06427685f,0.3517062f,0.77579355f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.vector3DNormalize(0.28365788f,0.06231286f,-0.9568988f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.vector3DNormalize(-0.4840406f,-0.8318711f,-0.26038894f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.vector3DNormalize(-0.66784906f,0.71959245f,0.1901691f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.vector3DNormalize(2.3796018E-7f,6.060376E-7f,-5.4022047E-7f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.vector3DNormalize(37.427174f,64.398f,13.90984f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.vector3DNormalize(-3.7519616E-4f,-2.2169354E-6f,2.3373963E-4f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.vector3DNormalize(-63.928055f,93.10895f,-41.83937f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.vector3DNormalize(95.761925f,27.72172f,12.906263f ) ;
  }
}
