import org.junit.Test;

public class JpfTargetPowTestTest {

  @Test
  public void test0() {
    concolic.PowExample.test(13,169 ) ;
  }

  @Test
  public void test1() {
    concolic.PowExample.test(167,-587 ) ;
  }

  @Test
  public void test2() {
    concolic.PowExample.test(17,289 ) ;
  }

  @Test
  public void test3() {
    concolic.PowExample.test(290,-14 ) ;
  }

  @Test
  public void test4() {
    concolic.PowExample.test(3,8 ) ;
  }

  @Test
  public void test5() {
    concolic.PowExample.test(-5,0 ) ;
  }

  @Test
  public void test6() {
    concolic.PowExample.test(518,891 ) ;
  }

  @Test
  public void test7() {
    concolic.PowExample.test(81,0 ) ;
  }
}
