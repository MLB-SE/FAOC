import org.junit.Test;

public class JpfTargetCollision2Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision2(228,-540,182,-75 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision2(-448,952,-899,-369 ) ;
  }
}
