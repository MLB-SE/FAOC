import org.junit.Test;

public class JpfTargetCollision3Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision3(-195,-58 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision3(-25914,-150 ) ;
  }
}
