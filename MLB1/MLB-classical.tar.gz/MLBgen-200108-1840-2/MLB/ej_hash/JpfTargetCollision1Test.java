import org.junit.Test;

public class JpfTargetCollision1Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision1(-619,-62,-939,-152,660,340 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision1(769,-699,-236,758,-1032,12 ) ;
  }
}
