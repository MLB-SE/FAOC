import org.junit.Test;

public class TestbessyTest {

  @Test
  public void test0() {
    bess.bessy(1506,8.0 ) ;
  }

  @Test
  public void test1() {
    bess.bessy(166,0.0 ) ;
  }

  @Test
  public void test2() {
    bess.bessy(387,10.066638788611627 ) ;
  }

  @Test
  public void test3() {
    bess.bessy(-413,37.531986319403785 ) ;
  }

  @Test
  public void test4() {
    bess.bessy(-449,8.0 ) ;
  }

  @Test
  public void test5() {
    bess.bessy(-57,71.27200217016778 ) ;
  }

  @Test
  public void test6() {
    bess.bessy(-604,-67.71356643368512 ) ;
  }

  @Test
  public void test7() {
    bess.bessy(-80,0 ) ;
  }

  @Test
  public void test8() {
    bess.bessy(-800,0.0 ) ;
  }

  @Test
  public void test9() {
    bess.bessy(832,0 ) ;
  }

  @Test
  public void test10() {
    bess.bessy(873,29.15392372131916 ) ;
  }

  @Test
  public void test11() {
    bess.bessy(980,-78.350488486241 ) ;
  }
}
