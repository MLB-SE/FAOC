import org.junit.Test;

public class TestbesskTest {

  @Test
  public void test0() {
    bess.bessk(-1150,-4.2351647362715017E-22 ) ;
  }

  @Test
  public void test1() {
    bess.bessk(-116,35.28828157682952 ) ;
  }

  @Test
  public void test2() {
    bess.bessk(117,2.0 ) ;
  }

  @Test
  public void test3() {
    bess.bessk(-1428,0.0 ) ;
  }

  @Test
  public void test4() {
    bess.bessk(-176,2.0 ) ;
  }

  @Test
  public void test5() {
    bess.bessk(211,1.9999999999999991 ) ;
  }

  @Test
  public void test6() {
    bess.bessk(291,60.7833282633471 ) ;
  }

  @Test
  public void test7() {
    bess.bessk(-337,-90.43457566113202 ) ;
  }

  @Test
  public void test8() {
    bess.bessk(345,-48.57103193692256 ) ;
  }

  @Test
  public void test9() {
    bess.bessk(-346,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test10() {
    bess.bessk(-39,-85.42587820254614 ) ;
  }

  @Test
  public void test11() {
    bess.bessk(440,-98.89458799450604 ) ;
  }

  @Test
  public void test12() {
    bess.bessk(624,-9.074252641438221 ) ;
  }

  @Test
  public void test13() {
    bess.bessk(-651,-7.11948010204199 ) ;
  }

  @Test
  public void test14() {
    bess.bessk(-673,1.3133458532256417 ) ;
  }

  @Test
  public void test15() {
    bess.bessk(-673,2.0E-323 ) ;
  }

  @Test
  public void test16() {
    bess.bessk(812,-6.9E-323 ) ;
  }

  @Test
  public void test17() {
    bess.bessk(858,4.440892098500626E-16 ) ;
  }

  @Test
  public void test18() {
    bess.bessk(868,0.0 ) ;
  }

  @Test
  public void test19() {
    bess.bessk(873,2.0 ) ;
  }

  @Test
  public void test20() {
    bess.bessk(886,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test21() {
    bess.bessk(-904,0 ) ;
  }

  @Test
  public void test22() {
    bess.bessk(920,0 ) ;
  }

  @Test
  public void test23() {
    bess.bessk(-932,2.0 ) ;
  }
}
