import org.junit.Test;

public class TestdawsonTest {

  @Test
  public void test0() {
    dawson.dawson(0.14740000976822581 ) ;
  }

  @Test
  public void test1() {
    dawson.dawson(-0.1999999999999993 ) ;
  }

  @Test
  public void test2() {
    dawson.dawson(-0.19999999999999996 ) ;
  }

  @Test
  public void test3() {
    dawson.dawson(-0.2 ) ;
  }

  @Test
  public void test4() {
    dawson.dawson(-0.20000000000000004 ) ;
  }

  @Test
  public void test5() {
    dawson.dawson(-0.20000000000000007 ) ;
  }

  @Test
  public void test6() {
    dawson.dawson(0.20000000000000007 ) ;
  }

  @Test
  public void test7() {
    dawson.dawson(0.20000000000000018 ) ;
  }

  @Test
  public void test8() {
    dawson.dawson(0.20000000000000107 ) ;
  }

  @Test
  public void test9() {
    dawson.dawson(-0.2376894974452689 ) ;
  }

  @Test
  public void test10() {
    dawson.dawson(0.24267738182429177 ) ;
  }

  @Test
  public void test11() {
    dawson.dawson(-0.2800788677689612 ) ;
  }

  @Test
  public void test12() {
    dawson.dawson(-0.39999999999999997 ) ;
  }

  @Test
  public void test13() {
    dawson.dawson(-0.4 ) ;
  }

  @Test
  public void test14() {
    dawson.dawson(0.4 ) ;
  }

  @Test
  public void test15() {
    dawson.dawson(0.4000000000000025 ) ;
  }

  @Test
  public void test16() {
    dawson.dawson(0.4108797144054155 ) ;
  }

  @Test
  public void test17() {
    dawson.dawson(-0.41577481720361087 ) ;
  }

  @Test
  public void test18() {
    dawson.dawson(0.5642023008650523 ) ;
  }

  @Test
  public void test19() {
    dawson.dawson(-0.5647841103845288 ) ;
  }

  @Test
  public void test20() {
    dawson.dawson(0.593891747361866 ) ;
  }

  @Test
  public void test21() {
    dawson.dawson(-0.6313747696646412 ) ;
  }

  @Test
  public void test22() {
    dawson.dawson(0.634796970776333 ) ;
  }

  @Test
  public void test23() {
    dawson.dawson(0.6515316779515054 ) ;
  }

  @Test
  public void test24() {
    dawson.dawson(-0.6894512013915618 ) ;
  }

  @Test
  public void test25() {
    dawson.dawson(-0.7676770665565602 ) ;
  }

  @Test
  public void test26() {
    dawson.dawson(-0.7999999999999996 ) ;
  }

  @Test
  public void test27() {
    dawson.dawson(0.7999999999999996 ) ;
  }

  @Test
  public void test28() {
    dawson.dawson(-0.7999999999999999 ) ;
  }

  @Test
  public void test29() {
    dawson.dawson(0.7999999999999999 ) ;
  }

  @Test
  public void test30() {
    dawson.dawson(1.0034283699768074 ) ;
  }

  @Test
  public void test31() {
    dawson.dawson(-1.0948094342120736 ) ;
  }

  @Test
  public void test32() {
    dawson.dawson(10.964599483285681 ) ;
  }

  @Test
  public void test33() {
    dawson.dawson(1.6512574767642265 ) ;
  }

  @Test
  public void test34() {
    dawson.dawson(-1.6582661672834569 ) ;
  }

  @Test
  public void test35() {
    dawson.dawson(18.16390377351098 ) ;
  }

  @Test
  public void test36() {
    dawson.dawson(-19.901223770111898 ) ;
  }

  @Test
  public void test37() {
    dawson.dawson(23.147660542696173 ) ;
  }

  @Test
  public void test38() {
    dawson.dawson(24.631160515890798 ) ;
  }

  @Test
  public void test39() {
    dawson.dawson(-2.4907970834927307 ) ;
  }

  @Test
  public void test40() {
    dawson.dawson(2.7003567516869613 ) ;
  }

  @Test
  public void test41() {
    dawson.dawson(-27.11611846473552 ) ;
  }

  @Test
  public void test42() {
    dawson.dawson(30.506518532438207 ) ;
  }

  @Test
  public void test43() {
    dawson.dawson(-3.321964290295119 ) ;
  }

  @Test
  public void test44() {
    dawson.dawson(33.31300071086446 ) ;
  }

  @Test
  public void test45() {
    dawson.dawson(3.5330353818899027 ) ;
  }

  @Test
  public void test46() {
    dawson.dawson(-37.32809293407491 ) ;
  }

  @Test
  public void test47() {
    dawson.dawson(3.84001299031695 ) ;
  }

  @Test
  public void test48() {
    dawson.dawson(39.65359776335987 ) ;
  }

  @Test
  public void test49() {
    dawson.dawson(40.274964939168996 ) ;
  }

  @Test
  public void test50() {
    dawson.dawson(4.0529324738529455 ) ;
  }

  @Test
  public void test51() {
    dawson.dawson(-41.14254488340406 ) ;
  }

  @Test
  public void test52() {
    dawson.dawson(-42.80956032197905 ) ;
  }

  @Test
  public void test53() {
    dawson.dawson(-4.291813492981957 ) ;
  }

  @Test
  public void test54() {
    dawson.dawson(44.799260079067466 ) ;
  }

  @Test
  public void test55() {
    dawson.dawson(-45.86269747426406 ) ;
  }

  @Test
  public void test56() {
    dawson.dawson(-47.15975362097331 ) ;
  }

  @Test
  public void test57() {
    dawson.dawson(48.80006125858273 ) ;
  }

  @Test
  public void test58() {
    dawson.dawson(-50.78487698817289 ) ;
  }

  @Test
  public void test59() {
    dawson.dawson(51.33493462709376 ) ;
  }

  @Test
  public void test60() {
    dawson.dawson(57.07504991492209 ) ;
  }

  @Test
  public void test61() {
    dawson.dawson(6.965887802409469 ) ;
  }

  @Test
  public void test62() {
    dawson.dawson(-70.24880345158894 ) ;
  }

  @Test
  public void test63() {
    dawson.dawson(72.28925388349353 ) ;
  }

  @Test
  public void test64() {
    dawson.dawson(72.5971014567586 ) ;
  }

  @Test
  public void test65() {
    dawson.dawson(-8.009119278412768 ) ;
  }

  @Test
  public void test66() {
    dawson.dawson(-80.50439121716724 ) ;
  }

  @Test
  public void test67() {
    dawson.dawson(-80.52823520196199 ) ;
  }

  @Test
  public void test68() {
    dawson.dawson(-81.19163235679625 ) ;
  }

  @Test
  public void test69() {
    dawson.dawson(-84.62839593827165 ) ;
  }

  @Test
  public void test70() {
    dawson.dawson(-86.90850291168839 ) ;
  }

  @Test
  public void test71() {
    dawson.dawson(89.94758425566263 ) ;
  }

  @Test
  public void test72() {
    dawson.dawson(90.1231594351276 ) ;
  }

  @Test
  public void test73() {
    dawson.dawson(9.163471347500547 ) ;
  }

  @Test
  public void test74() {
    dawson.dawson(-93.7688584042216 ) ;
  }

  @Test
  public void test75() {
    dawson.dawson(-94.19918430382145 ) ;
  }
}
