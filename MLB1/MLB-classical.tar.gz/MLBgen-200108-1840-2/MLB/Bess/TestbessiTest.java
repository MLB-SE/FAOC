import org.junit.Test;

public class TestbessiTest {

  @Test
  public void test0() {
    bess.bessi(105,7.860796873475891 ) ;
  }

  @Test
  public void test1() {
    bess.bessi(1158,7.753739648484046E-32 ) ;
  }

  @Test
  public void test2() {
    bess.bessi(-16,11.511137221363697 ) ;
  }

  @Test
  public void test3() {
    bess.bessi(333,0 ) ;
  }

  @Test
  public void test4() {
    bess.bessi(409,-57.45294612419703 ) ;
  }

  @Test
  public void test5() {
    bess.bessi(-472,-54.69699164830075 ) ;
  }

  @Test
  public void test6() {
    bess.bessi(-537,9.025090038388814E-9 ) ;
  }

  @Test
  public void test7() {
    bess.bessi(-599,0 ) ;
  }

  @Test
  public void test8() {
    bess.bessi(6,0.0 ) ;
  }

  @Test
  public void test9() {
    bess.bessi(-675,23.528378172350443 ) ;
  }

  @Test
  public void test10() {
    bess.bessi(682,-1.593112904727871E-9 ) ;
  }

  @Test
  public void test11() {
    bess.bessi(722,-4.093602121140606 ) ;
  }

  @Test
  public void test12() {
    bess.bessi(-824,2.626006902395564E-32 ) ;
  }

  @Test
  public void test13() {
    bess.bessi(-879,0.0 ) ;
  }
}
