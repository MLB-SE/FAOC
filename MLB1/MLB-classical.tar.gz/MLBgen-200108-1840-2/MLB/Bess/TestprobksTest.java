import org.junit.Test;

public class TestprobksTest {

  @Test
  public void test0() {
    dawson.probks(0.7598926595372859 ) ;
  }

  @Test
  public void test1() {
    dawson.probks(0.8449779587344324 ) ;
  }

  @Test
  public void test2() {
    dawson.probks(-16.174597313458378 ) ;
  }

  @Test
  public void test3() {
    dawson.probks(18.906605300595444 ) ;
  }

  @Test
  public void test4() {
    dawson.probks(19.28898415680933 ) ;
  }

  @Test
  public void test5() {
    dawson.probks(19.29527857493253 ) ;
  }

  @Test
  public void test6() {
    dawson.probks(19.295337737302553 ) ;
  }

  @Test
  public void test7() {
    dawson.probks(19.298375199710406 ) ;
  }

  @Test
  public void test8() {
    dawson.probks(2.7860531066846477 ) ;
  }

  @Test
  public void test9() {
    dawson.probks(30.71705478956366 ) ;
  }

  @Test
  public void test10() {
    dawson.probks(35.933576766803526 ) ;
  }

  @Test
  public void test11() {
    dawson.probks(48.717782654418244 ) ;
  }

  @Test
  public void test12() {
    dawson.probks(-6.317570139319727 ) ;
  }

  @Test
  public void test13() {
    dawson.probks(64.26275260711881 ) ;
  }

  @Test
  public void test14() {
    dawson.probks(-8.08511711661852 ) ;
  }
}
