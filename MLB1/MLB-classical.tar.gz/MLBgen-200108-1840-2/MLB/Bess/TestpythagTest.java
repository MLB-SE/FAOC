import org.junit.Test;

public class TestpythagTest {

  @Test
  public void test0() {
    dawson.pythag(0.0011650358596710124,-0.001168623087055324 ) ;
  }

  @Test
  public void test1() {
    dawson.pythag(0.0015658073887066665,0.0015658295400973784 ) ;
  }

  @Test
  public void test2() {
    dawson.pythag(-0.002813979387441942,-0.002813961064729661 ) ;
  }

  @Test
  public void test3() {
    dawson.pythag(-0.009528266690820655,-0.009528324711374686 ) ;
  }

  @Test
  public void test4() {
    dawson.pythag(-0.024372058555069742,0.024372058583679298 ) ;
  }

  @Test
  public void test5() {
    dawson.pythag(-0.27405215270424466,-0.2740521609244362 ) ;
  }

  @Test
  public void test6() {
    dawson.pythag(-0.35388298078317854,0.35389804188677876 ) ;
  }

  @Test
  public void test7() {
    dawson.pythag(100.0,0.0 ) ;
  }

  @Test
  public void test8() {
    dawson.pythag(10.311727244742741,0.0 ) ;
  }

  @Test
  public void test9() {
    dawson.pythag(1.1102230246251565E-16,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test10() {
    dawson.pythag(-11.291543576983273,-51.349945152264475 ) ;
  }

  @Test
  public void test11() {
    dawson.pythag(-11.724047435888584,-11.724047435888584 ) ;
  }

  @Test
  public void test12() {
    dawson.pythag(1.3698808431302519E-194,-1.3698808431302519E-194 ) ;
  }

  @Test
  public void test13() {
    dawson.pythag(13.807170176416989,0 ) ;
  }

  @Test
  public void test14() {
    dawson.pythag(-1.402757983365378E-191,1.402757983365378E-191 ) ;
  }

  @Test
  public void test15() {
    dawson.pythag(-16.21703309997757,-66.41706585212144 ) ;
  }

  @Test
  public void test16() {
    dawson.pythag(-1.778206999588062E-161,-1.778206999588062E-161 ) ;
  }

  @Test
  public void test17() {
    dawson.pythag(1.9721522630525295E-31,-6.011498826133131E-24 ) ;
  }

  @Test
  public void test18() {
    dawson.pythag(21.570477746317792,-21.570477746317792 ) ;
  }

  @Test
  public void test19() {
    dawson.pythag(-2.1684043449710089E-19,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test20() {
    dawson.pythag(21.931377913696153,-19.00231792262666 ) ;
  }

  @Test
  public void test21() {
    dawson.pythag(-2.4308653429145085E-63,8.884812225272962E-50 ) ;
  }

  @Test
  public void test22() {
    dawson.pythag(25.229720165569987,42.48425198523955 ) ;
  }

  @Test
  public void test23() {
    dawson.pythag(2.562979807693583E-31,2.563216384847137E-31 ) ;
  }

  @Test
  public void test24() {
    dawson.pythag(-2.657348416452293,2.657348416452293 ) ;
  }

  @Test
  public void test25() {
    dawson.pythag(-27.59231719885862,0.0 ) ;
  }

  @Test
  public void test26() {
    dawson.pythag(2.778448436856347E-163,3.0846974273316917E-179 ) ;
  }

  @Test
  public void test27() {
    dawson.pythag(2.8225406782040397E-241,0.0 ) ;
  }

  @Test
  public void test28() {
    dawson.pythag(-29.455945010056112,-16.63564837429523 ) ;
  }

  @Test
  public void test29() {
    dawson.pythag(-30.776379332315756,0 ) ;
  }

  @Test
  public void test30() {
    dawson.pythag(-3.16E-322,0.0 ) ;
  }

  @Test
  public void test31() {
    dawson.pythag(-33.21034685441731,97.60602244152608 ) ;
  }

  @Test
  public void test32() {
    dawson.pythag(3.3265978282137993,-3.3265978282137993 ) ;
  }

  @Test
  public void test33() {
    dawson.pythag(3.3881317890172014E-21,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test34() {
    dawson.pythag(3.469446951953614E-18,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test35() {
    dawson.pythag(3.606632272572553E-130,3.606632272572553E-130 ) ;
  }

  @Test
  public void test36() {
    dawson.pythag(37.70391820807369,0.0 ) ;
  }

  @Test
  public void test37() {
    dawson.pythag(3.852922799012944,-27.151202966159843 ) ;
  }

  @Test
  public void test38() {
    dawson.pythag(-3.855051834050356E-33,-3.869424210475875E-33 ) ;
  }

  @Test
  public void test39() {
    dawson.pythag(-3.9484127069845653E-177,-4.383618698016806E-193 ) ;
  }

  @Test
  public void test40() {
    dawson.pythag(-3.95964829762012,-67.67513655370907 ) ;
  }

  @Test
  public void test41() {
    dawson.pythag(4.2730054855919094E-65,-3.7982270983039195E-65 ) ;
  }

  @Test
  public void test42() {
    dawson.pythag(43.150527132128076,-43.150527132128076 ) ;
  }

  @Test
  public void test43() {
    dawson.pythag(46.40721708467865,90.94979300173526 ) ;
  }

  @Test
  public void test44() {
    dawson.pythag(47.609770913533424,-52.55513819217838 ) ;
  }

  @Test
  public void test45() {
    dawson.pythag(-4.922684329818012E-16,4.917558257251386E-16 ) ;
  }

  @Test
  public void test46() {
    dawson.pythag(-49.28891679099667,49.28891679099667 ) ;
  }

  @Test
  public void test47() {
    dawson.pythag(5.06E-321,0.0 ) ;
  }

  @Test
  public void test48() {
    dawson.pythag(-52.33814164172803,0.0 ) ;
  }

  @Test
  public void test49() {
    dawson.pythag(-52.3821487792995,86.50745291391985 ) ;
  }

  @Test
  public void test50() {
    dawson.pythag(53.96618059907905,53.96618059907905 ) ;
  }

  @Test
  public void test51() {
    dawson.pythag(-5.611031933461512E-191,5.611031933461512E-191 ) ;
  }

  @Test
  public void test52() {
    dawson.pythag(58.68274775758164,62.731732685016425 ) ;
  }

  @Test
  public void test53() {
    dawson.pythag(59.2746686663605,59.2746686663605 ) ;
  }

  @Test
  public void test54() {
    dawson.pythag(-59.73576481429483,90.37953030431561 ) ;
  }

  @Test
  public void test55() {
    dawson.pythag(61.20107415009346,68.82445779127468 ) ;
  }

  @Test
  public void test56() {
    dawson.pythag(61.364428688281635,-58.66206270359271 ) ;
  }

  @Test
  public void test57() {
    dawson.pythag(-6.2714455473651896,0.4214458835450472 ) ;
  }

  @Test
  public void test58() {
    dawson.pythag(64.40713880502719,0 ) ;
  }

  @Test
  public void test59() {
    dawson.pythag(-65.39393179790314,68.34117278982274 ) ;
  }

  @Test
  public void test60() {
    dawson.pythag(66.19680096303847,-72.89681340643838 ) ;
  }

  @Test
  public void test61() {
    dawson.pythag(6.729437401556018E-5,6.766657392735405E-5 ) ;
  }

  @Test
  public void test62() {
    dawson.pythag(-6.938893903907228E-18,0.061902191446384904 ) ;
  }

  @Test
  public void test63() {
    dawson.pythag(-7.490321610655521,0.0 ) ;
  }

  @Test
  public void test64() {
    dawson.pythag(-78.79952301882554,78.79952301882554 ) ;
  }

  @Test
  public void test65() {
    dawson.pythag(-7.888609052210118E-31,7.888609052210118E-31 ) ;
  }

  @Test
  public void test66() {
    dawson.pythag(79.28649145955185,61.85241837394136 ) ;
  }

  @Test
  public void test67() {
    dawson.pythag(81.36574199719547,81.36574199719547 ) ;
  }

  @Test
  public void test68() {
    dawson.pythag(-82.19944962235742,-82.19944962235742 ) ;
  }

  @Test
  public void test69() {
    dawson.pythag(84.26546277316015,17.47950765595985 ) ;
  }

  @Test
  public void test70() {
    dawson.pythag(8.433758354584419E-81,8.46409787442516E-81 ) ;
  }

  @Test
  public void test71() {
    dawson.pythag(-84.8731528952934,-46.59921101307947 ) ;
  }

  @Test
  public void test72() {
    dawson.pythag(-85.37942561009588,-85.37942561009588 ) ;
  }

  @Test
  public void test73() {
    dawson.pythag(-8.6916947597938E-311,0.0 ) ;
  }

  @Test
  public void test74() {
    dawson.pythag(-87.42495393333513,52.119020506833834 ) ;
  }

  @Test
  public void test75() {
    dawson.pythag(9.398401352086103E-190,-9.967194951097568E-206 ) ;
  }

  @Test
  public void test76() {
    dawson.pythag(9.453131681884498E-17,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test77() {
    dawson.pythag(-96.58798874766832,-71.20102127415129 ) ;
  }

  @Test
  public void test78() {
    dawson.pythag(98.01633331786036,-10.698470708446493 ) ;
  }
}
