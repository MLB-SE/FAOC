import org.junit.Test;

public class TestbessjTest {

  @Test
  public void test0() {
    bess.bessj(107,0.0 ) ;
  }

  @Test
  public void test1() {
    bess.bessj(107,-150.94781185384284 ) ;
  }

  @Test
  public void test2() {
    bess.bessj(-1098,-7.112827998352248E-161 ) ;
  }

  @Test
  public void test3() {
    bess.bessj(1,-1.0 ) ;
  }

  @Test
  public void test4() {
    bess.bessj(1,1.0 ) ;
  }

  @Test
  public void test5() {
    bess.bessj(1275,-6.480399673561395E-162 ) ;
  }

  @Test
  public void test6() {
    bess.bessj(151,-28.111458760265066 ) ;
  }

  @Test
  public void test7() {
    bess.bessj(1,-7.888609052210118E-31 ) ;
  }

  @Test
  public void test8() {
    bess.bessj(1,7.888609052210118E-31 ) ;
  }

  @Test
  public void test9() {
    bess.bessj(-207,54.7120322486513 ) ;
  }

  @Test
  public void test10() {
    bess.bessj(314,-10.896658535896833 ) ;
  }

  @Test
  public void test11() {
    bess.bessj(-352,4.445517498970155E-162 ) ;
  }

  @Test
  public void test12() {
    bess.bessj(-374,-12.261391610734321 ) ;
  }

  @Test
  public void test13() {
    bess.bessj(433,-1.2634920662350609E-175 ) ;
  }

  @Test
  public void test14() {
    bess.bessj(434,0.0 ) ;
  }

  @Test
  public void test15() {
    bess.bessj(-443,-69.29525001086809 ) ;
  }

  @Test
  public void test16() {
    bess.bessj(-467,15.700963360938871 ) ;
  }

  @Test
  public void test17() {
    bess.bessj(481,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test18() {
    bess.bessj(489,-7.240786055508238 ) ;
  }

  @Test
  public void test19() {
    bess.bessj(50,-50.0 ) ;
  }

  @Test
  public void test20() {
    bess.bessj(-583,2.220446049250313E-16 ) ;
  }

  @Test
  public void test21() {
    bess.bessj(-591,0 ) ;
  }

  @Test
  public void test22() {
    bess.bessj(-637,-26.614753815524665 ) ;
  }

  @Test
  public void test23() {
    bess.bessj(63,91.52101728548317 ) ;
  }

  @Test
  public void test24() {
    bess.bessj(653,0.0 ) ;
  }

  @Test
  public void test25() {
    bess.bessj(727,23.816244076308735 ) ;
  }

  @Test
  public void test26() {
    bess.bessj(-793,78.4817326838104 ) ;
  }

  @Test
  public void test27() {
    bess.bessj(-82,0.0 ) ;
  }

  @Test
  public void test28() {
    bess.bessj(-820,-8.24657274119959E-162 ) ;
  }

  @Test
  public void test29() {
    bess.bessj(831,0 ) ;
  }

  @Test
  public void test30() {
    bess.bessj(-843,0.0 ) ;
  }

  @Test
  public void test31() {
    bess.bessj(-852,0.0 ) ;
  }

  @Test
  public void test32() {
    bess.bessj(-854,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test33() {
    bess.bessj(874,84.57944848547001 ) ;
  }

  @Test
  public void test34() {
    bess.bessj(88,88.0 ) ;
  }

  @Test
  public void test35() {
    bess.bessj(90,5.0539682649402436E-175 ) ;
  }

  @Test
  public void test36() {
    bess.bessj(920,1.5E-323 ) ;
  }

  @Test
  public void test37() {
    bess.bessj(9,61.115787564888876 ) ;
  }
}
