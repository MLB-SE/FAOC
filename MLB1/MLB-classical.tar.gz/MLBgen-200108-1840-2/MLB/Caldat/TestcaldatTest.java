import org.junit.Test;

public class TestcaldatTest {

  @Test
  public void test0() {
    caldat.caldat(0 ) ;
  }

  @Test
  public void test1() {
    caldat.caldat(-1 ) ;
  }

  @Test
  public void test2() {
    caldat.caldat(12136 ) ;
  }

  @Test
  public void test3() {
    caldat.caldat(-184 ) ;
  }

  @Test
  public void test4() {
    caldat.caldat(222 ) ;
  }

  @Test
  public void test5() {
    caldat.caldat(-228 ) ;
  }

  @Test
  public void test6() {
    caldat.caldat(253 ) ;
  }

  @Test
  public void test7() {
    caldat.caldat(27295 ) ;
  }

  @Test
  public void test8() {
    caldat.caldat(-278 ) ;
  }

  @Test
  public void test9() {
    caldat.caldat(-315 ) ;
  }

  @Test
  public void test10() {
    caldat.caldat(-32 ) ;
  }

  @Test
  public void test11() {
    caldat.caldat(-331 ) ;
  }

  @Test
  public void test12() {
    caldat.caldat(-353 ) ;
  }

  @Test
  public void test13() {
    caldat.caldat(378 ) ;
  }

  @Test
  public void test14() {
    caldat.caldat(-381 ) ;
  }

  @Test
  public void test15() {
    caldat.caldat(390 ) ;
  }

  @Test
  public void test16() {
    caldat.caldat(404 ) ;
  }

  @Test
  public void test17() {
    caldat.caldat(-434 ) ;
  }

  @Test
  public void test18() {
    caldat.caldat(435 ) ;
  }

  @Test
  public void test19() {
    caldat.caldat(566 ) ;
  }

  @Test
  public void test20() {
    caldat.caldat(58 ) ;
  }

  @Test
  public void test21() {
    caldat.caldat(-690 ) ;
  }

  @Test
  public void test22() {
    caldat.caldat(-693 ) ;
  }

  @Test
  public void test23() {
    caldat.caldat(-717 ) ;
  }

  @Test
  public void test24() {
    caldat.caldat(723 ) ;
  }

  @Test
  public void test25() {
    caldat.caldat(737 ) ;
  }

  @Test
  public void test26() {
    caldat.caldat(758 ) ;
  }

  @Test
  public void test27() {
    caldat.caldat(83 ) ;
  }

  @Test
  public void test28() {
    caldat.caldat(-898 ) ;
  }

  @Test
  public void test29() {
    caldat.caldat(-98 ) ;
  }
}
