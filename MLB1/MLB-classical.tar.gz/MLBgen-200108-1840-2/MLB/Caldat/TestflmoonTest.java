import org.junit.Test;

public class TestflmoonTest {

  @Test
  public void test0() {
    caldat.flmoon(0,0 ) ;
  }

  @Test
  public void test1() {
    caldat.flmoon(0,1 ) ;
  }

  @Test
  public void test2() {
    caldat.flmoon(0,-168 ) ;
  }

  @Test
  public void test3() {
    caldat.flmoon(0,2 ) ;
  }

  @Test
  public void test4() {
    caldat.flmoon(0,3 ) ;
  }

  @Test
  public void test5() {
    caldat.flmoon(0,759 ) ;
  }

  @Test
  public void test6() {
    caldat.flmoon(0,840 ) ;
  }

  @Test
  public void test7() {
    caldat.flmoon(0,-999 ) ;
  }

  @Test
  public void test8() {
    caldat.flmoon(-1,0 ) ;
  }

  @Test
  public void test9() {
    caldat.flmoon(-1,1 ) ;
  }

  @Test
  public void test10() {
    caldat.flmoon(1,1 ) ;
  }

  @Test
  public void test11() {
    caldat.flmoon(-1,2 ) ;
  }

  @Test
  public void test12() {
    caldat.flmoon(-123,0 ) ;
  }

  @Test
  public void test13() {
    caldat.flmoon(1257,-6 ) ;
  }

  @Test
  public void test14() {
    caldat.flmoon(-128,2 ) ;
  }

  @Test
  public void test15() {
    caldat.flmoon(-1,3 ) ;
  }

  @Test
  public void test16() {
    caldat.flmoon(-1496,26 ) ;
  }

  @Test
  public void test17() {
    caldat.flmoon(-172,686 ) ;
  }

  @Test
  public void test18() {
    caldat.flmoon(-1757,2 ) ;
  }

  @Test
  public void test19() {
    caldat.flmoon(-200,2 ) ;
  }

  @Test
  public void test20() {
    caldat.flmoon(-221,3 ) ;
  }

  @Test
  public void test21() {
    caldat.flmoon(224,-895 ) ;
  }

  @Test
  public void test22() {
    caldat.flmoon(-227,-8 ) ;
  }

  @Test
  public void test23() {
    caldat.flmoon(-228,1 ) ;
  }

  @Test
  public void test24() {
    caldat.flmoon(-2,3 ) ;
  }

  @Test
  public void test25() {
    caldat.flmoon(-24,-1 ) ;
  }

  @Test
  public void test26() {
    caldat.flmoon(-250,0 ) ;
  }

  @Test
  public void test27() {
    caldat.flmoon(254,-3 ) ;
  }

  @Test
  public void test28() {
    caldat.flmoon(26,-106 ) ;
  }

  @Test
  public void test29() {
    caldat.flmoon(264,1673 ) ;
  }

  @Test
  public void test30() {
    caldat.flmoon(-270,1 ) ;
  }

  @Test
  public void test31() {
    caldat.flmoon(334,3 ) ;
  }

  @Test
  public void test32() {
    caldat.flmoon(373,182 ) ;
  }

  @Test
  public void test33() {
    caldat.flmoon(446,3 ) ;
  }

  @Test
  public void test34() {
    caldat.flmoon(460,2 ) ;
  }

  @Test
  public void test35() {
    caldat.flmoon(493,1 ) ;
  }

  @Test
  public void test36() {
    caldat.flmoon(493,2 ) ;
  }

  @Test
  public void test37() {
    caldat.flmoon(-501,3 ) ;
  }

  @Test
  public void test38() {
    caldat.flmoon(534,1 ) ;
  }

  @Test
  public void test39() {
    caldat.flmoon(-591,95 ) ;
  }

  @Test
  public void test40() {
    caldat.flmoon(-679,-462 ) ;
  }

  @Test
  public void test41() {
    caldat.flmoon(779,-10 ) ;
  }

  @Test
  public void test42() {
    caldat.flmoon(801,-101 ) ;
  }

  @Test
  public void test43() {
    caldat.flmoon(80,-19 ) ;
  }

  @Test
  public void test44() {
    caldat.flmoon(82,0 ) ;
  }

  @Test
  public void test45() {
    caldat.flmoon(913,0 ) ;
  }

  @Test
  public void test46() {
    caldat.flmoon(-947,305 ) ;
  }
}
