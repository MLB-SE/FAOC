import org.junit.Test;

public class TestjuldayTest {

  @Test
  public void test0() {
    caldat.julday(0,0,0 ) ;
  }

  @Test
  public void test1() {
    caldat.julday(0,0,-1 ) ;
  }

  @Test
  public void test2() {
    caldat.julday(0,0,-171 ) ;
  }

  @Test
  public void test3() {
    caldat.julday(0,0,-489 ) ;
  }

  @Test
  public void test4() {
    caldat.julday(0,0,712 ) ;
  }

  @Test
  public void test5() {
    caldat.julday(-10,0,0 ) ;
  }

  @Test
  public void test6() {
    caldat.julday(1019,0,0 ) ;
  }

  @Test
  public void test7() {
    caldat.julday(-116,0,-836 ) ;
  }

  @Test
  public void test8() {
    caldat.julday(-1,21369,2 ) ;
  }

  @Test
  public void test9() {
    caldat.julday(-1,23458,-2 ) ;
  }

  @Test
  public void test10() {
    caldat.julday(-13,0,0 ) ;
  }

  @Test
  public void test11() {
    caldat.julday(-13,0,-168 ) ;
  }

  @Test
  public void test12() {
    caldat.julday(-13,0,-853 ) ;
  }

  @Test
  public void test13() {
    caldat.julday(-13,0,892 ) ;
  }

  @Test
  public void test14() {
    caldat.julday(-13,0,917 ) ;
  }

  @Test
  public void test15() {
    caldat.julday(-13,-1496,-401 ) ;
  }

  @Test
  public void test16() {
    caldat.julday(-13,1656,25 ) ;
  }

  @Test
  public void test17() {
    caldat.julday(-13,1666,2096 ) ;
  }

  @Test
  public void test18() {
    caldat.julday(-13,1670,1917 ) ;
  }

  @Test
  public void test19() {
    caldat.julday(-13,206,0 ) ;
  }

  @Test
  public void test20() {
    caldat.julday(-13,497,-728 ) ;
  }

  @Test
  public void test21() {
    caldat.julday(-13,-630,1122 ) ;
  }

  @Test
  public void test22() {
    caldat.julday(150,-484,1586 ) ;
  }

  @Test
  public void test23() {
    caldat.julday(-15,22613,-5 ) ;
  }

  @Test
  public void test24() {
    caldat.julday(1,614,-401 ) ;
  }

  @Test
  public void test25() {
    caldat.julday(19096,1198,-1 ) ;
  }

  @Test
  public void test26() {
    caldat.julday(-19,21355,8 ) ;
  }

  @Test
  public void test27() {
    caldat.julday(19486,372,0 ) ;
  }

  @Test
  public void test28() {
    caldat.julday(19836,-228,-63 ) ;
  }

  @Test
  public void test29() {
    caldat.julday(-2,0,0 ) ;
  }

  @Test
  public void test30() {
    caldat.julday(-2,0,159 ) ;
  }

  @Test
  public void test31() {
    caldat.julday(2,0,-213 ) ;
  }

  @Test
  public void test32() {
    caldat.julday(-2,0,-245 ) ;
  }

  @Test
  public void test33() {
    caldat.julday(206,0,0 ) ;
  }

  @Test
  public void test34() {
    caldat.julday(-2,0,724 ) ;
  }

  @Test
  public void test35() {
    caldat.julday(-2,0,-738 ) ;
  }

  @Test
  public void test36() {
    caldat.julday(2,16702,0 ) ;
  }

  @Test
  public void test37() {
    caldat.julday(-24,20994,-4 ) ;
  }

  @Test
  public void test38() {
    caldat.julday(-297,193,1820 ) ;
  }

  @Test
  public void test39() {
    caldat.julday(-3,0,-1216 ) ;
  }

  @Test
  public void test40() {
    caldat.julday(-3,0,318 ) ;
  }

  @Test
  public void test41() {
    caldat.julday(314,0,-1 ) ;
  }

  @Test
  public void test42() {
    caldat.julday(-3,16643,-8 ) ;
  }

  @Test
  public void test43() {
    caldat.julday(-3,-168,86 ) ;
  }

  @Test
  public void test44() {
    caldat.julday(-3,-1772,0 ) ;
  }

  @Test
  public void test45() {
    caldat.julday(-34,0,0 ) ;
  }

  @Test
  public void test46() {
    caldat.julday(345,128,110 ) ;
  }

  @Test
  public void test47() {
    caldat.julday(348,0,12 ) ;
  }

  @Test
  public void test48() {
    caldat.julday(-362,-932,665 ) ;
  }

  @Test
  public void test49() {
    caldat.julday(-378,0,-1 ) ;
  }

  @Test
  public void test50() {
    caldat.julday(-38,13927,-16 ) ;
  }

  @Test
  public void test51() {
    caldat.julday(390,0,132 ) ;
  }

  @Test
  public void test52() {
    caldat.julday(395,-629,248 ) ;
  }

  @Test
  public void test53() {
    caldat.julday(4,0,0 ) ;
  }

  @Test
  public void test54() {
    caldat.julday(4,0,148 ) ;
  }

  @Test
  public void test55() {
    caldat.julday(4,0,-17 ) ;
  }

  @Test
  public void test56() {
    caldat.julday(4,0,1742 ) ;
  }

  @Test
  public void test57() {
    caldat.julday(4,0,-182 ) ;
  }

  @Test
  public void test58() {
    caldat.julday(4121,-40,1872 ) ;
  }

  @Test
  public void test59() {
    caldat.julday(423,506,0 ) ;
  }

  @Test
  public void test60() {
    caldat.julday(-442,0,1 ) ;
  }

  @Test
  public void test61() {
    caldat.julday(-4,-535,1740 ) ;
  }

  @Test
  public void test62() {
    caldat.julday(-469,-984,247 ) ;
  }

  @Test
  public void test63() {
    caldat.julday(481,0,-845 ) ;
  }

  @Test
  public void test64() {
    caldat.julday(-489,-597,-308 ) ;
  }

  @Test
  public void test65() {
    caldat.julday(492,0,-657 ) ;
  }

  @Test
  public void test66() {
    caldat.julday(-5,0,297 ) ;
  }

  @Test
  public void test67() {
    caldat.julday(510,0,519 ) ;
  }

  @Test
  public void test68() {
    caldat.julday(-521,0,2 ) ;
  }

  @Test
  public void test69() {
    caldat.julday(-569,0,-748 ) ;
  }

  @Test
  public void test70() {
    caldat.julday(-5,-81,-112 ) ;
  }

  @Test
  public void test71() {
    caldat.julday(-595,0,401 ) ;
  }

  @Test
  public void test72() {
    caldat.julday(609,0,949 ) ;
  }

  @Test
  public void test73() {
    caldat.julday(618,0,1 ) ;
  }

  @Test
  public void test74() {
    caldat.julday(-625,0,1 ) ;
  }

  @Test
  public void test75() {
    caldat.julday(-637,0,0 ) ;
  }

  @Test
  public void test76() {
    caldat.julday(638,-318,-29 ) ;
  }

  @Test
  public void test77() {
    caldat.julday(-63,835,1921 ) ;
  }

  @Test
  public void test78() {
    caldat.julday(-658,159,-535 ) ;
  }

  @Test
  public void test79() {
    caldat.julday(66,0,-233 ) ;
  }

  @Test
  public void test80() {
    caldat.julday(-670,0,-811 ) ;
  }

  @Test
  public void test81() {
    caldat.julday(-6,715,1949 ) ;
  }

  @Test
  public void test82() {
    caldat.julday(-673,0,31 ) ;
  }

  @Test
  public void test83() {
    caldat.julday(687,0,0 ) ;
  }

  @Test
  public void test84() {
    caldat.julday(707,-520,-854 ) ;
  }

  @Test
  public void test85() {
    caldat.julday(-725,0,553 ) ;
  }

  @Test
  public void test86() {
    caldat.julday(734,0,-998 ) ;
  }

  @Test
  public void test87() {
    caldat.julday(-7,-549,77 ) ;
  }

  @Test
  public void test88() {
    caldat.julday(76,0,-1 ) ;
  }

  @Test
  public void test89() {
    caldat.julday(-791,715,0 ) ;
  }

  @Test
  public void test90() {
    caldat.julday(-809,0,649 ) ;
  }

  @Test
  public void test91() {
    caldat.julday(-8,15375,-6 ) ;
  }

  @Test
  public void test92() {
    caldat.julday(-826,0,-421 ) ;
  }

  @Test
  public void test93() {
    caldat.julday(858,0,-976 ) ;
  }

  @Test
  public void test94() {
    caldat.julday(-866,0,-577 ) ;
  }

  @Test
  public void test95() {
    caldat.julday(-883,0,0 ) ;
  }

  @Test
  public void test96() {
    caldat.julday(897,0,1 ) ;
  }

  @Test
  public void test97() {
    caldat.julday(-911,0,178 ) ;
  }

  @Test
  public void test98() {
    caldat.julday(925,0,246 ) ;
  }
}
