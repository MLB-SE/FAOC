import org.junit.Test;

public class JpfTargetlaplaceTest {

  @Test
  public void test0() {
    color.laplace.solve(-0.120981075f,10.106492f,0f,-24.375874f,27.937548f,0f,-12.341329f,-24.989439f,-60.548595f ) ;
  }

  @Test
  public void test1() {
    color.laplace.solve(-0.25537238f,-96.23712f,-9.461262f,-12.911154f,-28.976744f,69.98014f,-22.412498f,-76.738846f,17.820877f ) ;
  }

  @Test
  public void test2() {
    color.laplace.solve(100.0f,16.7696f,0f,48.20076f,1.5650057f,-69.844696f,91.23804f,17.715014f,0f ) ;
  }

  @Test
  public void test3() {
    color.laplace.solve(10.218098f,36.066128f,38.376842f,-95.19373f,-4.330429f,17.44124f,-64.018875f,-2.5470316f,0f ) ;
  }

  @Test
  public void test4() {
    color.laplace.solve(10.402157f,-45.011494f,-12.980808f,-13.379879f,-11.034626f,70.07818f,-52.887047f,-8.479489f,0f ) ;
  }

  @Test
  public void test5() {
    color.laplace.solve(10.501299f,-57.962345f,55.919693f,-0.029737568f,-7.2330117f,42.352936f,-3.331797f,-13.292899f,-42.60679f ) ;
  }

  @Test
  public void test6() {
    color.laplace.solve(106.08815f,-76.30689f,0f,81.295586f,126.2544f,26.21719f,31.260557f,43.74664f,17.490957f ) ;
  }

  @Test
  public void test7() {
    color.laplace.solve(10.896946f,-64.87333f,-13.401487f,-6.243523f,-36.14539f,-80.805626f,0.27434984f,7.3409224f,65.234726f ) ;
  }

  @Test
  public void test8() {
    color.laplace.solve(11.891435f,6.331868f,62.436684f,13.095255f,-3.3443947f,11.778935f,43.83398f,-44.583637f,-11.976549f ) ;
  }

  @Test
  public void test9() {
    color.laplace.solve(12.141964f,6.6489573f,-37.852036f,-58.0811f,-47.6941f,100.0f,-99.76345f,45.770615f,0f ) ;
  }

  @Test
  public void test10() {
    color.laplace.solve(12.551966f,-38.25315f,-1.2469169f,-11.538985f,-56.122402f,100.0f,-2.5855052f,1.1969639f,0f ) ;
  }

  @Test
  public void test11() {
    color.laplace.solve(12.734723f,7.513131f,-94.2914f,-56.574238f,-20.127056f,0f,-0.7055303f,53.752117f,62.708855f ) ;
  }

  @Test
  public void test12() {
    color.laplace.solve(12.878147f,30.111244f,0f,-16.188086f,-68.56383f,25.39484f,-9.066661f,-20.078556f,-2.6837363f ) ;
  }

  @Test
  public void test13() {
    color.laplace.solve(13.037937f,51.955654f,21.046616f,-99.8039f,73.73806f,-67.76919f,-49.836735f,-99.54304f,68.72659f ) ;
  }

  @Test
  public void test14() {
    color.laplace.solve(13.111891f,-8.935809f,-110.88992f,-37.63028f,-38.160877f,-8.438614f,-125.54249f,-97.82731f,75.935555f ) ;
  }

  @Test
  public void test15() {
    color.laplace.solve(-13.530207f,39.76955f,0f,-10.104482f,-53.194347f,53.592186f,26.30663f,60.08424f,0f ) ;
  }

  @Test
  public void test16() {
    color.laplace.solve(13.69241f,9.393655f,21.864553f,-54.624012f,-97.982346f,-21.935442f,20.524277f,16.008549f,0f ) ;
  }

  @Test
  public void test17() {
    color.laplace.solve(13.723145f,81.82175f,0f,4.372532f,8.058501f,-20.557854f,-2.3397176f,-13.731402f,-60.644394f ) ;
  }

  @Test
  public void test18() {
    color.laplace.solve(13.950693f,-18.574198f,-99.998245f,-25.62303f,-88.249245f,40.53688f,-19.625933f,-52.8807f,0f ) ;
  }

  @Test
  public void test19() {
    color.laplace.solve(140.38443f,137.90463f,0f,49.05529f,24.783033f,-11.222357f,31.05578f,75.16784f,0f ) ;
  }

  @Test
  public void test20() {
    color.laplace.solve(-1.4335842f,-11.324509f,-62.498802f,-94.40983f,-81.36565f,49.689857f,-5.002063f,74.40157f,83.1083f ) ;
  }

  @Test
  public void test21() {
    color.laplace.solve(14.90822f,-1.6551727f,-0.83391845f,-8.189569f,-23.390299f,5.1987634f,-24.276197f,-88.91522f,45.01927f ) ;
  }

  @Test
  public void test22() {
    color.laplace.solve(15.047848f,29.570807f,37.179775f,-69.37942f,-33.944397f,19.148296f,-26.074762f,-34.919636f,-79.73372f ) ;
  }

  @Test
  public void test23() {
    color.laplace.solve(-15.128053f,77.03075f,-0.92354727f,11.586742f,52.82381f,99.659645f,8.651213f,23.01811f,30.597416f ) ;
  }

  @Test
  public void test24() {
    color.laplace.solve(15.229358f,-2.7082143f,0f,19.600885f,91.40305f,-1.9732866f,11.949348f,28.196508f,9.433636f ) ;
  }

  @Test
  public void test25() {
    color.laplace.solve(-15.307656f,87.29895f,0f,-38.204926f,-27.519152f,0f,-61.621384f,27.861996f,0f ) ;
  }

  @Test
  public void test26() {
    color.laplace.solve(15.316719f,42.85176f,0f,10.073331f,17.105463f,-1.7663451f,7.871143f,21.411242f,60.668358f ) ;
  }

  @Test
  public void test27() {
    color.laplace.solve(15.491972f,-100.0f,81.69309f,-7.7810755f,-44.235985f,-67.42279f,-2.3802886f,-1.740079f,-99.99999f ) ;
  }

  @Test
  public void test28() {
    color.laplace.solve(15.532924f,-39.770836f,-1.3997636f,1.9518527f,158.31908f,69.37327f,12.837078f,49.39646f,26.439604f ) ;
  }

  @Test
  public void test29() {
    color.laplace.solve(15.636386f,50.90217f,41.677715f,-88.35662f,46.29457f,15.808696f,0f,0f,0f ) ;
  }

  @Test
  public void test30() {
    color.laplace.solve(16.097557f,4.7441406f,-25.57352f,-40.353912f,-71.54748f,23.203323f,0f,0f,0f ) ;
  }

  @Test
  public void test31() {
    color.laplace.solve(16.245241f,-36.48f,-32.592525f,1.4609638f,-11.05293f,-10.337898f,0.6515449f,1.145216f,-2.665361f ) ;
  }

  @Test
  public void test32() {
    color.laplace.solve(16.276453f,10.690254f,-17.929625f,-2.3851376f,13.456421f,24.333248f,-39.273422f,21.187317f,-27.591318f ) ;
  }

  @Test
  public void test33() {
    color.laplace.solve(-16.39332f,30.02817f,-2.5732853f,-23.581406f,7.497138f,8.518874f,-85.429436f,15.022913f,29.151642f ) ;
  }

  @Test
  public void test34() {
    color.laplace.solve(-16.578388f,-72.43518f,-40.52916f,-93.87837f,-8.295787f,0f,-23.911108f,-1.7660614f,30.769005f ) ;
  }

  @Test
  public void test35() {
    color.laplace.solve(16.636332f,-21.21112f,0f,-49.673878f,29.883974f,-18.93029f,-11.508974f,3.6379807f,-3.8230772f ) ;
  }

  @Test
  public void test36() {
    color.laplace.solve(16.917673f,67.67069f,15.038241f,-100.0f,-28.93288f,100.0f,-28.333525f,-13.3341f,3.9300048f ) ;
  }

  @Test
  public void test37() {
    color.laplace.solve(17.016817f,-27.393587f,-48.495323f,-4.5391474f,-20.207308f,-100.0f,-4.4449363f,-13.240599f,-28.31015f ) ;
  }

  @Test
  public void test38() {
    color.laplace.solve(17.201199f,-15.404527f,47.828682f,-15.790681f,-59.02257f,-53.145462f,-21.34135f,-69.57472f,5.7463665f ) ;
  }

  @Test
  public void test39() {
    color.laplace.solve(17.633549f,73.47741f,0f,81.51291f,-20.97008f,0f,17.886356f,-9.967482f,-36.7862f ) ;
  }

  @Test
  public void test40() {
    color.laplace.solve(17.716625f,-33.37897f,74.04356f,4.245475f,-13.992049f,17.441406f,13.257322f,-44.276108f,100.0f ) ;
  }

  @Test
  public void test41() {
    color.laplace.solve(17.963608f,-17.174314f,99.717514f,-10.971252f,-28.136822f,-55.517696f,-33.7118f,-28.884018f,-8.84707f ) ;
  }

  @Test
  public void test42() {
    color.laplace.solve(18.149942f,-19.007637f,0f,-8.3925905f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test43() {
    color.laplace.solve(18.514822f,-48.118187f,26.746576f,22.177475f,-32.483536f,93.64697f,6.846926f,5.210229f,46.477528f ) ;
  }

  @Test
  public void test44() {
    color.laplace.solve(18.625017f,-78.251076f,84.77859f,52.75115f,20.32148f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test45() {
    color.laplace.solve(18.675026f,-33.74018f,17.701374f,8.440288f,0.74745643f,73.01041f,14.338667f,-44.720688f,-10.876909f ) ;
  }

  @Test
  public void test46() {
    color.laplace.solve(18.894672f,-67.999466f,-14.956853f,43.639458f,113.674446f,95.19821f,41.946003f,127.58637f,78.45253f ) ;
  }

  @Test
  public void test47() {
    color.laplace.solve(19.018948f,63.4958f,5.992455f,-87.42001f,-32.659847f,0f,47.742126f,0f,0f ) ;
  }

  @Test
  public void test48() {
    color.laplace.solve(1.9107453f,-28.651445f,-11.340887f,-63.705574f,-34.458187f,69.630905f,-16.464273f,-2.1515172f,42.31639f ) ;
  }

  @Test
  public void test49() {
    color.laplace.solve(-192.06085f,102.0246f,52.350163f,-65.828476f,-35.41136f,-99.761566f,-36.090073f,-78.19985f,76.19952f ) ;
  }

  @Test
  public void test50() {
    color.laplace.solve(19.26248f,-50.02681f,-60.556786f,27.07673f,44.3298f,0f,44.714645f,0f,0f ) ;
  }

  @Test
  public void test51() {
    color.laplace.solve(19.729351f,10.446362f,-93.403336f,-31.528955f,-64.411156f,14.129251f,-81.43401f,1.7784956f,0f ) ;
  }

  @Test
  public void test52() {
    color.laplace.solve(-19.866379f,-37.590195f,0f,-6.1248164f,45.719f,-67.82534f,-50.351887f,0.12608609f,0f ) ;
  }

  @Test
  public void test53() {
    color.laplace.solve(-20.429705f,-9.812596f,0f,-83.49397f,-75.5239f,0f,0.41239628f,0f,0f ) ;
  }

  @Test
  public void test54() {
    color.laplace.solve(20.469007f,-5.5237823f,-70.88342f,-12.600186f,-58.240513f,-50.52719f,-12.629241f,-37.91678f,-80.797356f ) ;
  }

  @Test
  public void test55() {
    color.laplace.solve(20.497475f,30.90852f,12.210691f,-48.918625f,-9.074089f,100.0f,-12.249669f,-0.08005384f,21.003542f ) ;
  }

  @Test
  public void test56() {
    color.laplace.solve(20.81717f,-23.987362f,8.648385f,7.256041f,-36.557423f,64.13891f,-0.274534f,-8.354177f,3.4152465f ) ;
  }

  @Test
  public void test57() {
    color.laplace.solve(20.96663f,-2.9725056f,-33.878555f,-13.160973f,-98.978096f,29.55702f,25.367575f,-97.44333f,0f ) ;
  }

  @Test
  public void test58() {
    color.laplace.solve(21.086878f,17.696962f,0f,11.744797f,34.342865f,78.53602f,-8.450556f,-45.54702f,0f ) ;
  }

  @Test
  public void test59() {
    color.laplace.solve(2.1250021f,38.985863f,14.261509f,-130.48105f,39.549133f,-249.84383f,-68.590065f,0f,0f ) ;
  }

  @Test
  public void test60() {
    color.laplace.solve(21.322433f,-50.556717f,0f,-6.282882f,-15.190479f,19.521284f,-31.25524f,-118.884026f,0f ) ;
  }

  @Test
  public void test61() {
    color.laplace.solve(22.193743f,10.048646f,18.000843f,-21.273674f,-100.0f,-87.755005f,-9.680756f,-17.449348f,0f ) ;
  }

  @Test
  public void test62() {
    color.laplace.solve(22.540806f,-72.11948f,14.530604f,62.282696f,-66.33402f,0f,52.821365f,-8.537603f,0f ) ;
  }

  @Test
  public void test63() {
    color.laplace.solve(22.633684f,-37.831154f,30.630123f,28.365892f,84.264694f,58.87586f,6.56519f,-2.1051335f,23.044886f ) ;
  }

  @Test
  public void test64() {
    color.laplace.solve(-22.787226f,-3.1497633f,-12.603268f,-3.335608f,6.3879485f,-24.593456f,3.0568452f,56.630623f,65.410416f ) ;
  }

  @Test
  public void test65() {
    color.laplace.solve(22.858843f,-44.65482f,-13.921135f,36.090195f,26.779911f,59.059315f,94.72202f,56.624958f,0f ) ;
  }

  @Test
  public void test66() {
    color.laplace.solve(2.363172f,-85.86716f,0f,-5.2218094f,-28.015057f,-100.0f,4.764646f,24.280394f,0f ) ;
  }

  @Test
  public void test67() {
    color.laplace.solve(23.697325f,-12.355576f,36.69483f,6.0150514f,-1.1746029f,1.5076311f,1.5374831f,0.13448873f,0.41052997f ) ;
  }

  @Test
  public void test68() {
    color.laplace.solve(23.7581f,-11.483503f,-23.12602f,-2.1720166f,-24.028591f,-50.960556f,-8.417576f,-31.498287f,-93.54698f ) ;
  }

  @Test
  public void test69() {
    color.laplace.solve(23.873169f,69.59774f,78.96217f,-74.105064f,75.555626f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test70() {
    color.laplace.solve(24.012373f,-18.110628f,100.0f,14.160121f,34.6485f,-14.40967f,-2.0203876f,-22.24167f,0f ) ;
  }

  @Test
  public void test71() {
    color.laplace.solve(24.157385f,-40.422092f,-27.674246f,37.051632f,-19.256048f,0f,14.609295f,21.385548f,0f ) ;
  }

  @Test
  public void test72() {
    color.laplace.solve(24.655058f,-84.67023f,84.226616f,5.7431664f,-27.606993f,10.100655f,25.924603f,-41.601566f,36.693447f ) ;
  }

  @Test
  public void test73() {
    color.laplace.solve(24.799244f,4.146833f,-82.79514f,-4.949859f,-43.12753f,-51.56383f,-1.4711506f,-0.93474305f,19.279911f ) ;
  }

  @Test
  public void test74() {
    color.laplace.solve(25.076414f,-44.08827f,57.262917f,44.39392f,-20.389671f,0f,10.005846f,-4.3705397f,-7.098333f ) ;
  }

  @Test
  public void test75() {
    color.laplace.solve(26.170883f,94.94314f,0f,27.583906f,72.0652f,-24.445034f,12.099543f,20.814262f,-0.9076931f ) ;
  }

  @Test
  public void test76() {
    color.laplace.solve(26.42114f,-33.938263f,-29.734472f,3.731504f,-9.706426f,-7.3129215f,-1.7886994f,-1.3060224f,-77.98517f ) ;
  }

  @Test
  public void test77() {
    color.laplace.solve(-26.46021f,50.252335f,0f,-54.70563f,-14.076366f,0f,-5.330721f,33.382748f,0f ) ;
  }

  @Test
  public void test78() {
    color.laplace.solve(26.664425f,4.5949883f,-84.91019f,2.0627089f,-23.374287f,36.33084f,4.960698f,86.79661f,0f ) ;
  }

  @Test
  public void test79() {
    color.laplace.solve(26.690287f,25.451572f,-11.795444f,-18.690424f,-45.923862f,0f,-17.524487f,-51.407528f,16.439983f ) ;
  }

  @Test
  public void test80() {
    color.laplace.solve(26.857899f,5.963948f,-81.14317f,1.4676474f,-21.858896f,-100.0f,0.8716284f,2.018866f,70.877335f ) ;
  }

  @Test
  public void test81() {
    color.laplace.solve(26.9514f,23.13609f,-193.71552f,-15.523473f,-89.69506f,-38.420067f,-0.53374565f,18.38699f,164.28738f ) ;
  }

  @Test
  public void test82() {
    color.laplace.solve(26.95292f,40.841274f,86.850685f,-33.02959f,-50.43851f,2.0446613f,0f,0f,0f ) ;
  }

  @Test
  public void test83() {
    color.laplace.solve(-2.7540236f,-101.12477f,0f,-53.491825f,28.115719f,0f,-17.786074f,-17.652473f,-11.948684f ) ;
  }

  @Test
  public void test84() {
    color.laplace.solve(27.603973f,49.37643f,-14.859177f,-38.960533f,-24.819653f,0f,-32.76181f,-92.086716f,0f ) ;
  }

  @Test
  public void test85() {
    color.laplace.solve(27.733849f,0.3085865f,-98.9939f,13.749045f,7.814514f,-46.841805f,19.447819f,64.04223f,-96.18784f ) ;
  }

  @Test
  public void test86() {
    color.laplace.solve(27.78615f,19.033283f,16.28952f,-7.888682f,-67.942535f,-53.875202f,-27.210789f,0f,0f ) ;
  }

  @Test
  public void test87() {
    color.laplace.solve(2.9096344f,-99.99999f,-92.50169f,11.638526f,42.486523f,69.5431f,1.1579497f,-7.006727f,-71.67138f ) ;
  }

  @Test
  public void test88() {
    color.laplace.solve(29.208921f,67.64124f,-48.750492f,-50.805557f,88.7522f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test89() {
    color.laplace.solve(29.250195f,14.134808f,-97.794525f,2.8659725f,-11.378932f,-100.0f,-6.407373f,-28.495464f,0f ) ;
  }

  @Test
  public void test90() {
    color.laplace.solve(29.301744f,25.597857f,36.32521f,-8.390876f,-63.23553f,-42.515068f,-5.991547f,-15.575314f,-61.188133f ) ;
  }

  @Test
  public void test91() {
    color.laplace.solve(29.388426f,23.217607f,6.0328374f,-5.663901f,-42.550835f,-6.8320804f,-9.4931965f,-32.308884f,0f ) ;
  }

  @Test
  public void test92() {
    color.laplace.solve(29.969046f,38.686333f,41.640583f,-18.810152f,-16.864294f,27.875996f,-2.0504353f,0f,0f ) ;
  }

  @Test
  public void test93() {
    color.laplace.solve(30.134033f,16.015005f,-56.27711f,4.5211277f,-11.023075f,-81.20564f,-1.0264467f,-8.626915f,-22.45814f ) ;
  }

  @Test
  public void test94() {
    color.laplace.solve(30.38547f,-6.126001f,84.109184f,27.667877f,87.71063f,0f,51.263725f,0f,0f ) ;
  }

  @Test
  public void test95() {
    color.laplace.solve(30.387854f,18.65811f,-36.333023f,2.893303f,-19.422392f,13.118301f,-3.5093558f,-91.6628f,0f ) ;
  }

  @Test
  public void test96() {
    color.laplace.solve(30.465086f,16.182241f,-54.67296f,5.6781044f,-10.378167f,-68.196915f,2.6255007f,4.823899f,-27.12703f ) ;
  }

  @Test
  public void test97() {
    color.laplace.solve(30.816124f,26.765457f,-6.879942f,-4.319347f,-19.38625f,-154.49779f,-27.107752f,55.237675f,0f ) ;
  }

  @Test
  public void test98() {
    color.laplace.solve(30.894054f,37.395237f,-0.5372539f,-13.819019f,-74.96024f,2.2143068f,-11.209889f,-31.02054f,-37.912033f ) ;
  }

  @Test
  public void test99() {
    color.laplace.solve(30.967531f,25.695877f,-24.616854f,-1.8257543f,-3.5671697f,-45.805107f,-34.703377f,31.681723f,0f ) ;
  }

  @Test
  public void test100() {
    color.laplace.solve(31.037415f,23.425028f,-98.76998f,0.72462744f,-19.265837f,-64.9961f,-8.873067f,-36.216896f,69.500435f ) ;
  }

  @Test
  public void test101() {
    color.laplace.solve(31.122242f,53.581966f,-76.68499f,-29.092995f,-27.547813f,0f,-31.206484f,-19.201292f,0f ) ;
  }

  @Test
  public void test102() {
    color.laplace.solve(31.202486f,19.03607f,-30.766748f,5.7738748f,-24.29146f,-47.01066f,16.184471f,-74.96512f,0f ) ;
  }

  @Test
  public void test103() {
    color.laplace.solve(31.20586f,25.93455f,0.5718716f,-1.111107f,-28.039534f,-99.99988f,-7.6107545f,-42.329285f,0f ) ;
  }

  @Test
  public void test104() {
    color.laplace.solve(31.215727f,19.36388f,-82.968956f,5.4990277f,29.20875f,43.194027f,-38.428364f,48.778065f,0f ) ;
  }

  @Test
  public void test105() {
    color.laplace.solve(-31.422903f,-60.466278f,0f,-12.602574f,-17.832052f,-66.65366f,-1.1553421f,7.981206f,50.91222f ) ;
  }

  @Test
  public void test106() {
    color.laplace.solve(31.859554f,11.578748f,-63.34511f,15.8594675f,46.274857f,-100.0f,-14.69654f,-62.169132f,0f ) ;
  }

  @Test
  public void test107() {
    color.laplace.solve(3.1886477f,-59.880672f,-92.24769f,-27.364737f,-99.39562f,-80.20253f,-13.251973f,-25.643156f,-36.621346f ) ;
  }

  @Test
  public void test108() {
    color.laplace.solve(31.900488f,16.495981f,-216.19641f,11.105799f,39.436073f,-110.92551f,-26.913364f,-47.13427f,0f ) ;
  }

  @Test
  public void test109() {
    color.laplace.solve(31.942137f,29.866f,30.51227f,-2.0974495f,-42.990406f,-82.142975f,2.6584713f,98.23632f,0f ) ;
  }

  @Test
  public void test110() {
    color.laplace.solve(32.17143f,32.74144f,-33.07577f,-4.055723f,-60.904392f,-72.189064f,12.51007f,54.096004f,0f ) ;
  }

  @Test
  public void test111() {
    color.laplace.solve(32.292175f,11.1272f,55.03075f,17.374834f,30.960655f,87.72936f,6.2465143f,7.6112237f,-6.762272f ) ;
  }

  @Test
  public void test112() {
    color.laplace.solve(32.432625f,-0.67870295f,22.921793f,30.409208f,-91.62624f,0f,-96.22799f,81.672615f,0f ) ;
  }

  @Test
  public void test113() {
    color.laplace.solve(32.63988f,10.411134f,-15.000489f,20.148388f,32.927197f,61.19174f,15.026478f,39.957523f,1.8123591f ) ;
  }

  @Test
  public void test114() {
    color.laplace.solve(33.315876f,-14.712372f,99.60905f,47.97587f,10.771719f,-22.556778f,13.217288f,4.8932834f,-4.4158735f ) ;
  }

  @Test
  public void test115() {
    color.laplace.solve(33.58358f,6.66961f,-48.540287f,27.664707f,-58.364853f,36.937595f,-100.0f,27.576448f,0f ) ;
  }

  @Test
  public void test116() {
    color.laplace.solve(33.733166f,23.387049f,-57.430325f,11.545619f,-18.743015f,0f,8.871829f,23.941696f,36.803356f ) ;
  }

  @Test
  public void test117() {
    color.laplace.solve(-33.739586f,-92.93295f,0f,12.890989f,77.43092f,73.21369f,7.8726172f,18.59948f,-10.905623f ) ;
  }

  @Test
  public void test118() {
    color.laplace.solve(33.858707f,33.405968f,-95.668465f,2.0288649f,8.261563f,21.419382f,-34.00481f,-23.990232f,0f ) ;
  }

  @Test
  public void test119() {
    color.laplace.solve(33.859127f,25.322546f,1.1771053f,10.113956f,-33.643562f,-149.9534f,40.26696f,117.769325f,0f ) ;
  }

  @Test
  public void test120() {
    color.laplace.solve(33.89094f,21.822723f,53.399952f,13.741044f,-100.0f,91.777084f,-100.0f,-88.16085f,0f ) ;
  }

  @Test
  public void test121() {
    color.laplace.solve(34.12845f,43.738552f,-0.16006817f,-7.224759f,-57.500423f,0f,-18.640411f,-67.33688f,0f ) ;
  }

  @Test
  public void test122() {
    color.laplace.solve(35.050343f,23.809685f,-1.5518315f,16.292524f,10.848735f,-57.498817f,19.271017f,60.79155f,38.888367f ) ;
  }

  @Test
  public void test123() {
    color.laplace.solve(35.20205f,41.04192f,16.891033f,-0.23372127f,12.0745945f,-73.47779f,6.4619546f,26.08154f,85.78961f ) ;
  }

  @Test
  public void test124() {
    color.laplace.solve(-35.25315f,-99.93171f,-93.311844f,-20.829926f,-43.900646f,-59.007244f,-4.165907f,4.166299f,-100.0f ) ;
  }

  @Test
  public void test125() {
    color.laplace.solve(35.306736f,-46.90031f,11.582162f,13.930113f,5.9437356f,12.795332f,14.46998f,43.949806f,-58.850945f ) ;
  }

  @Test
  public void test126() {
    color.laplace.solve(35.36595f,26.442623f,-29.639534f,15.021176f,0.04407743f,39.98301f,24.674677f,-81.2705f,0f ) ;
  }

  @Test
  public void test127() {
    color.laplace.solve(35.50692f,33.991844f,-11.70487f,8.03584f,-5.8302355f,68.29656f,2.4666727f,1.830851f,10.686967f ) ;
  }

  @Test
  public void test128() {
    color.laplace.solve(35.752182f,42.5761f,66.19621f,0.43262312f,-31.643997f,33.10783f,-4.021163f,-16.517275f,-30.403942f ) ;
  }

  @Test
  public void test129() {
    color.laplace.solve(-3.608298f,-100.0f,-85.68397f,-18.570837f,-58.395092f,-84.460526f,-12.279961f,-30.549006f,-8.587738f ) ;
  }

  @Test
  public void test130() {
    color.laplace.solve(36.1781f,41.120617f,18.914043f,3.5917878f,9.390327f,-100.0f,-31.201277f,0f,0f ) ;
  }

  @Test
  public void test131() {
    color.laplace.solve(36.31392f,22.906427f,-100.0f,22.34925f,55.311787f,-100.0f,-2.2287016f,84.294586f,0f ) ;
  }

  @Test
  public void test132() {
    color.laplace.solve(36.325115f,16.28941f,-11.111509f,29.011051f,-60.055965f,-56.218357f,2.429125f,-19.294552f,-19.551363f ) ;
  }

  @Test
  public void test133() {
    color.laplace.solve(36.468147f,97.10411f,27.477272f,-51.23152f,24.94215f,0f,4.5272713f,-26.925154f,0f ) ;
  }

  @Test
  public void test134() {
    color.laplace.solve(36.68452f,38.068005f,0.0124291405f,8.670073f,15.575317f,94.551094f,-17.57928f,-78.9872f,0f ) ;
  }

  @Test
  public void test135() {
    color.laplace.solve(36.815464f,34.979927f,4.7510037f,12.281932f,-1.6467534f,-16.316032f,1.2164025f,-7.416322f,-19.089058f ) ;
  }

  @Test
  public void test136() {
    color.laplace.solve(36.88427f,-95.59992f,0f,47.835213f,76.12794f,0f,78.32864f,0f,0f ) ;
  }

  @Test
  public void test137() {
    color.laplace.solve(37.004734f,45.800404f,50.352043f,2.2185366f,-4.1551695f,55.60777f,-23.975418f,-99.195816f,0f ) ;
  }

  @Test
  public void test138() {
    color.laplace.solve(37.17385f,34.19545f,-3.1163032f,14.499951f,2.7242577f,-100.0f,18.101698f,57.90684f,37.927914f ) ;
  }

  @Test
  public void test139() {
    color.laplace.solve(37.262463f,48.950798f,44.201935f,0.099119f,14.338464f,27.910378f,-51.204456f,-19.606516f,53.101112f ) ;
  }

  @Test
  public void test140() {
    color.laplace.solve(37.311802f,39.249546f,11.52301f,9.9976635f,-13.196753f,-90.01233f,15.875605f,-57.863102f,0f ) ;
  }

  @Test
  public void test141() {
    color.laplace.solve(37.483257f,40.471622f,20.252163f,9.461413f,4.150947f,-52.424114f,-3.7886374f,-24.615961f,-98.82615f ) ;
  }

  @Test
  public void test142() {
    color.laplace.solve(37.5761f,52.765606f,48.20487f,-2.4612114f,25.281458f,14.629345f,-72.7024f,36.19209f,0f ) ;
  }

  @Test
  public void test143() {
    color.laplace.solve(37.664997f,34.924725f,58.828167f,15.735255f,-57.011425f,10.035194f,0.32175577f,-14.448232f,-1.1032594f ) ;
  }

  @Test
  public void test144() {
    color.laplace.solve(37.738796f,48.657127f,-83.77034f,2.2979946f,-25.92037f,-77.86584f,-2.6264477f,-12.803665f,-22.667376f ) ;
  }

  @Test
  public void test145() {
    color.laplace.solve(38.000984f,25.183159f,-320.35608f,26.82078f,64.58857f,186.65256f,15.34984f,33.93162f,55.482967f ) ;
  }

  @Test
  public void test146() {
    color.laplace.solve(38.09129f,36.276726f,33.242496f,16.088432f,-15.239455f,-100.0f,41.501892f,100.0f,0f ) ;
  }

  @Test
  public void test147() {
    color.laplace.solve(38.1862f,32.52211f,-42.622116f,20.222683f,34.369583f,9.280454f,8.040464f,11.939174f,5.346647f ) ;
  }

  @Test
  public void test148() {
    color.laplace.solve(38.20788f,25.313736f,0f,15.613654f,18.994862f,33.83491f,5.2518764f,-83.71577f,0f ) ;
  }

  @Test
  public void test149() {
    color.laplace.solve(38.39017f,27.400696f,56.053066f,26.159985f,38.29102f,46.207302f,27.958748f,53.39609f,90.48513f ) ;
  }

  @Test
  public void test150() {
    color.laplace.solve(38.62518f,21.215317f,-100.0f,33.285404f,30.447468f,28.075747f,64.06897f,39.2134f,20.954502f ) ;
  }

  @Test
  public void test151() {
    color.laplace.solve(-38.77337f,-96.646095f,0f,-58.084373f,-76.49028f,0f,53.671654f,-90.09806f,0f ) ;
  }

  @Test
  public void test152() {
    color.laplace.solve(38.879692f,31.904985f,-95.70301f,23.613781f,42.625687f,86.79878f,12.949745f,28.185202f,-61.222515f ) ;
  }

  @Test
  public void test153() {
    color.laplace.solve(38.888504f,47.20461f,58.785107f,8.349388f,-8.855032f,4.5423083f,3.3640811f,-95.51641f,-31.760843f ) ;
  }

  @Test
  public void test154() {
    color.laplace.solve(38.956944f,22.311432f,-67.51579f,33.51634f,39.541126f,84.57186f,55.567287f,17.764877f,-76.616394f ) ;
  }

  @Test
  public void test155() {
    color.laplace.solve(39.019276f,38.557373f,-71.59954f,17.519735f,19.296232f,-8.426182f,11.763431f,29.533983f,18.598576f ) ;
  }

  @Test
  public void test156() {
    color.laplace.solve(39.06551f,-45.242645f,0f,27.221722f,3.1330216f,0f,-4.9804225f,0f,0f ) ;
  }

  @Test
  public void test157() {
    color.laplace.solve(39.13717f,46.02272f,-99.975365f,10.525958f,-2.7971673f,-100.0f,5.7638297f,12.529362f,47.150784f ) ;
  }

  @Test
  public void test158() {
    color.laplace.solve(39.215855f,47.08404f,18.456594f,9.779375f,30.663712f,-29.41451f,-30.762064f,95.20594f,-70.07308f ) ;
  }

  @Test
  public void test159() {
    color.laplace.solve(39.48582f,42.8406f,19.179825f,15.102682f,12.696752f,-66.1213f,8.228157f,0f,0f ) ;
  }

  @Test
  public void test160() {
    color.laplace.solve(39.502277f,36.04212f,57.91816f,21.966988f,5.657414f,-44.229702f,42.70826f,8.850246f,-59.12215f ) ;
  }

  @Test
  public void test161() {
    color.laplace.solve(39.618343f,37.972256f,-12.348759f,20.50111f,100.0f,0f,18.021475f,51.58479f,12.29617f ) ;
  }

  @Test
  public void test162() {
    color.laplace.solve(39.62478f,57.234436f,-100.0f,1.2646804f,23.844572f,-27.389618f,-58.41063f,64.26879f,-53.759018f ) ;
  }

  @Test
  public void test163() {
    color.laplace.solve(40.132683f,50.118202f,22.151402f,10.412529f,38.188732f,-67.08856f,-36.6713f,18.14198f,0f ) ;
  }

  @Test
  public void test164() {
    color.laplace.solve(40.2031f,41.814487f,26.836382f,18.997898f,0.21847557f,-99.9977f,35.570023f,40.05922f,0f ) ;
  }

  @Test
  public void test165() {
    color.laplace.solve(-40.65078f,-76.21212f,0f,-45.861427f,-69.53761f,85.13124f,-73.25732f,70.80358f,0f ) ;
  }

  @Test
  public void test166() {
    color.laplace.solve(40.7711f,52.600266f,78.062775f,10.484122f,-8.432805f,-46.92264f,9.598197f,-49.89297f,0f ) ;
  }

  @Test
  public void test167() {
    color.laplace.solve(40.8692f,53.572277f,99.92654f,9.904534f,-26.50663f,100.0f,25.255564f,99.99994f,0f ) ;
  }

  @Test
  public void test168() {
    color.laplace.solve(41.099983f,44.617878f,-44.052357f,19.78206f,-17.124325f,0f,50.28219f,-0.28996703f,0f ) ;
  }

  @Test
  public void test169() {
    color.laplace.solve(41.516033f,55.69087f,-18.729597f,10.373266f,99.97703f,-5.340143f,-100.0f,99.999054f,0f ) ;
  }

  @Test
  public void test170() {
    color.laplace.solve(-41.526825f,-66.9381f,0f,-23.778564f,-52.82368f,-66.50629f,-0.7637499f,20.723564f,14.621751f ) ;
  }

  @Test
  public void test171() {
    color.laplace.solve(41.54945f,48.355f,17.023706f,17.842806f,34.84684f,-80.26018f,-5.0250697f,-37.68307f,0f ) ;
  }

  @Test
  public void test172() {
    color.laplace.solve(41.62772f,65.45326f,90.999435f,1.0576224f,19.65633f,0.8784708f,-57.053562f,11.235967f,27.478527f ) ;
  }

  @Test
  public void test173() {
    color.laplace.solve(41.711327f,28.5345f,-26.001612f,38.310814f,-1.5717161f,-7.215416f,32.26123f,90.734116f,-100.0f ) ;
  }

  @Test
  public void test174() {
    color.laplace.solve(41.82299f,34.499496f,-13.923182f,32.792465f,5.390873f,-2.9590106f,83.956f,-42.769463f,-56.07559f ) ;
  }

  @Test
  public void test175() {
    color.laplace.solve(4.2178645f,9.798231f,-9.218393f,-92.92677f,-55.806545f,54.93269f,2.9045625f,-5.7783303f,0f ) ;
  }

  @Test
  public void test176() {
    color.laplace.solve(42.28604f,-58.455936f,98.842f,6.687532f,-11.355209f,29.757917f,-4.180705f,-23.41035f,-100.0f ) ;
  }

  @Test
  public void test177() {
    color.laplace.solve(42.512466f,48.797855f,-45.13132f,21.252018f,24.874449f,7.5636168f,17.621155f,53.380486f,0f ) ;
  }

  @Test
  public void test178() {
    color.laplace.solve(42.536243f,62.04052f,100.0f,8.104461f,5.625558f,23.438644f,-15.744525f,-71.08251f,0f ) ;
  }

  @Test
  public void test179() {
    color.laplace.solve(42.57986f,47.740494f,69.27983f,22.578949f,43.123196f,0f,6.878958f,4.936883f,-30.254622f ) ;
  }

  @Test
  public void test180() {
    color.laplace.solve(42.630787f,49.48639f,21.12915f,21.036757f,34.18562f,19.42592f,7.3306217f,8.285729f,0f ) ;
  }

  @Test
  public void test181() {
    color.laplace.solve(42.642906f,66.10595f,-6.7386007f,4.465682f,-22.169666f,-85.35119f,-0.3831882f,-5.998435f,-1.4408848f ) ;
  }

  @Test
  public void test182() {
    color.laplace.solve(43.038624f,56.027653f,71.836716f,16.12685f,9.235267f,65.32462f,12.23351f,32.80719f,0f ) ;
  }

  @Test
  public void test183() {
    color.laplace.solve(43.344173f,53.809776f,56.79266f,19.566917f,15.102273f,73.36086f,19.821222f,27.060375f,0f ) ;
  }

  @Test
  public void test184() {
    color.laplace.solve(-4.34402f,-84.62891f,0f,-74.33397f,-37.804012f,0f,-75.94781f,32.178566f,0f ) ;
  }

  @Test
  public void test185() {
    color.laplace.solve(4.3625884f,-34.953915f,43.778942f,15.715298f,-22.20668f,3.8162012f,80.705284f,-73.404305f,27.570091f ) ;
  }

  @Test
  public void test186() {
    color.laplace.solve(43.879204f,56.334053f,14.92387f,19.182768f,66.533134f,-96.63857f,-15.004328f,-79.20008f,0f ) ;
  }

  @Test
  public void test187() {
    color.laplace.solve(4.389833f,-0.6818174f,-100.0f,3.0223253f,5.0797143f,10.521657f,2.619754f,7.4566913f,58.10538f ) ;
  }

  @Test
  public void test188() {
    color.laplace.solve(44.149776f,49.19233f,39.515434f,27.40677f,13.104102f,8.869412f,6.377806f,-1.8955331f,-27.064041f ) ;
  }

  @Test
  public void test189() {
    color.laplace.solve(44.175453f,48.13429f,-1.1877432f,28.56752f,44.78415f,8.389184f,25.310476f,94.04561f,-10.039672f ) ;
  }

  @Test
  public void test190() {
    color.laplace.solve(-44.42112f,-40.896473f,0f,-9.2092495f,99.11684f,-47.946075f,-91.532715f,-65.15483f,0f ) ;
  }

  @Test
  public void test191() {
    color.laplace.solve(44.606194f,63.246235f,32.218937f,15.178536f,26.283075f,29.51081f,-10.175125f,-2.8032796f,0f ) ;
  }

  @Test
  public void test192() {
    color.laplace.solve(44.619392f,60.74082f,-59.28361f,17.736742f,15.021845f,-52.2666f,11.305731f,33.87642f,31.607742f ) ;
  }

  @Test
  public void test193() {
    color.laplace.solve(44.777378f,50.798836f,-30.077785f,28.310675f,88.49576f,38.538948f,-20.030436f,0f,0f ) ;
  }

  @Test
  public void test194() {
    color.laplace.solve(-44.88985f,-31.88965f,0f,-4.3507304f,-100.0f,-39.976902f,-7.2106667f,-24.491936f,9.242923f ) ;
  }

  @Test
  public void test195() {
    color.laplace.solve(45.428333f,55.76454f,22.808355f,25.94879f,54.821484f,-64.53112f,1.7304165f,-19.027122f,24.278648f ) ;
  }

  @Test
  public void test196() {
    color.laplace.solve(-45.52322f,-37.885345f,0f,-25.795546f,24.196297f,0f,-5.5132837f,3.7424107f,-3.7133713f ) ;
  }

  @Test
  public void test197() {
    color.laplace.solve(45.932297f,67.766174f,46.575665f,15.963022f,7.816044f,-77.19836f,10.103748f,24.45197f,27.656801f ) ;
  }

  @Test
  public void test198() {
    color.laplace.solve(-45.95648f,5.5561852f,0f,-15.432263f,-8.824707f,-65.05402f,-6.947868f,-12.359209f,-33.66426f ) ;
  }

  @Test
  public void test199() {
    color.laplace.solve(46.004147f,25.942759f,-74.18912f,58.073822f,31.965107f,0f,-38.271618f,0f,0f ) ;
  }

  @Test
  public void test200() {
    color.laplace.solve(46.055252f,60.25841f,58.23013f,23.962597f,36.575684f,34.64672f,13.21945f,27.435009f,43.781067f ) ;
  }

  @Test
  public void test201() {
    color.laplace.solve(46.132893f,59.5041f,31.553493f,25.02747f,60.330013f,-33.290127f,-6.3530254f,-50.43957f,0f ) ;
  }

  @Test
  public void test202() {
    color.laplace.solve(46.377304f,23.425142f,5.8562856f,62.08407f,-58.533024f,-100.0f,-5.146801f,-82.67127f,0f ) ;
  }

  @Test
  public void test203() {
    color.laplace.solve(46.4579f,30.734882f,-80.013405f,55.096725f,87.72713f,-37.285057f,86.20187f,100.0f,0f ) ;
  }

  @Test
  public void test204() {
    color.laplace.solve(46.820053f,57.666286f,18.190876f,29.613924f,54.300922f,-19.884737f,17.334723f,39.724964f,87.26422f ) ;
  }

  @Test
  public void test205() {
    color.laplace.solve(-48.040752f,-3.7731402f,0f,20.126244f,38.66105f,0f,-11.125739f,-64.6292f,0f ) ;
  }

  @Test
  public void test206() {
    color.laplace.solve(48.18498f,62.10482f,37.772404f,30.63509f,62.461895f,-35.11138f,11.893492f,16.938879f,-6.5998607f ) ;
  }

  @Test
  public void test207() {
    color.laplace.solve(48.417625f,79.96761f,-93.743805f,13.702894f,100.0f,0f,10.005749f,26.320103f,-4.7253385f ) ;
  }

  @Test
  public void test208() {
    color.laplace.solve(48.42028f,82.18257f,198.80725f,11.544466f,-18.7015f,-219.14787f,15.995973f,-93.59181f,0f ) ;
  }

  @Test
  public void test209() {
    color.laplace.solve(48.694416f,100.0f,0f,11.817346f,-8.293127f,-23.35899f,6.868092f,15.655023f,0f ) ;
  }

  @Test
  public void test210() {
    color.laplace.solve(48.804012f,38.285465f,0f,5.8986845f,-4.4591236f,0f,6.0796585f,18.41995f,-32.190186f ) ;
  }

  @Test
  public void test211() {
    color.laplace.solve(48.908688f,6.0236692f,-53.482376f,89.611084f,-74.279594f,19.276232f,18.358532f,-16.176958f,-8.786763f ) ;
  }

  @Test
  public void test212() {
    color.laplace.solve(49.13935f,91.916306f,-95.46719f,4.6410937f,-89.52629f,0f,58.951313f,0f,0f ) ;
  }

  @Test
  public void test213() {
    color.laplace.solve(49.51686f,29.76515f,-278.42538f,68.47075f,196.21126f,97.8755f,26.089645f,39.10847f,-61.916145f ) ;
  }

  @Test
  public void test214() {
    color.laplace.solve(4.9834075f,-45.68514f,-89.928856f,-34.18349f,10.408442f,64.81351f,-152.47531f,56.693012f,-70.608086f ) ;
  }

  @Test
  public void test215() {
    color.laplace.solve(49.902992f,71.03692f,83.95903f,28.575043f,50.285664f,35.83113f,14.111516f,27.871023f,0f ) ;
  }

  @Test
  public void test216() {
    color.laplace.solve(50.015854f,63.390076f,34.738335f,36.673344f,68.80611f,-41.256645f,27.871407f,74.81229f,-21.510853f ) ;
  }

  @Test
  public void test217() {
    color.laplace.solve(-50.09759f,61.897137f,0f,-18.773293f,-83.6176f,72.01204f,58.622025f,6.9074244f,0f ) ;
  }

  @Test
  public void test218() {
    color.laplace.solve(5.011071f,-4.5358057f,-39.578022f,-75.41991f,-83.57627f,-18.059444f,-37.89849f,-76.17406f,23.861864f ) ;
  }

  @Test
  public void test219() {
    color.laplace.solve(50.288063f,57.017727f,55.88009f,44.13453f,100.0f,0f,-6.789855f,-71.29395f,100.0f ) ;
  }

  @Test
  public void test220() {
    color.laplace.solve(50.43612f,77.04135f,96.36033f,24.703127f,61.368965f,-100.0f,-12.992578f,-76.67344f,99.9434f ) ;
  }

  @Test
  public void test221() {
    color.laplace.solve(5.053124f,15.419915f,-17.10927f,-95.20742f,-26.264193f,5.939105f,-51.67619f,0f,0f ) ;
  }

  @Test
  public void test222() {
    color.laplace.solve(-50.78847f,-58.70091f,0f,-16.845901f,-22.313374f,-31.361692f,5.718241f,-66.12305f,0f ) ;
  }

  @Test
  public void test223() {
    color.laplace.solve(51.19418f,62.184814f,59.062035f,42.591908f,33.127033f,19.172493f,86.04641f,8.558919f,-15.499094f ) ;
  }

  @Test
  public void test224() {
    color.laplace.solve(51.612648f,59.302635f,43.70593f,47.14796f,41.891964f,14.41351f,95.08723f,46.70375f,-22.446264f ) ;
  }

  @Test
  public void test225() {
    color.laplace.solve(51.70215f,54.086685f,-11.10754f,52.721905f,75.75214f,-52.810802f,-11.819524f,-100.0f,0f ) ;
  }

  @Test
  public void test226() {
    color.laplace.solve(51.93706f,70.69217f,61.329525f,37.056072f,69.502075f,74.598526f,26.78515f,95.66154f,-27.593876f ) ;
  }

  @Test
  public void test227() {
    color.laplace.solve(-52.92948f,-99.570984f,9.896015f,-12.099059f,-8.026891f,17.222885f,12.560135f,62.3396f,62.03716f ) ;
  }

  @Test
  public void test228() {
    color.laplace.solve(-53.21095f,-59.11715f,0f,-6.9049463f,24.588318f,57.29824f,0.9299521f,10.624755f,16.98075f ) ;
  }

  @Test
  public void test229() {
    color.laplace.solve(53.2585f,75.68277f,41.595135f,37.35124f,19.4306f,-15.187644f,76.71584f,-20.12396f,-55.531567f ) ;
  }

  @Test
  public void test230() {
    color.laplace.solve(53.472607f,34.315727f,-29.872482f,79.57469f,13.662785f,-56.445995f,-45.565403f,0f,0f ) ;
  }

  @Test
  public void test231() {
    color.laplace.solve(54.576797f,70.83941f,62.97731f,47.467773f,65.80354f,81.069824f,69.49075f,26.27118f,0f ) ;
  }

  @Test
  public void test232() {
    color.laplace.solve(54.70452f,71.75251f,40.92007f,47.06558f,91.385445f,-8.072228f,19.231024f,29.858517f,-99.99325f ) ;
  }

  @Test
  public void test233() {
    color.laplace.solve(55.366188f,-52.637894f,0f,29.865858f,-5.1701117f,-16.487768f,69.26736f,18.57936f,0f ) ;
  }

  @Test
  public void test234() {
    color.laplace.solve(56.15264f,71.873604f,-72.484474f,52.736958f,71.55215f,0f,3.408298f,-39.103764f,0.9891209f ) ;
  }

  @Test
  public void test235() {
    color.laplace.solve(56.332634f,37.066742f,91.934326f,88.2638f,-100.0f,55.470463f,-88.09595f,-99.44511f,0f ) ;
  }

  @Test
  public void test236() {
    color.laplace.solve(56.348934f,-6.158364f,0f,8.789171f,22.599478f,-32.70939f,6.440203f,16.971642f,38.84689f ) ;
  }

  @Test
  public void test237() {
    color.laplace.solve(56.58289f,26.331617f,37.358788f,99.99995f,-88.61521f,-22.050945f,0.2317748f,-99.072845f,27.294256f ) ;
  }

  @Test
  public void test238() {
    color.laplace.solve(56.65427f,90.80918f,-38.75449f,35.807903f,-5.3851075f,-20.614473f,91.96245f,-94.50693f,0f ) ;
  }

  @Test
  public void test239() {
    color.laplace.solve(56.80003f,54.94148f,72.79326f,72.25864f,38.545567f,0f,29.852604f,47.15178f,-59.81562f ) ;
  }

  @Test
  public void test240() {
    color.laplace.solve(56.950714f,62.890205f,63.035683f,64.91265f,31.574429f,4.2374697f,-12.360418f,0f,0f ) ;
  }

  @Test
  public void test241() {
    color.laplace.solve(57.9372f,-51.047478f,0f,39.150074f,36.85277f,-39.30182f,14.10579f,17.273087f,18.133783f ) ;
  }

  @Test
  public void test242() {
    color.laplace.solve(-58.535503f,58.15843f,0f,-26.578466f,-36.25814f,34.6767f,-11.520219f,-19.502409f,17.689491f ) ;
  }

  @Test
  public void test243() {
    color.laplace.solve(58.550407f,-8.1557455f,0f,72.82005f,40.53022f,0f,30.901758f,50.786976f,0f ) ;
  }

  @Test
  public void test244() {
    color.laplace.solve(59.614155f,70.381485f,31.788345f,68.075134f,28.364222f,0f,36.97647f,0f,0f ) ;
  }

  @Test
  public void test245() {
    color.laplace.solve(-59.96723f,-32.9334f,0f,-48.417393f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test246() {
    color.laplace.solve(60.035175f,79.71073f,58.80775f,60.42997f,100.0f,-6.823399f,81.68471f,-93.167404f,0f ) ;
  }

  @Test
  public void test247() {
    color.laplace.solve(60.05258f,98.32328f,0f,-89.56061f,-11.435924f,0f,-30.617374f,-32.90889f,-89.58226f ) ;
  }

  @Test
  public void test248() {
    color.laplace.solve(6.0114427f,-84.65141f,0f,24.183533f,-6.475776f,0f,79.80969f,95.80457f,0f ) ;
  }

  @Test
  public void test249() {
    color.laplace.solve(60.316925f,149.85919f,-44.390457f,-8.635385f,-78.50079f,51.98914f,-16.485708f,-57.453102f,-132.08734f ) ;
  }

  @Test
  public void test250() {
    color.laplace.solve(-60.328518f,47.67196f,88.98356f,-11.746093f,36.04822f,30.558475f,-22.704077f,77.70855f,-2.79788f ) ;
  }

  @Test
  public void test251() {
    color.laplace.solve(60.93043f,-46.074173f,0f,33.207542f,3.7490692f,-16.276606f,7.244245f,-4.230561f,-27.915558f ) ;
  }

  @Test
  public void test252() {
    color.laplace.solve(61.164406f,100.0f,38.74695f,44.65762f,97.41362f,-68.05774f,20.052458f,35.552208f,100.0f ) ;
  }

  @Test
  public void test253() {
    color.laplace.solve(62.789154f,18.928492f,17.487616f,38.083454f,31.745316f,63.491596f,57.799343f,6.4777236f,-30.86532f ) ;
  }

  @Test
  public void test254() {
    color.laplace.solve(-62.850525f,53.438404f,-47.94529f,-15.416395f,5.621402f,-13.206823f,-4.436457f,-2.3295944f,-10.503323f ) ;
  }

  @Test
  public void test255() {
    color.laplace.solve(-63.57218f,85.00605f,-8.81099f,-21.248106f,-1.9162229f,-14.654865f,-19.504019f,-56.76797f,-47.892246f ) ;
  }

  @Test
  public void test256() {
    color.laplace.solve(63.69739f,-97.904884f,0f,3.5283687f,-38.112858f,0f,78.6456f,0f,0f ) ;
  }

  @Test
  public void test257() {
    color.laplace.solve(64.15997f,71.278f,37.46097f,85.3619f,83.49104f,-21.434114f,31.35701f,-18.588657f,0f ) ;
  }

  @Test
  public void test258() {
    color.laplace.solve(6.435087f,-79.958435f,-12.527081f,5.6987815f,36.24772f,0f,13.949479f,50.099136f,0f ) ;
  }

  @Test
  public void test259() {
    color.laplace.solve(65.64396f,79.499054f,74.60917f,83.07677f,77.7431f,-98.97684f,87.64307f,-58.33784f,0f ) ;
  }

  @Test
  public void test260() {
    color.laplace.solve(65.70787f,-92.91402f,0f,-7.094284f,-70.09061f,0f,3.6640575f,21.750515f,0f ) ;
  }

  @Test
  public void test261() {
    color.laplace.solve(-65.92736f,-73.759575f,0f,-11.175823f,17.678352f,47.711876f,3.545715f,25.358683f,54.259834f ) ;
  }

  @Test
  public void test262() {
    color.laplace.solve(66.52228f,100.0f,24.866127f,66.089096f,44.234547f,0f,-44.756344f,-75.97535f,0f ) ;
  }

  @Test
  public void test263() {
    color.laplace.solve(-6.658437f,-98.13418f,-78.4385f,-28.49957f,-94.92949f,33.04832f,-12.410355f,-84.97726f,0f ) ;
  }

  @Test
  public void test264() {
    color.laplace.solve(6.8823495f,-62.525383f,-20.341698f,-9.945218f,-9.857247f,-35.250782f,-36.805977f,9.797831f,0f ) ;
  }

  @Test
  public void test265() {
    color.laplace.solve(-69.42291f,-0.79663414f,35.239796f,-21.279755f,4.4014125f,65.131676f,-20.09752f,-25.449636f,25.434666f ) ;
  }

  @Test
  public void test266() {
    color.laplace.solve(69.50272f,88.26006f,65.81027f,89.75084f,-86.38319f,0f,16.191225f,-24.985935f,-29.751778f ) ;
  }

  @Test
  public void test267() {
    color.laplace.solve(72.6819f,-80.99899f,0f,7.1425357f,-56.759396f,0f,-10.747857f,-50.133965f,93.95822f ) ;
  }

  @Test
  public void test268() {
    color.laplace.solve(73.06731f,-148.98491f,33.131283f,2.4057844f,-27.38299f,21.199066f,-35.93249f,15.848137f,79.04797f ) ;
  }

  @Test
  public void test269() {
    color.laplace.solve(73.718735f,-5.8874507f,0f,-9.196486f,-43.847664f,27.610882f,-66.65702f,85.205414f,0f ) ;
  }

  @Test
  public void test270() {
    color.laplace.solve(-7.3754234f,100.0f,0f,-79.43858f,10.345844f,31.65778f,-19.973886f,-0.4569592f,7.800205f ) ;
  }

  @Test
  public void test271() {
    color.laplace.solve(-7.3778915f,-90.06053f,0f,98.618256f,81.079f,0f,-81.70145f,-44.608562f,0f ) ;
  }

  @Test
  public void test272() {
    color.laplace.solve(74.43726f,70.53476f,0f,98.43947f,-95.10363f,0f,5.9598827f,-34.08624f,0f ) ;
  }

  @Test
  public void test273() {
    color.laplace.solve(7.912356f,-38.194546f,0f,-41.368343f,-45.48046f,-32.51973f,-17.021852f,-26.719067f,-44.373947f ) ;
  }

  @Test
  public void test274() {
    color.laplace.solve(80.08737f,-37.06675f,0f,59.98519f,71.33562f,0f,16.622282f,6.5039363f,-61.942154f ) ;
  }

  @Test
  public void test275() {
    color.laplace.solve(-80.19599f,26.86784f,0f,68.128365f,-48.167324f,0f,89.83838f,0f,0f ) ;
  }

  @Test
  public void test276() {
    color.laplace.solve(-80.357346f,-39.388172f,0f,2.789436f,36.44489f,0f,3.917757f,12.881592f,82.227806f ) ;
  }

  @Test
  public void test277() {
    color.laplace.solve(81.28117f,14.706821f,0f,19.59702f,34.381752f,37.7568f,-37.27485f,-86.81128f,0f ) ;
  }

  @Test
  public void test278() {
    color.laplace.solve(83.014175f,26.095379f,0f,-29.342531f,-49.176987f,0f,32.043194f,-58.504604f,0f ) ;
  }

  @Test
  public void test279() {
    color.laplace.solve(-84.37082f,8.860044f,-52.09909f,-11.893185f,-15.135297f,-22.202383f,51.93338f,-35.305664f,-6.836015f ) ;
  }

  @Test
  public void test280() {
    color.laplace.solve(-85.59618f,100.0f,0f,-45.141968f,-78.1566f,48.110737f,-16.815092f,-22.118402f,6.498084f ) ;
  }

  @Test
  public void test281() {
    color.laplace.solve(-85.74407f,-39.650116f,0f,-29.289375f,-68.769104f,0f,4.5445952f,47.46776f,94.52418f ) ;
  }

  @Test
  public void test282() {
    color.laplace.solve(-8.804237f,-65.30452f,-47.198246f,-69.91243f,-23.418118f,0f,71.81684f,47.141376f,0f ) ;
  }

  @Test
  public void test283() {
    color.laplace.solve(88.74191f,100.0f,0f,61.84026f,-0.47358343f,0f,33.97846f,74.07356f,27.050472f ) ;
  }

  @Test
  public void test284() {
    color.laplace.solve(8.897556f,-67.56465f,-66.07409f,3.154875f,3.9412522f,84.20691f,-0.21930784f,-4.032112f,-5.4329033f ) ;
  }

  @Test
  public void test285() {
    color.laplace.solve(8.913909f,-33.52356f,0f,-2.6057708f,34.70938f,0f,7.432893f,32.33734f,-72.16932f ) ;
  }

  @Test
  public void test286() {
    color.laplace.solve(-89.32346f,53.788635f,0f,150.24493f,26.684849f,56.322002f,42.324192f,19.05431f,7.2081995f ) ;
  }

  @Test
  public void test287() {
    color.laplace.solve(89.38203f,63.081192f,0f,2.835836f,-54.6458f,-38.8473f,-23.392878f,-40.304153f,0f ) ;
  }

  @Test
  public void test288() {
    color.laplace.solve(-89.498055f,63.045765f,0f,-12.694565f,15.365953f,-15.419942f,23.353846f,26.532557f,0f ) ;
  }

  @Test
  public void test289() {
    color.laplace.solve(-91.25487f,68.05804f,-99.99999f,-20.377909f,13.635523f,2.0532322f,-3.8922937f,4.8087344f,9.491708f ) ;
  }

  @Test
  public void test290() {
    color.laplace.solve(-91.429695f,11.908595f,0f,-3.3124917f,69.79761f,0f,8.382118f,0f,0f ) ;
  }

  @Test
  public void test291() {
    color.laplace.solve(9.434005f,-58.74822f,0f,-3.515761f,-18.190704f,8.977322f,-5.306345f,-17.70962f,-47.34143f ) ;
  }

  @Test
  public void test292() {
    color.laplace.solve(94.70433f,31.917551f,0f,-26.109608f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test293() {
    color.laplace.solve(94.72068f,20.338913f,6.035662f,-1.8698322f,-2.2000089f,-18.792864f,-100.0f,-8.4762535f,-74.88818f ) ;
  }

  @Test
  public void test294() {
    color.laplace.solve(96.177765f,65.724434f,52.67526f,33.845917f,26.0613f,-14.057621f,13.144598f,18.732477f,35.724007f ) ;
  }

  @Test
  public void test295() {
    color.laplace.solve(-9.618339f,16.092405f,-58.480495f,-1.8116419f,2.7290163f,-3.747349f,-0.35725102f,0.38264745f,-0.8411754f ) ;
  }

  @Test
  public void test296() {
    color.laplace.solve(-97.05393f,20.248611f,0f,-35.34635f,-12.521376f,40.909935f,-31.810106f,-91.89407f,64.782104f ) ;
  }

  @Test
  public void test297() {
    color.laplace.solve(9.706327f,-99.10143f,0f,17.478203f,-27.574383f,0f,87.78087f,-67.359535f,0f ) ;
  }

  @Test
  public void test298() {
    color.laplace.solve(-9.795016f,-97.811615f,-89.24345f,-41.368454f,42.51587f,0f,-86.434685f,90.99781f,0f ) ;
  }

  @Test
  public void test299() {
    color.laplace.solve(-98.0232f,66.0372f,-25.072554f,4.664815f,67.67551f,100.0f,49.006958f,100.0f,21.287685f ) ;
  }

  @Test
  public void test300() {
    color.laplace.solve(9.816361f,-54.257393f,-61.733368f,-13.257239f,-36.98773f,11.17972f,-25.85759f,-91.616005f,-63.95759f ) ;
  }

  @Test
  public void test301() {
    color.laplace.solve(98.57439f,-24.480457f,-35.357616f,35.84841f,11.535398f,-44.257282f,33.283855f,79.03092f,-100.0f ) ;
  }

  @Test
  public void test302() {
    color.laplace.solve(-99.937744f,-99.919205f,-84.56599f,-41.568428f,-49.321205f,-29.306566f,-17.014763f,-26.490623f,-39.62653f ) ;
  }
}
