import org.junit.Test;

public class JpfTargetloanTest {

  @Test
  public void test0() {
    color.loan.solve(64.288155f ) ;
  }

  @Test
  public void test1() {
    color.loan.solve(64.91535f ) ;
  }

  @Test
  public void test2() {
    color.loan.solve(74.55137f ) ;
  }
}
