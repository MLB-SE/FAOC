import org.junit.Test;

public class JpfTargetsendmoremoneyTest {

  @Test
  public void test0() {
    color.sendmoremoney.solve(0,5,3,3,3,9,0,0 ) ;
  }

  @Test
  public void test1() {
    color.sendmoremoney.solve(105,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test2() {
    color.sendmoremoney.solve(1,2,2,2,7,339,0,0 ) ;
  }

  @Test
  public void test3() {
    color.sendmoremoney.solve(1,7,7,0,0,0,0,0 ) ;
  }

  @Test
  public void test4() {
    color.sendmoremoney.solve(3,1,-508,0,0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    color.sendmoremoney.solve(4,7,7,7,-288,0,0,0 ) ;
  }

  @Test
  public void test6() {
    color.sendmoremoney.solve(4,9,7,561,0,0,0,0 ) ;
  }

  @Test
  public void test7() {
    color.sendmoremoney.solve(5,0,781,0,0,0,0,0 ) ;
  }

  @Test
  public void test8() {
    color.sendmoremoney.solve(6,0,2,6,4,1159,0,0 ) ;
  }

  @Test
  public void test9() {
    color.sendmoremoney.solve(626,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test10() {
    color.sendmoremoney.solve(6,8,1,864,0,0,0,0 ) ;
  }

  @Test
  public void test11() {
    color.sendmoremoney.solve(-753,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test12() {
    color.sendmoremoney.solve(7,5,8,-171,0,0,0,0 ) ;
  }

  @Test
  public void test13() {
    color.sendmoremoney.solve(7,7,9,2,362,0,0,0 ) ;
  }

  @Test
  public void test14() {
    color.sendmoremoney.solve(7,8,5,4,0,0,0,0 ) ;
  }

  @Test
  public void test15() {
    color.sendmoremoney.solve(7,9,2,8,6,0,0,0 ) ;
  }

  @Test
  public void test16() {
    color.sendmoremoney.solve(7,9,4,1,8,-1808,0,0 ) ;
  }

  @Test
  public void test17() {
    color.sendmoremoney.solve(8,0,4,4,518,0,0,0 ) ;
  }

  @Test
  public void test18() {
    color.sendmoremoney.solve(8,4,87,0,0,0,0,0 ) ;
  }

  @Test
  public void test19() {
    color.sendmoremoney.solve(9,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test20() {
    color.sendmoremoney.solve(9,4,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test21() {
    color.sendmoremoney.solve(9,789,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test22() {
    color.sendmoremoney.solve(9,-848,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test23() {
    color.sendmoremoney.solve(9,9,0,0,0,0,0,0 ) ;
  }
}
