import org.junit.Test;

public class JpfTargetmagicseries2Test {

  @Test
  public void test0() {
    color.magicseries.solve2(0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    color.magicseries.solve2(0,0,1,3 ) ;
  }

  @Test
  public void test2() {
    color.magicseries.solve2(0,2,1,402 ) ;
  }

  @Test
  public void test3() {
    color.magicseries.solve2(0,3,0,1 ) ;
  }

  @Test
  public void test4() {
    color.magicseries.solve2(0,3,1,141 ) ;
  }

  @Test
  public void test5() {
    color.magicseries.solve2(0,565,0,0 ) ;
  }

  @Test
  public void test6() {
    color.magicseries.solve2(1,0,0,0 ) ;
  }

  @Test
  public void test7() {
    color.magicseries.solve2(1,0,2,-710 ) ;
  }

  @Test
  public void test8() {
    color.magicseries.solve2(1,1,0,1 ) ;
  }

  @Test
  public void test9() {
    color.magicseries.solve2(1,23,0,0 ) ;
  }

  @Test
  public void test10() {
    color.magicseries.solve2(1,3,839,0 ) ;
  }

  @Test
  public void test11() {
    color.magicseries.solve2(2,0,-125,0 ) ;
  }

  @Test
  public void test12() {
    color.magicseries.solve2(3,3,1,0 ) ;
  }

  @Test
  public void test13() {
    color.magicseries.solve2(4,0,3,3 ) ;
  }

  @Test
  public void test14() {
    color.magicseries.solve2(4,2,1,4 ) ;
  }

  @Test
  public void test15() {
    color.magicseries.solve2(4,4,10,0 ) ;
  }

  @Test
  public void test16() {
    color.magicseries.solve2(4,-822,0,0 ) ;
  }

  @Test
  public void test17() {
    color.magicseries.solve2(66,0,0,0 ) ;
  }

  @Test
  public void test18() {
    color.magicseries.solve2(-855,0,0,0 ) ;
  }

  @Test
  public void test19() {
    color.magicseries.solve2(982,0,0,0 ) ;
  }
}
