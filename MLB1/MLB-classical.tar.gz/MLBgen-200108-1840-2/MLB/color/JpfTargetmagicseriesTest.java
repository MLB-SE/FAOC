import org.junit.Test;

public class JpfTargetmagicseriesTest {

  @Test
  public void test0() {
    color.magicseries.solve(0,0,0,2 ) ;
  }

  @Test
  public void test1() {
    color.magicseries.solve(0,0,0,3 ) ;
  }

  @Test
  public void test2() {
    color.magicseries.solve(0,0,0,4 ) ;
  }

  @Test
  public void test3() {
    color.magicseries.solve(0,0,1,0 ) ;
  }

  @Test
  public void test4() {
    color.magicseries.solve(0,0,2,0 ) ;
  }

  @Test
  public void test5() {
    color.magicseries.solve(0,0,3,3 ) ;
  }

  @Test
  public void test6() {
    color.magicseries.solve(0,0,4,1 ) ;
  }

  @Test
  public void test7() {
    color.magicseries.solve(0,1,1,2 ) ;
  }

  @Test
  public void test8() {
    color.magicseries.solve(0,1,2,-499 ) ;
  }

  @Test
  public void test9() {
    color.magicseries.solve(0,1,3,0 ) ;
  }

  @Test
  public void test10() {
    color.magicseries.solve(0,134,0,0 ) ;
  }

  @Test
  public void test11() {
    color.magicseries.solve(0,2,3,0 ) ;
  }

  @Test
  public void test12() {
    color.magicseries.solve(0,2,4,2 ) ;
  }

  @Test
  public void test13() {
    color.magicseries.solve(0,3,0,3 ) ;
  }

  @Test
  public void test14() {
    color.magicseries.solve(0,3,1,0 ) ;
  }

  @Test
  public void test15() {
    color.magicseries.solve(0,3,1,1 ) ;
  }

  @Test
  public void test16() {
    color.magicseries.solve(0,3,1,3 ) ;
  }

  @Test
  public void test17() {
    color.magicseries.solve(0,4,1,0 ) ;
  }

  @Test
  public void test18() {
    color.magicseries.solve(0,4,1,2 ) ;
  }

  @Test
  public void test19() {
    color.magicseries.solve(1,0,0,0 ) ;
  }

  @Test
  public void test20() {
    color.magicseries.solve(1,0,0,4 ) ;
  }

  @Test
  public void test21() {
    color.magicseries.solve(1,0,1,1 ) ;
  }

  @Test
  public void test22() {
    color.magicseries.solve(1,0,1,2 ) ;
  }

  @Test
  public void test23() {
    color.magicseries.solve(1,0,1,3 ) ;
  }

  @Test
  public void test24() {
    color.magicseries.solve(1,0,1,4 ) ;
  }

  @Test
  public void test25() {
    color.magicseries.solve(1,0,2,1 ) ;
  }

  @Test
  public void test26() {
    color.magicseries.solve(1,0,3,0 ) ;
  }

  @Test
  public void test27() {
    color.magicseries.solve(1,0,3,4 ) ;
  }

  @Test
  public void test28() {
    color.magicseries.solve(1,0,4,0 ) ;
  }

  @Test
  public void test29() {
    color.magicseries.solve(1,0,4,1 ) ;
  }

  @Test
  public void test30() {
    color.magicseries.solve(1,1,0,0 ) ;
  }

  @Test
  public void test31() {
    color.magicseries.solve(1,1,0,1 ) ;
  }

  @Test
  public void test32() {
    color.magicseries.solve(1,1,0,2 ) ;
  }

  @Test
  public void test33() {
    color.magicseries.solve(1,1,0,3 ) ;
  }

  @Test
  public void test34() {
    color.magicseries.solve(1,1,1,0 ) ;
  }

  @Test
  public void test35() {
    color.magicseries.solve(1,1,1,-1 ) ;
  }

  @Test
  public void test36() {
    color.magicseries.solve(1,1,1,1 ) ;
  }

  @Test
  public void test37() {
    color.magicseries.solve(1,1,2,0 ) ;
  }

  @Test
  public void test38() {
    color.magicseries.solve(1,1,3,1 ) ;
  }

  @Test
  public void test39() {
    color.magicseries.solve(1,1,4,0 ) ;
  }

  @Test
  public void test40() {
    color.magicseries.solve(1,1,4,3 ) ;
  }

  @Test
  public void test41() {
    color.magicseries.solve(1,2,0,0 ) ;
  }

  @Test
  public void test42() {
    color.magicseries.solve(1,2,0,1 ) ;
  }

  @Test
  public void test43() {
    color.magicseries.solve(1,2,0,2 ) ;
  }

  @Test
  public void test44() {
    color.magicseries.solve(1,2,0,3 ) ;
  }

  @Test
  public void test45() {
    color.magicseries.solve(1,2,0,4 ) ;
  }

  @Test
  public void test46() {
    color.magicseries.solve(1,2,1,1 ) ;
  }

  @Test
  public void test47() {
    color.magicseries.solve(1,2,2,0 ) ;
  }

  @Test
  public void test48() {
    color.magicseries.solve(1,2,4,0 ) ;
  }

  @Test
  public void test49() {
    color.magicseries.solve(1,3,0,0 ) ;
  }

  @Test
  public void test50() {
    color.magicseries.solve(1,3,0,1 ) ;
  }

  @Test
  public void test51() {
    color.magicseries.solve(1,3,0,2 ) ;
  }

  @Test
  public void test52() {
    color.magicseries.solve(1,3,0,4 ) ;
  }

  @Test
  public void test53() {
    color.magicseries.solve(1,3,1,0 ) ;
  }

  @Test
  public void test54() {
    color.magicseries.solve(1,3,1,4 ) ;
  }

  @Test
  public void test55() {
    color.magicseries.solve(1,3,2,0 ) ;
  }

  @Test
  public void test56() {
    color.magicseries.solve(1,3,2,1 ) ;
  }

  @Test
  public void test57() {
    color.magicseries.solve(1,3,3,0 ) ;
  }

  @Test
  public void test58() {
    color.magicseries.solve(1,3,4,0 ) ;
  }

  @Test
  public void test59() {
    color.magicseries.solve(1,4,1,0 ) ;
  }

  @Test
  public void test60() {
    color.magicseries.solve(1,4,2,2 ) ;
  }

  @Test
  public void test61() {
    color.magicseries.solve(1,4,4,4 ) ;
  }

  @Test
  public void test62() {
    color.magicseries.solve(15,0,0,0 ) ;
  }

  @Test
  public void test63() {
    color.magicseries.solve(1,640,0,0 ) ;
  }

  @Test
  public void test64() {
    color.magicseries.solve(2,0,0,0 ) ;
  }

  @Test
  public void test65() {
    color.magicseries.solve(2,0,0,1 ) ;
  }

  @Test
  public void test66() {
    color.magicseries.solve(2,0,0,2 ) ;
  }

  @Test
  public void test67() {
    color.magicseries.solve(2,0,0,3 ) ;
  }

  @Test
  public void test68() {
    color.magicseries.solve(2,0,0,4 ) ;
  }

  @Test
  public void test69() {
    color.magicseries.solve(2,0,1,1 ) ;
  }

  @Test
  public void test70() {
    color.magicseries.solve(2,0,1,3 ) ;
  }

  @Test
  public void test71() {
    color.magicseries.solve(2,0,1,4 ) ;
  }

  @Test
  public void test72() {
    color.magicseries.solve(2,0,2,1 ) ;
  }

  @Test
  public void test73() {
    color.magicseries.solve(2,0,2,3 ) ;
  }

  @Test
  public void test74() {
    color.magicseries.solve(2,0,276,0 ) ;
  }

  @Test
  public void test75() {
    color.magicseries.solve(2,0,3,2 ) ;
  }

  @Test
  public void test76() {
    color.magicseries.solve(2,0,4,1 ) ;
  }

  @Test
  public void test77() {
    color.magicseries.solve(2,1,0,0 ) ;
  }

  @Test
  public void test78() {
    color.magicseries.solve(2,1,0,1 ) ;
  }

  @Test
  public void test79() {
    color.magicseries.solve(2,1,0,2 ) ;
  }

  @Test
  public void test80() {
    color.magicseries.solve(2,1,0,4 ) ;
  }

  @Test
  public void test81() {
    color.magicseries.solve(2,1,1,0 ) ;
  }

  @Test
  public void test82() {
    color.magicseries.solve(2,1,4,0 ) ;
  }

  @Test
  public void test83() {
    color.magicseries.solve(2,2,0,0 ) ;
  }

  @Test
  public void test84() {
    color.magicseries.solve(2,2,2,0 ) ;
  }

  @Test
  public void test85() {
    color.magicseries.solve(2,2,4,0 ) ;
  }

  @Test
  public void test86() {
    color.magicseries.solve(2,3,0,0 ) ;
  }

  @Test
  public void test87() {
    color.magicseries.solve(2,3,0,1 ) ;
  }

  @Test
  public void test88() {
    color.magicseries.solve(2,3,0,435 ) ;
  }

  @Test
  public void test89() {
    color.magicseries.solve(2,3,1,0 ) ;
  }

  @Test
  public void test90() {
    color.magicseries.solve(2,3,2,0 ) ;
  }

  @Test
  public void test91() {
    color.magicseries.solve(2,4,0,0 ) ;
  }

  @Test
  public void test92() {
    color.magicseries.solve(2,4,-263,0 ) ;
  }

  @Test
  public void test93() {
    color.magicseries.solve(2,4,4,0 ) ;
  }

  @Test
  public void test94() {
    color.magicseries.solve(3,0,0,0 ) ;
  }

  @Test
  public void test95() {
    color.magicseries.solve(3,0,0,1 ) ;
  }

  @Test
  public void test96() {
    color.magicseries.solve(3,0,0,3 ) ;
  }

  @Test
  public void test97() {
    color.magicseries.solve(3,0,0,4 ) ;
  }

  @Test
  public void test98() {
    color.magicseries.solve(3,0,1,0 ) ;
  }

  @Test
  public void test99() {
    color.magicseries.solve(3,1,0,2 ) ;
  }

  @Test
  public void test100() {
    color.magicseries.solve(3,1,-1,1 ) ;
  }

  @Test
  public void test101() {
    color.magicseries.solve(3,3,0,0 ) ;
  }

  @Test
  public void test102() {
    color.magicseries.solve(3,3,2,3 ) ;
  }

  @Test
  public void test103() {
    color.magicseries.solve(3,3,3,0 ) ;
  }

  @Test
  public void test104() {
    color.magicseries.solve(3,4,2,0 ) ;
  }

  @Test
  public void test105() {
    color.magicseries.solve(4,0,1,1 ) ;
  }

  @Test
  public void test106() {
    color.magicseries.solve(4,0,2,2 ) ;
  }

  @Test
  public void test107() {
    color.magicseries.solve(4,0,4,2 ) ;
  }

  @Test
  public void test108() {
    color.magicseries.solve(4,1,0,0 ) ;
  }

  @Test
  public void test109() {
    color.magicseries.solve(4,1,2,4 ) ;
  }

  @Test
  public void test110() {
    color.magicseries.solve(4,1,3,2 ) ;
  }

  @Test
  public void test111() {
    color.magicseries.solve(4,3,2,536 ) ;
  }

  @Test
  public void test112() {
    color.magicseries.solve(4,4,0,4 ) ;
  }

  @Test
  public void test113() {
    color.magicseries.solve(4,-44,0,0 ) ;
  }

  @Test
  public void test114() {
    color.magicseries.solve(4,4,540,0 ) ;
  }

  @Test
  public void test115() {
    color.magicseries.solve(780,0,0,0 ) ;
  }

  @Test
  public void test116() {
    color.magicseries.solve(-870,0,0,0 ) ;
  }
}
