import org.junit.Test;

public class TestgamdevTest {

  @Test
  public void test0() {
    dev.gamdev(1,0 ) ;
  }

  @Test
  public void test1() {
    dev.gamdev(1,266 ) ;
  }

  @Test
  public void test2() {
    dev.gamdev(147,-368 ) ;
  }

  @Test
  public void test3() {
    dev.gamdev(284,0 ) ;
  }

  @Test
  public void test4() {
    dev.gamdev(305,-1 ) ;
  }

  @Test
  public void test5() {
    dev.gamdev(409,0 ) ;
  }

  @Test
  public void test6() {
    dev.gamdev(455,0 ) ;
  }

  @Test
  public void test7() {
    dev.gamdev(4,-924 ) ;
  }

  @Test
  public void test8() {
    dev.gamdev(5,0 ) ;
  }

  @Test
  public void test9() {
    dev.gamdev(552,443 ) ;
  }

  @Test
  public void test10() {
    dev.gamdev(6,0 ) ;
  }

  @Test
  public void test11() {
    dev.gamdev(817,-994 ) ;
  }

  @Test
  public void test12() {
    dev.gamdev(-829,0 ) ;
  }

  @Test
  public void test13() {
    dev.gamdev(-89,0 ) ;
  }

  @Test
  public void test14() {
    dev.gamdev(-915,0 ) ;
  }

  @Test
  public void test15() {
    dev.gamdev(980,632 ) ;
  }
}
