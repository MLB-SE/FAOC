import org.junit.Test;

public class TestbnldevTest {

  @Test
  public void test0() {
    dev.bnldev(0.0,26,0 ) ;
  }

  @Test
  public void test1() {
    dev.bnldev(0.0,79,0 ) ;
  }

  @Test
  public void test2() {
    dev.bnldev(1.0,224,0 ) ;
  }

  @Test
  public void test3() {
    dev.bnldev(1.0,-32,0 ) ;
  }

  @Test
  public void test4() {
    dev.bnldev(1.0,36,0 ) ;
  }

  @Test
  public void test5() {
    dev.bnldev(1.0,-401,0 ) ;
  }

  @Test
  public void test6() {
    dev.bnldev(116.0,-961,0 ) ;
  }

  @Test
  public void test7() {
    dev.bnldev(140.0,-375,0 ) ;
  }

  @Test
  public void test8() {
    dev.bnldev(-151.0,10,847 ) ;
  }

  @Test
  public void test9() {
    dev.bnldev(167.0,230,0 ) ;
  }

  @Test
  public void test10() {
    dev.bnldev(-209.0,-755,0 ) ;
  }

  @Test
  public void test11() {
    dev.bnldev(-232.0,16,0 ) ;
  }

  @Test
  public void test12() {
    dev.bnldev(277.0,25,0 ) ;
  }

  @Test
  public void test13() {
    dev.bnldev(-311.0,940,0 ) ;
  }

  @Test
  public void test14() {
    dev.bnldev(334.0,15,-90 ) ;
  }

  @Test
  public void test15() {
    dev.bnldev(-50.0,426,0 ) ;
  }

  @Test
  public void test16() {
    dev.bnldev(-5.216986523242156,0,0 ) ;
  }

  @Test
  public void test17() {
    dev.bnldev(-605.0,9,-26 ) ;
  }

  @Test
  public void test18() {
    dev.bnldev(-611.0,611,0 ) ;
  }

  @Test
  public void test19() {
    dev.bnldev(625.0,19,98 ) ;
  }

  @Test
  public void test20() {
    dev.bnldev(642.0,559,0 ) ;
  }

  @Test
  public void test21() {
    dev.bnldev(6.435734146128169,0,0 ) ;
  }

  @Test
  public void test22() {
    dev.bnldev(686.0,-907,0 ) ;
  }

  @Test
  public void test23() {
    dev.bnldev(-70.96294467001267,0,0 ) ;
  }

  @Test
  public void test24() {
    dev.bnldev(-748.0,-4,0 ) ;
  }

  @Test
  public void test25() {
    dev.bnldev(-754.0,-842,0 ) ;
  }

  @Test
  public void test26() {
    dev.bnldev(778.0,956,0 ) ;
  }

  @Test
  public void test27() {
    dev.bnldev(-847.0,25,0 ) ;
  }

  @Test
  public void test28() {
    dev.bnldev(-871.0,-563,0 ) ;
  }

  @Test
  public void test29() {
    dev.bnldev(-934.0,-693,0 ) ;
  }

  @Test
  public void test30() {
    dev.bnldev(990.0,5,0 ) ;
  }
}
