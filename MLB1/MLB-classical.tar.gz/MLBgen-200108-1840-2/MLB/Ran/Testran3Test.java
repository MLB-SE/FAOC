import org.junit.Test;

public class Testran3Test {

  @Test
  public void test0() {
    ran.ran3(0 ) ;
  }

  @Test
  public void test1() {
    ran.ran3(136 ) ;
  }

  @Test
  public void test2() {
    ran.ran3(-26154 ) ;
  }

  @Test
  public void test3() {
    ran.ran3(-26221 ) ;
  }

  @Test
  public void test4() {
    ran.ran3(27227 ) ;
  }

  @Test
  public void test5() {
    ran.ran3(27281 ) ;
  }

  @Test
  public void test6() {
    ran.ran3(-3 ) ;
  }

  @Test
  public void test7() {
    ran.ran3(499 ) ;
  }

  @Test
  public void test8() {
    ran.ran3(638 ) ;
  }

  @Test
  public void test9() {
    ran.ran3(-668 ) ;
  }

  @Test
  public void test10() {
    ran.ran3(-702 ) ;
  }

  @Test
  public void test11() {
    ran.ran3(845 ) ;
  }

  @Test
  public void test12() {
    ran.ran3(-915 ) ;
  }
}
