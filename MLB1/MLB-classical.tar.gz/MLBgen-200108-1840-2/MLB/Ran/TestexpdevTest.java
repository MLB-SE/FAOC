import org.junit.Test;

public class TestexpdevTest {

  @Test
  public void test0() {
    dev.expdev(0 ) ;
  }

  @Test
  public void test1() {
    dev.expdev(-1 ) ;
  }

  @Test
  public void test2() {
    dev.expdev(-118 ) ;
  }

  @Test
  public void test3() {
    dev.expdev(-395 ) ;
  }

  @Test
  public void test4() {
    dev.expdev(-768 ) ;
  }

  @Test
  public void test5() {
    dev.expdev(827 ) ;
  }

  @Test
  public void test6() {
    dev.expdev(-832 ) ;
  }

  @Test
  public void test7() {
    dev.expdev(899 ) ;
  }
}
