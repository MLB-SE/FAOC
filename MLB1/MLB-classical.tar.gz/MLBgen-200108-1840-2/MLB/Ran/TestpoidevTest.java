import org.junit.Test;

public class TestpoidevTest {

  @Test
  public void test0() {
    dev.poidev(-1.0,0 ) ;
  }

  @Test
  public void test1() {
    dev.poidev(-1.0000000000000002,0 ) ;
  }

  @Test
  public void test2() {
    dev.poidev(-1.0,-1 ) ;
  }

  @Test
  public void test3() {
    dev.poidev(-1.0,150 ) ;
  }

  @Test
  public void test4() {
    dev.poidev(-1.0,-319 ) ;
  }

  @Test
  public void test5() {
    dev.poidev(-1.0,776 ) ;
  }

  @Test
  public void test6() {
    dev.poidev(-1.0,-808 ) ;
  }

  @Test
  public void test7() {
    dev.poidev(-14.991855606306359,0 ) ;
  }

  @Test
  public void test8() {
    dev.poidev(-1.9999999999999987,0 ) ;
  }

  @Test
  public void test9() {
    dev.poidev(2.0,844 ) ;
  }

  @Test
  public void test10() {
    dev.poidev(21.22564806994383,0 ) ;
  }

  @Test
  public void test11() {
    dev.poidev(2.9928694435868692,0 ) ;
  }

  @Test
  public void test12() {
    dev.poidev(3.0,-1 ) ;
  }

  @Test
  public void test13() {
    dev.poidev(-303.0,995 ) ;
  }

  @Test
  public void test14() {
    dev.poidev(31.17414534408664,0 ) ;
  }

  @Test
  public void test15() {
    dev.poidev(34.686201981530786,0 ) ;
  }

  @Test
  public void test16() {
    dev.poidev(4.0,817 ) ;
  }

  @Test
  public void test17() {
    dev.poidev(-423.0,384 ) ;
  }

  @Test
  public void test18() {
    dev.poidev(-44.044753490184064,0 ) ;
  }

  @Test
  public void test19() {
    dev.poidev(-483.0,0 ) ;
  }

  @Test
  public void test20() {
    dev.poidev(-49.0,-790 ) ;
  }

  @Test
  public void test21() {
    dev.poidev(-59.0,-1 ) ;
  }

  @Test
  public void test22() {
    dev.poidev(-592.0,-469 ) ;
  }

  @Test
  public void test23() {
    dev.poidev(7.0,-960 ) ;
  }

  @Test
  public void test24() {
    dev.poidev(72.95375293819237,0 ) ;
  }

  @Test
  public void test25() {
    dev.poidev(9.0,0 ) ;
  }

  @Test
  public void test26() {
    dev.poidev(9.0,-43 ) ;
  }
}
