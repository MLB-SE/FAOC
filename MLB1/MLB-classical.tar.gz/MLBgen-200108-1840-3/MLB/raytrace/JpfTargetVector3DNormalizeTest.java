import org.junit.Test;

public class JpfTargetVector3DNormalizeTest {

  @Test
  public void test0() {
    TestDrivers.vector3DNormalize(0.089130834f,0.09676218f,0.9911457f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.vector3DNormalize(0.15810265f,-0.908957f,-0.38574696f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.vector3DNormalize(0.1585069f,0.1962227f,0.9676633f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.vector3DNormalize(-0.5348156f,0.34250903f,0.5457146f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.vector3DNormalize(1.7288793E-4f,-1.4482754E-4f,-3.849468E-4f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.vector3DNormalize(40.28109f,-22.231497f,85.833565f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.vector3DNormalize(-5.730657E-9f,2.2380215E-8f,1.3712962E-8f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.vector3DNormalize(-71.7495f,-55.711033f,-71.99919f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.vector3DNormalize(75.10833f,44.0117f,-65.03892f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.vector3DNormalize(8.638442E-5f,-7.0416264E-4f,1.6626065E-4f ) ;
  }
}
