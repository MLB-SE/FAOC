import org.junit.Test;

public class JpfTargetSphereIntersectTest {

  @Test
  public void test0() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.39753777f,-49.778366f,6.0653257f,60.73393f,80.444756f,-87.70827f,-43.65969f,20.420492f,-11.862722f,0.87621135f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.041042656f,0.26596296f,-0.25607055f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.13435835f,-0.67579687f,0.45882246f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.14510868f,-55.577396f,56.805244f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.67614925f,0.28129712f,-0.6809509f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.8236629f,0.5448209f,-0.15732014f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1.8390694E-5f,-2.4272181E-4f,-6.794742E-4f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2.9414275E-4f,-5.5585744E-5f,-1.9303242E-4f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,60.406124f,91.28852f,72.24019f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,63.86586f,-16.882624f,-95.24375f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-9.514097E-10f,-3.817722E-10f,-9.209364E-10f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,100.0f,100.0f,0.0f,-100.0f,100.0f,100.0f,-100.0f,-100.0f,-100.0f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,100.0f,-34.410896f,100.0f,-61.79999f,49.079517f,100.0f,-0.3223575f,0.0864328f,-0.30965394f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,99.999306f,35.690605f,76.29901f,-99.88172f,57.641518f,100.0f,2.2066576f,-5.103239f,-2.3860233f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,11.876138f,5.139439f,-49.56331f,67.76305f,-54.799427f,-5.680965f,-54.959496f,-15.71988f,96.94015f,1.2389517f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-13.6702795f,99.95973f,-48.938923f,74.63289f,52.295586f,65.16068f,-46.18206f,-63.95555f,33.686832f,-3.1418557f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-13.924323f,-47.72958f,59.855206f,62.669178f,-26.232487f,14.635615f,88.45148f,0.4681279f,-0.6134626f,0.1864565f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-14.250717f,-26.167376f,45.883194f,96.6668f,100.0f,29.272167f,79.61402f,-0.03696887f,0.09164985f,0.007874384f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-14.280509f,29.193918f,-16.417418f,88.00132f,51.95492f,19.455782f,-77.75915f,32.43591f,39.793686f,74.779434f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-14.781764f,5.269445f,54.60327f,-59.474327f,8.813739f,-23.477375f,-0.17577517f,-8.405248f,-66.0131f,-94.1851f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-16.399786f,101.34705f,-29.174528f,40.438915f,-63.50406f,82.63615f,-55.592136f,31.930952f,71.64759f,146.70648f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-19.302082f,49.73898f,83.620514f,-3.7247636f,-26.386053f,49.816753f,82.59097f,-41.82816f,-64.65955f,3.9459562f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-21.095177f,-33.535442f,-56.580482f,73.73378f,34.371067f,-80.33146f,-69.63034f,0.10010701f,0.72564864f,-0.4207211f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,24.393103f,-32.18762f,-3.2879035f,39.90205f,-45.972675f,11.485498f,100.0f,0.6629374f,0.3201868f,-0.014716376f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-24.526356f,-3.191192f,100.0f,48.55482f,12.968775f,23.358929f,84.29321f,103.03853f,-91.8022f,99.95863f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-32.40836f,8.060611f,31.53069f,65.22456f,-69.12624f,-9.695077f,14.451958f,-33.21928f,-47.187412f,88.81786f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,34.072765f,70.549385f,-76.169556f,-78.20114f,21.211693f,-51.62158f,35.331738f,-12.21856f,-30.539358f,86.20461f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,3.5658317f,19.294918f,-98.59778f,70.2648f,-28.33447f,66.67477f,-57.675133f,-0.17027861f,0.30533147f,-1.0723971f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,38.888405f,56.000805f,73.23788f,91.664375f,-0.17825924f,-28.568602f,16.005377f,-71.69291f,-11.234676f,-14.510613f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,40.350773f,7.327904f,-45.634277f,81.57991f,61.44322f,43.831596f,-47.333504f,-0.13346913f,-0.0032195845f,0.28051558f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,40.82487f,-8.284303f,21.285707f,84.39612f,2.0344856f,62.400154f,-3.648578f,-5.116643f,-89.725655f,1.3642408f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,42.66951f,32.344456f,-18.448679f,-3.259461f,18.765245f,-25.767647f,-44.78393f,38.84799f,-39.552223f,43.308f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,44.99831f,-82.11397f,-69.88419f,95.361824f,-34.052124f,-84.64977f,-16.606844f,72.06027f,95.74661f,51.17974f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-45.971786f,19.163876f,-1.4283297f,-38.266026f,26.941896f,76.01f,-18.409283f,32.717587f,-19.074968f,-21.421429f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-49.056854f,-24.923958f,22.64544f,75.08095f,-98.85189f,52.173218f,60.48145f,-83.501335f,-99.17369f,64.175026f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,5.118619f,-4.6613917f,11.709517f,95.47725f,-57.019485f,23.097006f,-55.254894f,-6.3921065f,-59.43453f,-8.370291f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-51.24317f,-66.270035f,10.070809f,-100.0f,-96.74454f,30.809849f,-84.4619f,-0.36041448f,0.22912063f,-0.23487142f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-51.26889f,-41.22087f,-30.12433f,37.83295f,-59.78314f,-24.441643f,2.6978729f,33.242046f,-55.565475f,-100.0f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-58.617107f,-11.096515f,-100.0f,84.15528f,13.717979f,-49.098354f,-79.86034f,-0.13346039f,1.206514f,-0.120070465f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-61.61951f,-87.834145f,74.03682f,97.010826f,33.642365f,-91.441154f,92.01639f,-55.787296f,2.1495667f,-10.791081f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-67.938835f,-37.04005f,38.50836f,30.29509f,-42.836006f,-96.44529f,73.68377f,83.006226f,-89.91859f,27.557974f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-7.007218f,-78.27408f,-15.983466f,40.086994f,-8.633691f,-73.52953f,23.78852f,-61.653534f,100.0f,-100.0f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-71.35306f,-92.527435f,-47.57396f,57.393085f,-14.801028f,-94.35191f,-57.186398f,-28.486948f,-158.87541f,-117.19781f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,74.26776f,31.335508f,85.98305f,23.252699f,72.732056f,54.509876f,87.11367f,-100.054276f,-31.65094f,-78.025696f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,8.21516f,81.22993f,-90.617455f,11.854049f,22.141275f,80.558586f,-87.04579f,-70.005806f,-44.118668f,-13.719791f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-82.16162f,-96.76342f,4.897888f,56.295345f,-100.0f,-59.909702f,40.020363f,-0.07623699f,-0.099211864f,-0.13376589f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,85.49144f,99.64945f,12.785071f,-91.62686f,13.1841755f,77.20794f,-38.793053f,-4.378984f,11.107478f,14.117024f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,88.40816f,100.0f,-15.719213f,-29.705326f,-41.24658f,100.0f,15.751423f,-1.9965432f,1.839549f,-3.8097944f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-9.466607f,37.897655f,85.66124f,-24.909307f,-22.698492f,81.87419f,-3.2316206f,-57.496296f,21.803984f,-11.757902f ) ;
  }
}
