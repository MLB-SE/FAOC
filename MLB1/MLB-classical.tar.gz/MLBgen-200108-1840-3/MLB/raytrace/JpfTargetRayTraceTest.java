import org.junit.Test;

public class JpfTargetRayTraceTest {

  @Test
  public void test0() {
    TestDrivers.rayTrace(-0.23016521f,35.977642f,-99.76372f,-100.0f,-10.923945f,82.92532f,59.043488f,0.5923433f,-0.23425657f,0.74146026f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-0.13151525f,-0.95980316f,-0.11251786f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,0.18501359f,0.20416924f,-0.15062028f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-0.832194f,-0.48820606f,-0.262884f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,0.97227496f,0.12982397f,0.1944919f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,1.890879E-9f,-6.627619E-10f,1.8152765E-9f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-29.762371f,-71.76138f,34.34953f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-33.483505f,43.86317f,-46.709656f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-3.8557386E-4f,-6.2478194E-4f,5.917239E-4f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-70.42011f,40.90444f,18.58112f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-9.3825714E-4f,-2.7058844E-4f,-0.0043739183f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.rayTrace(-100.0f,100.0f,-4.1145754f,31.955647f,-67.33192f,99.99308f,83.54796f,-0.6324543f,0.10612011f,-0.76729405f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.rayTrace(-100.0f,-100.0f,84.6364f,60.167137f,92.17671f,-0.62895256f,-14.234363f,-0.58975196f,-0.43532032f,-0.42026284f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.rayTrace(-100.0f,100.0f,99.98598f,100.0f,13.502004f,-99.63327f,-25.795897f,0.49314743f,-0.65925467f,-0.5676169f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.rayTrace(-100.0f,39.926964f,-100.0f,-100.0f,-100.0f,100.0f,99.99994f,-0.13086262f,0.2737083f,0.9528687f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.rayTrace(-100.0f,-99.10883f,100.0f,-100.0f,-100.0f,-100.0f,-100.0f,-0.69802904f,-0.61101353f,0.37338704f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.rayTrace(100.0f,99.97631f,-96.98895f,99.244995f,100.0f,-83.303474f,-87.558014f,0.10686042f,0.9947617f,-0.011266766f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.rayTrace(14.993108f,93.58925f,41.250145f,100.0f,100.0f,100.0f,76.50489f,0.6806771f,-0.5677021f,0.4630259f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.rayTrace(-1.7871002f,13.157074f,44.652996f,-59.412056f,32.60813f,-66.76842f,-59.653477f,-87.79676f,-98.78536f,65.55887f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.rayTrace(19.797194f,-78.07466f,16.490105f,55.52643f,58.5664f,68.002235f,-50.368416f,20.225159f,96.831894f,-65.27455f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.rayTrace(22.765934f,-16.931997f,-23.05581f,63.732113f,19.408258f,-20.025497f,36.574356f,0.5895829f,-0.6459014f,-0.43077132f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.rayTrace(25.077072f,-99.99999f,-66.20481f,-100.0f,27.540234f,-99.456276f,-100.0f,-0.029227715f,0.8685613f,0.49471903f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.rayTrace(27.628157f,-83.10916f,-100.0f,-52.122128f,55.905983f,42.986988f,100.0f,0.29392645f,-0.9069762f,0.30166438f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.rayTrace(28.27944f,100.0f,-100.0f,-3.212871f,12.061409f,22.3851f,96.00738f,0.1173365f,-0.05035148f,-0.84140956f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.rayTrace(-31.369469f,28.222265f,23.812227f,-73.38008f,23.638948f,64.784256f,55.77988f,-0.13804376f,-0.65761566f,0.20373897f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.rayTrace(34.33819f,-100.0f,-100.0f,97.93651f,-81.18267f,-85.19972f,13.368156f,-0.31657085f,0.35899994f,0.5991149f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.rayTrace(34.72187f,-60.343708f,-9.081652f,-75.95874f,43.244766f,-30.81104f,-44.874676f,-0.008265668f,0.17596294f,-0.8372208f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.rayTrace(39.32405f,38.723225f,-7.989608f,-94.322075f,-28.518864f,-5.0152674f,40.99156f,-0.30633745f,-0.015514748f,0.5505385f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.rayTrace(41.90014f,-27.459944f,-100.0f,-24.860163f,100.0f,100.0f,100.0f,0.87001777f,-1.0797008E-4f,0.4930204f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.rayTrace(46.088272f,36.31073f,100.0f,100.0f,3.4004586f,24.190313f,10.385012f,100.0f,100.0f,-0.50182796f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.rayTrace(46.20001f,9.502082f,-69.67717f,-100.0f,-49.099133f,-58.59942f,-5.888894f,0.113922f,0.42171592f,-0.6011854f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.rayTrace(46.280174f,87.83184f,-65.39985f,-88.731514f,-11.760416f,-56.53159f,-52.42546f,56.88809f,66.68989f,-16.902096f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.rayTrace(51.841396f,23.882145f,16.762793f,87.3327f,95.53167f,-2.758237f,56.004745f,-85.416695f,-17.269545f,-61.56807f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.rayTrace(-52.67796f,-100.0f,-100.0f,-100.0f,100.0f,-100.0f,-100.0f,0.9956572f,0.071271546f,0.0598927f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.rayTrace(55.45042f,-1.2550185f,71.27322f,18.633818f,43.353313f,-60.724995f,-91.01784f,58.66059f,-80.44183f,52.73205f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.rayTrace(59.17813f,-44.464073f,17.03289f,-10.536859f,-51.309513f,25.364042f,2.2176683f,81.0005f,71.5607f,-86.625534f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.rayTrace(-66.51448f,-33.51696f,-50.070885f,-40.05746f,-85.17619f,4.1068544f,-35.458466f,93.10655f,3.8634279f,-15.951318f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.rayTrace(-78.96724f,100.0f,36.35407f,100.0f,0.7453225f,56.721577f,-100.0f,0.17082497f,-0.48043066f,-0.6654646f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.rayTrace(-80.47745f,79.36718f,30.94481f,-46.674232f,-82.585266f,38.610313f,8.950166f,-88.59194f,83.07727f,-71.553635f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.rayTrace(-82.44597f,-15.122005f,98.90981f,38.10321f,-67.25459f,-50.187202f,97.00317f,-3.3882034f,-1.8591042f,-0.08841537f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.rayTrace(83.31003f,-54.77052f,-95.70483f,53.976227f,39.48348f,-79.374115f,-51.231705f,7.873864f,-36.20746f,39.206097f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.rayTrace(-86.450905f,-14.808122f,-90.87826f,80.10525f,-6.010574f,40.179688f,-39.262028f,83.171005f,91.902565f,-6.7044234f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.rayTrace(-91.90773f,-7.232285f,99.934494f,100.0f,-22.455416f,25.230669f,35.72755f,-0.033567373f,-0.98047876f,0.19373865f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.rayTrace(-92.323044f,10.824787f,-46.397453f,-146.75671f,-11.548059f,-13.1929f,40.575626f,-0.39760843f,0.48307356f,-0.08765315f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.rayTrace(-96.23452f,-51.383003f,17.119877f,-80.49436f,83.379234f,7.5928564f,58.315098f,58.134624f,33.907352f,89.89024f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.rayTrace(-97.506584f,-91.16149f,100.0f,-52.26938f,39.26846f,-100.0f,100.0f,-0.718341f,0.16069756f,-0.676877f ) ;
  }
}
