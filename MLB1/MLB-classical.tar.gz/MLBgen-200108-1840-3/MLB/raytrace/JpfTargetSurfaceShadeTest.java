import org.junit.Test;

public class JpfTargetSurfaceShadeTest {

  @Test
  public void test0() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,7.743199f,-31.948717f,0f,0f,0f,1525,0.34154287f,0.60516596f,0.12668918f,0f,0f,0f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,25.53552f,65.98005f,89.61203f,0f,0f,0f,-865,80.0259f,24.019114f,-41.246708f,0f,0f,0f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.33086178f,0.9197429f,0.1178382f,0f,0f,0f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0.09730505f,1.1590774f,-0.40139347f,0f,0f,0f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,100.0f,71.94095f,0f,0f,0f,-3076,0.07119622f,0.6185711f,-0.7824966f,0f,0f,0f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,10.956042f,-100.0f,-18.227182f,0f,0f,0f,142,-5.8157344f,100.0f,-7.4202657f,0f,0f,0f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-77.33572f,-19.35506f,22.270565f,0f,0f,0f,-1074,0.39907125f,0.3968365f,0.82042545f,0f,0f,0f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-1.0167196f,0.03402049f,-0.35135093f,0f,0f,0f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,3.864424E-32f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,1.2222521f,-0.738113f,1.088678f,0f,0f,0f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,-51.644135f,0f,0f,0f,0f,0f,5.1311626f,-2.596211f,5.81819f,0f,0f,0f,22,-31.941082f,44.2276f,29.1648f,0f,0f,0f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,58.286f,0f,0f,0f,0f,0f,-27.085182f,9.923074f,92.47429f,0f,0f,0f,-566,41.394188f,-2.6388426f,-60.34384f,0f,0f,0f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,68.64641f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,4,5.3192744f,-1.4315834f,2.4705749f,0f,0f,0f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,-73.95047f,0f,0f,0f,0f,0f,43.42136f,5.1948957f,-11.821416f,0f,0f,0f,-1223,0.15825495f,-0.29566392f,0.8767234f,0f,0f,0f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,8.910123f,0f,0f,0f,0f,0f,82.08294f,60.47581f,26.860807f,0f,0f,0f,99,-0.6455719f,-0.38873217f,0.4852568f,0f,0f,0f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.48501313f,0.8190456f,0.011698635f,0f,0f,0f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.69992f,0.00385213f,-0.6103014f,0f,0f,0f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,-100.0f,0f,0f,0f,1,0.20116553f,0.78365004f,-0.58772874f,0f,0f,0f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,26.351389f,10.242518f,26.765753f,0f,0f,0f,383,-35.092968f,19.585943f,20.366558f,0f,0f,0f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,92.073784f,79.63054f,-54.46976f,0f,0f,0f,1,-0.042953186f,-0.056870725f,0.002260601f,0f,0f,0f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,-95.610825f,63.507927f,63.117207f,0f,0f,0f,1132,-0.219711f,-0.8861659f,-0.0910875f,0f,0f,0f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,99.95376f,-1.1992649f,-36.685577f,0f,0f,0f,2678,-0.51025593f,-0.8592895f,0.035502426f,0f,0f,0f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0.050900277f,-0.06790129f,0.25197425f,0f,0f,0f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,-1.0009062f,31.7489f,-3.0364487f,452.0f,940.0f,-178.0f,-1557,-0.9073008f,0.024532612f,0.5603821f,0f,0f,0f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-100.0f,35.52999f,2857.0f,-1139.0f,447.0f,988,0.24479033f,0.8758515f,0.41588676f,0f,0f,0f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,100.0f,31.911005f,100.0f,0f,0f,0f,-245,-0.026534688f,-0.6911104f,-0.72226197f,0f,0f,0f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-40.147633f,-46.34808f,-587.0f,308.0f,1789.0f,210,0.6803423f,-0.3703187f,-0.6324542f,0f,0f,0f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,-14.440416f,-21.386385f,-36.66563f,-1093.0f,250.0f,458.0f,10,-0.90157056f,-0.74835753f,0.60759145f,0f,0f,0f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,-27.037312f,73.01945f,72.554016f,254.0f,-1418.0f,-216.0f,-2,0.49835837f,0.01597682f,-0.056797635f,0f,0f,0f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,46.649345f,-72.0317f,100.0f,0f,0f,0f,-748,100.0f,34.337395f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,60.87203f,27.814383f,12.551757f,1170.0f,-1011.0f,1851.0f,724,-0.15921605f,-0.3090071f,-0.048564162f,0f,0f,0f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,-88.66393f,98.87632f,99.99997f,-100.0f,2177.0f,755.0f,-471,0.6732335f,0.39699268f,-0.12937294f,0f,0f,0f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-100.0f,0f,100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,3,0.049230985f,-0.36242872f,-0.9402712f,0f,0f,0f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-100.0f,0f,83.54286f,0f,0f,0f,0f,0f,-57.971634f,-93.86673f,-54.55835f,0f,0f,0f,-864,-0.19238895f,-0.18012637f,0.732691f,0f,0f,0f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,1.0f,0f,2699.0f,0f,0f,0f,0f,0f,-3589.0f,-135.0f,-283.0f,-1139.0f,-375.0f,433.0f,1747,0.5790857f,-0.35169715f,0.41589057f,0f,0f,0f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,11.512459f,0f,0f,0f,0f,0f,0f,0f,42.743103f,24.396702f,-24.493843f,483.0f,436.0f,1273.0f,-2478,-0.6359972f,-0.44188488f,-0.4014599f,0f,0f,0f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-1204.0f,0f,715.0f,0f,0f,0f,0f,0f,286.0f,457.0f,-169.0f,-459.0f,120.0f,676.0f,223,86.10996f,-80.52391f,-68.08817f,0f,0f,0f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-12.310881f,0f,0f,0f,0f,0f,0f,0f,-115.83738f,-19.68441f,-77.40846f,-317.0f,-365.0f,1460.0f,-1,-0.88640887f,-0.29732406f,0.004365002f,0f,0f,0f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,13.304221f,0f,0f,0f,0f,0f,0f,0f,5.240056f,2.6746943f,13.521904f,-817.0f,51.0f,305.0f,12,-1.8787252f,-3.3969443f,0.89150256f,0f,0f,0f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-1.5786422f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0.5025169f,-0.14683394f,-0.5315153f,0f,0f,0f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-182.0f,0f,85.0f,0f,0f,0f,0f,0f,201.0f,-332.0f,128.0f,-540.0f,-464.0f,300.0f,708,49.148754f,61.14977f,-89.801544f,0f,0f,0f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-19.077015f,0f,15.516816f,0f,0f,0f,0f,0f,-94.61866f,-85.52791f,-92.02277f,0f,0f,0f,743,36.640594f,-46.96815f,29.528055f,0f,0f,0f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-1935.0f,0f,192.0f,0f,0f,0f,0f,0f,-374.0f,-157.0f,-140.0f,517.0f,187.0f,-1591.0f,2305,68.29636f,56.166077f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,20.108587f,0f,0f,0f,0f,0f,0f,0f,2.8916767f,-4.3493147f,13.468283f,-466.0f,-145.0f,715.0f,573,39.463676f,20.551075f,-12.159823f,0f,0f,0f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-20.550207f,0f,0f,0f,0f,0f,0f,0f,-100.0f,31.861921f,9.94532f,-1125.0f,-713.0f,-505.0f,4,0.49703848f,-0.053011343f,-0.43811193f,0f,0f,0f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,211.0f,0f,779.0f,0f,0f,0f,0f,0f,901.0f,977.0f,400.0f,-946.0f,-373.0f,509.0f,-407,29.412397f,-61.627563f,45.745842f,0f,0f,0f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,21.486963f,0f,0f,0f,0f,0f,0f,0f,30.430222f,14.0077715f,-16.5431f,650.0f,-926.0f,412.0f,-1571,0.057342943f,-0.04746682f,0.475632f,0f,0f,0f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-221.0f,0f,1428.0f,0f,0f,0f,0f,0f,-1192.0f,997.0f,-922.0f,411.0f,-914.0f,-662.0f,-657,0.008451163f,-0.8296864f,-0.106520556f,0f,0f,0f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,29.081657f,0f,0f,0f,0f,0f,0f,0f,-9.386543f,100.0f,-57.05277f,18.0f,1649.0f,982.0f,849,-0.4543958f,-0.3960081f,-0.59749514f,0f,0f,0f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-294.0f,0f,1142.0f,0f,0f,0f,0f,0f,-1606.0f,-840.0f,77.0f,-709.0f,380.0f,263.0f,2514,0.27714416f,0.021330733f,-0.73368114f,0f,0f,0f ) ;
  }

  @Test
  public void test49() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-30.294956f,0f,-100.0f,0f,0f,0f,0f,0f,100.0f,-100.0f,70.58697f,0f,0f,0f,-198,-0.14494283f,0.5907717f,-0.47063002f,0f,0f,0f ) ;
  }

  @Test
  public void test50() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-3.0f,0f,1773.0f,0f,0f,0f,0f,0f,396.0f,-487.0f,-430.0f,412.0f,-233.0f,648.0f,-640,-23.808868f,82.4815f,-3.1408958f,0f,0f,0f ) ;
  }

  @Test
  public void test51() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,32.0f,0f,-1151.0f,0f,0f,0f,0f,0f,295.0f,302.0f,-487.0f,-442.0f,-626.0f,419.0f,392,-92.949104f,21.264526f,15.674662f,0f,0f,0f ) ;
  }

  @Test
  public void test52() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,322.0f,0f,-69.0f,0f,0f,0f,0f,0f,127.0f,-880.0f,2039.0f,-737.0f,-313.0f,950.0f,647,-75.20875f,100.0f,-14.846403f,0f,0f,0f ) ;
  }

  @Test
  public void test53() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,3231.0f,0f,-1.0f,0f,0f,0f,0f,0f,1233.0f,-890.0f,-822.0f,-566.0f,822.0f,247.0f,-440,0.8898819f,1.3065559f,-0.07981795f,0f,0f,0f ) ;
  }

  @Test
  public void test54() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-34.595093f,0f,0.0f,0f,0f,0f,0f,0f,-0.06601714f,64.74562f,-64.36106f,0f,0f,0f,-957,-77.32708f,-88.22916f,99.58764f,0f,0f,0f ) ;
  }

  @Test
  public void test55() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-36.860054f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.023714606f,-0.24670549f,-0.12038427f,0f,0f,0f ) ;
  }

  @Test
  public void test56() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-37.39583f,0f,0f,0f,0f,0f,0f,0f,-20.321392f,-1.711602f,-34.89401f,482.0f,558.0f,-298.0f,729,-0.69293493f,-0.2559844f,0.67402756f,0f,0f,0f ) ;
  }

  @Test
  public void test57() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,37.955826f,0f,0f,0f,0f,0f,0f,0f,61.845737f,-70.57367f,61.889545f,1348.0f,-238.0f,435.0f,308,-0.49609107f,0.78470623f,0.3640713f,0f,0f,0f ) ;
  }

  @Test
  public void test58() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,386.0f,0f,-4.0f,0f,0f,0f,0f,0f,-342.0f,-325.0f,278.0f,-617.0f,-992.0f,699.0f,124,-4.1654477f,82.66571f,27.105179f,0f,0f,0f ) ;
  }

  @Test
  public void test59() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,40.2547f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.802243f,-0.34241506f,0.2804178f,0f,0f,0f ) ;
  }

  @Test
  public void test60() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,416.0f,0f,-1439.0f,0f,0f,0f,0f,0f,-1835.0f,-54.0f,-910.0f,281.0f,-159.0f,354.0f,268,0.6788214f,0.11596199f,-0.02149335f,0f,0f,0f ) ;
  }

  @Test
  public void test61() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-42.244034f,0f,0f,0f,0f,0f,0f,0f,-18.880846f,3.023422f,-20.090998f,338.0f,290.0f,-274.0f,-10,-2.096331f,-7.270478f,3.0130484f,0f,0f,0f ) ;
  }

  @Test
  public void test62() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,43.81472f,0f,0f,0f,0f,0f,0f,0f,-16.989855f,91.80563f,-64.72824f,0f,0f,0f,1348,0.16835828f,0.09217581f,0.62303144f,0f,0f,0f ) ;
  }

  @Test
  public void test63() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,44.37343f,0f,0f,0f,0f,0f,0f,0f,68.3621f,100.0f,100.0f,608.0f,1714.0f,-1323.0f,900,0.79331464f,0.0621089f,-0.6056355f,0f,0f,0f ) ;
  }

  @Test
  public void test64() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-45.41093f,0f,-29.249733f,0f,0f,0f,0f,0f,-100.0f,-62.55254f,-75.51183f,0f,0f,0f,164,-0.17673859f,-0.37876844f,0.9084591f,0f,0f,0f ) ;
  }

  @Test
  public void test65() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-4.654533f,0f,0f,0f,0f,0f,0f,0f,-39.615437f,0.52811015f,49.824635f,973.0f,-601.0f,780.0f,-462,-0.2280736f,0.9085285f,-0.2702485f,0f,0f,0f ) ;
  }

  @Test
  public void test66() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-466.0f,0f,728.0f,0f,0f,0f,0f,0f,106.0f,-136.0f,-159.0f,-221.0f,1426.0f,94.0f,118,-5.7651963f,31.905987f,29.629852f,0f,0f,0f ) ;
  }

  @Test
  public void test67() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-47.01227f,0f,100.0f,0f,0f,0f,0f,0f,-94.922585f,-64.4076f,-16.057486f,0f,0f,0f,-129,0.4301446f,-0.3549421f,0.83005524f,0f,0f,0f ) ;
  }

  @Test
  public void test68() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-4.7356954f,0f,-37.88796f,0f,0f,0f,0f,0f,20.298092f,-45.015087f,6.955415f,0f,0f,0f,-1407,-6.289864f,23.988297f,11.945755f,0f,0f,0f ) ;
  }

  @Test
  public void test69() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,4.7653003f,0f,0f,0f,0f,0f,0f,0f,13.104294f,2.1147273f,35.27707f,1846.0f,-2401.0f,-541.0f,-1532,0.48063028f,0.42410976f,-0.20979448f,0f,0f,0f ) ;
  }

  @Test
  public void test70() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,4.952852f,0f,0f,0f,0f,0f,0f,0f,-27.106037f,33.239155f,-85.79095f,868.0f,-740.0f,602.0f,-716,77.68292f,73.56164f,3.957611f,0f,0f,0f ) ;
  }

  @Test
  public void test71() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,50.805645f,0f,0f,0f,0f,0f,0f,0f,-100.0f,100.0f,-92.13749f,0f,0f,0f,1,-0.3743416f,-0.89863354f,-0.22874908f,0f,0f,0f ) ;
  }

  @Test
  public void test72() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,51.463867f,0f,0f,0f,0f,0f,0f,0f,21.6128f,-21.901922f,-16.41248f,741.0f,760.0f,-39.0f,-1140,-0.37633318f,0.0099020675f,0.3915851f,0f,0f,0f ) ;
  }

  @Test
  public void test73() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,54.68511f,0f,0f,0f,0f,0f,0f,0f,48.916718f,-34.590454f,-11.892597f,-804.0f,-590.0f,-1591.0f,-562,-0.34714058f,-0.055545937f,-0.12918386f,0f,0f,0f ) ;
  }

  @Test
  public void test74() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,559.0f,0f,1261.0f,0f,0f,0f,0f,0f,-818.0f,-905.0f,-266.0f,-1446.0f,-503.0f,-57.0f,1308,0.47462726f,-0.17331699f,0.20950647f,0f,0f,0f ) ;
  }

  @Test
  public void test75() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-58.583828f,0f,0f,0f,0f,0f,0f,0f,61.09159f,8.722935f,34.177944f,0f,0f,0f,246,-0.18849581f,0.93959755f,-0.28570217f,0f,0f,0f ) ;
  }

  @Test
  public void test76() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-59.949593f,0f,0.0f,0f,0f,0f,0f,0f,63.64066f,-13.647091f,50.11765f,0f,0f,0f,565,-0.4255361f,0.2736892f,0.37927523f,0f,0f,0f ) ;
  }

  @Test
  public void test77() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-62.373158f,0f,0f,0f,0f,0f,0f,0f,68.189064f,-68.16749f,0.86749744f,0f,0f,0f,-675,-0.3467346f,-0.22592665f,-0.08816479f,0f,0f,0f ) ;
  }

  @Test
  public void test78() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-64.0f,0f,383.0f,0f,0f,0f,0f,0f,-854.0f,-258.0f,-1035.0f,606.0f,-493.0f,-482.0f,-351,-47.052902f,-35.063534f,59.188988f,0f,0f,0f ) ;
  }

  @Test
  public void test79() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-64.682f,0f,-16.834051f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,-1.7458025f,3.215433f,0.6703156f,0f,0f,0f ) ;
  }

  @Test
  public void test80() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,65.19797f,0f,0f,0f,0f,0f,0f,0f,99.78068f,94.61186f,100.0f,-459.0f,350.0f,-1311.0f,-171,-0.96904665f,0.102323696f,0.03774972f,0f,0f,0f ) ;
  }

  @Test
  public void test81() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-675.0f,0f,257.0f,0f,0f,0f,0f,0f,393.0f,752.0f,1743.0f,-1102.0f,388.0f,-866.0f,-635,93.54393f,-53.604034f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test82() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-72.67142f,0f,-19.221489f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.92113835f,-0.09589053f,2.2088637f,0f,0f,0f ) ;
  }

  @Test
  public void test83() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-733.0f,0f,236.0f,0f,0f,0f,0f,0f,-986.0f,952.0f,846.0f,-969.0f,415.0f,798.0f,861,68.1272f,71.28122f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test84() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-770.0f,0f,546.0f,0f,0f,0f,0f,0f,684.0f,-387.0f,-764.0f,-332.0f,373.0f,-488.0f,652,-170.34149f,-100.0f,-50.82434f,0f,0f,0f ) ;
  }

  @Test
  public void test85() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,77.03466f,0f,0f,0f,0f,0f,0f,0f,-67.06636f,17.619892f,-33.726585f,-846.0f,183.0f,673.0f,834,0.17079042f,-0.44590557f,-0.56807333f,0f,0f,0f ) ;
  }

  @Test
  public void test86() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-82.97012f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.2983834f,-0.25998402f,-0.029941669f,0f,0f,0f ) ;
  }

  @Test
  public void test87() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-84.8778f,0f,0.0f,0f,0f,0f,0f,0f,46.16675f,-99.565094f,-23.824265f,0f,0f,0f,-696,0.37671894f,0.28805918f,0.88040036f,0f,0f,0f ) ;
  }

  @Test
  public void test88() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,8.60311f,0f,0f,0f,0f,0f,0f,0f,40.22437f,-100.0f,-40.47383f,1352.0f,245.0f,934.0f,384,0.91674566f,-0.23448713f,1.4944715f,0f,0f,0f ) ;
  }

  @Test
  public void test89() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,89.75348f,0f,0f,0f,0f,0f,0f,0f,-42.27928f,10.781485f,-100.0f,-513.0f,-705.0f,238.0f,-455,-70.74475f,100.0f,42.140892f,0f,0f,0f ) ;
  }

  @Test
  public void test90() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-921.0f,0f,255.0f,0f,0f,0f,0f,0f,70.0f,-1673.0f,-2049.0f,-1316.0f,-643.0f,237.0f,-879,71.46795f,154.19678f,184.58766f,0f,0f,0f ) ;
  }

  @Test
  public void test91() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-92.14828f,0f,0f,0f,0f,0f,0f,0f,100.0f,-93.860115f,100.0f,0f,0f,0f,2,-0.007403734f,-0.30824336f,-0.95127875f,0f,0f,0f ) ;
  }

  @Test
  public void test92() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-96.592834f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.079790495f,0.0633849f,1.1539842f,0f,0f,0f ) ;
  }

  @Test
  public void test93() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,97.73862f,0f,0f,0f,0f,0f,0f,0f,-20.64415f,78.76374f,-39.709682f,0f,0f,0f,-891,-34.041603f,-53.211067f,-87.73473f,0f,0f,0f ) ;
  }

  @Test
  public void test94() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-98.065155f,0f,173.86748f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.025425429f,0.5226135f,0.8380987f,0f,0f,0f ) ;
  }

  @Test
  public void test95() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,988.0f,788.0f,-643.0f,0f,0f,0f,0f,0f,-2525.0f,-707.0f,-1438.0f,949.0f,198.0f,-2048.0f,876,0.13586308f,-0.11204669f,-0.010814651f,-16.038155f,0f,0f ) ;
  }

  @Test
  public void test96() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,99.98217f,0f,0f,0f,0f,0f,0f,0f,-32.555378f,-16.93151f,-6.529277f,149.0f,-207.0f,-555.0f,-402,-0.18150096f,0.39644486f,-0.121675275f,0f,0f,0f ) ;
  }

  @Test
  public void test97() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.25315124f,22.605196f,0f,0f,0f,0f,0f,0f,0f,45.22031f,99.99998f,73.81988f,0f,0f,0f,-797,-0.32236606f,-0.81816953f,0.47610793f,0f,0f,0f ) ;
  }

  @Test
  public void test98() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,52.15554f,38.244587f,-95.33692f,0f,0f,0f,1,-0.47406763f,-0.4031118f,-0.18586957f,0f,0f,0f ) ;
  }

  @Test
  public void test99() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test100() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-85.06001f,100.0f,60.76758f,0f,0f,0f ) ;
  }

  @Test
  public void test101() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,25.146502f,0f,0f,0f,-357,-0.007838622f,-0.44438905f,0.89579964f,0f,0f,0f ) ;
  }

  @Test
  public void test102() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,10.233754f,-37.472767f,31.05413f,0f,0f,0f,517,57.264736f,-59.720783f,-29.344454f,0f,0f,0f ) ;
  }

  @Test
  public void test103() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-12.070699f,100.0f,80.4837f,0f,0f,0f,2,0.13356948f,-0.5274147f,0.20984851f,0f,0f,0f ) ;
  }

  @Test
  public void test104() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-83.9679f,99.97064f,-47.60449f,0f,0f,0f,846,-0.25551832f,2.1226516f,4.908323f,0f,0f,0f ) ;
  }

  @Test
  public void test105() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-87.1786f,-100.0f,100.0f,0f,0f,0f,1629,-0.8428887f,0.08960636f,-0.29218134f,0f,0f,0f ) ;
  }

  @Test
  public void test106() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-95.35124f,71.8689f,-18.026335f,0f,0f,0f,1,-0.62904197f,0.6207585f,0.28566188f,0f,0f,0f ) ;
  }

  @Test
  public void test107() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-97.74751f,-27.317707f,65.26202f,0f,0f,0f,920,76.81165f,-35.945404f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test108() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.5959434f,0f,0f,0f,0f,0f,-25.128672f,65.91584f,-50.23776f,948.0f,-1066.0f,-856.0f,3,-0.6944325f,0.04731197f,5.061242f,0f,0f,0f ) ;
  }

  @Test
  public void test109() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test110() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.001386862f,-0.9910236f,-0.13367993f,0f,0f,0f ) ;
  }

  @Test
  public void test111() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.0019256287f,1.4638609E-5f,0.0036205028f,0f,0f,0f ) ;
  }

  @Test
  public void test112() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.025106234f,0.33940455f,0.9403054f,0f,0f,0f ) ;
  }

  @Test
  public void test113() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.040674366f,-0.31974724f,-0.6338889f,0f,0f,0f ) ;
  }

  @Test
  public void test114() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.044209063f,-0.6655559f,0.21229911f,0f,0f,0f ) ;
  }

  @Test
  public void test115() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.06666652f,0.08414296f,0.56256324f,0f,0f,0f ) ;
  }

  @Test
  public void test116() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.07092513f,0.1300657f,0.9889654f,0f,0f,0f ) ;
  }

  @Test
  public void test117() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.09206646f,0.2635763f,0.53788286f,0f,0f,0f ) ;
  }

  @Test
  public void test118() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1009,7.856841E-5f,-0.0024477378f,0.0035673792f,0f,0f,0f ) ;
  }

  @Test
  public void test119() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.11086895f,-0.59036064f,-0.08024501f,0f,0f,0f ) ;
  }

  @Test
  public void test120() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.14278279f,0.44095567f,-0.088100016f,0f,0f,0f ) ;
  }

  @Test
  public void test121() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.14685512f,-0.65565586f,-0.74064094f,0f,0f,0f ) ;
  }

  @Test
  public void test122() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.15130082f,0.008890419f,-0.72180974f,0f,0f,0f ) ;
  }

  @Test
  public void test123() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.15444423f,-0.2190641f,0.9399927f,0f,0f,0f ) ;
  }

  @Test
  public void test124() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.19389929f,-0.24053234f,-0.09624983f,0f,0f,0f ) ;
  }

  @Test
  public void test125() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1022,-0.108666405f,-0.28995097f,0.7025689f,0f,0f,0f ) ;
  }

  @Test
  public void test126() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.24179223f,0.7921404f,0.5604017f,0f,0f,0f ) ;
  }

  @Test
  public void test127() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.3011017f,-0.6809683f,0.2599542f,0f,0f,0f ) ;
  }

  @Test
  public void test128() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.3057592f,-0.95156384f,0.032212187f,0f,0f,0f ) ;
  }

  @Test
  public void test129() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.3889904f,-0.35615996f,0.054512877f,0f,0f,0f ) ;
  }

  @Test
  public void test130() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.47837687f,0.49386552f,-0.66240716f,0f,0f,0f ) ;
  }

  @Test
  public void test131() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.57644f,0.25963897f,-0.13282904f,0f,0f,0f ) ;
  }

  @Test
  public void test132() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.60843676f,0.75118226f,0.2559882f,0f,0f,0f ) ;
  }

  @Test
  public void test133() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.6198527f,0.7388192f,-0.2234369f,0f,0f,0f ) ;
  }

  @Test
  public void test134() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.6391808f,-0.17106931f,-0.09691221f,0f,0f,0f ) ;
  }

  @Test
  public void test135() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.71967256f,-0.028762555f,-0.6937176f,0f,0f,0f ) ;
  }

  @Test
  public void test136() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.9227235f,0.17742634f,-0.34220067f,0f,0f,0f ) ;
  }

  @Test
  public void test137() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.9731602f,0.14267041f,-0.18056683f,0f,0f,0f ) ;
  }

  @Test
  public void test138() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.9961203f,-0.08347141f,-0.027873803f,0f,0f,0f ) ;
  }

  @Test
  public void test139() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test140() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test141() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,11.96732f,54.52286f,-38.95644f,0f,0f,0f ) ;
  }

  @Test
  public void test142() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-1.4119115f,-84.175125f,53.249477f,0f,0f,0f ) ;
  }

  @Test
  public void test143() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,29.130219f,61.079185f,-93.473595f,0f,0f,0f ) ;
  }

  @Test
  public void test144() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-3.1647442E-8f,2.4439558E-7f,-1.2875634E-7f,0f,0f,0f ) ;
  }

  @Test
  public void test145() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-133,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test146() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-4.3041375E-4f,-0.49148366f,0.8708867f,0f,0f,0f ) ;
  }

  @Test
  public void test147() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,5.653459E-4f,-4.5753E-4f,3.0813945E-4f,0f,0f,0f ) ;
  }

  @Test
  public void test148() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1907,-0.1560537f,0.8172799f,-0.5547079f,0f,0f,0f ) ;
  }

  @Test
  public void test149() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-93.894226f,45.765682f,-87.70829f,0f,0f,0f ) ;
  }

  @Test
  public void test150() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,-0.83251065f,-0.24378835f,-0.39829823f,0f,0f,0f ) ;
  }

  @Test
  public void test151() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test152() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,127.830536f,72.83491f,-9.631489f,0f,0f,0f ) ;
  }

  @Test
  public void test153() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,302,-79.14122f,-76.308876f,11.666845f,0f,0f,0f ) ;
  }

  @Test
  public void test154() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,33,40.196583f,-84.95985f,-72.71899f,0f,0f,0f ) ;
  }

  @Test
  public void test155() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-724,0.06253143f,-0.14224339f,0.96277004f,0f,0f,0f ) ;
  }

  @Test
  public void test156() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,767,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test157() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-857,-1.6658346E-4f,0.0021473467f,4.5817767E-4f,0f,0f,0f ) ;
  }

  @Test
  public void test158() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-870,80.19864f,-69.58914f,37.288494f,0f,0f,0f ) ;
  }

  @Test
  public void test159() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,897,-7.207177E-10f,-8.095973E-9f,5.0583445E-8f,0f,0f,0f ) ;
  }

  @Test
  public void test160() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,911,0.11264621f,0.9900513f,-0.08431626f,0f,0f,0f ) ;
  }

  @Test
  public void test161() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-921,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test162() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-925,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test163() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-100.0f,-100.0f,0f,0f,0f,1,-0.4829622f,-0.06153269f,-0.10191313f,0f,0f,0f ) ;
  }

  @Test
  public void test164() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,100.0f,100.0f,438.0f,-1619.0f,140.0f,-2,-0.96746415f,0.12713061f,0.21874851f,0f,0f,0f ) ;
  }

  @Test
  public void test165() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,100.0f,100.0f,-987.0f,382.0f,-741.0f,2,0.022549087f,0.2946573f,0.955337f,0f,0f,0f ) ;
  }

  @Test
  public void test166() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,-18.547318f,0f,0f,0f,-484,5.3720503f,-6.337449f,5.20506f,0f,0f,0f ) ;
  }

  @Test
  public void test167() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,58.859825f,0f,0f,0f,713,0.38136724f,-0.9081688f,0.17259337f,0f,0f,0f ) ;
  }

  @Test
  public void test168() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,11.050403f,77.106995f,0f,0f,0f,1,0.23598856f,0.9281483f,0.30441266f,0f,0f,0f ) ;
  }

  @Test
  public void test169() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,12.338473f,100.0f,0f,0f,0f,1,0.924466f,-0.090846084f,-0.37028316f,0f,0f,0f ) ;
  }

  @Test
  public void test170() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-24.285301f,-72.39833f,0f,0f,0f,1,0.96615547f,-0.22698429f,-0.12256322f,0f,0f,0f ) ;
  }

  @Test
  public void test171() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-52.654327f,98.52597f,0f,0f,0f,1,0.11959748f,0.6141769f,-0.1430357f,0f,0f,0f ) ;
  }

  @Test
  public void test172() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-66.13022f,-72.50065f,0f,0f,0f,1,0.06838856f,-0.008569323f,0.9747591f,0f,0f,0f ) ;
  }

  @Test
  public void test173() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,12.970391f,-13.478442f,37.315483f,590.0f,230.0f,-122.0f,511,-7.7792416f,-6.487841f,0.3605424f,0f,0f,0f ) ;
  }

  @Test
  public void test174() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-18.63388f,-5.2828965f,-9.360662f,0f,0f,0f,818,0.18933143f,0.97708124f,-0.09729285f,0f,0f,0f ) ;
  }

  @Test
  public void test175() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-23.97223f,-100.0f,-16.291508f,0f,0f,0f,-1894,-0.04274795f,0.009838549f,0.0025110452f,0f,0f,0f ) ;
  }

  @Test
  public void test176() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-24.675537f,12.524473f,23.681541f,0f,0f,0f,-479,0.080825776f,-0.4419015f,0.05853399f,0f,0f,0f ) ;
  }

  @Test
  public void test177() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,33.24736f,17.307442f,-1.5879892f,0f,0f,0f,1,9.390054f,-17.15707f,9.603019f,0f,0f,0f ) ;
  }

  @Test
  public void test178() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-46.00305f,82.169426f,75.67171f,0f,0f,0f,-372,-59.373848f,58.800255f,-24.489613f,0f,0f,0f ) ;
  }

  @Test
  public void test179() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,4.8395114f,45.29961f,-76.44251f,-51.0f,1455.0f,859.0f,5,-1.0108181f,0.18245395f,-0.029308982f,0f,0f,0f ) ;
  }

  @Test
  public void test180() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-54.835297f,-60.20351f,43.841747f,0f,0f,0f,-6,92.13384f,-23.958858f,-39.38469f,0f,0f,0f ) ;
  }

  @Test
  public void test181() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,5.7229156f,-100.0f,93.78136f,0f,0f,0f,1,1.8080128f,0.2043328f,1.7782393f,0f,0f,0f ) ;
  }

  @Test
  public void test182() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-66.85418f,-55.896683f,81.60327f,0f,0f,0f,-37,80.9368f,1.8282955f,67.56052f,0f,0f,0f ) ;
  }

  @Test
  public void test183() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-69.50746f,-14.462014f,-75.04081f,0f,0f,0f,1,-0.25473696f,0.2073071f,0.12757261f,0f,0f,0f ) ;
  }

  @Test
  public void test184() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-75.327835f,99.995804f,-42.863003f,0f,0f,0f,1,9.409172f,-5.3434362f,-29.001554f,0f,0f,0f ) ;
  }

  @Test
  public void test185() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-81.2459f,-21.586283f,-67.34636f,0f,0f,0f,1,0.23350595f,0.8081383f,-0.5407286f,0f,0f,0f ) ;
  }

  @Test
  public void test186() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,87.59326f,50.29137f,100.0f,0f,0f,0f,1,18.418041f,1.4604361f,-16.867435f,0f,0f,0f ) ;
  }

  @Test
  public void test187() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-87.69062f,-12.939228f,-21.645975f,0f,0f,0f,1163,-0.32012033f,-0.031075254f,0.03424904f,0f,0f,0f ) ;
  }

  @Test
  public void test188() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,94.02033f,46.14095f,41.820095f,1443.0f,-122.0f,-247.0f,1564,2.1799195f,-0.014777885f,-4.88461f,0f,0f,0f ) ;
  }

  @Test
  public void test189() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,99.99946f,-97.480064f,-5.978544f,-818.0f,-176.0f,906.0f,-187,5.445421f,5.4955096f,1.4780381f,0f,0f,0f ) ;
  }

  @Test
  public void test190() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,100.0f,-35.265194f,0f,0f,0f,0f,0f,0f,2,100.0f,100.0f,-35.265194f,0f,0f,0f ) ;
  }

  @Test
  public void test191() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-4.6972404f,7.917658f,0f,0f,0f,0f,0f,0f,-2,100.0f,-4.7238784f,7.9039516f,0f,0f,0f ) ;
  }

  @Test
  public void test192() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-72.83256f,-97.179924f,-18.902134f,0f,0f,0f,0f,0f,0f,3,-46.67425f,63.137646f,-47.05448f,0f,0f,0f ) ;
  }

  @Test
  public void test193() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-0.64806485f,32.976276f,-42.09752f,1334.0f,-1004.0f,-807.0f,-410,0.5152183f,-0.5368433f,-0.66821194f,0f,0f,0f ) ;
  }

  @Test
  public void test194() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,100.0f,-100.0f,9.7505665f,-76.0f,-33.0f,441.0f,372,100.0f,100.0f,99.980125f,0f,0f,0f ) ;
  }

  @Test
  public void test195() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,10.148688f,19.919641f,-3.7897758f,-801.0f,67.0f,-1806.0f,-1577,-0.06372059f,0.29392147f,0.9537032f,0f,0f,0f ) ;
  }

  @Test
  public void test196() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-16.780972f,-99.99988f,-0.5938167f,0f,0f,0f,1,0.0023228428f,-0.0063277637f,0.99997735f,0f,0f,0f ) ;
  }

  @Test
  public void test197() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,24.600695f,95.92249f,-41.467f,236.0f,-99.0f,-89.0f,5,5.226771f,-7.5269256f,-0.06812009f,0f,0f,0f ) ;
  }

  @Test
  public void test198() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,29.222218f,-21.03257f,-6.2755075f,267.0f,456.0f,-285.0f,-2031,0.72054905f,-0.69457364f,2.3165863E-4f,0f,0f,0f ) ;
  }

  @Test
  public void test199() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,32.333614f,-53.83348f,-100.0f,0f,0f,0f,1,-0.0023592608f,0.5240254f,0.8481378f,0f,0f,0f ) ;
  }

  @Test
  public void test200() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,38.039207f,-15.911096f,-12.279466f,-288.0f,-1366.0f,873.0f,-2,-0.9065031f,0.485964f,0.29745328f,0f,0f,0f ) ;
  }

  @Test
  public void test201() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-54.212708f,19.192146f,4.76658f,-249.0f,-756.0f,219.0f,-1094,21.549038f,52.892677f,32.121056f,0f,0f,0f ) ;
  }

  @Test
  public void test202() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,74.073685f,23.832262f,98.621925f,-40.0f,-1278.0f,425.0f,315,0.3270444f,-0.04468989f,0.8635957f,0f,0f,0f ) ;
  }

  @Test
  public void test203() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-87.85724f,-1.0718807f,100.0f,-1582.0f,-138.0f,-218.0f,548,0.09121046f,-0.35720798f,0.9295607f,0f,0f,0f ) ;
  }

  @Test
  public void test204() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,90.64004f,-72.65023f,-100.0f,0f,0f,0f,503,-0.18618228f,-3.4306524f,2.3236213f,0f,0f,0f ) ;
  }

  @Test
  public void test205() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-94.725586f,-100.0f,100.0f,-1286.0f,110.0f,-121.0f,2013,0.5628263f,-0.31027424f,0.7661308f,0f,0f,0f ) ;
  }

  @Test
  public void test206() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-95.3255f,100.0f,100.0f,-1173.0f,-233.0f,-818.0f,1,0.6198663f,-0.091274634f,0.4295149f,0f,0f,0f ) ;
  }

  @Test
  public void test207() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,98.38904f,68.41918f,19.732487f,0f,0f,0f,2,-0.52723217f,0.82117f,-0.21841729f,0f,0f,0f ) ;
  }

  @Test
  public void test208() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,11.408165f,0f,0f,0f,0f,0f,-34.949802f,31.745892f,10.28244f,979.0f,-202.0f,-288.0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test209() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,125.19866f,0f,0f,0f,0f,0f,-28.328365f,-101.25607f,-2.420922f,243.0f,-993.0f,978.0f,-1,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test210() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,12.684656f,0f,0f,0f,0f,0f,-5.7206764f,-9.469482f,7.026597f,-1345.0f,1109.0f,401.0f,-744,-81.14856f,99.96428f,68.651344f,0f,0f,0f ) ;
  }

  @Test
  public void test211() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,12.871313f,0f,0f,0f,0f,0f,66.63904f,45.83172f,-21.247135f,-10.0f,267.0f,539.0f,3177,-0.270463f,1.0251377f,0.05128472f,0f,0f,0f ) ;
  }

  @Test
  public void test212() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,13.705362f,0f,0f,0f,0f,0f,-40.518677f,81.33403f,0.44817272f,478.0f,249.0f,-1973.0f,48,10.301413f,13.454061f,55.151314f,0f,0f,0f ) ;
  }

  @Test
  public void test213() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,153.3765f,0f,0f,0f,0f,0f,-35.61706f,41.00011f,-0.50994974f,-850.0f,-741.0f,-209.0f,-1,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test214() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,15.6893215f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test215() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,16.114649f,0f,0f,0f,0f,0f,6.2483153f,38.80475f,45.426018f,1206.0f,-105.0f,1188.0f,-971,42.435642f,-54.68207f,40.874653f,0f,0f,0f ) ;
  }

  @Test
  public void test216() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,16.963985f,0f,0f,0f,0f,0f,-0.3795204f,0.58073384f,0.12767766f,-623.0f,985.0f,214.0f,3842,0.29680985f,0.19844207f,-0.020337375f,0f,0f,0f ) ;
  }

  @Test
  public void test217() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,17.415257f,0f,0f,0f,0f,0f,-100.0f,-100.0f,2.185657f,0f,0f,0f,189,-0.94118f,-0.05393125f,-0.2949875f,0f,0f,0f ) ;
  }

  @Test
  public void test218() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,1.7763568E-15f,0f,0f,0f,0f,0f,-100.0f,-61.780544f,-100.0f,0f,0f,0f,4,0.027070872f,-0.020377604f,-0.99942577f,0f,0f,0f ) ;
  }

  @Test
  public void test219() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,19.371172f,0f,0f,0f,0f,0f,-60.801144f,14.346409f,-21.645721f,253.0f,-2612.0f,693.0f,-1,0.3213054f,-0.005889489f,2.1843257f,0f,0f,0f ) ;
  }

  @Test
  public void test220() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,21.135239f,0f,0f,0f,0f,0f,39.879913f,-25.753183f,-96.334496f,-447.0f,834.0f,-408.0f,852,-97.01824f,100.0f,-66.89605f,0f,0f,0f ) ;
  }

  @Test
  public void test221() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,21.942726f,0f,0f,0f,0f,0f,-65.213745f,6.667468f,-20.487822f,-190.0f,85.0f,-799.0f,-374,29.869383f,69.13133f,-72.57792f,0f,0f,0f ) ;
  }

  @Test
  public void test222() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-22.254278f,0f,0f,0f,0f,0f,20.666018f,-53.694664f,-99.98115f,0f,0f,0f,1,0.026581213f,0.15229785f,-0.9826759f,0f,0f,0f ) ;
  }

  @Test
  public void test223() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,23.95381f,0f,0f,0f,0f,0f,41.2502f,-10.811394f,-13.423879f,-714.0f,-2644.0f,-73.0f,4,-1.7918296f,-0.103559025f,0.025581906f,0f,0f,0f ) ;
  }

  @Test
  public void test224() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-24.539629f,0f,0f,0f,0f,0f,-92.99645f,-70.64962f,15.149888f,0f,0f,0f,94,-40.0462f,43.773064f,18.96973f,0f,0f,0f ) ;
  }

  @Test
  public void test225() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,249.37419f,0f,0f,0f,0f,0f,-77.5319f,-19.668108f,-24.64218f,-272.0f,-944.0f,-120.0f,3794,-0.009486113f,-0.63320386f,-1.4807978f,0f,0f,0f ) ;
  }

  @Test
  public void test226() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,250.36275f,0f,0f,0f,0f,0f,-74.58945f,197.48798f,-13.865225f,-2215.0f,-453.0f,956.0f,1987,-1.158159f,0.008177082f,2.265446f,0f,0f,0f ) ;
  }

  @Test
  public void test227() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,251.69211f,0f,0f,0f,0f,0f,-48.978535f,30.767916f,-128.14062f,-261.0f,275.0f,-987.0f,-869,2.4118211f,0.15497983f,-1.4409202f,0f,0f,0f ) ;
  }

  @Test
  public void test228() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,251.97005f,0f,0f,0f,0f,0f,-47.57028f,-100.0f,100.0f,452.0f,190.0f,667.0f,-137,-71.938835f,-100.0f,7.798632f,0f,0f,0f ) ;
  }

  @Test
  public void test229() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,252.44249f,0f,0f,0f,0f,0f,-47.66538f,0.22076748f,76.27325f,808.0f,-482.0f,586.0f,1086,-120.085365f,25.340601f,-19.550732f,0f,0f,0f ) ;
  }

  @Test
  public void test230() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.10817f,0f,0f,0f,0f,0f,80.17548f,14.987468f,-100.0f,1038.0f,1350.0f,-122.0f,-242,8.33554f,-24.44114f,3.0211794f,0f,0f,0f ) ;
  }

  @Test
  public void test231() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.49034f,0f,0f,0f,0f,0f,-92.85689f,77.745674f,93.50865f,-830.0f,-669.0f,721.0f,599,-1.5556176f,0.050851855f,0.987314f,0f,0f,0f ) ;
  }

  @Test
  public void test232() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.66197f,0f,0f,0f,0f,0f,100.0f,73.7071f,-165.88869f,1277.0f,-132.0f,-3308.0f,-274,0.7865702f,3.2006319f,1.8067963f,0f,0f,0f ) ;
  }

  @Test
  public void test233() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.69485f,0f,0f,0f,0f,0f,-128.3575f,196.76662f,-50.10606f,-1615.0f,509.0f,-360.0f,627,-0.44487277f,-1.4502549f,-4.852665f,0f,0f,0f ) ;
  }

  @Test
  public void test234() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.71962f,0f,0f,0f,0f,0f,1.5293049f,70.50442f,32.315796f,580.0f,80.0f,807.0f,-645,35.101063f,-22.314255f,47.00642f,0f,0f,0f ) ;
  }

  @Test
  public void test235() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.99022f,0f,0f,0f,0f,0f,-67.161316f,30.869308f,-41.338833f,-851.0f,-1127.0f,-630.0f,-444,-130.755f,-125.55366f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test236() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.01463f,0f,0f,0f,0f,0f,56.118855f,178.44722f,144.60277f,-1538.0f,637.0f,652.0f,-1334,1.383704f,1.2389392f,1.4425735f,0f,0f,0f ) ;
  }

  @Test
  public void test237() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.2306f,0f,0f,0f,0f,0f,-100.0f,145.69714f,100.0f,-513.0f,862.0f,-648.0f,323,-192.56253f,-113.80841f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test238() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.4218f,0f,0f,0f,0f,0f,-87.40323f,-100.0f,-12.157657f,-1399.0f,-308.0f,-1175.0f,-936,57.74396f,-94.88101f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test239() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.46501f,0f,0f,0f,0f,0f,100.0f,-100.0f,88.28873f,437.0f,-328.0f,448.0f,1610,74.28219f,-100.0f,-2.018967f,0f,0f,0f ) ;
  }

  @Test
  public void test240() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.46568f,0f,0f,0f,0f,0f,31.963955f,31.75863f,-26.77401f,-553.0f,370.0f,-1010.0f,1739,46.321693f,-9.528084f,44.00972f,0f,0f,0f ) ;
  }

  @Test
  public void test241() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.66331f,0f,0f,0f,0f,0f,8.758528f,6.6747847f,13.790518f,806.0f,74.0f,1544.0f,-71,96.21326f,85.51894f,-80.493675f,0f,0f,0f ) ;
  }

  @Test
  public void test242() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.7645f,0f,0f,0f,0f,0f,11.190926f,45.14699f,-44.431732f,410.0f,332.0f,31.0f,1247,18.843271f,-36.3712f,-32.1918f,0f,0f,0f ) ;
  }

  @Test
  public void test243() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.98357f,0f,0f,0f,0f,0f,-80.87587f,-20.147104f,23.27549f,-1124.0f,195.0f,1004.0f,856,37.631f,-51.857918f,85.8511f,0f,0f,0f ) ;
  }

  @Test
  public void test244() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.12347f,0f,0f,0f,0f,0f,-141.95891f,-15.869876f,121.07607f,-1392.0f,-117.0f,-65.0f,-686,2.1785128f,-0.8463625f,3.419226f,0f,0f,0f ) ;
  }

  @Test
  public void test245() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.46747f,0f,0f,0f,0f,0f,-111.35016f,-98.69676f,-100.85178f,-1427.0f,541.0f,500.0f,-1162,-0.6324232f,-0.48139784f,-0.848198f,0f,0f,0f ) ;
  }

  @Test
  public void test246() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.75067f,0f,0f,0f,0f,0f,-58.75107f,32.983654f,-36.51653f,570.0f,1047.0f,-923.0f,189,9.401819f,21.043037f,-80.53374f,0f,0f,0f ) ;
  }

  @Test
  public void test247() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,257.67166f,0f,0f,0f,0f,0f,-81.327f,100.0f,100.0f,1151.0f,1485.0f,-62.0f,19,82.79655f,44.82547f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test248() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,265.5821f,0f,0f,0f,0f,0f,-100.0f,-100.0f,-29.774906f,-916.0f,-507.0f,-171.0f,-376,52.58238f,-100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test249() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,27.019863f,0f,0f,0f,0f,0f,-45.496094f,-4.1750546f,63.90524f,913.0f,-505.0f,617.0f,132,-29.319616f,39.18364f,80.04584f,0f,0f,0f ) ;
  }

  @Test
  public void test250() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,280.07294f,0f,0f,0f,0f,0f,13.989003f,120.78923f,-109.680374f,1344.0f,534.0f,-1643.0f,354,0.28815964f,-0.33088908f,-0.5308064f,0f,0f,0f ) ;
  }

  @Test
  public void test251() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,283.85992f,0f,0f,0f,0f,0f,78.89117f,-55.059593f,-2.2354074f,322.0f,-234.0f,-309.0f,223,0.8251533f,-0.04196534f,-0.52916497f,0f,0f,0f ) ;
  }

  @Test
  public void test252() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,28.411058f,0f,0f,0f,0f,0f,71.7759f,10.417302f,-22.095253f,81.0f,-305.0f,119.0f,-795,-6.5896506f,78.63623f,15.66849f,0f,0f,0f ) ;
  }

  @Test
  public void test253() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,285.05405f,0f,0f,0f,0f,0f,8.981803f,-43.66176f,-3.1572382f,310.0f,-880.0f,-81.0f,-756,47.86318f,-126.140526f,50.797356f,0f,0f,0f ) ;
  }

  @Test
  public void test254() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,28.613111f,0f,0f,0f,0f,0f,-68.3131f,74.65581f,54.145428f,402.0f,117.0f,-1131.0f,37,-0.932694f,-0.2775174f,-0.23036052f,0f,0f,0f ) ;
  }

  @Test
  public void test255() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,28.705519f,0f,0f,0f,0f,0f,-32.169575f,-100.0f,-99.977104f,0f,0f,0f,920,-0.43613684f,0.027236653f,0.1130926f,0f,0f,0f ) ;
  }

  @Test
  public void test256() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,29.174389f,0f,0f,0f,0f,0f,-72.494125f,28.03563f,80.681595f,0f,0f,0f,607,-37.155144f,39.135494f,25.914932f,0f,0f,0f ) ;
  }

  @Test
  public void test257() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,292.11966f,0f,0f,0f,0f,0f,-175.73868f,-122.56434f,-4.271813f,90.0f,-1801.0f,1496.0f,-627,-0.4000285f,0.21963409f,-0.05991808f,0f,0f,0f ) ;
  }

  @Test
  public void test258() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,297.70956f,0f,0f,0f,0f,0f,-48.02524f,-128.06804f,7.6908226f,376.0f,-561.0f,666.0f,960,-44.419888f,13.123996f,51.82345f,0f,0f,0f ) ;
  }

  @Test
  public void test259() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,30.390804f,0f,0f,0f,0f,0f,72.31138f,8.360045f,50.902733f,225.0f,-294.0f,-268.0f,564,-0.066051625f,0.11985712f,0.544802f,0f,0f,0f ) ;
  }

  @Test
  public void test260() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,32.835564f,0f,0f,0f,0f,0f,28.716017f,-95.13432f,38.677338f,-675.0f,-517.0f,-350.0f,678,-6.485606f,-13.1442175f,-16.807878f,0f,0f,0f ) ;
  }

  @Test
  public void test261() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,3.360758f,0f,0f,0f,0f,0f,-81.41439f,49.742588f,-46.93424f,-376.0f,-806.0f,-202.0f,143,-0.685438f,-0.3200027f,-0.31531805f,0f,0f,0f ) ;
  }

  @Test
  public void test262() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,35.133453f,0f,0f,0f,0f,0f,95.72934f,74.00432f,-99.28932f,-308.0f,-619.0f,540.0f,-808,0.41880172f,0.51545316f,0.30845347f,0f,0f,0f ) ;
  }

  @Test
  public void test263() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,362.10196f,0f,0f,0f,0f,0f,15.5859995f,-92.32871f,-71.34345f,-352.0f,-536.0f,143.0f,1638,38.161987f,6.58053f,-0.18681215f,0f,0f,0f ) ;
  }

  @Test
  public void test264() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,42.081745f,0f,0f,0f,0f,0f,-78.51982f,-14.5730505f,23.820835f,89.0f,-619.0f,623.0f,897,-0.31888855f,0.22166093f,-0.91550165f,0f,0f,0f ) ;
  }

  @Test
  public void test265() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,42.832577f,0f,0f,0f,0f,0f,-87.730965f,49.245087f,75.827f,-191.0f,-580.0f,609.0f,586,-30.635656f,-11.801863f,-27.7805f,0f,0f,0f ) ;
  }

  @Test
  public void test266() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,45.125977f,0f,0f,0f,0f,0f,23.89616f,-78.11674f,-27.7002f,-551.0f,-101.0f,812.0f,377,42.156227f,13.604238f,-1.9980619f,0f,0f,0f ) ;
  }

  @Test
  public void test267() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,45.74809f,0f,0f,0f,0f,0f,54.99467f,9.406634f,-100.0f,0f,0f,0f,-870,-0.0719067f,-0.35742605f,-0.93116915f,0f,0f,0f ) ;
  }

  @Test
  public void test268() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,4.579761f,0f,0f,0f,0f,0f,97.02025f,-0.85268116f,67.13503f,1385.0f,-1699.0f,402.0f,-489,-0.18672854f,-0.124828056f,0.6871469f,0f,0f,0f ) ;
  }

  @Test
  public void test269() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,47.23116f,0f,0f,0f,0f,0f,-26.386919f,-10.995426f,57.95349f,-911.0f,-308.0f,747.0f,-679,-70.877914f,16.842056f,11.462422f,0f,0f,0f ) ;
  }

  @Test
  public void test270() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,47.508293f,0f,0f,0f,0f,0f,20.576292f,46.726246f,18.758196f,852.0f,-213.0f,-404.0f,-520,-74.86036f,63.773567f,-76.74249f,0f,0f,0f ) ;
  }

  @Test
  public void test271() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,49.54259f,0f,0f,0f,0f,0f,-21.225254f,-29.48379f,9.567419f,-945.0f,875.0f,600.0f,-667,-0.30739087f,0.013412614f,1.0602124f,0f,0f,0f ) ;
  }

  @Test
  public void test272() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,49.657196f,0f,0f,0f,0f,0f,98.31732f,51.448807f,21.186293f,249.0f,101.0f,-124.0f,679,21.727798f,25.635569f,65.59659f,0f,0f,0f ) ;
  }

  @Test
  public void test273() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-49.770653f,0f,0f,0f,0f,0f,-70.3108f,-82.90167f,92.69505f,0f,0f,0f,3,-0.6016018f,-0.75298893f,0.26661384f,0f,0f,0f ) ;
  }

  @Test
  public void test274() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,50.821888f,0f,0f,0f,0f,0f,-97.51274f,-43.340527f,26.943005f,129.0f,-602.0f,370.0f,-67,-47.21351f,-6.3388886f,-61.173607f,0f,0f,0f ) ;
  }

  @Test
  public void test275() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,53.90217f,0f,0f,0f,0f,0f,-58.262104f,6.9059453f,-28.5243f,-684.0f,-2078.0f,894.0f,-596,0.20077151f,-0.018761842f,-0.41925436f,0f,0f,0f ) ;
  }

  @Test
  public void test276() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,54.469826f,0f,0f,0f,0f,0f,47.4629f,-15.635808f,-49.09803f,152.0f,1080.0f,-197.0f,-202,0.18624593f,0.25183052f,0.09983837f,0f,0f,0f ) ;
  }

  @Test
  public void test277() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,56.87438f,0f,0f,0f,0f,0f,-74.4049f,-100.0f,37.312714f,0f,0f,0f,2,-1.523589f,-0.4020899f,-0.23704116f,0f,0f,0f ) ;
  }

  @Test
  public void test278() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,58.35978f,0f,0f,0f,0f,0f,-34.935658f,33.230957f,36.20029f,795.0f,911.0f,613.0f,-917,17.505527f,77.40122f,-7.6620812f,0f,0f,0f ) ;
  }

  @Test
  public void test279() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,59.692158f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,5,62.79286f,62.320805f,51.360622f,0f,0f,0f ) ;
  }

  @Test
  public void test280() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-60.231606f,0f,0f,0f,0f,0f,43.277348f,74.78653f,-91.76221f,0f,0f,0f,631,0.48226768f,0.00849811f,-0.54799014f,0f,0f,0f ) ;
  }

  @Test
  public void test281() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,61.45739f,0f,0f,0f,0f,0f,7.4468865f,-88.10381f,2.2797105f,994.0f,51.0f,-1276.0f,-274,0.8143762f,-0.16937892f,-0.46086583f,0f,0f,0f ) ;
  }

  @Test
  public void test282() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,64.316376f,0f,0f,0f,0f,0f,100.0f,27.05412f,71.32984f,-224.0f,-848.0f,905.0f,-1098,0.5774447f,0.6234188f,0.07415598f,0f,0f,0f ) ;
  }

  @Test
  public void test283() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,6.4410577f,0f,0f,0f,0f,0f,14.101543f,16.781963f,-100.0f,970.0f,1583.0f,-965.0f,-848,0.574925f,-0.76491535f,-0.29045781f,0f,0f,0f ) ;
  }

  @Test
  public void test284() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-64.5563f,0f,0f,0f,0f,0f,20.635592f,-29.774832f,18.769722f,0f,0f,0f,1165,-42.98787f,10.6465435f,64.15008f,0f,0f,0f ) ;
  }

  @Test
  public void test285() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-72.74204f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-5,86.00575f,-66.11154f,79.471054f,0f,0f,0f ) ;
  }

  @Test
  public void test286() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,73.405495f,0f,0f,0f,0f,0f,-80.98017f,4.2620807f,-61.13626f,129.0f,-328.0f,-880.0f,-504,-81.96944f,-31.658722f,-46.91888f,0f,0f,0f ) ;
  }

  @Test
  public void test287() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,74.42077f,0f,0f,0f,0f,0f,-50.181007f,-47.78815f,27.559135f,-885.0f,848.0f,-141.0f,1178,68.42975f,-83.50001f,92.694664f,0f,0f,0f ) ;
  }

  @Test
  public void test288() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-7.5314703f,0f,0f,0f,0f,0f,-11.172022f,-1.3278561f,71.93862f,0f,0f,0f,1,0.2217358f,-0.03835267f,-0.18860093f,0f,0f,0f ) ;
  }

  @Test
  public void test289() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,76.44188f,0f,0f,0f,0f,0f,-32.183582f,30.065336f,-8.809383f,0f,0f,0f,-714,-48.806263f,-73.71482f,-73.274185f,0f,0f,0f ) ;
  }

  @Test
  public void test290() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-78.1523f,0f,0f,0f,0f,0f,89.638535f,35.168125f,100.0f,0f,0f,0f,1907,0.19722833f,0.6674964f,0.7180178f,0f,0f,0f ) ;
  }

  @Test
  public void test291() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-81.363785f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test292() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,81.88202f,0f,0f,0f,0f,0f,-77.88927f,-21.217619f,50.686874f,-466.0f,822.0f,-372.0f,634,-100.0f,-11.9537325f,-59.40409f,0f,0f,0f ) ;
  }

  @Test
  public void test293() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,8.205065f,0f,0f,0f,0f,0f,95.18293f,50.527416f,33.69121f,289.0f,-107.0f,-656.0f,-157,64.13905f,66.95645f,45.49876f,0f,0f,0f ) ;
  }

  @Test
  public void test294() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,82.56448f,0f,0f,0f,0f,0f,-12.08048f,11.974181f,-42.384403f,-1546.0f,769.0f,356.0f,-897,-0.90962553f,-0.08515232f,-0.40434384f,0f,0f,0f ) ;
  }

  @Test
  public void test295() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,84.07782f,0f,0f,0f,0f,0f,7.804441f,3.6255574f,24.265005f,-314.0f,102.0f,1331.0f,95,49.754738f,-53.45824f,-8.015329f,0f,0f,0f ) ;
  }

  @Test
  public void test296() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,86.2389f,0f,0f,0f,0f,0f,-9.459531f,-10.20543f,1.6076996f,237.0f,-296.0f,-484.0f,-631,-21.50908f,29.54364f,60.981377f,0f,0f,0f ) ;
  }

  @Test
  public void test297() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-8.6809717E-20f,0f,0f,0f,0f,0f,-100.0f,42.320927f,-100.0f,0f,0f,0f,4,0.65284437f,0.6586753f,-0.3740871f,0f,0f,0f ) ;
  }

  @Test
  public void test298() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,88.17878f,0f,0f,0f,0f,0f,-100.0f,13.564022f,-81.45213f,-894.0f,-384.0f,-423.0f,-31,-0.734332f,-0.08793105f,0.5588325f,0f,0f,0f ) ;
  }

  @Test
  public void test299() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,93.171974f,0f,0f,0f,0f,0f,96.79876f,2.4668002f,-100.0f,148.0f,-168.0f,-625.0f,-1409,0.09932045f,0.9010685f,-0.37877062f,0f,0f,0f ) ;
  }

  @Test
  public void test300() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,93.5956f,0f,0f,0f,0f,0f,69.34347f,-57.62751f,100.0f,490.0f,-79.0f,819.0f,732,-68.67201f,-46.293327f,20.94187f,0f,0f,0f ) ;
  }

  @Test
  public void test301() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,96.226036f,0f,0f,0f,0f,0f,-35.523117f,41.9878f,-2.5529659f,744.0f,-593.0f,-406.0f,916,-93.91411f,3.2661502f,10.66286f,0f,0f,0f ) ;
  }

  @Test
  public void test302() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,97.18583f,0f,0f,0f,0f,0f,39.227913f,-89.541885f,77.26471f,-43.0f,-914.0f,-420.0f,456,54.387268f,-77.590614f,-8.414603f,0f,0f,0f ) ;
  }

  @Test
  public void test303() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,97.749466f,0f,0f,0f,0f,0f,69.196266f,99.96029f,-99.99465f,-1537.0f,1169.0f,-572.0f,3522,0.6158607f,-0.57609063f,-0.53743386f,0f,0f,0f ) ;
  }

  @Test
  public void test304() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,97.99462f,0f,0f,0f,0f,0f,44.41855f,-34.95208f,-23.549818f,832.0f,-721.0f,-137.0f,-631,3.0514464f,11.859791f,-11.846525f,0f,0f,0f ) ;
  }

  @Test
  public void test305() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,98.71342f,0f,0f,0f,0f,0f,33.014397f,-90.45404f,-91.239876f,628.0f,155.0f,45.0f,504,-25.72788f,42.56178f,-51.504623f,0f,0f,0f ) ;
  }

  @Test
  public void test306() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,99.79108f,0f,0f,0f,0f,0f,99.193726f,98.84567f,99.99985f,0f,0f,0f,1,0.045851182f,0.07814223f,0.9958873f,0f,0f,0f ) ;
  }

  @Test
  public void test307() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,99.85f,0f,0f,0f,0f,0f,25.643784f,21.484453f,35.013012f,-384.0f,-746.0f,739.0f,1486,-0.5210494f,0.4369402f,0.7568281f,0f,0f,0f ) ;
  }

  @Test
  public void test308() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,-36.68178f,27.007599f,84.041466f,0f,0f,0f,1,0.9212132f,-0.04000924f,0.39358294f,0f,0f,0f ) ;
  }

  @Test
  public void test309() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,0f,0f,-65.56908f,87.00031f,100.0f,0f,0f,0f,1,-0.42491758f,0.5198301f,-0.8470891f,0f,0f,0f ) ;
  }

  @Test
  public void test310() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.01727f,0.0f,0f,-49.45861f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.109819226f,-0.35414267f,-0.37220973f,0f,0f,0f ) ;
  }

  @Test
  public void test311() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,4,0.32554215f,-0.6965051f,0.18868008f,0f,0f,0f ) ;
  }

  @Test
  public void test312() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,-77.305504f,55.157463f,0f,0f,0f,608,-0.41310683f,-0.42829323f,-0.20486483f,0f,0f,0f ) ;
  }

  @Test
  public void test313() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,-0.44032097f,0.57031715f,-0.12844817f,0f,0f,0f ) ;
  }

  @Test
  public void test314() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.5563319f,-0.1878261f,0.58846915f,0f,0f,0f ) ;
  }

  @Test
  public void test315() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.7224752f,0.45499173f,-0.3172654f,0f,0f,0f ) ;
  }

  @Test
  public void test316() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-82.100624f,10.690356f,24.080978f,0f,0f,0f,-1224,0.37017393f,0.794136f,-0.48199514f,0f,0f,0f ) ;
  }

  @Test
  public void test317() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,-99.19619f,-100.0f,100.0f,0f,0f,0f,719,-0.203119f,0.54748774f,-0.8117881f,0f,0f,0f ) ;
  }

  @Test
  public void test318() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0.0f,0f,-84.03014f,0f,0f,0f,0f,0f,60.544235f,71.71191f,-24.002584f,0f,0f,0f,-832,-83.35884f,52.146267f,-54.468685f,0f,0f,0f ) ;
  }

  @Test
  public void test319() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.595881f,-0.41514695f,0.13831502f,0f,0f,0f ) ;
  }

  @Test
  public void test320() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-19.377321f,-100.0f,0f,0f,0f,-38,0.08388542f,-0.09412209f,0.10212375f,0f,0f,0f ) ;
  }

  @Test
  public void test321() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-100.0f,0f,0.0f,0f,0f,0f,0f,0f,34.932957f,-100.0f,37.221523f,0f,0f,0f,-823,-4.511608f,5.027866f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test322() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-84.1049f,-100.0f,0f,0f,0f,573,-0.16332804f,0.049859192f,0.9853111f,0f,0f,0f ) ;
  }

  @Test
  public void test323() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,69.7491f,-99.05824f,-7.4519086f,35.0f,1286.0f,-396.0f,697,-0.67686355f,0.14298114f,-0.23048607f,0f,0f,0f ) ;
  }

  @Test
  public void test324() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-100.0f,0f,38.660297f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.6065071f,-0.7376686f,0.2661823f,0f,0f,0f ) ;
  }

  @Test
  public void test325() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,-100.0f,0f,82.28426f,0f,0f,0f,0f,0f,-90.65434f,100.0f,34.4427f,0f,0f,0f,-1232,-0.2742942f,-0.9520359f,0.13561103f,0f,0f,0f ) ;
  }

  @Test
  public void test326() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,-10.978116f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,-0.6140675f,0.20322964f,0.6280099f,0f,0f,0f ) ;
  }

  @Test
  public void test327() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,-11.906478f,0f,0f,0f,0f,0f,0f,0f,18.760994f,25.69873f,48.128254f,0f,0f,0f,819,0.0018618294f,-0.22479169f,-0.1208067f,0f,0f,0f ) ;
  }

  @Test
  public void test328() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,12.108412f,0f,0f,0f,0f,0f,0f,0f,76.11398f,52.460392f,0.44993186f,1071.0f,-1538.0f,-1846.0f,3,-0.9946709f,-1.7375716f,4.852756f,0f,0f,0f ) ;
  }

  @Test
  public void test329() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,-14.775744f,0f,-41.44432f,0f,0f,0f,0f,0f,98.27537f,11.883724f,-34.46923f,0f,0f,0f,1059,-0.7105885f,-0.3440125f,-0.61377466f,0f,0f,0f ) ;
  }

  @Test
  public void test330() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,-17.520695f,0f,-36.580074f,0f,0f,0f,0f,0f,-67.52829f,63.936657f,29.181774f,0f,0f,0f,-668,-0.2652422f,-0.32966015f,-0.89794695f,0f,0f,0f ) ;
  }

  @Test
  public void test331() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-2.8815215f,0f,-1.4779654f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.012181403f,-0.043824196f,-0.0017729917f,0f,0f,0f ) ;
  }

  @Test
  public void test332() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,-58.3927f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.12293679f,-0.13941248f,-0.89925784f,0f,0f,0f ) ;
  }

  @Test
  public void test333() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-85.93033f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.10639303f,0.18152888f,-0.21963792f,0f,0f,0f ) ;
  }

  @Test
  public void test334() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,86.21642f,0f,0f,0f,0f,0f,0f,0f,-23.430984f,98.41878f,-93.1502f,0f,0f,0f,-319,0.06224216f,-0.35063398f,0.8029925f,0f,0f,0f ) ;
  }

  @Test
  public void test335() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,95.03496f,0f,0f,0f,0f,0f,0f,0f,98.972694f,-55.103046f,-89.28323f,880.0f,-136.0f,2420.0f,-6,-0.8850083f,-0.7967116f,-1.2656689f,0f,0f,0f ) ;
  }

  @Test
  public void test336() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,99.998924f,0f,0f,0f,0f,0f,0f,0f,100.0f,94.82324f,-53.604324f,-759.0f,-687.0f,2061.0f,-87,0.03364728f,-0.5338784f,-0.84489155f,0f,0f,0f ) ;
  }

  @Test
  public void test337() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1010.0f,823.0f,-678.0f,-3.0f,0f,0f,0f,0f,0f,699.0f,911.0f,-108.0f,-474.0f,895.0f,651.0f,1233,-31.676863f,-12.78077f,166.23203f,37.463135f,0f,0f ) ;
  }

  @Test
  public void test338() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1033.0f,0.0f,0f,615.0f,0f,0f,0f,0f,0f,14.0f,-674.0f,-956.0f,-653.0f,-377.0f,256.0f,-439,-24.399815f,32.976883f,77.47604f,0f,0f,0f ) ;
  }

  @Test
  public void test339() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1035.0f,1473.0f,0f,67.0f,0f,0f,0f,0f,0f,-1028.0f,-332.0f,-572.0f,129.0f,390.0f,-462.0f,-1333,22.432772f,-100.0f,17.725716f,0f,0f,0f ) ;
  }

  @Test
  public void test340() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0590155E-4f,100.0f,0f,0f,0f,0f,0f,0f,0f,-2.3152633f,-30.20758f,-19.053957f,-661.0f,361.0f,-492.0f,-1816,0.2944541f,1.7458911f,0.885432f,0f,0f,0f ) ;
  }

  @Test
  public void test341() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,106.0f,-243.0f,757.0f,239.0f,0f,0f,0f,0f,0f,920.0f,-944.0f,282.0f,549.0f,891.0f,508.0f,-553,-78.30177f,32.19927f,-40.652122f,63.79839f,-98.652466f,66.370125f ) ;
  }

  @Test
  public void test342() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1072.0f,3140.0f,0f,951.0f,0f,0f,0f,0f,0f,229.0f,201.0f,205.0f,-325.0f,51.0f,314.0f,-682,-100.805466f,-44.8778f,-99.31439f,0f,0f,0f ) ;
  }

  @Test
  public void test343() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1078.0f,1359.0f,-656.0f,-2.0f,0f,0f,0f,0f,0f,-111.0f,-250.0f,1130.0f,206.0f,-489.0f,1867.0f,1818,-0.3117047f,0.114290975f,-0.9600062f,98.283066f,-4.6144447f,0f ) ;
  }

  @Test
  public void test344() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1088.0f,418.0f,0f,1817.0f,0f,0f,0f,0f,0f,1027.0f,-947.0f,-442.0f,-335.0f,-209.0f,-661.0f,845,-0.16646636f,0.8941469f,-0.41568044f,0f,0f,0f ) ;
  }

  @Test
  public void test345() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1088.0f,833.0f,0f,1351.0f,0f,0f,0f,0f,0f,-649.0f,643.0f,319.0f,414.0f,-194.0f,1235.0f,-832,-19.784739f,-16.577492f,-6.8761964f,0f,0f,0f ) ;
  }

  @Test
  public void test346() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,-1.0f,0f,1503.0f,0f,0f,0f,0f,0f,675.0f,686.0f,-249.0f,525.0f,-1621.0f,1521.0f,-356,0.114050925f,-0.94395566f,-0.28560504f,0f,0f,0f ) ;
  }

  @Test
  public void test347() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,1.0f,0f,905.0f,0f,0f,0f,0f,0f,542.0f,-812.0f,222.0f,987.0f,-546.0f,3136.0f,481,-65.80501f,-38.298855f,-63.72511f,0f,0f,0f ) ;
  }

  @Test
  public void test348() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,1307.0f,0f,2.0f,0f,0f,0f,0f,0f,-330.0f,894.0f,-1797.0f,1013.0f,-976.0f,-1334.0f,-55,-0.14330691f,-0.79011315f,0.0636659f,0f,0f,0f ) ;
  }

  @Test
  public void test349() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,165.0f,0f,597.0f,0f,0f,0f,0f,0f,9.0f,314.0f,509.0f,8.0f,-383.0f,1162.0f,259,-54.27851f,-96.036575f,7.951432f,0f,0f,0f ) ;
  }

  @Test
  public void test350() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,273.0f,0f,925.0f,0f,0f,0f,0f,0f,504.0f,1475.0f,264.0f,-622.0f,-1398.0f,-1267.0f,947,-0.0164128f,-0.2934086f,-0.54445004f,0f,0f,0f ) ;
  }

  @Test
  public void test351() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,-33.0f,0f,243.0f,0f,0f,0f,0f,0f,193.0f,-383.0f,256.0f,588.0f,620.0f,590.0f,798,87.39647f,71.85415f,19.401783f,0f,0f,0f ) ;
  }

  @Test
  public void test352() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,35.0f,0f,2236.0f,0f,0f,0f,0f,0f,-502.0f,-635.0f,-835.0f,535.0f,573.0f,-953.0f,836,-49.808937f,26.82718f,9.54358f,0f,0f,0f ) ;
  }

  @Test
  public void test353() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,-370.0f,0f,194.0f,0f,0f,0f,0f,0f,-980.0f,884.0f,572.0f,-54.0f,-411.0f,542.0f,614,-54.445457f,-119.82456f,-34.148647f,0f,0f,0f ) ;
  }

  @Test
  public void test354() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,-528.0f,0f,182.0f,0f,0f,0f,0f,0f,622.0f,503.0f,-565.0f,-798.0f,1559.0f,509.0f,182,-58.064484f,-91.88268f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test355() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,-615.0f,0f,253.0f,0f,0f,0f,0f,0f,-1107.0f,-195.0f,-964.0f,-837.0f,-958.0f,-446.0f,1347,121.88977f,-100.0f,87.487755f,0f,0f,0f ) ;
  }

  @Test
  public void test356() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,-7.0f,0f,513.0f,0f,0f,0f,0f,0f,-680.0f,-696.0f,-274.0f,100.0f,875.0f,-343.0f,-427,47.04689f,178.13087f,8.042683f,0f,0f,0f ) ;
  }

  @Test
  public void test357() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,-734.0f,0f,2112.0f,0f,0f,0f,0f,0f,-193.0f,-299.0f,-520.0f,-806.0f,-1049.0f,898.0f,-948,-0.18999173f,0.6171623f,0.60656565f,0f,0f,0f ) ;
  }

  @Test
  public void test358() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,-904.0f,0f,1756.0f,0f,0f,0f,0f,0f,-1326.0f,-455.0f,-990.0f,39.0f,-623.0f,487.0f,2033,-9.009917f,124.88078f,40.38988f,0f,0f,0f ) ;
  }

  @Test
  public void test359() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1102.0f,-695.0f,0f,580.0f,0f,0f,0f,0f,0f,-634.0f,-68.0f,-2955.0f,-862.0f,-1672.0f,-820.0f,1388,-0.24436319f,0.7927826f,0.24599019f,0f,0f,0f ) ;
  }

  @Test
  public void test360() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1105.0f,104.0f,0f,321.0f,0f,0f,0f,0f,0f,-171.0f,307.0f,-1483.0f,1696.0f,728.0f,-1247.0f,-1475,-0.037049398f,0.23093155f,0.18358356f,0f,0f,0f ) ;
  }

  @Test
  public void test361() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,111.0f,98.0f,0f,34.0f,0f,0f,0f,0f,0f,-342.0f,-725.0f,258.0f,-515.0f,-44.0f,-805.0f,-248,-3.4593809f,-26.79466f,-80.19911f,0f,0f,0f ) ;
  }

  @Test
  public void test362() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1155.0f,-185.0f,0f,15.0f,0f,0f,0f,0f,0f,1761.0f,935.0f,-914.0f,-542.0f,627.0f,-208.0f,10,2.022685f,0.8566367f,0.27679193f,0f,0f,0f ) ;
  }

  @Test
  public void test363() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1156.0f,9.0f,0f,1567.0f,0f,0f,0f,0f,0f,2065.0f,-621.0f,1395.0f,1697.0f,679.0f,-266.0f,-1,-0.3552903f,0.973112f,0.06210257f,0f,0f,0f ) ;
  }

  @Test
  public void test364() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1167.0f,732.0f,0f,1430.0f,0f,0f,0f,0f,0f,-677.0f,588.0f,921.0f,217.0f,-972.0f,1458.0f,364,60.953686f,67.446495f,1.7449555f,0f,0f,0f ) ;
  }

  @Test
  public void test365() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1168.0f,1571.0f,0f,1234.0f,0f,0f,0f,0f,0f,909.0f,705.0f,-116.0f,1133.0f,-1267.0f,1171.0f,833,-0.25039333f,0.43505043f,0.6819225f,0f,0f,0f ) ;
  }

  @Test
  public void test366() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1168.0f,-929.0f,0f,480.0f,0f,0f,0f,0f,0f,-1226.0f,69.0f,628.0f,1456.0f,1595.0f,-663.0f,-5,0.33760083f,-1.1952428f,3.9530659f,0f,0f,0f ) ;
  }

  @Test
  public void test367() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1170.0f,327.0f,0f,307.0f,0f,0f,0f,0f,0f,270.0f,-2281.0f,-2490.0f,840.0f,263.0f,1165.0f,-8,-0.92269444f,1.6994537f,-0.89644825f,0f,0f,0f ) ;
  }

  @Test
  public void test368() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1177.0f,474.0f,0f,754.0f,0f,0f,0f,0f,0f,720.0f,-376.0f,78.0f,-401.0f,-876.0f,-516.0f,-597,-0.6580501f,-0.53364986f,1.5489116f,0f,0f,0f ) ;
  }

  @Test
  public void test369() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-117.81499f,32.29902f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,1.0398322f,0.03520823f,0.621645f,0f,0f,0f ) ;
  }

  @Test
  public void test370() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,11.804288f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.068491906f,0.034446165f,0.18567874f,0f,0f,0f ) ;
  }

  @Test
  public void test371() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-118.0f,1070.0f,0f,582.0f,0f,0f,0f,0f,0f,49.0f,-22.0f,-244.0f,-240.0f,47.0f,-59.0f,-158,-0.7741031f,-0.4446018f,-0.008321f,0f,0f,0f ) ;
  }

  @Test
  public void test372() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1182.0f,-1766.0f,0f,1195.0f,0f,0f,0f,0f,0f,-383.0f,737.0f,795.0f,267.0f,415.0f,-252.0f,-1601,-0.2837142f,0.5750146f,-0.6697463f,0f,0f,0f ) ;
  }

  @Test
  public void test373() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,12.0219965f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-9.791207f,-5.737103f,35.63946f,0f,0f,0f,-101,-28.789814f,11.328651f,-21.343845f,0f,0f,0f ) ;
  }

  @Test
  public void test374() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-12.0f,-1319.0f,0f,223.0f,0f,0f,0f,0f,0f,-827.0f,242.0f,-923.0f,-965.0f,-494.0f,735.0f,-287,20.72385f,-32.030647f,-1.7048938f,0f,0f,0f ) ;
  }

  @Test
  public void test375() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1219.0f,421.0f,-988.0f,885.0f,0f,0f,0f,0f,0f,470.0f,-1003.0f,-29.0f,247.0f,137.0f,787.0f,978,58.467506f,27.487034f,-3.095425f,68.13262f,0f,0f ) ;
  }

  @Test
  public void test376() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-12.2011795f,45.803093f,0f,0f,0f,0f,0f,0f,0f,-59.671272f,-10.502287f,-23.391298f,-253.0f,140.0f,-2420.0f,-704,0.10045861f,0.72772217f,0.44847375f,0f,0f,0f ) ;
  }

  @Test
  public void test377() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-123.0f,1023.0f,-825.0f,1003.0f,0f,0f,0f,0f,0f,736.0f,855.0f,-532.0f,805.0f,-1153.0f,-729.0f,210,12.397209f,-10.8679085f,-0.31525487f,-43.771744f,0f,0f ) ;
  }

  @Test
  public void test378() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,123.0f,-158.0f,0f,1236.0f,0f,0f,0f,0f,0f,-43.0f,-632.0f,282.0f,-259.0f,102.0f,190.0f,-183,0.2491822f,-0.0063383076f,-0.88543904f,0f,0f,0f ) ;
  }

  @Test
  public void test379() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1232.0f,1409.0f,0f,715.0f,0f,0f,0f,0f,0f,57.0f,-101.0f,203.0f,-2889.0f,127.0f,875.0f,-1059,-245.74417f,-12.758697f,34.7443f,0f,0f,0f ) ;
  }

  @Test
  public void test380() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1234.0f,-922.0f,0f,123.0f,0f,0f,0f,0f,0f,500.0f,272.0f,1407.0f,-1239.0f,1080.0f,687.0f,-2881,0.029112827f,-0.49633184f,-0.79329515f,0f,0f,0f ) ;
  }

  @Test
  public void test381() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1237.0f,310.0f,-895.0f,-619.0f,0f,0f,0f,0f,0f,1325.0f,-196.0f,257.0f,-1460.0f,264.0f,-1301.0f,-820,-0.82647985f,0.098401226f,-0.55429983f,-100.0f,100.0f,0f ) ;
  }

  @Test
  public void test382() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1243.0f,335.0f,0f,296.0f,0f,0f,0f,0f,0f,1298.0f,920.0f,-483.0f,737.0f,-966.0f,141.0f,535,-0.020032885f,1.1705217f,2.9493437f,0f,0f,0f ) ;
  }

  @Test
  public void test383() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1247.0f,-1204.0f,0f,1746.0f,0f,0f,0f,0f,0f,-227.0f,-18.0f,-310.0f,818.0f,-819.0f,-551.0f,276,-0.26302606f,-1.8867275f,0.4169887f,0f,0f,0f ) ;
  }

  @Test
  public void test384() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1260.0f,-2564.0f,0f,247.0f,0f,0f,0f,0f,0f,-2214.0f,618.0f,-1252.0f,-3652.0f,492.0f,-632.0f,900,0.18053566f,-0.6412275f,0.48939598f,0f,0f,0f ) ;
  }

  @Test
  public void test385() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1277.0f,627.0f,0f,179.0f,0f,0f,0f,0f,0f,-682.0f,-21.0f,-969.0f,-573.0f,1055.0f,380.0f,-1241,86.31677f,-82.680435f,-3.2270608f,0f,0f,0f ) ;
  }

  @Test
  public void test386() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,128.0f,-461.0f,964.0f,-7.0f,0f,0f,0f,0f,0f,-346.0f,-197.0f,-333.0f,-747.0f,-358.0f,733.0f,247,2.564652f,-39.593307f,-67.81568f,12.706017f,0f,0f ) ;
  }

  @Test
  public void test387() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-129.0f,-2.0f,0f,312.0f,0f,0f,0f,0f,0f,-460.0f,265.0f,795.0f,-1318.0f,-125.0f,-722.0f,542,-3.0078435f,-0.5090966f,-1.5706885f,0f,0f,0f ) ;
  }

  @Test
  public void test388() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1293.0f,184.0f,0f,771.0f,0f,0f,0f,0f,0f,-312.0f,390.0f,-364.0f,774.0f,89.0f,-568.0f,-158,-60.8942f,8.335066f,61.70492f,0f,0f,0f ) ;
  }

  @Test
  public void test389() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,13.074013f,0.0f,0f,-83.2108f,0f,0f,0f,0f,0f,120.13381f,17.959688f,50.96382f,0f,0f,0f,334,-1.0735924f,23.209126f,-6.261912f,0f,0f,0f ) ;
  }

  @Test
  public void test390() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-131.0f,1035.0f,0f,1027.0f,0f,0f,0f,0f,0f,-396.0f,2103.0f,527.0f,-819.0f,-949.0f,-337.0f,809,-0.3745583f,-0.6658455f,0.5299175f,0f,0f,0f ) ;
  }

  @Test
  public void test391() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-131.0f,-135.0f,0f,256.0f,0f,0f,0f,0f,0f,142.0f,-494.0f,458.0f,-351.0f,-109.0f,499.0f,-426,0.7035611f,0.65164477f,0.21047865f,0f,0f,0f ) ;
  }

  @Test
  public void test392() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,131.0f,-303.0f,0f,2592.0f,0f,0f,0f,0f,0f,627.0f,1542.0f,3191.0f,547.0f,-1100.0f,848.0f,374,0.013258214f,-0.7444237f,-0.6417204f,0f,0f,0f ) ;
  }

  @Test
  public void test393() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-131.0f,-936.0f,0f,727.0f,0f,0f,0f,0f,0f,746.0f,-462.0f,611.0f,741.0f,122.0f,839.0f,-545,-94.40918f,-7.7210445f,85.94694f,0f,0f,0f ) ;
  }

  @Test
  public void test394() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1317.0f,1688.0f,0f,850.0f,0f,0f,0f,0f,0f,746.0f,-84.0f,160.0f,165.0f,498.0f,-507.0f,-336,-12.098873f,-29.73305f,-54.848213f,0f,0f,0f ) ;
  }

  @Test
  public void test395() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-13.280151f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.24991725f,0.22100304f,0.7162544f,0f,0f,0f ) ;
  }

  @Test
  public void test396() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,134.0f,1413.0f,0f,1147.0f,0f,0f,0f,0f,0f,668.0f,1067.0f,-743.0f,-670.0f,374.0f,705.0f,384,-0.8190042f,0.47654974f,0.11272246f,0f,0f,0f ) ;
  }

  @Test
  public void test397() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1343.0f,-1.0f,0f,180.0f,0f,0f,0f,0f,0f,826.0f,1543.0f,-70.0f,731.0f,-978.0f,-317.0f,-992,0.24381368f,-0.28732082f,-0.029252352f,0f,0f,0f ) ;
  }

  @Test
  public void test398() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1345.0f,659.0f,0f,159.0f,0f,0f,0f,0f,0f,-295.0f,-146.0f,218.0f,159.0f,5.0f,-326.0f,-453,35.6425f,-96.02144f,-16.076107f,0f,0f,0f ) ;
  }

  @Test
  public void test399() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-135.0f,648.0f,0f,935.0f,0f,0f,0f,0f,0f,-140.0f,131.0f,-150.0f,-1787.0f,-1764.0f,110.0f,1042,34.19924f,1.9987764f,-30.160898f,0f,0f,0f ) ;
  }

  @Test
  public void test400() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1369.0f,420.0f,-1384.0f,248.0f,0f,0f,0f,0f,0f,-910.0f,1468.0f,1552.0f,421.0f,817.0f,581.0f,-147,0.6840532f,-4.516821E-4f,0.0332558f,54.67928f,0f,0f ) ;
  }

  @Test
  public void test401() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1372.0f,-561.0f,0f,449.0f,0f,0f,0f,0f,0f,-17.0f,194.0f,-114.0f,187.0f,-612.0f,-1073.0f,-1,9.932888f,17.580828f,0.959949f,0f,0f,0f ) ;
  }

  @Test
  public void test402() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1374.0f,129.0f,0f,2132.0f,0f,0f,0f,0f,0f,350.0f,-336.0f,302.0f,2106.0f,1921.0f,727.0f,1323,2.2452557f,-2.0082626f,-4.8364835f,0f,0f,0f ) ;
  }

  @Test
  public void test403() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1379.0f,413.0f,0f,1278.0f,0f,0f,0f,0f,0f,591.0f,1188.0f,155.0f,488.0f,674.0f,1048.0f,-476,-0.089490145f,-0.1714972f,-0.83759916f,0f,0f,0f ) ;
  }

  @Test
  public void test404() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1381.0f,1734.0f,-2034.0f,400.0f,0f,0f,0f,0f,0f,1160.0f,-476.0f,299.0f,140.0f,16.0f,-541.0f,-995,0.33282134f,1.7106333f,1.3275807f,26.924623f,0f,0f ) ;
  }

  @Test
  public void test405() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,14.0f,-1615.0f,0f,1932.0f,0f,0f,0f,0f,0f,574.0f,6.0f,-430.0f,345.0f,-608.0f,452.0f,918,-100.0f,82.450325f,-14.262009f,0f,0f,0f ) ;
  }

  @Test
  public void test406() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-14.267592f,38.629684f,0f,0f,0f,0f,0f,0f,0f,-61.65698f,100.0f,14.872068f,1261.0f,314.0f,-618.0f,674,0.15592726f,-0.27491808f,-0.056832157f,0f,0f,0f ) ;
  }

  @Test
  public void test407() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1449.0f,46.0f,0f,506.0f,0f,0f,0f,0f,0f,-625.0f,-590.0f,346.0f,-1256.0f,747.0f,-62.0f,-625,7.852504f,-29.126701f,-35.4826f,0f,0f,0f ) ;
  }

  @Test
  public void test408() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1451.0f,-477.0f,0f,148.0f,0f,0f,0f,0f,0f,599.0f,672.0f,335.0f,-297.0f,55.0f,421.0f,13,5.324492f,5.869351f,-2.9632509f,0f,0f,0f ) ;
  }

  @Test
  public void test409() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1458.0f,-677.0f,0f,1087.0f,0f,0f,0f,0f,0f,418.0f,-704.0f,308.0f,110.0f,-114.0f,-405.0f,-1447,0.2563429f,-0.5484661f,-2.487566f,0f,0f,0f ) ;
  }

  @Test
  public void test410() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1463.0f,631.0f,0f,4.0f,0f,0f,0f,0f,0f,-85.0f,318.0f,-210.0f,-688.0f,101.0f,414.0f,129,-232.44102f,-116.21101f,-81.49142f,0f,0f,0f ) ;
  }

  @Test
  public void test411() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1511.0f,364.0f,0f,57.0f,0f,0f,0f,0f,0f,303.0f,-16.0f,-440.0f,-348.0f,-969.0f,-442.0f,292,95.36148f,59.592876f,63.50353f,0f,0f,0f ) ;
  }

  @Test
  public void test412() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-15.199393f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-70.01012f,100.0f,-100.0f,0f,0f,0f,695,-0.51207995f,-0.847184f,-0.14160997f,0f,0f,0f ) ;
  }

  @Test
  public void test413() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1523.0f,-552.0f,0f,51.0f,0f,0f,0f,0f,0f,977.0f,-818.0f,461.0f,1113.0f,-772.0f,-806.0f,-1633,0.11842701f,0.5397921f,0.10220227f,0f,0f,0f ) ;
  }

  @Test
  public void test414() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1532.0f,1606.0f,0f,464.0f,0f,0f,0f,0f,0f,243.0f,58.0f,142.0f,476.0f,15.0f,-1682.0f,508,0.2837029f,-0.38299266f,-0.32905796f,0f,0f,0f ) ;
  }

  @Test
  public void test415() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1533.0f,-3164.0f,0f,1357.0f,0f,0f,0f,0f,0f,-86.0f,-1430.0f,-856.0f,-691.0f,334.0f,-1286.0f,671,-0.27474287f,0.35502708f,-0.32052797f,0f,0f,0f ) ;
  }

  @Test
  public void test416() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-15.356824f,0.0f,0f,100.0f,0f,0f,0f,0f,0f,-86.89477f,-14.119988f,46.907585f,0f,0f,0f,-631,7.459009f,67.11544f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test417() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1540.0f,-1175.0f,0f,501.0f,0f,0f,0f,0f,0f,168.0f,-664.0f,-401.0f,150.0f,-530.0f,940.0f,573,-0.5672465f,3.1875556f,-0.6312637f,0f,0f,0f ) ;
  }

  @Test
  public void test418() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-155.0f,1324.0f,-839.0f,-897.0f,0f,0f,0f,0f,0f,250.0f,400.0f,540.0f,-138.0f,-181.0f,613.0f,259,70.61637f,-73.20239f,-16.440508f,-13.174356f,52.073925f,0f ) ;
  }

  @Test
  public void test419() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-158.0f,122.0f,0f,-1.0f,0f,0f,0f,0f,0f,-882.0f,-760.0f,-223.0f,-36.0f,275.0f,804.0f,-172,1.4150139f,4.5628314f,68.26461f,0f,0f,0f ) ;
  }

  @Test
  public void test420() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-158.0f,994.0f,-201.0f,-264.0f,0f,0f,0f,0f,0f,692.0f,423.0f,323.0f,-118.0f,802.0f,-790.0f,-807,0.2358591f,-60.73089f,-11.375823f,-41.412674f,0f,0f ) ;
  }

  @Test
  public void test421() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1591.0f,-108.0f,0f,256.0f,0f,0f,0f,0f,0f,-5.0f,105.0f,421.0f,2167.0f,1116.0f,743.0f,-1246,43.248985f,-29.599197f,-62.681816f,0f,0f,0f ) ;
  }

  @Test
  public void test422() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1607.0f,1974.0f,0f,28.0f,0f,0f,0f,0f,0f,-856.0f,114.0f,523.0f,245.0f,317.0f,332.0f,-536,0.47640455f,0.32034922f,-0.64161444f,0f,0f,0f ) ;
  }

  @Test
  public void test423() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1627.0f,678.0f,188.0f,0.0f,0f,0f,0f,0f,0f,-615.0f,-10.0f,-1366.0f,124.0f,-290.0f,-767.0f,752,0.59964913f,-0.52374536f,-0.2504546f,-2.7357786f,0f,0f ) ;
  }

  @Test
  public void test424() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1630.0f,378.0f,574.0f,2027.0f,0f,0f,0f,0f,0f,386.0f,-266.0f,277.0f,1410.0f,-1221.0f,-1819.0f,-377,-0.14437647f,-0.1656216f,-0.20236762f,17.980404f,-21.55499f,0f ) ;
  }

  @Test
  public void test425() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1640.0f,500.0f,247.0f,-224.0f,0f,0f,0f,0f,0f,829.0f,669.0f,-1544.0f,-1177.0f,-144.0f,-3171.0f,-886,-0.4393037f,-0.7381853f,0.5119519f,-92.34688f,0f,0f ) ;
  }

  @Test
  public void test426() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1652.0f,-860.0f,0f,1029.0f,0f,0f,0f,0f,0f,-1554.0f,-1783.0f,-567.0f,236.0f,-102.0f,-329.0f,-62,0.22439133f,0.010821558f,2.131208f,0f,0f,0f ) ;
  }

  @Test
  public void test427() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1681.0f,-1160.0f,0f,217.0f,0f,0f,0f,0f,0f,543.0f,-461.0f,-853.0f,-219.0f,-971.0f,385.0f,1381,-15.006375f,12.745001f,108.16899f,0f,0f,0f ) ;
  }

  @Test
  public void test428() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1707.0f,494.0f,1050.0f,817.0f,0f,0f,0f,0f,0f,-1287.0f,846.0f,-1095.0f,941.0f,2657.0f,-2691.0f,-209,0.7603479f,-0.16811678f,-0.07730497f,-11.139156f,0f,0f ) ;
  }

  @Test
  public void test429() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1723.0f,3.0f,0f,55.0f,0f,0f,0f,0f,0f,-50.0f,245.0f,-119.0f,-601.0f,-195.0f,-146.0f,-277,0.565351f,-0.56214046f,2.1971934f,0f,0f,0f ) ;
  }

  @Test
  public void test430() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1724.0f,1141.0f,-2357.0f,873.0f,0f,0f,0f,0f,0f,-689.0f,1115.0f,-550.0f,-746.0f,-1369.0f,882.0f,591,-0.6045821f,-0.7925399f,0.079756334f,32.410057f,0f,0f ) ;
  }

  @Test
  public void test431() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-173.0f,-1633.0f,0f,155.0f,0f,0f,0f,0f,0f,85.0f,-441.0f,-667.0f,-690.0f,-838.0f,-701.0f,558,0.9711961f,-0.03559009f,0.1904544f,0f,0f,0f ) ;
  }

  @Test
  public void test432() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-173.0f,88.0f,0f,1015.0f,0f,0f,0f,0f,0f,492.0f,333.0f,663.0f,758.0f,180.0f,-651.0f,235,86.18055f,-116.87296f,-5.3387575f,0f,0f,0f ) ;
  }

  @Test
  public void test433() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1746.0f,49.0f,-1903.0f,969.0f,0f,0f,0f,0f,0f,1163.0f,-675.0f,-15.0f,-429.0f,812.0f,-147.0f,928,-0.753526f,-0.05169324f,0.6553827f,96.68412f,0f,0f ) ;
  }

  @Test
  public void test434() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-176.0f,-697.0f,0f,255.0f,0f,0f,0f,0f,0f,-413.0f,-194.0f,924.0f,-277.0f,-1239.0f,131.0f,-1657,-0.026740372f,0.09232501f,0.0030310806f,0f,0f,0f ) ;
  }

  @Test
  public void test435() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-177.0f,-928.0f,232.0f,71.0f,0f,0f,0f,0f,0f,948.0f,-36.0f,-671.0f,6.0f,36.0f,20.0f,461,-51.718807f,-37.909397f,-85.90162f,21.11421f,16.200102f,74.36931f ) ;
  }

  @Test
  public void test436() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1778.0f,-585.0f,0f,253.0f,0f,0f,0f,0f,0f,429.0f,-2169.0f,1012.0f,201.0f,-231.0f,-403.0f,-562,-0.23644663f,-0.06601006f,-0.5226572f,0f,0f,0f ) ;
  }

  @Test
  public void test437() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1811.0f,1.0f,0f,904.0f,0f,0f,0f,0f,0f,1026.0f,-1443.0f,480.0f,-422.0f,-461.0f,-481.0f,-1,-2.3945339f,11.024269f,-2.502172f,0f,0f,0f ) ;
  }

  @Test
  public void test438() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-18.437561f,-80.47737f,0f,46.123425f,0f,0f,0f,0f,0f,-10.597893f,-0.8886694f,-62.653748f,0f,0f,0f,-468,-76.252754f,90.48236f,38.53393f,0f,0f,0f ) ;
  }

  @Test
  public void test439() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1852.0f,975.0f,0f,3.0f,0f,0f,0f,0f,0f,672.0f,819.0f,683.0f,-914.0f,-1076.0f,711.0f,1511,-0.8984861f,-0.0054705977f,0.3905303f,0f,0f,0f ) ;
  }

  @Test
  public void test440() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,186.0f,736.0f,859.0f,550.0f,0f,0f,0f,0f,0f,663.0f,521.0f,-943.0f,438.0f,-756.0f,675.0f,362,-50.868935f,0.58578944f,99.98633f,-14.4593315f,73.857506f,0f ) ;
  }

  @Test
  public void test441() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-189.0f,317.0f,0f,83.0f,0f,0f,0f,0f,0f,-837.0f,-599.0f,-331.0f,389.0f,-825.0f,508.0f,690,-66.66684f,184.54799f,89.55131f,0f,0f,0f ) ;
  }

  @Test
  public void test442() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,19.0f,-882.0f,0f,2443.0f,0f,0f,0f,0f,0f,562.0f,655.0f,-254.0f,556.0f,-748.0f,-710.0f,513,0.98691946f,-0.40366507f,1.1472259f,0f,0f,0f ) ;
  }

  @Test
  public void test443() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,194.0f,910.0f,795.0f,-577.0f,0f,0f,0f,0f,0f,283.0f,-869.0f,-224.0f,255.0f,-338.0f,-678.0f,-563,95.52221f,-31.932528f,27.4756f,0f,30.664288f,0f ) ;
  }

  @Test
  public void test444() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.9588686f,0.0f,0f,19.724745f,0f,0f,0f,0f,0f,27.40911f,14.442529f,-42.444347f,0f,0f,0f,1004,-0.09745664f,0.6711676f,0.38931113f,0f,0f,0f ) ;
  }

  @Test
  public void test445() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,19.63127f,51.7068f,0f,0f,0f,0f,0f,0f,0f,-36.332024f,-64.906555f,-94.6896f,809.0f,286.0f,648.0f,-484,21.109936f,80.1238f,86.161095f,0f,0f,0f ) ;
  }

  @Test
  public void test446() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-19.802845f,0.0f,0f,0f,0f,0f,0f,0f,0f,-87.34005f,-24.224123f,-32.134598f,0f,0f,0f,-585,0.45018092f,0.22184138f,-0.71750104f,0f,0f,0f ) ;
  }

  @Test
  public void test447() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,20.05094f,0.0f,0f,18.724592f,0f,0f,0f,0f,0f,-91.02556f,36.977516f,69.66749f,0f,0f,0f,276,72.60983f,-24.515306f,-46.630527f,0f,0f,0f ) ;
  }

  @Test
  public void test448() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-20.0f,0.0f,0f,361.0f,0f,0f,0f,0f,0f,-853.0f,251.0f,858.0f,693.0f,-432.0f,109.0f,-51,10.568531f,-65.95774f,-23.436424f,0f,0f,0f ) ;
  }

  @Test
  public void test449() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2038.0f,871.0f,-840.0f,-1206.0f,0f,0f,0f,0f,0f,149.0f,767.0f,689.0f,-837.0f,1961.0f,-108.0f,754,0.6172544f,0.18100768f,-0.76565874f,-90.38176f,71.50479f,0f ) ;
  }

  @Test
  public void test450() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2038.0f,99.0f,0f,1312.0f,0f,0f,0f,0f,0f,537.0f,311.0f,-1704.0f,1607.0f,-797.0f,-342.0f,516,0.026914457f,0.20336027f,0.11174401f,0f,0f,0f ) ;
  }

  @Test
  public void test451() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-205.0f,189.0f,0f,855.0f,0f,0f,0f,0f,0f,-258.0f,323.0f,451.0f,389.0f,759.0f,-321.0f,-1272,56.5568f,-96.57939f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test452() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,205.0f,569.0f,0f,139.0f,0f,0f,0f,0f,0f,460.0f,-542.0f,586.0f,-246.0f,-1147.0f,-868.0f,505,-15.961007f,155.48651f,23.049284f,0f,0f,0f ) ;
  }

  @Test
  public void test453() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,209.0f,274.0f,0f,3.0f,0f,0f,0f,0f,0f,-953.0f,-614.0f,-542.0f,-901.0f,244.0f,801.0f,1581,0.51363575f,-0.04534697f,-0.0707655f,0f,0f,0f ) ;
  }

  @Test
  public void test454() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,-1.0f,0f,536.0f,0f,0f,0f,0f,0f,156.0f,-36.0f,1589.0f,-1622.0f,939.0f,161.0f,-939,38.263783f,-12.494724f,-11.161551f,0f,0f,0f ) ;
  }

  @Test
  public void test455() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,-1307.0f,0f,1009.0f,0f,0f,0f,0f,0f,-21.0f,369.0f,424.0f,928.0f,489.0f,-374.0f,-439,0.45297295f,-4.097409f,2.01391f,0f,0f,0f ) ;
  }

  @Test
  public void test456() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,2572.0f,0f,242.0f,0f,0f,0f,0f,0f,102.0f,-208.0f,-27.0f,-868.0f,-298.0f,-991.0f,961,-99.821396f,86.59382f,-115.61253f,0f,0f,0f ) ;
  }

  @Test
  public void test457() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,-2857.0f,0f,925.0f,0f,0f,0f,0f,0f,233.0f,26.0f,126.0f,134.0f,767.0f,-406.0f,128,-7.6887064f,83.94935f,-75.07858f,0f,0f,0f ) ;
  }

  @Test
  public void test458() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,634.0f,-1857.0f,-1214.0f,0f,0f,0f,0f,0f,449.0f,-1479.0f,-53.0f,2325.0f,-142.0f,732.0f,-109,-0.56258094f,0.43946964f,-0.35962728f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test459() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,929.0f,241.0f,-113.0f,0f,0f,0f,0f,0f,-21.0f,-534.0f,570.0f,-396.0f,-66.0f,398.0f,-41,-43.665794f,35.77942f,-4.497236f,27.755846f,0f,0f ) ;
  }

  @Test
  public void test460() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-210.0f,-1613.0f,0f,1791.0f,0f,0f,0f,0f,0f,-939.0f,1288.0f,588.0f,-941.0f,1151.0f,-368.0f,-6,-0.9955971f,0.00759464f,0.3076971f,0f,0f,0f ) ;
  }

  @Test
  public void test461() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-210.0f,-210.0f,0f,701.0f,0f,0f,0f,0f,0f,-1416.0f,222.0f,10.0f,77.0f,548.0f,-1211.0f,-989,-0.06480378f,-0.35307097f,-1.3380394f,0f,0f,0f ) ;
  }

  @Test
  public void test462() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-21.26858f,-100.0f,0f,0.0f,0f,0f,0f,0f,0f,10.059606f,-70.0701f,87.12342f,0f,0f,0f,948,-0.3977983f,-0.20126466f,-0.74935395f,0f,0f,0f ) ;
  }

  @Test
  public void test463() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-21.279226f,50.794018f,0f,0f,0f,0f,0f,0f,0f,100.0f,-100.0f,-20.172062f,-2090.0f,-511.0f,-1156.0f,-403,-0.72168607f,-0.121398315f,-0.68149227f,0f,0f,0f ) ;
  }

  @Test
  public void test464() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-214.0f,-1681.0f,0f,253.0f,0f,0f,0f,0f,0f,80.0f,267.0f,-2558.0f,977.0f,-757.0f,-165.0f,-519,166.5473f,43.509045f,64.42537f,0f,0f,0f ) ;
  }

  @Test
  public void test465() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-215.0f,-1193.0f,0f,1875.0f,0f,0f,0f,0f,0f,488.0f,-1219.0f,1651.0f,798.0f,-11.0f,-325.0f,1,-0.0363888f,-0.34594157f,-0.038279746f,0f,0f,0f ) ;
  }

  @Test
  public void test466() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2154.0f,2575.0f,0f,-412.0f,0f,0f,0f,0f,0f,-950.0f,-909.0f,-501.0f,1375.0f,529.0f,-674.0f,497,-0.1160183f,0.9092788f,-0.3996896f,0f,0f,0f ) ;
  }

  @Test
  public void test467() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-216.0f,1327.0f,0f,-1188.0f,0f,0f,0f,0f,0f,25.0f,749.0f,123.0f,-490.0f,768.0f,352.0f,1508,0.20251726f,-0.5526572f,-0.1404867f,0f,0f,0f ) ;
  }

  @Test
  public void test468() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-216.0f,918.0f,0f,590.0f,0f,0f,0f,0f,0f,738.0f,-306.0f,647.0f,671.0f,-417.0f,-893.0f,316,-82.13509f,59.213516f,83.87737f,0f,0f,0f ) ;
  }

  @Test
  public void test469() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-218.0f,-837.0f,0f,822.0f,0f,0f,0f,0f,0f,-945.0f,-586.0f,893.0f,-858.0f,-777.0f,610.0f,726,51.913555f,89.63008f,-86.18811f,0f,0f,0f ) ;
  }

  @Test
  public void test470() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2182.0f,1908.0f,0f,827.0f,0f,0f,0f,0f,0f,389.0f,412.0f,-593.0f,-503.0f,245.0f,-160.0f,241,-0.036427144f,0.9442138f,1.2626052f,0f,0f,0f ) ;
  }

  @Test
  public void test471() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2191.0f,1824.0f,0f,540.0f,0f,0f,0f,0f,0f,460.0f,467.0f,-353.0f,-1409.0f,359.0f,-1362.0f,163,0.7048216f,-0.34629226f,0.46205747f,0f,0f,0f ) ;
  }

  @Test
  public void test472() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-220.0f,547.0f,-303.0f,863.0f,0f,0f,0f,0f,0f,-651.0f,-710.0f,561.0f,914.0f,594.0f,852.0f,-596,-61.764465f,72.05307f,19.516954f,-99.60493f,-84.31648f,0f ) ;
  }

  @Test
  public void test473() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-222.0f,1703.0f,-681.0f,2021.0f,0f,0f,0f,0f,0f,1092.0f,608.0f,875.0f,-298.0f,958.0f,791.0f,453,-0.7938344f,0.27046615f,-0.48812672f,-99.083176f,-57.004642f,-56.13458f ) ;
  }

  @Test
  public void test474() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,222.0f,624.0f,177.0f,491.0f,0f,0f,0f,0f,0f,-738.0f,-110.0f,402.0f,426.0f,674.0f,628.0f,185,61.28368f,79.07216f,23.535757f,38.869465f,0f,0f ) ;
  }

  @Test
  public void test475() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,224.0f,856.0f,0f,2114.0f,0f,0f,0f,0f,0f,-427.0f,590.0f,-926.0f,-15.0f,9.0f,12.0f,1976,-100.0f,74.08533f,93.315704f,0f,0f,0f ) ;
  }

  @Test
  public void test476() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,225.0f,-21.0f,0f,58.0f,0f,0f,0f,0f,0f,-469.0f,284.0f,283.0f,-658.0f,500.0f,-1592.0f,-931,85.554695f,1.5325216f,28.978712f,0f,0f,0f ) ;
  }

  @Test
  public void test477() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2293.0f,680.0f,0f,1999.0f,0f,0f,0f,0f,0f,116.0f,58.0f,-155.0f,-288.0f,159.0f,-157.0f,212,-0.19056697f,-0.7095587f,-0.14435959f,0f,0f,0f ) ;
  }

  @Test
  public void test478() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,23.288551f,0.0f,0f,100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.97376955f,-1.9881696f,-1.9485911f,0f,0f,0f ) ;
  }

  @Test
  public void test479() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-236.0f,208.0f,737.0f,4.0f,0f,0f,0f,0f,0f,377.0f,614.0f,149.0f,-397.0f,808.0f,170.0f,509,18.48741f,-28.794827f,-16.743555f,46.633183f,0f,0f ) ;
  }

  @Test
  public void test480() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-23.739033f,-0.007853766f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.06040063f,-0.1260003f,-0.0063582887f,0f,0f,0f ) ;
  }

  @Test
  public void test481() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-241.0f,172.0f,0f,20.0f,0f,0f,0f,0f,0f,-525.0f,-70.0f,774.0f,1811.0f,650.0f,670.0f,4,0.39382496f,0.2240579f,-1.9738078f,0f,0f,0f ) ;
  }

  @Test
  public void test482() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,247.0f,-165.0f,0f,1740.0f,0f,0f,0f,0f,0f,731.0f,825.0f,413.0f,6.0f,215.0f,-336.0f,-117,0.18289927f,-0.9478503f,-0.26101285f,0f,0f,0f ) ;
  }

  @Test
  public void test483() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2472.0f,787.0f,0f,390.0f,0f,0f,0f,0f,0f,-707.0f,667.0f,-1308.0f,-937.0f,-701.0f,149.0f,1200,35.369507f,-96.25787f,-20.503698f,0f,0f,0f ) ;
  }

  @Test
  public void test484() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,248.0f,893.0f,0f,-307.0f,0f,0f,0f,0f,0f,748.0f,-685.0f,209.0f,834.0f,-190.0f,944.0f,705,-0.179065f,0.24776311f,-0.7062136f,0f,0f,0f ) ;
  }

  @Test
  public void test485() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-25.157425f,42.139034f,0f,0f,0f,0f,0f,0f,0f,35.433544f,0.29931316f,-36.093117f,-23.0f,-764.0f,566.0f,866,-0.6007294f,-0.5026637f,-0.59388024f,0f,0f,0f ) ;
  }

  @Test
  public void test486() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2551.0f,-737.0f,0f,255.0f,0f,0f,0f,0f,0f,339.0f,-1540.0f,814.0f,-195.0f,-564.0f,336.0f,-642,0.8569426f,0.47991616f,-0.025453605f,0f,0f,0f ) ;
  }

  @Test
  public void test487() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-25.703592f,42.285145f,0f,0f,0f,0f,0f,0f,0f,-12.759065f,29.618525f,-47.14424f,-954.0f,-520.0f,-69.0f,5,-0.017874867f,-0.13848487f,0.26160216f,0f,0f,0f ) ;
  }

  @Test
  public void test488() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-259.0f,-1442.0f,0f,254.0f,0f,0f,0f,0f,0f,-379.0f,1028.0f,1268.0f,737.0f,729.0f,1571.0f,-399,0.047291305f,-0.4387871f,-0.11332117f,0f,0f,0f ) ;
  }

  @Test
  public void test489() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,261.0f,441.0f,0f,465.0f,0f,0f,0f,0f,0f,-200.0f,-141.0f,519.0f,55.0f,358.0f,514.0f,-257,-74.99542f,27.450375f,-99.38188f,0f,0f,0f ) ;
  }

  @Test
  public void test490() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-263.0f,-154.0f,0f,260.0f,0f,0f,0f,0f,0f,-51.0f,-696.0f,-639.0f,-372.0f,-644.0f,-2939.0f,-592,-0.043388143f,-0.072943985f,0.9403105f,0f,0f,0f ) ;
  }

  @Test
  public void test491() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2643.0f,-851.0f,0f,180.0f,0f,0f,0f,0f,0f,528.0f,-953.0f,1444.0f,-616.0f,-1302.0f,1632.0f,972,-0.65798473f,0.6345734f,0.054239366f,0f,0f,0f ) ;
  }

  @Test
  public void test492() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,26.46651f,0f,0f,0f,0f,0f,0f,0f,0f,-78.543884f,79.26633f,13.943592f,0f,0f,0f,-2,0.9192535f,-0.13993508f,0.36795527f,0f,0f,0f ) ;
  }

  @Test
  public void test493() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-269.0f,1291.0f,-1155.0f,-808.0f,0f,0f,0f,0f,0f,541.0f,197.0f,962.0f,315.0f,-1058.0f,573.0f,114,-0.077784136f,0.27027124f,-0.06795875f,-80.63516f,0f,0f ) ;
  }

  @Test
  public void test494() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2720.0f,1581.0f,0f,0.0f,0f,0f,0f,0f,0f,442.0f,1111.0f,137.0f,420.0f,-131.0f,-557.0f,1762,-0.6431242f,0.058808222f,-0.682066f,0f,0f,0f ) ;
  }

  @Test
  public void test495() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-280.0f,832.0f,0f,153.0f,0f,0f,0f,0f,0f,-75.0f,-3.0f,25.0f,294.0f,6.0f,883.0f,-440,50.797108f,69.34458f,-79.618004f,0f,0f,0f ) ;
  }

  @Test
  public void test496() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,28.551472f,-67.61934f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.9528116f,0.0752194f,-0.18143068f,0f,0f,0f ) ;
  }

  @Test
  public void test497() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,287.0f,-711.0f,0f,427.0f,0f,0f,0f,0f,0f,-626.0f,-345.0f,811.0f,466.0f,-312.0f,227.0f,143,120.90156f,8.633372f,-1.1627527f,0f,0f,0f ) ;
  }

  @Test
  public void test498() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.902226f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,100.0f,-2.5008476f,0f,0f,0f,1,0.44615078f,-0.83264494f,-0.32810348f,0f,0f,0f ) ;
  }

  @Test
  public void test499() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-29.32071f,0f,0f,0f,0f,0f,0f,0f,0f,1.5965427f,-6.9541926f,-65.981384f,0f,0f,0f,-417,0.16724762f,-0.5970013f,0.095216945f,0f,0f,0f ) ;
  }

  @Test
  public void test500() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-295.0f,621.0f,0f,-655.0f,0f,0f,0f,0f,0f,1218.0f,1415.0f,-155.0f,-1698.0f,-21.0f,-827.0f,324,-0.20388517f,-0.20615694f,-0.28802618f,0f,0f,0f ) ;
  }

  @Test
  public void test501() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,307.0f,339.0f,0f,26.0f,0f,0f,0f,0f,0f,-304.0f,-1596.0f,-264.0f,-770.0f,-537.0f,-774.0f,-425,24.231823f,43.129143f,-85.1058f,0f,0f,0f ) ;
  }

  @Test
  public void test502() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,309.0f,-562.0f,299.0f,-278.0f,0f,0f,0f,0f,0f,374.0f,430.0f,-406.0f,963.0f,449.0f,186.0f,-532,89.92215f,-62.220726f,-51.88571f,36.037354f,35.726562f,0f ) ;
  }

  @Test
  public void test503() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3.0f,-1292.0f,0f,367.0f,0f,0f,0f,0f,0f,1333.0f,236.0f,-892.0f,1036.0f,138.0f,-379.0f,2003,-0.7966158f,0.4676373f,0.29709205f,0f,0f,0f ) ;
  }

  @Test
  public void test504() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,3.0f,-1512.0f,0f,1442.0f,0f,0f,0f,0f,0f,427.0f,124.0f,358.0f,-828.0f,844.0f,702.0f,-595,2.8282166f,-2.790159f,-2.4069092f,0f,0f,0f ) ;
  }

  @Test
  public void test505() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,3.0f,542.0f,0f,-283.0f,0f,0f,0f,0f,0f,-944.0f,580.0f,-160.0f,-244.0f,-527.0f,-1143.0f,675,0.36390173f,-0.44053113f,-0.23283035f,0f,0f,0f ) ;
  }

  @Test
  public void test506() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3.0f,995.0f,0f,565.0f,0f,0f,0f,0f,0f,-965.0f,1565.0f,872.0f,884.0f,-821.0f,568.0f,1248,53.158756f,-81.724075f,-23.008883f,0f,0f,0f ) ;
  }

  @Test
  public void test507() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-316.0f,-48.0f,0f,296.0f,0f,0f,0f,0f,0f,965.0f,724.0f,-404.0f,454.0f,-258.0f,302.0f,-857,29.820147f,-89.43015f,-69.91633f,0f,0f,0f ) ;
  }

  @Test
  public void test508() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-31.71772f,0f,0f,0f,0f,0f,0f,0f,0f,15.344144f,12.269396f,92.01463f,0f,0f,0f,60,22.127764f,-5.5770054f,-15.026936f,0f,0f,0f ) ;
  }

  @Test
  public void test509() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,318.0f,645.0f,0f,-575.0f,0f,0f,0f,0f,0f,-869.0f,-776.0f,-811.0f,-94.0f,797.0f,-821.0f,562,39.28847f,-13.5971775f,11.010418f,0f,0f,0f ) ;
  }

  @Test
  public void test510() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-323.0f,78.0f,353.0f,-682.0f,0f,0f,0f,0f,0f,-405.0f,845.0f,703.0f,91.0f,72.0f,-252.0f,-117,-17.047918f,66.42241f,59.97747f,-19.174149f,0f,0f ) ;
  }

  @Test
  public void test511() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3245.0f,-953.0f,0f,215.0f,0f,0f,0f,0f,0f,11.0f,-35.0f,-42.0f,-382.0f,-400.0f,232.0f,821,72.97549f,98.06617f,115.52445f,0f,0f,0f ) ;
  }

  @Test
  public void test512() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-326.0f,856.0f,22.0f,16.0f,0f,0f,0f,0f,0f,-621.0f,-810.0f,47.0f,-406.0f,-311.0f,331.0f,222,64.17155f,92.131386f,-78.04395f,0f,27.012428f,-89.17148f ) ;
  }

  @Test
  public void test513() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,33.105038f,0.0f,0f,0f,0f,0f,0f,0f,0f,-72.9113f,-8.697732f,-100.0f,0f,0f,0f,687,0.64757967f,-0.6937913f,-0.23540084f,0f,0f,0f ) ;
  }

  @Test
  public void test514() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-333.0f,-1109.0f,0f,1811.0f,0f,0f,0f,0f,0f,1107.0f,64.0f,320.0f,854.0f,-377.0f,2845.0f,-25,-0.104480356f,0.50250447f,-1.1180212f,0f,0f,0f ) ;
  }

  @Test
  public void test515() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-336.0f,-1200.0f,0f,1210.0f,0f,0f,0f,0f,0f,1198.0f,1085.0f,22.0f,627.0f,-238.0f,186.0f,1073,-0.6653302f,0.73275864f,0.09192853f,0f,0f,0f ) ;
  }

  @Test
  public void test516() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,33.77322f,-85.48125f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.03445153f,0.6586526f,0.19454043f,0f,0f,0f ) ;
  }

  @Test
  public void test517() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,34.13645f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.17959438f,0.69664764f,-0.2510476f,0f,0f,0f ) ;
  }

  @Test
  public void test518() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-34.68919f,-9.24464f,0f,0f,0f,0f,0f,0f,0f,1.1081008f,36.42459f,-0.934637f,0f,0f,0f,1,0.05594803f,-0.68773526f,-0.72380245f,0f,0f,0f ) ;
  }

  @Test
  public void test519() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,347.0f,577.0f,0f,122.0f,0f,0f,0f,0f,0f,-970.0f,-104.0f,-715.0f,-1371.0f,-139.0f,899.0f,520,0.6020505f,0.7092758f,-0.1449776f,0f,0f,0f ) ;
  }

  @Test
  public void test520() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-348.0f,1284.0f,-460.0f,354.0f,0f,0f,0f,0f,0f,-166.0f,-177.0f,186.0f,681.0f,-322.0f,-52.0f,14,100.0f,-91.2852f,2.379136f,-93.451035f,-75.489006f,100.0f ) ;
  }

  @Test
  public void test521() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,35.0f,178.0f,0f,446.0f,0f,0f,0f,0f,0f,966.0f,-434.0f,801.0f,-326.0f,-936.0f,-431.0f,-950,-57.877403f,45.398483f,-34.282463f,0f,0f,0f ) ;
  }

  @Test
  public void test522() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,3510.0f,1539.0f,0f,2202.0f,0f,0f,0f,0f,0f,-138.0f,-690.0f,30.0f,-786.0f,121.0f,-821.0f,-665,0.44997424f,-0.20003423f,-2.530906f,0f,0f,0f ) ;
  }

  @Test
  public void test523() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-352.0f,-117.0f,0f,137.0f,0f,0f,0f,0f,0f,-302.0f,864.0f,518.0f,2.0f,574.0f,-130.0f,-695,7.7940326f,12.689191f,-78.28298f,0f,0f,0f ) ;
  }

  @Test
  public void test524() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,35.50287f,-1.4210855E-14f,0f,-0.0f,0f,0f,0f,0f,0f,-99.748024f,-100.0f,100.0f,0f,0f,0f,-1321,0.44021934f,0.594854f,0.6725739f,0f,0f,0f ) ;
  }

  @Test
  public void test525() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,358.0f,1601.0f,0f,968.0f,0f,0f,0f,0f,0f,-420.0f,599.0f,320.0f,-919.0f,-6.0f,-865.0f,985,0.052827556f,0.110994756f,-0.9331965f,0f,0f,0f ) ;
  }

  @Test
  public void test526() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-35.834293f,0.0f,0f,-12.031762f,0f,0f,0f,0f,0f,-26.734564f,-59.432034f,-10.446167f,0f,0f,0f,-143,0.84562206f,0.35418606f,0.3993439f,0f,0f,0f ) ;
  }

  @Test
  public void test527() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,35.84935f,99.69312f,0f,0f,0f,0f,0f,0f,0f,26.642519f,-20.140291f,-97.58325f,0f,0f,0f,-301,-0.40093362f,-0.5413015f,0.5839975f,0f,0f,0f ) ;
  }

  @Test
  public void test528() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-359.0f,-270.0f,0f,617.0f,0f,0f,0f,0f,0f,-761.0f,-854.0f,-897.0f,-769.0f,1469.0f,-287.0f,-1359,-0.052092142f,-0.08923217f,0.4134279f,0f,0f,0f ) ;
  }

  @Test
  public void test529() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,365.0f,-585.0f,0f,295.0f,0f,0f,0f,0f,0f,-556.0f,759.0f,573.0f,-924.0f,-1141.0f,-555.0f,94,136.22716f,33.21138f,-93.02705f,0f,0f,0f ) ;
  }

  @Test
  public void test530() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,36.542446f,-5.8702613E-18f,0f,-9.862721E-32f,0f,0f,0f,0f,0f,-4.653783f,-100.0f,21.823753f,0f,0f,0f,195,0.56014425f,-0.02317412f,-0.82813066f,0f,0f,0f ) ;
  }

  @Test
  public void test531() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-37.0f,179.0f,0f,1033.0f,0f,0f,0f,0f,0f,754.0f,-1163.0f,-1274.0f,485.0f,522.0f,-1433.0f,-758,0.12799169f,0.544144f,0.8022855f,0f,0f,0f ) ;
  }

  @Test
  public void test532() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-37.0f,799.0f,-197.0f,544.0f,0f,0f,0f,0f,0f,-374.0f,-47.0f,185.0f,-645.0f,288.0f,1229.0f,-782,0.27433565f,-0.10064645f,0.14766482f,-18.574194f,-84.16878f,0f ) ;
  }

  @Test
  public void test533() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3.736511f,69.83546f,0f,0f,0f,0f,0f,0f,0f,-30.462692f,-56.212658f,85.92734f,0f,0f,0f,-26,-55.034943f,-33.626186f,-66.02191f,0f,0f,0f ) ;
  }

  @Test
  public void test534() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,374.0f,1403.0f,0f,862.0f,0f,0f,0f,0f,0f,-670.0f,999.0f,511.0f,1103.0f,949.0f,-2289.0f,-655,0.53644747f,0.02405718f,-0.8439356f,0f,0f,0f ) ;
  }

  @Test
  public void test535() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-37.5552f,73.12813f,0f,0f,0f,0f,0f,0f,0f,84.58824f,56.354027f,-31.269184f,913.0f,496.0f,953.0f,-78,-75.62406f,57.79802f,37.52343f,0f,0f,0f ) ;
  }

  @Test
  public void test536() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-376.0f,1463.0f,0f,610.0f,0f,0f,0f,0f,0f,-804.0f,176.0f,1351.0f,483.0f,819.0f,181.0f,-1328,-5.1484294f,-2.2469668f,-2.776396f,0f,0f,0f ) ;
  }

  @Test
  public void test537() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-378.0f,122.0f,-785.0f,1042.0f,0f,0f,0f,0f,0f,7.0f,427.0f,1393.0f,1028.0f,316.0f,316.0f,-1268,0.1773773f,-0.44393003f,-0.58938706f,-66.532166f,-11.817391f,0f ) ;
  }

  @Test
  public void test538() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-38.0f,-1461.0f,0f,568.0f,0f,0f,0f,0f,0f,1046.0f,334.0f,369.0f,-244.0f,1433.0f,-596.0f,422,-0.0010712114f,-0.46033493f,0.21340676f,0f,0f,0f ) ;
  }

  @Test
  public void test539() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-381.0f,866.0f,0f,1110.0f,0f,0f,0f,0f,0f,-460.0f,-503.0f,-745.0f,737.0f,-129.0f,-368.0f,251,100.0f,100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test540() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,385.0f,536.0f,0f,949.0f,0f,0f,0f,0f,0f,-1205.0f,132.0f,868.0f,-688.0f,-800.0f,382.0f,433,0.1417188f,0.5539121f,0.112505496f,0f,0f,0f ) ;
  }

  @Test
  public void test541() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,385.0f,-952.0f,0f,1969.0f,0f,0f,0f,0f,0f,793.0f,-1139.0f,-160.0f,-1625.0f,667.0f,-53.0f,667,0.06769081f,0.36626932f,-0.81667453f,0f,0f,0f ) ;
  }

  @Test
  public void test542() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-390.0f,-495.0f,0f,1927.0f,0f,0f,0f,0f,0f,-327.0f,-879.0f,-1215.0f,-7.0f,20.0f,-12.0f,2,-5.531194f,-0.65571135f,0.2256526f,0f,0f,0f ) ;
  }

  @Test
  public void test543() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,391.0f,-477.0f,0f,327.0f,0f,0f,0f,0f,0f,280.0f,-723.0f,-318.0f,-763.0f,-741.0f,466.0f,-374,-73.3912f,-50.165604f,99.26893f,0f,0f,0f ) ;
  }

  @Test
  public void test544() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-392.0f,-694.0f,0f,1567.0f,0f,0f,0f,0f,0f,-109.0f,1913.0f,-780.0f,840.0f,-541.0f,-1445.0f,722,-0.014325071f,-0.09418849f,0.14478196f,0f,0f,0f ) ;
  }

  @Test
  public void test545() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,393.0f,-425.0f,0f,685.0f,0f,0f,0f,0f,0f,605.0f,-445.0f,-351.0f,595.0f,-37.0f,-412.0f,-560,83.89256f,82.30135f,46.79137f,0f,0f,0f ) ;
  }

  @Test
  public void test546() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-397.0f,983.0f,0f,185.0f,0f,0f,0f,0f,0f,-56.0f,-200.0f,579.0f,-1044.0f,1007.0f,254.0f,-2095,0.8624303f,-0.019106109f,-0.16256818f,0f,0f,0f ) ;
  }

  @Test
  public void test547() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3973.0f,326.0f,0f,-489.0f,0f,0f,0f,0f,0f,514.0f,-434.0f,-1648.0f,1144.0f,-133.0f,-910.0f,19,0.28246188f,-0.25681058f,-3.2904124f,0f,0f,0f ) ;
  }

  @Test
  public void test548() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-400.0f,-1808.0f,0f,255.0f,0f,0f,0f,0f,0f,778.0f,-1445.0f,402.0f,-76.0f,-937.0f,672.0f,1118,-7.338162f,22.877155f,63.99969f,0f,0f,0f ) ;
  }

  @Test
  public void test549() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-40.05281f,-100.0f,0f,-174.55824f,0f,0f,0f,0f,0f,40.505756f,77.199486f,-33.746906f,0f,0f,0f,1,-0.4866995f,-0.20995736f,-0.84796315f,0f,0f,0f ) ;
  }

  @Test
  public void test550() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,402.0f,-875.0f,0f,2221.0f,0f,0f,0f,0f,0f,611.0f,-887.0f,-411.0f,-71.0f,-174.0f,270.0f,-117,44.68643f,80.99526f,-15.713001f,0f,0f,0f ) ;
  }

  @Test
  public void test551() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,40.26234f,0.0f,0f,99.5188f,0f,0f,0f,0f,0f,-43.485443f,-12.3433275f,75.0109f,0f,0f,0f,459,0.09256099f,-0.80437344f,-0.07960304f,0f,0f,0f ) ;
  }

  @Test
  public void test552() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,407.0f,546.0f,0f,-1665.0f,0f,0f,0f,0f,0f,296.0f,128.0f,447.0f,-897.0f,1063.0f,-653.0f,-787,-0.058453243f,-0.54462004f,0.13611373f,0f,0f,0f ) ;
  }

  @Test
  public void test553() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,408.0f,1637.0f,0f,65.0f,0f,0f,0f,0f,0f,404.0f,-221.0f,170.0f,973.0f,1579.0f,-257.0f,-830,-0.1222775f,0.4303578f,-0.8577944f,0f,0f,0f ) ;
  }

  @Test
  public void test554() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-40.98972f,-50.67292f,0f,0f,0f,0f,0f,0f,0f,72.45567f,-24.375439f,19.528185f,0f,0f,0f,-274,-71.61392f,31.194523f,46.7518f,0f,0f,0f ) ;
  }

  @Test
  public void test555() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,4.0f,1219.0f,-983.0f,-1457.0f,0f,0f,0f,0f,0f,-265.0f,-363.0f,1500.0f,-433.0f,601.0f,306.0f,416,-85.31662f,-73.47604f,-50.665264f,15.0958395f,0f,0f ) ;
  }

  @Test
  public void test556() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-410.0f,151.0f,0f,322.0f,0f,0f,0f,0f,0f,-302.0f,-418.0f,1325.0f,396.0f,205.0f,155.0f,199,24.918169f,-79.19009f,-19.340765f,0f,0f,0f ) ;
  }

  @Test
  public void test557() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,415.0f,-1103.0f,0f,101.0f,0f,0f,0f,0f,0f,-988.0f,796.0f,-501.0f,543.0f,622.0f,-86.0f,-548,2.041506f,-0.2463433f,2.0604181f,0f,0f,0f ) ;
  }

  @Test
  public void test558() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-421.0f,932.0f,0f,878.0f,0f,0f,0f,0f,0f,-453.0f,-54.0f,796.0f,938.0f,515.0f,976.0f,939,25.522238f,93.35179f,20.299654f,0f,0f,0f ) ;
  }

  @Test
  public void test559() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-43.030563f,40.82462f,0f,0f,0f,0f,0f,0f,0f,-51.326283f,75.16f,63.088326f,-701.0f,876.0f,1108.0f,1,-0.28740555f,0.373869f,0.54533297f,0f,0f,0f ) ;
  }

  @Test
  public void test560() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-434.0f,528.0f,-563.0f,1.0f,0f,0f,0f,0f,0f,722.0f,-1043.0f,-758.0f,1231.0f,33.0f,-30.0f,1005,-0.4645012f,0.4489989f,-0.6482741f,8.847144f,0f,0f ) ;
  }

  @Test
  public void test561() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,436.0f,162.0f,0f,592.0f,0f,0f,0f,0f,0f,675.0f,-78.0f,-215.0f,-145.0f,-915.0f,-130.0f,433,-0.09401854f,0.67720675f,-0.54000634f,0f,0f,0f ) ;
  }

  @Test
  public void test562() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-44.0f,-1213.0f,0f,255.0f,0f,0f,0f,0f,0f,118.0f,-2611.0f,-222.0f,-1581.0f,-258.0f,721.0f,-11,0.37694877f,0.15345871f,0.53108495f,0f,0f,0f ) ;
  }

  @Test
  public void test563() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,449.0f,902.0f,860.0f,731.0f,0f,0f,0f,0f,0f,-172.0f,-438.0f,178.0f,318.0f,-740.0f,-965.0f,889,67.61719f,37.4654f,-63.86394f,48.11574f,0f,0f ) ;
  }

  @Test
  public void test564() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-45.0f,-573.0f,0f,255.0f,0f,0f,0f,0f,0f,-471.0f,151.0f,-723.0f,394.0f,-717.0f,-766.0f,-965,28.161182f,58.517f,93.51868f,0f,0f,0f ) ;
  }

  @Test
  public void test565() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-46.0f,1659.0f,0f,1760.0f,0f,0f,0f,0f,0f,-354.0f,150.0f,-492.0f,954.0f,-73.0f,-709.0f,941,0.7089993f,-1.2243205f,0.1755278f,0f,0f,0f ) ;
  }

  @Test
  public void test566() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,465.0f,316.0f,0f,-6.0f,0f,0f,0f,0f,0f,-340.0f,1260.0f,-129.0f,2491.0f,-1420.0f,1867.0f,489,-0.17175466f,-0.40344268f,0.8988949f,0f,0f,0f ) ;
  }

  @Test
  public void test567() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,468.0f,701.0f,366.0f,385.0f,0f,0f,0f,0f,0f,-732.0f,537.0f,-791.0f,-736.0f,46.0f,210.0f,-159,-36.82172f,-94.976875f,19.97879f,74.09795f,0f,0f ) ;
  }

  @Test
  public void test568() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-46.91361f,-61.092762f,0f,56.97681f,0f,0f,0f,0f,0f,17.621908f,11.293249f,-29.863836f,0f,0f,0f,502,0.39253965f,-0.7056807f,0.17661043f,0f,0f,0f ) ;
  }

  @Test
  public void test569() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-489.0f,-1849.0f,0f,1191.0f,0f,0f,0f,0f,0f,-57.0f,-645.0f,-458.0f,-853.0f,-411.0f,686.0f,-978,28.87248f,40.31642f,119.62312f,0f,0f,0f ) ;
  }

  @Test
  public void test570() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-49.481575f,-48.71108f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.37354672f,-0.7343579f,0.46077886f,0f,0f,0f ) ;
  }

  @Test
  public void test571() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-50.088028f,35.96177f,0f,0f,0f,0f,0f,0f,0f,4.1832952f,-96.4779f,59.708553f,531.0f,183.0f,-77.0f,522,53.766323f,13.170464f,-97.823296f,0f,0f,0f ) ;
  }

  @Test
  public void test572() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-502.0f,-590.0f,651.0f,-38.0f,0f,0f,0f,0f,0f,-694.0f,196.0f,-643.0f,-905.0f,564.0f,-900.0f,80,47.167816f,4.5816936f,1.2046978f,72.009415f,-1.9634076f,0f ) ;
  }

  @Test
  public void test573() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-503.0f,19.0f,-328.0f,-809.0f,0f,0f,0f,0f,0f,35.0f,636.0f,910.0f,993.0f,822.0f,-6.0f,163,-100.0f,100.0f,-100.0f,-100.0f,-6.489245f,0f ) ;
  }

  @Test
  public void test574() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,504.0f,6.0f,0f,1231.0f,0f,0f,0f,0f,0f,-1092.0f,649.0f,1722.0f,-74.0f,-512.0f,666.0f,-1679,-0.63302827f,0.13363943f,-0.63752204f,0f,0f,0f ) ;
  }

  @Test
  public void test575() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-506.0f,-169.0f,0f,1328.0f,0f,0f,0f,0f,0f,-810.0f,1162.0f,-468.0f,-366.0f,568.0f,-354.0f,-592,0.13375306f,0.1444103f,0.7910571f,0f,0f,0f ) ;
  }

  @Test
  public void test576() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-50.77315f,0f,0f,0f,0f,0f,0f,0f,0f,87.60326f,-69.01541f,-100.0f,0f,0f,0f,572,-0.2285466f,0.72405875f,-0.65077287f,0f,0f,0f ) ;
  }

  @Test
  public void test577() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,51.0f,606.0f,973.0f,-361.0f,0f,0f,0f,0f,0f,572.0f,774.0f,-783.0f,745.0f,794.0f,448.0f,-245,33.36963f,30.071695f,-64.15502f,91.076f,0f,0f ) ;
  }

  @Test
  public void test578() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,51.202656f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.40223056f,0.8116193f,-0.06773906f,0f,0f,0f ) ;
  }

  @Test
  public void test579() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-512.0f,776.0f,357.0f,-234.0f,0f,0f,0f,0f,0f,-302.0f,-249.0f,-746.0f,-738.0f,65.0f,881.0f,37,-29.50575f,-83.13166f,0.55163854f,-67.08592f,18.554502f,0f ) ;
  }

  @Test
  public void test580() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-52.491676f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,29.880205f,-65.09618f,0f,0f,0f,-1,0.73488647f,-0.031164624f,-0.061435353f,0f,0f,0f ) ;
  }

  @Test
  public void test581() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,52.50627f,-52.678276f,0f,0f,0f,0f,0f,0f,0f,-40.106514f,44.882343f,16.331299f,0f,0f,0f,128,-0.6046332f,-98.51553f,-74.39325f,0f,0f,0f ) ;
  }

  @Test
  public void test582() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,525.0f,-55.0f,0f,646.0f,0f,0f,0f,0f,0f,215.0f,-47.0f,260.0f,-160.0f,617.0f,245.0f,254,-0.07701689f,0.99007195f,0.041660935f,0f,0f,0f ) ;
  }

  @Test
  public void test583() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-526.0f,-494.0f,0f,1044.0f,0f,0f,0f,0f,0f,692.0f,-630.0f,187.0f,731.0f,767.0f,-121.0f,565,37.826256f,100.0f,23.636768f,0f,0f,0f ) ;
  }

  @Test
  public void test584() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,5.2679157f,92.16692f,0f,0f,0f,0f,0f,0f,0f,10.544313f,-57.026665f,22.100874f,421.0f,1393.0f,183.0f,-475,-3.0872269f,0.6259019f,3.0878785f,0f,0f,0f ) ;
  }

  @Test
  public void test585() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,530.0f,797.0f,542.0f,-506.0f,0f,0f,0f,0f,0f,2.0f,389.0f,-453.0f,710.0f,-278.0f,-254.0f,73,-9.921518f,-5.938637f,36.023155f,-32.452286f,-81.16768f,0f ) ;
  }

  @Test
  public void test586() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-531.0f,-165.0f,0f,255.0f,0f,0f,0f,0f,0f,-1834.0f,-575.0f,386.0f,-652.0f,646.0f,-197.0f,-972,26.814745f,-19.855553f,7.768039f,0f,0f,0f ) ;
  }

  @Test
  public void test587() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-53.194542f,-21.991186f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.2716663f,0.3423346f,0.447651f,0f,0f,0f ) ;
  }

  @Test
  public void test588() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,53.77286f,0f,0f,0f,0f,0f,0f,0f,0f,62.25556f,87.29979f,66.709656f,0f,0f,0f,-167,-80.78436f,36.43179f,5.9536734f,0f,0f,0f ) ;
  }

  @Test
  public void test589() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-54.0f,-451.0f,0f,207.0f,0f,0f,0f,0f,0f,-173.0f,-988.0f,292.0f,-346.0f,-899.0f,-291.0f,672,20.31117f,52.840893f,3.1242414f,0f,0f,0f ) ;
  }

  @Test
  public void test590() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-54.0f,-939.0f,0f,870.0f,0f,0f,0f,0f,0f,-852.0f,-340.0f,-351.0f,-513.0f,-144.0f,216.0f,742,37.18832f,93.998535f,-73.40061f,0f,0f,0f ) ;
  }

  @Test
  public void test591() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-547.0f,823.0f,-180.0f,188.0f,0f,0f,0f,0f,0f,201.0f,-819.0f,665.0f,203.0f,14.0f,-881.0f,595,-76.616974f,-100.0f,-100.0f,100.0f,100.0f,0f ) ;
  }

  @Test
  public void test592() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-55.03163f,-92.753975f,0f,61.87691f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.36143848f,-0.1718201f,0.49553132f,0f,0f,0f ) ;
  }

  @Test
  public void test593() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-5.5033746f,2.5219834f,0f,0f,0f,0f,0f,0f,0f,26.696783f,14.160705f,67.05917f,-503.0f,1244.0f,-374.0f,325,24.512484f,36.483883f,-17.476944f,0f,0f,0f ) ;
  }

  @Test
  public void test594() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-552.0f,-911.0f,0f,141.0f,0f,0f,0f,0f,0f,469.0f,-580.0f,483.0f,-144.0f,-228.0f,133.0f,-615,-53.593613f,10.908715f,-21.866083f,0f,0f,0f ) ;
  }

  @Test
  public void test595() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,55.405777f,0.0f,0f,78.665436f,0f,0f,0f,0f,0f,-4.0777802f,53.210957f,-100.0f,0f,0f,0f,-849,-0.14955167f,-0.57438314f,0.8048095f,0f,0f,0f ) ;
  }

  @Test
  public void test596() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,556.0f,198.0f,0f,743.0f,0f,0f,0f,0f,0f,589.0f,-305.0f,799.0f,-797.0f,332.0f,715.0f,608,15.006509f,-12.731891f,-71.81116f,0f,0f,0f ) ;
  }

  @Test
  public void test597() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-55.927658f,0.0f,0f,7.1054274E-15f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.105820015f,0.122848235f,0.028829468f,0f,0f,0f ) ;
  }

  @Test
  public void test598() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-56.0f,594.0f,0f,736.0f,0f,0f,0f,0f,0f,-1079.0f,-666.0f,212.0f,994.0f,-914.0f,-580.0f,-639,19.50908f,30.458849f,-9.181408f,0f,0f,0f ) ;
  }

  @Test
  public void test599() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,56.598515f,23.054651f,0f,0f,0f,0f,0f,0f,0f,-96.6662f,-4.2966576f,11.7792015f,375.0f,1916.0f,616.0f,-6,-0.17709093f,-1.132546f,-2.1022549f,0f,0f,0f ) ;
  }

  @Test
  public void test600() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-567.0f,-1.0f,0f,421.0f,0f,0f,0f,0f,0f,2599.0f,-456.0f,-509.0f,627.0f,-376.0f,-285.0f,580,-110.28758f,61.665028f,-83.07578f,0f,0f,0f ) ;
  }

  @Test
  public void test601() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-567.0f,-778.0f,0f,424.0f,0f,0f,0f,0f,0f,500.0f,-291.0f,425.0f,57.0f,-343.0f,297.0f,677,-34.58055f,62.95431f,-23.467875f,0f,0f,0f ) ;
  }

  @Test
  public void test602() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,569.0f,250.0f,0f,-332.0f,0f,0f,0f,0f,0f,58.0f,-509.0f,-131.0f,457.0f,582.0f,-385.0f,826,100.0f,100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test603() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-5.715203f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,15.788068f,51.875217f,-19.035086f,0f,0f,0f,844,0.21559195f,-0.33048642f,-0.13721965f,0f,0f,0f ) ;
  }

  @Test
  public void test604() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-573.0f,1.0f,0f,847.0f,0f,0f,0f,0f,0f,-922.0f,-199.0f,-958.0f,356.0f,-1286.0f,-76.0f,1199,39.55382f,-100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test605() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,585.0f,615.0f,555.0f,-640.0f,0f,0f,0f,0f,0f,-304.0f,70.0f,951.0f,-774.0f,501.0f,-832.0f,937,-0.24092674f,-14.688403f,12.53627f,-56.802597f,0f,0f ) ;
  }

  @Test
  public void test606() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,59.10208f,0.0f,0f,0f,0f,0f,0f,0f,0f,11.486435f,24.458738f,-9.60833f,0f,0f,0f,1093,-9.188648f,-65.39106f,38.859158f,0f,0f,0f ) ;
  }

  @Test
  public void test607() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-593.0f,443.0f,0f,625.0f,0f,0f,0f,0f,0f,-665.0f,-337.0f,14.0f,731.0f,654.0f,-570.0f,-270,0.044755418f,0.06974299f,-0.71992224f,0f,0f,0f ) ;
  }

  @Test
  public void test608() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,59.529335f,0.0f,0f,33.22678f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0.10666666f,1.031658f,3.1219208f,0f,0f,0f ) ;
  }

  @Test
  public void test609() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,597.0f,1787.0f,0f,149.0f,0f,0f,0f,0f,0f,-1.0f,-300.0f,-14.0f,3661.0f,-6.0f,-152.0f,-445,0.73472893f,0.038596366f,0.13957933f,0f,0f,0f ) ;
  }

  @Test
  public void test610() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,599.0f,-537.0f,391.0f,18.0f,0f,0f,0f,0f,0f,-878.0f,950.0f,903.0f,-14.0f,992.0f,528.0f,952,-14.170304f,-7.1424594f,-23.763248f,23.550556f,-60.292866f,0f ) ;
  }

  @Test
  public void test611() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-603.0f,-1310.0f,0f,210.0f,0f,0f,0f,0f,0f,-458.0f,467.0f,504.0f,260.0f,56.0f,187.0f,1507,-0.26310444f,-0.52232593f,0.109985515f,0f,0f,0f ) ;
  }

  @Test
  public void test612() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,60.344288f,85.68784f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,-17.972216f,618.0f,-1321.0f,-610.0f,709,-0.016378613f,0.15420686f,-0.104061596f,0f,0f,0f ) ;
  }

  @Test
  public void test613() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,604.0f,2267.0f,0f,1503.0f,0f,0f,0f,0f,0f,1186.0f,443.0f,987.0f,-734.0f,-137.0f,945.0f,-896,0.935298f,-0.2090481f,-1.1748916f,0f,0f,0f ) ;
  }

  @Test
  public void test614() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-605.0f,20.0f,0f,0.0f,0f,0f,0f,0f,0f,-312.0f,854.0f,-684.0f,-624.0f,-330.0f,-591.0f,220,64.55503f,-29.674156f,65.18723f,0f,0f,0f ) ;
  }

  @Test
  public void test615() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,6.0f,1.0f,0f,2024.0f,0f,0f,0f,0f,0f,637.0f,-251.0f,862.0f,89.0f,-913.0f,-333.0f,832,-0.4199794f,-2.9180794f,-0.53933996f,0f,0f,0f ) ;
  }

  @Test
  public void test616() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,6.0f,367.0f,-1788.0f,-1879.0f,0f,0f,0f,0f,0f,-748.0f,723.0f,1907.0f,510.0f,-922.0f,1081.0f,-938,0.8550851f,-0.36563602f,-0.011290004f,50.241806f,0f,0f ) ;
  }

  @Test
  public void test617() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-6.0f,379.0f,0f,0.0f,0f,0f,0f,0f,0f,-636.0f,-22.0f,-284.0f,323.0f,522.0f,-701.0f,1228,59.36895f,86.291595f,-81.45299f,0f,0f,0f ) ;
  }

  @Test
  public void test618() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-61.0f,-841.0f,976.0f,-439.0f,0f,0f,0f,0f,0f,-988.0f,986.0f,-972.0f,266.0f,-235.0f,966.0f,-239,-53.060753f,-24.608898f,35.170166f,0f,-46.14478f,0f ) ;
  }

  @Test
  public void test619() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-611.0f,938.0f,0f,-441.0f,0f,0f,0f,0f,0f,-132.0f,-702.0f,30.0f,94.0f,-964.0f,214.0f,427,6.8722825f,84.12525f,-2.7665234f,0f,0f,0f ) ;
  }

  @Test
  public void test620() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,62.0f,-181.0f,0f,1567.0f,0f,0f,0f,0f,0f,1638.0f,-1111.0f,3418.0f,44.0f,-531.0f,-1846.0f,-186,-0.86107f,-0.47903842f,0.17053065f,0f,0f,0f ) ;
  }

  @Test
  public void test621() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-628.0f,-400.0f,0f,1044.0f,0f,0f,0f,0f,0f,-516.0f,238.0f,851.0f,-606.0f,766.0f,775.0f,-377,0.9457787f,0.17003548f,0.24645536f,0f,0f,0f ) ;
  }

  @Test
  public void test622() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-637.0f,-1.0f,0f,1057.0f,0f,0f,0f,0f,0f,1030.0f,283.0f,-263.0f,705.0f,114.0f,-103.0f,988,-0.73334503f,0.53040504f,-0.023196341f,0f,0f,0f ) ;
  }

  @Test
  public void test623() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,637.0f,-939.0f,0f,285.0f,0f,0f,0f,0f,0f,-931.0f,209.0f,537.0f,-733.0f,32.0f,1062.0f,862,0.13944802f,-0.0032495684f,-0.302118f,0f,0f,0f ) ;
  }

  @Test
  public void test624() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-63.881542f,55.56297f,0f,0f,0f,0f,0f,0f,0f,31.0402f,-31.467667f,93.720314f,0f,0f,0f,-254,-0.64483297f,0.038213525f,-0.76336765f,0f,0f,0f ) ;
  }

  @Test
  public void test625() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,6.4180503f,21.051987f,0f,0f,0f,0f,0f,0f,0f,-54.902817f,-24.604984f,-93.285805f,0f,0f,0f,-45,-26.877285f,62.604908f,51.598156f,0f,0f,0f ) ;
  }

  @Test
  public void test626() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,643.0f,-609.0f,0f,1178.0f,0f,0f,0f,0f,0f,168.0f,-744.0f,-1882.0f,1104.0f,-606.0f,-679.0f,438,0.06836405f,0.119137414f,0.14388998f,0f,0f,0f ) ;
  }

  @Test
  public void test627() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-648.0f,480.0f,907.0f,-141.0f,0f,0f,0f,0f,0f,781.0f,-976.0f,-266.0f,530.0f,525.0f,-380.0f,835,-85.90681f,-18.610886f,-81.86266f,40.68591f,0f,0f ) ;
  }

  @Test
  public void test628() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,649.0f,941.0f,0f,990.0f,0f,0f,0f,0f,0f,-828.0f,471.0f,-219.0f,-745.0f,-182.0f,-253.0f,465,68.01059f,87.530815f,99.93179f,0f,0f,0f ) ;
  }

  @Test
  public void test629() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-64.994705f,99.995026f,0f,-1.9243588E-17f,0f,0f,0f,0f,0f,-100.0f,52.3894f,17.900425f,0f,0f,0f,268,-0.1809808f,-0.021815097f,-0.99127084f,0f,0f,0f ) ;
  }

  @Test
  public void test630() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-650.0f,775.0f,0f,218.0f,0f,0f,0f,0f,0f,1686.0f,93.0f,-2140.0f,335.0f,406.0f,-738.0f,-846,-0.13142501f,-0.06182678f,0.37386808f,0f,0f,0f ) ;
  }

  @Test
  public void test631() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-651.0f,1026.0f,0f,0.0f,0f,0f,0f,0f,0f,451.0f,307.0f,-29.0f,1069.0f,-613.0f,1160.0f,-932,0.15281051f,-0.5014841f,0.74795055f,0f,0f,0f ) ;
  }

  @Test
  public void test632() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-653.0f,937.0f,0f,183.0f,0f,0f,0f,0f,0f,-523.0f,380.0f,730.0f,858.0f,-421.0f,834.0f,-498,85.62907f,-96.12016f,-18.464148f,0f,0f,0f ) ;
  }

  @Test
  public void test633() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-655.0f,133.0f,64.0f,745.0f,0f,0f,0f,0f,0f,-934.0f,-530.0f,531.0f,-653.0f,568.0f,-732.0f,-222,59.214314f,-73.59417f,62.559658f,0f,40.932728f,94.96405f ) ;
  }

  @Test
  public void test634() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,66.0f,662.0f,498.0f,-479.0f,0f,0f,0f,0f,0f,-455.0f,-198.0f,-326.0f,-964.0f,-535.0f,299.0f,-255,3.225498f,-67.23957f,93.57008f,-24.394829f,0f,0f ) ;
  }

  @Test
  public void test635() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,66.30141f,-52.529068f,0f,15.931336f,0f,0f,0f,0f,0f,39.290806f,8.251237f,100.0f,0f,0f,0f,608,0.2667984f,0.58127636f,-0.22669105f,0f,0f,0f ) ;
  }

  @Test
  public void test636() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,663.0f,1131.0f,0f,131.0f,0f,0f,0f,0f,0f,553.0f,-277.0f,-794.0f,741.0f,152.0f,463.0f,-375,-121.744286f,0.41159907f,30.344883f,0f,0f,0f ) ;
  }

  @Test
  public void test637() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,669.0f,158.0f,0f,223.0f,0f,0f,0f,0f,0f,234.0f,195.0f,371.0f,1583.0f,-1136.0f,-395.0f,395,-0.72330505f,0.097073585f,-0.4899954f,0f,0f,0f ) ;
  }

  @Test
  public void test638() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-676.0f,594.0f,-716.0f,-1.0f,0f,0f,0f,0f,0f,810.0f,54.0f,-995.0f,2001.0f,-481.0f,352.0f,938,-0.6126243f,0.43704203f,0.6447274f,43.226646f,85.511604f,0f ) ;
  }

  @Test
  public void test639() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-684.0f,159.0f,592.0f,-500.0f,0f,0f,0f,0f,0f,903.0f,213.0f,-798.0f,-59.0f,-880.0f,-909.0f,-468,-75.070885f,32.94389f,-60.547684f,-46.64066f,0f,0f ) ;
  }

  @Test
  public void test640() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-685.0f,1.0f,0f,514.0f,0f,0f,0f,0f,0f,-238.0f,-1716.0f,2393.0f,-909.0f,514.0f,-1166.0f,3,3.1833198f,3.5443268f,0.7937913f,0f,0f,0f ) ;
  }

  @Test
  public void test641() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-688.0f,-512.0f,0f,252.0f,0f,0f,0f,0f,0f,198.0f,913.0f,-662.0f,114.0f,983.0f,-626.0f,100,24.748758f,-39.71833f,76.9458f,0f,0f,0f ) ;
  }

  @Test
  public void test642() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-689.0f,-688.0f,840.0f,896.0f,0f,0f,0f,0f,0f,561.0f,-670.0f,-751.0f,-202.0f,232.0f,-424.0f,-426,-23.514471f,-21.567905f,73.450424f,34.523373f,-9.511659f,0f ) ;
  }

  @Test
  public void test643() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-69.0f,-656.0f,0f,397.0f,0f,0f,0f,0f,0f,-554.0f,-661.0f,1048.0f,135.0f,-875.0f,-479.0f,-948,78.03505f,-10.595826f,-98.661476f,0f,0f,0f ) ;
  }

  @Test
  public void test644() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-692.0f,-662.0f,0f,254.0f,0f,0f,0f,0f,0f,9.0f,2634.0f,153.0f,-247.0f,577.0f,-764.0f,708,100.0f,-100.0f,-34.399868f,0f,0f,0f ) ;
  }

  @Test
  public void test645() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,698.0f,-361.0f,0f,300.0f,0f,0f,0f,0f,0f,226.0f,-759.0f,186.0f,-548.0f,-370.0f,181.0f,-456,-73.95441f,-5.888045f,-11.448017f,0f,0f,0f ) ;
  }

  @Test
  public void test646() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,699.0f,978.0f,0f,270.0f,0f,0f,0f,0f,0f,-78.0f,999.0f,-153.0f,716.0f,374.0f,-474.0f,-863,67.604195f,-62.030506f,-39.964302f,0f,0f,0f ) ;
  }

  @Test
  public void test647() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,70.907715f,-96.15506f,0f,56.469933f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.0037296477f,-0.8127217f,2.0089426f,0f,0f,0f ) ;
  }

  @Test
  public void test648() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-7.0f,-4.0f,0f,429.0f,0f,0f,0f,0f,0f,-992.0f,-525.0f,217.0f,817.0f,-1222.0f,779.0f,-668,0.26119757f,12.992194f,-23.193521f,0f,0f,0f ) ;
  }

  @Test
  public void test649() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-7.1054274E-15f,0.0f,0f,0f,0f,0f,0f,0f,0f,-14.738249f,-4.0419507f,8.168289f,0f,0f,0f,-3,0.5738966f,0.44354492f,0.68841165f,0f,0f,0f ) ;
  }

  @Test
  public void test650() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,712.0f,482.0f,0f,564.0f,0f,0f,0f,0f,0f,786.0f,-518.0f,392.0f,840.0f,881.0f,-520.0f,-260,-15.212458f,54.877914f,28.535948f,0f,0f,0f ) ;
  }

  @Test
  public void test651() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-71.33774f,-49.4486f,0f,-23.391508f,0f,0f,0f,0f,0f,88.84178f,100.0f,50.68426f,0f,0f,0f,-713,-3.5879676f,2.8927498f,-10.662348f,0f,0f,0f ) ;
  }

  @Test
  public void test652() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-717.0f,298.0f,0f,969.0f,0f,0f,0f,0f,0f,527.0f,-662.0f,927.0f,94.0f,-575.0f,-314.0f,579,-85.37177f,21.32963f,57.156025f,0f,0f,0f ) ;
  }

  @Test
  public void test653() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,721.0f,708.0f,0f,464.0f,0f,0f,0f,0f,0f,-795.0f,-46.0f,100.0f,311.0f,544.0f,497.0f,-233,11.970595f,24.380457f,-19.56828f,0f,0f,0f ) ;
  }

  @Test
  public void test654() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-725.0f,315.0f,112.0f,744.0f,0f,0f,0f,0f,0f,-405.0f,-245.0f,1289.0f,928.0f,-22.0f,504.0f,608,97.748375f,-61.884495f,16.043201f,0f,-39.94206f,0f ) ;
  }

  @Test
  public void test655() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-739.0f,-621.0f,0f,55.0f,0f,0f,0f,0f,0f,-106.0f,338.0f,28.0f,-416.0f,370.0f,33.0f,915,1.253312f,-43.398495f,-46.575317f,0f,0f,0f ) ;
  }

  @Test
  public void test656() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,741.0f,-2212.0f,0f,38.0f,0f,0f,0f,0f,0f,239.0f,534.0f,99.0f,1768.0f,100.0f,136.0f,-9,-0.1980415f,0.2346595f,-0.01239357f,0f,0f,0f ) ;
  }

  @Test
  public void test657() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-742.0f,906.0f,0f,820.0f,0f,0f,0f,0f,0f,1323.0f,1081.0f,13.0f,377.0f,299.0f,745.0f,-739,-0.110143445f,-0.06284529f,-0.9705052f,0f,0f,0f ) ;
  }

  @Test
  public void test658() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-745.0f,747.0f,0f,516.0f,0f,0f,0f,0f,0f,1921.0f,-993.0f,-1120.0f,-329.0f,-755.0f,-1886.0f,1510,-0.4106732f,-0.3431616f,-0.21788973f,0f,0f,0f ) ;
  }

  @Test
  public void test659() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-748.0f,154.0f,0f,344.0f,0f,0f,0f,0f,0f,20.0f,737.0f,-153.0f,811.0f,932.0f,345.0f,324,-47.9031f,-6.6796246f,-38.43755f,0f,0f,0f ) ;
  }

  @Test
  public void test660() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-74.9023f,-44.76874f,0f,0f,0f,0f,0f,0f,0f,-67.16844f,-10.388864f,75.64606f,0f,0f,0f,-199,-0.15132292f,-0.003294365f,-0.8566238f,0f,0f,0f ) ;
  }

  @Test
  public void test661() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-75.0f,-494.0f,0f,255.0f,0f,0f,0f,0f,0f,665.0f,728.0f,349.0f,653.0f,1320.0f,-978.0f,-895,-79.066475f,-34.841602f,48.11047f,0f,0f,0f ) ;
  }

  @Test
  public void test662() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-75.3529f,-100.0f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,99.52681f,6.579764f,0f,0f,0f,3,0.107050605f,-0.8007353f,-0.5893752f,0f,0f,0f ) ;
  }

  @Test
  public void test663() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,757.0f,1439.0f,0f,2.0f,0f,0f,0f,0f,0f,540.0f,86.0f,-508.0f,-459.0f,-446.0f,870.0f,-604,-3.5570662f,6.919135f,21.543026f,0f,0f,0f ) ;
  }

  @Test
  public void test664() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-76.00137f,0.0f,0f,0f,0f,0f,0f,0f,0f,30.391863f,-24.324585f,-31.962305f,0f,0f,0f,348,79.84654f,80.32724f,70.89501f,0f,0f,0f ) ;
  }

  @Test
  public void test665() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,76.21023f,-100.0f,0f,-20.775505f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.15666077f,-0.62834495f,-0.08643502f,0f,0f,0f ) ;
  }

  @Test
  public void test666() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,76.30734f,-6.4129105f,0f,-33.338516f,0f,0f,0f,0f,0f,-75.4602f,-20.271044f,-93.465355f,0f,0f,0f,-133,36.735195f,8.442256f,49.49349f,0f,0f,0f ) ;
  }

  @Test
  public void test667() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-768.0f,-577.0f,393.0f,612.0f,0f,0f,0f,0f,0f,-443.0f,996.0f,422.0f,160.0f,-363.0f,721.0f,845,-14.307108f,42.592228f,-43.29835f,-16.355604f,0f,0f ) ;
  }

  @Test
  public void test668() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,77.02605f,0.0f,0f,-21.465714f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,-0.21251561f,-0.02204683f,0.41671768f,0f,0f,0f ) ;
  }

  @Test
  public void test669() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-77.41993f,84.788864f,0f,0f,0f,0f,0f,0f,0f,70.38378f,62.589294f,17.328827f,205.0f,1043.0f,844.0f,83,-0.8976519f,-0.13652916f,-0.41902363f,0f,0f,0f ) ;
  }

  @Test
  public void test670() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,775.0f,1687.0f,0f,721.0f,0f,0f,0f,0f,0f,8.0f,274.0f,428.0f,126.0f,934.0f,878.0f,249,-0.6869809f,0.044961385f,-0.015942926f,0f,0f,0f ) ;
  }

  @Test
  public void test671() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-777.0f,-640.0f,993.0f,-980.0f,0f,0f,0f,0f,0f,-873.0f,-826.0f,-329.0f,531.0f,-491.0f,-889.0f,236,-44.762463f,2.432467f,-8.343076f,-15.500659f,0f,0f ) ;
  }

  @Test
  public void test672() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,781.0f,-4.0f,0f,916.0f,0f,0f,0f,0f,0f,-356.0f,-1828.0f,303.0f,2466.0f,-98.0f,1302.0f,-439,0.83382493f,0.43244663f,0.33873227f,0f,0f,0f ) ;
  }

  @Test
  public void test673() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,782.0f,396.0f,0f,1656.0f,0f,0f,0f,0f,0f,92.0f,74.0f,576.0f,-837.0f,625.0f,72.0f,-628,0.7928111f,-0.10538691f,-0.11314321f,0f,0f,0f ) ;
  }

  @Test
  public void test674() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-782.0f,-635.0f,0f,743.0f,0f,0f,0f,0f,0f,-166.0f,390.0f,246.0f,-139.0f,-333.0f,435.0f,270,27.354166f,-22.210905f,-1.97113f,0f,0f,0f ) ;
  }

  @Test
  public void test675() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-785.0f,-591.0f,0f,248.0f,0f,0f,0f,0f,0f,-399.0f,-33.0f,179.0f,-286.0f,689.0f,-316.0f,-329,5.8582473f,-24.576723f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test676() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,79.28052f,-19.99889f,0f,0.0f,0f,0f,0f,0f,0f,-48.83851f,-50.05461f,19.591831f,0f,0f,0f,-810,-24.009293f,93.300964f,-68.19597f,0f,0f,0f ) ;
  }

  @Test
  public void test677() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,79.494156f,0.0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,100.0f,100.0f,0f,0f,0f,932,0.79793906f,0.081679605f,0.5971781f,0f,0f,0f ) ;
  }

  @Test
  public void test678() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,795.0f,-10.0f,0f,28.0f,0f,0f,0f,0f,0f,476.0f,-142.0f,485.0f,537.0f,-508.0f,98.0f,-1277,87.60537f,-96.5081f,-166.82814f,0f,0f,0f ) ;
  }

  @Test
  public void test679() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,799.0f,-937.0f,760.0f,-203.0f,0f,0f,0f,0f,0f,-529.0f,-463.0f,-50.0f,516.0f,222.0f,-884.0f,884,96.13616f,-30.249508f,-48.47864f,11.2615385f,-60.678432f,46.827007f ) ;
  }

  @Test
  public void test680() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,815.0f,870.0f,0f,1203.0f,0f,0f,0f,0f,0f,1097.0f,459.0f,1426.0f,873.0f,978.0f,478.0f,-868,0.2192701f,-0.02706444f,-0.94285715f,0f,0f,0f ) ;
  }

  @Test
  public void test681() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,815.0f,878.0f,0f,1.0f,0f,0f,0f,0f,0f,-269.0f,-219.0f,360.0f,517.0f,-93.0f,916.0f,1221,95.190605f,49.467976f,38.59761f,0f,0f,0f ) ;
  }

  @Test
  public void test682() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,81.73323f,-37.16292f,0f,98.57718f,0f,0f,0f,0f,0f,0.8541024f,15.950662f,-22.347153f,0f,0f,0f,34,-59.007675f,-52.711647f,-29.777874f,0f,0f,0f ) ;
  }

  @Test
  public void test683() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-827.0f,600.0f,0f,-397.0f,0f,0f,0f,0f,0f,-656.0f,61.0f,-940.0f,805.0f,-787.0f,293.0f,-862,34.273903f,-47.13565f,68.901596f,0f,0f,0f ) ;
  }

  @Test
  public void test684() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,84.16075f,90.83751f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.011730218f,0.091177434f,-0.75597185f,0f,0f,0f ) ;
  }

  @Test
  public void test685() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,84.23499f,12.322393f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0.4329403f,-0.032884303f,0.38749453f,0f,0f,0f ) ;
  }

  @Test
  public void test686() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-84.52964f,-100.0f,0f,-36.063087f,0f,0f,0f,0f,0f,10.798043f,1.1421518f,62.522785f,0f,0f,0f,939,-0.30110672f,0.7315757f,-0.5130698f,0f,0f,0f ) ;
  }

  @Test
  public void test687() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-846.0f,11.0f,0f,280.0f,0f,0f,0f,0f,0f,227.0f,-694.0f,-5.0f,-527.0f,334.0f,2899.0f,-128,-0.9843696f,-0.11568661f,-0.13278982f,0f,0f,0f ) ;
  }

  @Test
  public void test688() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-84.79494f,0.0f,0f,32.08058f,0f,0f,0f,0f,0f,-3.2242184f,-4.620044f,80.69926f,0f,0f,0f,598,0.99096555f,-0.13020909f,0.03213806f,0f,0f,0f ) ;
  }

  @Test
  public void test689() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,848.0f,2424.0f,0f,1923.0f,0f,0f,0f,0f,0f,-250.0f,202.0f,567.0f,1477.0f,1539.0f,104.0f,103,1.4175159f,-0.52521336f,0.79489684f,0f,0f,0f ) ;
  }

  @Test
  public void test690() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-85.0f,476.0f,-1229.0f,1352.0f,0f,0f,0f,0f,0f,348.0f,-1282.0f,975.0f,-230.0f,-971.0f,201.0f,782,-0.77253246f,0.3874654f,-0.17108865f,-83.19748f,88.41686f,0f ) ;
  }

  @Test
  public void test691() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-851.0f,685.0f,0f,996.0f,0f,0f,0f,0f,0f,556.0f,-915.0f,682.0f,-271.0f,-469.0f,-882.0f,-963,-56.94743f,-4.6479325f,-32.43943f,0f,0f,0f ) ;
  }

  @Test
  public void test692() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,85.97392f,-33.946323f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.6452747f,-0.1865056f,0.26742524f,0f,0f,0f ) ;
  }

  @Test
  public void test693() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-862.0f,344.0f,0f,935.0f,0f,0f,0f,0f,0f,431.0f,835.0f,3.0f,-990.0f,576.0f,10.0f,-381,52.688946f,-95.57324f,4.0140557f,0f,0f,0f ) ;
  }

  @Test
  public void test694() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-863.0f,1124.0f,0f,675.0f,0f,0f,0f,0f,0f,-212.0f,-327.0f,-4.0f,1278.0f,-827.0f,-157.0f,146,0.42755577f,0.812668f,-0.023496604f,0f,0f,0f ) ;
  }

  @Test
  public void test695() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-867.0f,563.0f,-831.0f,957.0f,0f,0f,0f,0f,0f,633.0f,601.0f,-22.0f,212.0f,-262.0f,-1031.0f,-448,-100.0f,100.0f,-142.00365f,51.974487f,-40.879333f,-238.45311f ) ;
  }

  @Test
  public void test696() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-87.60937f,100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.113600485f,0.0565351f,-0.39030445f,0f,0f,0f ) ;
  }

  @Test
  public void test697() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,876.0f,957.0f,0f,3464.0f,0f,0f,0f,0f,0f,642.0f,231.0f,97.0f,508.0f,-1037.0f,-891.0f,206,0.118504606f,-0.30715603f,-0.05285482f,0f,0f,0f ) ;
  }

  @Test
  public void test698() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,879.0f,353.0f,301.0f,-726.0f,0f,0f,0f,0f,0f,-480.0f,798.0f,33.0f,787.0f,616.0f,-974.0f,-163,-94.64716f,-35.882862f,9.975741f,28.060257f,0f,0f ) ;
  }

  @Test
  public void test699() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-882.0f,600.0f,-1713.0f,-606.0f,0f,0f,0f,0f,0f,-814.0f,771.0f,-571.0f,-30.0f,-49.0f,-836.0f,671,67.03301f,19.076902f,2.8591254f,-90.39433f,0f,0f ) ;
  }

  @Test
  public void test700() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,88.57002f,100.0f,0f,0f,0f,0f,0f,0f,0f,-38.35724f,-3.6769936f,99.78427f,2.0f,409.0f,789.0f,206,0.21607828f,0.9754885f,0.042374857f,0f,0f,0f ) ;
  }

  @Test
  public void test701() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-88.63445f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.4789823f,0.13706726f,0.027613342f,0f,0f,0f ) ;
  }

  @Test
  public void test702() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-8.898235f,48.492916f,0f,0f,0f,0f,0f,0f,0f,11.943656f,-47.742275f,26.05499f,-1019.0f,-254.0f,-1220.0f,270,0.39045796f,-0.36085805f,-0.8406443f,0f,0f,0f ) ;
  }

  @Test
  public void test703() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-893.0f,-1469.0f,0f,255.0f,0f,0f,0f,0f,0f,-147.0f,-1046.0f,1414.0f,-435.0f,-1712.0f,314.0f,248,-0.32168865f,-0.39189005f,-0.402436f,0f,0f,0f ) ;
  }

  @Test
  public void test704() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,894.0f,0.0f,0f,867.0f,0f,0f,0f,0f,0f,-740.0f,288.0f,45.0f,483.0f,83.0f,646.0f,415,63.588665f,-32.12156f,-48.701683f,0f,0f,0f ) ;
  }

  @Test
  public void test705() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-896.0f,953.0f,751.0f,701.0f,0f,0f,0f,0f,0f,-574.0f,-931.0f,891.0f,-985.0f,-566.0f,-336.0f,282,52.533245f,-72.507996f,-75.373726f,30.772095f,0f,0f ) ;
  }

  @Test
  public void test706() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-897.0f,1233.0f,-936.0f,778.0f,0f,0f,0f,0f,0f,1602.0f,197.0f,454.0f,913.0f,51.0f,540.0f,-397,-0.18351342f,0.37871853f,0.03984022f,72.50077f,0f,0f ) ;
  }

  @Test
  public void test707() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,90.81781f,44.451332f,0f,0f,0f,0f,0f,0f,0f,51.119373f,19.406754f,0.62462646f,-14.0f,313.0f,98.0f,1981,0.107680626f,-0.2826753f,-0.043955237f,0f,0f,0f ) ;
  }

  @Test
  public void test708() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,919.0f,114.0f,0f,663.0f,0f,0f,0f,0f,0f,608.0f,792.0f,866.0f,199.0f,36.0f,983.0f,168,-88.35476f,-76.140594f,-8.338864f,0f,0f,0f ) ;
  }

  @Test
  public void test709() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-92.09366f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-24.092167f,-40.47252f,89.51783f,0f,0f,0f,-410,-0.20199743f,-0.2414855f,-0.83477265f,0f,0f,0f ) ;
  }

  @Test
  public void test710() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,926.0f,-1.0f,0f,274.0f,0f,0f,0f,0f,0f,225.0f,-375.0f,475.0f,715.0f,545.0f,700.0f,-76,-2.9665678f,32.67902f,-38.639458f,0f,0f,0f ) ;
  }

  @Test
  public void test711() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,930.0f,2019.0f,0f,753.0f,0f,0f,0f,0f,0f,517.0f,579.0f,650.0f,-1107.0f,536.0f,260.0f,1346,2.0599802f,68.975815f,-63.08016f,0f,0f,0f ) ;
  }

  @Test
  public void test712() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-931.0f,-94.0f,0f,259.0f,0f,0f,0f,0f,0f,732.0f,125.0f,-634.0f,705.0f,642.0f,-707.0f,-507,29.423376f,100.0f,96.90323f,0f,0f,0f ) ;
  }

  @Test
  public void test713() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-93.62713f,78.18106f,0f,0f,0f,0f,0f,0f,0f,-80.30654f,-54.35682f,88.001396f,-1217.0f,700.0f,-1219.0f,1,0.38872907f,-0.03048896f,1.1070423f,0f,0f,0f ) ;
  }

  @Test
  public void test714() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,940.0f,593.0f,505.0f,-204.0f,0f,0f,0f,0f,0f,105.0f,447.0f,89.0f,-253.0f,231.0f,645.0f,-588,-53.286278f,-23.83686f,11.361881f,0f,-70.42595f,-49.673134f ) ;
  }

  @Test
  public void test715() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,94.0f,-80.0f,0f,515.0f,0f,0f,0f,0f,0f,75.0f,17.0f,-161.0f,3.0f,944.0f,101.0f,1288,36.08945f,-37.840298f,19.866846f,0f,0f,0f ) ;
  }

  @Test
  public void test716() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-941.0f,-927.0f,0f,118.0f,0f,0f,0f,0f,0f,-136.0f,816.0f,578.0f,-23.0f,-612.0f,-824.0f,-894,70.75816f,-51.35833f,-11.214177f,0f,0f,0f ) ;
  }

  @Test
  public void test717() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,94.583954f,30.91662f,0f,0f,0f,0f,0f,0f,0f,-68.2138f,-64.96385f,73.32782f,477.0f,74.0f,989.0f,52,-43.574028f,23.651031f,-70.37317f,0f,0f,0f ) ;
  }

  @Test
  public void test718() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,9.487431E-30f,0.0f,0f,0f,0f,0f,0f,0f,0f,5.3564186f,99.985565f,-96.61307f,0f,0f,0f,-1,0.5573941f,-0.8046371f,0.20462397f,0f,0f,0f ) ;
  }

  @Test
  public void test719() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,949.0f,461.0f,0f,1122.0f,0f,0f,0f,0f,0f,727.0f,1925.0f,-62.0f,-955.0f,-1717.0f,-1576.0f,-870,-0.11282266f,-0.07353231f,-0.012702318f,0f,0f,0f ) ;
  }

  @Test
  public void test720() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,95.08939f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.5303707f,-0.1265847f,0.27759126f,0f,0f,0f ) ;
  }

  @Test
  public void test721() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-955.0f,1453.0f,0f,680.0f,0f,0f,0f,0f,0f,956.0f,94.0f,-16.0f,-137.0f,287.0f,-246.0f,115,-0.011441804f,0.108000726f,-0.049133f,0f,0f,0f ) ;
  }

  @Test
  public void test722() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,95.84369f,-23.314524f,0f,0.0f,0f,0f,0f,0f,0f,-21.05713f,-2.0223079f,-73.87945f,0f,0f,0f,727,0.14073992f,-0.39349386f,0.21856451f,0f,0f,0f ) ;
  }

  @Test
  public void test723() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-959.0f,863.0f,453.0f,-268.0f,0f,0f,0f,0f,0f,-571.0f,-451.0f,852.0f,164.0f,481.0f,-598.0f,589,-14.780232f,-27.731094f,-48.458256f,79.02411f,-48.101448f,0f ) ;
  }

  @Test
  public void test724() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-96.22467f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,99.017654f,-78.97971f,-66.6127f,0f,0f,0f,-946,-60.43469f,-44.068672f,19.687998f,0f,0f,0f ) ;
  }

  @Test
  public void test725() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-965.0f,752.0f,0f,409.0f,0f,0f,0f,0f,0f,652.0f,545.0f,-372.0f,570.0f,-133.0f,-798.0f,265,13.170252f,-37.17431f,96.53502f,0f,0f,0f ) ;
  }

  @Test
  public void test726() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,96.51004f,25.326569f,0f,0f,0f,0f,0f,0f,0f,33.770958f,-62.760086f,-77.09507f,-751.0f,-558.0f,518.0f,-180,-67.65078f,-100.0f,51.800724f,0f,0f,0f ) ;
  }

  @Test
  public void test727() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,96.79966f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.2974284f,0.16656698f,0.7481711f,0f,0f,0f ) ;
  }

  @Test
  public void test728() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,968.0f,-198.0f,753.0f,-369.0f,0f,0f,0f,0f,0f,269.0f,-608.0f,592.0f,993.0f,154.0f,14.0f,498,-23.055609f,-79.90727f,-0.8791925f,-49.080635f,0f,0f ) ;
  }

  @Test
  public void test729() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,969.0f,859.0f,0f,3637.0f,0f,0f,0f,0f,0f,149.0f,-493.0f,888.0f,-1286.0f,61.0f,827.0f,-683,1.4298509f,-0.038828228f,-0.26147673f,0f,0f,0f ) ;
  }

  @Test
  public void test730() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,977.0f,-1365.0f,0f,342.0f,0f,0f,0f,0f,0f,868.0f,-1382.0f,259.0f,1017.0f,-1281.0f,1111.0f,913,-0.31443262f,0.039132647f,0.5805446f,0f,0f,0f ) ;
  }

  @Test
  public void test731() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-978.0f,97.0f,-723.0f,1023.0f,0f,0f,0f,0f,0f,-513.0f,798.0f,667.0f,886.0f,356.0f,249.0f,751,26.480314f,97.67158f,-96.48804f,26.815653f,61.719574f,0f ) ;
  }

  @Test
  public void test732() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-98.02817f,-37.66351f,0f,32.723743f,0f,0f,0f,0f,0f,94.51146f,99.96624f,17.52076f,0f,0f,0f,1,0.71656287f,-0.6975104f,-0.0041137547f,0f,0f,0f ) ;
  }

  @Test
  public void test733() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,98.621315f,0.0f,0f,-29.532581f,0f,0f,0f,0f,0f,-65.19487f,-4.812325f,99.16223f,0f,0f,0f,-732,-0.006130569f,0.34986362f,0.012948235f,0f,0f,0f ) ;
  }

  @Test
  public void test734() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,98.66645f,-175.97699f,0f,100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.045696992f,0.2454618f,-0.07944549f,0f,0f,0f ) ;
  }

  @Test
  public void test735() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,98.98626f,-39.159187f,0f,0f,0f,0f,0f,0f,0f,-99.33458f,92.73062f,-39.496906f,0f,0f,0f,1103,0.600163f,-0.6623141f,0.44849125f,0f,0f,0f ) ;
  }

  @Test
  public void test736() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-99.1064f,-100.0f,0f,-86.774216f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,-0.15552145f,-0.25335288f,-0.016203864f,0f,0f,0f ) ;
  }

  @Test
  public void test737() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-99.251f,49.601616f,0f,0f,0f,0f,0f,0f,0f,-100.0f,100.0f,-25.046358f,0f,0f,0f,3,0.9080975f,0.21800609f,0.3575364f,0f,0f,0f ) ;
  }

  @Test
  public void test738() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,99.603096f,0f,0f,0f,0f,0f,0f,0f,0f,115.028656f,-127.03919f,-77.827156f,0f,0f,0f,-2,-0.43696123f,0.31321502f,0.831269f,0f,0f,0f ) ;
  }

  @Test
  public void test739() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-997.0f,-190.0f,0f,1670.0f,0f,0f,0f,0f,0f,-1041.0f,-1286.0f,1824.0f,-363.0f,-452.0f,1769.0f,174,-1.8935424E-4f,-0.14070141f,-0.16414274f,0f,0f,0f ) ;
  }

  @Test
  public void test740() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,99.94016f,0f,0f,0f,0f,0f,0f,0f,0f,1.4588339f,23.682177f,-100.0f,0f,0f,0f,703,0.42110848f,-0.40791515f,0.8101067f,0f,0f,0f ) ;
  }

  @Test
  public void test741() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-99.997696f,22.30281f,0f,61.52472f,0f,0f,0f,0f,0f,100.0f,-99.991554f,-8.321027f,0f,0f,0f,1453,-0.7218648f,0.26284432f,0.64017504f,0f,0f,0f ) ;
  }

  @Test
  public void test742() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-99.99973f,11.475388f,0f,-99.94406f,0f,0f,0f,0f,0f,48.167656f,14.661114f,-99.802574f,0f,0f,0f,1049,0.37840822f,-0.8117885f,0.44475463f,0f,0f,0f ) ;
  }

  @Test
  public void test743() {
    TestDrivers.surfaceShade(0f,0f,-1236.0f,0f,1306.0f,-1.0f,0f,355.0f,0f,0f,0f,0f,0f,-350.0f,635.0f,-581.0f,2040.0f,-477.0f,1378.0f,1557,1.3892422f,-20.472836f,-23.21254f,0f,0f,-6.3679633f ) ;
  }

  @Test
  public void test744() {
    TestDrivers.surfaceShade(0f,0f,-407.0f,0f,1187.0f,-1.0f,0f,762.0f,0f,0f,0f,0f,0f,941.0f,832.0f,982.0f,-528.0f,-585.0f,588.0f,826,-99.04012f,-49.97729f,-69.04289f,0f,0f,-10.768686f ) ;
  }

  @Test
  public void test745() {
    TestDrivers.surfaceShade(0f,0f,-878.0f,0f,230.0f,3.0f,0f,458.0f,0f,0f,0f,0f,0f,-139.0f,783.0f,784.0f,814.0f,212.0f,-416.0f,322,61.859142f,-92.7896f,-120.87018f,0f,0f,99.22926f ) ;
  }

  @Test
  public void test746() {
    TestDrivers.surfaceShade(0f,1661.0f,0f,0f,484.0f,0.0f,0f,533.0f,0f,0f,0f,0f,0f,-191.0f,-444.0f,753.0f,1868.0f,851.0f,-478.0f,-1029,-56.77681f,18.335423f,-79.469154f,0f,51.976685f,0f ) ;
  }

  @Test
  public void test747() {
    TestDrivers.surfaceShade(0f,601.0f,0f,0f,461.0f,-3.0f,0f,1372.0f,0f,0f,0f,0f,0f,826.0f,-1022.0f,299.0f,-904.0f,893.0f,220.0f,-204,-40.529156f,-10.758001f,75.191986f,0f,100.0f,0f ) ;
  }

  @Test
  public void test748() {
    TestDrivers.surfaceShade(0f,-901.0f,0f,0f,499.0f,-4.0f,0f,263.0f,0f,0f,0f,0f,0f,-982.0f,-924.0f,1486.0f,-525.0f,1118.0f,-431.0f,-297,37.254154f,86.87773f,64.43375f,0f,73.671f,0f ) ;
  }

  @Test
  public void test749() {
    TestDrivers.surfaceShade(-100.0f,1956.0f,-1583.0f,0f,1.0f,-543.0f,0f,145.0f,0f,0f,0f,0f,0f,151.0f,-554.0f,647.0f,75.0f,755.0f,648.0f,-233,-0.47140872f,0.7426866f,0.072734766f,72.28101f,-21.17397f,-14.186898f ) ;
  }

  @Test
  public void test750() {
    TestDrivers.surfaceShade(-100.0f,-249.0f,1346.0f,0f,212.0f,-423.0f,0f,274.0f,0f,0f,0f,0f,0f,31.0f,-611.0f,330.0f,-40.0f,-1130.0f,-1006.0f,-515,-0.07795154f,-0.37037843f,-0.67843854f,54.917442f,-7.587516f,-29.504734f ) ;
  }

  @Test
  public void test751() {
    TestDrivers.surfaceShade(-1008.0f,-19.0f,0f,0f,465.0f,0.0f,0f,-1035.0f,0f,0f,0f,0f,0f,533.0f,1740.0f,-1053.0f,0f,0f,0f,1533,100.0f,-82.51804f,-85.73732f,-0.09222281f,-40.11313f,0f ) ;
  }

  @Test
  public void test752() {
    TestDrivers.surfaceShade(-1014.0f,0f,0f,0f,28.354385f,0.0f,0f,-51.310505f,0f,0f,0f,0f,0f,-90.033394f,20.897614f,-28.552588f,0f,0f,0f,692,0.22493294f,0.49352527f,-0.34635338f,28.502193f,0f,0f ) ;
  }

  @Test
  public void test753() {
    TestDrivers.surfaceShade(-102.0f,162.0f,971.0f,-42.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,5.2969656f,-45.690678f,-40.73759f,-13.805641f,2.1389854f,95.402084f ) ;
  }

  @Test
  public void test754() {
    TestDrivers.surfaceShade(1021.0f,0f,-602.0f,0f,227.0f,-408.0f,0f,645.0f,0f,0f,0f,0f,0f,126.0f,-272.0f,-526.0f,74.0f,-570.0f,-1356.0f,-1661,-15.468025f,87.911026f,-49.164963f,-58.648815f,0f,100.0f ) ;
  }

  @Test
  public void test755() {
    TestDrivers.surfaceShade(-103.0f,585.0f,1103.0f,0f,247.0f,-45.0f,0f,1877.0f,0f,0f,0f,0f,0f,116.0f,-168.0f,113.0f,-472.0f,369.0f,21.0f,-316,100.0f,100.0f,-42.71564f,-100.0f,25.691238f,-100.0f ) ;
  }

  @Test
  public void test756() {
    TestDrivers.surfaceShade(1034.0f,1575.0f,0f,0f,654.0f,701.0f,0f,1543.0f,0f,0f,0f,0f,0f,639.0f,-1149.0f,964.0f,33.0f,911.0f,247.0f,2123,-0.54713935f,-0.08828402f,-0.29281512f,-11.175813f,18.448387f,0f ) ;
  }

  @Test
  public void test757() {
    TestDrivers.surfaceShade(104.0f,318.0f,-130.0f,0f,235.0f,-80.0f,0f,275.0f,0f,0f,0f,0f,0f,-557.0f,-685.0f,663.0f,35.0f,-818.0f,-540.0f,142,52.649014f,-25.799334f,-23.71868f,14.455196f,-95.88931f,57.31471f ) ;
  }

  @Test
  public void test758() {
    TestDrivers.surfaceShade(1044.0f,0f,0f,0f,808.0f,603.0f,-1156.0f,951.0f,0f,0f,0f,0f,0f,548.0f,137.0f,-186.0f,43.0f,1020.0f,1319.0f,-1162,1.1357726f,0.85875165f,3.9789784f,-2.4324472f,0f,0f ) ;
  }

  @Test
  public void test759() {
    TestDrivers.surfaceShade(-1045.0f,-87.0f,268.0f,0f,33.0f,363.0f,0f,-339.0f,0f,0f,0f,0f,0f,-33.0f,-805.0f,74.0f,376.0f,325.0f,844.0f,380,-0.24388945f,0.8141249f,0.021925637f,-46.06058f,-2.5272076f,52.066704f ) ;
  }

  @Test
  public void test760() {
    TestDrivers.surfaceShade(-1049.0f,0f,0f,0f,81.62551f,0.0f,0f,-53.814896f,0f,0f,0f,0f,0f,5.1887107f,100.0f,-99.58616f,0f,0f,0f,8,-0.85527605f,-2.6874866f,-1.9995921f,14.501261f,0f,0f ) ;
  }

  @Test
  public void test761() {
    TestDrivers.surfaceShade(-105.0f,0f,0f,0f,17.791916f,-26.724102f,0f,0.0f,0f,0f,0f,0f,0f,-72.58401f,25.994251f,30.609234f,0f,0f,0f,-5,40.355637f,4.9707584f,34.76361f,-92.02242f,0f,0f ) ;
  }

  @Test
  public void test762() {
    TestDrivers.surfaceShade(-106.0f,-259.0f,920.0f,0f,318.0f,-1861.0f,0f,352.0f,0f,0f,0f,0f,0f,197.0f,476.0f,281.0f,-997.0f,-764.0f,-14.0f,881,13.672788f,32.965332f,-65.42718f,-16.755081f,-0.33460295f,1.74346f ) ;
  }

  @Test
  public void test763() {
    TestDrivers.surfaceShade(107.0f,638.0f,-1980.0f,0f,814.0f,427.0f,0f,-948.0f,0f,0f,0f,0f,0f,895.0f,784.0f,-394.0f,384.0f,-961.0f,956.0f,635,-24.017399f,51.55184f,81.37578f,24.463005f,-91.15292f,-27.481712f ) ;
  }

  @Test
  public void test764() {
    TestDrivers.surfaceShade(-107.0f,793.0f,0f,0f,422.0f,0.0f,0f,-4.0f,0f,0f,0f,0f,0f,651.0f,-578.0f,1369.0f,0f,0f,0f,-1785,35.506615f,66.91255f,11.366436f,-100.0f,13.585336f,0f ) ;
  }

  @Test
  public void test765() {
    TestDrivers.surfaceShade(1080.0f,-360.0f,-6.0f,-87.0f,0f,0f,0f,-3.5527137E-15f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,13.906507f,80.4872f,0.0019157088f ) ;
  }

  @Test
  public void test766() {
    TestDrivers.surfaceShade(1081.0f,-2288.0f,0f,0f,623.0f,921.0f,0f,1421.0f,0f,0f,0f,0f,0f,804.0f,-358.0f,675.0f,-375.0f,655.0f,-596.0f,-761,32.769135f,-38.62352f,-59.51645f,5.002524f,-4.6439533f,0f ) ;
  }

  @Test
  public void test767() {
    TestDrivers.surfaceShade(1086.0f,-2392.0f,383.0f,0f,42.0f,-9.0f,0f,229.0f,0f,0f,0f,0f,0f,87.0f,-438.0f,-424.0f,-1088.0f,-1223.0f,-123.0f,-72,-85.283966f,-99.49604f,85.28198f,88.16943f,-10.093189f,56.902767f ) ;
  }

  @Test
  public void test768() {
    TestDrivers.surfaceShade(1102.0f,-348.0f,-323.0f,-847.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,100.0f,12.752447f,-7.885938E-6f ) ;
  }

  @Test
  public void test769() {
    TestDrivers.surfaceShade(1102.0f,-778.0f,60.0f,0f,11.0f,-1629.0f,0f,1348.0f,0f,0f,0f,0f,0f,-11.0f,-1741.0f,1327.0f,-494.0f,-1596.0f,-932.0f,589,-0.40795693f,0.17239591f,0.22279839f,67.244865f,100.0f,-11.391268f ) ;
  }

  @Test
  public void test770() {
    TestDrivers.surfaceShade(-1106.0f,-206.0f,0f,28.0f,0f,0f,0f,2483.0f,0f,0f,0f,0f,0f,-39.0f,-108.0f,759.0f,641.0f,579.0f,-87.0f,-3,0f,0f,0f,16.424822f,-1.7337032E-4f,0f ) ;
  }

  @Test
  public void test771() {
    TestDrivers.surfaceShade(-1108.0f,0f,0f,0f,7.1054274E-15f,-100.0f,0f,-31.952366f,0f,0f,0f,0f,0f,-21.05607f,13.671187f,59.017372f,0f,0f,0f,1826,0.2589799f,0.9558788f,-0.13865562f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test772() {
    TestDrivers.surfaceShade(-11.0f,-1577.0f,-1021.0f,0f,1332.0f,581.0f,0f,-40.0f,0f,0f,0f,0f,0f,-816.0f,-1149.0f,520.0f,971.0f,-77.0f,-969.0f,197,0.23352252f,0.19506289f,0.14705296f,-80.79855f,6.999084f,-75.72421f ) ;
  }

  @Test
  public void test773() {
    TestDrivers.surfaceShade(1117.0f,-519.0f,844.0f,0f,79.0f,-689.0f,0f,1334.0f,0f,0f,0f,0f,0f,888.0f,-419.0f,626.0f,-298.0f,1118.0f,-125.0f,1520,42.052967f,-42.983246f,-88.42335f,34.065624f,-72.988235f,9.349647f ) ;
  }

  @Test
  public void test774() {
    TestDrivers.surfaceShade(-1118.0f,0f,0f,0f,2.4080408f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-45.982105f,100.0f,77.05568f,0f,0f,0f,-1700,16.040352f,19.883924f,-16.232725f,-1.0948653f,0f,0f ) ;
  }

  @Test
  public void test775() {
    TestDrivers.surfaceShade(-113.0f,0f,0f,0f,100.0f,-3.1842983f,0f,0.0f,0f,0f,0f,0f,0f,57.597874f,12.491521f,13.199532f,0f,0f,0f,-785,11.559811f,-24.376884f,-27.373411f,-3.03223f,0f,0f ) ;
  }

  @Test
  public void test776() {
    TestDrivers.surfaceShade(-1131.0f,739.0f,0f,0f,621.0f,-897.0f,0f,-2.0f,0f,0f,0f,0f,0f,429.0f,-682.0f,-489.0f,0f,0f,0f,-381,1.6853029f,1.5304985f,-0.656043f,-92.15782f,-10.827545f,0f ) ;
  }

  @Test
  public void test777() {
    TestDrivers.surfaceShade(-1132.0f,610.0f,-441.0f,-259.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,-41.321095f,-23.839615f,45.01968f,48.536674f,29.840336f,48.832615f ) ;
  }

  @Test
  public void test778() {
    TestDrivers.surfaceShade(1140.0f,2091.0f,0f,0f,1284.0f,-118.0f,0f,-292.0f,0f,0f,0f,0f,0f,1015.0f,-265.0f,49.0f,0f,0f,0f,-468,-0.0206293f,0.026622156f,0.5712982f,100.0f,64.85733f,0f ) ;
  }

  @Test
  public void test779() {
    TestDrivers.surfaceShade(-1141.0f,18.0f,-967.0f,843.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,39.90399f,-56.413036f,-90.02352f,-4.3890944f,-9.799855f,19.380484f ) ;
  }

  @Test
  public void test780() {
    TestDrivers.surfaceShade(-1143.0f,0f,0f,0f,2.8476368E-6f,0.0f,0f,-77.77797f,0f,0f,0f,0f,0f,-65.4794f,-99.269295f,84.061905f,0f,0f,0f,1257,-0.4890561f,0.33742857f,-0.091755934f,-33.444527f,0f,0f ) ;
  }

  @Test
  public void test781() {
    TestDrivers.surfaceShade(1146.0f,-395.0f,0f,0f,3.0f,-1115.0f,0f,-1774.0f,0f,0f,0f,0f,0f,450.0f,-396.0f,491.0f,0f,0f,0f,1029,0.19860268f,-0.25033024f,-0.38391453f,52.54805f,-16.577908f,0f ) ;
  }

  @Test
  public void test782() {
    TestDrivers.surfaceShade(1156.0f,2281.0f,-92.0f,0f,1076.0f,-581.0f,0f,290.0f,0f,0f,0f,0f,0f,2176.0f,1038.0f,34.0f,-903.0f,678.0f,-3.0f,573,0.7179667f,-1.5132467f,0.24865992f,48.253036f,86.22077f,-88.218124f ) ;
  }

  @Test
  public void test783() {
    TestDrivers.surfaceShade(-1162.0f,855.0f,0f,0f,121.0f,-1.0f,0f,-106.0f,0f,0f,0f,0f,0f,355.0f,-602.0f,810.0f,0f,0f,0f,389,0.04869781f,-0.021550965f,-0.03735976f,-2.3830185f,3.1828363f,0f ) ;
  }

  @Test
  public void test784() {
    TestDrivers.surfaceShade(-1186.0f,500.0f,-512.0f,0f,154.0f,4.0f,0f,-897.0f,0f,0f,0f,0f,0f,1249.0f,417.0f,1902.0f,0f,0f,0f,692,-53.519054f,-94.49985f,54.328735f,98.79026f,4.4499284E-9f,-95.778206f ) ;
  }

  @Test
  public void test785() {
    TestDrivers.surfaceShade(1190.0f,-384.0f,-435.0f,0f,632.0f,2986.0f,0f,975.0f,0f,0f,0f,0f,0f,-1578.0f,-662.0f,-545.0f,956.0f,4.0f,-129.0f,527,-6.7957683f,-2.3106034f,22.483196f,-127.128105f,-30.725368f,-24.701889f ) ;
  }

  @Test
  public void test786() {
    TestDrivers.surfaceShade(1200.0f,-893.0f,-1172.0f,0f,348.0f,-586.0f,0f,1433.0f,0f,0f,0f,0f,0f,-2196.0f,-605.0f,-1779.0f,156.0f,-760.0f,1143.0f,619,0.1752551f,0.18385646f,0.34598973f,35.9241f,-1.759906f,1.3918306f ) ;
  }

  @Test
  public void test787() {
    TestDrivers.surfaceShade(1204.0f,0f,0f,0f,3248.0f,-145.0f,0f,2902.0f,0f,0f,0f,0f,0f,-1317.0f,33.0f,71.0f,1638.0f,487.0f,257.0f,-1104,-6.0988927f,-100.0f,-66.65129f,100.0f,0f,0f ) ;
  }

  @Test
  public void test788() {
    TestDrivers.surfaceShade(-1204.0f,-172.0f,332.0f,0f,985.0f,-1003.0f,0f,-67.0f,0f,0f,0f,0f,0f,-860.0f,-33.0f,617.0f,0f,0f,0f,-280,-14.786902f,27.905924f,-19.118055f,-54.777287f,43.601753f,33.842808f ) ;
  }

  @Test
  public void test789() {
    TestDrivers.surfaceShade(12.0f,-486.0f,0f,0f,612.0f,-797.0f,580.0f,-366.0f,0f,0f,0f,0f,0f,-683.0f,107.0f,613.0f,245.0f,158.0f,905.0f,-162,34.21815f,-98.446014f,-42.758305f,87.911255f,-39.456047f,0f ) ;
  }

  @Test
  public void test790() {
    TestDrivers.surfaceShade(-1213.0f,747.0f,0f,0f,924.0f,-601.0f,0f,0.0f,0f,0f,0f,0f,0f,806.0f,-296.0f,-139.0f,0f,0f,0f,701,-37.378834f,-21.247625f,-67.82098f,-7.422721f,-82.8182f,0f ) ;
  }

  @Test
  public void test791() {
    TestDrivers.surfaceShade(-1220.0f,-165.0f,-2018.0f,0f,102.0f,516.0f,0f,482.0f,0f,0f,0f,0f,0f,207.0f,931.0f,573.0f,-1034.0f,380.0f,-880.0f,-2570,68.41937f,-33.2204f,29.258959f,16.757978f,-100.0f,-8.126459f ) ;
  }

  @Test
  public void test792() {
    TestDrivers.surfaceShade(1227.0f,261.0f,161.0f,0f,100.0f,-93.0f,0f,310.0f,0f,0f,0f,0f,0f,304.0f,79.0f,576.0f,1228.0f,1913.0f,2976.0f,39,58.57227f,21.319462f,-33.837166f,-25.12544f,-34.560276f,-62.465157f ) ;
  }

  @Test
  public void test793() {
    TestDrivers.surfaceShade(1231.0f,-598.0f,0f,0f,2079.0f,1328.0f,0f,-1210.0f,0f,0f,0f,0f,0f,-551.0f,-521.0f,595.0f,-160.0f,-1282.0f,93.0f,1079,-1.0930396f,82.735405f,71.43341f,76.15939f,-65.028725f,0f ) ;
  }

  @Test
  public void test794() {
    TestDrivers.surfaceShade(1236.0f,-102.0f,0f,34.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,7.86229f,-22.396772f,0f ) ;
  }

  @Test
  public void test795() {
    TestDrivers.surfaceShade(-124.0f,896.0f,379.0f,0f,208.0f,-320.0f,0f,-245.0f,0f,0f,0f,0f,0f,90.0f,1426.0f,-706.0f,0f,0f,0f,-1496,34.413445f,22.04084f,55.96358f,-51.006756f,129.27617f,59.870384f ) ;
  }

  @Test
  public void test796() {
    TestDrivers.surfaceShade(1245.0f,880.0f,355.0f,0f,730.0f,-253.0f,0f,2145.0f,0f,0f,0f,0f,0f,-1612.0f,314.0f,678.0f,708.0f,-456.0f,619.0f,-836,-0.14581543f,0.69130313f,-0.666849f,19.506554f,-36.732334f,0.9565604f ) ;
  }

  @Test
  public void test797() {
    TestDrivers.surfaceShade(-126.0f,-382.0f,22.0f,0f,19.0f,1897.0f,0f,-245.0f,0f,0f,0f,0f,0f,926.0f,-78.0f,362.0f,796.0f,358.0f,916.0f,824,0.16554475f,-0.24746493f,-0.47678652f,100.0f,87.46976f,89.83794f ) ;
  }

  @Test
  public void test798() {
    TestDrivers.surfaceShade(127.0f,-1534.0f,346.0f,353.0f,0f,0f,0f,-67.526886f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,2.2305994E-5f,11.549511f,-100.0f ) ;
  }

  @Test
  public void test799() {
    TestDrivers.surfaceShade(-1277.0f,567.0f,878.0f,2.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,32.3933f,8.818342E-4f,3.0676377f ) ;
  }

  @Test
  public void test800() {
    TestDrivers.surfaceShade(-1284.0f,-611.0f,-119.0f,191.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,-4.0775717E-6f,10.623076f,86.928154f ) ;
  }

  @Test
  public void test801() {
    TestDrivers.surfaceShade(-1289.0f,1096.0f,-510.0f,0f,1540.0f,125.0f,0f,1757.0f,0f,0f,0f,0f,0f,2168.0f,-1228.0f,788.0f,-1385.0f,1502.0f,1457.0f,261,0.3092523f,0.101795495f,-0.69220066f,100.0f,100.0f,-5.6522107f ) ;
  }

  @Test
  public void test802() {
    TestDrivers.surfaceShade(-129.0f,0f,0f,0f,22.0f,-649.0f,0f,2193.0f,0f,0f,0f,0f,0f,-451.0f,-139.0f,-529.0f,1441.0f,1522.0f,-238.0f,1109,0.12950456f,0.94654185f,-0.2969319f,4.3907595f,0f,0f ) ;
  }

  @Test
  public void test803() {
    TestDrivers.surfaceShade(-1294.0f,0f,0f,0f,0.05535973f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,48.795414f,-9.896568f,-20.44124f,0f,0f,0f,-4,-0.33410817f,0.43254337f,-1.0069509f,-50.78494f,0f,0f ) ;
  }

  @Test
  public void test804() {
    TestDrivers.surfaceShade(1311.0f,570.0f,-261.0f,282.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,1.1109741f,75.65678f,51.135246f,30.622746f,6.2212266E-6f,-2.2148884E-5f ) ;
  }

  @Test
  public void test805() {
    TestDrivers.surfaceShade(-1314.0f,679.0f,0f,0f,31.0f,339.0f,0f,850.0f,0f,0f,0f,0f,0f,-97.0f,-1224.0f,1148.0f,-720.0f,-24.0f,-1974.0f,11,0.90799236f,-0.23894179f,-0.17803963f,21.2532f,8.86987f,0f ) ;
  }

  @Test
  public void test806() {
    TestDrivers.surfaceShade(-1315.0f,0f,0f,0f,1361.0f,-827.0f,0f,67.0f,0f,0f,0f,0f,0f,1153.0f,1570.0f,-479.0f,-1212.0f,-542.0f,-228.0f,246,0.3770463f,-0.16064255f,0.9115276f,-31.069263f,0f,0f ) ;
  }

  @Test
  public void test807() {
    TestDrivers.surfaceShade(132.0f,151.0f,-316.0f,0f,457.0f,2.0f,0f,-193.0f,0f,0f,0f,0f,0f,83.0f,644.0f,224.0f,0f,0f,0f,-1304,-66.94821f,3.5187645f,14.690254f,-92.16245f,6.47678f,-55.921093f ) ;
  }

  @Test
  public void test808() {
    TestDrivers.surfaceShade(-1326.0f,54.0f,0f,0f,430.0f,-7.0f,0f,-3542.0f,0f,0f,0f,0f,0f,840.0f,-615.0f,-547.0f,0f,0f,0f,2289,0.07373237f,0.14598884f,-0.050910324f,-30.78946f,46.86381f,0f ) ;
  }

  @Test
  public void test809() {
    TestDrivers.surfaceShade(-1338.0f,249.0f,-174.0f,208.0f,0f,0f,0f,-39.69865f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,135.32106f,-158.06369f,-79.92467f ) ;
  }

  @Test
  public void test810() {
    TestDrivers.surfaceShade(-1339.0f,-357.0f,-534.0f,-54.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-65.84699f,-24.872316f,76.79973f,24.283514f,5.18726E-5f,22.552685f ) ;
  }

  @Test
  public void test811() {
    TestDrivers.surfaceShade(1346.0f,-919.0f,-1174.0f,0f,1032.0f,-560.0f,0f,267.0f,0f,0f,0f,0f,0f,305.0f,1166.0f,494.0f,903.0f,766.0f,-997.0f,-377,0.6584579f,-0.05595782f,-0.27445915f,25.744915f,-23.207268f,100.0f ) ;
  }

  @Test
  public void test812() {
    TestDrivers.surfaceShade(-1348.0f,-974.0f,0f,0f,844.0f,3.0f,0f,-464.0f,0f,0f,0f,0f,0f,-938.0f,-459.0f,-758.0f,0f,0f,0f,-1042,1.1543487f,0.80865264f,-1.9181408f,-68.85508f,100.0f,0f ) ;
  }

  @Test
  public void test813() {
    TestDrivers.surfaceShade(1356.0f,-265.0f,0f,0f,51.0f,-634.0f,0f,-1.0f,0f,0f,0f,0f,0f,-891.0f,17.0f,-82.0f,0f,0f,0f,-618,33.61596f,-112.301254f,-46.0027f,3.4207766E-9f,-14.57388f,0f ) ;
  }

  @Test
  public void test814() {
    TestDrivers.surfaceShade(1358.0f,-1457.0f,390.0f,0f,934.0f,75.0f,0f,510.0f,0f,0f,0f,0f,0f,-1116.0f,-679.0f,-478.0f,-106.0f,512.0f,761.0f,1378,0.3726494f,0.17494826f,0.55269897f,41.16279f,42.182823f,-26.647417f ) ;
  }

  @Test
  public void test815() {
    TestDrivers.surfaceShade(1362.0f,0f,-190.0f,567.0f,0f,0f,0f,1130.0f,0f,0f,0f,0f,0f,721.0f,-766.0f,-245.0f,-788.0f,883.0f,-138.0f,4,0f,0f,0f,-136.27744f,0f,26.099083f ) ;
  }

  @Test
  public void test816() {
    TestDrivers.surfaceShade(-1363.0f,-1195.0f,2611.0f,0f,1010.0f,-809.0f,0f,-449.0f,0f,0f,0f,0f,0f,-379.0f,1680.0f,652.0f,0f,0f,0f,191,-0.39866287f,-0.14218217f,-0.05793564f,-85.86702f,-87.211975f,-89.684235f ) ;
  }

  @Test
  public void test817() {
    TestDrivers.surfaceShade(-137.0f,0f,0f,0f,0.14080362f,-100.0f,0f,-100.0f,0f,0f,0f,0f,0f,-97.65387f,-39.84071f,39.78779f,0f,0f,0f,1,-0.7473643f,1.0020688f,0.75931025f,100.0f,0f,0f ) ;
  }

  @Test
  public void test818() {
    TestDrivers.surfaceShade(-137.0f,0f,0f,0f,98.58752f,-97.83254f,0f,-99.99595f,0f,0f,0f,0f,0f,17.359663f,-99.98784f,4.9430137f,0f,0f,0f,-155,-0.9859319f,-0.12008056f,-0.116271056f,-95.803665f,0f,0f ) ;
  }

  @Test
  public void test819() {
    TestDrivers.surfaceShade(-1384.0f,116.0f,-258.0f,0f,58.0f,1724.0f,0f,147.0f,0f,0f,0f,0f,0f,1199.0f,-895.0f,660.0f,865.0f,743.0f,-1811.0f,1813,-0.54901713f,-0.7141189f,0.028992556f,46.98339f,16.41191f,-57.07378f ) ;
  }

  @Test
  public void test820() {
    TestDrivers.surfaceShade(-1386.0f,-8.0f,0f,0f,1127.0f,5.0f,0f,-2.0f,0f,0f,0f,0f,0f,270.0f,1170.0f,-1294.0f,0f,0f,0f,-492,-100.0f,93.1067f,63.79747f,100.0f,0.021615556f,0f ) ;
  }

  @Test
  public void test821() {
    TestDrivers.surfaceShade(-139.0f,1735.0f,0f,0f,8.0f,8.0f,0f,-488.0f,0f,0f,0f,0f,0f,-1170.0f,-348.0f,-117.0f,0f,0f,0f,-355,-12.45748f,69.33379f,-81.64879f,-11.350967f,-94.00004f,0f ) ;
  }

  @Test
  public void test822() {
    TestDrivers.surfaceShade(139.0f,415.0f,0f,0f,402.0f,0.0f,0f,-182.0f,0f,0f,0f,0f,0f,-275.0f,-739.0f,1520.0f,0f,0f,0f,-802,22.873741f,-29.770977f,-42.92296f,-104.435295f,-71.50062f,0f ) ;
  }

  @Test
  public void test823() {
    TestDrivers.surfaceShade(-1392.0f,-6.0f,0f,-236.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-30.261375f,7.062147E-4f,0f ) ;
  }

  @Test
  public void test824() {
    TestDrivers.surfaceShade(1408.0f,640.0f,-1082.0f,0f,307.0f,-1190.0f,0f,-581.0f,0f,0f,0f,0f,0f,-182.0f,251.0f,-872.0f,0f,0f,0f,-1594,0.007468688f,0.9600065f,0.27987808f,100.0f,-8.550644f,9.439791f ) ;
  }

  @Test
  public void test825() {
    TestDrivers.surfaceShade(-14.0f,-658.0f,0f,0f,768.0f,-971.0f,0f,324.0f,0f,0f,0f,0f,0f,703.0f,-12.0f,-774.0f,945.0f,378.0f,812.0f,46,83.16981f,98.7078f,74.010185f,36.79129f,-35.088005f,0f ) ;
  }

  @Test
  public void test826() {
    TestDrivers.surfaceShade(-141.0f,129.0f,-877.0f,0f,989.0f,-261.0f,0f,711.0f,0f,0f,0f,0f,0f,401.0f,1673.0f,85.0f,-832.0f,-264.0f,196.0f,-1391,4.1295953f,-1.4347816f,-15.593496f,1.4626709f,-21.87219f,-78.50265f ) ;
  }

  @Test
  public void test827() {
    TestDrivers.surfaceShade(142.0f,3142.0f,-321.0f,-53.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,3,44.57869f,5.8446436f,100.0f,-1.3287271E-4f,100.0f,38.475296f ) ;
  }

  @Test
  public void test828() {
    TestDrivers.surfaceShade(1430.0f,2001.0f,-1476.0f,0f,11.0f,501.0f,0f,-1895.0f,0f,0f,0f,0f,0f,-994.0f,-419.0f,674.0f,-404.0f,1597.0f,-758.0f,-1564,0.12930752f,-0.8168822f,-0.3366148f,-85.01756f,38.150284f,-11.475745f ) ;
  }

  @Test
  public void test829() {
    TestDrivers.surfaceShade(-143.0f,-1093.0f,-78.0f,0f,75.0f,891.0f,0f,1411.0f,0f,0f,0f,0f,0f,-595.0f,-698.0f,650.0f,1653.0f,-296.0f,920.0f,-1272,-0.6214426f,-0.025856564f,-0.596625f,-100.0f,-85.738045f,-97.74224f ) ;
  }

  @Test
  public void test830() {
    TestDrivers.surfaceShade(-143.0f,1242.0f,1016.0f,0f,323.0f,-836.0f,0f,-85.0f,0f,0f,0f,0f,0f,1428.0f,-956.0f,1093.0f,0f,0f,0f,299,-0.47306007f,0.36962318f,0.7732098f,-53.17487f,94.40653f,26.051294f ) ;
  }

  @Test
  public void test831() {
    TestDrivers.surfaceShade(-1437.0f,-20.0f,-38.0f,-49.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,17.593588f,0.0010204081f,5.3705694E-4f ) ;
  }

  @Test
  public void test832() {
    TestDrivers.surfaceShade(144.0f,1331.0f,0f,0f,491.0f,-3.0f,0f,-534.0f,0f,0f,0f,0f,0f,-359.0f,-649.0f,1587.0f,0f,0f,0f,-334,-27.618294f,3.3830986f,-4.864106f,55.066185f,99.04848f,0f ) ;
  }

  @Test
  public void test833() {
    TestDrivers.surfaceShade(144.0f,281.0f,-752.0f,0f,378.0f,-246.0f,0f,-276.0f,0f,0f,0f,0f,0f,110.0f,-317.0f,-1000.0f,0f,0f,0f,-197,47.98238f,29.087948f,12.428979f,-26.852556f,83.40649f,-62.397305f ) ;
  }

  @Test
  public void test834() {
    TestDrivers.surfaceShade(-1443.0f,-557.0f,0f,0f,123.0f,-287.0f,0f,-1.0f,0f,0f,0f,0f,0f,-408.0f,413.0f,240.0f,0f,0f,0f,-336,81.390114f,100.0f,-199.93097f,100.0f,-25.937628f,0f ) ;
  }

  @Test
  public void test835() {
    TestDrivers.surfaceShade(1449.0f,-174.0f,-1169.0f,0f,618.0f,1318.0f,0f,946.0f,0f,0f,0f,0f,0f,-870.0f,-381.0f,-783.0f,915.0f,1686.0f,-778.0f,-485,-12.464745f,-47.755123f,37.086884f,1.3680158f,-19.853153f,54.9931f ) ;
  }

  @Test
  public void test836() {
    TestDrivers.surfaceShade(1450.0f,146.0f,-739.0f,0f,59.0f,34.0f,0f,-972.0f,0f,0f,0f,0f,0f,-373.0f,-376.0f,771.0f,-789.0f,-1332.0f,599.0f,1595,39.13336f,22.823347f,30.062675f,63.185104f,-46.764137f,-69.54424f ) ;
  }

  @Test
  public void test837() {
    TestDrivers.surfaceShade(-1475.0f,-192.0f,-1763.0f,-423.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-23.89079f,1.2312845E-5f,-80.95313f ) ;
  }

  @Test
  public void test838() {
    TestDrivers.surfaceShade(1475.0f,-528.0f,-4.0f,0f,310.0f,-376.0f,0f,701.0f,0f,0f,0f,0f,0f,307.0f,-912.0f,-306.0f,-386.0f,822.0f,666.0f,-556,35.548294f,59.791046f,-141.36633f,-43.105125f,82.14274f,-2.1466576E-6f ) ;
  }

  @Test
  public void test839() {
    TestDrivers.surfaceShade(1491.0f,1275.0f,1560.0f,0f,285.0f,-1250.0f,0f,2781.0f,0f,0f,0f,0f,0f,-559.0f,-1010.0f,100.0f,-909.0f,621.0f,251.0f,1399,-0.37269145f,0.44172582f,0.14592044f,9.815033f,65.42172f,46.34116f ) ;
  }

  @Test
  public void test840() {
    TestDrivers.surfaceShade(-1492.0f,-1636.0f,0f,-5.0f,0f,0f,0f,-50.208782f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-2.0831072f,1.2224939E-4f,0f ) ;
  }

  @Test
  public void test841() {
    TestDrivers.surfaceShade(1503.0f,0f,2178.0f,0f,124.0f,-1930.0f,0f,367.0f,0f,0f,0f,0f,0f,-476.0f,765.0f,126.0f,573.0f,1624.0f,1758.0f,-20,70.60143f,42.180305f,10.621799f,-21.973299f,0f,-15.06702f ) ;
  }

  @Test
  public void test842() {
    TestDrivers.surfaceShade(-15.0f,0f,0f,0f,5.020885f,-2.348027f,0f,0.0f,0f,0f,0f,0f,0f,97.9809f,100.0f,-38.879337f,0f,0f,0f,4,-1.9480093f,1.2747244f,-1.0824783f,-0.0015997433f,0f,0f ) ;
  }

  @Test
  public void test843() {
    TestDrivers.surfaceShade(-15.0f,541.0f,0f,-10.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-20.579268f,-100.0f,-95.91396f,0.006666667f,70.07672f,0f ) ;
  }

  @Test
  public void test844() {
    TestDrivers.surfaceShade(151.0f,0f,0f,0f,703.0f,504.0f,-463.0f,616.0f,0f,0f,0f,0f,0f,903.0f,-519.0f,960.0f,-710.0f,327.0f,-931.0f,-316,75.76895f,-15.182263f,-79.47808f,58.546772f,0f,0f ) ;
  }

  @Test
  public void test845() {
    TestDrivers.surfaceShade(1540.0f,-863.0f,0f,0f,7.0f,2.0f,0f,-1546.0f,0f,0f,0f,0f,0f,273.0f,-948.0f,-924.0f,0f,0f,0f,1248,0.119118415f,0.627844f,0.34589025f,92.07275f,100.0f,0f ) ;
  }

  @Test
  public void test846() {
    TestDrivers.surfaceShade(-1547.0f,77.0f,-431.0f,0f,842.0f,384.0f,0f,-492.0f,0f,0f,0f,0f,0f,-270.0f,414.0f,707.0f,-541.0f,291.0f,-1080.0f,1972,-0.1925555f,-0.22932123f,-0.13713369f,-4.4094343f,75.426956f,24.635536f ) ;
  }

  @Test
  public void test847() {
    TestDrivers.surfaceShade(-1550.0f,9.0f,-246.0f,0f,108.0f,-859.0f,0f,1453.0f,0f,0f,0f,0f,0f,-413.0f,-567.0f,804.0f,2090.0f,-1133.0f,237.0f,41,-7.7448516f,52.266094f,32.880913f,-36.68991f,-95.87042f,-92.431274f ) ;
  }

  @Test
  public void test848() {
    TestDrivers.surfaceShade(1560.0f,0f,0f,-753.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,49.70976f,26.745016f,-71.34428f,1.5928942f,0f,0f ) ;
  }

  @Test
  public void test849() {
    TestDrivers.surfaceShade(1565.0f,0f,0f,0f,7.2031016E-6f,-45.052505f,0f,-97.29198f,0f,0f,0f,0f,0f,100.0f,51.731514f,54.515522f,0f,0f,0f,-3,-0.953677f,3.699092f,1.9449288f,11.701906f,0f,0f ) ;
  }

  @Test
  public void test850() {
    TestDrivers.surfaceShade(-157.0f,-410.0f,0f,0f,101.0f,-2188.0f,0f,-2655.0f,0f,0f,0f,0f,0f,-769.0f,-441.0f,232.0f,0f,0f,0f,-324,-28.46034f,69.78944f,38.323875f,15.343372f,-22.615017f,0f ) ;
  }

  @Test
  public void test851() {
    TestDrivers.surfaceShade(1575.0f,0f,0f,0f,85.436844f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,55.94911f,100.0f,43.640507f,0f,0f,0f,942,-0.8362382f,0.49987078f,-0.08587323f,24.134417f,0f,0f ) ;
  }

  @Test
  public void test852() {
    TestDrivers.surfaceShade(-1576.0f,0f,170.0f,-367.0f,0f,0f,0f,189.0f,0f,0f,0f,0f,0f,-51.0f,-530.0f,832.0f,506.0f,1975.0f,35.0f,6,0f,0f,0f,-43.03842f,0f,-109.18856f ) ;
  }

  @Test
  public void test853() {
    TestDrivers.surfaceShade(158.0f,-704.0f,1546.0f,0f,854.0f,-2499.0f,0f,1.0f,0f,0f,0f,0f,0f,-401.0f,-636.0f,-985.0f,0f,0f,0f,291,-0.09102776f,0.8945286f,-0.41621035f,100.0f,-24.157133f,-100.0f ) ;
  }

  @Test
  public void test854() {
    TestDrivers.surfaceShade(1581.0f,519.0f,0f,0f,720.0f,-983.0f,0f,-150.0f,0f,0f,0f,0f,0f,-323.0f,-665.0f,-782.0f,0f,0f,0f,3,0.88176644f,-0.056311242f,-0.9929124f,23.774548f,-5.0514988E-9f,0f ) ;
  }

  @Test
  public void test855() {
    TestDrivers.surfaceShade(-1589.0f,6.0f,-2194.0f,1.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-6.293266E-4f,0.16666667f,-67.241745f ) ;
  }

  @Test
  public void test856() {
    TestDrivers.surfaceShade(-159.0f,0f,754.0f,0f,25.0f,0.0f,0f,-458.0f,0f,0f,0f,0f,0f,-379.0f,-880.0f,-731.0f,0f,0f,0f,-2440,29.253014f,69.89808f,-99.31217f,-100.0f,0f,13.625991f ) ;
  }

  @Test
  public void test857() {
    TestDrivers.surfaceShade(-159.0f,-558.0f,-585.0f,0f,70.0f,458.0f,0f,1507.0f,0f,0f,0f,0f,0f,455.0f,421.0f,-13.0f,33.0f,-778.0f,-874.0f,-710,-88.107574f,95.28959f,2.1516821f,-30.182653f,-8.043886f,-7.064898f ) ;
  }

  @Test
  public void test858() {
    TestDrivers.surfaceShade(-1600.0f,-636.0f,0f,931.0f,0f,0f,0f,-95.8513f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,75.46119f,13.595709f,0f ) ;
  }

  @Test
  public void test859() {
    TestDrivers.surfaceShade(160.0f,105.0f,-675.0f,0f,948.0f,-847.0f,0f,194.0f,0f,0f,0f,0f,0f,-270.0f,-13.0f,320.0f,-1413.0f,-749.0f,497.0f,129,-54.20925f,-30.754663f,-46.988464f,69.34715f,-42.78749f,-51.781414f ) ;
  }

  @Test
  public void test860() {
    TestDrivers.surfaceShade(160.0f,-651.0f,-889.0f,0f,11.0f,-1081.0f,0f,987.0f,0f,0f,0f,0f,0f,887.0f,-579.0f,390.0f,-1258.0f,1183.0f,-300.0f,-1314,-0.7084575f,-0.17687586f,1.3099691f,-65.99899f,77.32949f,99.72974f ) ;
  }

  @Test
  public void test861() {
    TestDrivers.surfaceShade(1606.0f,1744.0f,-80.0f,-506.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,96.81982f,-68.32345f,44.327366f ) ;
  }

  @Test
  public void test862() {
    TestDrivers.surfaceShade(16.0f,0f,0f,0f,230.0f,-825.0f,930.0f,747.0f,0f,0f,0f,0f,0f,-874.0f,-921.0f,-681.0f,263.0f,-51.0f,-830.0f,329,-26.859276f,72.8552f,40.73021f,85.19248f,0f,0f ) ;
  }

  @Test
  public void test863() {
    TestDrivers.surfaceShade(16.0f,-1203.0f,-530.0f,0f,2306.0f,-83.0f,0f,1.0f,0f,0f,0f,0f,0f,1550.0f,1387.0f,-181.0f,0f,0f,0f,-770,-0.34916043f,-0.68212384f,-0.5140165f,4.2305884f,57.88575f,79.642136f ) ;
  }

  @Test
  public void test864() {
    TestDrivers.surfaceShade(-1611.0f,45.0f,36.0f,17.0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-8.826549f,0.0013071896f,0.001633987f ) ;
  }

  @Test
  public void test865() {
    TestDrivers.surfaceShade(163.0f,0f,738.0f,0f,487.0f,-1760.0f,0f,393.0f,0f,0f,0f,0f,0f,-544.0f,-249.0f,-700.0f,1028.0f,-1390.0f,-753.0f,-777,-28.38762f,-64.63608f,45.05321f,-30.916739f,0f,61.65975f ) ;
  }

  @Test
  public void test866() {
    TestDrivers.surfaceShade(1639.0f,0f,0f,0f,36.38131f,-26.15478f,0f,-51.25817f,0f,0f,0f,0f,0f,-15.5344f,81.18786f,63.85479f,0f,0f,0f,-2,-1.7669293f,0.7211782f,-1.9021878f,-98.3575f,0f,0f ) ;
  }

  @Test
  public void test867() {
    TestDrivers.surfaceShade(-1643.0f,0f,0f,0f,27.0f,484.0f,0f,-227.0f,0f,0f,0f,0f,0f,-3068.0f,-1314.0f,921.0f,1309.0f,-325.0f,62.0f,38,-0.07044951f,0.5595351f,-0.8258071f,4.0614595f,0f,0f ) ;
  }

  @Test
  public void test868() {
    TestDrivers.surfaceShade(1649.0f,-51.0f,0f,0f,895.0f,-13.0f,0f,-623.0f,0f,0f,0f,0f,0f,-585.0f,-54.0f,1267.0f,0f,0f,0f,-981,0.54106295f,-0.031487133f,-0.6433825f,91.68669f,4.2759047f,0f ) ;
  }

  @Test
  public void test869() {
    TestDrivers.surfaceShade(165.0f,-1156.0f,476.0f,5.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-4,-30.88181f,81.62243f,-34.80057f,0.0012121212f,-98.0992f,4.2016807E-4f ) ;
  }

  @Test
  public void test870() {
    TestDrivers.surfaceShade(1675.0f,-614.0f,520.0f,0f,217.0f,-1058.0f,0f,68.0f,0f,0f,0f,0f,0f,579.0f,-208.0f,216.0f,-459.0f,-805.0f,-946.0f,-1260,-4.3966174f,14.860092f,26.095097f,100.0f,-84.69045f,99.99987f ) ;
  }

  @Test
  public void test871() {
    TestDrivers.surfaceShade(-1680.0f,293.0f,0f,0f,10.0f,-1277.0f,0f,-1321.0f,0f,0f,0f,0f,0f,-807.0f,411.0f,-460.0f,0f,0f,0f,-966,-0.0323609f,0.9661586f,0.9474679f,-100.0f,22.019033f,0f ) ;
  }

  @Test
  public void test872() {
    TestDrivers.surfaceShade(-1683.0f,884.0f,-1048.0f,0f,754.0f,-174.0f,0f,-878.0f,0f,0f,0f,0f,0f,-43.0f,424.0f,638.0f,0f,0f,0f,199,-66.51369f,-78.57757f,47.737934f,-86.276375f,71.287415f,-100.0f ) ;
  }

  @Test
  public void test873() {
    TestDrivers.surfaceShade(-1694.0f,-997.0f,829.0f,0f,337.0f,-453.0f,0f,-886.0f,0f,0f,0f,0f,0f,912.0f,-477.0f,44.0f,0f,0f,0f,-111,0.10695782f,0.25321507f,0.5281375f,-48.502277f,-94.99473f,24.841053f ) ;
  }

  @Test
  public void test874() {
    TestDrivers.surfaceShade(1708.0f,-1904.0f,0f,0f,512.0f,-1883.0f,0f,0.0f,0f,0f,0f,0f,0f,-897.0f,-97.0f,1265.0f,0f,0f,0f,358,0.27339575f,0.3928138f,0.19142579f,97.91275f,-100.0f,0f ) ;
  }

  @Test
  public void test875() {
    TestDrivers.surfaceShade(1709.0f,945.0f,-283.0f,0f,176.0f,-290.0f,0f,-8.0f,0f,0f,0f,0f,0f,520.0f,809.0f,49.0f,0f,0f,0f,893,76.29135f,-52.690723f,60.312046f,100.0f,-86.817696f,-43.29703f ) ;
  }

  @Test
  public void test876() {
    TestDrivers.surfaceShade(17.0f,0f,0f,0f,29.31005f,-79.22252f,0f,-100.0f,0f,0f,0f,0f,0f,-100.0f,10.705798f,91.75475f,0f,0f,0f,322,0.62437147f,-0.5376323f,-0.53618896f,-99.09377f,0f,0f ) ;
  }

  @Test
  public void test877() {
    TestDrivers.surfaceShade(17.0f,-740.0f,0f,0f,221.0f,140.0f,276.0f,549.0f,0f,0f,0f,0f,0f,780.0f,655.0f,644.0f,-580.0f,-295.0f,749.0f,717,-59.329407f,82.05269f,95.07228f,-54.208466f,74.74903f,0f ) ;
  }

  @Test
  public void test878() {
    TestDrivers.surfaceShade(1737.0f,0f,0f,0f,53.0f,987.0f,0f,364.0f,0f,0f,0f,0f,0f,-1457.0f,297.0f,679.0f,471.0f,-876.0f,-1220.0f,104,0.1751363f,0.7427089f,0.050941143f,78.920006f,0f,0f ) ;
  }

  @Test
  public void test879() {
    TestDrivers.surfaceShade(-174.0f,767.0f,0f,0f,916.0f,-1313.0f,0f,-821.0f,0f,0f,0f,0f,0f,-427.0f,999.0f,-1337.0f,0f,0f,0f,389,-0.09444389f,-0.37647972f,0.92159826f,-76.97076f,-100.0f,0f ) ;
  }

  @Test
  public void test880() {
    TestDrivers.surfaceShade(-1743.0f,0f,0f,0f,26.717903f,-16.118864f,0f,0.0f,0f,0f,0f,0f,0f,-14.460221f,-27.628485f,-100.0f,0f,0f,0f,-1,0.18897676f,0.5074211f,-2.914566f,-50.451763f,0f,0f ) ;
  }

  @Test
  public void test881() {
    TestDrivers.surfaceShade(1756.0f,887.0f,979.0f,0f,1028.0f,-857.0f,0f,-548.0f,0f,0f,0f,0f,0f,816.0f,1429.0f,-29.0f,0f,0f,0f,-933,0.31228125f,-0.3470371f,0.1848835f,-82.85282f,-99.9991f,55.180756f ) ;
  }

  @Test
  public void test882() {
    TestDrivers.surfaceShade(-1760.0f,0f,0f,0f,49.0f,-584.0f,0f,71.0f,0f,0f,0f,0f,0f,-1352.0f,-30.0f,273.0f,-784.0f,-1034.0f,1062.0f,273,-0.03700584f,-0.5555733f,-0.45239663f,66.6152f,0f,0f ) ;
  }

  @Test
  public void test883() {
    TestDrivers.surfaceShade(-1767.0f,108.0f,-782.0f,0f,454.0f,-1329.0f,0f,660.0f,0f,0f,0f,0f,0f,-1271.0f,-740.0f,-504.0f,-401.0f,-752.0f,-186.0f,72,0.33319598f,-0.06391492f,0.17610084f,-27.799326f,27.614843f,100.0f ) ;
  }

  @Test
  public void test884() {
    TestDrivers.surfaceShade(1767.0f,-582.0f,-995.0f,0f,692.0f,1098.0f,0f,3134.0f,0f,0f,0f,0f,0f,-382.0f,767.0f,821.0f,1152.0f,1310.0f,-892.0f,212,-0.48601905f,-0.64728063f,-0.40760207f,-100.0f,53.091114f,-20.199465f ) ;
  }

  @Test
  public void test885() {
    TestDrivers.surfaceShade(177.0f,0f,0f,0f,664.0f,761.0f,0f,-406.0f,0f,0f,0f,0f,0f,850.0f,749.0f,302.0f,121.0f,-654.0f,524.0f,848,-0.06105318f,0.08414777f,-0.22633183f,-64.42488f,0f,0f ) ;
  }

  @Test
  public void test886() {
    TestDrivers.surfaceShade(18.0f,436.0f,-143.0f,-56.0f,0f,0f,0f,-14.510934f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0f,0f,0f,-0.0026041667f,-8.308408E-5f,1.2487512E-4f ) ;
  }

  @Test
  public void test887() {
    TestDrivers.surfaceShade(-181.0f,344.0f,0f,-686.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,7.602893f,2.3086667f,-40.71268f,-57.60809f,27.096104f,0f ) ;
  }

  @Test
  public void test888() {
    TestDrivers.surfaceShade(1811.0f,1324.0f,0f,0f,2153.0f,-218.0f,0f,473.0f,0f,0f,0f,0f,0f,-1670.0f,469.0f,-427.0f,723.0f,-119.0f,-1678.0f,619,0.826658f,0.05874372f,0.35837653f,-100.0f,-13.703035f,0f ) ;
  }

  @Test
  public void test889() {
    TestDrivers.surfaceShade(-1834.0f,0f,0f,0f,129.27217f,-88.22567f,0f,0.0f,0f,0f,0f,0f,0f,-65.22426f,93.1466f,55.692398f,0f,0f,0f,1,-0.9994888f,-1.0276071f,1.6221845f,100.0f,0f,0f ) ;
  }

  @Test
  public void test890() {
    TestDrivers.surfaceShade(-185.0f,927.0f,0f,0f,1528.0f,539.0f,0f,875.0f,0f,0f,0f,0f,0f,-821.0f,580.0f,372.0f,549.0f,784.0f,-682.0f,947,99.53725f,95.01005f,70.33681f,-37.888798f,-90.63695f,0f ) ;
  }

  @Test
  public void test891() {
    TestDrivers.surfaceShade(1892.0f,1077.0f,0f,-868.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,100.0f,-188.17755f,0f ) ;
  }

  @Test
  public void test892() {
    TestDrivers.surfaceShade(-190.0f,963.0f,0f,0f,528.0f,-520.0f,0f,-610.0f,0f,0f,0f,0f,0f,-679.0f,707.0f,-930.0f,0f,0f,0f,-171,37.210274f,-56.35255f,-14.3201275f,-97.11557f,14.016006f,0f ) ;
  }

  @Test
  public void test893() {
    TestDrivers.surfaceShade(-1918.0f,1630.0f,-1740.0f,0f,946.0f,-2354.0f,0f,500.0f,0f,0f,0f,0f,0f,-147.0f,513.0f,-594.0f,-1159.0f,-706.0f,803.0f,-1202,13.035525f,-5.0495386f,-7.5869284f,-92.84345f,100.0f,-100.0f ) ;
  }

  @Test
  public void test894() {
    TestDrivers.surfaceShade(192.0f,-19.0f,-69.0f,-107.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-57.216496f,4.918839E-4f,-14.758643f ) ;
  }

  @Test
  public void test895() {
    TestDrivers.surfaceShade(1921.0f,159.0f,0f,0f,1381.0f,-2195.0f,0f,1466.0f,0f,0f,0f,0f,0f,-195.0f,299.0f,396.0f,174.0f,16.0f,-615.0f,550,-0.45604113f,0.45797643f,-0.57036203f,82.40441f,0.011204724f,0f ) ;
  }

  @Test
  public void test896() {
    TestDrivers.surfaceShade(-1922.0f,259.0f,864.0f,-160.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-100.0f,100.0f,-51.1187f,-78.76448f,-2.4131274E-5f,-100.0f ) ;
  }

  @Test
  public void test897() {
    TestDrivers.surfaceShade(195.0f,0f,0f,0f,0.9357806f,-86.5222f,0f,-85.65444f,0f,0f,0f,0f,0f,99.06734f,34.164047f,33.165108f,0f,0f,0f,337,-0.02792993f,-0.078849815f,-0.154224f,80.44258f,0f,0f ) ;
  }

  @Test
  public void test898() {
    TestDrivers.surfaceShade(195.0f,-843.0f,378.0f,0f,827.0f,-807.0f,0f,-717.0f,0f,0f,0f,0f,0f,-312.0f,645.0f,-863.0f,0f,0f,0f,-40,-24.27683f,97.876625f,81.92908f,84.8737f,-71.72178f,71.4607f ) ;
  }

  @Test
  public void test899() {
    TestDrivers.surfaceShade(-1959.0f,-590.0f,-607.0f,295.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-30.900324f,-5.7454754E-6f,-73.40428f ) ;
  }

  @Test
  public void test900() {
    TestDrivers.surfaceShade(196.0f,-159.0f,423.0f,0f,355.0f,-378.0f,0f,429.0f,0f,0f,0f,0f,0f,-984.0f,391.0f,-31.0f,-314.0f,3.0f,270.0f,751,14.900321f,1.0906856f,89.21486f,-56.834564f,-15.948193f,55.883724f ) ;
  }

  @Test
  public void test901() {
    TestDrivers.surfaceShade(-1977.0f,870.0f,-578.0f,0f,640.0f,-770.0f,0f,-6.0f,0f,0f,0f,0f,0f,-488.0f,782.0f,433.0f,0f,0f,0f,149,2.8772523f,2.6323833f,-2.434388f,-100.0f,100.0f,-27.682257f ) ;
  }

  @Test
  public void test902() {
    TestDrivers.surfaceShade(-199.0f,-771.0f,-480.0f,0f,193.0f,-2695.0f,0f,-1087.0f,0f,0f,0f,0f,0f,550.0f,-235.0f,772.0f,0f,0f,0f,1410,-54.760143f,-41.27974f,26.447332f,69.52333f,-100.0f,-99.998726f ) ;
  }

  @Test
  public void test903() {
    TestDrivers.surfaceShade(-1996.0f,1237.0f,-719.0f,0f,382.0f,-366.0f,0f,-2409.0f,0f,0f,0f,0f,0f,1749.0f,-429.0f,1103.0f,0f,0f,0f,-144,-0.835556f,-0.4761092f,-0.27416462f,-100.0f,-90.776924f,-79.20102f ) ;
  }

  @Test
  public void test904() {
    TestDrivers.surfaceShade(1997.0f,287.0f,0f,0f,1824.0f,-3.0f,0f,8.0f,0f,0f,0f,0f,0f,-719.0f,1226.0f,-473.0f,0f,0f,0f,218,-84.98706f,-89.58907f,-100.0f,11.786629f,32.90631f,0f ) ;
  }

  @Test
  public void test905() {
    TestDrivers.surfaceShade(-201.0f,0f,0f,0f,-146.0f,382.0f,318.0f,-675.0f,0f,0f,0f,0f,0f,-223.0f,532.0f,949.0f,-192.0f,616.0f,318.0f,57,75.89318f,-3.71712f,39.34033f,-77.4386f,0f,0f ) ;
  }

  @Test
  public void test906() {
    TestDrivers.surfaceShade(-201.0f,0f,0f,0f,591.0f,-65.0f,0f,2106.0f,0f,0f,0f,0f,0f,29.0f,-907.0f,-622.0f,862.0f,527.0f,1381.0f,-3156,0.108858965f,0.07472262f,0.8466158f,3.9398541f,0f,0f ) ;
  }

  @Test
  public void test907() {
    TestDrivers.surfaceShade(-2020.0f,-545.0f,0f,0f,308.0f,-1622.0f,0f,464.0f,0f,0f,0f,0f,0f,311.0f,-26.0f,700.0f,846.0f,-1046.0f,-1704.0f,57,-0.055581972f,0.6363898f,0.04833161f,98.89284f,-0.37259027f,0f ) ;
  }

  @Test
  public void test908() {
    TestDrivers.surfaceShade(2020.0f,-816.0f,0f,0f,3.0f,-1007.0f,0f,984.0f,0f,0f,0f,0f,0f,-532.0f,1064.0f,1021.0f,-384.0f,2244.0f,433.0f,35,44.844925f,-73.53619f,100.0f,-40.17584f,100.0f,0f ) ;
  }

  @Test
  public void test909() {
    TestDrivers.surfaceShade(202.0f,766.0f,-208.0f,0f,140.0f,304.0f,0f,1968.0f,0f,0f,0f,0f,0f,395.0f,660.0f,-732.0f,-1658.0f,-1543.0f,942.0f,968,42.1193f,-52.658695f,-24.75084f,61.78846f,76.70747f,-40.68975f ) ;
  }

  @Test
  public void test910() {
    TestDrivers.surfaceShade(-203.0f,-374.0f,0f,0f,-543.0f,-844.0f,416.0f,-504.0f,0f,0f,0f,0f,0f,-659.0f,-917.0f,640.0f,-26.0f,7.0f,-889.0f,101,58.12267f,8.890155f,62.31021f,64.36284f,43.157536f,0f ) ;
  }

  @Test
  public void test911() {
    TestDrivers.surfaceShade(2034.0f,-259.0f,0f,0f,428.0f,1045.0f,0f,1849.0f,0f,0f,0f,0f,0f,-383.0f,-49.0f,-881.0f,769.0f,-462.0f,29.0f,865,-0.79987365f,0.163619f,0.33863142f,52.086555f,-2.0645535f,0f ) ;
  }

  @Test
  public void test912() {
    TestDrivers.surfaceShade(-2058.0f,1000.0f,1961.0f,0f,112.0f,544.0f,0f,-655.0f,0f,0f,0f,0f,0f,352.0f,-846.0f,189.0f,501.0f,-907.0f,-1018.0f,751,-5.5203075f,-2.2238278f,0.32692227f,-64.50558f,99.999985f,19.069132f ) ;
  }

  @Test
  public void test913() {
    TestDrivers.surfaceShade(-2078.0f,2075.0f,0f,0f,223.0f,-387.0f,0f,0.0f,0f,0f,0f,0f,0f,-925.0f,-703.0f,-31.0f,0f,0f,0f,656,4.0668006f,-5.312472f,-0.87493443f,-100.0f,100.0f,0f ) ;
  }

  @Test
  public void test914() {
    TestDrivers.surfaceShade(208.0f,0f,0f,699.0f,0f,0f,0f,16.762486f,0f,0f,0f,0f,0f,36.866257f,0.97479546f,-45.463303f,507.0f,-386.0f,932.0f,4,0f,0f,0f,8.828449f,0f,0f ) ;
  }

  @Test
  public void test915() {
    TestDrivers.surfaceShade(-208.0f,1022.0f,0f,0f,94.0f,4.0f,0f,-221.0f,0f,0f,0f,0f,0f,384.0f,-1903.0f,717.0f,0f,0f,0f,-537,-86.42587f,130.66595f,50.42169f,74.36409f,41.06764f,0f ) ;
  }

  @Test
  public void test916() {
    TestDrivers.surfaceShade(-2083.0f,-517.0f,0f,0f,901.0f,-875.0f,0f,2.0f,0f,0f,0f,0f,0f,1151.0f,-1355.0f,107.0f,0f,0f,0f,1264,-0.39254323f,-0.3308672f,-1.1321826f,71.22302f,-5.3934097f,0f ) ;
  }

  @Test
  public void test917() {
    TestDrivers.surfaceShade(-2.0f,1093.0f,943.0f,-293.0f,0f,0f,0f,-20.438877f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,41.069626f,-84.76023f,17.930801f ) ;
  }

  @Test
  public void test918() {
    TestDrivers.surfaceShade(-2.0f,-343.0f,0f,0f,1196.0f,-18.0f,0f,385.0f,0f,0f,0f,0f,0f,456.0f,71.0f,89.0f,978.0f,-733.0f,-643.0f,252,-1.0955117f,-16.509953f,5.0844f,87.80298f,4.947016f,0f ) ;
  }

  @Test
  public void test919() {
    TestDrivers.surfaceShade(-2.0f,-797.0f,670.0f,0f,588.0f,-332.0f,0f,103.0f,0f,0f,0f,0f,0f,-487.0f,-721.0f,-951.0f,71.0f,-494.0f,320.0f,769,33.949398f,35.259987f,-20.73195f,-23.424894f,-71.33256f,-25.674984f ) ;
  }

  @Test
  public void test920() {
    TestDrivers.surfaceShade(-210.0f,-661.0f,736.0f,0f,841.0f,-3.0f,0f,-439.0f,0f,0f,0f,0f,0f,675.0f,122.0f,264.0f,0f,0f,0f,-61,-84.50396f,107.84991f,68.7931f,48.76474f,27.653625f,-100.0f ) ;
  }

  @Test
  public void test921() {
    TestDrivers.surfaceShade(-21.0f,0f,0f,0f,62.21581f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-71.08998f,34.43365f,-24.053185f,0f,0f,0f,-779,-0.0038759983f,-0.19894603f,-0.27334726f,-35.527996f,0f,0f ) ;
  }

  @Test
  public void test922() {
    TestDrivers.surfaceShade(211.0f,-215.0f,0f,0f,60.0f,-1115.0f,0f,0.0f,0f,0f,0f,0f,0f,-774.0f,-858.0f,-792.0f,0f,0f,0f,1032,-53.017433f,-1.2288741f,53.143772f,-136.17485f,-1.6402272f,0f ) ;
  }

  @Test
  public void test923() {
    TestDrivers.surfaceShade(-215.0f,0f,0f,0f,39.0f,858.0f,0f,60.0f,0f,0f,0f,0f,0f,547.0f,-975.0f,911.0f,-861.0f,807.0f,19.0f,1302,27.363323f,26.64681f,12.088807f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test924() {
    TestDrivers.surfaceShade(-2157.0f,0f,0f,0f,916.0f,-1022.0f,0f,2324.0f,0f,0f,0f,0f,0f,430.0f,652.0f,-230.0f,-105.0f,-1204.0f,2210.0f,801,-0.89559734f,0.4441746f,0.040946346f,-1.9240067f,0f,0f ) ;
  }

  @Test
  public void test925() {
    TestDrivers.surfaceShade(-218.0f,-7.0f,-1047.0f,-5.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,4,99.99968f,100.0f,99.99966f,9.174312E-4f,0.028571429f,1.9102197E-4f ) ;
  }

  @Test
  public void test926() {
    TestDrivers.surfaceShade(-2209.0f,-1049.0f,1280.0f,0f,127.0f,473.0f,0f,-114.0f,0f,0f,0f,0f,0f,521.0f,317.0f,880.0f,203.0f,-356.0f,-876.0f,-909,-26.690014f,42.546997f,0.47511265f,20.338388f,-99.99998f,100.0f ) ;
  }

  @Test
  public void test927() {
    TestDrivers.surfaceShade(221.0f,0f,0f,0f,34.255405f,-51.091343f,0f,0.0f,0f,0f,0f,0f,0f,41.489918f,-91.78577f,-22.00328f,0f,0f,0f,578,0.45507655f,0.0988243f,0.58706003f,36.388737f,0f,0f ) ;
  }

  @Test
  public void test928() {
    TestDrivers.surfaceShade(-2213.0f,164.0f,-47.0f,0f,1135.0f,1173.0f,0f,-1374.0f,0f,0f,0f,0f,0f,2150.0f,830.0f,-730.0f,-257.0f,268.0f,-662.0f,583,0.13081759f,0.17436175f,0.5835316f,-37.551723f,-29.964798f,52.20644f ) ;
  }

  @Test
  public void test929() {
    TestDrivers.surfaceShade(-2215.0f,461.0f,0f,0f,2290.0f,-1126.0f,0f,-1697.0f,0f,0f,0f,0f,0f,1217.0f,-888.0f,1231.0f,0f,0f,0f,1246,-0.9623716f,0.26768255f,-0.04677328f,88.35921f,-96.50005f,0f ) ;
  }

  @Test
  public void test930() {
    TestDrivers.surfaceShade(222.0f,0f,0f,0f,63.0f,499.0f,0f,1005.0f,0f,0f,0f,0f,0f,-137.0f,129.0f,104.0f,847.0f,732.0f,-36.0f,-622,-76.00825f,-54.550797f,-85.031334f,94.81588f,0f,0f ) ;
  }

  @Test
  public void test931() {
    TestDrivers.surfaceShade(-222.0f,1307.0f,9.0f,0f,519.0f,-1105.0f,0f,775.0f,0f,0f,0f,0f,0f,-795.0f,-107.0f,-912.0f,485.0f,-748.0f,1830.0f,510,-0.41743404f,-0.7504514f,0.45192802f,8.625317f,15.762115f,-14.086885f ) ;
  }

  @Test
  public void test932() {
    TestDrivers.surfaceShade(-224.0f,0f,0f,0f,1186.0f,-5.0f,0f,714.0f,0f,0f,0f,0f,0f,304.0f,-219.0f,180.0f,-1020.0f,-918.0f,-593.0f,-406,50.886642f,91.88644f,25.853283f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test933() {
    TestDrivers.surfaceShade(-2245.0f,1794.0f,0f,0f,247.0f,-1226.0f,0f,-1083.0f,0f,0f,0f,0f,0f,-800.0f,-993.0f,502.0f,0f,0f,0f,-1081,0.5659258f,0.12906826f,-0.8148583f,53.781754f,1.3944566f,0f ) ;
  }

  @Test
  public void test934() {
    TestDrivers.surfaceShade(-225.0f,-1774.0f,0f,0f,2.0f,2.0f,0f,-84.0f,0f,0f,0f,0f,0f,-454.0f,613.0f,-404.0f,0f,0f,0f,1353,5.638736f,11.753666f,11.497553f,-88.89193f,-11.0408745f,0f ) ;
  }

  @Test
  public void test935() {
    TestDrivers.surfaceShade(-2268.0f,499.0f,-53.0f,0f,86.0f,-476.0f,0f,22.0f,0f,0f,0f,0f,0f,487.0f,-102.0f,71.0f,390.0f,956.0f,-364.0f,488,-0.36880413f,-0.7746738f,-0.16430825f,85.2439f,-22.468588f,-0.0021088321f ) ;
  }

  @Test
  public void test936() {
    TestDrivers.surfaceShade(-2279.0f,-938.0f,0f,0f,49.0f,5.0f,0f,-1508.0f,0f,0f,0f,0f,0f,631.0f,147.0f,703.0f,0f,0f,0f,-292,84.383766f,100.13644f,-96.9745f,-97.717804f,-100.0f,0f ) ;
  }

  @Test
  public void test937() {
    TestDrivers.surfaceShade(-228.0f,0f,0f,844.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,8.604299f,0f,0f ) ;
  }

  @Test
  public void test938() {
    TestDrivers.surfaceShade(-230.0f,1614.0f,-689.0f,0f,780.0f,1481.0f,0f,-338.0f,0f,0f,0f,0f,0f,-1228.0f,227.0f,-1258.0f,-401.0f,919.0f,1041.0f,211,0.16243505f,-0.4282833f,-0.1930214f,5.7150636f,-100.0f,-72.89735f ) ;
  }

  @Test
  public void test939() {
    TestDrivers.surfaceShade(-230.0f,-7.0f,0f,0f,86.0f,-2334.0f,0f,2134.0f,0f,0f,0f,0f,0f,832.0f,3426.0f,-519.0f,502.0f,1375.0f,956.0f,-1047,0.2720026f,0.02905975f,0.63231534f,-50.735523f,0.27013108f,0f ) ;
  }

  @Test
  public void test940() {
    TestDrivers.surfaceShade(23.0f,-248.0f,0f,0f,1856.0f,-1.0f,0f,-1.0f,0f,0f,0f,0f,0f,468.0f,-524.0f,346.0f,0f,0f,0f,-1116,-81.571754f,56.197163f,102.528206f,-78.86648f,-84.54777f,0f ) ;
  }

  @Test
  public void test941() {
    TestDrivers.surfaceShade(232.0f,-716.0f,355.0f,0f,126.0f,63.0f,0f,-178.0f,0f,0f,0f,0f,0f,538.0f,506.0f,-525.0f,806.0f,45.0f,1544.0f,-501,51.715233f,-80.815155f,-24.894615f,39.672844f,-47.60523f,96.01234f ) ;
  }

  @Test
  public void test942() {
    TestDrivers.surfaceShade(-233.0f,-475.0f,-430.0f,0f,132.0f,-307.0f,0f,610.0f,0f,0f,0f,0f,0f,-59.0f,-388.0f,-443.0f,-406.0f,877.0f,-258.0f,497,-66.62266f,65.65467f,65.4231f,90.78863f,-15.568887f,-4.3586112E-10f ) ;
  }

  @Test
  public void test943() {
    TestDrivers.surfaceShade(-237.0f,460.0f,1242.0f,0f,1197.0f,2124.0f,0f,821.0f,0f,0f,0f,0f,0f,-1014.0f,1009.0f,203.0f,307.0f,-439.0f,-1147.0f,1218,0.47114554f,0.38222417f,0.11075803f,-10.655446f,50.88159f,-34.49192f ) ;
  }

  @Test
  public void test944() {
    TestDrivers.surfaceShade(-239.0f,-233.0f,0f,-395.0f,0f,0f,0f,-84.25704f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-2,0f,0f,0f,13.836975f,-78.94624f,0f ) ;
  }

  @Test
  public void test945() {
    TestDrivers.surfaceShade(-240.0f,-1290.0f,0f,0f,865.0f,-837.0f,0f,-330.0f,0f,0f,0f,0f,0f,-33.0f,-972.0f,-933.0f,0f,0f,0f,699,-20.03693f,82.00444f,-84.72357f,-66.64748f,-12.309588f,0f ) ;
  }

  @Test
  public void test946() {
    TestDrivers.surfaceShade(240.0f,258.0f,0f,362.0f,0f,0f,0f,-86.87322f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,1.1510129E-5f,56.809956f,0f ) ;
  }

  @Test
  public void test947() {
    TestDrivers.surfaceShade(240.0f,41.0f,1364.0f,84.0f,0f,0f,0f,-87.43979f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0f,0f,0f,4.9603175E-5f,-23.424025f,84.44867f ) ;
  }

  @Test
  public void test948() {
    TestDrivers.surfaceShade(240.0f,-578.0f,0f,0f,152.0f,616.0f,0f,-989.0f,0f,0f,0f,0f,0f,-441.0f,-675.0f,100.0f,155.0f,691.0f,658.0f,173,45.62951f,9.2432575f,-97.79753f,-54.463448f,-43.38912f,0f ) ;
  }

  @Test
  public void test949() {
    TestDrivers.surfaceShade(241.0f,-173.0f,1026.0f,0f,696.0f,-409.0f,0f,65.0f,0f,0f,0f,0f,0f,914.0f,972.0f,512.0f,-499.0f,-499.0f,875.0f,-686,-56.02874f,28.795528f,31.586163f,-56.412006f,-2.5854363f,-26.356878f ) ;
  }

  @Test
  public void test950() {
    TestDrivers.surfaceShade(241.0f,-190.0f,131.0f,0f,15.0f,-630.0f,0f,-450.0f,0f,0f,0f,0f,0f,750.0f,-759.0f,421.0f,0f,0f,0f,328,-92.87632f,-55.39276f,65.59177f,-71.84061f,92.63041f,22.308367f ) ;
  }

  @Test
  public void test951() {
    TestDrivers.surfaceShade(242.0f,814.0f,-209.0f,0f,377.0f,-355.0f,0f,-736.0f,0f,0f,0f,0f,0f,422.0f,-285.0f,-547.0f,0f,0f,0f,-330,-100.0f,100.0f,-100.0f,92.75368f,100.0f,100.0f ) ;
  }

  @Test
  public void test952() {
    TestDrivers.surfaceShade(-2486.0f,0f,0f,0f,55.580204f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,-8.241264f,45.98049f,32.68248f,0f,0f,0f,-678,-0.09184062f,-0.31821844f,0.31660765f,-87.644615f,0f,0f ) ;
  }

  @Test
  public void test953() {
    TestDrivers.surfaceShade(249.0f,2024.0f,122.0f,0f,520.0f,-774.0f,0f,-464.0f,0f,0f,0f,0f,0f,-85.0f,638.0f,157.0f,0f,0f,0f,-920,88.17953f,24.450203f,-51.617638f,-28.639128f,32.20961f,-71.05116f ) ;
  }

  @Test
  public void test954() {
    TestDrivers.surfaceShade(-25.0f,-1557.0f,0f,0f,479.0f,-265.0f,0f,109.0f,0f,0f,0f,0f,0f,-149.0f,-309.0f,-619.0f,-773.0f,819.0f,-344.0f,877,66.5926f,31.02624f,-31.517618f,-69.21892f,73.30504f,0f ) ;
  }

  @Test
  public void test955() {
    TestDrivers.surfaceShade(253.0f,249.0f,0f,0f,637.0f,-2.0f,0f,-5.0f,0f,0f,0f,0f,0f,-1951.0f,-739.0f,796.0f,0f,0f,0f,-1849,43.146393f,-40.231308f,68.4016f,43.908092f,30.344059f,0f ) ;
  }

  @Test
  public void test956() {
    TestDrivers.surfaceShade(-2532.0f,-1715.0f,0f,0f,399.0f,66.0f,0f,1279.0f,0f,0f,0f,0f,0f,-1447.0f,-284.0f,-321.0f,1145.0f,-576.0f,2008.0f,-516,0.43230206f,-0.30648187f,-0.19252954f,48.227997f,36.95311f,0f ) ;
  }

  @Test
  public void test957() {
    TestDrivers.surfaceShade(2564.0f,0f,0f,0f,82.5238f,0.0f,0f,6.938894E-18f,0f,0f,0f,0f,0f,-16.720356f,-52.07268f,43.75284f,0f,0f,0f,6,-0.23298076f,8.13071f,-0.79209244f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test958() {
    TestDrivers.surfaceShade(257.0f,-11.0f,0f,-938.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,53.49257f,-88.7635f,0f ) ;
  }

  @Test
  public void test959() {
    TestDrivers.surfaceShade(-260.0f,-260.0f,65.0f,0f,564.0f,362.0f,0f,-164.0f,0f,0f,0f,0f,0f,-278.0f,-330.0f,-914.0f,236.0f,1354.0f,728.0f,-117,25.220415f,-1.667469f,94.78752f,-133.46208f,-59.34655f,6.135624f ) ;
  }

  @Test
  public void test960() {
    TestDrivers.surfaceShade(-26.0f,-218.0f,-1085.0f,0f,642.0f,-650.0f,0f,843.0f,0f,0f,0f,0f,0f,1446.0f,639.0f,-123.0f,939.0f,1376.0f,-364.0f,753,-0.5474858f,-0.7208946f,-0.17614968f,-92.86759f,98.19217f,79.856766f ) ;
  }

  @Test
  public void test961() {
    TestDrivers.surfaceShade(-261.0f,526.0f,0f,0f,657.0f,2.0f,0f,-8.0f,0f,0f,0f,0f,0f,-802.0f,-1304.0f,424.0f,0f,0f,0f,998,-76.06294f,81.90054f,56.901794f,-0.5958908f,-110.40247f,0f ) ;
  }

  @Test
  public void test962() {
    TestDrivers.surfaceShade(2633.0f,-687.0f,-21.0f,0f,19.0f,-2038.0f,0f,-811.0f,0f,0f,0f,0f,0f,-421.0f,614.0f,146.0f,0f,0f,0f,180,-0.5151054f,-0.42453414f,0.2380486f,-4.0015535f,-58.544064f,-0.34684235f ) ;
  }

  @Test
  public void test963() {
    TestDrivers.surfaceShade(2657.0f,80.0f,0f,0f,677.0f,-263.0f,0f,-5.0f,0f,0f,0f,0f,0f,822.0f,870.0f,-313.0f,0f,0f,0f,-1969,-0.44356766f,-0.31750232f,0.14005484f,35.982494f,2.6967193E-8f,0f ) ;
  }

  @Test
  public void test964() {
    TestDrivers.surfaceShade(-269.0f,0f,0f,0f,7.049765f,-8.154722f,0f,-13.173225f,0f,0f,0f,0f,0f,7.572463f,-24.949915f,-17.5967f,0f,0f,0f,-879,81.485f,-26.444807f,72.56121f,-97.39148f,0f,0f ) ;
  }

  @Test
  public void test965() {
    TestDrivers.surfaceShade(269.0f,0f,0f,-99.0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-98.72768f,48.911026f,-54.493294f,269.0f,-582.0f,1109.0f,3,0f,0f,0f,-3.7550224E-5f,0f,0f ) ;
  }

  @Test
  public void test966() {
    TestDrivers.surfaceShade(-270.0f,-1306.0f,0f,0f,61.0f,-1212.0f,0f,896.0f,0f,0f,0f,0f,0f,162.0f,-268.0f,1935.0f,438.0f,-901.0f,309.0f,37,0.10050182f,0.69720066f,-0.048724916f,-76.51888f,-43.737362f,0f ) ;
  }

  @Test
  public void test967() {
    TestDrivers.surfaceShade(270.0f,-810.0f,0f,0f,348.0f,177.0f,0f,470.0f,0f,0f,0f,0f,0f,-349.0f,621.0f,2059.0f,27.0f,204.0f,-827.0f,120,-0.0516437f,0.08870912f,-0.8825962f,12.297575f,84.68916f,0f ) ;
  }

  @Test
  public void test968() {
    TestDrivers.surfaceShade(2705.0f,1890.0f,39.0f,0f,66.0f,-1177.0f,0f,1873.0f,0f,0f,0f,0f,0f,836.0f,602.0f,-101.0f,-1139.0f,-220.0f,-1453.0f,-1572,-17.798737f,34.87148f,60.523624f,30.110441f,25.008053f,11.1014805f ) ;
  }

  @Test
  public void test969() {
    TestDrivers.surfaceShade(27.0f,385.0f,-495.0f,0f,475.0f,494.0f,0f,-194.0f,0f,0f,0f,0f,0f,588.0f,-116.0f,-3.0f,-619.0f,364.0f,340.0f,1714,-85.05568f,-13.102218f,48.464397f,76.09752f,19.191269f,34.73562f ) ;
  }

  @Test
  public void test970() {
    TestDrivers.surfaceShade(27.0f,96.0f,48.0f,891.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,93.26599f,99.53637f,-5.329657f,4.1567942E-5f,67.21116f,-23.069504f ) ;
  }

  @Test
  public void test971() {
    TestDrivers.surfaceShade(273.0f,449.0f,-580.0f,0f,66.0f,-24.0f,0f,23.0f,0f,0f,0f,0f,0f,878.0f,58.0f,788.0f,-457.0f,-947.0f,-812.0f,763,-1.4259286f,-1.1554095f,1.6738312f,100.0f,16.128984f,-72.20924f ) ;
  }

  @Test
  public void test972() {
    TestDrivers.surfaceShade(-274.0f,-947.0f,206.0f,0f,1094.0f,28.0f,0f,194.0f,0f,0f,0f,0f,0f,976.0f,-151.0f,971.0f,-335.0f,-408.0f,-2340.0f,-697,-24.578451f,-20.98182f,21.442135f,-64.74222f,-100.0f,86.11313f ) ;
  }

  @Test
  public void test973() {
    TestDrivers.surfaceShade(-276.0f,0f,0f,0f,522.0f,265.0f,-520.0f,-432.0f,0f,0f,0f,0f,0f,858.0f,-865.0f,874.0f,31.0f,627.0f,677.0f,782,-27.772022f,-60.840927f,-67.71087f,56.07891f,0f,0f ) ;
  }

  @Test
  public void test974() {
    TestDrivers.surfaceShade(-280.0f,-914.0f,0f,0f,581.0f,906.0f,0f,479.0f,0f,0f,0f,0f,0f,361.0f,651.0f,-384.0f,-771.0f,481.0f,943.0f,-231,22.39132f,-31.05729f,25.733774f,-12.997628f,-74.444435f,0f ) ;
  }

  @Test
  public void test975() {
    TestDrivers.surfaceShade(281.0f,-1143.0f,538.0f,17.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,100.0f,10.112098f,100.0f,2.093364E-4f,-100.0f,67.277534f ) ;
  }

  @Test
  public void test976() {
    TestDrivers.surfaceShade(-282.0f,-498.0f,0f,0f,373.0f,-531.0f,0f,333.0f,0f,0f,0f,0f,0f,839.0f,-30.0f,819.0f,740.0f,-411.0f,527.0f,847,-97.08873f,-62.645145f,64.80383f,-87.106316f,13.531484f,0f ) ;
  }

  @Test
  public void test977() {
    TestDrivers.surfaceShade(283.0f,-894.0f,551.0f,0f,1279.0f,-1450.0f,0f,-1.0f,0f,0f,0f,0f,0f,-1227.0f,746.0f,1470.0f,0f,0f,0f,435,0.77146214f,-0.0735577f,0.16568896f,21.834005f,-26.03412f,76.78972f ) ;
  }

  @Test
  public void test978() {
    TestDrivers.surfaceShade(-285.0f,0f,-619.0f,0f,396.0f,0.0f,0f,-1416.0f,0f,0f,0f,0f,0f,1126.0f,-24.0f,-909.0f,0f,0f,0f,63,-100.0f,100.0f,-18.58693f,-100.0f,0f,51.268944f ) ;
  }

  @Test
  public void test979() {
    TestDrivers.surfaceShade(286.0f,273.0f,64.0f,-6.0f,0f,0f,0f,-61.970047f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,85.07973f,79.496735f,-0.0026041667f ) ;
  }

  @Test
  public void test980() {
    TestDrivers.surfaceShade(29.0f,-727.0f,0f,-60.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,32.402298f,-100.0f,-86.61143f,-5.7471264E-4f,98.17407f,0f ) ;
  }

  @Test
  public void test981() {
    TestDrivers.surfaceShade(29.0f,-762.0f,0f,0f,96.0f,880.0f,-121.0f,-2606.0f,0f,0f,0f,0f,0f,678.0f,567.0f,1452.0f,-96.0f,1686.0f,448.0f,-60,0.43923876f,0.61144507f,-0.4438659f,84.07941f,37.17817f,0f ) ;
  }

  @Test
  public void test982() {
    TestDrivers.surfaceShade(2916.0f,0f,0f,0f,134.0f,632.0f,-6.0f,-85.0f,0f,0f,0f,0f,0f,434.0f,379.0f,-1761.0f,498.0f,395.0f,75.0f,666,-0.5654923f,0.24801806f,-0.08598773f,7.2668905f,0f,0f ) ;
  }

  @Test
  public void test983() {
    TestDrivers.surfaceShade(-294.0f,916.0f,0f,0f,1073.0f,-124.0f,0f,216.0f,0f,0f,0f,0f,0f,479.0f,148.0f,-424.0f,643.0f,-935.0f,-153.0f,-1527,-45.001076f,40.458183f,-36.71628f,-3.2663472f,31.785822f,0f ) ;
  }

  @Test
  public void test984() {
    TestDrivers.surfaceShade(299.0f,1152.0f,-1176.0f,326.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,1.0259146E-5f,25.320456f,-2.6084053E-6f ) ;
  }

  @Test
  public void test985() {
    TestDrivers.surfaceShade(30.0f,-63.0f,1260.0f,0f,503.0f,0.0f,0f,-144.0f,0f,0f,0f,0f,0f,902.0f,-1627.0f,137.0f,0f,0f,0f,133,100.0f,100.0f,-186.83409f,-100.0f,100.0f,100.0f ) ;
  }

  @Test
  public void test986() {
    TestDrivers.surfaceShade(302.0f,0f,0f,0f,395.0f,413.0f,231.0f,-798.0f,0f,0f,0f,0f,0f,-652.0f,-982.0f,-799.0f,388.0f,183.0f,-82.0f,315,88.21179f,-61.895664f,21.564604f,-8.171277f,0f,0f ) ;
  }

  @Test
  public void test987() {
    TestDrivers.surfaceShade(305.0f,-213.0f,0f,0f,759.0f,-1.0f,0f,-1847.0f,0f,0f,0f,0f,0f,-1861.0f,392.0f,669.0f,0f,0f,0f,-714,0.25198707f,0.9603168f,-0.028079031f,85.757576f,-39.953255f,0f ) ;
  }

  @Test
  public void test988() {
    TestDrivers.surfaceShade(-308.0f,1260.0f,939.0f,0f,269.0f,251.0f,0f,-1708.0f,0f,0f,0f,0f,0f,-1118.0f,132.0f,-812.0f,1054.0f,-841.0f,-943.0f,1208,-0.008518197f,-0.7069127f,0.6542696f,99.65389f,-48.120304f,-47.00135f ) ;
  }

  @Test
  public void test989() {
    TestDrivers.surfaceShade(-3.0f,-738.0f,355.0f,638.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,-5.22466E-4f,-19.214952f,100.0f ) ;
  }

  @Test
  public void test990() {
    TestDrivers.surfaceShade(-3.0f,883.0f,-1161.0f,0f,23.0f,-1218.0f,0f,1176.0f,0f,0f,0f,0f,0f,-321.0f,127.0f,267.0f,1277.0f,-966.0f,557.0f,254,-0.26941827f,-0.0058435886f,-0.32112783f,55.448605f,88.93714f,-69.24791f ) ;
  }

  @Test
  public void test991() {
    TestDrivers.surfaceShade(-310.0f,655.0f,0f,0f,954.0f,-742.0f,0f,-369.0f,0f,0f,0f,0f,0f,474.0f,797.0f,338.0f,0f,0f,0f,648,43.33884f,-80.6139f,-22.288626f,-48.071285f,-92.90322f,0f ) ;
  }

  @Test
  public void test992() {
    TestDrivers.surfaceShade(-31.0f,-1954.0f,597.0f,0f,9.0f,348.0f,0f,1997.0f,0f,0f,0f,0f,0f,-273.0f,-78.0f,882.0f,1472.0f,191.0f,-192.0f,2137,-0.34080553f,-0.0019542219f,-0.5991594f,47.037075f,71.74677f,-15.285954f ) ;
  }

  @Test
  public void test993() {
    TestDrivers.surfaceShade(-31.0f,525.0f,-2428.0f,-107.0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,3.0147724E-4f,-1.7801513E-5f,10.19926f ) ;
  }

  @Test
  public void test994() {
    TestDrivers.surfaceShade(311.0f,0f,0f,0f,345.0f,-721.0f,0f,229.0f,0f,0f,0f,0f,0f,-353.0f,-586.0f,-672.0f,-489.0f,282.0f,-254.0f,694,97.41373f,-97.47502f,42.065792f,-71.396416f,0f,0f ) ;
  }

  @Test
  public void test995() {
    TestDrivers.surfaceShade(311.0f,-297.0f,0f,0f,1194.0f,3.0f,0f,0.0f,0f,0f,0f,0f,0f,346.0f,2.0f,544.0f,0f,0f,0f,-1324,6.553124f,-10.622582f,-56.999928f,53.781067f,9.87039f,0f ) ;
  }

  @Test
  public void test996() {
    TestDrivers.surfaceShade(-313.0f,-1047.0f,0f,0f,111.0f,-995.0f,0f,-616.0f,0f,0f,0f,0f,0f,-958.0f,-350.0f,373.0f,0f,0f,0f,713,7.539119f,40.007526f,56.903778f,-95.477745f,-62.495995f,0f ) ;
  }

  @Test
  public void test997() {
    TestDrivers.surfaceShade(314.0f,-1181.0f,0f,0f,92.0f,561.0f,0f,874.0f,0f,0f,0f,0f,0f,-267.0f,-890.0f,-864.0f,350.0f,-586.0f,1139.0f,-967,36.050594f,34.114628f,-46.28186f,100.0f,-16.326735f,0f ) ;
  }

  @Test
  public void test998() {
    TestDrivers.surfaceShade(-314.0f,-794.0f,0f,0f,946.0f,282.0f,-128.0f,-496.0f,0f,0f,0f,0f,0f,543.0f,-168.0f,-231.0f,685.0f,1189.0f,-200.0f,-849,-51.265556f,-73.13056f,21.189259f,-56.695366f,-88.47045f,0f ) ;
  }

  @Test
  public void test999() {
    TestDrivers.surfaceShade(-316.0f,0f,0f,0f,1.2389932f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-74.88483f,93.73942f,99.92833f,0f,0f,0f,-696,0.4390007f,-0.06980371f,-0.07074931f,95.30468f,0f,0f ) ;
  }

  @Test
  public void test1000() {
    TestDrivers.surfaceShade(-317.0f,0f,0f,0f,924.0f,1510.0f,-490.0f,-1067.0f,0f,0f,0f,0f,0f,-1259.0f,-503.0f,736.0f,230.0f,-634.0f,826.0f,-987,-8.59853E-4f,-0.01714792f,-0.8632186f,65.99945f,0f,0f ) ;
  }

  @Test
  public void test1001() {
    TestDrivers.surfaceShade(-32.0f,0f,0f,405.0f,0f,0f,0f,-8.9763565f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-95.463264f,0f,0f ) ;
  }

  @Test
  public void test1002() {
    TestDrivers.surfaceShade(-321.0f,1566.0f,1407.0f,0f,520.0f,2470.0f,0f,320.0f,0f,0f,0f,0f,0f,841.0f,-336.0f,933.0f,477.0f,2.0f,-1318.0f,248,-11.250811f,10.771566f,14.0205555f,51.061012f,-100.0f,100.0f ) ;
  }

  @Test
  public void test1003() {
    TestDrivers.surfaceShade(-329.0f,-333.0f,-851.0f,0f,839.0f,13.0f,0f,659.0f,0f,0f,0f,0f,0f,-535.0f,875.0f,731.0f,84.0f,-809.0f,19.0f,-832,-38.908318f,-64.61813f,-96.46982f,95.67603f,-0.09567215f,51.210373f ) ;
  }

  @Test
  public void test1004() {
    TestDrivers.surfaceShade(331.0f,-941.0f,0f,0f,4159.0f,-526.0f,0f,0.0f,0f,0f,0f,0f,0f,225.0f,1474.0f,-2639.0f,0f,0f,0f,694,0.16923884f,-0.826281f,-0.072489075f,66.84114f,9.342761f,0f ) ;
  }

  @Test
  public void test1005() {
    TestDrivers.surfaceShade(-334.0f,0f,0f,0f,373.0f,1221.0f,0f,-460.0f,0f,0f,0f,0f,0f,26.0f,1066.0f,54.0f,-813.0f,-700.0f,-114.0f,-1990,0.0029713563f,-0.101095535f,1.0627257f,-0.0020211285f,0f,0f ) ;
  }

  @Test
  public void test1006() {
    TestDrivers.surfaceShade(334.0f,0f,0f,0f,69.78834f,-72.19105f,0f,0.0f,0f,0f,0f,0f,0f,50.111755f,-68.82546f,-20.3901f,0f,0f,0f,-734,-53.676094f,59.961895f,-29.14311f,-46.210403f,0f,0f ) ;
  }

  @Test
  public void test1007() {
    TestDrivers.surfaceShade(-334.0f,316.0f,0f,921.0f,0f,0f,0f,450.0f,0f,0f,0f,0f,0f,860.0f,226.0f,960.0f,-659.0f,400.0f,214.0f,0,0f,0f,0f,69.08355f,52.32042f,0f ) ;
  }

  @Test
  public void test1008() {
    TestDrivers.surfaceShade(-336.0f,0f,0f,0f,1100.0f,-371.0f,0f,1153.0f,0f,0f,0f,0f,0f,-412.0f,-376.0f,763.0f,648.0f,1598.0f,712.0f,-494,100.0f,-36.426308f,-13.582638f,-16.365839f,0f,0f ) ;
  }

  @Test
  public void test1009() {
    TestDrivers.surfaceShade(336.0f,0f,0f,-659.0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-4.5162224E-6f,0f,0f ) ;
  }

  @Test
  public void test1010() {
    TestDrivers.surfaceShade(-336.0f,456.0f,958.0f,0f,5.0f,-570.0f,0f,-1538.0f,0f,0f,0f,0f,0f,-603.0f,-509.0f,-1677.0f,0f,0f,0f,840,-14.3112955f,27.916452f,-3.327229f,-100.0f,78.682686f,0.9866003f ) ;
  }

  @Test
  public void test1011() {
    TestDrivers.surfaceShade(3375.0f,-577.0f,0f,0f,583.0f,-195.0f,0f,180.0f,0f,0f,0f,0f,0f,-1588.0f,-833.0f,-1158.0f,-32.0f,-458.0f,715.0f,-610,0.81555897f,-0.13966292f,-0.008751064f,-37.23478f,-23.965918f,0f ) ;
  }

  @Test
  public void test1012() {
    TestDrivers.surfaceShade(34.0f,-2129.0f,0f,0f,562.0f,929.0f,-1319.0f,-1131.0f,0f,0f,0f,0f,0f,-918.0f,-765.0f,-1147.0f,498.0f,-1350.0f,-1275.0f,412,-0.023641437f,0.35256392f,0.05119621f,-122.43765f,93.25729f,0f ) ;
  }

  @Test
  public void test1013() {
    TestDrivers.surfaceShade(34.0f,258.0f,0f,65.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,4.524887E-4f,14.846977f,0f ) ;
  }

  @Test
  public void test1014() {
    TestDrivers.surfaceShade(341.0f,0f,0f,0f,483.0f,125.0f,-1287.0f,389.0f,0f,0f,0f,0f,0f,119.0f,586.0f,-129.0f,-354.0f,-579.0f,758.0f,-579,-100.0f,18.541807f,-8.019387f,18.494219f,0f,0f ) ;
  }

  @Test
  public void test1015() {
    TestDrivers.surfaceShade(351.0f,-529.0f,0f,0f,417.0f,-304.0f,0f,-2277.0f,0f,0f,0f,0f,0f,-1410.0f,85.0f,-695.0f,0f,0f,0f,1907,0.2880098f,0.16789837f,0.18131533f,-20.074533f,-1.7845356f,0f ) ;
  }

  @Test
  public void test1016() {
    TestDrivers.surfaceShade(356.0f,0f,0f,0f,854.0f,-1487.0f,0f,589.0f,0f,0f,0f,0f,0f,1305.0f,-1108.0f,1751.0f,2156.0f,-225.0f,895.0f,924,-0.7518285f,0.23043673f,0.46983978f,94.45107f,0f,0f ) ;
  }

  @Test
  public void test1017() {
    TestDrivers.surfaceShade(-358.0f,0f,0f,24.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,64.93153f,-27.83317f,-56.32041f,-1.1638734E-4f,0f,0f ) ;
  }

  @Test
  public void test1018() {
    TestDrivers.surfaceShade(-358.0f,-224.0f,0f,237.0f,0f,0f,0f,-30.037642f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-41.40808f,-11.719336f,0f ) ;
  }

  @Test
  public void test1019() {
    TestDrivers.surfaceShade(-360.0f,-1186.0f,-1281.0f,0f,1509.0f,-579.0f,0f,1142.0f,0f,0f,0f,0f,0f,-1084.0f,-400.0f,-624.0f,20.0f,248.0f,163.0f,530,0.17182484f,0.53790754f,-0.14290433f,-22.53936f,48.405113f,-96.9546f ) ;
  }

  @Test
  public void test1020() {
    TestDrivers.surfaceShade(-360.0f,-484.0f,0f,0f,585.0f,-681.0f,0f,662.0f,0f,0f,0f,0f,0f,638.0f,-783.0f,636.0f,-1266.0f,-161.0f,-817.0f,471,43.344864f,-0.4901456f,-44.084602f,83.629005f,-100.0f,0f ) ;
  }

  @Test
  public void test1021() {
    TestDrivers.surfaceShade(-362.0f,0f,-996.0f,0f,530.0f,1.0f,0f,-886.0f,0f,0f,0f,0f,0f,597.0f,898.0f,657.0f,0f,0f,0f,797,-52.054146f,19.410437f,-45.08919f,-54.03624f,0f,-59.627357f ) ;
  }

  @Test
  public void test1022() {
    TestDrivers.surfaceShade(362.0f,-7.0f,-867.0f,1189.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,-100.0f,-89.248436f,-89.848206f,-37.004795f,-1.2014899E-4f,100.0f ) ;
  }

  @Test
  public void test1023() {
    TestDrivers.surfaceShade(-365.0f,-865.0f,-643.0f,702.0f,0f,0f,0f,-77.893654f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-2,0f,0f,0f,-7.0594783f,-83.89244f,-38.632412f ) ;
  }

  @Test
  public void test1024() {
    TestDrivers.surfaceShade(370.0f,0f,0f,0f,70.03338f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,-4.054886f,-30.812696f,19.330317f,0f,0f,0f,2,0.60481006f,-0.90702605f,-0.14363904f,-49.75649f,0f,0f ) ;
  }

  @Test
  public void test1025() {
    TestDrivers.surfaceShade(37.0f,15.0f,0f,0f,12.0f,-1386.0f,0f,1.0f,0f,0f,0f,0f,0f,-2384.0f,787.0f,980.0f,0f,0f,0f,-544,5.187192f,70.41254f,-43.926945f,0.46669787f,-71.387314f,0f ) ;
  }

  @Test
  public void test1026() {
    TestDrivers.surfaceShade(376.0f,0f,0f,0f,863.0f,564.0f,0f,379.0f,0f,0f,0f,0f,0f,814.0f,-646.0f,1531.0f,-2740.0f,317.0f,597.0f,-974,0.15467383f,0.14741535f,-0.5660686f,39.32856f,0f,0f ) ;
  }

  @Test
  public void test1027() {
    TestDrivers.surfaceShade(-377.0f,239.0f,0f,0f,-472.0f,-818.0f,721.0f,380.0f,0f,0f,0f,0f,0f,-692.0f,360.0f,-751.0f,117.0f,107.0f,-620.0f,209,94.252846f,-31.844334f,0.5445102f,-99.20061f,-55.45951f,0f ) ;
  }

  @Test
  public void test1028() {
    TestDrivers.surfaceShade(377.0f,-622.0f,0f,0f,337.0f,-546.0f,0f,0.0f,0f,0f,0f,0f,0f,-526.0f,801.0f,968.0f,0f,0f,0f,-1821,75.269264f,-39.77353f,73.81222f,5.911747f,-3.9199622f,0f ) ;
  }

  @Test
  public void test1029() {
    TestDrivers.surfaceShade(377.0f,-852.0f,0f,911.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,13.875007f,54.38261f,0f ) ;
  }

  @Test
  public void test1030() {
    TestDrivers.surfaceShade(380.0f,-4.0f,-1008.0f,0f,45.0f,-994.0f,0f,-130.0f,0f,0f,0f,0f,0f,517.0f,-300.0f,534.0f,0f,0f,0f,1162,-52.180847f,-61.583748f,15.922047f,58.82349f,-13.462629f,84.22832f ) ;
  }

  @Test
  public void test1031() {
    TestDrivers.surfaceShade(38.0f,1246.0f,-1509.0f,21.0f,0f,0f,0f,-64.42532f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0.0012531328f,-59.782932f,-3.155669E-5f ) ;
  }

  @Test
  public void test1032() {
    TestDrivers.surfaceShade(38.0f,-387.0f,0f,0f,220.0f,-534.0f,0f,-804.0f,0f,0f,0f,0f,0f,22.0f,272.0f,1744.0f,0f,0f,0f,8,0.80000377f,-0.8279324f,1.2797295f,100.0f,72.82407f,0f ) ;
  }

  @Test
  public void test1033() {
    TestDrivers.surfaceShade(-38.0f,401.0f,0f,0f,1140.0f,2.0f,0f,-1031.0f,0f,0f,0f,0f,0f,-65.0f,271.0f,352.0f,0f,0f,0f,-595,1.3479154f,2.304127f,-1.5250112f,-53.510387f,46.74746f,0f ) ;
  }

  @Test
  public void test1034() {
    TestDrivers.surfaceShade(383.0f,2361.0f,-258.0f,253.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,1.0320024E-5f,100.0f,9.7288f ) ;
  }

  @Test
  public void test1035() {
    TestDrivers.surfaceShade(384.0f,-841.0f,105.0f,0f,556.0f,387.0f,0f,1965.0f,0f,0f,0f,0f,0f,-362.0f,547.0f,-638.0f,788.0f,-2052.0f,211.0f,724,30.270752f,15.471775f,-3.9105816f,-100.0f,-84.33709f,81.50084f ) ;
  }

  @Test
  public void test1036() {
    TestDrivers.surfaceShade(385.0f,-471.0f,0f,709.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-46.442074f,87.78279f,-84.884544f,4.0372295f,0.87510073f,0f ) ;
  }

  @Test
  public void test1037() {
    TestDrivers.surfaceShade(-386.0f,-454.0f,-194.0f,0f,291.0f,1278.0f,0f,-7.0f,0f,0f,0f,0f,0f,125.0f,-644.0f,306.0f,-761.0f,-23.0f,-456.0f,1791,0.51914376f,0.09375805f,-0.014747672f,-100.0f,-24.414036f,-79.954926f ) ;
  }

  @Test
  public void test1038() {
    TestDrivers.surfaceShade(-389.0f,-229.0f,937.0f,0f,460.0f,-611.0f,0f,385.0f,0f,0f,0f,0f,0f,-797.0f,797.0f,-56.0f,951.0f,-732.0f,242.0f,22,46.72059f,41.673817f,-63.48423f,-73.08949f,-8.156076f,39.56235f ) ;
  }

  @Test
  public void test1039() {
    TestDrivers.surfaceShade(-391.0f,-366.0f,884.0f,0f,635.0f,-144.0f,0f,507.0f,0f,0f,0f,0f,0f,-866.0f,-497.0f,968.0f,-322.0f,651.0f,691.0f,161,-31.801302f,-44.61569f,-62.833916f,1.368653f,100.0f,-18.457638f ) ;
  }

  @Test
  public void test1040() {
    TestDrivers.surfaceShade(396.0f,668.0f,0f,0f,42.0f,383.0f,0f,-586.0f,0f,0f,0f,0f,0f,260.0f,1818.0f,658.0f,-1216.0f,-980.0f,1789.0f,504,0.35125917f,0.10725183f,-0.6538818f,-21.449192f,99.849655f,0f ) ;
  }

  @Test
  public void test1041() {
    TestDrivers.surfaceShade(-402.0f,2064.0f,0f,0f,951.0f,1170.0f,0f,-179.0f,0f,0f,0f,0f,0f,-791.0f,404.0f,771.0f,166.0f,-777.0f,-206.0f,-496,0.70816076f,0.17996033f,-0.20176236f,86.61224f,-60.16589f,0f ) ;
  }

  @Test
  public void test1042() {
    TestDrivers.surfaceShade(404.0f,-119.0f,2132.0f,0f,1774.0f,-1079.0f,0f,538.0f,0f,0f,0f,0f,0f,-793.0f,109.0f,1184.0f,1186.0f,-947.0f,-836.0f,-1231,-0.5229303f,0.40761247f,-0.3877648f,100.0f,-1.1270915f,74.58125f ) ;
  }

  @Test
  public void test1043() {
    TestDrivers.surfaceShade(-405.0f,-914.0f,109.0f,0f,979.0f,-1750.0f,0f,616.0f,0f,0f,0f,0f,0f,-715.0f,593.0f,933.0f,-2020.0f,-537.0f,966.0f,1757,-0.12917608f,-0.7555244f,0.26409075f,86.93522f,100.0f,-99.23916f ) ;
  }

  @Test
  public void test1044() {
    TestDrivers.surfaceShade(408.0f,981.0f,0f,0f,589.0f,460.0f,0f,-576.0f,0f,0f,0f,0f,0f,-806.0f,328.0f,176.0f,465.0f,746.0f,-267.0f,-53,35.998802f,-22.40885f,-43.40056f,-86.80471f,-83.205734f,0f ) ;
  }

  @Test
  public void test1045() {
    TestDrivers.surfaceShade(4.0f,-907.0f,-724.0f,0f,886.0f,90.0f,0f,-1131.0f,0f,0f,0f,0f,0f,-161.0f,-409.0f,-11.0f,594.0f,-344.0f,766.0f,-80,-18.181343f,7.17481f,-0.66372114f,-60.32693f,63.62989f,-48.07856f ) ;
  }

  @Test
  public void test1046() {
    TestDrivers.surfaceShade(-410.0f,-171.0f,-7.0f,-815.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-22.146322f,-151.83702f,-100.0f,-75.04834f,-12.725967f,73.468704f ) ;
  }

  @Test
  public void test1047() {
    TestDrivers.surfaceShade(410.0f,-726.0f,0f,-945.0f,0f,0f,0f,-82.22025f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-2.5809782E-6f,-66.821724f,0f ) ;
  }

  @Test
  public void test1048() {
    TestDrivers.surfaceShade(-41.0f,-1287.0f,-525.0f,0f,1039.0f,-231.0f,0f,-482.0f,0f,0f,0f,0f,0f,1120.0f,301.0f,1464.0f,0f,0f,0f,-704,-0.47108138f,-0.13240732f,0.07150917f,44.86741f,-3.6949937f,47.902084f ) ;
  }

  @Test
  public void test1049() {
    TestDrivers.surfaceShade(423.0f,-492.0f,9.0f,0f,778.0f,410.0f,0f,847.0f,0f,0f,0f,0f,0f,-288.0f,166.0f,370.0f,860.0f,5.0f,-1677.0f,-789,63.493164f,-67.15872f,79.552376f,100.0f,-83.54499f,0.7636151f ) ;
  }

  @Test
  public void test1050() {
    TestDrivers.surfaceShade(424.0f,-1214.0f,0f,0f,100.0f,-1599.0f,0f,531.0f,0f,0f,0f,0f,0f,720.0f,953.0f,369.0f,-311.0f,877.0f,-568.0f,388,-91.05918f,40.628483f,72.74707f,0.94707745f,24.045937f,0f ) ;
  }

  @Test
  public void test1051() {
    TestDrivers.surfaceShade(426.0f,0f,0f,0f,71.33089f,-73.11224f,0f,0.0f,0f,0f,0f,0f,0f,-35.08449f,1.4036157f,-16.474308f,0f,0f,0f,-515,-0.2594924f,0.0792168f,0.83166957f,-3.760318f,0f,0f ) ;
  }

  @Test
  public void test1052() {
    TestDrivers.surfaceShade(-426.0f,0f,0f,-177.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,1.3262248E-5f,0f,0f ) ;
  }

  @Test
  public void test1053() {
    TestDrivers.surfaceShade(-428.0f,506.0f,0f,0f,846.0f,-1.0f,0f,2.0f,0f,0f,0f,0f,0f,511.0f,-1209.0f,651.0f,0f,0f,0f,-294,-0.078020655f,0.19003992f,0.20878784f,21.106295f,1.4573636f,0f ) ;
  }

  @Test
  public void test1054() {
    TestDrivers.surfaceShade(-43.0f,1091.0f,0f,0f,215.0f,0.0f,0f,-1552.0f,0f,0f,0f,0f,0f,454.0f,-595.0f,10.0f,0f,0f,0f,854,-0.40982494f,-0.30564615f,0.40086085f,-0.24566679f,-49.002865f,0f ) ;
  }

  @Test
  public void test1055() {
    TestDrivers.surfaceShade(-43.0f,1359.0f,45.0f,-546.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-41.063923f,-49.179806f,-4.070004E-5f ) ;
  }

  @Test
  public void test1056() {
    TestDrivers.surfaceShade(43.0f,54.0f,0f,-69.0f,0f,0f,0f,-1.7763568E-15f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-100.0f,-2.6838432E-4f,0f ) ;
  }

  @Test
  public void test1057() {
    TestDrivers.surfaceShade(-43.0f,-597.0f,-1380.0f,1.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-0.023255814f,11.087966f,-7.246377E-4f ) ;
  }

  @Test
  public void test1058() {
    TestDrivers.surfaceShade(44.0f,0f,0f,0f,865.0f,213.0f,471.0f,-613.0f,0f,0f,0f,0f,0f,282.0f,961.0f,230.0f,161.0f,454.0f,-713.0f,509,23.106623f,25.586515f,-62.55136f,25.036413f,0f,0f ) ;
  }

  @Test
  public void test1059() {
    TestDrivers.surfaceShade(44.0f,-1492.0f,0f,8.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0.0028409092f,-8.378016E-5f,0f ) ;
  }

  @Test
  public void test1060() {
    TestDrivers.surfaceShade(-443.0f,-57.0f,1175.0f,0f,3.0f,720.0f,0f,433.0f,0f,0f,0f,0f,0f,282.0f,97.0f,329.0f,-237.0f,280.0f,-1632.0f,-161,51.9531f,-85.67577f,-19.271746f,14.406595f,-0.032395344f,6.6722107f ) ;
  }

  @Test
  public void test1061() {
    TestDrivers.surfaceShade(-447.0f,-299.0f,410.0f,0f,1122.0f,164.0f,0f,802.0f,0f,0f,0f,0f,0f,831.0f,239.0f,553.0f,-621.0f,-324.0f,212.0f,376,27.386478f,27.65757f,-61.057373f,-73.590454f,82.29189f,-90.86241f ) ;
  }

  @Test
  public void test1062() {
    TestDrivers.surfaceShade(447.0f,742.0f,-626.0f,0f,57.0f,258.0f,0f,756.0f,0f,0f,0f,0f,0f,253.0f,956.0f,55.0f,-405.0f,-244.0f,-674.0f,-847,-49.660347f,-58.0242f,80.239265f,19.815363f,73.691696f,-50.735977f ) ;
  }

  @Test
  public void test1063() {
    TestDrivers.surfaceShade(45.0f,162.0f,-883.0f,0f,816.0f,998.0f,0f,-612.0f,0f,0f,0f,0f,0f,-555.0f,6.0f,-191.0f,640.0f,275.0f,-992.0f,-800,80.277145f,-53.391075f,77.718f,-19.17336f,-33.52221f,21.515835f ) ;
  }

  @Test
  public void test1064() {
    TestDrivers.surfaceShade(451.0f,699.0f,639.0f,0f,750.0f,-276.0f,0f,219.0f,0f,0f,0f,0f,0f,-704.0f,-728.0f,395.0f,341.0f,-662.0f,-915.0f,-5,-36.5782f,57.223396f,-17.052317f,-54.313175f,-59.67079f,-99.80421f ) ;
  }

  @Test
  public void test1065() {
    TestDrivers.surfaceShade(454.0f,1710.0f,456.0f,0f,1363.0f,302.0f,0f,1600.0f,0f,0f,0f,0f,0f,-302.0f,-199.0f,-292.0f,-892.0f,931.0f,1193.0f,567,100.0f,-100.0f,-35.27397f,100.0f,-100.0f,97.17358f ) ;
  }

  @Test
  public void test1066() {
    TestDrivers.surfaceShade(-457.0f,1305.0f,0f,0f,748.0f,611.0f,0f,719.0f,0f,0f,0f,0f,0f,443.0f,-139.0f,-964.0f,-1851.0f,-764.0f,-644.0f,-1039,88.304016f,-77.45949f,51.748493f,10.907686f,11.395144f,0f ) ;
  }

  @Test
  public void test1067() {
    TestDrivers.surfaceShade(459.0f,-317.0f,-339.0f,0f,923.0f,-1238.0f,0f,659.0f,0f,0f,0f,0f,0f,-483.0f,1325.0f,-1660.0f,873.0f,151.0f,760.0f,-860,0.090737164f,-0.89614177f,-0.38391757f,-9.495218f,-93.08627f,-1.0635767f ) ;
  }

  @Test
  public void test1068() {
    TestDrivers.surfaceShade(-46.0f,33.0f,-18.0f,28.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,4,-100.0f,-48.09459f,-61.68551f,-7.7639753E-4f,0.0010822511f,-33.88387f ) ;
  }

  @Test
  public void test1069() {
    TestDrivers.surfaceShade(-462.0f,-999.0f,0f,0f,92.0f,-846.0f,0f,-1.0f,0f,0f,0f,0f,0f,-138.0f,-621.0f,282.0f,0f,0f,0f,-1209,31.910488f,100.0f,-60.098183f,42.452324f,25.20576f,0f ) ;
  }

  @Test
  public void test1070() {
    TestDrivers.surfaceShade(468.0f,-963.0f,0f,0f,863.0f,-742.0f,0f,793.0f,0f,0f,0f,0f,0f,876.0f,-662.0f,-829.0f,-144.0f,-618.0f,1043.0f,-498,-79.31053f,-50.487362f,-29.61133f,88.75333f,-49.21968f,0f ) ;
  }

  @Test
  public void test1071() {
    TestDrivers.surfaceShade(469.0f,1527.0f,0f,0f,1511.0f,914.0f,0f,1741.0f,0f,0f,0f,0f,0f,-1592.0f,1360.0f,219.0f,440.0f,-1618.0f,-2762.0f,-1238,0.045927092f,-0.39914203f,0.7587963f,48.53873f,73.001595f,0f ) ;
  }

  @Test
  public void test1072() {
    TestDrivers.surfaceShade(469.0f,230.0f,-882.0f,0f,625.0f,-106.0f,0f,-945.0f,0f,0f,0f,0f,0f,-32.0f,-1597.0f,118.0f,0f,0f,0f,901,-0.74079126f,0.23488675f,-0.4171691f,16.419296f,-100.0f,15.627025f ) ;
  }

  @Test
  public void test1073() {
    TestDrivers.surfaceShade(-470.0f,0f,0f,0f,938.0f,4.0f,0f,267.0f,0f,0f,0f,0f,0f,989.0f,1198.0f,204.0f,-281.0f,-343.0f,263.0f,-1860,37.04887f,-63.466595f,60.745453f,22.994312f,0f,0f ) ;
  }

  @Test
  public void test1074() {
    TestDrivers.surfaceShade(48.0f,450.0f,0f,0f,2812.0f,-4.0f,0f,-8.0f,0f,0f,0f,0f,0f,1584.0f,-2574.0f,967.0f,0f,0f,0f,1567,-0.5662633f,0.1440702f,-1.3394424f,-62.624332f,-79.476906f,0f ) ;
  }

  @Test
  public void test1075() {
    TestDrivers.surfaceShade(-48.0f,-884.0f,1279.0f,0f,1969.0f,-1226.0f,0f,-669.0f,0f,0f,0f,0f,0f,-676.0f,-820.0f,355.0f,0f,0f,0f,-310,0.7353577f,-0.044655856f,0.6762063f,-58.556866f,-44.349976f,1.3758117f ) ;
  }

  @Test
  public void test1076() {
    TestDrivers.surfaceShade(-488.0f,0f,0f,0f,317.0f,-854.0f,310.0f,311.0f,0f,0f,0f,0f,0f,-960.0f,-56.0f,-768.0f,259.0f,-444.0f,605.0f,594,86.34626f,90.1162f,59.41801f,62.60109f,0f,0f ) ;
  }

  @Test
  public void test1077() {
    TestDrivers.surfaceShade(-489.0f,-995.0f,-428.0f,-19.0f,0f,0f,0f,-0.45182174f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,1.07631044E-4f,67.91407f,1.2297097E-4f ) ;
  }

  @Test
  public void test1078() {
    TestDrivers.surfaceShade(490.0f,-115.0f,247.0f,0f,340.0f,-670.0f,0f,-758.0f,0f,0f,0f,0f,0f,337.0f,432.0f,-154.0f,0f,0f,0f,-236,-100.0f,100.0f,100.0f,100.0f,100.0f,-14.580877f ) ;
  }

  @Test
  public void test1079() {
    TestDrivers.surfaceShade(-49.0f,200.0f,0f,918.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-2.2231116E-5f,-100.0f,0f ) ;
  }

  @Test
  public void test1080() {
    TestDrivers.surfaceShade(49.0f,626.0f,72.0f,0f,17.0f,882.0f,0f,-276.0f,0f,0f,0f,0f,0f,279.0f,-348.0f,-244.0f,-579.0f,1173.0f,100.0f,-67,-47.374203f,94.25347f,37.297657f,-80.533905f,52.42427f,1.4822561E-8f ) ;
  }

  @Test
  public void test1081() {
    TestDrivers.surfaceShade(492.0f,-283.0f,0f,0f,202.0f,377.0f,0f,1426.0f,0f,0f,0f,0f,0f,-678.0f,594.0f,-776.0f,150.0f,823.0f,1752.0f,-687,-58.180576f,-90.62274f,-18.535408f,35.5716f,-61.841793f,0f ) ;
  }

  @Test
  public void test1082() {
    TestDrivers.surfaceShade(495.0f,-853.0f,31.0f,-193.0f,0f,0f,0f,-80.15328f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-42.722153f,6.074264E-6f,-97.65208f ) ;
  }

  @Test
  public void test1083() {
    TestDrivers.surfaceShade(496.0f,793.0f,0f,-20.0f,0f,0f,0f,-50.952812f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-1.0080645E-4f,-6.30517E-5f,0f ) ;
  }

  @Test
  public void test1084() {
    TestDrivers.surfaceShade(498.0f,0f,0f,0f,2646.0f,1294.0f,94.0f,2732.0f,0f,0f,0f,0f,0f,473.0f,628.0f,323.0f,-909.0f,-483.0f,509.0f,794,-1.5841994f,1.7191707f,-1.0226405f,100.0f,0f,0f ) ;
  }

  @Test
  public void test1085() {
    TestDrivers.surfaceShade(499.0f,827.0f,-12.0f,139.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,9,0f,0f,0f,-100.0f,8.699208E-6f,-5.995204E-4f ) ;
  }

  @Test
  public void test1086() {
    TestDrivers.surfaceShade(-501.0f,527.0f,536.0f,0f,220.0f,-1013.0f,0f,-2.0f,0f,0f,0f,0f,0f,-615.0f,46.0f,742.0f,0f,0f,0f,606,0.04174021f,0.2685262f,-0.36681405f,-100.0f,-22.274885f,39.66617f ) ;
  }

  @Test
  public void test1087() {
    TestDrivers.surfaceShade(502.0f,0f,0f,0f,1257.0f,880.0f,0f,804.0f,0f,0f,0f,0f,0f,93.0f,1372.0f,410.0f,-714.0f,-818.0f,-825.0f,-19,-0.47236606f,-0.6416315f,-0.5311437f,-1.651734f,0f,0f ) ;
  }

  @Test
  public void test1088() {
    TestDrivers.surfaceShade(-506.0f,-1396.0f,792.0f,347.0f,0f,0f,0f,-52.694588f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-5.6953445E-6f,-58.561638f,32.973873f ) ;
  }

  @Test
  public void test1089() {
    TestDrivers.surfaceShade(-507.0f,0f,464.0f,453.0f,0f,0f,0f,330.0f,0f,0f,0f,0f,0f,1065.0f,-39.0f,1480.0f,919.0f,-821.0f,-690.0f,-5,0f,0f,0f,71.456085f,0f,4.757555E-6f ) ;
  }

  @Test
  public void test1090() {
    TestDrivers.surfaceShade(510.0f,-348.0f,0f,0f,313.0f,629.0f,0f,714.0f,0f,0f,0f,0f,0f,247.0f,865.0f,535.0f,813.0f,-250.0f,-753.0f,800,-91.08902f,-100.0f,-148.74767f,-100.0f,-100.0f,0f ) ;
  }

  @Test
  public void test1091() {
    TestDrivers.surfaceShade(512.0f,364.0f,2.0f,0f,1360.0f,-710.0f,0f,-2156.0f,0f,0f,0f,0f,0f,-1733.0f,-2433.0f,-1054.0f,0f,0f,0f,-350,0.76806223f,-0.5047973f,-0.09760908f,100.0f,-71.763435f,29.828629f ) ;
  }

  @Test
  public void test1092() {
    TestDrivers.surfaceShade(-516.0f,-152.0f,0f,788.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-34.20099f,-97.66812f,-69.62429f,100.0f,-8.348918E-6f,0f ) ;
  }

  @Test
  public void test1093() {
    TestDrivers.surfaceShade(-531.0f,2057.0f,0f,0f,1252.0f,9.0f,-10.0f,969.0f,0f,0f,0f,0f,0f,-159.0f,479.0f,418.0f,528.0f,-469.0f,549.0f,889,42.651447f,-58.44686f,83.198616f,34.853943f,-79.52598f,0f ) ;
  }

  @Test
  public void test1094() {
    TestDrivers.surfaceShade(-536.0f,116.0f,76.0f,241.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-100.0f,-20.714296f,5.4597072E-5f ) ;
  }

  @Test
  public void test1095() {
    TestDrivers.surfaceShade(-536.0f,-720.0f,0f,0f,621.0f,-102.0f,0f,-783.0f,0f,0f,0f,0f,0f,767.0f,81.0f,-285.0f,0f,0f,0f,175,-37.89113f,100.0f,-73.55262f,-40.90842f,100.0f,0f ) ;
  }

  @Test
  public void test1096() {
    TestDrivers.surfaceShade(536.0f,-908.0f,-1173.0f,0f,446.0f,-3.0f,0f,-524.0f,0f,0f,0f,0f,0f,-923.0f,-26.0f,239.0f,0f,0f,0f,1334,-23.296501f,100.0f,-79.09067f,-14.70164f,-120.42745f,-100.0f ) ;
  }

  @Test
  public void test1097() {
    TestDrivers.surfaceShade(546.0f,-1214.0f,-238.0f,0f,358.0f,-566.0f,0f,-376.0f,0f,0f,0f,0f,0f,296.0f,418.0f,1570.0f,0f,0f,0f,826,-0.46473008f,0.33004233f,-2.5323906E-4f,-54.807777f,100.0f,-100.0f ) ;
  }

  @Test
  public void test1098() {
    TestDrivers.surfaceShade(554.0f,282.0f,0f,0f,461.0f,-4.0f,0f,0.0f,0f,0f,0f,0f,0f,-32.0f,-896.0f,409.0f,0f,0f,0f,542,89.67772f,-3.744089f,-1.1858597f,-11.6926f,100.0f,0f ) ;
  }

  @Test
  public void test1099() {
    TestDrivers.surfaceShade(-561.0f,-399.0f,0f,-908.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-2.0679467f,27.389997f,-35.223167f,19.174877f,2.7602046E-6f,0f ) ;
  }

  @Test
  public void test1100() {
    TestDrivers.surfaceShade(565.0f,-151.0f,-221.0f,0f,1024.0f,1062.0f,0f,284.0f,0f,0f,0f,0f,0f,440.0f,690.0f,-969.0f,408.0f,-586.0f,478.0f,-1121,0.2946268f,-0.11750318f,0.10074385f,40.48594f,14.257314f,-41.877323f ) ;
  }

  @Test
  public void test1101() {
    TestDrivers.surfaceShade(-569.0f,1526.0f,431.0f,0f,476.0f,-601.0f,0f,33.0f,0f,0f,0f,0f,0f,-2131.0f,-83.0f,-283.0f,1327.0f,-1545.0f,-541.0f,237,0.061112337f,-3.6043136f,1.5254848f,-96.83507f,35.244755f,56.26362f ) ;
  }

  @Test
  public void test1102() {
    TestDrivers.surfaceShade(-571.0f,-442.0f,0f,0f,261.0f,651.0f,663.0f,-309.0f,0f,0f,0f,0f,0f,734.0f,794.0f,672.0f,-405.0f,-670.0f,-210.0f,-841,-66.11907f,-90.57121f,24.022293f,-65.45749f,91.46116f,0f ) ;
  }

  @Test
  public void test1103() {
    TestDrivers.surfaceShade(571.0f,-606.0f,0f,0f,1884.0f,-2064.0f,0f,-892.0f,0f,0f,0f,0f,0f,-879.0f,165.0f,-109.0f,0f,0f,0f,425,0.95712346f,2.5205414f,-3.902956f,-17.425034f,-83.924095f,0f ) ;
  }

  @Test
  public void test1104() {
    TestDrivers.surfaceShade(574.0f,-987.0f,0f,0f,612.0f,-379.0f,0f,949.0f,0f,0f,0f,0f,0f,671.0f,51.0f,-292.0f,-673.0f,337.0f,-597.0f,933,-59.89661f,-72.47721f,21.564861f,-62.98148f,14.042818f,0f ) ;
  }

  @Test
  public void test1105() {
    TestDrivers.surfaceShade(576.0f,288.0f,0f,-840.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-2,70.11441f,-53.915436f,-40.05358f,36.035122f,-0.6243823f,0f ) ;
  }

  @Test
  public void test1106() {
    TestDrivers.surfaceShade(-578.0f,0f,0f,0f,918.0f,484.0f,0f,-269.0f,0f,0f,0f,0f,0f,117.0f,564.0f,268.0f,-133.0f,-713.0f,-792.0f,250,-79.67582f,-99.24832f,-97.65225f,-57.205776f,0f,0f ) ;
  }

  @Test
  public void test1107() {
    TestDrivers.surfaceShade(-580.0f,1313.0f,0f,0f,168.0f,965.0f,0f,-955.0f,0f,0f,0f,0f,0f,-646.0f,52.0f,-1859.0f,-788.0f,800.0f,764.0f,-685,-0.6309188f,0.38607025f,0.49071774f,-73.47007f,18.156445f,0f ) ;
  }

  @Test
  public void test1108() {
    TestDrivers.surfaceShade(584.0f,-276.0f,-967.0f,0f,-657.0f,362.0f,392.0f,551.0f,0f,0f,0f,0f,0f,-821.0f,-407.0f,-427.0f,68.0f,-968.0f,-825.0f,657,-88.481f,-10.689074f,-44.000854f,-62.39437f,70.61953f,60.23977f ) ;
  }

  @Test
  public void test1109() {
    TestDrivers.surfaceShade(-585.0f,-323.0f,-20.0f,0f,85.0f,142.0f,0f,341.0f,0f,0f,0f,0f,0f,-441.0f,-826.0f,27.0f,537.0f,221.0f,-533.0f,1445,0.46425372f,-0.25407094f,-0.18989024f,-100.0f,39.552525f,-3.4289348f ) ;
  }

  @Test
  public void test1110() {
    TestDrivers.surfaceShade(-586.0f,-589.0f,666.0f,0f,571.0f,-887.0f,0f,-1903.0f,0f,0f,0f,0f,0f,1448.0f,1323.0f,1755.0f,0f,0f,0f,790,0.6464628f,-0.7556024f,-0.12443883f,-39.667534f,-30.581858f,-15.363168f ) ;
  }

  @Test
  public void test1111() {
    TestDrivers.surfaceShade(-59.0f,0f,0f,583.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-15.318965f,0f,0f ) ;
  }

  @Test
  public void test1112() {
    TestDrivers.surfaceShade(592.0f,447.0f,52.0f,0f,459.0f,1266.0f,0f,-967.0f,0f,0f,0f,0f,0f,-270.0f,-401.0f,337.0f,683.0f,-194.0f,-684.0f,-483,-59.686016f,55.32683f,18.014349f,-34.630318f,21.428425f,100.0f ) ;
  }

  @Test
  public void test1113() {
    TestDrivers.surfaceShade(-595.0f,115.0f,0f,0f,24.0f,-395.0f,0f,179.0f,0f,0f,0f,0f,0f,-508.0f,1134.0f,699.0f,-537.0f,-908.0f,654.0f,-721,46.964867f,-23.778101f,72.70744f,-29.937246f,0.020180013f,0f ) ;
  }

  @Test
  public void test1114() {
    TestDrivers.surfaceShade(596.0f,119.0f,166.0f,0f,973.0f,-269.0f,0f,687.0f,0f,0f,0f,0f,0f,-303.0f,13.0f,285.0f,586.0f,286.0f,-172.0f,829,15.363881f,-75.92966f,-70.22383f,63.73891f,-110.965866f,-41.39389f ) ;
  }

  @Test
  public void test1115() {
    TestDrivers.surfaceShade(-596.0f,1240.0f,0f,0f,186.0f,0.0f,0f,-1.0f,0f,0f,0f,0f,0f,387.0f,-436.0f,268.0f,0f,0f,0f,1769,0.59135556f,0.113090955f,-0.6855237f,-95.49212f,-1.7748852f,0f ) ;
  }

  @Test
  public void test1116() {
    TestDrivers.surfaceShade(596.0f,159.0f,-942.0f,-85.0f,0f,0f,0f,-28.242056f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-63.663227f,-7.399186E-5f,-100.0f ) ;
  }

  @Test
  public void test1117() {
    TestDrivers.surfaceShade(597.0f,610.0f,0f,-591.0f,0f,0f,0f,835.0f,0f,0f,0f,0f,0f,-346.0f,454.0f,-826.0f,134.0f,260.0f,698.0f,-1,0f,0f,0f,35.19035f,44.239635f,0f ) ;
  }

  @Test
  public void test1118() {
    TestDrivers.surfaceShade(600.0f,-316.0f,-987.0f,0f,398.0f,-703.0f,0f,973.0f,0f,0f,0f,0f,0f,-1402.0f,-58.0f,429.0f,-721.0f,93.0f,51.0f,849,33.100403f,-100.0f,23.48284f,81.94728f,-100.0f,-105.7568f ) ;
  }

  @Test
  public void test1119() {
    TestDrivers.surfaceShade(-604.0f,735.0f,1435.0f,0f,28.0f,834.0f,0f,1094.0f,0f,0f,0f,0f,0f,248.0f,-441.0f,813.0f,-1376.0f,-906.0f,-1345.0f,-682,1.5975548f,51.609966f,27.507751f,-71.43282f,58.761f,100.0f ) ;
  }

  @Test
  public void test1120() {
    TestDrivers.surfaceShade(607.0f,-331.0f,195.0f,0f,852.0f,-1782.0f,0f,-960.0f,0f,0f,0f,0f,0f,235.0f,114.0f,200.0f,0f,0f,0f,5,32.089737f,-23.766546f,-24.158508f,4.839014f,-62.49613f,45.60235f ) ;
  }

  @Test
  public void test1121() {
    TestDrivers.surfaceShade(-6.0f,0f,0f,0f,368.0f,-682.0f,0f,736.0f,0f,0f,0f,0f,0f,-772.0f,2049.0f,-930.0f,2236.0f,66.0f,-922.0f,-1978,0.8395313f,0.11567259f,-0.4420484f,-13.924843f,0f,0f ) ;
  }

  @Test
  public void test1122() {
    TestDrivers.surfaceShade(61.0f,-655.0f,370.0f,-65.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-100.0f,-78.642136f,-65.596565f ) ;
  }

  @Test
  public void test1123() {
    TestDrivers.surfaceShade(611.0f,1958.0f,0f,0f,845.0f,-1319.0f,0f,1668.0f,0f,0f,0f,0f,0f,1468.0f,-958.0f,835.0f,-2759.0f,115.0f,644.0f,-1997,-0.15573773f,0.25317177f,-0.5852622f,88.20462f,64.86464f,0f ) ;
  }

  @Test
  public void test1124() {
    TestDrivers.surfaceShade(611.0f,-809.0f,0f,0f,1203.0f,-2.0f,0f,-964.0f,0f,0f,0f,0f,0f,25.0f,768.0f,-672.0f,0f,0f,0f,409,-2.225125f,-69.02444f,59.39946f,7.677126f,95.0805f,0f ) ;
  }

  @Test
  public void test1125() {
    TestDrivers.surfaceShade(-612.0f,-696.0f,0f,0f,826.0f,899.0f,0f,-1631.0f,0f,0f,0f,0f,0f,554.0f,-247.0f,-706.0f,-312.0f,-109.0f,87.0f,-713,-80.94634f,38.50076f,-25.978228f,100.0f,-4.830003E-11f,0f ) ;
  }

  @Test
  public void test1126() {
    TestDrivers.surfaceShade(-614.0f,-174.0f,0f,0f,355.0f,552.0f,0f,-540.0f,0f,0f,0f,0f,0f,-42.0f,-256.0f,-46.0f,-739.0f,530.0f,454.0f,-428,-36.801373f,2.720661f,85.277824f,-93.84582f,-74.64022f,0f ) ;
  }

  @Test
  public void test1127() {
    TestDrivers.surfaceShade(-618.0f,-242.0f,-147.0f,0f,140.0f,420.0f,0f,973.0f,0f,0f,0f,0f,0f,-841.0f,750.0f,-437.0f,624.0f,-292.0f,373.0f,785,18.442066f,-17.29216f,80.6516f,83.77064f,21.098867f,-16.510347f ) ;
  }

  @Test
  public void test1128() {
    TestDrivers.surfaceShade(-619.0f,0f,0f,0f,496.0f,-41.0f,0f,311.0f,0f,0f,0f,0f,0f,283.0f,-115.0f,763.0f,934.0f,-520.0f,3155.0f,-125,1.6683643f,2.2072468f,-0.28612542f,99.999756f,0f,0f ) ;
  }

  @Test
  public void test1129() {
    TestDrivers.surfaceShade(620.0f,-790.0f,0f,0f,5.0f,-34.0f,0f,211.0f,0f,0f,0f,0f,0f,-108.0f,829.0f,417.0f,-285.0f,59.0f,978.0f,-1392,0.29444572f,-0.09494117f,0.26500288f,-100.0f,-0.22757298f,0f ) ;
  }

  @Test
  public void test1130() {
    TestDrivers.surfaceShade(62.0f,944.0f,626.0f,0f,800.0f,-361.0f,0f,69.0f,0f,0f,0f,0f,0f,-602.0f,202.0f,774.0f,42.0f,781.0f,-450.0f,328,52.966064f,-80.68502f,10.398954f,31.708311f,-99.70534f,100.0f ) ;
  }

  @Test
  public void test1131() {
    TestDrivers.surfaceShade(-621.0f,-807.0f,-777.0f,0f,408.0f,-915.0f,0f,666.0f,0f,0f,0f,0f,0f,362.0f,-655.0f,-484.0f,206.0f,-929.0f,205.0f,37,46.071026f,24.54386f,56.45583f,-76.76367f,49.10861f,-41.32043f ) ;
  }

  @Test
  public void test1132() {
    TestDrivers.surfaceShade(-623.0f,0f,0f,0f,440.0f,2910.0f,0f,-186.0f,0f,0f,0f,0f,0f,-2787.0f,-1040.0f,-1457.0f,297.0f,-92.0f,1667.0f,479,0.62527305f,0.1733358f,-0.50229275f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test1133() {
    TestDrivers.surfaceShade(624.0f,983.0f,-627.0f,0f,282.0f,-728.0f,0f,140.0f,0f,0f,0f,0f,0f,-924.0f,176.0f,931.0f,-83.0f,-879.0f,542.0f,231,9.52788f,-47.78569f,18.489841f,-30.044226f,-41.722008f,-63.12265f ) ;
  }

  @Test
  public void test1134() {
    TestDrivers.surfaceShade(-638.0f,1092.0f,682.0f,3.0f,0f,0f,0f,-85.03948f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,57.66372f,81.14279f,100.0f ) ;
  }

  @Test
  public void test1135() {
    TestDrivers.surfaceShade(64.0f,1617.0f,2395.0f,0f,628.0f,315.0f,0f,1739.0f,0f,0f,0f,0f,0f,-880.0f,298.0f,696.0f,523.0f,867.0f,-1629.0f,388,87.54125f,73.17529f,79.35354f,99.998825f,100.0f,44.844086f ) ;
  }

  @Test
  public void test1136() {
    TestDrivers.surfaceShade(644.0f,327.0f,-373.0f,0f,59.0f,701.0f,0f,597.0f,0f,0f,0f,0f,0f,-152.0f,-315.0f,178.0f,-536.0f,364.0f,-189.0f,-317,-37.668724f,-28.795532f,-83.33179f,-56.13815f,-70.43895f,-1.234134E-6f ) ;
  }

  @Test
  public void test1137() {
    TestDrivers.surfaceShade(-650.0f,0f,0f,0f,43.823036f,0.0f,0f,-80.18716f,0f,0f,0f,0f,0f,132.05841f,33.76906f,-49.026367f,0f,0f,0f,7,0.26153734f,1.4677458f,1.7353306f,-0.5374635f,0f,0f ) ;
  }

  @Test
  public void test1138() {
    TestDrivers.surfaceShade(652.0f,397.0f,0f,-885.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-2,-16.377697f,63.150814f,-117.941795f,-33.8229f,-85.360435f,0f ) ;
  }

  @Test
  public void test1139() {
    TestDrivers.surfaceShade(654.0f,0f,0f,0f,1551.0f,1338.0f,544.0f,620.0f,0f,0f,0f,0f,0f,655.0f,-455.0f,-807.0f,-960.0f,274.0f,573.0f,608,-0.0840977f,-2.9189408f,1.5774897f,24.7059f,0f,0f ) ;
  }

  @Test
  public void test1140() {
    TestDrivers.surfaceShade(-654.0f,-197.0f,0f,0f,455.0f,-1300.0f,0f,1.0f,0f,0f,0f,0f,0f,-448.0f,429.0f,-176.0f,0f,0f,0f,-940,-0.09115161f,0.008219783f,0.38945392f,100.0f,52.22482f,0f ) ;
  }

  @Test
  public void test1141() {
    TestDrivers.surfaceShade(-658.0f,-574.0f,91.0f,0f,273.0f,-90.0f,0f,0.0f,0f,0f,0f,0f,0f,105.0f,-270.0f,-227.0f,0f,0f,0f,599,-89.11261f,62.5271f,-21.569683f,-10.507794f,80.681206f,62.272224f ) ;
  }

  @Test
  public void test1142() {
    TestDrivers.surfaceShade(667.0f,-1106.0f,0f,0f,1061.0f,-1.0f,0f,-1.0f,0f,0f,0f,0f,0f,486.0f,181.0f,114.0f,0f,0f,0f,-468,-0.386659f,0.3556419f,0.5137121f,45.348366f,-9.991031f,0f ) ;
  }

  @Test
  public void test1143() {
    TestDrivers.surfaceShade(67.0f,-142.0f,0f,0f,825.0f,938.0f,0f,170.0f,0f,0f,0f,0f,0f,-720.0f,783.0f,-345.0f,759.0f,765.0f,593.0f,180,-41.08562f,-6.0905533f,78.22854f,-18.835567f,7.3884664f,0f ) ;
  }

  @Test
  public void test1144() {
    TestDrivers.surfaceShade(671.0f,461.0f,0f,0f,622.0f,-232.0f,0f,-54.0f,0f,0f,0f,0f,0f,-441.0f,-735.0f,852.0f,0f,0f,0f,-593,-67.95107f,76.82665f,-24.406834f,-95.40599f,-85.364296f,0f ) ;
  }

  @Test
  public void test1145() {
    TestDrivers.surfaceShade(-674.0f,1925.0f,-968.0f,0f,15.0f,-359.0f,0f,-2551.0f,0f,0f,0f,0f,0f,188.0f,1206.0f,-1001.0f,0f,0f,0f,1623,-0.97018003f,0.22408965f,0.092340864f,-65.601906f,-99.523125f,-18.751337f ) ;
  }

  @Test
  public void test1146() {
    TestDrivers.surfaceShade(-677.0f,-348.0f,-596.0f,0f,156.0f,52.0f,0f,900.0f,0f,0f,0f,0f,0f,732.0f,-24.0f,316.0f,-594.0f,728.0f,-833.0f,-154,-26.621046f,50.10166f,65.471664f,-38.84735f,-42.99077f,8.920298f ) ;
  }

  @Test
  public void test1147() {
    TestDrivers.surfaceShade(-68.0f,0f,0f,0f,60.072346f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-39.594734f,19.34743f,55.31443f,0f,0f,0f,-900,12.572948f,-81.20822f,34.38192f,-1.4884324f,0f,0f ) ;
  }

  @Test
  public void test1148() {
    TestDrivers.surfaceShade(683.0f,-455.0f,1333.0f,-711.0f,0f,0f,0f,-3.9443045E-31f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,-103.60409f,-104.306526f,45.85595f ) ;
  }

  @Test
  public void test1149() {
    TestDrivers.surfaceShade(-684.0f,0f,0f,0f,787.0f,-555.0f,0f,1597.0f,0f,0f,0f,0f,0f,180.0f,-1226.0f,261.0f,-187.0f,1046.0f,-380.0f,-1152,0.4882322f,0.6982796f,-0.5234834f,99.95645f,0f,0f ) ;
  }

  @Test
  public void test1150() {
    TestDrivers.surfaceShade(-684.0f,928.0f,0f,0f,105.0f,-856.0f,0f,-710.0f,0f,0f,0f,0f,0f,-13.0f,17.0f,274.0f,0f,0f,0f,1226,0.7464038f,0.41051236f,0.0099435765f,36.943577f,86.07763f,0f ) ;
  }

  @Test
  public void test1151() {
    TestDrivers.surfaceShade(685.0f,0f,0f,0f,961.0f,238.0f,-505.0f,498.0f,0f,0f,0f,0f,0f,-502.0f,459.0f,-17.0f,772.0f,835.0f,-1017.0f,178,42.41187f,-20.599756f,-4.127358f,100.0f,0f,0f ) ;
  }

  @Test
  public void test1152() {
    TestDrivers.surfaceShade(-687.0f,884.0f,86.0f,0f,1361.0f,-379.0f,0f,-1173.0f,0f,0f,0f,0f,0f,-258.0f,-1052.0f,-819.0f,0f,0f,0f,397,-0.6951993f,0.16009511f,0.2762707f,-3.2874393f,-70.53922f,100.0f ) ;
  }

  @Test
  public void test1153() {
    TestDrivers.surfaceShade(-688.0f,719.0f,0f,0f,2737.0f,648.0f,-1525.0f,532.0f,0f,0f,0f,0f,0f,849.0f,-633.0f,596.0f,16.0f,967.0f,-89.0f,992,31.36615f,52.131485f,10.68686f,-14.129197f,11.265825f,0f ) ;
  }

  @Test
  public void test1154() {
    TestDrivers.surfaceShade(689.0f,777.0f,0f,0f,200.0f,-977.0f,0f,-927.0f,0f,0f,0f,0f,0f,322.0f,-802.0f,23.0f,0f,0f,0f,-627,-21.261755f,53.076813f,-22.83624f,-76.728195f,19.216846f,0f ) ;
  }

  @Test
  public void test1155() {
    TestDrivers.surfaceShade(-693.0f,600.0f,256.0f,-631.0f,0f,0f,0f,-45.252243f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-69.00196f,65.40418f,47.712444f ) ;
  }

  @Test
  public void test1156() {
    TestDrivers.surfaceShade(-701.0f,35.0f,0f,0f,415.0f,4.0f,0f,-970.0f,0f,0f,0f,0f,0f,-598.0f,1708.0f,-192.0f,0f,0f,0f,984,0.84838504f,-0.13593991f,0.26377138f,57.015465f,41.92417f,0f ) ;
  }

  @Test
  public void test1157() {
    TestDrivers.surfaceShade(703.0f,0f,0f,0f,302.0f,376.0f,0f,394.0f,0f,0f,0f,0f,0f,-200.0f,-930.0f,-812.0f,230.0f,286.0f,833.0f,-630,-4.7239656f,35.40331f,-4.917479f,-39.39499f,0f,0f ) ;
  }

  @Test
  public void test1158() {
    TestDrivers.surfaceShade(705.0f,704.0f,0f,0f,761.0f,-180.0f,0f,-551.0f,0f,0f,0f,0f,0f,1220.0f,517.0f,-745.0f,0f,0f,0f,990,0.21915801f,0.028673844f,0.97526795f,96.672325f,58.37804f,0f ) ;
  }

  @Test
  public void test1159() {
    TestDrivers.surfaceShade(-7.0f,1919.0f,0f,0f,274.0f,-1543.0f,0f,-6.0f,0f,0f,0f,0f,0f,-1138.0f,-658.0f,-1181.0f,0f,0f,0f,-452,-0.10630994f,0.6886682f,-0.26879153f,-3.5419213E-5f,50.60748f,0f ) ;
  }

  @Test
  public void test1160() {
    TestDrivers.surfaceShade(711.0f,1032.0f,-1313.0f,0f,743.0f,-1463.0f,0f,426.0f,0f,0f,0f,0f,0f,-365.0f,-520.0f,-498.0f,645.0f,957.0f,1626.0f,-715,0.35213554f,0.8289089f,0.08168563f,7.1279893f,-19.013178f,26.501495f ) ;
  }

  @Test
  public void test1161() {
    TestDrivers.surfaceShade(-717.0f,-269.0f,-730.0f,0f,115.0f,387.0f,0f,1444.0f,0f,0f,0f,0f,0f,864.0f,-632.0f,-2216.0f,-765.0f,783.0f,232.0f,81,-0.6248458f,0.33708346f,0.012829603f,-100.0f,-15.670244f,-87.3674f ) ;
  }

  @Test
  public void test1162() {
    TestDrivers.surfaceShade(-724.0f,0f,0f,0f,12.731147f,-22.537256f,0f,-22.917208f,0f,0f,0f,0f,0f,-79.85933f,-53.493687f,9.673244f,0f,0f,0f,-47,52.736973f,50.376816f,-97.72691f,-74.285706f,0f,0f ) ;
  }

  @Test
  public void test1163() {
    TestDrivers.surfaceShade(-725.0f,1066.0f,0f,0f,1637.0f,-1349.0f,0f,1288.0f,0f,0f,0f,0f,0f,348.0f,-666.0f,-246.0f,-1349.0f,-1533.0f,-464.0f,-1027,-0.6615445f,0.22187296f,0.38065568f,0.17793927f,-44.01092f,0f ) ;
  }

  @Test
  public void test1164() {
    TestDrivers.surfaceShade(726.0f,-530.0f,-106.0f,0f,786.0f,-606.0f,0f,1410.0f,0f,0f,0f,0f,0f,562.0f,-1354.0f,-1024.0f,423.0f,-970.0f,-1120.0f,576,-0.22364604f,0.5673864f,-0.26664564f,58.812965f,-39.448666f,-9.9315605f ) ;
  }

  @Test
  public void test1165() {
    TestDrivers.surfaceShade(-727.0f,0f,0f,0f,101.53114f,-100.0f,0f,-50.412178f,0f,0f,0f,0f,0f,54.571495f,-67.85602f,100.0f,0f,0f,0f,1,-0.020323006f,-0.10483728f,1.7404963f,100.0f,0f,0f ) ;
  }

  @Test
  public void test1166() {
    TestDrivers.surfaceShade(731.0f,0f,0f,0f,57.12643f,0.0f,0f,-23.622921f,0f,0f,0f,0f,0f,58.672092f,-59.562874f,8.076432f,0f,0f,0f,656,9.876688f,8.851482f,-27.389214f,-38.872314f,0f,0f ) ;
  }

  @Test
  public void test1167() {
    TestDrivers.surfaceShade(-731.0f,-1800.0f,0f,0f,872.0f,-549.0f,0f,-392.0f,0f,0f,0f,0f,0f,428.0f,-2039.0f,3080.0f,0f,0f,0f,2,1.00776f,-0.7607347f,-0.8157553f,79.19449f,74.001396f,0f ) ;
  }

  @Test
  public void test1168() {
    TestDrivers.surfaceShade(-737.0f,11.0f,0f,0f,30.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,620.0f,-1844.0f,-722.0f,0f,0f,0f,-197,-0.08967265f,-0.20185043f,0.51634246f,6.0273266f,-0.1535972f,0f ) ;
  }

  @Test
  public void test1169() {
    TestDrivers.surfaceShade(737.0f,-645.0f,1244.0f,0f,146.0f,599.0f,0f,-1466.0f,0f,0f,0f,0f,0f,604.0f,920.0f,-805.0f,716.0f,1981.0f,-1166.0f,202,7.214077f,-62.72489f,-66.2728f,-77.32552f,-43.18638f,36.06257f ) ;
  }

  @Test
  public void test1170() {
    TestDrivers.surfaceShade(739.0f,1193.0f,-11.0f,0f,346.0f,-1600.0f,0f,-917.0f,0f,0f,0f,0f,0f,-730.0f,272.0f,-562.0f,0f,0f,0f,2064,-41.0808f,39.107765f,72.28878f,-88.30153f,3.446743f,-372.74524f ) ;
  }

  @Test
  public void test1171() {
    TestDrivers.surfaceShade(-739.0f,-364.0f,0f,0f,508.0f,-527.0f,0f,2.0f,0f,0f,0f,0f,0f,-763.0f,-641.0f,-152.0f,0f,0f,0f,-603,-67.25088f,56.33763f,100.0f,-100.0f,-45.722614f,0f ) ;
  }

  @Test
  public void test1172() {
    TestDrivers.surfaceShade(-739.0f,-500.0f,-475.0f,0f,1121.0f,828.0f,0f,-228.0f,0f,0f,0f,0f,0f,452.0f,31.0f,-349.0f,-648.0f,27.0f,-789.0f,467,-9.592726f,100.0f,97.71419f,-36.785057f,19.005358f,9.727972f ) ;
  }

  @Test
  public void test1173() {
    TestDrivers.surfaceShade(-740.0f,2479.0f,607.0f,0f,748.0f,-1137.0f,0f,414.0f,0f,0f,0f,0f,0f,98.0f,-1.0f,979.0f,46.0f,-1055.0f,602.0f,-618,-7.749668f,-99.296906f,0.67433155f,-53.873615f,-100.0f,-26.059484f ) ;
  }

  @Test
  public void test1174() {
    TestDrivers.surfaceShade(-744.0f,-763.0f,181.0f,0f,-488.0f,734.0f,481.0f,-425.0f,0f,0f,0f,0f,0f,-547.0f,-208.0f,-865.0f,-296.0f,568.0f,-476.0f,-73,45.203735f,-58.784363f,-51.896f,51.12773f,-94.900276f,8.584045f ) ;
  }

  @Test
  public void test1175() {
    TestDrivers.surfaceShade(-747.0f,2158.0f,-136.0f,0f,1923.0f,-1431.0f,0f,576.0f,0f,0f,0f,0f,0f,-61.0f,-421.0f,1441.0f,513.0f,894.0f,483.0f,-738,-0.63520074f,0.4453638f,-0.59238446f,-76.69219f,-100.0f,-0.55791605f ) ;
  }

  @Test
  public void test1176() {
    TestDrivers.surfaceShade(750.0f,360.0f,1593.0f,0f,887.0f,1252.0f,0f,266.0f,0f,0f,0f,0f,0f,-101.0f,716.0f,715.0f,848.0f,-1699.0f,938.0f,1566,-44.54322f,-13.73455f,7.46164f,-21.645214f,30.21093f,-28.800802f ) ;
  }

  @Test
  public void test1177() {
    TestDrivers.surfaceShade(-75.0f,0f,0f,0f,19.472378f,-57.073936f,0f,-82.652725f,0f,0f,0f,0f,0f,-24.119745f,-100.0f,-18.707144f,0f,0f,0f,1,0.27261487f,-0.039803073f,-0.8298557f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test1178() {
    TestDrivers.surfaceShade(-752.0f,0f,0f,0f,30.282032f,-64.04343f,0f,-29.506754f,0f,0f,0f,0f,0f,81.15634f,35.576153f,-0.058632787f,0f,0f,0f,492,-35.42594f,-96.54386f,-51.536972f,55.232086f,0f,0f ) ;
  }

  @Test
  public void test1179() {
    TestDrivers.surfaceShade(-752.0f,207.0f,0f,0f,728.0f,-739.0f,0f,551.0f,0f,0f,0f,0f,0f,-273.0f,612.0f,-733.0f,-901.0f,-197.0f,311.0f,-275,67.63923f,34.436184f,62.991653f,30.468481f,29.817783f,0f ) ;
  }

  @Test
  public void test1180() {
    TestDrivers.surfaceShade(-754.0f,2537.0f,0f,0f,1522.0f,-314.0f,0f,7.0f,0f,0f,0f,0f,0f,419.0f,-867.0f,602.0f,0f,0f,0f,1341,-75.85519f,-42.79493f,-8.83701f,-34.048935f,20.053432f,0f ) ;
  }

  @Test
  public void test1181() {
    TestDrivers.surfaceShade(754.0f,785.0f,0f,0f,14.0f,-1.0f,0f,-3.0f,0f,0f,0f,0f,0f,524.0f,588.0f,676.0f,0f,0f,0f,848,25.064342f,23.153828f,-39.568295f,100.0f,-2.4394474f,0f ) ;
  }

  @Test
  public void test1182() {
    TestDrivers.surfaceShade(76.0f,2.0f,0f,0f,150.0f,-790.0f,0f,-2.0f,0f,0f,0f,0f,0f,1254.0f,-536.0f,329.0f,0f,0f,0f,1372,0.017217338f,0.0074355635f,-0.053510886f,93.07078f,100.0f,0f ) ;
  }

  @Test
  public void test1183() {
    TestDrivers.surfaceShade(768.0f,-919.0f,928.0f,0f,748.0f,58.0f,0f,59.0f,0f,0f,0f,0f,0f,248.0f,180.0f,-177.0f,-276.0f,-623.0f,-114.0f,217,81.52236f,-74.95411f,57.768337f,-72.90319f,-9.566102f,77.75742f ) ;
  }

  @Test
  public void test1184() {
    TestDrivers.surfaceShade(-770.0f,2914.0f,0f,0f,633.0f,226.0f,0f,-22.0f,0f,0f,0f,0f,0f,2152.0f,2522.0f,920.0f,-852.0f,-1596.0f,558.0f,1300,0.07015071f,-0.69366735f,0.017195048f,-56.6521f,-33.83638f,0f ) ;
  }

  @Test
  public void test1185() {
    TestDrivers.surfaceShade(-77.0f,1696.0f,278.0f,35.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-2,0f,0f,0f,-3.710575E-4f,-157.3276f,100.0f ) ;
  }

  @Test
  public void test1186() {
    TestDrivers.surfaceShade(773.0f,0f,0f,0f,68.2113f,0.0f,0f,-78.01659f,0f,0f,0f,0f,0f,-75.90343f,-66.62674f,-47.690754f,0f,0f,0f,326,100.0f,-66.86829f,100.0f,78.34292f,0f,0f ) ;
  }

  @Test
  public void test1187() {
    TestDrivers.surfaceShade(-776.0f,0f,0f,0f,201.0f,-1067.0f,0f,828.0f,0f,0f,0f,0f,0f,800.0f,874.0f,56.0f,769.0f,-141.0f,-847.0f,600,-46.62651f,38.645927f,62.940517f,1.0537913f,0f,0f ) ;
  }

  @Test
  public void test1188() {
    TestDrivers.surfaceShade(-780.0f,-24.0f,545.0f,0f,202.0f,-1267.0f,0f,-456.0f,0f,0f,0f,0f,0f,418.0f,-150.0f,-115.0f,0f,0f,0f,-1963,-2.904672f,23.010954f,-40.57214f,-64.26845f,-81.15521f,3.9537528f ) ;
  }

  @Test
  public void test1189() {
    TestDrivers.surfaceShade(-78.0f,859.0f,0f,0f,60.0f,911.0f,0f,-1291.0f,0f,0f,0f,0f,0f,976.0f,609.0f,-647.0f,-364.0f,-1468.0f,1016.0f,-512,-0.43190017f,0.8278252f,0.1276831f,26.256653f,14.55107f,0f ) ;
  }

  @Test
  public void test1190() {
    TestDrivers.surfaceShade(78.0f,-875.0f,1091.0f,68.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,83.0313f,-100.0f,82.86724f,-1.9596316E-4f,107.26843f,-60.617172f ) ;
  }

  @Test
  public void test1191() {
    TestDrivers.surfaceShade(-781.0f,145.0f,0f,0f,577.0f,-898.0f,0f,553.0f,0f,0f,0f,0f,0f,571.0f,137.0f,557.0f,385.0f,795.0f,-661.0f,-280,-21.387053f,-49.55837f,23.206501f,-39.525486f,-98.22022f,0f ) ;
  }

  @Test
  public void test1192() {
    TestDrivers.surfaceShade(784.0f,1407.0f,0f,0f,110.0f,-396.0f,0f,-82.0f,0f,0f,0f,0f,0f,30.0f,1242.0f,-177.0f,0f,0f,0f,-722,0.5782387f,-0.11649234f,0.42962343f,3.6616185f,74.36664f,0f ) ;
  }

  @Test
  public void test1193() {
    TestDrivers.surfaceShade(-786.0f,1558.0f,1981.0f,0f,162.0f,-959.0f,0f,-2.0f,0f,0f,0f,0f,0f,552.0f,-341.0f,-286.0f,0f,0f,0f,-877,-16.297266f,100.0f,42.666798f,-73.00649f,-0.85505056f,-14.708241f ) ;
  }

  @Test
  public void test1194() {
    TestDrivers.surfaceShade(-789.0f,0f,0f,0f,-583.0f,-204.0f,472.0f,-945.0f,0f,0f,0f,0f,0f,220.0f,-162.0f,753.0f,-623.0f,-130.0f,-911.0f,960,-93.88304f,-73.250496f,-89.398384f,49.11839f,0f,0f ) ;
  }

  @Test
  public void test1195() {
    TestDrivers.surfaceShade(792.0f,0f,0f,0f,3.737329f,-16.372746f,0f,0.0f,0f,0f,0f,0f,0f,-75.338356f,-0.49459016f,100.0f,0f,0f,0f,-281,0.4214443f,0.5223276f,0.3196999f,0.008603803f,0f,0f ) ;
  }

  @Test
  public void test1196() {
    TestDrivers.surfaceShade(-792.0f,0f,0f,0f,78.33935f,-100.0f,0f,-33.50671f,0f,0f,0f,0f,0f,-84.96652f,-100.0f,28.724857f,0f,0f,0f,424,-0.18010963f,0.42408514f,0.8875316f,66.5904f,0f,0f ) ;
  }

  @Test
  public void test1197() {
    TestDrivers.surfaceShade(794.0f,0f,0f,-34.0f,0f,0f,0f,-5.396498f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,83.43688f,0f,0f ) ;
  }

  @Test
  public void test1198() {
    TestDrivers.surfaceShade(797.0f,-2215.0f,908.0f,0f,1.0f,-705.0f,0f,629.0f,0f,0f,0f,0f,0f,963.0f,-535.0f,359.0f,1819.0f,164.0f,-36.0f,214,-0.3839944f,-0.7381422f,-0.069978274f,-38.131023f,-86.52684f,-0.6716677f ) ;
  }

  @Test
  public void test1199() {
    TestDrivers.surfaceShade(797.0f,-258.0f,0f,0f,77.0f,-357.0f,0f,879.0f,0f,0f,0f,0f,0f,746.0f,-893.0f,122.0f,671.0f,-867.0f,-157.0f,464,-27.32732f,-18.483559f,31.806257f,-96.83666f,2.2528813f,0f ) ;
  }

  @Test
  public void test1200() {
    TestDrivers.surfaceShade(799.0f,-107.0f,858.0f,0f,38.0f,-390.0f,0f,-1280.0f,0f,0f,0f,0f,0f,-429.0f,759.0f,928.0f,0f,0f,0f,318,-100.0f,-100.0f,35.560345f,-77.81649f,-99.16799f,43.607655f ) ;
  }

  @Test
  public void test1201() {
    TestDrivers.surfaceShade(802.0f,0f,0f,0f,448.0f,-571.0f,0f,717.0f,0f,0f,0f,0f,0f,178.0f,-228.0f,-30.0f,-4.0f,346.0f,-672.0f,125,-23.575546f,86.35155f,46.75283f,-7.1390452f,0f,0f ) ;
  }

  @Test
  public void test1202() {
    TestDrivers.surfaceShade(806.0f,0f,0f,-974.0f,0f,0f,0f,57.076576f,0f,0f,0f,0f,0f,95.71098f,63.07946f,75.25766f,-729.0f,-598.0f,511.0f,0,0f,0f,0f,80.06529f,0f,0f ) ;
  }

  @Test
  public void test1203() {
    TestDrivers.surfaceShade(-810.0f,-1412.0f,932.0f,-5.0f,0f,0f,0f,-63.602646f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0f,0f,0f,2.4691358E-4f,1.4164306E-4f,50.715363f ) ;
  }

  @Test
  public void test1204() {
    TestDrivers.surfaceShade(810.0f,805.0f,0f,0f,1024.0f,-917.0f,0f,-1133.0f,0f,0f,0f,0f,0f,-452.0f,206.0f,47.0f,0f,0f,0f,492,29.707918f,66.63418f,-6.3545003f,99.858826f,100.0f,0f ) ;
  }

  @Test
  public void test1205() {
    TestDrivers.surfaceShade(814.0f,181.0f,0f,0f,949.0f,0.0f,0f,-493.0f,0f,0f,0f,0f,0f,679.0f,-936.0f,349.0f,0f,0f,0f,-138,12.598239f,26.766033f,-59.852875f,11.771395f,52.236317f,0f ) ;
  }

  @Test
  public void test1206() {
    TestDrivers.surfaceShade(816.0f,-839.0f,0f,0f,748.0f,-687.0f,0f,1434.0f,0f,0f,0f,0f,0f,3.0f,-1156.0f,435.0f,-385.0f,-99.0f,-23.0f,220,59.338936f,92.15167f,85.11228f,-32.221905f,-5.405969f,0f ) ;
  }

  @Test
  public void test1207() {
    TestDrivers.surfaceShade(-822.0f,659.0f,-1527.0f,0f,506.0f,-102.0f,0f,-1.0f,0f,0f,0f,0f,0f,-1563.0f,-537.0f,-583.0f,0f,0f,0f,-870,0.6293239f,-0.15119386f,0.45226735f,-100.0f,-69.17969f,-1.1092851E-9f ) ;
  }

  @Test
  public void test1208() {
    TestDrivers.surfaceShade(-829.0f,-471.0f,-313.0f,0f,15.0f,-273.0f,0f,-903.0f,0f,0f,0f,0f,0f,318.0f,746.0f,862.0f,0f,0f,0f,-730,-61.096046f,-65.53614f,14.692176f,78.235245f,69.71053f,-37.34337f ) ;
  }

  @Test
  public void test1209() {
    TestDrivers.surfaceShade(-830.0f,-20.0f,0f,0f,847.0f,902.0f,0f,-403.0f,0f,0f,0f,0f,0f,741.0f,-183.0f,298.0f,-714.0f,1237.0f,-245.0f,-73,-55.53215f,-71.85496f,89.38233f,-92.60436f,43.98209f,0f ) ;
  }

  @Test
  public void test1210() {
    TestDrivers.surfaceShade(83.0f,0f,0f,0f,427.0f,566.0f,0f,-639.0f,0f,0f,0f,0f,0f,665.0f,305.0f,347.0f,626.0f,302.0f,-1628.0f,39,-26.21982f,-17.485134f,65.617134f,100.0f,0f,0f ) ;
  }

  @Test
  public void test1211() {
    TestDrivers.surfaceShade(-83.0f,-855.0f,337.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,-75.63521f,-67.600525f,-72.20257f,81.71177f,-17.855385f,-100.0f ) ;
  }

  @Test
  public void test1212() {
    TestDrivers.surfaceShade(-831.0f,-3434.0f,-685.0f,0f,1951.0f,-892.0f,0f,-507.0f,0f,0f,0f,0f,0f,-883.0f,-651.0f,625.0f,0f,0f,0f,-1514,0.75750464f,0.023594517f,0.46088958f,100.0f,-88.06336f,-100.0f ) ;
  }

  @Test
  public void test1213() {
    TestDrivers.surfaceShade(-834.0f,990.0f,-593.0f,0f,889.0f,16.0f,0f,997.0f,0f,0f,0f,0f,0f,395.0f,167.0f,-832.0f,-766.0f,528.0f,-119.0f,-879,-100.0f,-7.771298f,100.0f,-100.0f,-100.0f,-100.0f ) ;
  }

  @Test
  public void test1214() {
    TestDrivers.surfaceShade(-837.0f,-99.0f,-74.0f,0f,672.0f,759.0f,0f,-4.0f,0f,0f,0f,0f,0f,210.0f,499.0f,-499.0f,813.0f,120.0f,990.0f,83,-28.437527f,36.786972f,62.495182f,18.753891f,85.769684f,-97.4435f ) ;
  }

  @Test
  public void test1215() {
    TestDrivers.surfaceShade(-839.0f,0f,0f,0f,782.0f,0.0f,0f,950.0f,0f,0f,0f,0f,0f,227.0f,164.0f,610.0f,-360.0f,30.0f,-885.0f,549,18.313541f,82.27851f,-98.19727f,-35.993347f,0f,0f ) ;
  }

  @Test
  public void test1216() {
    TestDrivers.surfaceShade(-841.0f,-2605.0f,22.0f,0f,730.0f,-1025.0f,0f,-424.0f,0f,0f,0f,0f,0f,-957.0f,-1430.0f,1184.0f,0f,0f,0f,-750,-0.24185409f,-0.454101f,-0.74393475f,-100.0f,-4.547605f,100.0f ) ;
  }

  @Test
  public void test1217() {
    TestDrivers.surfaceShade(842.0f,0f,0f,0f,48.01481f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,3.6480145f,-33.413143f,22.65069f,0f,0f,0f,1688,23.70023f,58.03256f,60.18874f,-0.5848592f,0f,0f ) ;
  }

  @Test
  public void test1218() {
    TestDrivers.surfaceShade(842.0f,127.0f,78.0f,4.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-2,85.897736f,80.828964f,-30.723251f,0.031530727f,0.001968504f,-53.382797f ) ;
  }

  @Test
  public void test1219() {
    TestDrivers.surfaceShade(844.0f,-1224.0f,0f,0f,2279.0f,-645.0f,0f,366.0f,0f,0f,0f,0f,0f,-1373.0f,1264.0f,607.0f,-1435.0f,-329.0f,1930.0f,-1272,0.3241304f,-0.31802303f,-0.07470659f,-49.286068f,-22.766287f,0f ) ;
  }

  @Test
  public void test1220() {
    TestDrivers.surfaceShade(-850.0f,243.0f,0f,0f,207.0f,906.0f,0f,-2428.0f,0f,0f,0f,0f,0f,-291.0f,-707.0f,-298.0f,526.0f,-132.0f,-727.0f,2292,-1.4985523f,0.68081623f,-0.15186551f,-79.12265f,6.059012f,0f ) ;
  }

  @Test
  public void test1221() {
    TestDrivers.surfaceShade(-85.0f,-640.0f,0f,11.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,79.17358f,53.874916f,-100.0f,-0.0010695187f,-1.4204545E-4f,0f ) ;
  }

  @Test
  public void test1222() {
    TestDrivers.surfaceShade(-856.0f,-233.0f,0f,0f,294.0f,-2674.0f,0f,426.0f,0f,0f,0f,0f,0f,-1375.0f,-1797.0f,1012.0f,860.0f,-494.0f,332.0f,-74,0.32961416f,0.70816684f,0.29111305f,-18.377275f,52.917206f,0f ) ;
  }

  @Test
  public void test1223() {
    TestDrivers.surfaceShade(859.0f,0f,0f,0f,-638.0f,79.0f,841.0f,662.0f,0f,0f,0f,0f,0f,890.0f,289.0f,-895.0f,228.0f,-777.0f,366.0f,246,22.603834f,-88.03491f,35.58112f,14.936487f,0f,0f ) ;
  }

  @Test
  public void test1224() {
    TestDrivers.surfaceShade(864.0f,-788.0f,0f,0f,589.0f,934.0f,-3084.0f,-727.0f,0f,0f,0f,0f,0f,-1146.0f,1023.0f,880.0f,-511.0f,-44.0f,24.0f,-535,-0.11649979f,-0.03488847f,-0.9721419f,99.31047f,38.537525f,0f ) ;
  }

  @Test
  public void test1225() {
    TestDrivers.surfaceShade(-866.0f,191.0f,896.0f,0f,387.0f,472.0f,0f,965.0f,0f,0f,0f,0f,0f,-897.0f,392.0f,846.0f,196.0f,854.0f,-399.0f,18,86.86331f,53.27416f,40.61809f,-15.76973f,58.9296f,-36.76469f ) ;
  }

  @Test
  public void test1226() {
    TestDrivers.surfaceShade(868.0f,-1030.0f,-740.0f,367.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,42.5979f,-15.904291f,100.0f,-52.013832f,18.212635f,-3.6821564E-6f ) ;
  }

  @Test
  public void test1227() {
    TestDrivers.surfaceShade(-870.0f,-1102.0f,437.0f,0f,1692.0f,40.0f,0f,-1195.0f,0f,0f,0f,0f,0f,-476.0f,-441.0f,973.0f,957.0f,-1870.0f,-479.0f,146,-0.58122504f,-0.4121388f,-0.55936205f,100.0f,-56.885788f,-65.461464f ) ;
  }

  @Test
  public void test1228() {
    TestDrivers.surfaceShade(-87.0f,0f,0f,0f,647.0f,-410.0f,0f,406.0f,0f,0f,0f,0f,0f,938.0f,176.0f,793.0f,419.0f,32.0f,-255.0f,-90,-28.468058f,12.866544f,-45.35164f,-28.57701f,0f,0f ) ;
  }

  @Test
  public void test1229() {
    TestDrivers.surfaceShade(873.0f,-83.0f,46.0f,0f,522.0f,-772.0f,0f,371.0f,0f,0f,0f,0f,0f,-985.0f,647.0f,410.0f,-106.0f,-672.0f,706.0f,-1523,36.711475f,-1.8209711f,91.07066f,-34.792103f,-47.35113f,29.851835f ) ;
  }

  @Test
  public void test1230() {
    TestDrivers.surfaceShade(-875.0f,-47.0f,6.0f,-344.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-5,-7.025514f,-100.0f,100.0f,-100.0f,6.1850566E-5f,-4.8449612E-4f ) ;
  }

  @Test
  public void test1231() {
    TestDrivers.surfaceShade(-879.0f,715.0f,-937.0f,0f,1262.0f,1121.0f,0f,-911.0f,0f,0f,0f,0f,0f,387.0f,851.0f,-329.0f,480.0f,-222.0f,-816.0f,535,-92.948074f,50.295887f,20.762596f,-7.9507785f,100.0f,-8.13196f ) ;
  }

  @Test
  public void test1232() {
    TestDrivers.surfaceShade(-885.0f,-817.0f,-139.0f,-201.0f,0f,0f,0f,-7.572654f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,5.6216095E-6f,100.0f,-14.804987f ) ;
  }

  @Test
  public void test1233() {
    TestDrivers.surfaceShade(886.0f,365.0f,-170.0f,0f,160.0f,915.0f,-1289.0f,984.0f,0f,0f,0f,0f,0f,927.0f,-1239.0f,-707.0f,-539.0f,-1292.0f,1371.0f,699,-0.42115688f,0.026065886f,0.7892938f,100.0f,100.0f,-66.75547f ) ;
  }

  @Test
  public void test1234() {
    TestDrivers.surfaceShade(-887.0f,0f,0f,0f,545.0f,464.0f,0f,-1968.0f,0f,0f,0f,0f,0f,-677.0f,155.0f,-86.0f,438.0f,-300.0f,565.0f,-749,0.29932112f,-0.1883276f,-0.891507f,2.1572643E-5f,0f,0f ) ;
  }

  @Test
  public void test1235() {
    TestDrivers.surfaceShade(891.0f,-23.0f,1596.0f,0f,8.0f,1315.0f,0f,893.0f,0f,0f,0f,0f,0f,1963.0f,752.0f,-255.0f,-456.0f,-709.0f,856.0f,-1153,-0.3987301f,0.17006853f,-1.0592469f,-100.0f,-2.2550201f,-100.0f ) ;
  }

  @Test
  public void test1236() {
    TestDrivers.surfaceShade(892.0f,983.0f,0f,0f,1171.0f,-3.0f,0f,-2164.0f,0f,0f,0f,0f,0f,-182.0f,820.0f,-540.0f,0f,0f,0f,973,0.44416773f,0.15629588f,0.5528261f,-69.87898f,-100.0f,0f ) ;
  }

  @Test
  public void test1237() {
    TestDrivers.surfaceShade(900.0f,-430.0f,0f,-241.0f,0f,0f,0f,-1.1698232f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,15.950144f,1.7146189E-5f,0f ) ;
  }

  @Test
  public void test1238() {
    TestDrivers.surfaceShade(90.0f,0f,0f,0f,4.14805f,-22.560776f,0f,-159.74852f,0f,0f,0f,0f,0f,100.0f,189.50555f,25.317255f,0f,0f,0f,4,-0.55818933f,-0.3980582f,5.3204923f,-0.25989753f,0f,0f ) ;
  }

  @Test
  public void test1239() {
    TestDrivers.surfaceShade(-90.0f,-151.0f,823.0f,-231.0f,0f,0f,0f,-45.089447f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,-9.254041f,87.465004f,100.0f ) ;
  }

  @Test
  public void test1240() {
    TestDrivers.surfaceShade(903.0f,-357.0f,-416.0f,0f,20.0f,-1085.0f,0f,16.0f,0f,0f,0f,0f,0f,-915.0f,1636.0f,-509.0f,27.0f,721.0f,320.0f,-99,-27.950758f,-46.892567f,-100.0f,-90.27765f,-93.28118f,-4.6685352E-7f ) ;
  }

  @Test
  public void test1241() {
    TestDrivers.surfaceShade(9.0f,265.0f,215.0f,29.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,32.829395f,14.441133f,29.587069f,0.0038314175f,1.3012362E-4f,-100.0f ) ;
  }

  @Test
  public void test1242() {
    TestDrivers.surfaceShade(913.0f,0f,0f,0f,1.8997073E-7f,-100.0f,0f,-72.87045f,0f,0f,0f,0f,0f,-100.0f,100.0f,-99.9909f,0f,0f,0f,-1240,0.072324075f,-0.8775437f,-0.16989845f,73.91905f,0f,0f ) ;
  }

  @Test
  public void test1243() {
    TestDrivers.surfaceShade(915.0f,-1340.0f,0f,0f,671.0f,-1.0f,0f,-2.0f,0f,0f,0f,0f,0f,-617.0f,339.0f,551.0f,0f,0f,0f,-1318,-1.1088768f,0.71464974f,-1.6813853f,81.827324f,-17.318377f,0f ) ;
  }

  @Test
  public void test1244() {
    TestDrivers.surfaceShade(-918.0f,0f,0f,0f,748.0f,305.0f,0f,-3359.0f,0f,0f,0f,0f,0f,830.0f,-1265.0f,851.0f,637.0f,1458.0f,17.0f,-1874,-0.042798527f,-0.077215604f,-0.99609536f,-2.7087674E-9f,0f,0f ) ;
  }

  @Test
  public void test1245() {
    TestDrivers.surfaceShade(-919.0f,372.0f,0f,0f,3.0f,-197.0f,0f,1311.0f,0f,0f,0f,0f,0f,857.0f,989.0f,-84.0f,-1460.0f,951.0f,171.0f,898,0.24356307f,-0.21844023f,-0.046159483f,-28.319141f,-3.7810984f,0f ) ;
  }

  @Test
  public void test1246() {
    TestDrivers.surfaceShade(-926.0f,-131.0f,974.0f,-24.0f,0f,0f,0f,1.1749036E-12f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,4.49964E-5f,3.1806616E-4f,7.9533434E-5f ) ;
  }

  @Test
  public void test1247() {
    TestDrivers.surfaceShade(940.0f,858.0f,-1149.0f,0f,92.0f,-1193.0f,0f,1284.0f,0f,0f,0f,0f,0f,-981.0f,-1610.0f,423.0f,-367.0f,2549.0f,-1066.0f,-1220,0.8863731f,-0.26264915f,0.23328418f,-93.74953f,-52.932526f,6.4717007f ) ;
  }

  @Test
  public void test1248() {
    TestDrivers.surfaceShade(-949.0f,0f,0f,0f,578.0f,933.0f,0f,-425.0f,0f,0f,0f,0f,0f,132.0f,809.0f,-554.0f,-651.0f,-426.0f,411.0f,-23,-99.54208f,-61.087425f,6.9585915f,20.721668f,0f,0f ) ;
  }

  @Test
  public void test1249() {
    TestDrivers.surfaceShade(95.0f,2003.0f,-247.0f,0f,351.0f,1.0f,0f,-758.0f,0f,0f,0f,0f,0f,-496.0f,-537.0f,622.0f,0f,0f,0f,208,-65.03104f,65.0883f,4.336049f,100.0f,32.509186f,-14.11366f ) ;
  }

  @Test
  public void test1250() {
    TestDrivers.surfaceShade(-954.0f,-910.0f,-212.0f,0f,36.0f,867.0f,0f,-536.0f,0f,0f,0f,0f,0f,33.0f,286.0f,931.0f,-786.0f,-633.0f,-843.0f,-1108,0.03332974f,-0.15107691f,0.045228884f,39.771328f,-98.76115f,-5.4572716f ) ;
  }

  @Test
  public void test1251() {
    TestDrivers.surfaceShade(958.0f,0f,0f,0f,-628.0f,-510.0f,165.0f,-961.0f,0f,0f,0f,0f,0f,-255.0f,954.0f,519.0f,-98.0f,978.0f,-81.0f,-882,-89.57628f,-23.092028f,-70.143364f,38.191555f,0f,0f ) ;
  }

  @Test
  public void test1252() {
    TestDrivers.surfaceShade(-959.0f,0f,0f,0f,333.0f,849.0f,-302.0f,537.0f,0f,0f,0f,0f,0f,927.0f,987.0f,-955.0f,-953.0f,924.0f,-1428.0f,-912,0.3066421f,-0.15045589f,0.9147396f,1.5178205f,0f,0f ) ;
  }

  @Test
  public void test1253() {
    TestDrivers.surfaceShade(959.0f,-1183.0f,0f,0f,96.0f,854.0f,2407.0f,1067.0f,0f,0f,0f,0f,0f,1141.0f,221.0f,455.0f,-96.0f,-267.0f,1411.0f,-203,-0.67728764f,-0.49122357f,0.4276382f,-69.44845f,-79.41821f,0f ) ;
  }

  @Test
  public void test1254() {
    TestDrivers.surfaceShade(-968.0f,-1148.0f,-196.0f,0f,820.0f,729.0f,0f,-986.0f,0f,0f,0f,0f,0f,-636.0f,-47.0f,954.0f,957.0f,379.0f,804.0f,1831,-76.95176f,-65.43216f,-54.52477f,-24.30695f,-67.03777f,-59.171417f ) ;
  }

  @Test
  public void test1255() {
    TestDrivers.surfaceShade(-968.0f,81.0f,383.0f,0f,53.0f,29.0f,0f,56.0f,0f,0f,0f,0f,0f,-969.0f,390.0f,-51.0f,-339.0f,-1220.0f,-201.0f,-650,0.13584442f,-0.31016105f,0.30245417f,23.218336f,48.961628f,21.577347f ) ;
  }

  @Test
  public void test1256() {
    TestDrivers.surfaceShade(97.0f,0f,0f,0f,95.0447f,0.0f,0f,-6.938894E-18f,0f,0f,0f,0f,0f,-25.389599f,-2.1469622f,-21.81941f,0f,0f,0f,8,6.366823f,-2.0944517f,4.584958f,31.911415f,0f,0f ) ;
  }

  @Test
  public void test1257() {
    TestDrivers.surfaceShade(97.0f,-231.0f,307.0f,0f,669.0f,-1503.0f,0f,1624.0f,0f,0f,0f,0f,0f,-1325.0f,1480.0f,383.0f,-1059.0f,-324.0f,-730.0f,-544,0.67238665f,-0.18077804f,0.012839254f,-100.0f,-22.557884f,13.09124f ) ;
  }

  @Test
  public void test1258() {
    TestDrivers.surfaceShade(-972.0f,13.0f,-141.0f,1.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-5.656109E-4f,0.16155936f,-0.0035460992f ) ;
  }

  @Test
  public void test1259() {
    TestDrivers.surfaceShade(-972.0f,783.0f,-790.0f,0f,698.0f,-402.0f,0f,-683.0f,0f,0f,0f,0f,0f,-29.0f,-41.0f,-113.0f,0f,0f,0f,135,97.79868f,71.99384f,77.71349f,-69.35775f,-64.297844f,-57.644238f ) ;
  }

  @Test
  public void test1260() {
    TestDrivers.surfaceShade(974.0f,-379.0f,-11.0f,-152.0f,0f,0f,0f,-35.751926f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-73.839935f,45.38687f,5.980861E-4f ) ;
  }

  @Test
  public void test1261() {
    TestDrivers.surfaceShade(978.0f,362.0f,0f,0f,55.0f,529.0f,0f,134.0f,0f,0f,0f,0f,0f,-454.0f,253.0f,-533.0f,100.0f,-90.0f,960.0f,410,84.66761f,58.08916f,-44.545097f,31.994495f,59.842987f,0f ) ;
  }

  @Test
  public void test1262() {
    TestDrivers.surfaceShade(-982.0f,0f,0f,0f,87.356255f,0.0f,0f,-25.432104f,0f,0f,0f,0f,0f,-7.035638f,-5.2689776f,-8.664421f,0f,0f,0f,541,6.96197f,-22.997833f,8.33214f,-25.612331f,0f,0f ) ;
  }

  @Test
  public void test1263() {
    TestDrivers.surfaceShade(-986.0f,-212.0f,0.0f,-101.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-37.754f,-68.51812f,85.91997f,2.4601467f,-9.707805f,12.616114f ) ;
  }

  @Test
  public void test1264() {
    TestDrivers.surfaceShade(990.0f,945.0f,788.0f,0f,713.0f,-874.0f,0f,-1229.0f,0f,0f,0f,0f,0f,-151.0f,702.0f,-1570.0f,0f,0f,0f,2694,0.43518358f,0.7571067f,0.4425272f,-46.9594f,-100.0f,-100.0f ) ;
  }

  @Test
  public void test1265() {
    TestDrivers.surfaceShade(993.0f,206.0f,-636.0f,0f,938.0f,841.0f,0f,533.0f,0f,0f,0f,0f,0f,-672.0f,-596.0f,163.0f,106.0f,172.0f,903.0f,-608,-0.44894147f,0.49429956f,-0.052489795f,-100.0f,40.821526f,23.634592f ) ;
  }

  @Test
  public void test1266() {
    TestDrivers.surfaceShade(999.0f,0f,0f,-62.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,62.607605f,145.7924f,162.01698f,-33.543095f,0f,0f ) ;
  }

  @Test
  public void test1267() {
    TestDrivers.surfaceShade(-999.0f,5.0f,0f,498.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-67.37702f,4.0160643E-4f,0f ) ;
  }
}
