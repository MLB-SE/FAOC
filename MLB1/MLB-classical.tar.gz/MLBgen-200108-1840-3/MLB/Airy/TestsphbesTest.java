import org.junit.Test;

public class TestsphbesTest {

  @Test
  public void test0() {
    airy.sphbes(0,105.57088247322247 ) ;
  }

  @Test
  public void test1() {
    airy.sphbes(0,125.33667319667018 ) ;
  }

  @Test
  public void test2() {
    airy.sphbes(0,99.16243113098076 ) ;
  }

  @Test
  public void test3() {
    airy.sphbes(1000,1.9721522630525295E-31 ) ;
  }

  @Test
  public void test4() {
    airy.sphbes(117,-4.4E-323 ) ;
  }

  @Test
  public void test5() {
    airy.sphbes(-1,39.67180824267976 ) ;
  }

  @Test
  public void test6() {
    airy.sphbes(-1467,0.0 ) ;
  }

  @Test
  public void test7() {
    airy.sphbes(1585,-4.0E-323 ) ;
  }

  @Test
  public void test8() {
    airy.sphbes(-162,-39.76301287334159 ) ;
  }

  @Test
  public void test9() {
    airy.sphbes(180,57.841180263525246 ) ;
  }

  @Test
  public void test10() {
    airy.sphbes(195,0 ) ;
  }

  @Test
  public void test11() {
    airy.sphbes(-213,38.7704997305207 ) ;
  }

  @Test
  public void test12() {
    airy.sphbes(27,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test13() {
    airy.sphbes(3010,2.0000000000000253 ) ;
  }

  @Test
  public void test14() {
    airy.sphbes(-31,0 ) ;
  }

  @Test
  public void test15() {
    airy.sphbes(32,1.0E-323 ) ;
  }

  @Test
  public void test16() {
    airy.sphbes(321,-22.30917094003803 ) ;
  }

  @Test
  public void test17() {
    airy.sphbes(427,2.00000000000004 ) ;
  }

  @Test
  public void test18() {
    airy.sphbes(446,0.0 ) ;
  }

  @Test
  public void test19() {
    airy.sphbes(-463,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test20() {
    airy.sphbes(-491,4.440892098500626E-16 ) ;
  }

  @Test
  public void test21() {
    airy.sphbes(499,61.96665727208094 ) ;
  }

  @Test
  public void test22() {
    airy.sphbes(-500,45.37353447918247 ) ;
  }

  @Test
  public void test23() {
    airy.sphbes(-51,1.6156390176583342 ) ;
  }

  @Test
  public void test24() {
    airy.sphbes(52,0.0 ) ;
  }

  @Test
  public void test25() {
    airy.sphbes(-574,0.0 ) ;
  }

  @Test
  public void test26() {
    airy.sphbes(-597,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test27() {
    airy.sphbes(619,0.0 ) ;
  }

  @Test
  public void test28() {
    airy.sphbes(-652,-69.05269187607925 ) ;
  }

  @Test
  public void test29() {
    airy.sphbes(671,-88.9400863975215 ) ;
  }

  @Test
  public void test30() {
    airy.sphbes(-731,2.0000000000000004 ) ;
  }

  @Test
  public void test31() {
    airy.sphbes(-751,2.0 ) ;
  }

  @Test
  public void test32() {
    airy.sphbes(751,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test33() {
    airy.sphbes(754,1.265E-321 ) ;
  }

  @Test
  public void test34() {
    airy.sphbes(-754,17.30580850902001 ) ;
  }

  @Test
  public void test35() {
    airy.sphbes(816,-8.76843124916924 ) ;
  }

  @Test
  public void test36() {
    airy.sphbes(868,0.0 ) ;
  }

  @Test
  public void test37() {
    airy.sphbes(947,89.68036818081379 ) ;
  }
}
