import org.junit.Test;

public class TestAiryTest {

  @Test
  public void test0() {
    airy.main_airy(1.1551138543459416 ) ;
  }

  @Test
  public void test1() {
    airy.main_airy(-1.232595164407831E-32 ) ;
  }

  @Test
  public void test2() {
    airy.main_airy(1.752422998389406 ) ;
  }

  @Test
  public void test3() {
    airy.main_airy(17.620331664581542 ) ;
  }

  @Test
  public void test4() {
    airy.main_airy(1.7763568394002505E-15 ) ;
  }

  @Test
  public void test5() {
    airy.main_airy(-19.640835708766204 ) ;
  }

  @Test
  public void test6() {
    airy.main_airy(-2.465190328815662E-32 ) ;
  }

  @Test
  public void test7() {
    airy.main_airy(2.465190328815662E-32 ) ;
  }

  @Test
  public void test8() {
    airy.main_airy(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test9() {
    airy.main_airy(-45.73830212751846 ) ;
  }

  @Test
  public void test10() {
    airy.main_airy(63.86569411124182 ) ;
  }

  @Test
  public void test11() {
    airy.main_airy(-66.2090326719335 ) ;
  }

  @Test
  public void test12() {
    airy.main_airy(-74.28396205212171 ) ;
  }

  @Test
  public void test13() {
    airy.main_airy(80.98368807014887 ) ;
  }

  @Test
  public void test14() {
    airy.main_airy(-84.78782862254228 ) ;
  }

  @Test
  public void test15() {
    airy.main_airy(-8.645163535653227E-224 ) ;
  }

  @Test
  public void test16() {
    airy.main_airy(8.645163535653227E-224 ) ;
  }
}
