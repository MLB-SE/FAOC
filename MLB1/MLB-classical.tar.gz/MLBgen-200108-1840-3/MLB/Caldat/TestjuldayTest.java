import org.junit.Test;

public class TestjuldayTest {

  @Test
  public void test0() {
    caldat.julday(0,0,0 ) ;
  }

  @Test
  public void test1() {
    caldat.julday(0,0,-1 ) ;
  }

  @Test
  public void test2() {
    caldat.julday(0,0,410 ) ;
  }

  @Test
  public void test3() {
    caldat.julday(0,0,-745 ) ;
  }

  @Test
  public void test4() {
    caldat.julday(0,0,802 ) ;
  }

  @Test
  public void test5() {
    caldat.julday(0,20742,-1 ) ;
  }

  @Test
  public void test6() {
    caldat.julday(0,-440,1670 ) ;
  }

  @Test
  public void test7() {
    caldat.julday(0,784,0 ) ;
  }

  @Test
  public void test8() {
    caldat.julday(-10,0,442 ) ;
  }

  @Test
  public void test9() {
    caldat.julday(-10,0,-932 ) ;
  }

  @Test
  public void test10() {
    caldat.julday(-10,21310,1 ) ;
  }

  @Test
  public void test11() {
    caldat.julday(1,0,-964 ) ;
  }

  @Test
  public void test12() {
    caldat.julday(-114,0,1 ) ;
  }

  @Test
  public void test13() {
    caldat.julday(-114,571,2145 ) ;
  }

  @Test
  public void test14() {
    caldat.julday(-119,0,397 ) ;
  }

  @Test
  public void test15() {
    caldat.julday(-120,0,234 ) ;
  }

  @Test
  public void test16() {
    caldat.julday(1,21167,-4 ) ;
  }

  @Test
  public void test17() {
    caldat.julday(-12,259,655 ) ;
  }

  @Test
  public void test18() {
    caldat.julday(-12,434,1665 ) ;
  }

  @Test
  public void test19() {
    caldat.julday(-13,0,0 ) ;
  }

  @Test
  public void test20() {
    caldat.julday(-13,0,-1324 ) ;
  }

  @Test
  public void test21() {
    caldat.julday(-13,0,1501 ) ;
  }

  @Test
  public void test22() {
    caldat.julday(-13,0,602 ) ;
  }

  @Test
  public void test23() {
    caldat.julday(-13,0,-899 ) ;
  }

  @Test
  public void test24() {
    caldat.julday(-13,1021,1809 ) ;
  }

  @Test
  public void test25() {
    caldat.julday(-13,14,1706 ) ;
  }

  @Test
  public void test26() {
    caldat.julday(-13,-1570,0 ) ;
  }

  @Test
  public void test27() {
    caldat.julday(-13,16844,-2 ) ;
  }

  @Test
  public void test28() {
    caldat.julday(-13,-172,-876 ) ;
  }

  @Test
  public void test29() {
    caldat.julday(-13,-3,-385 ) ;
  }

  @Test
  public void test30() {
    caldat.julday(-13,671,520 ) ;
  }

  @Test
  public void test31() {
    caldat.julday(-13,-834,1213 ) ;
  }

  @Test
  public void test32() {
    caldat.julday(-14,21095,-1 ) ;
  }

  @Test
  public void test33() {
    caldat.julday(-168,0,456 ) ;
  }

  @Test
  public void test34() {
    caldat.julday(-18,0,0 ) ;
  }

  @Test
  public void test35() {
    caldat.julday(-18,15226,-20 ) ;
  }

  @Test
  public void test36() {
    caldat.julday(-18,18901,1 ) ;
  }

  @Test
  public void test37() {
    caldat.julday(18,-739,-136 ) ;
  }

  @Test
  public void test38() {
    caldat.julday(19307,-802,2 ) ;
  }

  @Test
  public void test39() {
    caldat.julday(19745,-654,-54 ) ;
  }

  @Test
  public void test40() {
    caldat.julday(-2,0,0 ) ;
  }

  @Test
  public void test41() {
    caldat.julday(-2,0,19 ) ;
  }

  @Test
  public void test42() {
    caldat.julday(-2,0,-221 ) ;
  }

  @Test
  public void test43() {
    caldat.julday(20485,691,-61 ) ;
  }

  @Test
  public void test44() {
    caldat.julday(-2,0,796 ) ;
  }

  @Test
  public void test45() {
    caldat.julday(-2,0,-86 ) ;
  }

  @Test
  public void test46() {
    caldat.julday(227,-678,657 ) ;
  }

  @Test
  public void test47() {
    caldat.julday(241,0,350 ) ;
  }

  @Test
  public void test48() {
    caldat.julday(272,0,0 ) ;
  }

  @Test
  public void test49() {
    caldat.julday(284,0,-759 ) ;
  }

  @Test
  public void test50() {
    caldat.julday(-3,21390,1 ) ;
  }

  @Test
  public void test51() {
    caldat.julday(-332,686,2414 ) ;
  }

  @Test
  public void test52() {
    caldat.julday(-3,-331,-559 ) ;
  }

  @Test
  public void test53() {
    caldat.julday(-38,19509,-4 ) ;
  }

  @Test
  public void test54() {
    caldat.julday(384,0,-705 ) ;
  }

  @Test
  public void test55() {
    caldat.julday(394,-484,-873 ) ;
  }

  @Test
  public void test56() {
    caldat.julday(4,0,0 ) ;
  }

  @Test
  public void test57() {
    caldat.julday(4,0,1517 ) ;
  }

  @Test
  public void test58() {
    caldat.julday(4,0,-809 ) ;
  }

  @Test
  public void test59() {
    caldat.julday(4,0,908 ) ;
  }

  @Test
  public void test60() {
    caldat.julday(4,0,-966 ) ;
  }

  @Test
  public void test61() {
    caldat.julday(-415,0,0 ) ;
  }

  @Test
  public void test62() {
    caldat.julday(-4,-2054,-712 ) ;
  }

  @Test
  public void test63() {
    caldat.julday(428,0,308 ) ;
  }

  @Test
  public void test64() {
    caldat.julday(-432,0,2 ) ;
  }

  @Test
  public void test65() {
    caldat.julday(-4,-41,837 ) ;
  }

  @Test
  public void test66() {
    caldat.julday(-444,0,1 ) ;
  }

  @Test
  public void test67() {
    caldat.julday(457,0,396 ) ;
  }

  @Test
  public void test68() {
    caldat.julday(512,168,1560 ) ;
  }

  @Test
  public void test69() {
    caldat.julday(-517,0,0 ) ;
  }

  @Test
  public void test70() {
    caldat.julday(-518,0,333 ) ;
  }

  @Test
  public void test71() {
    caldat.julday(-521,309,-11 ) ;
  }

  @Test
  public void test72() {
    caldat.julday(524,0,-1 ) ;
  }

  @Test
  public void test73() {
    caldat.julday(557,-179,1618 ) ;
  }

  @Test
  public void test74() {
    caldat.julday(-602,0,-92 ) ;
  }

  @Test
  public void test75() {
    caldat.julday(-665,0,-760 ) ;
  }

  @Test
  public void test76() {
    caldat.julday(-686,14,877 ) ;
  }

  @Test
  public void test77() {
    caldat.julday(-688,0,-221 ) ;
  }

  @Test
  public void test78() {
    caldat.julday(-7,0,0 ) ;
  }

  @Test
  public void test79() {
    caldat.julday(-7,0,429 ) ;
  }

  @Test
  public void test80() {
    caldat.julday(708,0,39 ) ;
  }

  @Test
  public void test81() {
    caldat.julday(-712,0,-519 ) ;
  }

  @Test
  public void test82() {
    caldat.julday(742,0,0 ) ;
  }

  @Test
  public void test83() {
    caldat.julday(-744,0,616 ) ;
  }

  @Test
  public void test84() {
    caldat.julday(760,-117,0 ) ;
  }

  @Test
  public void test85() {
    caldat.julday(-768,838,-340 ) ;
  }

  @Test
  public void test86() {
    caldat.julday(-773,328,0 ) ;
  }

  @Test
  public void test87() {
    caldat.julday(-8,0,-993 ) ;
  }

  @Test
  public void test88() {
    caldat.julday(817,0,-817 ) ;
  }

  @Test
  public void test89() {
    caldat.julday(836,0,-698 ) ;
  }

  @Test
  public void test90() {
    caldat.julday(843,0,103 ) ;
  }

  @Test
  public void test91() {
    caldat.julday(-845,-8,94 ) ;
  }

  @Test
  public void test92() {
    caldat.julday(858,0,1 ) ;
  }

  @Test
  public void test93() {
    caldat.julday(874,-324,616 ) ;
  }

  @Test
  public void test94() {
    caldat.julday(905,0,1 ) ;
  }

  @Test
  public void test95() {
    caldat.julday(-939,0,-1 ) ;
  }

  @Test
  public void test96() {
    caldat.julday(952,0,0 ) ;
  }

  @Test
  public void test97() {
    caldat.julday(976,0,-1 ) ;
  }

  @Test
  public void test98() {
    caldat.julday(982,0,-440 ) ;
  }
}
