import org.junit.Test;

public class TestflmoonTest {

  @Test
  public void test0() {
    caldat.flmoon(0,0 ) ;
  }

  @Test
  public void test1() {
    caldat.flmoon(0,1 ) ;
  }

  @Test
  public void test2() {
    caldat.flmoon(0,181 ) ;
  }

  @Test
  public void test3() {
    caldat.flmoon(0,2 ) ;
  }

  @Test
  public void test4() {
    caldat.flmoon(0,3 ) ;
  }

  @Test
  public void test5() {
    caldat.flmoon(0,-71 ) ;
  }

  @Test
  public void test6() {
    caldat.flmoon(0,-722 ) ;
  }

  @Test
  public void test7() {
    caldat.flmoon(0,-910 ) ;
  }

  @Test
  public void test8() {
    caldat.flmoon(-1,0 ) ;
  }

  @Test
  public void test9() {
    caldat.flmoon(108,1 ) ;
  }

  @Test
  public void test10() {
    caldat.flmoon(-1,1 ) ;
  }

  @Test
  public void test11() {
    caldat.flmoon(1,1 ) ;
  }

  @Test
  public void test12() {
    caldat.flmoon(-110,-623 ) ;
  }

  @Test
  public void test13() {
    caldat.flmoon(-118,0 ) ;
  }

  @Test
  public void test14() {
    caldat.flmoon(-1,2 ) ;
  }

  @Test
  public void test15() {
    caldat.flmoon(-1257,1 ) ;
  }

  @Test
  public void test16() {
    caldat.flmoon(-1,3 ) ;
  }

  @Test
  public void test17() {
    caldat.flmoon(-1453,0 ) ;
  }

  @Test
  public void test18() {
    caldat.flmoon(1490,5 ) ;
  }

  @Test
  public void test19() {
    caldat.flmoon(-1617,-4 ) ;
  }

  @Test
  public void test20() {
    caldat.flmoon(191,-763 ) ;
  }

  @Test
  public void test21() {
    caldat.flmoon(-20,78 ) ;
  }

  @Test
  public void test22() {
    caldat.flmoon(-2,3 ) ;
  }

  @Test
  public void test23() {
    caldat.flmoon(242,-385 ) ;
  }

  @Test
  public void test24() {
    caldat.flmoon(245,-982 ) ;
  }

  @Test
  public void test25() {
    caldat.flmoon(252,3 ) ;
  }

  @Test
  public void test26() {
    caldat.flmoon(292,0 ) ;
  }

  @Test
  public void test27() {
    caldat.flmoon(323,1 ) ;
  }

  @Test
  public void test28() {
    caldat.flmoon(-34,-4 ) ;
  }

  @Test
  public void test29() {
    caldat.flmoon(-356,2 ) ;
  }

  @Test
  public void test30() {
    caldat.flmoon(399,0 ) ;
  }

  @Test
  public void test31() {
    caldat.flmoon(414,14 ) ;
  }

  @Test
  public void test32() {
    caldat.flmoon(-423,1 ) ;
  }

  @Test
  public void test33() {
    caldat.flmoon(428,-2 ) ;
  }

  @Test
  public void test34() {
    caldat.flmoon(-478,1 ) ;
  }

  @Test
  public void test35() {
    caldat.flmoon(-510,25 ) ;
  }

  @Test
  public void test36() {
    caldat.flmoon(-538,-313 ) ;
  }

  @Test
  public void test37() {
    caldat.flmoon(575,-24 ) ;
  }

  @Test
  public void test38() {
    caldat.flmoon(607,2 ) ;
  }

  @Test
  public void test39() {
    caldat.flmoon(-668,3 ) ;
  }

  @Test
  public void test40() {
    caldat.flmoon(-677,-2181 ) ;
  }

  @Test
  public void test41() {
    caldat.flmoon(692,358 ) ;
  }

  @Test
  public void test42() {
    caldat.flmoon(-708,2 ) ;
  }

  @Test
  public void test43() {
    caldat.flmoon(74,3 ) ;
  }

  @Test
  public void test44() {
    caldat.flmoon(827,2 ) ;
  }

  @Test
  public void test45() {
    caldat.flmoon(967,152 ) ;
  }

  @Test
  public void test46() {
    caldat.flmoon(-982,3 ) ;
  }
}
