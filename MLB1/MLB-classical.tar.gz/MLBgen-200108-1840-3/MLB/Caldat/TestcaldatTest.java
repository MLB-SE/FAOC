import org.junit.Test;

public class TestcaldatTest {

  @Test
  public void test0() {
    caldat.caldat(0 ) ;
  }

  @Test
  public void test1() {
    caldat.caldat(-1 ) ;
  }

  @Test
  public void test2() {
    caldat.caldat(11813 ) ;
  }

  @Test
  public void test3() {
    caldat.caldat(200 ) ;
  }

  @Test
  public void test4() {
    caldat.caldat(26229 ) ;
  }

  @Test
  public void test5() {
    caldat.caldat(-276 ) ;
  }

  @Test
  public void test6() {
    caldat.caldat(-277 ) ;
  }

  @Test
  public void test7() {
    caldat.caldat(-315 ) ;
  }

  @Test
  public void test8() {
    caldat.caldat(-323 ) ;
  }

  @Test
  public void test9() {
    caldat.caldat(-331 ) ;
  }

  @Test
  public void test10() {
    caldat.caldat(-337 ) ;
  }

  @Test
  public void test11() {
    caldat.caldat(-342 ) ;
  }

  @Test
  public void test12() {
    caldat.caldat(362 ) ;
  }

  @Test
  public void test13() {
    caldat.caldat(-39 ) ;
  }

  @Test
  public void test14() {
    caldat.caldat(392 ) ;
  }

  @Test
  public void test15() {
    caldat.caldat(-407 ) ;
  }

  @Test
  public void test16() {
    caldat.caldat(409 ) ;
  }

  @Test
  public void test17() {
    caldat.caldat(4398 ) ;
  }

  @Test
  public void test18() {
    caldat.caldat(53 ) ;
  }

  @Test
  public void test19() {
    caldat.caldat(-648 ) ;
  }

  @Test
  public void test20() {
    caldat.caldat(658 ) ;
  }

  @Test
  public void test21() {
    caldat.caldat(684 ) ;
  }

  @Test
  public void test22() {
    caldat.caldat(-697 ) ;
  }

  @Test
  public void test23() {
    caldat.caldat(-708 ) ;
  }

  @Test
  public void test24() {
    caldat.caldat(758 ) ;
  }

  @Test
  public void test25() {
    caldat.caldat(781 ) ;
  }

  @Test
  public void test26() {
    caldat.caldat(83 ) ;
  }

  @Test
  public void test27() {
    caldat.caldat(-877 ) ;
  }

  @Test
  public void test28() {
    caldat.caldat(93 ) ;
  }

  @Test
  public void test29() {
    caldat.caldat(-996 ) ;
  }
}
