import org.junit.Test;

public class TestStatCalcTest {

  @Test
  public void test0() {
    concolic.TestStatCalc.run(-102 ) ;
  }

  @Test
  public void test1() {
    concolic.TestStatCalc.run(-255 ) ;
  }

  @Test
  public void test2() {
    concolic.TestStatCalc.run(257 ) ;
  }

  @Test
  public void test3() {
    concolic.TestStatCalc.run(-27 ) ;
  }

  @Test
  public void test4() {
    concolic.TestStatCalc.run(3 ) ;
  }

  @Test
  public void test5() {
    concolic.TestStatCalc.run(-301 ) ;
  }

  @Test
  public void test6() {
    concolic.TestStatCalc.run(337 ) ;
  }

  @Test
  public void test7() {
    concolic.TestStatCalc.run(-37 ) ;
  }

  @Test
  public void test8() {
    concolic.TestStatCalc.run(377 ) ;
  }

  @Test
  public void test9() {
    concolic.TestStatCalc.run(-382 ) ;
  }

  @Test
  public void test10() {
    concolic.TestStatCalc.run(457 ) ;
  }

  @Test
  public void test11() {
    concolic.TestStatCalc.run(-495 ) ;
  }

  @Test
  public void test12() {
    concolic.TestStatCalc.run(593 ) ;
  }

  @Test
  public void test13() {
    concolic.TestStatCalc.run(-80 ) ;
  }

  @Test
  public void test14() {
    concolic.TestStatCalc.run(859 ) ;
  }

  @Test
  public void test15() {
    concolic.TestStatCalc.run(91 ) ;
  }

  @Test
  public void test16() {
    concolic.TestStatCalc.run(912 ) ;
  }
}
