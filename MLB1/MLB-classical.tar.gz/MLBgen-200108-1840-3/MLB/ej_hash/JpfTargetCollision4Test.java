import org.junit.Test;

public class JpfTargetCollision4Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision4(-26090,393,643 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision4(793,146,-387 ) ;
  }
}
