import org.junit.Test;

public class JpfTargetCollision1Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision1(483,853,272,-69,-471,-929 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision1(-818,-848,-577,-842,-1531,1314 ) ;
  }
}
