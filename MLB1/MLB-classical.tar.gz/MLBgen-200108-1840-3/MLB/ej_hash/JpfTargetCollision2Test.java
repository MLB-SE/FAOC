import org.junit.Test;

public class JpfTargetCollision2Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision2(517,149,522,-967 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision2(-782,921,-175,-829 ) ;
  }
}
