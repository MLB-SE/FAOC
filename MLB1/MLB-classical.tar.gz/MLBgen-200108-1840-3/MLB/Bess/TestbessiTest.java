import org.junit.Test;

public class TestbessiTest {

  @Test
  public void test0() {
    bess.bessi(-149,-71.0562844181301 ) ;
  }

  @Test
  public void test1() {
    bess.bessi(-1662,3.6615641693097725E-35 ) ;
  }

  @Test
  public void test2() {
    bess.bessi(-178,22.7478351535882 ) ;
  }

  @Test
  public void test3() {
    bess.bessi(187,0.0 ) ;
  }

  @Test
  public void test4() {
    bess.bessi(306,10.580406271090183 ) ;
  }

  @Test
  public void test5() {
    bess.bessi(366,1.036268908299723E-8 ) ;
  }

  @Test
  public void test6() {
    bess.bessi(438,-89.78171819709195 ) ;
  }

  @Test
  public void test7() {
    bess.bessi(-49,-1.2968471084548025E-9 ) ;
  }

  @Test
  public void test8() {
    bess.bessi(-518,0 ) ;
  }

  @Test
  public void test9() {
    bess.bessi(-709,-53.15131315286066 ) ;
  }

  @Test
  public void test10() {
    bess.bessi(760,80.37516239940993 ) ;
  }

  @Test
  public void test11() {
    bess.bessi(-843,0.0 ) ;
  }

  @Test
  public void test12() {
    bess.bessi(921,0 ) ;
  }

  @Test
  public void test13() {
    bess.bessi(928,-1.3071435594242296E-31 ) ;
  }
}
