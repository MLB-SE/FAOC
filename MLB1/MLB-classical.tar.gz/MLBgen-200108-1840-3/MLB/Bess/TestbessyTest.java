import org.junit.Test;

public class TestbessyTest {

  @Test
  public void test0() {
    bess.bessy(-146,98.11064118707134 ) ;
  }

  @Test
  public void test1() {
    bess.bessy(16,0 ) ;
  }

  @Test
  public void test2() {
    bess.bessy(-213,0 ) ;
  }

  @Test
  public void test3() {
    bess.bessy(-270,0.0 ) ;
  }

  @Test
  public void test4() {
    bess.bessy(44,-72.921762351313 ) ;
  }

  @Test
  public void test5() {
    bess.bessy(461,74.75606997280951 ) ;
  }

  @Test
  public void test6() {
    bess.bessy(-687,8.0 ) ;
  }

  @Test
  public void test7() {
    bess.bessy(716,64.65013208424116 ) ;
  }

  @Test
  public void test8() {
    bess.bessy(7,8.0 ) ;
  }

  @Test
  public void test9() {
    bess.bessy(877,0.0 ) ;
  }

  @Test
  public void test10() {
    bess.bessy(-960,-31.0814503423712 ) ;
  }

  @Test
  public void test11() {
    bess.bessy(-974,-4.232212528610972 ) ;
  }
}
