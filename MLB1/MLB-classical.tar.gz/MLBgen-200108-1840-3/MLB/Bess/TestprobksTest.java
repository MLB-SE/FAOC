import org.junit.Test;

public class TestprobksTest {

  @Test
  public void test0() {
    dawson.probks(10.387081513027496 ) ;
  }

  @Test
  public void test1() {
    dawson.probks(-1.4332899253653295 ) ;
  }

  @Test
  public void test2() {
    dawson.probks(-14.585671626035477 ) ;
  }

  @Test
  public void test3() {
    dawson.probks(14.9074709100816 ) ;
  }

  @Test
  public void test4() {
    dawson.probks(-19.2932326161421 ) ;
  }

  @Test
  public void test5() {
    dawson.probks(19.293368839116756 ) ;
  }

  @Test
  public void test6() {
    dawson.probks(-19.29559102435617 ) ;
  }

  @Test
  public void test7() {
    dawson.probks(19.295626345062363 ) ;
  }

  @Test
  public void test8() {
    dawson.probks(-21.167964304883654 ) ;
  }

  @Test
  public void test9() {
    dawson.probks(51.229192689503606 ) ;
  }

  @Test
  public void test10() {
    dawson.probks(6.46142848064504 ) ;
  }

  @Test
  public void test11() {
    dawson.probks(7.529186789316938 ) ;
  }

  @Test
  public void test12() {
    dawson.probks(-85.09533356563053 ) ;
  }

  @Test
  public void test13() {
    dawson.probks(-9.418136059346665 ) ;
  }

  @Test
  public void test14() {
    dawson.probks(98.04435475087746 ) ;
  }
}
