import org.junit.Test;

public class TestpythagTest {

  @Test
  public void test0() {
    dawson.pythag(0.0020309192477848126,0.0020309192477848265 ) ;
  }

  @Test
  public void test1() {
    dawson.pythag(0.09977373168092524,0.09979970035999809 ) ;
  }

  @Test
  public void test2() {
    dawson.pythag(-0.12966610953543098,-0.12966614453817163 ) ;
  }

  @Test
  public void test3() {
    dawson.pythag(0.27090570490644517,0.2709057049518551 ) ;
  }

  @Test
  public void test4() {
    dawson.pythag(0.4779560532660341,-0.4779560532660305 ) ;
  }

  @Test
  public void test5() {
    dawson.pythag(-0.5832263489136551,0 ) ;
  }

  @Test
  public void test6() {
    dawson.pythag(-100.0,-100.0 ) ;
  }

  @Test
  public void test7() {
    dawson.pythag(100.0,100.0 ) ;
  }

  @Test
  public void test8() {
    dawson.pythag(-10.602339093540252,0 ) ;
  }

  @Test
  public void test9() {
    dawson.pythag(-1.1270725851789228E-131,-1.1270725851789228E-131 ) ;
  }

  @Test
  public void test10() {
    dawson.pythag(1.295163E-318,0.0 ) ;
  }

  @Test
  public void test11() {
    dawson.pythag(-1.3684555315672042E-48,-1.7023610651144657E-33 ) ;
  }

  @Test
  public void test12() {
    dawson.pythag(15.217922731965501,-21.83162236183304 ) ;
  }

  @Test
  public void test13() {
    dawson.pythag(-1.5407439555097887E-33,-7.703719777548943E-34 ) ;
  }

  @Test
  public void test14() {
    dawson.pythag(-1.734723475976807E-18,1.7347300934217075E-18 ) ;
  }

  @Test
  public void test15() {
    dawson.pythag(1.7713361414857254,-1.7713361414857254 ) ;
  }

  @Test
  public void test16() {
    dawson.pythag(-1.7800590868057611E-307,0.0 ) ;
  }

  @Test
  public void test17() {
    dawson.pythag(-19.47649643289246,-26.251149178333137 ) ;
  }

  @Test
  public void test18() {
    dawson.pythag(1.9616237442316148E-166,3.012399831378605E-182 ) ;
  }

  @Test
  public void test19() {
    dawson.pythag(2.3182538441796384E-69,-2.3182538441796384E-69 ) ;
  }

  @Test
  public void test20() {
    dawson.pythag(23.754019547052202,23.754019547052202 ) ;
  }

  @Test
  public void test21() {
    dawson.pythag(2.50710170322301E-6,2.5099904268140744E-6 ) ;
  }

  @Test
  public void test22() {
    dawson.pythag(2.704998716307611E-69,1.3177747429038154E-82 ) ;
  }

  @Test
  public void test23() {
    dawson.pythag(-2.737595830060229,95.9874482513377 ) ;
  }

  @Test
  public void test24() {
    dawson.pythag(28.423509115429738,85.97475850228284 ) ;
  }

  @Test
  public void test25() {
    dawson.pythag(-3.036527308570585E-33,3.036767924614385E-33 ) ;
  }

  @Test
  public void test26() {
    dawson.pythag(-3.036604459589289E-33,-3.037073042285697E-33 ) ;
  }

  @Test
  public void test27() {
    dawson.pythag(-3.08174851652719E-33,3.0795278248327506E-33 ) ;
  }

  @Test
  public void test28() {
    dawson.pythag(31.270425913798814,-31.270425913798814 ) ;
  }

  @Test
  public void test29() {
    dawson.pythag(-34.134722853663035,34.134722853663035 ) ;
  }

  @Test
  public void test30() {
    dawson.pythag(3.469446951953614E-18,-3.464850159067002E-18 ) ;
  }

  @Test
  public void test31() {
    dawson.pythag(3.469446951953614E-18,3.469446951953614E-18 ) ;
  }

  @Test
  public void test32() {
    dawson.pythag(-35.323983396781244,74.19408869630163 ) ;
  }

  @Test
  public void test33() {
    dawson.pythag(36.55750717012947,12.070873436903568 ) ;
  }

  @Test
  public void test34() {
    dawson.pythag(3.9484127069845653E-177,-3.9484127069845653E-177 ) ;
  }

  @Test
  public void test35() {
    dawson.pythag(-3.9484127069845653E-177,4.383618698016806E-193 ) ;
  }

  @Test
  public void test36() {
    dawson.pythag(40.23841864516905,-95.14291442132328 ) ;
  }

  @Test
  public void test37() {
    dawson.pythag(-41.29262389634829,-66.1911519187636 ) ;
  }

  @Test
  public void test38() {
    dawson.pythag(-41.514489830152044,-41.514489830152044 ) ;
  }

  @Test
  public void test39() {
    dawson.pythag(-4.3368086899420177E-19,-4.3364239761189326E-19 ) ;
  }

  @Test
  public void test40() {
    dawson.pythag(4.4E-323,0.0 ) ;
  }

  @Test
  public void test41() {
    dawson.pythag(47.3231452622702,-92.6519591410687 ) ;
  }

  @Test
  public void test42() {
    dawson.pythag(50.10724692060438,70.0017240140487 ) ;
  }

  @Test
  public void test43() {
    dawson.pythag(-51.86296401671442,24.000179330927978 ) ;
  }

  @Test
  public void test44() {
    dawson.pythag(52.4546238001781,0.0 ) ;
  }

  @Test
  public void test45() {
    dawson.pythag(-53.3209797033076,53.3209797033076 ) ;
  }

  @Test
  public void test46() {
    dawson.pythag(55.158768963182695,0.0 ) ;
  }

  @Test
  public void test47() {
    dawson.pythag(-55.25005213232275,0.0 ) ;
  }

  @Test
  public void test48() {
    dawson.pythag(5.551115123125783E-17,-6.938893903907228E-17 ) ;
  }

  @Test
  public void test49() {
    dawson.pythag(-57.14210785157516,76.81247664537253 ) ;
  }

  @Test
  public void test50() {
    dawson.pythag(58.92782637351078,44.63584303662765 ) ;
  }

  @Test
  public void test51() {
    dawson.pythag(-59.08842425317966,-59.08842425317966 ) ;
  }

  @Test
  public void test52() {
    dawson.pythag(-6.0223583092473945,-64.86751231694154 ) ;
  }

  @Test
  public void test53() {
    dawson.pythag(6.162975822039155E-33,-6.175012884191575E-33 ) ;
  }

  @Test
  public void test54() {
    dawson.pythag(62.15159370971236,-56.821412281262184 ) ;
  }

  @Test
  public void test55() {
    dawson.pythag(-62.515838747930765,-36.25286851592486 ) ;
  }

  @Test
  public void test56() {
    dawson.pythag(-6.3174603311753045E-176,6.3174603311753045E-176 ) ;
  }

  @Test
  public void test57() {
    dawson.pythag(-63.67005509625767,-73.66089787310352 ) ;
  }

  @Test
  public void test58() {
    dawson.pythag(67.46736174055651,-67.46736174055651 ) ;
  }

  @Test
  public void test59() {
    dawson.pythag(-6.842277657836021E-49,6.848959569611251E-49 ) ;
  }

  @Test
  public void test60() {
    dawson.pythag(6.9997235105271E-4,-6.999725062651514E-4 ) ;
  }

  @Test
  public void test61() {
    dawson.pythag(-7.213264545145106E-130,-8.008332380732404E-146 ) ;
  }

  @Test
  public void test62() {
    dawson.pythag(-73.26503850324224,73.44641596525895 ) ;
  }

  @Test
  public void test63() {
    dawson.pythag(73.30626463928789,73.30626463928789 ) ;
  }

  @Test
  public void test64() {
    dawson.pythag(7.350525056770053,43.654000755190964 ) ;
  }

  @Test
  public void test65() {
    dawson.pythag(7.52286409459983E-37,-7.5228640945998296E-37 ) ;
  }

  @Test
  public void test66() {
    dawson.pythag(-75.750272777187,6.7699962920388685 ) ;
  }

  @Test
  public void test67() {
    dawson.pythag(81.51611867912085,0.0 ) ;
  }

  @Test
  public void test68() {
    dawson.pythag(88.50239337172312,0 ) ;
  }

  @Test
  public void test69() {
    dawson.pythag(-8.891856315200182E-308,8.891856315200163E-308 ) ;
  }

  @Test
  public void test70() {
    dawson.pythag(-89.01327725106856,89.01327725106856 ) ;
  }

  @Test
  public void test71() {
    dawson.pythag(-9.223397059923119E-33,9.244463733058732E-33 ) ;
  }

  @Test
  public void test72() {
    dawson.pythag(-94.37201228588003,0.0 ) ;
  }

  @Test
  public void test73() {
    dawson.pythag(95.08809477050158,-62.60049722773546 ) ;
  }

  @Test
  public void test74() {
    dawson.pythag(-95.41844712003014,0.0 ) ;
  }

  @Test
  public void test75() {
    dawson.pythag(-96.17269827661032,-22.675847632885365 ) ;
  }

  @Test
  public void test76() {
    dawson.pythag(97.77030042038945,68.27511991214371 ) ;
  }

  @Test
  public void test77() {
    dawson.pythag(-9.860761315262648E-32,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test78() {
    dawson.pythag(9.871031767461413E-178,9.871031767461413E-178 ) ;
  }
}
