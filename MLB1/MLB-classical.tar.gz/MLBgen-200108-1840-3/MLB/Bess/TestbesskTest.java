import org.junit.Test;

public class TestbesskTest {

  @Test
  public void test0() {
    bess.bessk(-185,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1() {
    bess.bessk(222,-38.176378610549676 ) ;
  }

  @Test
  public void test2() {
    bess.bessk(235,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test3() {
    bess.bessk(-253,2.715917161797023 ) ;
  }

  @Test
  public void test4() {
    bess.bessk(257,0.0 ) ;
  }

  @Test
  public void test5() {
    bess.bessk(319,2.0 ) ;
  }

  @Test
  public void test6() {
    bess.bessk(-499,-69.0862077531901 ) ;
  }

  @Test
  public void test7() {
    bess.bessk(-511,0.0 ) ;
  }

  @Test
  public void test8() {
    bess.bessk(512,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test9() {
    bess.bessk(-600,1.1643490607585135E-15 ) ;
  }

  @Test
  public void test10() {
    bess.bessk(-618,17.425525177843525 ) ;
  }

  @Test
  public void test11() {
    bess.bessk(663,99.17635271616695 ) ;
  }

  @Test
  public void test12() {
    bess.bessk(689,-26.250014636380243 ) ;
  }

  @Test
  public void test13() {
    bess.bessk(-721,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test14() {
    bess.bessk(797,70.5619316130427 ) ;
  }

  @Test
  public void test15() {
    bess.bessk(-806,4.9E-324 ) ;
  }

  @Test
  public void test16() {
    bess.bessk(812,2.0 ) ;
  }

  @Test
  public void test17() {
    bess.bessk(-840,2.0 ) ;
  }

  @Test
  public void test18() {
    bess.bessk(-846,2.0 ) ;
  }

  @Test
  public void test19() {
    bess.bessk(847,0 ) ;
  }

  @Test
  public void test20() {
    bess.bessk(914,1.1830521861667747E-271 ) ;
  }

  @Test
  public void test21() {
    bess.bessk(-927,-31.863947701592494 ) ;
  }

  @Test
  public void test22() {
    bess.bessk(950,1.1356305909570867 ) ;
  }

  @Test
  public void test23() {
    bess.bessk(-99,0 ) ;
  }
}
