import org.junit.Test;

public class TestbessjTest {

  @Test
  public void test0() {
    bess.bessj(1,-0.25762086720527755 ) ;
  }

  @Test
  public void test1() {
    bess.bessj(1,-1.0 ) ;
  }

  @Test
  public void test2() {
    bess.bessj(1,1.0 ) ;
  }

  @Test
  public void test3() {
    bess.bessj(1,6.162975822039155E-33 ) ;
  }

  @Test
  public void test4() {
    bess.bessj(170,-41.53084981790942 ) ;
  }

  @Test
  public void test5() {
    bess.bessj(19,-19.0 ) ;
  }

  @Test
  public void test6() {
    bess.bessj(194,27.806461976351798 ) ;
  }

  @Test
  public void test7() {
    bess.bessj(-2104,-1.778205794257249E-161 ) ;
  }

  @Test
  public void test8() {
    bess.bessj(-256,-1.3892242184281734E-163 ) ;
  }

  @Test
  public void test9() {
    bess.bessj(262,0.0 ) ;
  }

  @Test
  public void test10() {
    bess.bessj(-313,0.0 ) ;
  }

  @Test
  public void test11() {
    bess.bessj(-325,4.299440708842937E-137 ) ;
  }

  @Test
  public void test12() {
    bess.bessj(3,3.0 ) ;
  }

  @Test
  public void test13() {
    bess.bessj(335,73.74570886818987 ) ;
  }

  @Test
  public void test14() {
    bess.bessj(-349,0 ) ;
  }

  @Test
  public void test15() {
    bess.bessj(51,-84.31009714097146 ) ;
  }

  @Test
  public void test16() {
    bess.bessj(533,1.2E-322 ) ;
  }

  @Test
  public void test17() {
    bess.bessj(53,-79.00370154607617 ) ;
  }

  @Test
  public void test18() {
    bess.bessj(-545,-13.934278106339889 ) ;
  }

  @Test
  public void test19() {
    bess.bessj(-553,-84.54374884954727 ) ;
  }

  @Test
  public void test20() {
    bess.bessj(558,0.0 ) ;
  }

  @Test
  public void test21() {
    bess.bessj(-577,2.220446049250313E-16 ) ;
  }

  @Test
  public void test22() {
    bess.bessj(588,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test23() {
    bess.bessj(-595,0.0 ) ;
  }

  @Test
  public void test24() {
    bess.bessj(-595,4.280687916554385 ) ;
  }

  @Test
  public void test25() {
    bess.bessj(628,0.0 ) ;
  }

  @Test
  public void test26() {
    bess.bessj(730,-1.2634920662350609E-175 ) ;
  }

  @Test
  public void test27() {
    bess.bessj(742,85.94669595539227 ) ;
  }

  @Test
  public void test28() {
    bess.bessj(7,48.42804247420136 ) ;
  }

  @Test
  public void test29() {
    bess.bessj(788,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test30() {
    bess.bessj(838,-8.89103499794031E-162 ) ;
  }

  @Test
  public void test31() {
    bess.bessj(-881,10.227709213584404 ) ;
  }

  @Test
  public void test32() {
    bess.bessj(-891,0.0 ) ;
  }

  @Test
  public void test33() {
    bess.bessj(906,-75.89647444102977 ) ;
  }

  @Test
  public void test34() {
    bess.bessj(-922,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test35() {
    bess.bessj(-969,78.50634556184906 ) ;
  }

  @Test
  public void test36() {
    bess.bessj(973,0 ) ;
  }

  @Test
  public void test37() {
    bess.bessj(-999,-84.09099969321478 ) ;
  }
}
