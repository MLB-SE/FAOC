import org.junit.Test;

public class TestdawsonTest {

  @Test
  public void test0() {
    dawson.dawson(0.1999999999999993 ) ;
  }

  @Test
  public void test1() {
    dawson.dawson(-0.19999999999999996 ) ;
  }

  @Test
  public void test2() {
    dawson.dawson(0.19999999999999996 ) ;
  }

  @Test
  public void test3() {
    dawson.dawson(-0.2 ) ;
  }

  @Test
  public void test4() {
    dawson.dawson(-0.20000000000000004 ) ;
  }

  @Test
  public void test5() {
    dawson.dawson(-0.20000000000000018 ) ;
  }

  @Test
  public void test6() {
    dawson.dawson(0.20000000000000018 ) ;
  }

  @Test
  public void test7() {
    dawson.dawson(-0.20000000000000107 ) ;
  }

  @Test
  public void test8() {
    dawson.dawson(0.20000000000000107 ) ;
  }

  @Test
  public void test9() {
    dawson.dawson(0.20000000000000195 ) ;
  }

  @Test
  public void test10() {
    dawson.dawson(-0.20411536308559164 ) ;
  }

  @Test
  public void test11() {
    dawson.dawson(-0.39999999999999997 ) ;
  }

  @Test
  public void test12() {
    dawson.dawson(0.39999999999999997 ) ;
  }

  @Test
  public void test13() {
    dawson.dawson(-0.4 ) ;
  }

  @Test
  public void test14() {
    dawson.dawson(-0.46076290325560176 ) ;
  }

  @Test
  public void test15() {
    dawson.dawson(-0.5864268381400084 ) ;
  }

  @Test
  public void test16() {
    dawson.dawson(0.6104994433614852 ) ;
  }

  @Test
  public void test17() {
    dawson.dawson(-0.6496035430981646 ) ;
  }

  @Test
  public void test18() {
    dawson.dawson(-0.6706338487292627 ) ;
  }

  @Test
  public void test19() {
    dawson.dawson(0.6841428542747661 ) ;
  }

  @Test
  public void test20() {
    dawson.dawson(-0.6919100629869233 ) ;
  }

  @Test
  public void test21() {
    dawson.dawson(0.7273444400955036 ) ;
  }

  @Test
  public void test22() {
    dawson.dawson(0.7539737055496439 ) ;
  }

  @Test
  public void test23() {
    dawson.dawson(0.7941610168297296 ) ;
  }

  @Test
  public void test24() {
    dawson.dawson(0.7999999999998891 ) ;
  }

  @Test
  public void test25() {
    dawson.dawson(-0.7999999999999999 ) ;
  }

  @Test
  public void test26() {
    dawson.dawson(0.7999999999999999 ) ;
  }

  @Test
  public void test27() {
    dawson.dawson(0.962383921987693 ) ;
  }

  @Test
  public void test28() {
    dawson.dawson(-10.825726747684342 ) ;
  }

  @Test
  public void test29() {
    dawson.dawson(11.02809085501437 ) ;
  }

  @Test
  public void test30() {
    dawson.dawson(-1.1077223616198149 ) ;
  }

  @Test
  public void test31() {
    dawson.dawson(1.232595164407831E-32 ) ;
  }

  @Test
  public void test32() {
    dawson.dawson(-15.315484390006432 ) ;
  }

  @Test
  public void test33() {
    dawson.dawson(-15.58060764592581 ) ;
  }

  @Test
  public void test34() {
    dawson.dawson(1.6013059987441465 ) ;
  }

  @Test
  public void test35() {
    dawson.dawson(16.08024054862136 ) ;
  }

  @Test
  public void test36() {
    dawson.dawson(-1.6717001641894882 ) ;
  }

  @Test
  public void test37() {
    dawson.dawson(-1.808139762995049 ) ;
  }

  @Test
  public void test38() {
    dawson.dawson(-20.4423158262303 ) ;
  }

  @Test
  public void test39() {
    dawson.dawson(-2.4354446082951484 ) ;
  }

  @Test
  public void test40() {
    dawson.dawson(2.4585106323430748 ) ;
  }

  @Test
  public void test41() {
    dawson.dawson(25.4166311119171 ) ;
  }

  @Test
  public void test42() {
    dawson.dawson(27.574991655790043 ) ;
  }

  @Test
  public void test43() {
    dawson.dawson(30.45638201464655 ) ;
  }

  @Test
  public void test44() {
    dawson.dawson(3.292087038036935 ) ;
  }

  @Test
  public void test45() {
    dawson.dawson(33.243784001889736 ) ;
  }

  @Test
  public void test46() {
    dawson.dawson(-3.3453156360800733 ) ;
  }

  @Test
  public void test47() {
    dawson.dawson(3.3903848452725924 ) ;
  }

  @Test
  public void test48() {
    dawson.dawson(34.33166332673389 ) ;
  }

  @Test
  public void test49() {
    dawson.dawson(35.53071422659596 ) ;
  }

  @Test
  public void test50() {
    dawson.dawson(-3.9728046159856802 ) ;
  }

  @Test
  public void test51() {
    dawson.dawson(4.102196655151985 ) ;
  }

  @Test
  public void test52() {
    dawson.dawson(-4.187761593111839 ) ;
  }

  @Test
  public void test53() {
    dawson.dawson(-41.99177022855458 ) ;
  }

  @Test
  public void test54() {
    dawson.dawson(-42.490920552193586 ) ;
  }

  @Test
  public void test55() {
    dawson.dawson(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test56() {
    dawson.dawson(-45.0621460050419 ) ;
  }

  @Test
  public void test57() {
    dawson.dawson(48.82267165819755 ) ;
  }

  @Test
  public void test58() {
    dawson.dawson(48.89516827549281 ) ;
  }

  @Test
  public void test59() {
    dawson.dawson(51.413114169341895 ) ;
  }

  @Test
  public void test60() {
    dawson.dawson(54.50778627664016 ) ;
  }

  @Test
  public void test61() {
    dawson.dawson(55.919798877362524 ) ;
  }

  @Test
  public void test62() {
    dawson.dawson(-58.21417708566854 ) ;
  }

  @Test
  public void test63() {
    dawson.dawson(5.898121020028185 ) ;
  }

  @Test
  public void test64() {
    dawson.dawson(-63.40829910749333 ) ;
  }

  @Test
  public void test65() {
    dawson.dawson(-63.87634937738347 ) ;
  }

  @Test
  public void test66() {
    dawson.dawson(66.49814637743401 ) ;
  }

  @Test
  public void test67() {
    dawson.dawson(6.672819532327495 ) ;
  }

  @Test
  public void test68() {
    dawson.dawson(-68.58288608958634 ) ;
  }

  @Test
  public void test69() {
    dawson.dawson(-81.88730420289976 ) ;
  }

  @Test
  public void test70() {
    dawson.dawson(-84.0497857705316 ) ;
  }

  @Test
  public void test71() {
    dawson.dawson(84.13365915965323 ) ;
  }

  @Test
  public void test72() {
    dawson.dawson(-87.99435731873962 ) ;
  }

  @Test
  public void test73() {
    dawson.dawson(92.97624160614942 ) ;
  }

  @Test
  public void test74() {
    dawson.dawson(-99.07442129093644 ) ;
  }
}
