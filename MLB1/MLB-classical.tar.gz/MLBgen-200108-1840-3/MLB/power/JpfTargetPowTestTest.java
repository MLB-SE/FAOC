import org.junit.Test;

public class JpfTargetPowTestTest {

  @Test
  public void test0() {
    concolic.PowExample.test(193,822 ) ;
  }

  @Test
  public void test1() {
    concolic.PowExample.test(2,4 ) ;
  }

  @Test
  public void test2() {
    concolic.PowExample.test(33,1089 ) ;
  }

  @Test
  public void test3() {
    concolic.PowExample.test(34,1156 ) ;
  }

  @Test
  public void test4() {
    concolic.PowExample.test(341,-571 ) ;
  }

  @Test
  public void test5() {
    concolic.PowExample.test(442,678 ) ;
  }

  @Test
  public void test6() {
    concolic.PowExample.test(-654,0 ) ;
  }

  @Test
  public void test7() {
    concolic.PowExample.test(734,0 ) ;
  }
}
