import org.junit.Test;

public class JpfTargetDartTest {

  @Test
  public void test0() {
    concolic.DART.test(0,0 ) ;
  }

  @Test
  public void test1() {
    concolic.DART.test(1,0 ) ;
  }

  @Test
  public void test2() {
    concolic.DART.test(423,10 ) ;
  }

  @Test
  public void test3() {
    concolic.DART.test(464,0 ) ;
  }

  @Test
  public void test4() {
    concolic.DART.test(467,0 ) ;
  }

  @Test
  public void test5() {
    concolic.DART.test(866,-455 ) ;
  }

  @Test
  public void test6() {
    concolic.DART.test(-876,0 ) ;
  }

  @Test
  public void test7() {
    concolic.DART.test(-989,0 ) ;
  }
}
