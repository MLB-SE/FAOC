import org.junit.Test;

public class JpfTargetBealeTest {

  @Test
  public void test0() {
    Optimization.beale(10.5521557425625,0.8578489517597152 ) ;
  }

  @Test
  public void test1() {
    Optimization.beale(15.901857384671004,94.40679188670583 ) ;
  }

  @Test
  public void test2() {
    Optimization.beale(49.47796863665806,-90.20451591036664 ) ;
  }
}
