import org.junit.Test;

public class JpfTargetFreudensteinRothTest {

  @Test
  public void test0() {
    Optimization.freudensteinRoth(-51.75994136086838,6.435400714771362 ) ;
  }

  @Test
  public void test1() {
    Optimization.freudensteinRoth(-68.33085903858718,-3.2686758545922885 ) ;
  }

  @Test
  public void test2() {
    Optimization.freudensteinRoth(83.04858596571867,-57.381244849557 ) ;
  }
}
