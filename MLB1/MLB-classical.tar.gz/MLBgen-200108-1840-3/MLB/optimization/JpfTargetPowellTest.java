import org.junit.Test;

public class JpfTargetPowellTest {

  @Test
  public void test0() {
    Optimization.powell(-1.184663614907247E-5,-8.44121476693023 ) ;
  }

  @Test
  public void test1() {
    Optimization.powell(25.57212536622582,12.705399986267295 ) ;
  }

  @Test
  public void test2() {
    Optimization.powell(-4.6649638700757856E-6,-21.436393246573083 ) ;
  }

  @Test
  public void test3() {
    Optimization.powell(-75.50284767763134,63.86614917146122 ) ;
  }

  @Test
  public void test4() {
    Optimization.powell(8.38323184073873,1.1928573836410567E-5 ) ;
  }

  @Test
  public void test5() {
    Optimization.powell(8.857499148410121E-5,1.128986842950468 ) ;
  }
}
