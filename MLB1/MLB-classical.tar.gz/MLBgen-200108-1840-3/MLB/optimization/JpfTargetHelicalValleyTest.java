import org.junit.Test;

public class JpfTargetHelicalValleyTest {

  @Test
  public void test0() {
    Optimization.theta(0.043851836934919675,0 ) ;
  }

  @Test
  public void test1() {
    Optimization.theta(100.0,0.0 ) ;
  }

  @Test
  public void test2() {
    Optimization.theta(-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test3() {
    Optimization.theta(-11.384575029763695,-98.90492613500783 ) ;
  }

  @Test
  public void test4() {
    Optimization.theta(1.232595164407831E-32,0 ) ;
  }

  @Test
  public void test5() {
    Optimization.theta(15.214164799383184,0 ) ;
  }

  @Test
  public void test6() {
    Optimization.theta(-18.95150162997939,-8.341173809037912 ) ;
  }

  @Test
  public void test7() {
    Optimization.theta(-22.970290654422666,-47.26795243419007 ) ;
  }

  @Test
  public void test8() {
    Optimization.theta(-2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test9() {
    Optimization.theta(-25.36920961324276,33.09083575032875 ) ;
  }

  @Test
  public void test10() {
    Optimization.theta(-34.62080631672366,0 ) ;
  }

  @Test
  public void test11() {
    Optimization.theta(38.77392962445332,5.30471864602394 ) ;
  }

  @Test
  public void test12() {
    Optimization.theta(-4.440892098500626E-16,99.99999999997863 ) ;
  }

  @Test
  public void test13() {
    Optimization.theta(45.87292329569702,51.860163896514116 ) ;
  }

  @Test
  public void test14() {
    Optimization.theta(-46.725482663017004,60.52074286352878 ) ;
  }

  @Test
  public void test15() {
    Optimization.theta(47.41743409958333,93.53107825562246 ) ;
  }

  @Test
  public void test16() {
    Optimization.theta(-4.79354420009895,0 ) ;
  }

  @Test
  public void test17() {
    Optimization.theta(5.522655773786141,-16.9495417709457 ) ;
  }

  @Test
  public void test18() {
    Optimization.theta(56.37920167466129,-5.616670541947167 ) ;
  }

  @Test
  public void test19() {
    Optimization.theta(60.77086087109879,65.04521489329159 ) ;
  }

  @Test
  public void test20() {
    Optimization.theta(64.04614948799313,-2.3609875202015456 ) ;
  }

  @Test
  public void test21() {
    Optimization.theta(68.23313997410818,0 ) ;
  }

  @Test
  public void test22() {
    Optimization.theta(-6.938893903907228E-18,35.086093989765175 ) ;
  }

  @Test
  public void test23() {
    Optimization.theta(-7.474278929734888,-9.231836669938454 ) ;
  }

  @Test
  public void test24() {
    Optimization.theta(76.59414548012842,-2.500291083944461 ) ;
  }

  @Test
  public void test25() {
    Optimization.theta(-83.47909517450188,0 ) ;
  }

  @Test
  public void test26() {
    Optimization.theta(-97.6441950064751,0 ) ;
  }

  @Test
  public void test27() {
    Optimization.theta(-98.03188009022146,-24.82927002426537 ) ;
  }
}
