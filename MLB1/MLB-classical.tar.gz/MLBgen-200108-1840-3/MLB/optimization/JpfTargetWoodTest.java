import org.junit.Test;

public class JpfTargetWoodTest {

  @Test
  public void test0() {
    Optimization.wood(1.0,0.9999999999994853,1.0,1.000000000000515 ) ;
  }

  @Test
  public void test1() {
    Optimization.wood(1.0,1.0,0,0 ) ;
  }

  @Test
  public void test2() {
    Optimization.wood(1.0,1.0000000000000004,1.0,1.0 ) ;
  }

  @Test
  public void test3() {
    Optimization.wood(1.0,1.0,1.0,0.9999999999999998 ) ;
  }

  @Test
  public void test4() {
    Optimization.wood(1.0,1.0,1.0,1.0 ) ;
  }

  @Test
  public void test5() {
    Optimization.wood(1.0,1.0,3.6282864697835002,13.164462706814014 ) ;
  }

  @Test
  public void test6() {
    Optimization.wood(1.0,1.0,-49.71214129036838,77.70922919841507 ) ;
  }

  @Test
  public void test7() {
    Optimization.wood(1.0,1.0,-5.491734706691988,30.159150088685333 ) ;
  }

  @Test
  public void test8() {
    Optimization.wood(1.0,1.0,6.26852331393618,100.0 ) ;
  }

  @Test
  public void test9() {
    Optimization.wood(1.0,1.0,-6.840256962222051,46.789115309227235 ) ;
  }

  @Test
  public void test10() {
    Optimization.wood(4.281311217743422,41.11922801560743,0,0 ) ;
  }

  @Test
  public void test11() {
    Optimization.wood(4.462643283758766,19.91518507807722,0,0 ) ;
  }

  @Test
  public void test12() {
    Optimization.wood(-4.463871559601728,19.926149300621162,0,0 ) ;
  }

  @Test
  public void test13() {
    Optimization.wood(7.3821324983190095,54.49588022273766,0,0 ) ;
  }

  @Test
  public void test14() {
    Optimization.wood(89.43330734585135,-99.07920151453962,0,0 ) ;
  }
}
