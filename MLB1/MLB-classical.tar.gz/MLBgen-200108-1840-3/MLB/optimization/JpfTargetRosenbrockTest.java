import org.junit.Test;

public class JpfTargetRosenbrockTest {

  @Test
  public void test0() {
    Optimization.rosenbrock(0.4727159716463041,0.22086668749598562 ) ;
  }

  @Test
  public void test1() {
    Optimization.rosenbrock(-1.0723969787051737,1.1429144092434462 ) ;
  }

  @Test
  public void test2() {
    Optimization.rosenbrock(5.992224942940382,28.406175538368927 ) ;
  }
}
