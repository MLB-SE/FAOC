import org.junit.Test;

public class TesteiTest {

  @Test
  public void test0() {
    expint.ei(1.232595164407831E-32 ) ;
  }

  @Test
  public void test1() {
    expint.ei(22.474011398740032 ) ;
  }

  @Test
  public void test2() {
    expint.ei(31.330220112274816 ) ;
  }

  @Test
  public void test3() {
    expint.ei(3.2076268305257543 ) ;
  }

  @Test
  public void test4() {
    expint.ei(32.23619130191664 ) ;
  }

  @Test
  public void test5() {
    expint.ei(3.552713678800501E-15 ) ;
  }

  @Test
  public void test6() {
    expint.ei(4.096881996245656 ) ;
  }

  @Test
  public void test7() {
    expint.ei(4.4E-323 ) ;
  }

  @Test
  public void test8() {
    expint.ei(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test9() {
    expint.ei(5.1948146786495957E-17 ) ;
  }

  @Test
  public void test10() {
    expint.ei(-5.723306468574862 ) ;
  }

  @Test
  public void test11() {
    expint.ei(-61.25233159193362 ) ;
  }

  @Test
  public void test12() {
    expint.ei(-6.938893903907228E-18 ) ;
  }

  @Test
  public void test13() {
    expint.ei(87.02791436796596 ) ;
  }

  @Test
  public void test14() {
    expint.ei(8.881784197001252E-16 ) ;
  }

  @Test
  public void test15() {
    expint.ei(92.28552631452902 ) ;
  }

  @Test
  public void test16() {
    expint.ei(9.758536822510735 ) ;
  }
}
