import org.junit.Test;

public class TestbetaiTest {

  @Test
  public void test0() {
    beta.betai(0,0,0.9999999999999982 ) ;
  }

  @Test
  public void test1() {
    beta.betai(0,0,0.9999999999999998 ) ;
  }

  @Test
  public void test2() {
    beta.betai(0,0,1.0 ) ;
  }

  @Test
  public void test3() {
    beta.betai(0,0,1.0000000000000002 ) ;
  }

  @Test
  public void test4() {
    beta.betai(0,0,1.0000000000000004 ) ;
  }

  @Test
  public void test5() {
    beta.betai(0,0,1.0000000000000009 ) ;
  }

  @Test
  public void test6() {
    beta.betai(0,0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test7() {
    beta.betai(0,0,-1.2553178876862887 ) ;
  }

  @Test
  public void test8() {
    beta.betai(0,0,13.874502512937667 ) ;
  }

  @Test
  public void test9() {
    beta.betai(0,0,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test10() {
    beta.betai(0,0,21.060214210395586 ) ;
  }

  @Test
  public void test11() {
    beta.betai(0,0,24.21135297254378 ) ;
  }

  @Test
  public void test12() {
    beta.betai(0,0,35.418201064517774 ) ;
  }

  @Test
  public void test13() {
    beta.betai(0,0,-5.54866898880077 ) ;
  }

  @Test
  public void test14() {
    beta.betai(0,0,-6.162975822039155E-33 ) ;
  }

  @Test
  public void test15() {
    beta.betai(0,0,-67.71999067225711 ) ;
  }

  @Test
  public void test16() {
    beta.betai(0,0,6.893482795505989 ) ;
  }

  @Test
  public void test17() {
    beta.betai(0,0,7.524237188856759 ) ;
  }

  @Test
  public void test18() {
    beta.betai(0,0,8.222865365428689 ) ;
  }

  @Test
  public void test19() {
    beta.betai(0,0,-84.643491172116 ) ;
  }

  @Test
  public void test20() {
    beta.betai(0,0,88.02517799950633 ) ;
  }

  @Test
  public void test21() {
    beta.betai(0,0,-9.860761315262648E-32 ) ;
  }
}
