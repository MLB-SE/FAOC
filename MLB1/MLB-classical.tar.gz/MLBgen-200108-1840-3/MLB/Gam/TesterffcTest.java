import org.junit.Test;

public class TesterffcTest {

  @Test
  public void test0() {
    gam.erffc(0.5376842746977815 ) ;
  }

  @Test
  public void test1() {
    gam.erffc(0.8017380276258024 ) ;
  }

  @Test
  public void test2() {
    gam.erffc(-1.165683583674583 ) ;
  }

  @Test
  public void test3() {
    gam.erffc(-1.224744871391589 ) ;
  }

  @Test
  public void test4() {
    gam.erffc(1.224744871391589 ) ;
  }

  @Test
  public void test5() {
    gam.erffc(-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test6() {
    gam.erffc(-2.220446049250313E-16 ) ;
  }

  @Test
  public void test7() {
    gam.erffc(-2.5269841324701218E-175 ) ;
  }

  @Test
  public void test8() {
    gam.erffc(3.4211388289180104E-49 ) ;
  }

  @Test
  public void test9() {
    gam.erffc(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test10() {
    gam.erffc(4.440892098500626E-16 ) ;
  }

  @Test
  public void test11() {
    gam.erffc(44.71271283696947 ) ;
  }

  @Test
  public void test12() {
    gam.erffc(5.0539682649402436E-175 ) ;
  }

  @Test
  public void test13() {
    gam.erffc(-56.23241764182963 ) ;
  }

  @Test
  public void test14() {
    gam.erffc(57.468105784900615 ) ;
  }

  @Test
  public void test15() {
    gam.erffc(6.938893903907228E-18 ) ;
  }

  @Test
  public void test16() {
    gam.erffc(-70.86706969059406 ) ;
  }

  @Test
  public void test17() {
    gam.erffc(85.13676365670437 ) ;
  }

  @Test
  public void test18() {
    gam.erffc(8.881784197001252E-16 ) ;
  }

  @Test
  public void test19() {
    gam.erffc(-95.95505740651411 ) ;
  }
}
