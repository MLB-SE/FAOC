import org.junit.Test;

public class TestexpintTest {

  @Test
  public void test0() {
    expint.expint(0,0.0 ) ;
  }

  @Test
  public void test1() {
    expint.expint(0,83.00308463857644 ) ;
  }

  @Test
  public void test2() {
    expint.expint(213,92.80156573335998 ) ;
  }

  @Test
  public void test3() {
    expint.expint(262,0 ) ;
  }

  @Test
  public void test4() {
    expint.expint(294,1.5E-323 ) ;
  }

  @Test
  public void test5() {
    expint.expint(387,0.0 ) ;
  }

  @Test
  public void test6() {
    expint.expint(409,9.860761315262648E-32 ) ;
  }

  @Test
  public void test7() {
    expint.expint(464,-5.9E-323 ) ;
  }

  @Test
  public void test8() {
    expint.expint(60,0.0 ) ;
  }

  @Test
  public void test9() {
    expint.expint(684,1.0E-323 ) ;
  }

  @Test
  public void test10() {
    expint.expint(763,42.60286214268717 ) ;
  }

  @Test
  public void test11() {
    expint.expint(848,41.77463066234287 ) ;
  }

  @Test
  public void test12() {
    expint.expint(921,0.0 ) ;
  }

  @Test
  public void test13() {
    expint.expint(-974,0 ) ;
  }

  @Test
  public void test14() {
    expint.expint(979,-86.54047639455258 ) ;
  }
}
