import org.junit.Test;

public class TestbicoTest {

  @Test
  public void test0() {
    gam.bico(0,0 ) ;
  }

  @Test
  public void test1() {
    gam.bico(0,100 ) ;
  }

  @Test
  public void test2() {
    gam.bico(0,2 ) ;
  }

  @Test
  public void test3() {
    gam.bico(0,-347 ) ;
  }

  @Test
  public void test4() {
    gam.bico(-1,0 ) ;
  }

  @Test
  public void test5() {
    gam.bico(1,1 ) ;
  }

  @Test
  public void test6() {
    gam.bico(1,-692 ) ;
  }

  @Test
  public void test7() {
    gam.bico(1,964 ) ;
  }

  @Test
  public void test8() {
    gam.bico(-259,616 ) ;
  }

  @Test
  public void test9() {
    gam.bico(-305,0 ) ;
  }

  @Test
  public void test10() {
    gam.bico(-373,0 ) ;
  }

  @Test
  public void test11() {
    gam.bico(39,0 ) ;
  }

  @Test
  public void test12() {
    gam.bico(-435,0 ) ;
  }

  @Test
  public void test13() {
    gam.bico(-467,2 ) ;
  }

  @Test
  public void test14() {
    gam.bico(500,0 ) ;
  }

  @Test
  public void test15() {
    gam.bico(-630,-894 ) ;
  }

  @Test
  public void test16() {
    gam.bico(-75,-859 ) ;
  }

  @Test
  public void test17() {
    gam.bico(89,0 ) ;
  }

  @Test
  public void test18() {
    gam.bico(-892,544 ) ;
  }

  @Test
  public void test19() {
    gam.bico(901,0 ) ;
  }
}
