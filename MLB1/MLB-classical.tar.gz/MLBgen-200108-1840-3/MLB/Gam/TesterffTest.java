import org.junit.Test;

public class TesterffTest {

  @Test
  public void test0() {
    gam.erff(-0.029840315848828 ) ;
  }

  @Test
  public void test1() {
    gam.erff(1.0454060189543388 ) ;
  }

  @Test
  public void test2() {
    gam.erff(1.224744871391589 ) ;
  }

  @Test
  public void test3() {
    gam.erff(-1.2247448713915892 ) ;
  }

  @Test
  public void test4() {
    gam.erff(12.605964963410415 ) ;
  }

  @Test
  public void test5() {
    gam.erff(-1.2873092873296486 ) ;
  }

  @Test
  public void test6() {
    gam.erff(-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test7() {
    gam.erff(1.7763568394002505E-15 ) ;
  }

  @Test
  public void test8() {
    gam.erff(-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test9() {
    gam.erff(-3.0478348852269903 ) ;
  }

  @Test
  public void test10() {
    gam.erff(-3.1587301655876523E-176 ) ;
  }

  @Test
  public void test11() {
    gam.erff(3.1587301655876523E-176 ) ;
  }

  @Test
  public void test12() {
    gam.erff(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test13() {
    gam.erff(4.440892098500626E-16 ) ;
  }

  @Test
  public void test14() {
    gam.erff(49.916982348336234 ) ;
  }

  @Test
  public void test15() {
    gam.erff(72.877665142578 ) ;
  }

  @Test
  public void test16() {
    gam.erff(-83.78200525609111 ) ;
  }

  @Test
  public void test17() {
    gam.erff(8.673617379884035E-19 ) ;
  }

  @Test
  public void test18() {
    gam.erff(-8.881784197001252E-16 ) ;
  }

  @Test
  public void test19() {
    gam.erff(8.881784197001252E-16 ) ;
  }

  @Test
  public void test20() {
    gam.erff(-91.21108644250164 ) ;
  }
}
