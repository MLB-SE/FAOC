import org.junit.Test;

public class TestbetacfTest {

  @Test
  public void test0() {
    beta.betacf(-1.0,0,0 ) ;
  }

  @Test
  public void test1() {
    beta.betacf(23.905286853187874,-18.416239144108957,4.537269153626482 ) ;
  }

  @Test
  public void test2() {
    beta.betacf(27.51584913130946,-57.88504766736499,-0.9389727258509736 ) ;
  }

  @Test
  public void test3() {
    beta.betacf(-27.614994017522037,96.54114916128879,96.78552378346316 ) ;
  }

  @Test
  public void test4() {
    beta.betacf(-64.36976070654896,96.97276894616593,-1.9436783330179424 ) ;
  }

  @Test
  public void test5() {
    beta.betacf(-65.87329359939866,-9.41211473046097,10.919051106177463 ) ;
  }

  @Test
  public void test6() {
    beta.betacf(-71.34716866018375,-82.28664610354352,0.457888575951657 ) ;
  }

  @Test
  public void test7() {
    beta.betacf(76.29634113035883,0,0 ) ;
  }

  @Test
  public void test8() {
    beta.betacf(78.5404764597645,-76.13768941144662,33.10342317495348 ) ;
  }

  @Test
  public void test9() {
    beta.betacf(-80.34001916740097,77.90054507332037,32.52341123847973 ) ;
  }

  @Test
  public void test10() {
    beta.betacf(-82.95371305068875,75.78663143595915,11.434739752685338 ) ;
  }

  @Test
  public void test11() {
    beta.betacf(-9.598482701896756,-16.02004298971397,66.23597624699588 ) ;
  }

  @Test
  public void test12() {
    beta.betacf(-96.17737284362846,5.747433280751935,-93.69554300968295 ) ;
  }

  @Test
  public void test13() {
    beta.betacf(99.99052784368271,-88.01089774632433,8.430187495184184 ) ;
  }
}
