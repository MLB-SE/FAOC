import org.junit.Test;

public class TesterfccTest {

  @Test
  public void test0() {
    erf.erfcc(13.099085679594609 ) ;
  }

  @Test
  public void test1() {
    erf.erfcc(-2.0E-323 ) ;
  }

  @Test
  public void test2() {
    erf.erfcc(2.7148889690176077 ) ;
  }

  @Test
  public void test3() {
    erf.erfcc(-44.15315947942069 ) ;
  }

  @Test
  public void test4() {
    erf.erfcc(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test5() {
    erf.erfcc(49.812220679962905 ) ;
  }

  @Test
  public void test6() {
    erf.erfcc(-52.18143629887309 ) ;
  }

  @Test
  public void test7() {
    erf.erfcc(58.46028187878346 ) ;
  }

  @Test
  public void test8() {
    erf.erfcc(-61.50019291642745 ) ;
  }

  @Test
  public void test9() {
    erf.erfcc(7.4E-323 ) ;
  }

  @Test
  public void test10() {
    erf.erfcc(-9.860761315262648E-32 ) ;
  }

  @Test
  public void test11() {
    erf.erfcc(9.860761315262648E-32 ) ;
  }
}
