import org.junit.Test;

public class TestbetaTest {

  @Test
  public void test0() {
    beta.beta(14.885494339713674,0 ) ;
  }

  @Test
  public void test1() {
    beta.beta(-16.339149698995456,0 ) ;
  }

  @Test
  public void test2() {
    beta.beta(-2.0,0 ) ;
  }

  @Test
  public void test3() {
    beta.beta(-3.0,0 ) ;
  }

  @Test
  public void test4() {
    beta.beta(-4.45600994093995,0 ) ;
  }

  @Test
  public void test5() {
    beta.beta(-98.038897218096,0 ) ;
  }
}
