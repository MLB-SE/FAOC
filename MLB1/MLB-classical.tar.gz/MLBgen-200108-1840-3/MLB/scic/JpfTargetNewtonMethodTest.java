import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(-25.750000000000522,-29.024086085819235 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(-36.67265235007091,32.19622005718978 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(-44.25,0 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(-46.54140328855999,1.487132403187836 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(49.05854731853452,-51.58153400962089 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(51.9177643034657,0 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonMethod.newton(-58.846071812117586,-91.53319503879503 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonMethod.newton(-78.88556589337172,0.15385107526530817 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonMethod.newton(-81.4217151539961,0 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonMethod.newton(-81.75,0.0 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonMethod.newton(88.23429688644251,0 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonMethod.newton(-88.9667023688343,74.17994418986746 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonMethod.newton(94.97488038589158,0 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonMethod.newton(-99.75,19.54991602041677 ) ;
  }
}
