import org.junit.Test;

public class JpfTargetEulerMethodTest {

  @Test
  public void test0() {
    scic.EulerMethod.euler(-1.9946221946070222 ) ;
  }

  @Test
  public void test1() {
    scic.EulerMethod.euler(39.476030901335236 ) ;
  }

  @Test
  public void test2() {
    scic.EulerMethod.euler(-9.653764123710502 ) ;
  }
}
