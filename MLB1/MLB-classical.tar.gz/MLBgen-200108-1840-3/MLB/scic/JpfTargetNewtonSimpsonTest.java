import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(-0.6986395204924492,0 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(11.2474616213984,77.349662332359 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(-12.252581220843567,0 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(1.2595669974600128,0.08086994069447284 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(15.97044098508708,0 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(1.6317647165004985,-69.59011181842655 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonSimpson.newton(1.733722563190753,-1.6570946945797118 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonSimpson.newton(-18.790758307209288,53.87784026505125 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonSimpson.newton(2.003094090872139,0 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonSimpson.newton(-20.501221308904974,0 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonSimpson.newton(-20.681480899535387,46.70676248657975 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonSimpson.newton(-20.84452945018107,0 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonSimpson.newton(2.303887906166736,0 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonSimpson.newton(2.842396878414604,0 ) ;
  }

  @Test
  public void test14() {
    scic.NewtonSimpson.newton(29.55803660283081,0 ) ;
  }

  @Test
  public void test15() {
    scic.NewtonSimpson.newton(-38.84876573915672,0 ) ;
  }
}
