import org.junit.Test;

public class JpfTargetRungeKuttaTest {

  @Test
  public void test0() {
    scic.RungeKutta.rungeKutta(-22.301919738337347 ) ;
  }

  @Test
  public void test1() {
    scic.RungeKutta.rungeKutta(-25.234021108627218 ) ;
  }

  @Test
  public void test2() {
    scic.RungeKutta.rungeKutta(2707.748590811217 ) ;
  }

  @Test
  public void test3() {
    scic.RungeKutta.rungeKutta(2723.4551513507713 ) ;
  }

  @Test
  public void test4() {
    scic.RungeKutta.rungeKutta(2723.7071036025236 ) ;
  }

  @Test
  public void test5() {
    scic.RungeKutta.rungeKutta(2740.951359175216 ) ;
  }

  @Test
  public void test6() {
    scic.RungeKutta.rungeKutta(54.30407027886531 ) ;
  }

  @Test
  public void test7() {
    scic.RungeKutta.rungeKutta(-57.420726959100875 ) ;
  }

  @Test
  public void test8() {
    scic.RungeKutta.rungeKutta(8.268243266917779 ) ;
  }

  @Test
  public void test9() {
    scic.RungeKutta.rungeKutta(83.80985901870008 ) ;
  }

  @Test
  public void test10() {
    scic.RungeKutta.rungeKutta(87.13439088846155 ) ;
  }

  @Test
  public void test11() {
    scic.RungeKutta.rungeKutta(87.24684870475164 ) ;
  }

  @Test
  public void test12() {
    scic.RungeKutta.rungeKutta(87.60421942794065 ) ;
  }

  @Test
  public void test13() {
    scic.RungeKutta.rungeKutta(89.25015898267091 ) ;
  }

  @Test
  public void test14() {
    scic.RungeKutta.rungeKutta(91.00474409847448 ) ;
  }

  @Test
  public void test15() {
    scic.RungeKutta.rungeKutta(91.96890258730122 ) ;
  }

  @Test
  public void test16() {
    scic.RungeKutta.rungeKutta(-92.16014995580393 ) ;
  }

  @Test
  public void test17() {
    scic.RungeKutta.rungeKutta(92.21452043660784 ) ;
  }
}
