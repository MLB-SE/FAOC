import org.junit.Test;

public class JpfTargetCubedRootTest {

  @Test
  public void test0() {
    scic.CubedRoot.check(24.998540136119132 ) ;
  }

  @Test
  public void test1() {
    scic.CubedRoot.check(48.54079230633462 ) ;
  }

  @Test
  public void test2() {
    scic.CubedRoot.check(6.966171382699102 ) ;
  }
}
