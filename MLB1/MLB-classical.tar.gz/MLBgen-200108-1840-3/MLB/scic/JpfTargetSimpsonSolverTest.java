import org.junit.Test;

public class JpfTargetSimpsonSolverTest {

  @Test
  public void test0() {
    scic.SimpsonSolver.simpson(-22.088864096068907,24.799983657142267 ) ;
  }

  @Test
  public void test1() {
    scic.SimpsonSolver.simpson(-50.36305043423008,84.90669462786713 ) ;
  }

  @Test
  public void test2() {
    scic.SimpsonSolver.simpson(-74.30593108938217,73.91977012358143 ) ;
  }
}
