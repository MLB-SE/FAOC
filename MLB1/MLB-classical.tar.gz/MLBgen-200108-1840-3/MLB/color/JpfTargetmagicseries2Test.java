import org.junit.Test;

public class JpfTargetmagicseries2Test {

  @Test
  public void test0() {
    color.magicseries.solve2(0,0,2,-1181 ) ;
  }

  @Test
  public void test1() {
    color.magicseries.solve2(0,2,0,2 ) ;
  }

  @Test
  public void test2() {
    color.magicseries.solve2(0,2,-967,0 ) ;
  }

  @Test
  public void test3() {
    color.magicseries.solve2(0,4,2,0 ) ;
  }

  @Test
  public void test4() {
    color.magicseries.solve2(2,0,0,2 ) ;
  }

  @Test
  public void test5() {
    color.magicseries.solve2(2,1,41,0 ) ;
  }

  @Test
  public void test6() {
    color.magicseries.solve2(2,1,900,0 ) ;
  }

  @Test
  public void test7() {
    color.magicseries.solve2(2,-243,0,0 ) ;
  }

  @Test
  public void test8() {
    color.magicseries.solve2(296,0,0,0 ) ;
  }

  @Test
  public void test9() {
    color.magicseries.solve2(3,225,0,0 ) ;
  }

  @Test
  public void test10() {
    color.magicseries.solve2(3,3,3,373 ) ;
  }

  @Test
  public void test11() {
    color.magicseries.solve2(3,3,4,0 ) ;
  }

  @Test
  public void test12() {
    color.magicseries.solve2(4,0,0,0 ) ;
  }

  @Test
  public void test13() {
    color.magicseries.solve2(4,0,1,2 ) ;
  }

  @Test
  public void test14() {
    color.magicseries.solve2(4,0,4,815 ) ;
  }

  @Test
  public void test15() {
    color.magicseries.solve2(4,1,0,1 ) ;
  }

  @Test
  public void test16() {
    color.magicseries.solve2(4,4,0,0 ) ;
  }

  @Test
  public void test17() {
    color.magicseries.solve2(4,405,0,0 ) ;
  }

  @Test
  public void test18() {
    color.magicseries.solve2(-667,0,0,0 ) ;
  }

  @Test
  public void test19() {
    color.magicseries.solve2(891,0,0,0 ) ;
  }
}
