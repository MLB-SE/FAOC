import org.junit.Test;

public class JpfTargetlaplaceTest {

  @Test
  public void test0() {
    color.laplace.solve(-0.07039739f,-10.231993f,-64.14764f,-90.0496f,-76.70994f,-22.681717f,-30.004736f,-29.969353f,-13.16276f ) ;
  }

  @Test
  public void test1() {
    color.laplace.solve(0.07237665f,-56.445343f,-132.3526f,-43.23236f,-193.48984f,5.41475f,9.802774f,81.98146f,-120.733986f ) ;
  }

  @Test
  public void test2() {
    color.laplace.solve(-0.37354442f,-39.03557f,-0.6430003f,-62.45861f,79.64468f,0f,52.445786f,0f,0f ) ;
  }

  @Test
  public void test3() {
    color.laplace.solve(-100.0f,100.0f,0f,1.8643869f,-100.0f,0f,-9.504871f,-39.883873f,100.0f ) ;
  }

  @Test
  public void test4() {
    color.laplace.solve(-100.0f,-100.0f,0f,-47.150257f,-56.52568f,-6.0847783f,-32.075344f,-81.151115f,0f ) ;
  }

  @Test
  public void test5() {
    color.laplace.solve(-100.0f,-62.047543f,90.74734f,-33.794113f,-24.156466f,9.501649f,-11.019993f,-10.285856f,-28.584278f ) ;
  }

  @Test
  public void test6() {
    color.laplace.solve(10.014462f,-47.245525f,-1.9184849f,10.696874f,6.3495355f,-30.606829f,26.423498f,92.55362f,-50.61531f ) ;
  }

  @Test
  public void test7() {
    color.laplace.solve(10.374811f,29.74418f,-43.828415f,-88.244934f,52.43032f,-45.96452f,18.689661f,0f,0f ) ;
  }

  @Test
  public void test8() {
    color.laplace.solve(105.83152f,102.05639f,65.61676f,19.520845f,3.2759423f,30.53232f,-31.105556f,-140.98518f,52.83134f ) ;
  }

  @Test
  public void test9() {
    color.laplace.solve(10.6173115f,-99.62491f,0f,-2.1540532f,-22.386856f,-13.263925f,3.1533318f,14.767381f,78.30305f ) ;
  }

  @Test
  public void test10() {
    color.laplace.solve(11.13706f,-49.315468f,-76.64942f,-6.1362896f,-49.44262f,-42.318714f,13.760399f,-100.0f,-93.208115f ) ;
  }

  @Test
  public void test11() {
    color.laplace.solve(1.1250004f,-129.23358f,0f,-3.3864903f,40.12834f,0f,2.555647f,13.609077f,11.752322f ) ;
  }

  @Test
  public void test12() {
    color.laplace.solve(-11.410095f,-62.774162f,0f,22.289093f,32.57682f,0f,2.86875f,-10.814093f,-78.70194f ) ;
  }

  @Test
  public void test13() {
    color.laplace.solve(11.616677f,-3.2008123f,-43.2013f,-0.6386106f,-13.554684f,-48.552177f,-0.61643595f,-1.8271332f,58.274666f ) ;
  }

  @Test
  public void test14() {
    color.laplace.solve(-11.699492f,-21.196716f,48.352455f,-16.86415f,-32.638954f,-16.88649f,-23.118153f,-75.60846f,-83.25945f ) ;
  }

  @Test
  public void test15() {
    color.laplace.solve(-11.720618f,-1.6737841f,0f,6.5267706f,18.039143f,27.437407f,19.788557f,72.62746f,4.1090817f ) ;
  }

  @Test
  public void test16() {
    color.laplace.solve(11.8405f,-22.992985f,11.288259f,-33.090298f,-214.72119f,-32.00192f,-15.167042f,-27.54409f,-90.66f ) ;
  }

  @Test
  public void test17() {
    color.laplace.solve(-1.2203023f,-100.0f,0f,-13.324367f,-62.534027f,37.62925f,10.456864f,55.15182f,-54.319225f ) ;
  }

  @Test
  public void test18() {
    color.laplace.solve(12.385784f,-55.71258f,0f,5.9978356f,13.597635f,-100.0f,-1.992076f,-13.96614f,-67.470116f ) ;
  }

  @Test
  public void test19() {
    color.laplace.solve(12.991045f,-51.461823f,2.7195907f,3.4259999f,8.772311f,0f,0.076287195f,-3.1208513f,-21.332003f ) ;
  }

  @Test
  public void test20() {
    color.laplace.solve(13.249012f,98.607315f,0f,56.64719f,-83.08848f,0f,20.470346f,25.234192f,78.95907f ) ;
  }

  @Test
  public void test21() {
    color.laplace.solve(13.351157f,20.621607f,-14.611959f,-58.790325f,-13.700858f,-180.206f,-15.418147f,-7.351933f,1.8993852f ) ;
  }

  @Test
  public void test22() {
    color.laplace.solve(14.387764f,-205.48682f,-8.888505f,-11.313944f,-53.718437f,16.589582f,-5.6850195f,-13.765608f,1.2692765f ) ;
  }

  @Test
  public void test23() {
    color.laplace.solve(14.688778f,57.961273f,17.687368f,-99.25141f,99.46895f,-87.18281f,-43.630703f,-75.12049f,13.877053f ) ;
  }

  @Test
  public void test24() {
    color.laplace.solve(14.973082f,30.678831f,19.255064f,-70.78651f,-11.512823f,4.7798576f,0f,0f,0f ) ;
  }

  @Test
  public void test25() {
    color.laplace.solve(15.175613f,18.371433f,0f,0.51953965f,16.495289f,-72.40827f,-29.592745f,59.72665f,0f ) ;
  }

  @Test
  public void test26() {
    color.laplace.solve(1.5340338f,98.06547f,0f,-19.775394f,-61.323914f,0f,3.614924f,34.235092f,96.3607f ) ;
  }

  @Test
  public void test27() {
    color.laplace.solve(155.733f,98.14416f,0f,58.847595f,63.527763f,-66.824684f,15.833872f,3.149333f,-66.77251f ) ;
  }

  @Test
  public void test28() {
    color.laplace.solve(15.6502285f,-72.97238f,0f,11.818738f,28.042925f,0f,3.581798f,2.5084546f,-11.727434f ) ;
  }

  @Test
  public void test29() {
    color.laplace.solve(15.810811f,3.0186577f,-52.295677f,-39.775414f,-51.440502f,-100.0f,-17.842607f,-31.595018f,-57.096962f ) ;
  }

  @Test
  public void test30() {
    color.laplace.solve(15.876848f,-31.955286f,-3.5248563f,-4.53732f,-46.682796f,43.358982f,12.656668f,55.16399f,-73.53912f ) ;
  }

  @Test
  public void test31() {
    color.laplace.solve(15.951548f,45.037853f,0f,12.95974f,29.526344f,48.812878f,6.3610654f,12.484523f,14.05068f ) ;
  }

  @Test
  public void test32() {
    color.laplace.solve(16.109133f,-65.18214f,28.774708f,-0.8755379f,-16.510015f,11.547144f,-3.1012688f,-11.529537f,33.92388f ) ;
  }

  @Test
  public void test33() {
    color.laplace.solve(16.206459f,35.74246f,58.87278f,-70.91662f,37.200535f,0f,1.493979f,76.89253f,64.88958f ) ;
  }

  @Test
  public void test34() {
    color.laplace.solve(16.285336f,-29.020191f,99.998856f,-5.838457f,-34.14537f,-83.49493f,-5.493794f,-16.136732f,-24.907915f ) ;
  }

  @Test
  public void test35() {
    color.laplace.solve(16.475079f,-56.193867f,0f,-2.0442076f,-18.953278f,20.723665f,-5.6986313f,-20.750319f,-58.34936f ) ;
  }

  @Test
  public void test36() {
    color.laplace.solve(-1.7076801f,33.791702f,0f,65.743744f,53.77238f,17.498932f,17.102493f,2.666228f,-60.20996f ) ;
  }

  @Test
  public void test37() {
    color.laplace.solve(17.158949f,-41.868458f,2.9159591f,10.504254f,21.85577f,-3.6395185f,3.0022988f,1.5049411f,-18.838305f ) ;
  }

  @Test
  public void test38() {
    color.laplace.solve(-1.7259816f,-99.91736f,-69.20337f,-10.627274f,-35.761642f,-23.043339f,-5.021469f,-9.458604f,2.9486985f ) ;
  }

  @Test
  public void test39() {
    color.laplace.solve(17.712942f,-26.974571f,-14.470756f,-2.1736634f,-14.294271f,4.1915956f,-12.113324f,-32.220448f,45.531406f ) ;
  }

  @Test
  public void test40() {
    color.laplace.solve(17.97475f,8.167961f,-49.1132f,-36.268963f,-82.58365f,-48.117676f,-80.46695f,10.140435f,0f ) ;
  }

  @Test
  public void test41() {
    color.laplace.solve(18.046703f,-31.789064f,-50.644653f,3.9761639f,-6.7732296f,-13.829052f,4.631182f,14.548838f,2.1016748f ) ;
  }

  @Test
  public void test42() {
    color.laplace.solve(18.601463f,-0.44617173f,32.48271f,-25.047813f,-152.76927f,30.377016f,-15.381007f,-36.476215f,106.60363f ) ;
  }

  @Test
  public void test43() {
    color.laplace.solve(18.698858f,-4.527075f,18.346159f,-20.67749f,20.903507f,0f,-11.56423f,-25.579432f,0f ) ;
  }

  @Test
  public void test44() {
    color.laplace.solve(-19.089771f,54.485764f,25.141087f,-18.700506f,-7.535833f,-6.9146028f,-48.176426f,-59.013985f,-45.263664f ) ;
  }

  @Test
  public void test45() {
    color.laplace.solve(19.10695f,-28.889885f,53.610146f,5.317688f,22.171593f,58.12131f,-20.007792f,54.137253f,0f ) ;
  }

  @Test
  public void test46() {
    color.laplace.solve(19.13996f,-99.9755f,-6.3061852f,-8.303025f,-42.823883f,-33.20732f,-9.528176f,-29.80968f,-100.0f ) ;
  }

  @Test
  public void test47() {
    color.laplace.solve(19.236214f,0.81616825f,16.546968f,-23.871313f,-99.842f,-92.976494f,-14.879462f,-35.646534f,-27.864676f ) ;
  }

  @Test
  public void test48() {
    color.laplace.solve(19.904318f,20.836414f,98.29402f,-41.219143f,-85.361984f,49.006607f,-16.340527f,-24.142967f,5.130647f ) ;
  }

  @Test
  public void test49() {
    color.laplace.solve(20.002653f,70.16245f,95.97824f,-90.15184f,64.66891f,-45.013485f,-20.105642f,9.729266f,14.115024f ) ;
  }

  @Test
  public void test50() {
    color.laplace.solve(20.810898f,52.357018f,35.744183f,-69.11343f,52.87299f,-9.380283f,0f,0f,0f ) ;
  }

  @Test
  public void test51() {
    color.laplace.solve(21.124338f,20.996937f,-22.300512f,-36.087593f,-14.7054205f,35.068394f,-151.6154f,-78.55877f,0f ) ;
  }

  @Test
  public void test52() {
    color.laplace.solve(21.127504f,-28.311861f,-47.003098f,12.821876f,25.50803f,0f,4.651968f,0f,0f ) ;
  }

  @Test
  public void test53() {
    color.laplace.solve(21.3376f,15.145752f,39.245403f,-29.795347f,-100.0f,41.83587f,-86.73773f,14.004799f,0f ) ;
  }

  @Test
  public void test54() {
    color.laplace.solve(21.353056f,-45.13603f,-29.046785f,30.54825f,72.630745f,71.004f,28.209206f,82.28857f,0f ) ;
  }

  @Test
  public void test55() {
    color.laplace.solve(21.43925f,2.6105843f,-204.05518f,-17.143253f,7.845836f,-53.57507f,-98.3956f,100.0f,-1.9181606f ) ;
  }

  @Test
  public void test56() {
    color.laplace.solve(21.46208f,12.905855f,-72.93124f,-27.057539f,-100.0f,0f,-31.704176f,-99.75916f,0f ) ;
  }

  @Test
  public void test57() {
    color.laplace.solve(21.522707f,-106.7844f,12.60157f,-7.107065f,-66.240875f,-4.2147145f,16.288399f,-147.20018f,37.694622f ) ;
  }

  @Test
  public void test58() {
    color.laplace.solve(21.581995f,-13.603234f,4.9658837f,-0.08044792f,-26.141163f,-59.89565f,4.237377f,-30.985323f,-37.759506f ) ;
  }

  @Test
  public void test59() {
    color.laplace.solve(21.84536f,-12.340237f,27.439215f,-0.27832267f,-43.39621f,81.4884f,20.43756f,82.02856f,0f ) ;
  }

  @Test
  public void test60() {
    color.laplace.solve(21.863655f,21.793716f,39.203693f,-34.339096f,-73.89249f,38.004925f,-85.32755f,0f,0f ) ;
  }

  @Test
  public void test61() {
    color.laplace.solve(223.2824f,63.000626f,198.49814f,59.435505f,10.622249f,-35.82982f,3.8223429f,-44.146133f,-164.40099f ) ;
  }

  @Test
  public void test62() {
    color.laplace.solve(22.909029f,-25.563835f,37.068325f,17.199951f,21.528227f,0f,15.0282345f,42.912987f,0f ) ;
  }

  @Test
  public void test63() {
    color.laplace.solve(22.940458f,-16.630405f,19.60379f,8.392235f,4.7114873f,-8.530214f,5.9169936f,35.614334f,-18.14908f ) ;
  }

  @Test
  public void test64() {
    color.laplace.solve(22.97257f,-16.662958f,-37.01734f,8.553241f,-78.01882f,-45.878784f,-4.1009903f,-24.957201f,-17.708996f ) ;
  }

  @Test
  public void test65() {
    color.laplace.solve(23.415337f,-10.166429f,-70.09545f,7.9150133f,11.743538f,71.135864f,-3.4988217f,-21.910301f,94.953926f ) ;
  }

  @Test
  public void test66() {
    color.laplace.solve(23.668695f,-27.944319f,52.656025f,22.619097f,30.268162f,38.94148f,36.539528f,87.4564f,72.84172f ) ;
  }

  @Test
  public void test67() {
    color.laplace.solve(24.097197f,21.57793f,45.342583f,-25.189146f,-83.12805f,-80.95586f,-14.371217f,-32.29572f,-31.683609f ) ;
  }

  @Test
  public void test68() {
    color.laplace.solve(-24.557362f,-64.09279f,-1.7614533f,5.3692203f,0.20690705f,2.9410605f,45.827335f,56.610138f,13.318789f ) ;
  }

  @Test
  public void test69() {
    color.laplace.solve(-24.565086f,100.0f,0f,-61.11475f,53.176437f,-70.532875f,-17.984945f,-10.82503f,-78.491615f ) ;
  }

  @Test
  public void test70() {
    color.laplace.solve(24.665419f,86.15788f,0f,-78.88727f,-32.876934f,0f,-45.0386f,19.227602f,0f ) ;
  }

  @Test
  public void test71() {
    color.laplace.solve(24.740765f,10.875253f,-53.82199f,-11.912198f,-27.417763f,45.086243f,-3.5733516f,-2.3812082f,21.466282f ) ;
  }

  @Test
  public void test72() {
    color.laplace.solve(24.82196f,27.19536f,47.83879f,-27.907518f,-63.879307f,-8.366579f,-46.046772f,-51.049904f,0f ) ;
  }

  @Test
  public void test73() {
    color.laplace.solve(25.108038f,47.34187f,42.637135f,-46.909718f,21.622305f,23.77731f,-16.307077f,-18.318594f,-78.5896f ) ;
  }

  @Test
  public void test74() {
    color.laplace.solve(25.324013f,-61.628185f,-54.024796f,62.92424f,9.117772f,0f,16.13916f,1.6324031f,-10.510024f ) ;
  }

  @Test
  public void test75() {
    color.laplace.solve(-2.5409915f,-73.04384f,-30.268553f,-38.612057f,-59.306335f,-25.569437f,-92.6009f,-100.0f,-12.702859f ) ;
  }

  @Test
  public void test76() {
    color.laplace.solve(25.455364f,18.862043f,28.069153f,-17.040588f,-78.07634f,-11.59645f,27.349113f,-2.3371747f,0f ) ;
  }

  @Test
  public void test77() {
    color.laplace.solve(25.52034f,-17.415764f,-39.698357f,19.497122f,-4.530768f,3.7794678f,56.998917f,-23.983898f,15.730607f ) ;
  }

  @Test
  public void test78() {
    color.laplace.solve(25.978315f,21.11405f,32.57232f,-17.200785f,-74.09444f,9.17522f,-20.687021f,-65.5473f,0f ) ;
  }

  @Test
  public void test79() {
    color.laplace.solve(26.069729f,49.636936f,98.05592f,-45.358017f,-25.57791f,-99.99999f,-20.42357f,-36.336266f,-99.34358f ) ;
  }

  @Test
  public void test80() {
    color.laplace.solve(26.072893f,16.113068f,21.55653f,-11.821499f,-83.177155f,-29.886948f,11.871634f,59.308033f,0f ) ;
  }

  @Test
  public void test81() {
    color.laplace.solve(26.251143f,-23.776031f,0f,15.377691f,31.527246f,13.199603f,3.7323756f,-0.44818866f,-37.184868f ) ;
  }

  @Test
  public void test82() {
    color.laplace.solve(26.270855f,0.5964211f,71.30332f,1.612692f,27.275333f,28.991674f,-47.09542f,77.90054f,24.942144f ) ;
  }

  @Test
  public void test83() {
    color.laplace.solve(26.307638f,-55.423782f,29.306051f,60.65433f,40.176937f,0f,-90.64003f,0f,0f ) ;
  }

  @Test
  public void test84() {
    color.laplace.solve(-2.645678f,58.102818f,0f,-23.0327f,-67.8384f,88.29454f,-21.646717f,-63.554165f,-36.70931f ) ;
  }

  @Test
  public void test85() {
    color.laplace.solve(26.5424f,47.362217f,-25.73204f,-41.192616f,88.63851f,-46.986828f,-4.8646483f,21.734022f,25.069496f ) ;
  }

  @Test
  public void test86() {
    color.laplace.solve(26.61265f,15.993493f,-39.731182f,-9.542894f,-47.55245f,-90.044815f,-17.231781f,-59.384228f,0f ) ;
  }

  @Test
  public void test87() {
    color.laplace.solve(26.903736f,22.865839f,-38.365257f,-15.250897f,2.476244f,0.11446504f,-90.38357f,2.1755686f,36.34687f ) ;
  }

  @Test
  public void test88() {
    color.laplace.solve(27.01205f,5.5733266f,-77.50854f,2.4748788f,-27.21021f,98.37944f,-3.9793317f,-18.392206f,-42.37928f ) ;
  }

  @Test
  public void test89() {
    color.laplace.solve(27.17387f,-1.0745163f,-99.038994f,9.769997f,9.142741f,21.599396f,2.7633767f,1.2835101f,5.94014f ) ;
  }

  @Test
  public void test90() {
    color.laplace.solve(-27.388927f,33.65373f,0f,-14.423643f,-21.094292f,92.18057f,-9.211351f,-22.421762f,-59.38141f ) ;
  }

  @Test
  public void test91() {
    color.laplace.solve(27.417059f,-0.7603779f,94.98145f,10.428615f,26.606081f,-55.3827f,3.7140212f,4.4274707f,-12.610221f ) ;
  }

  @Test
  public void test92() {
    color.laplace.solve(27.456388f,48.665913f,41.80702f,-38.840355f,25.400236f,6.4335084f,-8.47448f,4.9424367f,2.8439863f ) ;
  }

  @Test
  public void test93() {
    color.laplace.solve(27.549833f,19.81607f,-11.005f,-9.6167345f,-38.612587f,-66.96831f,-27.404184f,-100.0f,0f ) ;
  }

  @Test
  public void test94() {
    color.laplace.solve(-27.885397f,-8.889626f,63.493984f,-3.3485303f,13.393441f,58.073166f,1.0978342f,7.7359943f,16.45229f ) ;
  }

  @Test
  public void test95() {
    color.laplace.solve(27.916126f,21.984808f,24.962793f,-10.320304f,-64.93969f,-99.99966f,-10.2340975f,-30.616085f,-47.290558f ) ;
  }

  @Test
  public void test96() {
    color.laplace.solve(28.017744f,23.246054f,-34.78493f,-11.175077f,3.1519957f,100.0f,-75.87005f,-36.23114f,0f ) ;
  }

  @Test
  public void test97() {
    color.laplace.solve(28.160267f,-2.0496745f,47.427246f,14.6907425f,20.5372f,43.756744f,10.110434f,25.750992f,100.0f ) ;
  }

  @Test
  public void test98() {
    color.laplace.solve(28.345535f,14.866669f,-62.798214f,-1.4845243f,-22.602327f,-94.48615f,-11.681306f,-9.305302f,77.690765f ) ;
  }

  @Test
  public void test99() {
    color.laplace.solve(28.359112f,-3.988101f,-60.90573f,17.42455f,-4.0287137f,-63.151836f,45.367794f,27.669048f,0f ) ;
  }

  @Test
  public void test100() {
    color.laplace.solve(28.939709f,15.849916f,-51.465687f,-0.0910821f,-15.384534f,-21.710041f,-13.919503f,-55.58693f,41.63904f ) ;
  }

  @Test
  public void test101() {
    color.laplace.solve(29.217129f,43.17497f,3.3493931f,-26.306454f,-59.96686f,0f,62.141758f,23.200676f,0f ) ;
  }

  @Test
  public void test102() {
    color.laplace.solve(-29.293222f,-38.703735f,-58.38887f,-16.002268f,-26.072044f,-31.009222f,-8.6438055f,-18.572956f,-39.57597f ) ;
  }

  @Test
  public void test103() {
    color.laplace.solve(29.348207f,-36.035164f,57.37233f,53.427994f,-100.0f,-100.0f,9.795112f,-14.247546f,33.214706f ) ;
  }

  @Test
  public void test104() {
    color.laplace.solve(29.405027f,13.170366f,-75.69194f,4.4497447f,-5.1181655f,-19.271376f,-6.4878836f,-51.103394f,0f ) ;
  }

  @Test
  public void test105() {
    color.laplace.solve(29.470041f,-11.304665f,10.87933f,29.18483f,72.909035f,-11.744475f,14.360242f,28.256138f,-38.3593f ) ;
  }

  @Test
  public void test106() {
    color.laplace.solve(30.063414f,-9.960707f,6.5202684f,30.214363f,-7.348696f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test107() {
    color.laplace.solve(30.088238f,44.3263f,74.70388f,-23.973349f,90.86465f,0f,-56.486065f,-10.728077f,0f ) ;
  }

  @Test
  public void test108() {
    color.laplace.solve(30.10496f,45.009026f,85.615524f,-24.589186f,-35.68439f,-46.117165f,-67.88111f,0f,0f ) ;
  }

  @Test
  public void test109() {
    color.laplace.solve(30.128458f,-78.51511f,0f,8.968576f,-41.39292f,7.161905f,47.13877f,69.78408f,0f ) ;
  }

  @Test
  public void test110() {
    color.laplace.solve(30.501625f,71.930695f,75.553734f,-49.924202f,81.667435f,100.0f,-31.975744f,-77.978775f,0f ) ;
  }

  @Test
  public void test111() {
    color.laplace.solve(30.625587f,11.534554f,69.41367f,10.967798f,-7.216524f,35.419785f,20.46213f,-55.689396f,0f ) ;
  }

  @Test
  public void test112() {
    color.laplace.solve(30.691004f,5.189719f,22.360142f,11.544209f,10.148724f,14.056742f,5.337108f,9.804225f,23.718102f ) ;
  }

  @Test
  public void test113() {
    color.laplace.solve(-31.032555f,29.820295f,0f,-8.295545f,-4.4004188f,-55.53287f,2.2507956f,17.298727f,0f ) ;
  }

  @Test
  public void test114() {
    color.laplace.solve(31.272589f,22.282839f,-37.29377f,2.8075135f,-4.8474627f,43.922947f,-15.195072f,-49.991035f,0f ) ;
  }

  @Test
  public void test115() {
    color.laplace.solve(-3.139012f,-91.61791f,85.830215f,-20.938137f,-85.46588f,0f,24.384043f,-97.81905f,0f ) ;
  }

  @Test
  public void test116() {
    color.laplace.solve(31.660252f,99.53005f,-48.835033f,5.2440763f,8.45499f,10.845655f,-19.138937f,-81.79983f,83.762665f ) ;
  }

  @Test
  public void test117() {
    color.laplace.solve(31.69395f,18.428532f,36.037857f,8.34727f,-94.017685f,-100.0f,31.020256f,-57.638794f,0f ) ;
  }

  @Test
  public void test118() {
    color.laplace.solve(31.774067f,17.506653f,7.749699f,9.589618f,-0.28851235f,-42.28659f,6.8729143f,17.902039f,65.02376f ) ;
  }

  @Test
  public void test119() {
    color.laplace.solve(31.809275f,12.707584f,-68.392845f,14.529518f,-15.059623f,-53.727146f,41.36842f,-45.362022f,0f ) ;
  }

  @Test
  public void test120() {
    color.laplace.solve(31.984493f,100.0f,54.142822f,-72.06203f,-81.18464f,0f,-100.0f,-45.017296f,0f ) ;
  }

  @Test
  public void test121() {
    color.laplace.solve(32.066998f,100.0f,0f,-98.97612f,12.34738f,0f,-1.4328866f,93.244576f,-97.995415f ) ;
  }

  @Test
  public void test122() {
    color.laplace.solve(32.247597f,-100.0f,0f,-47.014133f,-97.81471f,-60.412384f,-20.658628f,-35.620384f,-24.008192f ) ;
  }

  @Test
  public void test123() {
    color.laplace.solve(32.45434f,21.170162f,-99.999954f,8.647199f,12.104007f,67.12408f,-9.969553f,-48.52541f,14.830395f ) ;
  }

  @Test
  public void test124() {
    color.laplace.solve(32.606823f,43.58354f,-47.727196f,-13.156244f,89.45454f,-50.116753f,-39.05749f,17.655336f,0f ) ;
  }

  @Test
  public void test125() {
    color.laplace.solve(32.689167f,8.3501005f,-27.767698f,22.406563f,-71.521065f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test126() {
    color.laplace.solve(32.76927f,24.12939f,-35.96136f,6.947692f,-0.29035017f,-99.54831f,-4.688153f,-25.700302f,0f ) ;
  }

  @Test
  public void test127() {
    color.laplace.solve(32.772625f,54.117786f,45.87811f,-23.027292f,37.82041f,28.62883f,-1.4221447f,17.338713f,32.956585f ) ;
  }

  @Test
  public void test128() {
    color.laplace.solve(32.901695f,31.058102f,43.022957f,0.54867965f,-51.69224f,15.264829f,-10.677639f,-43.259235f,0f ) ;
  }

  @Test
  public void test129() {
    color.laplace.solve(32.951492f,23.730816f,-56.207485f,8.075148f,18.179258f,-35.889023f,-0.633423f,-10.60884f,0f ) ;
  }

  @Test
  public void test130() {
    color.laplace.solve(32.970043f,43.77975f,99.575165f,-11.899582f,-57.426212f,100.0f,5.216766f,32.766647f,100.0f ) ;
  }

  @Test
  public void test131() {
    color.laplace.solve(33.013428f,65.654884f,29.612675f,-33.601177f,99.99344f,-47.20419f,-23.22727f,-60.51108f,0f ) ;
  }

  @Test
  public void test132() {
    color.laplace.solve(3.3033571f,-72.38227f,-51.5131f,-14.404299f,-53.75671f,-34.855797f,-7.16384f,-14.251061f,5.689389f ) ;
  }

  @Test
  public void test133() {
    color.laplace.solve(33.159874f,26.375212f,-31.936987f,6.264289f,4.277956f,-29.541594f,-12.596223f,-58.500385f,0f ) ;
  }

  @Test
  public void test134() {
    color.laplace.solve(33.164722f,34.907124f,-4.3351464f,-2.2482285f,-30.585876f,0f,14.8822155f,61.777092f,96.89426f ) ;
  }

  @Test
  public void test135() {
    color.laplace.solve(-33.38001f,42.601f,-38.626945f,0.95992345f,14.275989f,64.10238f,22.943712f,-50.55935f,-29.66051f ) ;
  }

  @Test
  public void test136() {
    color.laplace.solve(33.38003f,30.332434f,-9.023406f,3.1876884f,-3.026888f,-39.400974f,-17.602388f,-73.59724f,68.24924f ) ;
  }

  @Test
  public void test137() {
    color.laplace.solve(33.99303f,-49.64704f,92.52692f,85.61917f,-80.921394f,0f,19.160599f,-8.976772f,-44.669483f ) ;
  }

  @Test
  public void test138() {
    color.laplace.solve(34.05796f,26.46567f,18.058107f,9.76617f,-46.25339f,-99.99852f,51.26011f,-26.967958f,0f ) ;
  }

  @Test
  public void test139() {
    color.laplace.solve(34.34186f,25.384756f,45.22576f,11.982687f,-78.028595f,55.518288f,-1.7299389f,-18.902443f,4.2482376f ) ;
  }

  @Test
  public void test140() {
    color.laplace.solve(34.620724f,55.67821f,27.464727f,-16.908535f,60.61071f,-45.83212f,-162.8519f,-8.357501f,0f ) ;
  }

  @Test
  public void test141() {
    color.laplace.solve(34.740578f,-47.273556f,0f,28.122307f,46.553703f,23.658182f,31.194942f,34.34412f,0f ) ;
  }

  @Test
  public void test142() {
    color.laplace.solve(-34.82572f,71.84167f,0f,-42.258133f,-35.097496f,0f,-23.233461f,-50.675716f,0f ) ;
  }

  @Test
  public void test143() {
    color.laplace.solve(34.943073f,51.588085f,98.78918f,-11.815794f,11.668568f,-20.764872f,-93.87482f,-12.7377825f,0f ) ;
  }

  @Test
  public void test144() {
    color.laplace.solve(35.04404f,-17.106142f,27.673983f,57.282303f,29.077835f,0f,-35.7294f,-43.259113f,0f ) ;
  }

  @Test
  public void test145() {
    color.laplace.solve(35.05209f,13.7688875f,-7.7447014f,26.439466f,46.80785f,73.15712f,23.897926f,73.86593f,-93.22862f ) ;
  }

  @Test
  public void test146() {
    color.laplace.solve(35.144646f,32.64851f,53.323547f,7.9300675f,-57.874146f,25.913902f,-16.01157f,52.534195f,0f ) ;
  }

  @Test
  public void test147() {
    color.laplace.solve(35.28893f,32.09777f,-40.65801f,9.057939f,0.66984826f,-60.28652f,0.27298003f,-7.9660187f,45.330135f ) ;
  }

  @Test
  public void test148() {
    color.laplace.solve(35.405945f,30.129425f,-20.736729f,11.494353f,5.848482f,-51.863472f,4.7229857f,7.397589f,13.842763f ) ;
  }

  @Test
  public void test149() {
    color.laplace.solve(35.534927f,-16.643995f,159.6754f,58.83661f,269.04517f,0f,29.04139f,57.152496f,83.46398f ) ;
  }

  @Test
  public void test150() {
    color.laplace.solve(35.653713f,24.615627f,-82.59793f,17.999228f,-11.195138f,46.755608f,3.1064131f,-5.5735745f,-14.205574f ) ;
  }

  @Test
  public void test151() {
    color.laplace.solve(35.706387f,39.90758f,69.4789f,2.9179714f,-45.554955f,-42.846416f,-10.986725f,-46.86487f,-20.259241f ) ;
  }

  @Test
  public void test152() {
    color.laplace.solve(35.802925f,46.599346f,39.336163f,-3.390346f,11.9367075f,10.742849f,-61.306103f,-6.205017f,-8.298434f ) ;
  }

  @Test
  public void test153() {
    color.laplace.solve(35.98395f,27.101011f,-73.38229f,16.834799f,45.003605f,0f,7.0557528f,11.388212f,35.532047f ) ;
  }

  @Test
  public void test154() {
    color.laplace.solve(36.002594f,99.98263f,4.104098f,24.38528f,51.03617f,3.9265416f,10.50236f,75.85022f,9.974341f ) ;
  }

  @Test
  public void test155() {
    color.laplace.solve(36.55086f,29.094662f,33.956875f,17.10878f,27.548326f,-100.0f,4.3359294f,0.23493773f,-30.944506f ) ;
  }

  @Test
  public void test156() {
    color.laplace.solve(36.743702f,31.119701f,74.51945f,15.8551f,-86.78434f,10.666976f,0.82216805f,-12.566427f,35.696465f ) ;
  }

  @Test
  public void test157() {
    color.laplace.solve(36.74547f,35.06497f,-31.799496f,11.916906f,11.785306f,-42.243576f,-0.8631506f,-15.369509f,-72.40019f ) ;
  }

  @Test
  public void test158() {
    color.laplace.solve(3.6812606f,0.46494073f,0f,-64.40894f,44.40547f,0f,-13.976145f,8.504366f,3.5881371f ) ;
  }

  @Test
  public void test159() {
    color.laplace.solve(36.980095f,30.611544f,19.290455f,17.308832f,-33.824375f,-53.449722f,-6.9966044f,-45.29525f,100.0f ) ;
  }

  @Test
  public void test160() {
    color.laplace.solve(37.307304f,5.9545712f,-64.81347f,43.27464f,-48.675552f,32.15142f,-86.278076f,0f,0f ) ;
  }

  @Test
  public void test161() {
    color.laplace.solve(37.513435f,26.464823f,-80.535324f,23.588917f,48.88118f,100.0f,7.961054f,22.887547f,0f ) ;
  }

  @Test
  public void test162() {
    color.laplace.solve(37.517666f,37.36356f,36.74899f,11.662692f,-25.517214f,-148.92235f,34.615242f,126.70932f,0f ) ;
  }

  @Test
  public void test163() {
    color.laplace.solve(37.519314f,34.37983f,-100.0f,15.697432f,100.0f,-100.0f,-74.72959f,-100.0f,0f ) ;
  }

  @Test
  public void test164() {
    color.laplace.solve(37.690773f,12.733044f,-54.65907f,38.03005f,-44.901665f,0f,100.0f,-100.0f,0f ) ;
  }

  @Test
  public void test165() {
    color.laplace.solve(37.768063f,-21.65271f,0f,-6.2437396f,-56.260323f,35.24344f,-6.4827f,17.445354f,0f ) ;
  }

  @Test
  public void test166() {
    color.laplace.solve(38.028267f,52.290184f,-32.055504f,-0.17711629f,-24.682913f,-85.73108f,-14.05382f,-56.038162f,-99.99996f ) ;
  }

  @Test
  public void test167() {
    color.laplace.solve(38.26976f,31.448565f,-42.43405f,21.87522f,29.955004f,11.7337f,19.27695f,55.232582f,59.413845f ) ;
  }

  @Test
  public void test168() {
    color.laplace.solve(38.460716f,-7.0720625f,-42.80895f,60.914925f,-10.86214f,0f,12.923342f,-9.221558f,-38.947433f ) ;
  }

  @Test
  public void test169() {
    color.laplace.solve(38.500076f,29.427612f,17.293798f,24.57269f,-38.083427f,-60.922234f,-79.95369f,0f,0f ) ;
  }

  @Test
  public void test170() {
    color.laplace.solve(38.64072f,62.54738f,99.89345f,-7.9845033f,11.655344f,37.821594f,-82.23408f,-45.763092f,92.795395f ) ;
  }

  @Test
  public void test171() {
    color.laplace.solve(38.890903f,-63.091984f,-57.095863f,21.42523f,-9.781124f,100.0f,56.591137f,-97.45774f,90.43784f ) ;
  }

  @Test
  public void test172() {
    color.laplace.solve(38.926678f,23.904964f,36.536095f,31.801746f,-79.84292f,-2.6322622f,-1.496277f,-37.786854f,-97.97292f ) ;
  }

  @Test
  public void test173() {
    color.laplace.solve(39.33888f,24.879385f,-36.68185f,32.47613f,-3.1394854f,-92.373985f,93.70514f,63.54982f,0f ) ;
  }

  @Test
  public void test174() {
    color.laplace.solve(39.537613f,31.730734f,1.8455682f,26.419714f,-14.460241f,0f,-32.282455f,89.799065f,0f ) ;
  }

  @Test
  public void test175() {
    color.laplace.solve(39.5484f,-85.35906f,0f,-58.666126f,-37.57369f,73.03755f,-18.621588f,-15.82023f,-7.085639f ) ;
  }

  @Test
  public void test176() {
    color.laplace.solve(40.259045f,32.6482f,14.84682f,28.387972f,-24.513058f,-73.26092f,97.8059f,-80.42185f,0f ) ;
  }

  @Test
  public void test177() {
    color.laplace.solve(40.481697f,43.42224f,40.19348f,18.504543f,-6.9862165f,10.128351f,40.522694f,-100.0f,-53.326584f ) ;
  }

  @Test
  public void test178() {
    color.laplace.solve(40.50836f,50.449207f,30.724894f,11.584235f,30.563578f,-27.549637f,14.957501f,48.24577f,100.0f ) ;
  }

  @Test
  public void test179() {
    color.laplace.solve(40.71897f,31.516834f,80.9571f,31.359053f,7.4679437f,17.077307f,77.2493f,44.334686f,0f ) ;
  }

  @Test
  public void test180() {
    color.laplace.solve(-40.81535f,-20.724562f,0f,-4.0907865f,-16.158318f,-26.787104f,40.61052f,45.045982f,0f ) ;
  }

  @Test
  public void test181() {
    color.laplace.solve(40.892876f,99.89016f,0f,4.320742f,22.246683f,0f,-45.856594f,0f,0f ) ;
  }

  @Test
  public void test182() {
    color.laplace.solve(41.0568f,71.36088f,-33.193916f,-7.1336756f,11.453022f,-3.7099733f,-81.044525f,-30.90407f,0f ) ;
  }

  @Test
  public void test183() {
    color.laplace.solve(41.238266f,55.76079f,53.873005f,9.192267f,27.931904f,59.731224f,-32.401096f,-12.956671f,0f ) ;
  }

  @Test
  public void test184() {
    color.laplace.solve(41.33479f,36.099678f,-10.324973f,29.239481f,69.024765f,47.74691f,13.614967f,25.220388f,18.241825f ) ;
  }

  @Test
  public void test185() {
    color.laplace.solve(41.39959f,46.491894f,16.046421f,19.10646f,28.521557f,-50.43066f,6.5044355f,6.9115005f,-7.379989f ) ;
  }

  @Test
  public void test186() {
    color.laplace.solve(41.400272f,37.158443f,-54.990067f,28.442646f,62.223564f,-60.402023f,-14.624523f,-86.94074f,-69.77782f ) ;
  }

  @Test
  public void test187() {
    color.laplace.solve(41.749306f,56.393925f,73.05732f,10.603269f,10.761323f,30.581196f,-10.097555f,-54.53312f,38.50614f ) ;
  }

  @Test
  public void test188() {
    color.laplace.solve(41.934208f,33.981544f,-89.961586f,33.755295f,75.561295f,100.0f,17.525677f,36.347412f,52.30268f ) ;
  }

  @Test
  public void test189() {
    color.laplace.solve(42.240784f,33.421547f,53.76969f,35.541584f,-62.32429f,65.23996f,0f,0f,0f ) ;
  }

  @Test
  public void test190() {
    color.laplace.solve(-42.410984f,37.74385f,0f,-78.62596f,76.53177f,0f,-3.8407025f,0f,0f ) ;
  }

  @Test
  public void test191() {
    color.laplace.solve(42.556545f,42.24977f,-71.10643f,27.976406f,97.54898f,-75.11356f,60.43036f,100.0f,0f ) ;
  }

  @Test
  public void test192() {
    color.laplace.solve(42.57129f,46.982742f,19.957224f,23.302414f,25.402462f,0.73233616f,25.235903f,59.46308f,0f ) ;
  }

  @Test
  public void test193() {
    color.laplace.solve(42.662518f,70.58355f,-53.825447f,0.06651692f,-40.887024f,0f,-1.5094246f,0f,0f ) ;
  }

  @Test
  public void test194() {
    color.laplace.solve(42.690807f,79.39309f,29.982769f,-8.629857f,22.789764f,2.8645701f,-100.0f,17.531254f,-85.61216f ) ;
  }

  @Test
  public void test195() {
    color.laplace.solve(42.859768f,79.89745f,-18.656351f,-8.458386f,-85.506744f,-31.248264f,8.813435f,43.712124f,62.30411f ) ;
  }

  @Test
  public void test196() {
    color.laplace.solve(42.96931f,70.73578f,143.19734f,1.1414696f,-2.5422804f,-138.39908f,-35.890636f,82.80504f,0f ) ;
  }

  @Test
  public void test197() {
    color.laplace.solve(43.3473f,44.415703f,38.256393f,28.973497f,-3.9408836f,7.3376517f,7.610575f,1.467827f,2.2016163f ) ;
  }

  @Test
  public void test198() {
    color.laplace.solve(43.384083f,71.37747f,82.893036f,2.158867f,59.232765f,94.482414f,-93.981384f,6.302884f,0f ) ;
  }

  @Test
  public void test199() {
    color.laplace.solve(43.466404f,53.083324f,46.973934f,20.782299f,21.89295f,99.44388f,17.769838f,50.297054f,0f ) ;
  }

  @Test
  public void test200() {
    color.laplace.solve(43.52163f,50.697895f,-23.871695f,23.388617f,42.248066f,-22.19794f,7.784773f,7.750476f,-19.030935f ) ;
  }

  @Test
  public void test201() {
    color.laplace.solve(43.55462f,48.88116f,-51.785397f,25.337317f,8.360722f,-27.856703f,49.433926f,-12.918886f,-68.00214f ) ;
  }

  @Test
  public void test202() {
    color.laplace.solve(-43.561264f,19.484861f,70.73346f,-12.269408f,-4.376019f,-32.427525f,-1.1403528f,7.707997f,36.348362f ) ;
  }

  @Test
  public void test203() {
    color.laplace.solve(43.763706f,39.08624f,-36.892708f,35.968594f,49.47395f,3.3869338f,50.63671f,3.341294f,0f ) ;
  }

  @Test
  public void test204() {
    color.laplace.solve(43.97033f,67.17127f,46.8434f,8.71004f,77.87135f,20.202326f,-87.001526f,5.843856f,0f ) ;
  }

  @Test
  public void test205() {
    color.laplace.solve(44.413364f,37.308735f,50.47725f,40.344727f,-45.65568f,64.60026f,-2.0631847f,-48.597466f,0f ) ;
  }

  @Test
  public void test206() {
    color.laplace.solve(44.473614f,-20.971706f,0f,91.78534f,97.6424f,64.940186f,32.719463f,39.09251f,26.008173f ) ;
  }

  @Test
  public void test207() {
    color.laplace.solve(44.566235f,70.33436f,29.299032f,7.930575f,-6.484018f,23.54978f,-6.3599157f,-98.851654f,0f ) ;
  }

  @Test
  public void test208() {
    color.laplace.solve(44.71741f,45.508064f,25.18112f,33.361584f,13.584834f,-10.88655f,75.14409f,-13.6437645f,-82.31215f ) ;
  }

  @Test
  public void test209() {
    color.laplace.solve(44.806877f,26.286736f,21.640789f,52.94077f,-61.300728f,-39.72358f,-19.458124f,0f,0f ) ;
  }

  @Test
  public void test210() {
    color.laplace.solve(44.895287f,51.51633f,40.26305f,28.064812f,20.906992f,-30.41404f,46.45697f,-2.8685179f,0f ) ;
  }

  @Test
  public void test211() {
    color.laplace.solve(45.252403f,59.75855f,46.339195f,21.251059f,47.4426f,19.996096f,-7.690765f,88.764694f,0f ) ;
  }

  @Test
  public void test212() {
    color.laplace.solve(4.5494437f,-63.96359f,65.91186f,-17.838636f,24.096012f,96.60659f,-100.0f,-24.480602f,0f ) ;
  }

  @Test
  public void test213() {
    color.laplace.solve(45.5014f,64.91252f,-25.463367f,17.093084f,-8.869649f,0f,31.740583f,0f,0f ) ;
  }

  @Test
  public void test214() {
    color.laplace.solve(45.51626f,20.963371f,4.6852965f,61.10167f,-100.0f,0f,2.465021f,-51.241585f,43.9415f ) ;
  }

  @Test
  public void test215() {
    color.laplace.solve(45.62895f,71.07477f,22.201687f,11.441032f,-65.57482f,8.331624f,65.71001f,9.222635f,0f ) ;
  }

  @Test
  public void test216() {
    color.laplace.solve(45.853138f,65.468994f,-36.31706f,17.943552f,9.458768f,-42.959423f,16.462301f,-2.6180477f,0f ) ;
  }

  @Test
  public void test217() {
    color.laplace.solve(-4.597832f,89.12495f,0f,-35.292625f,48.918762f,0f,5.4499245f,19.94737f,0f ) ;
  }

  @Test
  public void test218() {
    color.laplace.solve(46.002148f,6.6282434f,0f,19.509695f,30.3202f,0f,-76.725136f,2.6375923f,0f ) ;
  }

  @Test
  public void test219() {
    color.laplace.solve(46.191624f,63.503216f,0f,-12.84259f,-22.288475f,0f,-16.627642f,-53.66798f,-26.25552f ) ;
  }

  @Test
  public void test220() {
    color.laplace.solve(46.320408f,56.594795f,0f,28.686832f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test221() {
    color.laplace.solve(46.326447f,50.279022f,93.55184f,35.026756f,11.213445f,-0.545112f,82.56714f,-39.90689f,-1.1267515f ) ;
  }

  @Test
  public void test222() {
    color.laplace.solve(46.52379f,58.23497f,28.235113f,27.860191f,58.18097f,-45.294514f,6.7360096f,-20.859661f,0f ) ;
  }

  @Test
  public void test223() {
    color.laplace.solve(46.81511f,49.759052f,43.99019f,37.501385f,8.230919f,26.2017f,94.95951f,0f,0f ) ;
  }

  @Test
  public void test224() {
    color.laplace.solve(46.82224f,58.624153f,75.31434f,28.664795f,12.360036f,50.105846f,55.476906f,-100.0f,0f ) ;
  }

  @Test
  public void test225() {
    color.laplace.solve(46.839993f,-8.771034f,40.736877f,96.131004f,-54.52241f,0f,80.128105f,-10.495353f,0f ) ;
  }

  @Test
  public void test226() {
    color.laplace.solve(46.89675f,71.424904f,-6.2695913f,16.162104f,14.874128f,-23.20164f,2.8775327f,-4.8888574f,35.237446f ) ;
  }

  @Test
  public void test227() {
    color.laplace.solve(47.072826f,59.80039f,20.779932f,28.491077f,55.20542f,6.117013f,11.685752f,18.245447f,6.090615f ) ;
  }

  @Test
  public void test228() {
    color.laplace.solve(47.089546f,44.07158f,17.137f,44.28661f,12.059774f,-75.52358f,-13.244521f,-97.264694f,-43.19707f ) ;
  }

  @Test
  public void test229() {
    color.laplace.solve(47.554077f,71.00024f,87.4596f,19.21607f,48.98727f,-100.0f,-19.677063f,-97.924324f,0f ) ;
  }

  @Test
  public void test230() {
    color.laplace.solve(-47.763184f,100.0f,0f,-0.93979764f,32.018993f,97.75031f,3.7808807f,16.06332f,28.453407f ) ;
  }

  @Test
  public void test231() {
    color.laplace.solve(47.77315f,67.75111f,-71.94049f,23.341501f,31.60063f,-9.805648f,13.992224f,32.627396f,7.2092576f ) ;
  }

  @Test
  public void test232() {
    color.laplace.solve(47.7857f,22.746496f,-34.63822f,68.39631f,-96.59404f,100.0f,13.357138f,-14.967757f,23.365875f ) ;
  }

  @Test
  public void test233() {
    color.laplace.solve(47.946827f,72.12861f,81.72798f,19.658697f,58.839626f,12.229173f,-28.151663f,0f,0f ) ;
  }

  @Test
  public void test234() {
    color.laplace.solve(48.346336f,12.213775f,-50.47842f,81.17158f,-49.012817f,59.6927f,32.22293f,47.720146f,0f ) ;
  }

  @Test
  public void test235() {
    color.laplace.solve(48.363716f,96.28975f,53.05791f,-2.8348882f,-55.314354f,-36.12425f,-4.388913f,-14.720765f,0.8202064f ) ;
  }

  @Test
  public void test236() {
    color.laplace.solve(48.514374f,65.11311f,37.39065f,28.944382f,74.54742f,-15.550507f,-6.672591f,0f,0f ) ;
  }

  @Test
  public void test237() {
    color.laplace.solve(48.657825f,53.303265f,75.20171f,41.328037f,45.52735f,11.331899f,71.126976f,76.1462f,-20.159609f ) ;
  }

  @Test
  public void test238() {
    color.laplace.solve(48.75182f,57.238857f,6.9501934f,37.768425f,73.25342f,39.10839f,34.44211f,100.0f,-38.43192f ) ;
  }

  @Test
  public void test239() {
    color.laplace.solve(48.883514f,4.3825026f,32.87956f,31.95967f,0.894529f,-2.1607034f,78.06063f,-30.603352f,-71.00089f ) ;
  }

  @Test
  public void test240() {
    color.laplace.solve(48.89795f,59.14796f,71.60529f,36.443832f,16.0886f,68.237175f,80.78878f,41.891117f,0f ) ;
  }

  @Test
  public void test241() {
    color.laplace.solve(49.91469f,21.66331f,-39.69636f,77.995445f,-23.565086f,-79.483604f,-18.159353f,100.0f,0f ) ;
  }

  @Test
  public void test242() {
    color.laplace.solve(50.190407f,108.4569f,279.11636f,-7.6829185f,-141.48544f,-24.698645f,-12.645773f,-42.900173f,-17.553698f ) ;
  }

  @Test
  public void test243() {
    color.laplace.solve(-50.30048f,-55.85135f,0f,-9.388596f,8.046615f,3.801842f,4.699482f,28.186523f,100.0f ) ;
  }

  @Test
  public void test244() {
    color.laplace.solve(50.36236f,-18.050203f,0f,4.2651043f,-57.869835f,14.802648f,24.567892f,56.62158f,0f ) ;
  }

  @Test
  public void test245() {
    color.laplace.solve(50.66975f,57.180653f,-159.8785f,44.975037f,112.607346f,0f,16.806242f,21.146328f,-44.249287f ) ;
  }

  @Test
  public void test246() {
    color.laplace.solve(50.795044f,5.9312434f,0f,34.149357f,91.14027f,59.986446f,-5.3378778f,81.82684f,0f ) ;
  }

  @Test
  public void test247() {
    color.laplace.solve(50.80304f,81.02655f,-30.168306f,22.185612f,30.203053f,8.840246f,7.736353f,8.759801f,2.9535785f ) ;
  }

  @Test
  public void test248() {
    color.laplace.solve(-5.0913153f,41.882027f,70.01487f,1.0927302f,12.522906f,20.452284f,-3.0606709f,-13.335413f,-82.86614f ) ;
  }

  @Test
  public void test249() {
    color.laplace.solve(52.042736f,95.42007f,-82.50516f,12.750878f,13.172964f,31.650682f,-14.212188f,-87.129776f,43.786133f ) ;
  }

  @Test
  public void test250() {
    color.laplace.solve(52.286953f,35.852f,0f,47.615143f,72.32056f,0f,60.22078f,5.5702615f,0f ) ;
  }

  @Test
  public void test251() {
    color.laplace.solve(52.527996f,-89.71891f,0f,52.166695f,100.0f,0f,18.970839f,23.716656f,-82.62645f ) ;
  }

  @Test
  public void test252() {
    color.laplace.solve(5.3309155f,-70.01028f,100.0f,-8.666061f,-30.42721f,-2.9537644f,-9.567953f,-29.605751f,-78.42784f ) ;
  }

  @Test
  public void test253() {
    color.laplace.solve(53.58726f,69.81134f,62.59267f,44.53771f,63.06543f,-50.90031f,15.630758f,17.985325f,-6.754892f ) ;
  }

  @Test
  public void test254() {
    color.laplace.solve(53.691032f,73.6033f,-100.0f,41.16083f,-46.318073f,0f,1.2222866f,-36.271683f,-99.99095f ) ;
  }

  @Test
  public void test255() {
    color.laplace.solve(-54.071777f,-15.172274f,0f,-22.372938f,-28.550642f,0f,-11.170817f,-22.310331f,0f ) ;
  }

  @Test
  public void test256() {
    color.laplace.solve(54.763657f,100.0f,0f,9.33164f,-13.903579f,28.150269f,-3.533519f,-23.465715f,69.689545f ) ;
  }

  @Test
  public void test257() {
    color.laplace.solve(-54.89982f,-47.351753f,0f,59.99819f,104.61619f,-37.63447f,29.63402f,58.562878f,100.0f ) ;
  }

  @Test
  public void test258() {
    color.laplace.solve(55.067562f,51.13635f,28.23786f,69.1339f,21.23997f,-38.184906f,23.714762f,25.725142f,57.945835f ) ;
  }

  @Test
  public void test259() {
    color.laplace.solve(5.519804f,16.340242f,0f,-3.9656262f,-22.671127f,-71.55411f,1.2888185f,9.1209f,0f ) ;
  }

  @Test
  public void test260() {
    color.laplace.solve(55.493874f,-33.433865f,0f,0.1868228f,-20.783552f,19.269983f,-33.96303f,-69.15715f,0f ) ;
  }

  @Test
  public void test261() {
    color.laplace.solve(-56.948082f,-56.20323f,0f,-18.753448f,-0.24911584f,-9.708467f,-17.816593f,-52.512924f,62.584606f ) ;
  }

  @Test
  public void test262() {
    color.laplace.solve(57.3901f,33.18951f,-96.88702f,22.161951f,24.268684f,35.929157f,6.989017f,5.7941175f,-8.081232f ) ;
  }

  @Test
  public void test263() {
    color.laplace.solve(57.860886f,-57.453056f,0f,10.934782f,-10.974297f,-71.95539f,-3.1474595f,-23.52462f,0f ) ;
  }

  @Test
  public void test264() {
    color.laplace.solve(58.19353f,99.96873f,-97.306564f,33.462193f,62.71312f,99.86476f,12.698267f,17.412287f,-5.762234f ) ;
  }

  @Test
  public void test265() {
    color.laplace.solve(59.0693f,82.346054f,-62.014755f,53.93116f,54.05086f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test266() {
    color.laplace.solve(-60.53529f,28.177011f,38.840584f,-18.339117f,-3.8733552f,-7.8791485f,-8.947821f,-17.452168f,-4.1334343f ) ;
  }

  @Test
  public void test267() {
    color.laplace.solve(60.720863f,5.595098f,0f,13.779055f,-28.197039f,2.3746529f,22.59239f,76.59051f,0f ) ;
  }

  @Test
  public void test268() {
    color.laplace.solve(-60.74963f,46.697124f,59.671104f,16.115902f,32.398357f,0.060873225f,92.81488f,66.71953f,-89.828255f ) ;
  }

  @Test
  public void test269() {
    color.laplace.solve(-61.20567f,-31.776293f,0f,-66.81643f,9.3508415f,-36.0307f,-17.054667f,-1.4022348f,2.0948858f ) ;
  }

  @Test
  public void test270() {
    color.laplace.solve(61.486637f,82.59376f,35.369637f,63.352783f,-100.0f,0f,40.838196f,100.0f,36.011284f ) ;
  }

  @Test
  public void test271() {
    color.laplace.solve(-61.916965f,-25.336718f,0f,-6.3686843f,27.875494f,73.418625f,8.566734f,40.635624f,52.76592f ) ;
  }

  @Test
  public void test272() {
    color.laplace.solve(62.053974f,90.098946f,23.778063f,21.549873f,52.365437f,38.212055f,-28.219917f,59.600872f,76.70472f ) ;
  }

  @Test
  public void test273() {
    color.laplace.solve(62.240547f,17.897678f,0f,8.056847f,-29.303999f,-71.137924f,-0.70916265f,-10.893497f,-13.560827f ) ;
  }

  @Test
  public void test274() {
    color.laplace.solve(-63.07618f,11.835018f,0f,7.103435f,87.81619f,-63.51642f,3.673722f,7.591453f,-61.124107f ) ;
  }

  @Test
  public void test275() {
    color.laplace.solve(6.3095217f,-9.220521f,-35.027542f,3.6471784f,4.8817315f,15.157602f,3.397461f,9.942665f,31.491468f ) ;
  }

  @Test
  public void test276() {
    color.laplace.solve(-6.330457f,93.11281f,0f,-3.0736449f,-3.273273f,-91.489815f,-2.6908495f,-7.6897535f,-24.794891f ) ;
  }

  @Test
  public void test277() {
    color.laplace.solve(-63.388798f,78.577995f,0f,14.52255f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test278() {
    color.laplace.solve(63.412277f,73.060524f,-9.112833f,80.58859f,100.0f,0f,100.0f,0f,0f ) ;
  }

  @Test
  public void test279() {
    color.laplace.solve(64.40516f,46.880123f,-14.528923f,25.938227f,27.425928f,15.13634f,11.921812f,21.749023f,47.648354f ) ;
  }

  @Test
  public void test280() {
    color.laplace.solve(64.974144f,-38.657078f,0f,11.09964f,-21.858683f,24.118963f,-1.6575546f,-17.729858f,-47.403194f ) ;
  }

  @Test
  public void test281() {
    color.laplace.solve(-66.15627f,1.1649369f,0f,-50.14305f,45.87484f,0f,-10.928281f,6.429927f,80.23378f ) ;
  }

  @Test
  public void test282() {
    color.laplace.solve(66.35452f,-24.187521f,0f,60.13108f,146.64879f,-90.79003f,27.550213f,49.49768f,46.184505f ) ;
  }

  @Test
  public void test283() {
    color.laplace.solve(-66.43121f,50.361553f,0f,-21.346546f,-31.874811f,0f,-63.122906f,14.209206f,0f ) ;
  }

  @Test
  public void test284() {
    color.laplace.solve(-6.78529f,2.9505851f,-31.198792f,6.6905313f,28.434654f,42.088615f,5.1127605f,62.008884f,-60.97595f ) ;
  }

  @Test
  public void test285() {
    color.laplace.solve(-67.964935f,-32.344585f,0f,-21.996326f,11.51572f,32.121937f,-31.536089f,61.164215f,0f ) ;
  }

  @Test
  public void test286() {
    color.laplace.solve(70.0327f,-87.31847f,0f,-80.8433f,49.470226f,0f,-44.635563f,-24.225948f,0f ) ;
  }

  @Test
  public void test287() {
    color.laplace.solve(-70.645134f,37.445656f,0f,13.228301f,-3.2628667f,0f,85.25187f,-3.4748535f,0f ) ;
  }

  @Test
  public void test288() {
    color.laplace.solve(7.104055f,-87.579735f,-96.5893f,-18.87956f,-2.289548f,-1.1081109f,-80.33275f,98.40921f,94.281525f ) ;
  }

  @Test
  public void test289() {
    color.laplace.solve(71.06935f,-100.0f,0f,58.61152f,-60.72817f,24.365816f,13.916223f,-2.9466286f,35.025433f ) ;
  }

  @Test
  public void test290() {
    color.laplace.solve(71.102554f,-50.412888f,0f,9.191067f,100.0f,67.43986f,15.784285f,53.94607f,100.0f ) ;
  }

  @Test
  public void test291() {
    color.laplace.solve(7.14595f,-71.71786f,6.480671f,-31.987463f,-38.153652f,-36.931454f,-96.94215f,-11.9778385f,-100.0f ) ;
  }

  @Test
  public void test292() {
    color.laplace.solve(71.908394f,67.81454f,0f,86.13092f,-73.67026f,0f,17.695482f,-15.348988f,-5.4211774f ) ;
  }

  @Test
  public void test293() {
    color.laplace.solve(72.37568f,-33.82064f,0f,14.952209f,-15.554977f,5.2725677f,2.9881394f,-2.9996521f,0.5682289f ) ;
  }

  @Test
  public void test294() {
    color.laplace.solve(-72.43462f,-5.1507564f,0f,1.2636805f,0.4862556f,11.721846f,77.00309f,86.900406f,0f ) ;
  }

  @Test
  public void test295() {
    color.laplace.solve(72.55868f,26.369015f,-38.51945f,23.671852f,13.998985f,-2.8920372f,8.129741f,8.847113f,9.585319f ) ;
  }

  @Test
  public void test296() {
    color.laplace.solve(7.2764482f,97.53277f,0f,5.6305866f,81.4613f,-78.169846f,5.9309673f,18.093283f,-15.01914f ) ;
  }

  @Test
  public void test297() {
    color.laplace.solve(74.99426f,100.0f,75.0f,100.0f,149.9672f,100.0f,28.876923f,6.083832f,0f ) ;
  }

  @Test
  public void test298() {
    color.laplace.solve(75.60726f,-32.579067f,0f,-17.683025f,49.48844f,0f,30.3093f,-85.574295f,0f ) ;
  }

  @Test
  public void test299() {
    color.laplace.solve(77.437294f,-14.863262f,0f,11.30705f,-21.869379f,-67.13384f,-10.339716f,-16.787466f,0f ) ;
  }

  @Test
  public void test300() {
    color.laplace.solve(-78.25316f,-31.354664f,-66.196686f,-25.635244f,-17.123281f,-8.48032f,-7.1645365f,-3.0229015f,12.196213f ) ;
  }

  @Test
  public void test301() {
    color.laplace.solve(-7.9131203f,-97.1562f,-100.0f,-3.4152515f,-15.525788f,-4.058566f,9.777903f,42.526863f,99.008224f ) ;
  }

  @Test
  public void test302() {
    color.laplace.solve(80.7268f,61.85456f,0f,-2.8961964f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test303() {
    color.laplace.solve(81.18019f,-100.0f,0f,14.104949f,-20.491714f,-54.63586f,-4.268682f,-31.179676f,-99.958305f ) ;
  }

  @Test
  public void test304() {
    color.laplace.solve(81.89594f,25.686346f,-97.20207f,32.88406f,39.09473f,88.51028f,10.545573f,9.298233f,-12.44737f ) ;
  }

  @Test
  public void test305() {
    color.laplace.solve(83.51545f,-31.669418f,0f,18.755627f,-67.83631f,0f,-0.37532365f,-20.256922f,0f ) ;
  }

  @Test
  public void test306() {
    color.laplace.solve(83.92049f,44.807915f,0f,28.098658f,21.350512f,80.09264f,7.1236367f,0.3958889f,-26.890593f ) ;
  }

  @Test
  public void test307() {
    color.laplace.solve(8.426916f,88.67745f,0f,51.27553f,9.274251f,0f,97.79347f,0f,0f ) ;
  }

  @Test
  public void test308() {
    color.laplace.solve(-86.17521f,64.35976f,0f,7.4029922f,18.13262f,-95.09155f,97.65456f,95.85928f,0f ) ;
  }

  @Test
  public void test309() {
    color.laplace.solve(-8.64381f,64.06279f,0f,-11.918307f,-31.92418f,-100.0f,-7.105239f,-16.50265f,-26.981178f ) ;
  }

  @Test
  public void test310() {
    color.laplace.solve(8.686925f,25.588833f,45.45781f,-90.84113f,-60.48188f,0f,-39.988388f,-69.11242f,0f ) ;
  }

  @Test
  public void test311() {
    color.laplace.solve(8.749774f,-45.45034f,-65.58347f,-19.550566f,-57.11296f,-63.645214f,-29.839075f,-99.80573f,78.89798f ) ;
  }

  @Test
  public void test312() {
    color.laplace.solve(-89.200264f,66.196945f,0f,-7.4922113f,6.517028f,-69.1385f,52.71439f,0.014598842f,0f ) ;
  }

  @Test
  public void test313() {
    color.laplace.solve(8.935421f,16.332787f,9.61683f,-80.5911f,-53.221104f,-77.86546f,-64.032875f,23.754747f,0f ) ;
  }

  @Test
  public void test314() {
    color.laplace.solve(-8.989904f,99.99993f,-31.699154f,9.515097f,29.565191f,-51.679558f,17.485098f,60.425297f,-31.704264f ) ;
  }

  @Test
  public void test315() {
    color.laplace.solve(90.18642f,-58.615276f,0f,-26.859673f,22.484467f,0f,75.66898f,0f,0f ) ;
  }

  @Test
  public void test316() {
    color.laplace.solve(9.110284f,-54.828613f,-90.16091f,-8.730252f,-31.668552f,-22.394642f,-12.362739f,-40.720703f,-72.406166f ) ;
  }

  @Test
  public void test317() {
    color.laplace.solve(91.15833f,-16.793192f,0f,26.058277f,-41.4646f,0f,-33.39678f,0f,0f ) ;
  }

  @Test
  public void test318() {
    color.laplace.solve(92.61662f,-17.550043f,0f,50.892223f,53.91007f,0f,57.042202f,0f,0f ) ;
  }

  @Test
  public void test319() {
    color.laplace.solve(-96.641335f,-100.0f,0f,-32.233677f,-21.437685f,-38.662777f,-10.855691f,-11.189085f,-12.462965f ) ;
  }

  @Test
  public void test320() {
    color.laplace.solve(99.86115f,-98.30202f,0f,-46.888428f,41.485046f,0f,-13.409168f,-6.7482476f,0f ) ;
  }

  @Test
  public void test321() {
    color.laplace.solve(-99.995346f,-97.99364f,-5.286283f,-30.634352f,-36.72601f,10.706073f,14.18395f,-28.982122f,84.836586f ) ;
  }

  @Test
  public void test322() {
    color.laplace.solve(99.99988f,-100.0f,0f,48.432938f,75.81827f,-26.605488f,17.9136f,23.221466f,-0.84600556f ) ;
  }

  @Test
  public void test323() {
    color.laplace.solve(-99.999985f,-86.72446f,-100.0f,-38.168285f,-36.59936f,51.14731f,-16.073805f,-72.652016f,-57.449734f ) ;
  }
}
