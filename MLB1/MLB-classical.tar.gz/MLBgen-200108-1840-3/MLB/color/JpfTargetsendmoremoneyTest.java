import org.junit.Test;

public class JpfTargetsendmoremoneyTest {

  @Test
  public void test0() {
    color.sendmoremoney.solve(0,6,-5,-6,2,3,0,-38 ) ;
  }

  @Test
  public void test1() {
    color.sendmoremoney.solve(-10,17,0,1,-1,12,-34,-1495 ) ;
  }

  @Test
  public void test2() {
    color.sendmoremoney.solve(1,0,6,-240,0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    color.sendmoremoney.solve(-137,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test4() {
    color.sendmoremoney.solve(184,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    color.sendmoremoney.solve(1,8,6,1,0,1,0,-476 ) ;
  }

  @Test
  public void test6() {
    color.sendmoremoney.solve(194,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test7() {
    color.sendmoremoney.solve(2,2,3,1,11,0,-882,0 ) ;
  }

  @Test
  public void test8() {
    color.sendmoremoney.solve(3,0,874,0,0,0,0,0 ) ;
  }

  @Test
  public void test9() {
    color.sendmoremoney.solve(3,581,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test10() {
    color.sendmoremoney.solve(4,1,8,0,0,0,0,0 ) ;
  }

  @Test
  public void test11() {
    color.sendmoremoney.solve(4,1,9,592,0,0,0,0 ) ;
  }

  @Test
  public void test12() {
    color.sendmoremoney.solve(4,-440,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test13() {
    color.sendmoremoney.solve(5,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test14() {
    color.sendmoremoney.solve(5,0,2,6,2453,0,0,0 ) ;
  }

  @Test
  public void test15() {
    color.sendmoremoney.solve(5,311,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test16() {
    color.sendmoremoney.solve(6,1,5,1,0,0,0,0 ) ;
  }

  @Test
  public void test17() {
    color.sendmoremoney.solve(6,7,7,0,6,3,1223,0 ) ;
  }

  @Test
  public void test18() {
    color.sendmoremoney.solve(6,8,9,5,1,10,0,0 ) ;
  }

  @Test
  public void test19() {
    color.sendmoremoney.solve(7,1,0,7,3,5,0,0 ) ;
  }

  @Test
  public void test20() {
    color.sendmoremoney.solve(7,6,1,7,1299,0,0,0 ) ;
  }

  @Test
  public void test21() {
    color.sendmoremoney.solve(7,6,19,1,0,-10,0,0 ) ;
  }

  @Test
  public void test22() {
    color.sendmoremoney.solve(7,7,4,8,6,0,0,0 ) ;
  }

  @Test
  public void test23() {
    color.sendmoremoney.solve(7,9,3,5,1,482,0,0 ) ;
  }

  @Test
  public void test24() {
    color.sendmoremoney.solve(8,1,807,0,0,0,0,0 ) ;
  }

  @Test
  public void test25() {
    color.sendmoremoney.solve(8,1,8,854,0,0,0,0 ) ;
  }

  @Test
  public void test26() {
    color.sendmoremoney.solve(8,7,6,10,4,9,-490,1189 ) ;
  }

  @Test
  public void test27() {
    color.sendmoremoney.solve(8,8,4,9,8,-600,0,0 ) ;
  }

  @Test
  public void test28() {
    color.sendmoremoney.solve(9,-1,0,0,2,8,0,765 ) ;
  }

  @Test
  public void test29() {
    color.sendmoremoney.solve(9,11,3,7,10,8,0,494 ) ;
  }

  @Test
  public void test30() {
    color.sendmoremoney.solve(9,1,-392,0,0,0,0,0 ) ;
  }

  @Test
  public void test31() {
    color.sendmoremoney.solve(9,1,5,4,3,202,0,0 ) ;
  }

  @Test
  public void test32() {
    color.sendmoremoney.solve(9,2,7,-6,5,6,1337,0 ) ;
  }

  @Test
  public void test33() {
    color.sendmoremoney.solve(9,3,1,0,-749,0,0,0 ) ;
  }

  @Test
  public void test34() {
    color.sendmoremoney.solve(9,4,6,12,2,-5,-1080,0 ) ;
  }

  @Test
  public void test35() {
    color.sendmoremoney.solve(9,8,0,0,0,0,0,0 ) ;
  }
}
