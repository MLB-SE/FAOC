import org.junit.Test;

public class JpfTargetstablemarriageTest {

  @Test
  public void test0() {
    color.stablemarriage.solve(1,248 ) ;
  }

  @Test
  public void test1() {
    color.stablemarriage.solve(3,834 ) ;
  }

  @Test
  public void test2() {
    color.stablemarriage.solve(4,0 ) ;
  }

  @Test
  public void test3() {
    color.stablemarriage.solve(4,2 ) ;
  }

  @Test
  public void test4() {
    color.stablemarriage.solve(-538,0 ) ;
  }

  @Test
  public void test5() {
    color.stablemarriage.solve(5,-647 ) ;
  }

  @Test
  public void test6() {
    color.stablemarriage.solve(735,0 ) ;
  }

  @Test
  public void test7() {
    color.stablemarriage.solve(894,0 ) ;
  }
}
