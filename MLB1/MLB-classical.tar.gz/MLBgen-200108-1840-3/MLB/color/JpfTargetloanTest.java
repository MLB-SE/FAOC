import org.junit.Test;

public class JpfTargetloanTest {

  @Test
  public void test0() {
    color.loan.solve(45.80384f ) ;
  }

  @Test
  public void test1() {
    color.loan.solve(61.68364f ) ;
  }

  @Test
  public void test2() {
    color.loan.solve(69.818405f ) ;
  }
}
