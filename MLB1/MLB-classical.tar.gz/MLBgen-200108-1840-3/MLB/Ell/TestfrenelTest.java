import org.junit.Test;

public class TestfrenelTest {

  @Test
  public void test0() {
    frenel.frenel(0.4354795382205907 ) ;
  }

  @Test
  public void test1() {
    frenel.frenel(-1.232595164407831E-32 ) ;
  }

  @Test
  public void test2() {
    frenel.frenel(-1.5 ) ;
  }

  @Test
  public void test3() {
    frenel.frenel(1.5 ) ;
  }

  @Test
  public void test4() {
    frenel.frenel(-18.400890012408453 ) ;
  }

  @Test
  public void test5() {
    frenel.frenel(3.218274744718073 ) ;
  }

  @Test
  public void test6() {
    frenel.frenel(3.4758770256798357 ) ;
  }

  @Test
  public void test7() {
    frenel.frenel(41.81398283623531 ) ;
  }

  @Test
  public void test8() {
    frenel.frenel(-4.69052865986059 ) ;
  }

  @Test
  public void test9() {
    frenel.frenel(-4.710380839558994 ) ;
  }

  @Test
  public void test10() {
    frenel.frenel(55.229988847648286 ) ;
  }

  @Test
  public void test11() {
    frenel.frenel(-5.551115123125783E-17 ) ;
  }

  @Test
  public void test12() {
    frenel.frenel(-65.21909564399616 ) ;
  }

  @Test
  public void test13() {
    frenel.frenel(-85.8269084106651 ) ;
  }

  @Test
  public void test14() {
    frenel.frenel(9.860761315262648E-32 ) ;
  }
}
