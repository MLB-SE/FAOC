import org.junit.Test;

public class TestellpiTest {

  @Test
  public void test0() {
    ell.ellpi(12.566370589265578,0,1.0961330990205578 ) ;
  }

  @Test
  public void test1() {
    ell.ellpi(16.577468397509975,0,-0.9704411102116337 ) ;
  }

  @Test
  public void test2() {
    ell.ellpi(-17.417288963146447,0,0.6801905643462902 ) ;
  }

  @Test
  public void test3() {
    ell.ellpi(-21.966234841104157,0,40.14265607620895 ) ;
  }

  @Test
  public void test4() {
    ell.ellpi(21.991142790705393,0,-6.00672018247349E-4 ) ;
  }

  @Test
  public void test5() {
    ell.ellpi(21.991148573872245,0,-33.64035878809922 ) ;
  }

  @Test
  public void test6() {
    ell.ellpi(-21.991148573996192,0,9.214182862057847 ) ;
  }

  @Test
  public void test7() {
    ell.ellpi(-25.132741229466205,0,-6.247311614870739 ) ;
  }

  @Test
  public void test8() {
    ell.ellpi(-26.70353756308338,0,1.0000000000000024 ) ;
  }

  @Test
  public void test9() {
    ell.ellpi(-34.55751919896635,0,1.0620382426802288 ) ;
  }

  @Test
  public void test10() {
    ell.ellpi(-37.69887800574549,0,-0.9999999982139803 ) ;
  }

  @Test
  public void test11() {
    ell.ellpi(39.269908169872416,0,-0.435571403689331 ) ;
  }

  @Test
  public void test12() {
    ell.ellpi(-39.714229917477375,0,-77.98874677499559 ) ;
  }

  @Test
  public void test13() {
    ell.ellpi(40.840704502945876,0,-1.1263083636251845 ) ;
  }

  @Test
  public void test14() {
    ell.ellpi(-48.6946861306418,0,1.0 ) ;
  }

  @Test
  public void test15() {
    ell.ellpi(52.4435144873994,0,-0.8258330399269624 ) ;
  }

  @Test
  public void test16() {
    ell.ellpi(53.758193563907945,0,-0.13646163824360324 ) ;
  }

  @Test
  public void test17() {
    ell.ellpi(59.690260408041574,0,-1.4431615448879143 ) ;
  }

  @Test
  public void test18() {
    ell.ellpi(6.28115082568101,0,-70.16895606969626 ) ;
  }

  @Test
  public void test19() {
    ell.ellpi(62.842769363477196,0,-91.608019497169 ) ;
  }

  @Test
  public void test20() {
    ell.ellpi(62.89701730810148,0,-15.356706947292011 ) ;
  }

  @Test
  public void test21() {
    ell.ellpi(-65.97344573304885,0,1.1738104300391523 ) ;
  }

  @Test
  public void test22() {
    ell.ellpi(-69.1126687415441,0,0.9999999999886594 ) ;
  }

  @Test
  public void test23() {
    ell.ellpi(-73.36390294343029,0,79.08706646286726 ) ;
  }

  @Test
  public void test24() {
    ell.ellpi(-73.82742735451089,0,0.965847528000326 ) ;
  }

  @Test
  public void test25() {
    ell.ellpi(75.39822367696502,0,-23.892181708277054 ) ;
  }

  @Test
  public void test26() {
    ell.ellpi(-75.39822812419328,0,1.000003995717795 ) ;
  }

  @Test
  public void test27() {
    ell.ellpi(75.39921436832371,0,1.000000000008101 ) ;
  }

  @Test
  public void test28() {
    ell.ellpi(-75.70245885886655,0,3.3381897398657876 ) ;
  }

  @Test
  public void test29() {
    ell.ellpi(77.67813936700159,0,-28.89311833937292 ) ;
  }

  @Test
  public void test30() {
    ell.ellpi(-78.54138625290369,0,-5.906930181733294E-6 ) ;
  }

  @Test
  public void test31() {
    ell.ellpi(-81.6813884883822,0,-52.64516506867638 ) ;
  }

  @Test
  public void test32() {
    ell.ellpi(-97.3893722644232,0,5.0899905560181296 ) ;
  }
}
