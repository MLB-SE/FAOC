import org.junit.Test;

public class TestplgndrTest {

  @Test
  public void test0() {
    plgndr.plgndr(0,1,0 ) ;
  }

  @Test
  public void test1() {
    plgndr.plgndr(0,-180,0 ) ;
  }

  @Test
  public void test2() {
    plgndr.plgndr(0,-398,0 ) ;
  }

  @Test
  public void test3() {
    plgndr.plgndr(0,568,0 ) ;
  }

  @Test
  public void test4() {
    plgndr.plgndr(-1,0,0 ) ;
  }

  @Test
  public void test5() {
    plgndr.plgndr(11,598,0 ) ;
  }

  @Test
  public void test6() {
    plgndr.plgndr(164,54,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test7() {
    plgndr.plgndr(228,254,0 ) ;
  }

  @Test
  public void test8() {
    plgndr.plgndr(238,183,0.0 ) ;
  }

  @Test
  public void test9() {
    plgndr.plgndr(-266,-267,0 ) ;
  }

  @Test
  public void test10() {
    plgndr.plgndr(-332,565,0 ) ;
  }

  @Test
  public void test11() {
    plgndr.plgndr(-342,0,0 ) ;
  }

  @Test
  public void test12() {
    plgndr.plgndr(471,466,62.387951938949584 ) ;
  }

  @Test
  public void test13() {
    plgndr.plgndr(-498,-498,0 ) ;
  }

  @Test
  public void test14() {
    plgndr.plgndr(546,73,-61.431833170029826 ) ;
  }

  @Test
  public void test15() {
    plgndr.plgndr(602,377,88.81452327801895 ) ;
  }

  @Test
  public void test16() {
    plgndr.plgndr(611,478,-1.0 ) ;
  }

  @Test
  public void test17() {
    plgndr.plgndr(667,382,0.0 ) ;
  }

  @Test
  public void test18() {
    plgndr.plgndr(72,31,0.8761441927227716 ) ;
  }

  @Test
  public void test19() {
    plgndr.plgndr(730,555,1.0 ) ;
  }

  @Test
  public void test20() {
    plgndr.plgndr(782,571,0 ) ;
  }

  @Test
  public void test21() {
    plgndr.plgndr(845,121,1.0000000000000002 ) ;
  }

  @Test
  public void test22() {
    plgndr.plgndr(860,299,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test23() {
    plgndr.plgndr(-883,0,0 ) ;
  }

  @Test
  public void test24() {
    plgndr.plgndr(-890,-613,0 ) ;
  }

  @Test
  public void test25() {
    plgndr.plgndr(-914,0,0 ) ;
  }

  @Test
  public void test26() {
    plgndr.plgndr(971,486,-44.98105539942119 ) ;
  }

  @Test
  public void test27() {
    plgndr.plgndr(-98,-928,0 ) ;
  }
}
