import org.junit.Test;

public class TestsncndnTest {

  @Test
  public void test0() {
    ell.sncndn(0,0.23547153806365628 ) ;
  }

  @Test
  public void test1() {
    ell.sncndn(0,0.813375639320383 ) ;
  }

  @Test
  public void test2() {
    ell.sncndn(0,0.9999999799999999 ) ;
  }

  @Test
  public void test3() {
    ell.sncndn(0,0.9999999907699743 ) ;
  }

  @Test
  public void test4() {
    ell.sncndn(0,0.9999999999999998 ) ;
  }

  @Test
  public void test5() {
    ell.sncndn(0,1.0 ) ;
  }

  @Test
  public void test6() {
    ell.sncndn(0,1.0000000000000002 ) ;
  }

  @Test
  public void test7() {
    ell.sncndn(0,1.0000000004857623 ) ;
  }

  @Test
  public void test8() {
    ell.sncndn(0,1.00000002 ) ;
  }

  @Test
  public void test9() {
    ell.sncndn(0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test10() {
    ell.sncndn(0,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test11() {
    ell.sncndn(0,15.527792992827443 ) ;
  }

  @Test
  public void test12() {
    ell.sncndn(0,-16.64859207381599 ) ;
  }

  @Test
  public void test13() {
    ell.sncndn(0,32.29580265394975 ) ;
  }

  @Test
  public void test14() {
    ell.sncndn(0,-3.608764770438526 ) ;
  }

  @Test
  public void test15() {
    ell.sncndn(0,4.299281728521549 ) ;
  }

  @Test
  public void test16() {
    ell.sncndn(0,-46.24389934848694 ) ;
  }

  @Test
  public void test17() {
    ell.sncndn(0,-6.770519433011984 ) ;
  }

  @Test
  public void test18() {
    ell.sncndn(0,68.29876004713435 ) ;
  }

  @Test
  public void test19() {
    ell.sncndn(0,76.98926526432217 ) ;
  }

  @Test
  public void test20() {
    ell.sncndn(0,-84.78967557255648 ) ;
  }

  @Test
  public void test21() {
    ell.sncndn(0,-85.16895064336303 ) ;
  }
}
