import org.junit.Test;

public class TestdbrentTest {

  @Test
  public void test0() {
    ell.dbrent(0.0,0.0,0.0,0 ) ;
  }

  @Test
  public void test1() {
    ell.dbrent(-0.2825542850321199,0,54.11432634362876,0 ) ;
  }

  @Test
  public void test2() {
    ell.dbrent(-100.0,0.0,-100.0,0 ) ;
  }

  @Test
  public void test3() {
    ell.dbrent(-100.0,100.0,-100.0,0 ) ;
  }

  @Test
  public void test4() {
    ell.dbrent(100.0,100.0,100.0,0 ) ;
  }

  @Test
  public void test5() {
    ell.dbrent(100.0,99.99999999999999,100.0,0 ) ;
  }

  @Test
  public void test6() {
    ell.dbrent(106.91333198645734,68.40851448982735,48.06824696208486,0 ) ;
  }

  @Test
  public void test7() {
    ell.dbrent(11.723318552707298,86.53545753297007,-8.913231169120436,0 ) ;
  }

  @Test
  public void test8() {
    ell.dbrent(-11.973927806783166,84.40403068887957,-11.973927806783166,0 ) ;
  }

  @Test
  public void test9() {
    ell.dbrent(-1.3266735721946645,8.739989348584103,51.89977868994214,0 ) ;
  }

  @Test
  public void test10() {
    ell.dbrent(14.021006794430207,0.0,-52.94399845419277,0 ) ;
  }

  @Test
  public void test11() {
    ell.dbrent(17.414934582937583,0.0,17.414934582937583,0 ) ;
  }

  @Test
  public void test12() {
    ell.dbrent(-17.709706536052792,0.0,23.06909673260534,0 ) ;
  }

  @Test
  public void test13() {
    ell.dbrent(-20.47892177276441,0.0,20.47892177276441,0 ) ;
  }

  @Test
  public void test14() {
    ell.dbrent(22.018863200464494,35.558714834608395,77.60327268731174,0 ) ;
  }

  @Test
  public void test15() {
    ell.dbrent(-23.841443197041595,0,-23.8414431970416,0 ) ;
  }

  @Test
  public void test16() {
    ell.dbrent(26.06408925493113,0,26.064089254931133,0 ) ;
  }

  @Test
  public void test17() {
    ell.dbrent(-2.7676246885772904,0,-2.767624688577291,0 ) ;
  }

  @Test
  public void test18() {
    ell.dbrent(-2.8161226012475,0,-2.8161226012475002,0 ) ;
  }

  @Test
  public void test19() {
    ell.dbrent(-29.69485716459326,-39.292459558626256,-72.09411944474115,0 ) ;
  }

  @Test
  public void test20() {
    ell.dbrent(3.1246286980591877,-76.0319670381395,3.1246286980591877,0 ) ;
  }

  @Test
  public void test21() {
    ell.dbrent(-31.799481691485838,77.29671521844168,48.58714837757398,0 ) ;
  }

  @Test
  public void test22() {
    ell.dbrent(36.926088341648324,0,-72.48135344694344,0 ) ;
  }

  @Test
  public void test23() {
    ell.dbrent(39.85913400253847,-32.96438554655788,-76.17479935854313,0 ) ;
  }

  @Test
  public void test24() {
    ell.dbrent(-41.53756651821951,-7.68411440286107,-93.8184569763781,0 ) ;
  }

  @Test
  public void test25() {
    ell.dbrent(-42.98468811058355,-36.209900287825874,-29.435112465068205,0 ) ;
  }

  @Test
  public void test26() {
    ell.dbrent(43.00251246338465,44.68170452885843,-80.24575148167216,0 ) ;
  }

  @Test
  public void test27() {
    ell.dbrent(-43.47478187678118,-81.95466388312397,30.965508112894923,0 ) ;
  }

  @Test
  public void test28() {
    ell.dbrent(47.05601452740231,0,49.4119543712587,0 ) ;
  }

  @Test
  public void test29() {
    ell.dbrent(4.934117311367331,0,4.934117311367331,0 ) ;
  }

  @Test
  public void test30() {
    ell.dbrent(5.184564012525399,0,5.184564012525399,0 ) ;
  }

  @Test
  public void test31() {
    ell.dbrent(55.909234536690185,0.0,100.0,0 ) ;
  }

  @Test
  public void test32() {
    ell.dbrent(57.844289414912566,0,-51.4338603324688,0 ) ;
  }

  @Test
  public void test33() {
    ell.dbrent(-59.060307174145365,-59.060307174145365,-59.060307174145365,0 ) ;
  }

  @Test
  public void test34() {
    ell.dbrent(59.154354975234526,-14.65270445836697,-88.45976389196846,0 ) ;
  }

  @Test
  public void test35() {
    ell.dbrent(-60.66613771094638,-20.458179702574867,-60.66613771094638,0 ) ;
  }

  @Test
  public void test36() {
    ell.dbrent(61.69675583224944,0.0,56.51713996848636,0 ) ;
  }

  @Test
  public void test37() {
    ell.dbrent(-62.68763888716471,-8.089120432855196,-11.333878532881926,0 ) ;
  }

  @Test
  public void test38() {
    ell.dbrent(-62.78612826292564,0.0,-62.78612826292564,0 ) ;
  }

  @Test
  public void test39() {
    ell.dbrent(-67.14047156335374,0.0,-67.14047156335357,0 ) ;
  }

  @Test
  public void test40() {
    ell.dbrent(-69.02731276866085,-72.360492647881,-49.15883882362222,0 ) ;
  }

  @Test
  public void test41() {
    ell.dbrent(70.36482029742565,0,70.36482029742567,0 ) ;
  }

  @Test
  public void test42() {
    ell.dbrent(72.15412501387365,0.0,-72.15412501387365,0 ) ;
  }

  @Test
  public void test43() {
    ell.dbrent(-72.79120830912987,-58.18974069871952,-72.79120830912987,0 ) ;
  }

  @Test
  public void test44() {
    ell.dbrent(8.032112707715669,0.0,-100.0,0 ) ;
  }

  @Test
  public void test45() {
    ell.dbrent(-86.8881299655639,0,-86.88812996556392,0 ) ;
  }

  @Test
  public void test46() {
    ell.dbrent(-9.23752051783427,26.912356533532346,63.06223358489896,0 ) ;
  }

  @Test
  public void test47() {
    ell.dbrent(97.1756654935269,23.84681263816684,-49.48204021719323,0 ) ;
  }
}
