import org.junit.Test;

public class TestellfTest {

  @Test
  public void test0() {
    ell.ellf(15.878543324462619,-5.89087685158616 ) ;
  }

  @Test
  public void test1() {
    ell.ellf(180.64157758628141,0.6120505332784205 ) ;
  }

  @Test
  public void test2() {
    ell.ellf(18.153059903634343,-1.5587644585351736 ) ;
  }

  @Test
  public void test3() {
    ell.ellf(18.627066459992104,-2.847243519413894 ) ;
  }

  @Test
  public void test4() {
    ell.ellf(18.84346423074008,1.0000000000014357 ) ;
  }

  @Test
  public void test5() {
    ell.ellf(-21.556717478698786,2.375892795086614 ) ;
  }

  @Test
  public void test6() {
    ell.ellf(-26.703537555513243,-0.31213980523231494 ) ;
  }

  @Test
  public void test7() {
    ell.ellf(31.415926531013167,-1.2927847321447523 ) ;
  }

  @Test
  public void test8() {
    ell.ellf(-3.141592655885384,-3.373914617819291 ) ;
  }

  @Test
  public void test9() {
    ell.ellf(-37.69911185494858,1.0016571996079269 ) ;
  }

  @Test
  public void test10() {
    ell.ellf(43.98229715013381,-51.16310402433458 ) ;
  }

  @Test
  public void test11() {
    ell.ellf(-45.551681276468315,-52.74897804532594 ) ;
  }

  @Test
  public void test12() {
    ell.ellf(-47.12388978733015,0.3895712755971772 ) ;
  }

  @Test
  public void test13() {
    ell.ellf(47.12388979431949,-1.0000476582497781 ) ;
  }

  @Test
  public void test14() {
    ell.ellf(50.26548219649212,1.0014552693767094 ) ;
  }

  @Test
  public void test15() {
    ell.ellf(50.83542974180628,-11.965571208349601 ) ;
  }

  @Test
  public void test16() {
    ell.ellf(-51.83627878423325,1.0 ) ;
  }

  @Test
  public void test17() {
    ell.ellf(-59.69026040236676,0.7991197463866397 ) ;
  }

  @Test
  public void test18() {
    ell.ellf(6.091972135767932,0.9999999999999983 ) ;
  }

  @Test
  public void test19() {
    ell.ellf(6.283185305964967,12.818678574008459 ) ;
  }

  @Test
  public void test20() {
    ell.ellf(62.83185307169586,-36.283440521616825 ) ;
  }

  @Test
  public void test21() {
    ell.ellf(62.83200997392531,-6.285909530484991E-5 ) ;
  }

  @Test
  public void test22() {
    ell.ellf(-63.718570986652814,0.6279298566159213 ) ;
  }

  @Test
  public void test23() {
    ell.ellf(65.98718006679528,1.0000000000000855 ) ;
  }

  @Test
  public void test24() {
    ell.ellf(68.89003583511158,0.16209208131562036 ) ;
  }

  @Test
  public void test25() {
    ell.ellf(-69.11503838498024,1.8973218885318504 ) ;
  }

  @Test
  public void test26() {
    ell.ellf(-72.25663102178588,1.1156450298637792 ) ;
  }

  @Test
  public void test27() {
    ell.ellf(-72.25663102577907,0.9012217863614327 ) ;
  }

  @Test
  public void test28() {
    ell.ellf(72.25663103244499,-100.0 ) ;
  }

  @Test
  public void test29() {
    ell.ellf(75.37994873897475,-39.34696282774843 ) ;
  }

  @Test
  public void test30() {
    ell.ellf(-75.41496735791435,-59.726847312496155 ) ;
  }

  @Test
  public void test31() {
    ell.ellf(-80.11061266048979,-1.0 ) ;
  }

  @Test
  public void test32() {
    ell.ellf(81.68140634341212,1.032874043081435 ) ;
  }

  @Test
  public void test33() {
    ell.ellf(81.74605083966838,-96.41841309300187 ) ;
  }

  @Test
  public void test34() {
    ell.ellf(84.81830036736733,0.6728747738114009 ) ;
  }

  @Test
  public void test35() {
    ell.ellf(-87.96465554340422,-2.0195384328308322E-4 ) ;
  }

  @Test
  public void test36() {
    ell.ellf(90.2513439555498,0.97546684738316 ) ;
  }

  @Test
  public void test37() {
    ell.ellf(91.1061869620793,1.5385173379335395 ) ;
  }

  @Test
  public void test38() {
    ell.ellf(-94.2477796155656,-1.4891044578522181 ) ;
  }
}
