import org.junit.Test;

public class TestcisiTest {

  @Test
  public void test0() {
    frenel.cisi(0.0 ) ;
  }

  @Test
  public void test1() {
    frenel.cisi(-1.159107973296301 ) ;
  }

  @Test
  public void test2() {
    frenel.cisi(-16.84259480433117 ) ;
  }

  @Test
  public void test3() {
    frenel.cisi(-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test4() {
    frenel.cisi(1.9999999999999998 ) ;
  }

  @Test
  public void test5() {
    frenel.cisi(-2.0 ) ;
  }

  @Test
  public void test6() {
    frenel.cisi(2.0 ) ;
  }

  @Test
  public void test7() {
    frenel.cisi(2.465190328815662E-32 ) ;
  }

  @Test
  public void test8() {
    frenel.cisi(-42.87245551582435 ) ;
  }

  @Test
  public void test9() {
    frenel.cisi(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test10() {
    frenel.cisi(4.4455174989701545E-162 ) ;
  }

  @Test
  public void test11() {
    frenel.cisi(4.689086499773907 ) ;
  }

  @Test
  public void test12() {
    frenel.cisi(52.2205619513166 ) ;
  }

  @Test
  public void test13() {
    frenel.cisi(5.551115123125783E-17 ) ;
  }

  @Test
  public void test14() {
    frenel.cisi(5.760362238552858 ) ;
  }

  @Test
  public void test15() {
    frenel.cisi(57.916013203174714 ) ;
  }

  @Test
  public void test16() {
    frenel.cisi(60.27190606970504 ) ;
  }

  @Test
  public void test17() {
    frenel.cisi(6.367254175214924 ) ;
  }

  @Test
  public void test18() {
    frenel.cisi(7.319445945887807 ) ;
  }

  @Test
  public void test19() {
    frenel.cisi(-91.77701273915315 ) ;
  }

  @Test
  public void test20() {
    frenel.cisi(9.860761315262648E-32 ) ;
  }
}
