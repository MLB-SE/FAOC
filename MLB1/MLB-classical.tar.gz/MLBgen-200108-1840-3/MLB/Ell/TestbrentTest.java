import org.junit.Test;

public class TestbrentTest {

  @Test
  public void test0() {
    ell.brent(0.0,0.0,0.0,0 ) ;
  }

  @Test
  public void test1() {
    ell.brent(0.9357249223991033,-74.06369947946827,0.9357249223991033,0 ) ;
  }

  @Test
  public void test2() {
    ell.brent(-100.0,0.0,-100.0,0 ) ;
  }

  @Test
  public void test3() {
    ell.brent(-100.0,-100.0,-100.0,0 ) ;
  }

  @Test
  public void test4() {
    ell.brent(100.0,100.0,100.0,0 ) ;
  }

  @Test
  public void test5() {
    ell.brent(11.928170824855513,0.0,-85.85143862016848,0 ) ;
  }

  @Test
  public void test6() {
    ell.brent(13.037188864619111,8.354312604446946,7.393301863006769,0 ) ;
  }

  @Test
  public void test7() {
    ell.brent(-15.06131782415359,0,-78.87091972427302,0 ) ;
  }

  @Test
  public void test8() {
    ell.brent(17.307715595723664,0,83.12075105549724,0 ) ;
  }

  @Test
  public void test9() {
    ell.brent(18.637529243804508,50.35290723662834,18.637529243804508,0 ) ;
  }

  @Test
  public void test10() {
    ell.brent(-1.9052316371753035,0,-1.9052316371753033,0 ) ;
  }

  @Test
  public void test11() {
    ell.brent(-19.068698038360115,-38.10883854279056,-57.148979047221,0 ) ;
  }

  @Test
  public void test12() {
    ell.brent(2.22045516497266E-16,0.0,2.22045516497266E-16,0 ) ;
  }

  @Test
  public void test13() {
    ell.brent(-23.337740658537427,0,-23.33774065853743,0 ) ;
  }

  @Test
  public void test14() {
    ell.brent(23.665201250526316,0,23.665201250526316,0 ) ;
  }

  @Test
  public void test15() {
    ell.brent(-28.24690001075716,0,-28.246900010757162,0 ) ;
  }

  @Test
  public void test16() {
    ell.brent(-28.93542730321596,21.752121279805948,54.4070047375489,0 ) ;
  }

  @Test
  public void test17() {
    ell.brent(31.956696467688914,43.630089855174845,-19.5832816576675,0 ) ;
  }

  @Test
  public void test18() {
    ell.brent(-34.436297973562745,-80.18598764828937,-34.436297973562745,0 ) ;
  }

  @Test
  public void test19() {
    ell.brent(36.25193572644453,0.0,36.25193572644453,0 ) ;
  }

  @Test
  public void test20() {
    ell.brent(37.547457556537495,-3.1880464909489064,-23.79895979136981,0 ) ;
  }

  @Test
  public void test21() {
    ell.brent(-38.52241872850494,0.0,52.106689808815645,0 ) ;
  }

  @Test
  public void test22() {
    ell.brent(40.604780440070066,0.0,14.538061936274273,0 ) ;
  }

  @Test
  public void test23() {
    ell.brent(-41.146225760279705,-41.06409676934024,-16.111699594582248,0 ) ;
  }

  @Test
  public void test24() {
    ell.brent(-41.82246235367608,-8.663616102191284,-36.06088213877088,0 ) ;
  }

  @Test
  public void test25() {
    ell.brent(-42.3397421714693,0,8.582815025771538,0 ) ;
  }

  @Test
  public void test26() {
    ell.brent(-43.09868657606562,0.0,-18.796513919556673,0 ) ;
  }

  @Test
  public void test27() {
    ell.brent(47.61424382056206,0,47.61424382056205,0 ) ;
  }

  @Test
  public void test28() {
    ell.brent(-5.012707564483792,-4.648042386368678,-5.012707564483792,0 ) ;
  }

  @Test
  public void test29() {
    ell.brent(53.75490736324267,0,53.75490736324268,0 ) ;
  }

  @Test
  public void test30() {
    ell.brent(-59.41072825984548,0.0,59.41072825984548,0 ) ;
  }

  @Test
  public void test31() {
    ell.brent(59.50417597103862,-66.62355725333073,65.77760204165818,0 ) ;
  }

  @Test
  public void test32() {
    ell.brent(64.22161868927498,0,-26.50788189599338,0 ) ;
  }

  @Test
  public void test33() {
    ell.brent(-67.2588384376722,0.0,81.21365165499532,0 ) ;
  }

  @Test
  public void test34() {
    ell.brent(-68.63224557366117,58.0987441970546,41.657151120884436,0 ) ;
  }

  @Test
  public void test35() {
    ell.brent(-69.01006432892889,27.98748374664804,-69.01006432892889,0 ) ;
  }

  @Test
  public void test36() {
    ell.brent(71.63481744916277,14.68956725792134,83.47921512786121,0 ) ;
  }

  @Test
  public void test37() {
    ell.brent(71.83688883065422,-1.0715125784506143,-73.97991398755545,0 ) ;
  }

  @Test
  public void test38() {
    ell.brent(-73.36512439410686,0,-73.36512439410686,0 ) ;
  }

  @Test
  public void test39() {
    ell.brent(73.97226160492225,71.4896125483228,73.97226160492225,0 ) ;
  }

  @Test
  public void test40() {
    ell.brent(78.6545502433582,0.0,-78.6545502433582,0 ) ;
  }

  @Test
  public void test41() {
    ell.brent(80.95678322090114,49.57153175422772,18.186280287554297,0 ) ;
  }

  @Test
  public void test42() {
    ell.brent(83.4123635001022,-17.61054860079456,-3.630106042394047,0 ) ;
  }

  @Test
  public void test43() {
    ell.brent(-8.555267662733861,0,-8.55526766273386,0 ) ;
  }

  @Test
  public void test44() {
    ell.brent(88.27178556025217,57.25417428795507,-55.322849563706455,0 ) ;
  }

  @Test
  public void test45() {
    ell.brent(89.8120228819638,0.0,-51.2291896160229,0 ) ;
  }

  @Test
  public void test46() {
    ell.brent(-91.14868777953639,-84.19114129729735,-77.2335948150583,0 ) ;
  }

  @Test
  public void test47() {
    ell.brent(99.94742901802874,99.97371450901437,100.0,0 ) ;
  }
}
