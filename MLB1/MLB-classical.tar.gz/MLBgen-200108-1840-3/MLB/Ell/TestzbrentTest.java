import org.junit.Test;

public class TestzbrentTest {

  @Test
  public void test0() {
    ell.zbrent(-100.0,-72.25663103256524,0 ) ;
  }

  @Test
  public void test1() {
    ell.zbrent(100.0,91.10618695410399,0 ) ;
  }

  @Test
  public void test2() {
    ell.zbrent(-144.51200126848292,99.61455105253899,0 ) ;
  }

  @Test
  public void test3() {
    ell.zbrent(-16.225496936142292,-78.53981633974482,0 ) ;
  }

  @Test
  public void test4() {
    ell.zbrent(-16.80739099532407,-48.96284744059196,0 ) ;
  }

  @Test
  public void test5() {
    ell.zbrent(17.32526140404036,92.09688077641042,0 ) ;
  }

  @Test
  public void test6() {
    ell.zbrent(-30.38111611808353,34.55751918948773,0 ) ;
  }

  @Test
  public void test7() {
    ell.zbrent(-31.31643725258182,0,0 ) ;
  }

  @Test
  public void test8() {
    ell.zbrent(-31.41592653589793,42.37270233931737,0 ) ;
  }

  @Test
  public void test9() {
    ell.zbrent(3.1799463055003514,50.2654824574367,0 ) ;
  }

  @Test
  public void test10() {
    ell.zbrent(-36.25884529008185,99.50100540012443,0 ) ;
  }

  @Test
  public void test11() {
    ell.zbrent(3.7452098268773852,0,0 ) ;
  }

  @Test
  public void test12() {
    ell.zbrent(-3.8877840168763953,12.566370614359174,0 ) ;
  }

  @Test
  public void test13() {
    ell.zbrent(40.05949635072693,19.23409533636631,0 ) ;
  }

  @Test
  public void test14() {
    ell.zbrent(-40.18649357337729,-116.2389281828223,0 ) ;
  }

  @Test
  public void test15() {
    ell.zbrent(52.66515725537343,-80.89728467757254,0 ) ;
  }

  @Test
  public void test16() {
    ell.zbrent(-54.1887601288493,-75.39822368615503,0 ) ;
  }

  @Test
  public void test17() {
    ell.zbrent(56.762660604523866,53.40707511102648,0 ) ;
  }

  @Test
  public void test18() {
    ell.zbrent(6.283185307179586,0,0 ) ;
  }

  @Test
  public void test19() {
    ell.zbrent(63.75226257920656,-7.725085630113,0 ) ;
  }

  @Test
  public void test20() {
    ell.zbrent(74.63812005920065,3.141592653589793,0 ) ;
  }

  @Test
  public void test21() {
    ell.zbrent(-83.00151276914649,25.132741228718345,0 ) ;
  }

  @Test
  public void test22() {
    ell.zbrent(-8.46788719703622,86.24686638193026,0 ) ;
  }

  @Test
  public void test23() {
    ell.zbrent(85.71688007006043,0,0 ) ;
  }

  @Test
  public void test24() {
    ell.zbrent(-86.41272165623074,-81.68140899333461,0 ) ;
  }

  @Test
  public void test25() {
    ell.zbrent(89.10741881548407,81.53837892723436,0 ) ;
  }

  @Test
  public void test26() {
    ell.zbrent(-90.37182545105777,-17.91953428504935,0 ) ;
  }

  @Test
  public void test27() {
    ell.zbrent(-91.10618695410399,0,0 ) ;
  }

  @Test
  public void test28() {
    ell.zbrent(-94.2477796076938,0,0 ) ;
  }

  @Test
  public void test29() {
    ell.zbrent(-95.58382682118567,-24.078276710165042,0 ) ;
  }
}
