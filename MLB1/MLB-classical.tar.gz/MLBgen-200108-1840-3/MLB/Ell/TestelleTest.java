import org.junit.Test;

public class TestelleTest {

  @Test
  public void test0() {
    ell.elle(108.3849465467543,0.999999999999834 ) ;
  }

  @Test
  public void test1() {
    ell.elle(-12.566370591219309,1.037004455262768 ) ;
  }

  @Test
  public void test2() {
    ell.elle(18.769505687454014,12.505507536550924 ) ;
  }

  @Test
  public void test3() {
    ell.elle(19.394333674203196,-83.99527547037775 ) ;
  }

  @Test
  public void test4() {
    ell.elle(-19.959091428635517,0.55380960525315 ) ;
  }

  @Test
  public void test5() {
    ell.elle(-21.991147707802696,-1.00000200380497 ) ;
  }

  @Test
  public void test6() {
    ell.elle(21.991148574792582,13.425609635172915 ) ;
  }

  @Test
  public void test7() {
    ell.elle(25.132741221540044,-1.9648126614044248 ) ;
  }

  @Test
  public void test8() {
    ell.elle(25.132741222830028,1.0560922254663314 ) ;
  }

  @Test
  public void test9() {
    ell.elle(25.132741228519162,67.29578062261223 ) ;
  }

  @Test
  public void test10() {
    ell.elle(26.703537548571163,-0.24452758731625165 ) ;
  }

  @Test
  public void test11() {
    ell.elle(26.70353772889697,-1.000000000000009 ) ;
  }

  @Test
  public void test12() {
    ell.elle(28.27433387114161,0.8738799079250583 ) ;
  }

  @Test
  public void test13() {
    ell.elle(-28.274333880322153,0.439759905428147 ) ;
  }

  @Test
  public void test14() {
    ell.elle(28.27433389533911,-0.8506664205321357 ) ;
  }

  @Test
  public void test15() {
    ell.elle(-28.499476367227786,94.71825055162057 ) ;
  }

  @Test
  public void test16() {
    ell.elle(31.41592652647672,1.43722789400359 ) ;
  }

  @Test
  public void test17() {
    ell.elle(31.415926536273165,16.292687322265284 ) ;
  }

  @Test
  public void test18() {
    ell.elle(37.69911184192902,-1.9904530843789416 ) ;
  }

  @Test
  public void test19() {
    ell.elle(-39.797422642205426,-1.1573258036374476 ) ;
  }

  @Test
  public void test20() {
    ell.elle(-40.82902143791776,13.781222690971504 ) ;
  }

  @Test
  public void test21() {
    ell.elle(-40.840704483560955,-0.526167277558885 ) ;
  }

  @Test
  public void test22() {
    ell.elle(43.982297149772705,18.199933722068124 ) ;
  }

  @Test
  public void test23() {
    ell.elle(4.71238898038469,1.0 ) ;
  }

  @Test
  public void test24() {
    ell.elle(-5.384692790273252E-7,0.011627243137471016 ) ;
  }

  @Test
  public void test25() {
    ell.elle(-56.45889181500876,3.129509808394303 ) ;
  }

  @Test
  public void test26() {
    ell.elle(-56.51385890234203,0.9999999999999115 ) ;
  }

  @Test
  public void test27() {
    ell.elle(-5.770866795236752,-2.0399861706578957 ) ;
  }

  @Test
  public void test28() {
    ell.elle(-58.119464091411174,-0.7184462719687258 ) ;
  }

  @Test
  public void test29() {
    ell.elle(59.59103527024294,-10.09464682821463 ) ;
  }

  @Test
  public void test30() {
    ell.elle(62.75092337540007,-0.2904802401715898 ) ;
  }

  @Test
  public void test31() {
    ell.elle(6.283185311814944,1.9229140805609717 ) ;
  }

  @Test
  public void test32() {
    ell.elle(-65.56235225669025,0.7299538813644375 ) ;
  }

  @Test
  public void test33() {
    ell.elle(69.16202532767471,-0.6535768676475291 ) ;
  }

  @Test
  public void test34() {
    ell.elle(-79.29258954382064,-27.366832554133296 ) ;
  }

  @Test
  public void test35() {
    ell.elle(91.10618695082016,-0.49455578840474956 ) ;
  }

  @Test
  public void test36() {
    ell.elle(-9.424777958475273,3.962667174475919 ) ;
  }

  @Test
  public void test37() {
    ell.elle(-94.24777962765496,-0.7055460539766543 ) ;
  }

  @Test
  public void test38() {
    ell.elle(94.24825004674379,-1.0000000001208023 ) ;
  }
}
