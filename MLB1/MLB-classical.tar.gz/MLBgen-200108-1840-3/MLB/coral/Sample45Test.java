import org.junit.Test;

public class Sample45Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark45(0.0,-25.739842826230962,50.92059122871345 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark45(1.1102230246251565E-16,1.0000000000068106,0.9688001689097476 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark45(1.1102230246251565E-16,1.000000000272829,1.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark45(-26.540294672359323,-96.83091510998048,12.85813385286059 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark45(26.67629770754752,46.12171745252181,15.548101029746348 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark45(-334.3319523163409,-333.4079242647779,34.03331675410493 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark45(-38.112903188931725,-62.69668778205022,2.419969800942937 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark45(43.088673898651706,96.35483112112647,5.890948012641346 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark45(60.47719352975173,-18.924829207044795,42.93937427066248 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark45(72.01445222486416,54.29392255571534,88.33578433632908 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark45(89.32397465396548,43.67941146988534,27.669928553874485 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark45(90.04396764873806,1.0,9.251894501412707 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark45(92.01953024506494,-28.030038814100905,14.443513098005909 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark45(92.73396221340573,58.670354197932,22.376838602288444 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark45(97.17407528079701,99.17407528079701,81.3556743098093 ) ;
  }
}
