import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(-0.3042625780455239,-82.26911139989937,-87.94626296894722,-82.6702969790475 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(0.5525773047237976,-100.0,15.708423091246349,197.21881533464318 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(-0.9795990942582478,-26.861121717204583,100.0,71.53416816350361 ) ;
  }
}
