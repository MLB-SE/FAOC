import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(0.1867983493238512,1.3121341046610837,47.122621708909236,52.80783561123502 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(-0.9601134740283186,3.8793563147264067,-17.61492205197592,-4.30267250369597 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(-0.9745426792033811,35.49552617821206,60.527808279792,-15.3484684512498 ) ;
  }
}
