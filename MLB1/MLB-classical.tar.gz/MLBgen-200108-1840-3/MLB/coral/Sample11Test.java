import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(-0.050891400324132974,-57.415487606127826,-68.44077018068589,13.61460783233413 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(-0.67498416429126,-74.55765765749737,-69.92430363261875,-60.54692690674861 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(0.8334706386947115,37.87873979361401,-77.57297421365192,-37.48232608183224 ) ;
  }
}
