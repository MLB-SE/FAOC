import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(100.0,66.36171516853389,0,-66.95297861400827 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(-20.533740482326934,84.09429759559352,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(20.65064440013013,-51.11996629054396,5.166530952968186,21.378399228101657 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(-36.680045610325806,8.09568529053391,-70.57458485965935,71.17346367740267 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(-44.682327807560526,-87.41099941759606,66.05890225460188,-1.3960993166138849 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(46.69512242418102,63.05001117364313,0,-60.59974921116695 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(-48.69613349382395,74.16857699488624,-55.757138710239616,5.9167688694602845 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark23(-60.031678703429534,61.29887263705788,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark23(70.25622510702075,-53.96177076860407,19.78355888459484,55.968336617799906 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark23(-77.72781706131914,-74.92519934869155,29.80654572612437,91.90120031180757 ) ;
  }
}
