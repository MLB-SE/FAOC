import org.junit.Test;

public class Sample39Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark39(1.10780545128826,2.593914208069126E-16 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark39(44.996181483914825,83.70781704779097 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark39(75.87050026594451,-78.89129174440401 ) ;
  }
}
