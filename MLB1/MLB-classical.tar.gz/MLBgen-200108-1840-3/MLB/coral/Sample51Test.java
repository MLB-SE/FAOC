import org.junit.Test;

public class Sample51Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark51(0.04101901084237138,0.031179534970549615 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark51(0.4130623524821109,0.7345950768952297 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark51(1.1362074680855778,14.326580609990636 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark51(12.355973201953546,25.71614077899062 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark51(1.2718715816833093,48.728128418316636 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark51(13.143685635583168,33.66548749826018 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark51(16.62293926753506,33.43335747129058 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark51(18.976426218347882,19.677710511620205 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark51(24.422105224085108,25.577894775914892 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark51(38.527687656811594,45.90976000476499 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark51(79.00001086910976,84.26377716604051 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark51(-93.39153965335638,76.56346400312822 ) ;
  }
}
