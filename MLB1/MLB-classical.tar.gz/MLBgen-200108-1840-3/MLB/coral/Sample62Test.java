import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-17.15311244220186 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,2.04268344457779 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(1.054080651900324,41.16091936162795,42.215000013528275,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(12.608222770403515,31.56260038433055,-89.36870234354419,10.056239961303277 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(14.866194423656617,0.0,78.26082925298157,-46.634468181906634 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(20.71837246545431,-11.632458562048484,66.27679422608793,-24.052750627026768 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(23.555284593398852,2.4955604920052608,2.0962802154859457,24.014306217153983 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(23.80005171776895,-2.339934608381947,80.44416232771998,-54.44856748223516 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(2.5523010269888706,54.86814115476921,100.0,34.56867000253894 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(2.561084254675502,-2.7755575615628914E-17,36.18671722932275,-33.48674382301687 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(31.873541747750068,9.367717293945361,-34.969800776733194,76.21105981842862 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(43.28362414327307,47.22836872276349,-90.40687850611545,95.05577042799851 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(48.759134771785455,64.68411237687405,48.46081226004429,80.75985940312898 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(4.90461323567726,-1.1856868025571288,75.58945078618655,75.30312358657548 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(-64.49520881693348,98.7791638929665,82.26033359044428,-55.43883939161907 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(65.97999008050911,-46.609647524898136,-2.0910317976640584,57.34855003097343 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(68.50689585524846,-68.26760666474686,-19.107963554535424,-79.85301598656254 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(-68.88155247490897,-2.2380348014795715,66.90409428656679,25.35463630762544 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(70.67253829435708,14.17173870197523,79.99974454578842,22.21332615059967 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(88.43513716846394,4.427537877676116,-99.41693121680129,69.09289299962745 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(90.80772920681679,-65.77741718014889,33.378814451606054,-1.3805304783876775 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(93.14266249826494,-56.89400008460059,67.2820383491277,-16.401966021478003 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(9.758278074185009,31.959064957699525,99.83450278358936,-100.0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(98.32116249701926,94.99710864151572,-80.78848403130257,-25.81101509427215 ) ;
  }
}
