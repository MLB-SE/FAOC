import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark05(-25.13590069152742,-70.61622965200722,76.97168562442866 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(64.23630893196619,79.01730572496697,7.179385984958515 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(-90.28104142994053,65.1629928236832,55.97895309825719 ) ;
  }
}
