import org.junit.Test;

public class Sample32Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark32(25.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark32(7.854066623391958 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark32(80.7081673837788 ) ;
  }
}
