import org.junit.Test;

public class Sample03Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark03(-13.799933899493778,-72.59386407422554 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark03(14.985497387194215,-94.88407712792237 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark03(21.417499209467223,54.89421846709999 ) ;
  }
}
