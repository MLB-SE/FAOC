import org.junit.Test;

public class Sample18Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark18(0.2680433777347133 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark18(0.9595496299847904 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark18(0.9722668404723862 ) ;
  }
}
