import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(-0.26927714590685525,-94.2615797533545,66.90262205728834,73.44266241551617 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(-0.6014934614214424,-92.2660115963151,90.7337488100629,1.4397983216493344 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(0.6682203039466259,47.892058521859354,95.7310293129382,-92.3443147580207 ) ;
  }
}
