import org.junit.Test;

public class Sample54Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark54(13.180752003441796,-56.33919714406377,12.058319939863352 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark54(16.207920492205275,-41.63574218752517,86.59299494729652 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark54(17.674677640971577,73.24614357256502,79.16666128686384 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark54(18.330129886407427,2.7367688528364003,58.327823945866 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark54(20.219636611611662,39.96116443372543,-68.50635000313761 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark54(24.529161455417196,12.712639993460797,29.0749291567694 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark54(24.55286779667869,-8.538494602207791,24.73463006500279 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark54(48.834106510329434,75.913370766072,66.30805475082965 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark54(52.23249713199225,-24.647312557137724,73.06682734355817 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark54(75.96415836390656,-22.556389765478244,39.53773671530115 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark54(76.13571994499796,32.68036078494501,94.16510570531514 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark54(95.67393841124905,-12.135263693752194,-53.95961211163802 ) ;
  }
}
