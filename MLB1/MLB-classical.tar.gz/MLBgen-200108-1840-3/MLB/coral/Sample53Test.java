import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark53(10.116893910589894,-91.98519019590776,-36.359220149102775 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(14.601273317741231,70.23213297821573,-91.1880909250412 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(16.722431727539664,14.293729977068708,25.615028942581606 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark53(20.109509433364778,-51.696014641083444,29.031236470419884 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark53(38.4632011018939,-70.41636887642807,-92.72221828564535 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark53(42.50751602480665,25.232691933107645,52.47254620489346 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark53(47.270771539718154,33.27379035971333,49.982116451990635 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark53(48.60673890844805,-21.598123741097993,54.967759832515526 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark53(69.79901897172925,2.782220162256402,86.56441827998596 ) ;
  }
}
