import org.junit.Test;

public class Sample04Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark04(-64.61936993780037 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark04(-664.9741155841409 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark04(-75.10547128216096 ) ;
  }
}
