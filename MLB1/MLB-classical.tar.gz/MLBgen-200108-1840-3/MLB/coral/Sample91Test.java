import org.junit.Test;

public class Sample91Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark91(100.0,-100.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark91(13.957558353462261,96.98853637342748 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark91(4.455666917451609,-87.68937557326166 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark91(-69.11503837897546,-43.982297150257104 ) ;
  }
}
