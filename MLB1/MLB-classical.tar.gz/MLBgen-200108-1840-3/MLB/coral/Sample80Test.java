import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(-1.83672577468883,1.816670632421502 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(-35.36402346368865,-76.00355479827697 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(49.57795842978979,-91.6727822210729 ) ;
  }
}
