import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(109.46652247928087,-124.82868294703752,178.82687071104175 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(15.987355180002055,-45.814850634133464,69.75166302547157 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(16.39939000541497,-39.80879422295018,16.09837656823929 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark55(20.827114667097163,-14.111850952458283,-60.894749798770434 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark55(22.067306196616656,65.69463758847408,72.0531485602782 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark55(23.477982395310377,-98.46382155395838,28.842311631476008 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark55(31.955150088984198,44.51110034290238,89.94161184809619 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark55(50.69997357492193,-18.970256331215296,27.52602081543776 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark55(55.51535557745922,62.493675758623084,-46.71288691071509 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark55(65.72399139168397,-15.597024199753463,80.34022073105632 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark55(70.63493903146826,2.782411574633421,77.38745639116092 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark55(76.16796188586525,40.64450099293222,95.46676250474741 ) ;
  }
}
