import org.junit.Test;

public class Sample43Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark43(100.0,100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark43(18.75104075732412,60.17780674856513 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark43(26.471695611094432,86.1888729672211 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark43(3.073285777423763,70.51575375669663 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark43(3.201053589406051,3.201053589406051 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark43(56.57695439480926,0.6439031879097428 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark43(79.25092711225884,62.91688059984958 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark43(8.992967317583094,80.87346117511767 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark43(98.85432843787055,99.89927616403094 ) ;
  }
}
