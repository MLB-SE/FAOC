import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(-147.03713559771617,-406.71013714619835,-590.0699054256245 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(-52.952158282179695,76.64270537013465,12.49425699797338 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(89.09978207150542,-75.041142397311,46.248920374008975 ) ;
  }
}
