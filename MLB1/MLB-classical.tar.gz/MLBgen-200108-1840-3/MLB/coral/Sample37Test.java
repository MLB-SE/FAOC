import org.junit.Test;

public class Sample37Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark37(-18.29075602304036,-9.343896917144008,-55.02979427654171 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark37(2.7271802334387405,-86.9666243458905,4.484440545629937 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark37(51.45799282080452,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark37(57.73883608523235,-43.12863788997523,70.13199649760367 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark37(69.11510363663264,0,0 ) ;
  }
}
