import org.junit.Test;

public class Sample63Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,13.41120941971947,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,-9.059481931913012,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark63(0.9831802622479923,99.59783621292387,98.61465595067587,-8.881784197001252E-16,-6.92922991596805 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark63(100.0,0.0,100.0,100.0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark63(100.0,3.2177790703508946,17.188379261409533,100.0,18.71932636833127 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark63(1.0455943500266012,50.847759552335454,51.90487559067793,-0.010816583912006355,-16.894798252628867 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark63(13.371383276310736,9.985709084710853,22.506902341046498,0.9636003485864582,107.97696799825536 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark63(151.4496172752048,3.330570261240122,23.726271608542746,85.77799019842593,93.53525503970016 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark63(16.661071278578465,5.277748660024395,20.316709477053678,1.6229939194399807,65.99138979494147 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark63(18.63139354905374,62.975959909256886,28.837335432666805,51.26235354014591,77.57094438498649 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark63(20.73962925145794,1.3772839906261538,-3.899368652703242,-60.67141190407619,93.13513989633434 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark63(-22.489223864807272,-86.14457548201901,-19.010265729464848,5.061722882900057,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark63(25.399317260938606,93.0368060548911,47.679448825230736,70.75667449059897,42.964133988890744 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark63(27.080207035521582,44.25854704538534,96.81933955654873,61.525221034833976,80.45017692204462 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark63(28.315866937283403,38.8300455832605,51.36025057368494,40.88759925401823,-21.71327481526913 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark63(2.862242584058521,10.143955883232053,14.671936648147636,38.05088866696235,0.9435653287389556 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark63(29.872270443575303,2.378360399668651,-44.18650420255137,85.24471564798938,-15.14795826126712 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark63(32.89797581080677,-32.20840333955914,32.19176131067812,46.68365204955792,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark63(40.44916398254304,22.949942864920363,69.62848463441424,-6.229377786949669,99.58657201489319 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark63(4.6609736458818105,34.92864943558483,75.09297240423442,-24.726034730474225,69.3871897602881 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark63(55.91495271142094,-0.33402444755836314,-35.40046034800713,29.63876762750138,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark63(60.38818771426611,-16.26211693752863,41.9794938413865,-85.01769695898636,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark63(64.95722291871968,72.18798807829586,9.398996391025477,-8.944268432274626,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark63(66.18116508094566,19.171976052020227,100.0,3.451974115833088,62.219702356270716 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark63(67.50817678521905,10.522553066091708,76.86039684153401,2.6847314743954556,0.8552778365144909 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark63(77.42140947506448,49.38066272131525,99.12321374759921,51.960349608507016,-92.75589752157553 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark63(80.26698628084634,9.880065245979125,17.10774952148148,96.24504673970384,-77.68157401362608 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark63(86.6690396057669,-0.3069387583747982,96.218312491239,-62.019340512893905,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark63(86.75268220152543,74.43945185127347,59.60790693538175,-32.49031015271578,3.5097989935653544 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark63(89.80122326501333,-7.970624583814896,-75.53243413840704,-21.163208666227135,0 ) ;
  }
}
