import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,19.617942847799938,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0,2.3041906403896064,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(10.44590641941779,-8.046384229850512,-92.14103956693297,-49.53078745212276,-80.97111421000001 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(62.593516295614194,-7.7405656688914775,27.091603373002826,-77.87846030662533,73.47536055849727 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(-91.0158225943684,-70.26534038235835,-94.26128952832417,77.5789212211103,63.81860330308308 ) ;
  }
}
