import org.junit.Test;

public class Sample40Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark40(2.369037490027793,100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark40(4.799728893273652,18.237668555652267 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark40(5.26024717062208,-27.542505606758255 ) ;
  }
}
