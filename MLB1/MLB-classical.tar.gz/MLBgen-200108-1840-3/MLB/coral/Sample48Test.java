import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(-18.685834722694096,-47.93311185516478,-96.74890755466583 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(-18.836524715175912,-52.49782371458889,-71.3343484297648 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(-93.31558890787942,-44.089835138773005,99.84471791641224 ) ;
  }
}
