import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(0.07828314221283902,0.2797912475629626 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(10.979145950193782,44.297470566728606 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(17.149872883467808,31.667337601424236 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(3.0508446749647273,5.3186240681813866 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(3.480767792643761,46.51923220735624 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(3.8435509115697375E-14,1.9604645545032252E-7 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(42.098611146866006,1.99163693425686 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(42.43546226744854,47.95498902968828 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(81.60826506863569,87.71122572917403 ) ;
  }
}
