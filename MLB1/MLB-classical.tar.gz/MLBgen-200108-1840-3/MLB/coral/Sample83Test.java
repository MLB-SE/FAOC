import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(0.10219764631845461,0.02917655192363071 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(22.52457174152029,55.37065434705377 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(2.287582567246819,5.232569789761712 ) ;
  }
}
