import org.junit.Test;

public class Sample44Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark44(12.753898778315602,16.862120021353917 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark44(1.4396813036893406,1.4396813036893406 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark44(16.401720212564094,0.5735199071108781 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark44(16.697973351433692,16.697973351433692 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark44(21.846132257876263,63.99274684810163 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark44(83.31110888037642,4.74226058492313 ) ;
  }
}
