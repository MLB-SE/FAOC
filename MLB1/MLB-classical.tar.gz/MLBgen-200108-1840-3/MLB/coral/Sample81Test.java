import org.junit.Test;

public class Sample81Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark81(-66.60430106371163,-1.4480256138972294 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark81(7.1383134866410245,15.487740392068446 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark81(-8.1518906122024,-2.0571053769978107 ) ;
  }
}
