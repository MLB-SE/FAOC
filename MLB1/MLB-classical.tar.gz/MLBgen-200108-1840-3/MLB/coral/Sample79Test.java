import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(6.351726526484915E-9,100.0,100.0,-100.0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(-6.787216962571865E-13,100.0,100.0,-100.0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(-77.796795333116,57.13210645176093,87.70419342704332,58.61545421763307,0 ) ;
  }
}
