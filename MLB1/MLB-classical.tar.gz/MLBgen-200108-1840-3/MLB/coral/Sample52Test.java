import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(15.037800750937308,-39.11572452884613,-12.849547598566005 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(60.07422901040656,14.20133955856815,93.72342914383307 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(61.47008695858,-49.37126981421785,79.51102435517669 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark52(69.81272820208554,74.55671756097786,1.8142741133809324 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark52(77.11528512133283,59.184063428560826,78.05940157394517 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark52(95.36984183187249,-53.46793835056647,41.149997624929625 ) ;
  }
}
