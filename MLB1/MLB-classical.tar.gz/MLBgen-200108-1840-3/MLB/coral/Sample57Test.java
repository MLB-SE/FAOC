import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0,1.752621980031364,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(-0.6984679106779028,-9.389702281807669,5.9582215962214775,49.918557276075376,65.6808617746152 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(0,70.12195027845581,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(10.608892774231519,64.62470066633898,-69.6832710208088,66.05892074371549,16.79361578157209 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(54.64689873043076,23.622875574289154,-17.867320218705146,78.5587833974605,82.09728029699914 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(5.783515758006246,51.09832361951959,96.31826609952287,97.53955514396026,43.73552337227616 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(75.17384677349449,91.43693175224138,-77.98373148752816,1.9950360445577076,27.24858853691626 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(93.15138279816628,-36.71975610646887,19.12766581209607,94.5571976655315,63.487022355323404 ) ;
  }
}
