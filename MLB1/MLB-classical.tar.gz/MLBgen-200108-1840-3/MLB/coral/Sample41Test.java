import org.junit.Test;

public class Sample41Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,1.9999999999999998 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0000000000000004 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark41(10.389594721922586,97.55408376387908 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark41(1.515748006409693,0.7817440125252659 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark41(1.9420799720173918,1.8295946456936818 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark41(-4.461984331761286,24.371288508644497 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark41(-82.90805674167046,9.553501696210901 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark41(9.52031861651223,81.1161479433971 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark41(-9.975263018429146,114.10292336545986 ) ;
  }
}
