import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark07(0,-18.80967524857249,0,-9.193264776070123 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(0,2.7154225780019203,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(0,-57.59590065019388,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(0,-96.16456951439125,0,55.15086823092123 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(-19.8281543714252,22.535712615400403,5.180630964885498,56.72257518052974 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(-71.2725734843333,2.086991930824624,-77.95335108889788,68.43121608085315 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(81.83029937807359,-71.36708505825055,-42.971306063623075,15.250203147848396 ) ;
  }
}
