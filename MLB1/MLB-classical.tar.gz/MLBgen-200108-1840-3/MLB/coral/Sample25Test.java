import org.junit.Test;

public class Sample25Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark25(-100.0,-100.0,-100.0,-100.0,-74.88935047358878 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark25(-100.0,72.63102093956792,100.0,0,-91.85496678455084 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark25(21.738817044911656,-51.53055550803089,29.84286231257377,28.2376698861718,92.64757519990482 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark25(-28.80365253942432,91.62867038048225,-54.07517114385845,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark25(-28.944136866504575,-94.63241201065154,-67.27000381476914,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark25(-3.203073768104602,87.04308991341861,18.746054245405446,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark25(-45.09513889578296,50.044570352203834,-17.377079616791562,62.39880446464937,-21.681806370843987 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark25(-50.569916160401846,-16.893762830632507,92.9438334376282,-14.297076850922409,-99.33930385473322 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark25(73.61484836089747,90.57741849518132,91.02981258038824,-59.76949075887432,-77.4686006741367 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark25(86.18326230407195,-59.64832282655343,74.2855182961805,0,-66.03574221129418 ) ;
  }
}
