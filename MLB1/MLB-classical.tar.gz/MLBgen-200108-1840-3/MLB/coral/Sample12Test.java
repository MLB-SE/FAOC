import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(0.0020867879735817496,-0.6811045659427748,12.800583195388256,-95.52143192331076 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(0.1185421200462713,-0.9970760291448073,20.316190878692495,33.39628353882469 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(0.8706800702427582,-0.9728831841303105,-49.45369587750853,68.65626535958813 ) ;
  }
}
