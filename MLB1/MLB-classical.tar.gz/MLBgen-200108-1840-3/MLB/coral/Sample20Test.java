import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(10.902327635373794,14.14744537268831 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(12.01309709084677,-36.59967845740979 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(14.900634628918429,-65.35921099110438 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(35.21657722531413,50.064888086503174 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(-41.72347371250527,34.95227333904012 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(-59.62729153862525,-56.039998032139636 ) ;
  }
}
