import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(-0.2628394389491502 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(-0.47547340730966425 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(-14.223357989130633 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark31(21.37007443365873 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark31(3.1083706626002368 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark31(4.532119200110472 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark31(-60.52186844012799 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark31(-8.881784197001252E-16 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark31(9.168463622270835 ) ;
  }
}
