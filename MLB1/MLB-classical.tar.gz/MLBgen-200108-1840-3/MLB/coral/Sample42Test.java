import org.junit.Test;

public class Sample42Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark42(1.0,-49.25677652837149 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark42(12.26193863602903,32.27839917364946 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark42(-37.777175274450975,100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark42(3.9467434423128505,4.145944637325909 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark42(45.93122805273392,1.0955842521141506 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark42(4.714070377677345,52.783323649012885 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark42(48.045302620578894,91.78976391987618 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark42(5.48361538315055,10.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark42(85.60497580256353,63.282926469492935 ) ;
  }
}
