import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(37.698467427883536,-47.51563087977422,-17.20386227528193 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(60.62859680097171,-43.65094230904649,64.61400094446947 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(72.64672767329196,-76.82951609365847,-6.083941025936767 ) ;
  }
}
