import org.junit.Test;

public class Sample01Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark01(-43.84359023036477,-62.39683412766468 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark01(-53.49385600626118,-63.25126644316567 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark01(73.41478365423151,-89.53259674102256 ) ;
  }
}
