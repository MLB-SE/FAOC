import org.junit.Test;

public class Sample72Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark72(-100.0,100.0,100.0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark72(-100.0,100.0,35.21204802870115,-88.61912313972763,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark72(100.0,-19.78698016841179,55.44168307499201,67.98405026480086,48.97024402369222,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark72(-136.71052750895836,-67.05945727780305,39.97350339633479,31.59788590671073,-87.94082467975912,-21.88909242140386,26.126885886848754 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark72(-161.21843609651694,-99.97102998177105,-27.538131470592806,-2.1777291909156844,98.53837478969928,143.12622552334213,-127.42484691613245 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark72(2.8697317038367913,85.07014129656062,-2.3935395292958788,0,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark72(-35.9927091902934,-4.254462959418632,-99.99999999999991,60.80769484394984,4.4948256435355365,-39.05234483302326,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark72(38.676500743841785,-83.76595260347655,55.709957562402764,0,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark72(-39.07637366214088,10.802039779832741,0,0,0,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark72(-43.2863923326456,-9.80245623388933,97.10934422492974,-88.74947346639375,-0.949502565776811,55.538359205949135,-88.97912789333857 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark72(51.88399400854209,46.40200393078766,25.275632667791385,61.91362351853405,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark72(-55.76106613050855,59.49776505404415,-64.32888173051809,24.66483468553963,0,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark72(-63.97228903610399,5.80799147192252,0,0,0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark72(65.07781285447419,52.544895803225586,-41.69808531689152,13.403678385960887,-66.46691087858679,30.137050861466918,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark72(8.08761592907465,-74.18715556905876,-6.860375638967859,-14.339861237365628,98.75747429186693,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark72(96.277495690443,51.00211501103209,62.960179906438526,-53.19883873438145,47.18940535996751,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark72(96.49610981036997,-74.50548758422478,12.92418819146312,98.24172374169834,74.33840119360548,90.03292788211624,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark72(98.27206941073712,73.25488210202909,0,0,0,0,0 ) ;
  }
}
