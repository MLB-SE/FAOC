import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(-27.032402123294204,-53.57806311965796,63.86028606406484 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(-53.10153852581952,-6.165892244081121,-91.32940822065324 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(59.80455815292024,65.02178256437114,5.352289491590888 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(-75.38825734987141,78.38750302548877,-59.912732956051244 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(90.75286632630903,70.6041089773116,-44.2713740998709 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(97.59410227079698,-63.740662448208155,25.436633623339418 ) ;
  }
}
