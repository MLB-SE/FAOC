import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,3.696850164300926 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,-54.48327048419481 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(0.29529545230924725,1.873048515752773,-20.76619938717479,24.368257345305324 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(18.82721603499852,-19.227736278962595,-31.954815473193943,79.78327176905503 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(192.24806272273563,-3.102720023532001,97.58628457012361,-42.41243293304351 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(26.810329344836006,0.0,14.54029457104771,92.18036224378105 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(26.81104285650038,-2.4308653429145085E-63,56.16135000224867,-100.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(33.32240394847017,44.1466607236336,-69.27189737484989,-74.11887027385299 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(37.22713068161022,-24.941542930317723,39.66794479399198,13.920468623635315 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(39.02875101174942,-52.59715101714691,29.369576012082515,-2.1390636544183224 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(45.65796956243756,-38.906072940326084,24.961955867867886,-64.05736002477147 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(48.27829811956151,53.84848619404782,41.84987257770388,60.276911735905465 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(49.081679798030024,11.203765060691723,78.4916940122004,-67.76665080042562 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(50.47458604999383,79.86217135465583,-70.83824704502075,71.21487886465158 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(56.074444750290496,-58.43868799809913,35.65544476739959,-0.9595431839967808 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(67.72865506828168,-62.381768178755,-33.74522891934639,100.0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(70.13708851046655,-32.13811232588944,-50.67453017534156,51.13936720321618 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(79.8384539468102,3.3141197426339772,58.842109704395625,57.193811980705846 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(82.9444608636677,12.617021974925365,-39.63958054619698,-69.87015908464713 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(88.02301267892685,-62.75268961118121,41.12396890186403,60.25967353929022 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(-92.47351151702344,83.56099663172392,-3.0150829772371566,-48.3214327464879 ) ;
  }
}
