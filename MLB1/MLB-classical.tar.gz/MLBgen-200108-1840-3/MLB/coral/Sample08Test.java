import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(-47.82890072767636,98.8531457073498,-44.521217649464326 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(-8.598720560879201,-35.097006610961614,54.26449320997054 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(93.10200764105255,-1.8734088344442625,82.57582552329018 ) ;
  }
}
