import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(-21.864808447557515,8.496118619187115 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(-32.139353087984546,-92.94714485119542 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(41.18765965040245,84.40915263393904 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(56.80612102232348,-41.68976080325939 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(-56.884835677638804,4.556247562881527 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(93.97463816725224,-50.91232089350686 ) ;
  }
}
