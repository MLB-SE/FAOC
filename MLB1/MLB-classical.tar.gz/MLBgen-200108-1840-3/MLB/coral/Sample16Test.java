import org.junit.Test;

public class Sample16Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,1.6357856579148518 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,-28.652068551810643 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark16(-30.619830097432455,15.413009086844525,-160.90713215778922,-63.304103862446894,-51.38929951347011 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark16(41.1804277956642,14.479526268389066,69.33583865943191,52.25310916042238,-91.47092559533971 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark16(98.99040649566129,15.18459364753673,68.03848119880661,-51.356320316876115,94.5807866491642 ) ;
  }
}
