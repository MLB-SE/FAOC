import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(0.6645593586181471,47.12161621534193,0.8570480194451449 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(0.766371008422567,-26.449751702999976,-0.7453308342464879 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(0.9866352279264987,71.09221687930456,-0.8751317065695684 ) ;
  }
}
