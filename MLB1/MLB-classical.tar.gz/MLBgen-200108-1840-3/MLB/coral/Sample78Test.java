import org.junit.Test;

public class Sample78Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,0.0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0.0,100.0,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-31.176311760529558,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,61.82731832839056,0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,90.0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-16.13942311433034,-68.57656758805062,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-22.592760376890823,18.03381561755431,0,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,23.413069839938874,-2.937E-320,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-34.24849516544369,90.0,0,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-44.62075545024491,59.66960567529398,0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark78(100.0,-100.0,-100.0,100.0,-3.0533333650396024,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark78(11.482564221465665,95.9635252509882,-84.03664263617533,-11.482562454634333,-90.98229999586388,0,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark78(-11.7583707112926,0,0,-49.26193537230337,-96.00129152672763,0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark78(12.25079224041545,0,0,30.859972059120253,-38.906018463754435,0,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark78(1.8325655057700203,0,0,-20.250376479349327,-37.0943310558008,0,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark78(24.422165259082675,0,0,-69.47346801760509,62.771929327357526,0,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark78(-26.202613552472634,0,0,31.520237991700782,6.47582E-319,0,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark78(27.79802508913636,0,0,-43.120553480000524,-57.81511939737767,0,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark78(-2.9308495994470366E-21,0,0,26.527445031022637,-90.0,0,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark78(31.0,579.0,219.0,31.0,1318.0,-745,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark78(-32.78453604226527,0,0,75.1099951065143,5.163024268617434,0,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark78(44.28536049267555,0,0,2.5379418373156492E-116,-90.00239282587064,0,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark78(49.02999777352246,0,0,26.14603308564292,-90.0,0,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark78(-517.0,415.0,235.0,517.0,517.0,0,0,-1 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark78(-5.397567102900619E-23,0,0,-24.158754881794685,-90.0,0,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark78(-66.46505345721258,0,0,-99.99999861303712,-90.0,0,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark78(-71.0,-98.0,82.0,71.0,94.0,0,0,-1139 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark78(-87.87025176814407,0,0,-100.0,3.050817811442471E-266,0,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark78(95.53329891376495,48.24756530887379,16.314706294179018,-92.4385188900152,77.03681613293557,0,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark78(-97.0,-1489.0,671.0,-97.0,-630.0,-1,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark78(99.9084773655261,0,0,62.79540984650046,85.04531413208983,0,0,0 ) ;
  }
}
