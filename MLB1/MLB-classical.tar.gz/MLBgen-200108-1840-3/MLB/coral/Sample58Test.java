import org.junit.Test;

public class Sample58Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark58(0,-11.093862463159951,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark58(0,-55.00798404551135,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark58(-0.9477943049041488,30.115041053901223,-26.093800866091886,-41.117087418919574,80.63919677579617 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark58(11.175032738167458,27.987462140662114,-39.805320900059144,50.0590865717215,54.66422887461912 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark58(17.39207508598006,38.07807429469036,-55.67341873046922,0.3075130949933688,94.01072270296359 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark58(22.43627814685183,2.7275897653830117,-25.567909526491913,-30.365801889229587,70.74257751487168 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark58(29.74825552694648,6.995605062671899,-36.60416620935241,-8.607811371678835,68.08229111578777 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark58(36.99946921202866,35.58472076117539,47.788705964715575,91.47343937851744,75.59939294675326 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark58(43.05984014238027,48.92188309990908,-23.053871687510835,93.59059625859837,17.081088519217985 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark58(5.128981459256494,41.30817153874054,-46.305699771436615,93.23235075097901,-37.079777875061694 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark58(6.15344654879182,1.5956137226346527,-8.634384884804106,96.06389384008094,85.46957335710933 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark58(-63.36171592173492,-14.954579161496056,-78.39678906345533,-95.76119051056217,-88.37945719330777 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark58(-75.36472853684089,78.52892653236131,88.4285489017675,-39.74212194694409,-65.394002643411 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark58(98.3903301771548,45.28356062678398,-11.317511338033668,41.26285673169698,9.926290099492022 ) ;
  }
}
