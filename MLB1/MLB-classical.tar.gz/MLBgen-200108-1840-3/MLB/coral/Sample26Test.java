import org.junit.Test;

public class Sample26Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark26(100.0,-66.2976980351696,100.0,11.697750342196981,-53.240630900737095 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark26(-22.132420335500044,27.507447677997646,50.56193865766926,38.755230672958305,-70.1925319175082 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark26(35.0805247044959,5.640245437651799,27.824586648027775,0,-42.32907442112135 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark26(5.01150404158075,21.41758863910079,-72.87322263547343,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark26(-55.605446084771934,-69.64404227878131,4.894905175365356,26.39559844769393,84.79335983813331 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark26(-57.61619948279764,55.86038363539882,-87.2226445207732,-32.75061035727116,24.359468475764444 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark26(-73.60984263057023,80.77871368405684,100.0,0,-32.75212857164014 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark26(-82.83731399422808,-55.066134010687094,-97.96908108343241,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark26(86.7195026908237,-36.09934195986148,-72.46303573001917,4.0105147709511755,22.082159927752755 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark26(-94.68195260107547,31.271570220284616,-50.93991497961794,0,0 ) ;
  }
}
