import org.junit.Test;

public class Sample02Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark02(25.786768865808625,60.88827462591922 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark02(40.54791080278952,68.61066173271254 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark02(86.766064927088,21.618881622034802 ) ;
  }
}
