import org.junit.Test;

public class Sample82Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark82(-0.16437759815285333,-6.083554031919292E-4 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark82(-1.2883787722519031,83.88922090477706 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark82(2.0081542753024166,4.979697089504768E-5 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark82(2.202389609878841E-6,45.40522691872909 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark82(51.17397542744567,1.9541182635259544E-6 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark82(-78.69909987110206,-72.04263767987449 ) ;
  }
}
