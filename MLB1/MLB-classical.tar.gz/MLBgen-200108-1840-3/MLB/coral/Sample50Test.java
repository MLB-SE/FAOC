import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(-0.0050754253559387235,0.020618318796325585 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(10.899512999256089,36.3213410084536 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(11.580124579202117,24.580124579202117 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(12.106197550326783,12.99966679694089 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(12.781659363923374,37.21834063607662 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(1.498409325813415,48.50159067418659 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(19.075657416345337,99.09436394308557 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(22.2028421663055,83.77513215101382 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(37.24167267894788,44.13118827218244 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(5.649977014021701E-13,7.514693771620683E-7 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(-82.08281581843369,24.43454023249805 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(8.225689382782718,15.832434542993127 ) ;
  }
}
