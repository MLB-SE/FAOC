import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(68.92116236324429,-29.517244376601525,96.94449505816112 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(-71.05388235356753,-92.40272473727448,58.72021185084654 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(9.018186822536764,81.4414158763243,96.11305765949749 ) ;
  }
}
