import org.junit.Test;

public class Sample28Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark28(1.5722233798437344 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark28(34.328040533627245 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark28(7.38905609893065 ) ;
  }
}
