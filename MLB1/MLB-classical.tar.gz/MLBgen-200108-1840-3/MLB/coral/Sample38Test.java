import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(-26.321681698943934,-37.77114452213737 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(84.04953444943678,-76.42984978476572 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(91.26994475269572,58.603757582440245 ) ;
  }
}
