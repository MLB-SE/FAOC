import org.junit.Test;

public class Testran1Test {

  @Test
  public void test0() {
    ran.ran1(0 ) ;
  }

  @Test
  public void test1() {
    ran.ran1(-1 ) ;
  }

  @Test
  public void test2() {
    ran.ran1(264 ) ;
  }

  @Test
  public void test3() {
    ran.ran1(-359 ) ;
  }

  @Test
  public void test4() {
    ran.ran1(585 ) ;
  }

  @Test
  public void test5() {
    ran.ran1(-609 ) ;
  }

  @Test
  public void test6() {
    ran.ran1(-631 ) ;
  }

  @Test
  public void test7() {
    ran.ran1(-649 ) ;
  }

  @Test
  public void test8() {
    ran.ran1(-758 ) ;
  }
}
