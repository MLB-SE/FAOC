import org.junit.Test;

public class TestexpdevTest {

  @Test
  public void test0() {
    dev.expdev(0 ) ;
  }

  @Test
  public void test1() {
    dev.expdev(-1 ) ;
  }

  @Test
  public void test2() {
    dev.expdev(-22 ) ;
  }

  @Test
  public void test3() {
    dev.expdev(282 ) ;
  }

  @Test
  public void test4() {
    dev.expdev(-629 ) ;
  }

  @Test
  public void test5() {
    dev.expdev(-631 ) ;
  }

  @Test
  public void test6() {
    dev.expdev(755 ) ;
  }

  @Test
  public void test7() {
    dev.expdev(-883 ) ;
  }

  @Test
  public void test8() {
    dev.expdev(-923 ) ;
  }
}
