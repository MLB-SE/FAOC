import org.junit.Test;

public class TestgamdevTest {

  @Test
  public void test0() {
    dev.gamdev(1,0 ) ;
  }

  @Test
  public void test1() {
    dev.gamdev(-201,0 ) ;
  }

  @Test
  public void test2() {
    dev.gamdev(2,-371 ) ;
  }

  @Test
  public void test3() {
    dev.gamdev(2,42 ) ;
  }

  @Test
  public void test4() {
    dev.gamdev(275,817 ) ;
  }

  @Test
  public void test5() {
    dev.gamdev(-305,0 ) ;
  }

  @Test
  public void test6() {
    dev.gamdev(4,0 ) ;
  }

  @Test
  public void test7() {
    dev.gamdev(464,0 ) ;
  }

  @Test
  public void test8() {
    dev.gamdev(5,0 ) ;
  }

  @Test
  public void test9() {
    dev.gamdev(541,-157 ) ;
  }

  @Test
  public void test10() {
    dev.gamdev(6,0 ) ;
  }

  @Test
  public void test11() {
    dev.gamdev(678,0 ) ;
  }

  @Test
  public void test12() {
    dev.gamdev(68,-1 ) ;
  }

  @Test
  public void test13() {
    dev.gamdev(699,-950 ) ;
  }

  @Test
  public void test14() {
    dev.gamdev(781,0 ) ;
  }

  @Test
  public void test15() {
    dev.gamdev(918,114 ) ;
  }

  @Test
  public void test16() {
    dev.gamdev(-969,0 ) ;
  }
}
