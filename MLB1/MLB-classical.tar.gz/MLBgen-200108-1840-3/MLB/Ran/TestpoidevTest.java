import org.junit.Test;

public class TestpoidevTest {

  @Test
  public void test0() {
    dev.poidev(0.0,904 ) ;
  }

  @Test
  public void test1() {
    dev.poidev(-1.0,0 ) ;
  }

  @Test
  public void test2() {
    dev.poidev(10.0,0 ) ;
  }

  @Test
  public void test3() {
    dev.poidev(-1.0000000000000009,0 ) ;
  }

  @Test
  public void test4() {
    dev.poidev(-1.0,-1 ) ;
  }

  @Test
  public void test5() {
    dev.poidev(1.0,-1 ) ;
  }

  @Test
  public void test6() {
    dev.poidev(-1.0,1600 ) ;
  }

  @Test
  public void test7() {
    dev.poidev(-1.0,218 ) ;
  }

  @Test
  public void test8() {
    dev.poidev(-1.0,-534 ) ;
  }

  @Test
  public void test9() {
    dev.poidev(1.0,-86 ) ;
  }

  @Test
  public void test10() {
    dev.poidev(-1.0,-910 ) ;
  }

  @Test
  public void test11() {
    dev.poidev(-183.0,-1 ) ;
  }

  @Test
  public void test12() {
    dev.poidev(-1.999999999999999,0 ) ;
  }

  @Test
  public void test13() {
    dev.poidev(2.0,205 ) ;
  }

  @Test
  public void test14() {
    dev.poidev(2.067287283614675,0 ) ;
  }

  @Test
  public void test15() {
    dev.poidev(26.861199306180097,0 ) ;
  }

  @Test
  public void test16() {
    dev.poidev(-35.50956772716913,0 ) ;
  }

  @Test
  public void test17() {
    dev.poidev(-418.0,0 ) ;
  }

  @Test
  public void test18() {
    dev.poidev(-465.0,-307 ) ;
  }

  @Test
  public void test19() {
    dev.poidev(-495.0,710 ) ;
  }

  @Test
  public void test20() {
    dev.poidev(5.0,-291 ) ;
  }

  @Test
  public void test21() {
    dev.poidev(-551.0,-749 ) ;
  }

  @Test
  public void test22() {
    dev.poidev(-579.0,740 ) ;
  }

  @Test
  public void test23() {
    dev.poidev(6.877305469254452,0 ) ;
  }

  @Test
  public void test24() {
    dev.poidev(71.37139462882106,0 ) ;
  }

  @Test
  public void test25() {
    dev.poidev(-78.05771118423002,0 ) ;
  }

  @Test
  public void test26() {
    dev.poidev(99.78675301841088,0 ) ;
  }
}
