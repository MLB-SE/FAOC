import org.junit.Test;

public class TestbnldevTest {

  @Test
  public void test0() {
    dev.bnldev(0.0,229,0 ) ;
  }

  @Test
  public void test1() {
    dev.bnldev(0.0,30,0 ) ;
  }

  @Test
  public void test2() {
    dev.bnldev(0.5814502715945054,0,0 ) ;
  }

  @Test
  public void test3() {
    dev.bnldev(1.0,307,0 ) ;
  }

  @Test
  public void test4() {
    dev.bnldev(1.0,48,0 ) ;
  }

  @Test
  public void test5() {
    dev.bnldev(1.0,-774,0 ) ;
  }

  @Test
  public void test6() {
    dev.bnldev(1.0,-852,0 ) ;
  }

  @Test
  public void test7() {
    dev.bnldev(-126.0,4,68 ) ;
  }

  @Test
  public void test8() {
    dev.bnldev(162.0,358,0 ) ;
  }

  @Test
  public void test9() {
    dev.bnldev(247.0,-866,0 ) ;
  }

  @Test
  public void test10() {
    dev.bnldev(311.0,7,0 ) ;
  }

  @Test
  public void test11() {
    dev.bnldev(-359.0,940,0 ) ;
  }

  @Test
  public void test12() {
    dev.bnldev(-397.0,12,-561 ) ;
  }

  @Test
  public void test13() {
    dev.bnldev(-440.0,80,0 ) ;
  }

  @Test
  public void test14() {
    dev.bnldev(-486.0,-419,0 ) ;
  }

  @Test
  public void test15() {
    dev.bnldev(-493.0,677,0 ) ;
  }

  @Test
  public void test16() {
    dev.bnldev(-518.0,18,0 ) ;
  }

  @Test
  public void test17() {
    dev.bnldev(535.0,298,0 ) ;
  }

  @Test
  public void test18() {
    dev.bnldev(557.0,19,-644 ) ;
  }

  @Test
  public void test19() {
    dev.bnldev(-623.0,-178,0 ) ;
  }

  @Test
  public void test20() {
    dev.bnldev(637.0,-1,0 ) ;
  }

  @Test
  public void test21() {
    dev.bnldev(-772.0,-877,0 ) ;
  }

  @Test
  public void test22() {
    dev.bnldev(819.0,-412,0 ) ;
  }

  @Test
  public void test23() {
    dev.bnldev(82.01991191016745,0,0 ) ;
  }

  @Test
  public void test24() {
    dev.bnldev(-83.0933277043134,0,0 ) ;
  }

  @Test
  public void test25() {
    dev.bnldev(831.0,15,500 ) ;
  }

  @Test
  public void test26() {
    dev.bnldev(-845.0,25,0 ) ;
  }

  @Test
  public void test27() {
    dev.bnldev(-87.0,-371,0 ) ;
  }

  @Test
  public void test28() {
    dev.bnldev(885.0,-719,0 ) ;
  }

  @Test
  public void test29() {
    dev.bnldev(895.0,164,0 ) ;
  }

  @Test
  public void test30() {
    dev.bnldev(-986.0,-453,0 ) ;
  }
}
