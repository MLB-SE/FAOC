import org.junit.Test;

public class Testran3Test {

  @Test
  public void test0() {
    ran.ran3(0 ) ;
  }

  @Test
  public void test1() {
    ran.ran3(138 ) ;
  }

  @Test
  public void test2() {
    ran.ran3(26299 ) ;
  }

  @Test
  public void test3() {
    ran.ran3(-26309 ) ;
  }

  @Test
  public void test4() {
    ran.ran3(26977 ) ;
  }

  @Test
  public void test5() {
    ran.ran3(-27490 ) ;
  }

  @Test
  public void test6() {
    ran.ran3(355 ) ;
  }

  @Test
  public void test7() {
    ran.ran3(-532 ) ;
  }

  @Test
  public void test8() {
    ran.ran3(543 ) ;
  }

  @Test
  public void test9() {
    ran.ran3(-554 ) ;
  }

  @Test
  public void test10() {
    ran.ran3(-615 ) ;
  }

  @Test
  public void test11() {
    ran.ran3(-763 ) ;
  }

  @Test
  public void test12() {
    ran.ran3(985 ) ;
  }
}
