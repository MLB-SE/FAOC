import org.junit.Test;

public class TestgasdevTest {

  @Test
  public void test0() {
    dev.gasdev(0 ) ;
  }

  @Test
  public void test1() {
    dev.gasdev(-1 ) ;
  }

  @Test
  public void test2() {
    dev.gasdev(1 ) ;
  }

  @Test
  public void test3() {
    dev.gasdev(-24 ) ;
  }

  @Test
  public void test4() {
    dev.gasdev(-366 ) ;
  }

  @Test
  public void test5() {
    dev.gasdev(-393 ) ;
  }

  @Test
  public void test6() {
    dev.gasdev(504 ) ;
  }

  @Test
  public void test7() {
    dev.gasdev(689 ) ;
  }

  @Test
  public void test8() {
    dev.gasdev(-775 ) ;
  }

  @Test
  public void test9() {
    dev.gasdev(898 ) ;
  }
}
