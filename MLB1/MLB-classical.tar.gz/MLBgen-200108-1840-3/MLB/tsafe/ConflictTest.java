import org.junit.Test;

public class ConflictTest {

  @Test
  public void test0() {
    tsafe.Conflict.snippet(0.17388004564107007,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    tsafe.Conflict.snippet(100.0,0,0,0,0,0,-1.1487E-320 ) ;
  }

  @Test
  public void test2() {
    tsafe.Conflict.snippet(100.0,-100.0,1.9875040604126942E-12,0,0,0,90.0 ) ;
  }

  @Test
  public void test3() {
    tsafe.Conflict.snippet(1.1102230246251565E-16,0,0,0,0,0,-56.40254110464274 ) ;
  }

  @Test
  public void test4() {
    tsafe.Conflict.snippet(1.295163E-318,0,0,0,0,0,-96.16650964397057 ) ;
  }

  @Test
  public void test5() {
    tsafe.Conflict.snippet(-1.61895E-319,0,0,0,0,0,-78.80262759666213 ) ;
  }

  @Test
  public void test6() {
    tsafe.Conflict.snippet(17.194849481514908,0,0,0,0,0,-60.347565902341024 ) ;
  }

  @Test
  public void test7() {
    tsafe.Conflict.snippet(-1.7763568394002505E-15,47.605540280854676,1.4922402843432155E-14,0,0,0,-90.0 ) ;
  }

  @Test
  public void test8() {
    tsafe.Conflict.snippet(-21.812771443534075,0.0,0,0,0,0,-75.34816001330698 ) ;
  }

  @Test
  public void test9() {
    tsafe.Conflict.snippet(-22.850337513552656,-61.95754219201722,71.74416490311141,60.80273734858607,-67.0488831576211,-13.220593100258485,0.0028749381439384936 ) ;
  }

  @Test
  public void test10() {
    tsafe.Conflict.snippet(-29.929485640990833,-1.3080163113385055,-14.966089230173424,-56.87001143020789,4.8397090612431555,59.33370056204495,-20.758784801936912 ) ;
  }

  @Test
  public void test11() {
    tsafe.Conflict.snippet(-31.191181911962843,-43.36115969533998,-81.22219402021844,0,0,0,99.11303378262932 ) ;
  }

  @Test
  public void test12() {
    tsafe.Conflict.snippet(-39.061765140851584,0,0,0,0,0,0.0 ) ;
  }

  @Test
  public void test13() {
    tsafe.Conflict.snippet(-41.23625161307189,0,0,0,0,0,4.18191054755863 ) ;
  }

  @Test
  public void test14() {
    tsafe.Conflict.snippet(41.29190845646577,-55.87958360325891,-99.31416467588963,0.7725800493911343,-5.090192109032737,12.385080090138981,0.5113193456077223 ) ;
  }

  @Test
  public void test15() {
    tsafe.Conflict.snippet(-4.232910139509727,11.074200196719431,-5.218030584650421,76.5827989556521,5.112045540101747,-63.68668180186625,-33.671995548417826 ) ;
  }

  @Test
  public void test16() {
    tsafe.Conflict.snippet(43.4587901741354,0,0,0,0,0,0.0 ) ;
  }

  @Test
  public void test17() {
    tsafe.Conflict.snippet(45.98408010568125,0.0,0,0,0,0,31.787168925379742 ) ;
  }

  @Test
  public void test18() {
    tsafe.Conflict.snippet(5.329070518200751E-15,0,0,0,0,0,-91.61775024779438 ) ;
  }

  @Test
  public void test19() {
    tsafe.Conflict.snippet(-53.71580935863251,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test20() {
    tsafe.Conflict.snippet(-57.13977695077417,-66.47751747549407,0,0,0,0,-81.97578534844514 ) ;
  }

  @Test
  public void test21() {
    tsafe.Conflict.snippet(58.02522482503676,69.84913886640321,39.29667053447882,9.170481752499185,63.13657930836443,-32.27420226050971,0.0022358216483260307 ) ;
  }

  @Test
  public void test22() {
    tsafe.Conflict.snippet(58.67929807859616,0,0,0,0,0,-3.1627485902508568 ) ;
  }

  @Test
  public void test23() {
    tsafe.Conflict.snippet(-5.99077019531768,0,0,0,0,0,80.600754899935 ) ;
  }

  @Test
  public void test24() {
    tsafe.Conflict.snippet(-62.80994763383449,0,0,0,0,0,-3.95E-322 ) ;
  }

  @Test
  public void test25() {
    tsafe.Conflict.snippet(-6.938386685140813,-9.017543932639072,107.08070045776478,-41.98882903690051,-1012.2734168935116,-100.0,-186.46116541942172 ) ;
  }

  @Test
  public void test26() {
    tsafe.Conflict.snippet(76.01087109018738,-19.62968504418386,-47.68342665675833,0,0,0,8.614149689153152 ) ;
  }

  @Test
  public void test27() {
    tsafe.Conflict.snippet(85.65455852112973,33.030083790082585,-4.831611568180477,-99.08207205404639,-52.106487161230966,-82.59727735649571,-90.59623606803623 ) ;
  }

  @Test
  public void test28() {
    tsafe.Conflict.snippet(-86.69828628822351,-99.97049642187999,100.0,0.5993520161447066,-0.11596336341870028,64.14283847993323,-46.50591865320089 ) ;
  }

  @Test
  public void test29() {
    tsafe.Conflict.snippet(87.85235168521938,99.99898181840074,99.99999077585987,-2.005209991300856,-0.3843127264194171,-65.54490604306909,96.53405854442728 ) ;
  }

  @Test
  public void test30() {
    tsafe.Conflict.snippet(87.91140001832639,38.28842053199406,0,0,0,0,58.84514888312435 ) ;
  }

  @Test
  public void test31() {
    tsafe.Conflict.snippet(-90.57263249527048,0,0,0,0,0,-59.846170605547286 ) ;
  }

  @Test
  public void test32() {
    tsafe.Conflict.snippet(93.95268000187536,-13.900909549851704,-35.85797234909636,62.72630046883435,-33.27582728118411,94.54649315404421,-36.270256912485664 ) ;
  }

  @Test
  public void test33() {
    tsafe.Conflict.snippet(94.3771066633962,29.252798206432146,-35.77357810839237,93.5461987113176,-1020.9904639429872,78.52691033104574,57.98734788549527 ) ;
  }

  @Test
  public void test34() {
    tsafe.Conflict.snippet(95.32132558480689,0,0,0,0,0,-39.44364652296672 ) ;
  }

  @Test
  public void test35() {
    tsafe.Conflict.snippet(98.5704498184364,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test36() {
    tsafe.Conflict.snippet(-99.49113653789313,-24.408705670776754,-100.0,1.5518850761564487,0.24671363442313607,-31.651345070840165,3.660583659084537 ) ;
  }
}
