import org.junit.Test;

public class JpfTargetunboundedTest {

  @Test
  public void test0() {
    bound.unbounded.solve(413,-812 ) ;
  }

  @Test
  public void test1() {
    bound.unbounded.solve(-459,390 ) ;
  }

  @Test
  public void test2() {
    bound.unbounded.solve(569,-443 ) ;
  }

  @Test
  public void test3() {
    bound.unbounded.solve(-698,683 ) ;
  }
}
