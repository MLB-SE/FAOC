import org.junit.Test;

public class JpfTargetgroceryTest {

  @Test
  public void test0() {
    bound.grocery.solve(108,-491,0,0 ) ;
  }

  @Test
  public void test1() {
    bound.grocery.solve(-194,0,0,0 ) ;
  }

  @Test
  public void test2() {
    bound.grocery.solve(26,9,176,500 ) ;
  }

  @Test
  public void test3() {
    bound.grocery.solve(276,239,159,335 ) ;
  }

  @Test
  public void test4() {
    bound.grocery.solve(293,370,899,0 ) ;
  }

  @Test
  public void test5() {
    bound.grocery.solve(305,201,189,16 ) ;
  }

  @Test
  public void test6() {
    bound.grocery.solve(369,171,37,671 ) ;
  }

  @Test
  public void test7() {
    bound.grocery.solve(386,428,439,-115 ) ;
  }

  @Test
  public void test8() {
    bound.grocery.solve(469,449,416,0 ) ;
  }

  @Test
  public void test9() {
    bound.grocery.solve(527,87,0,0 ) ;
  }

  @Test
  public void test10() {
    bound.grocery.solve(562,235,688,1151 ) ;
  }

  @Test
  public void test11() {
    bound.grocery.solve(592,403,630,0 ) ;
  }

  @Test
  public void test12() {
    bound.grocery.solve(621,986,0,0 ) ;
  }

  @Test
  public void test13() {
    bound.grocery.solve(642,312,-323,0 ) ;
  }

  @Test
  public void test14() {
    bound.grocery.solve(680,35,475,65 ) ;
  }

  @Test
  public void test15() {
    bound.grocery.solve(684,0,0,0 ) ;
  }

  @Test
  public void test16() {
    bound.grocery.solve(684,403,0,0 ) ;
  }

  @Test
  public void test17() {
    bound.grocery.solve(70,29,176,436 ) ;
  }

  @Test
  public void test18() {
    bound.grocery.solve(735,0,0,0 ) ;
  }

  @Test
  public void test19() {
    bound.grocery.solve(759,0,0,0 ) ;
  }

  @Test
  public void test20() {
    bound.grocery.solve(98,383,54,176 ) ;
  }
}
