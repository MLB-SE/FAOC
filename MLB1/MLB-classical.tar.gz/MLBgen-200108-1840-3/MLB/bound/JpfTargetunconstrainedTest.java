import org.junit.Test;

public class JpfTargetunconstrainedTest {

  @Test
  public void test0() {
    bound.unconstrained.solve(10,9,9,1 ) ;
  }

  @Test
  public void test1() {
    bound.unconstrained.solve(2,6,5,7 ) ;
  }

  @Test
  public void test2() {
    bound.unconstrained.solve(3,2,10,1140 ) ;
  }

  @Test
  public void test3() {
    bound.unconstrained.solve(3,7,-445,0 ) ;
  }

  @Test
  public void test4() {
    bound.unconstrained.solve(-393,0,0,0 ) ;
  }

  @Test
  public void test5() {
    bound.unconstrained.solve(460,0,0,0 ) ;
  }

  @Test
  public void test6() {
    bound.unconstrained.solve(4,7,5,-70 ) ;
  }

  @Test
  public void test7() {
    bound.unconstrained.solve(5,1,792,0 ) ;
  }

  @Test
  public void test8() {
    bound.unconstrained.solve(54,0,0,0 ) ;
  }

  @Test
  public void test9() {
    bound.unconstrained.solve(6,0,0,0 ) ;
  }

  @Test
  public void test10() {
    bound.unconstrained.solve(7,7,0,0 ) ;
  }

  @Test
  public void test11() {
    bound.unconstrained.solve(8,3,8,0 ) ;
  }

  @Test
  public void test12() {
    bound.unconstrained.solve(8,411,0,0 ) ;
  }

  @Test
  public void test13() {
    bound.unconstrained.solve(8,8,519,0 ) ;
  }

  @Test
  public void test14() {
    bound.unconstrained.solve(9,4,5,281 ) ;
  }

  @Test
  public void test15() {
    bound.unconstrained.solve(9,655,0,0 ) ;
  }

  @Test
  public void test16() {
    bound.unconstrained.solve(9,-702,0,0 ) ;
  }

  @Test
  public void test17() {
    bound.unconstrained.solve(9,8,6,6 ) ;
  }
}
