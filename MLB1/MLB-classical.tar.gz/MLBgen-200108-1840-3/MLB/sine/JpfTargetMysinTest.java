import org.junit.Test;

public class JpfTargetMysinTest {

  @Test
  public void test0() {
    JpfTargetMysin.static_mysin(0.2607883239444675 ) ;
  }

  @Test
  public void test1() {
    JpfTargetMysin.static_mysin(0.2636115665382911 ) ;
  }

  @Test
  public void test2() {
    JpfTargetMysin.static_mysin(-0.4374468830433198 ) ;
  }

  @Test
  public void test3() {
    JpfTargetMysin.static_mysin(-0.7966878775819768 ) ;
  }

  @Test
  public void test4() {
    JpfTargetMysin.static_mysin(0.8126858438047648 ) ;
  }

  @Test
  public void test5() {
    JpfTargetMysin.static_mysin(10.683849889943843 ) ;
  }

  @Test
  public void test6() {
    JpfTargetMysin.static_mysin(1.1103728259677422E-35 ) ;
  }

  @Test
  public void test7() {
    JpfTargetMysin.static_mysin(12.583544281948548 ) ;
  }

  @Test
  public void test8() {
    JpfTargetMysin.static_mysin(1.658098411894595E-4 ) ;
  }

  @Test
  public void test9() {
    JpfTargetMysin.static_mysin(17.309526340947514 ) ;
  }

  @Test
  public void test10() {
    JpfTargetMysin.static_mysin(19.634954084936208 ) ;
  }

  @Test
  public void test11() {
    JpfTargetMysin.static_mysin(-21.27036887783649 ) ;
  }

  @Test
  public void test12() {
    JpfTargetMysin.static_mysin(22.776546738526 ) ;
  }

  @Test
  public void test13() {
    JpfTargetMysin.static_mysin(23.514293095372537 ) ;
  }

  @Test
  public void test14() {
    JpfTargetMysin.static_mysin(-2.441406250000198E-4 ) ;
  }

  @Test
  public void test15() {
    JpfTargetMysin.static_mysin(2.44140625000054E-4 ) ;
  }

  @Test
  public void test16() {
    JpfTargetMysin.static_mysin(2.441406250000932E-4 ) ;
  }

  @Test
  public void test17() {
    JpfTargetMysin.static_mysin(258.25382507446056 ) ;
  }

  @Test
  public void test18() {
    JpfTargetMysin.static_mysin(-259.21428011805216 ) ;
  }

  @Test
  public void test19() {
    JpfTargetMysin.static_mysin(-259.5528321151123 ) ;
  }

  @Test
  public void test20() {
    JpfTargetMysin.static_mysin(2.617848857730537E-17 ) ;
  }

  @Test
  public void test21() {
    JpfTargetMysin.static_mysin(-2.62130507486698E-4 ) ;
  }

  @Test
  public void test22() {
    JpfTargetMysin.static_mysin(-3.9269908169872414 ) ;
  }

  @Test
  public void test23() {
    JpfTargetMysin.static_mysin(47.71545974846234 ) ;
  }

  @Test
  public void test24() {
    JpfTargetMysin.static_mysin(-53.50306107161524 ) ;
  }

  @Test
  public void test25() {
    JpfTargetMysin.static_mysin(-53.9183621656941 ) ;
  }

  @Test
  public void test26() {
    JpfTargetMysin.static_mysin(-60.325064447260736 ) ;
  }

  @Test
  public void test27() {
    JpfTargetMysin.static_mysin(66.7896585979154 ) ;
  }

  @Test
  public void test28() {
    JpfTargetMysin.static_mysin(-70.91725042172175 ) ;
  }

  @Test
  public void test29() {
    JpfTargetMysin.static_mysin(-96.60397409788614 ) ;
  }
}
