import org.junit.Test;

public class JpfTargetunboundedTest {

  @Test
  public void test0() {
    bound.unbounded.solve(-442,609 ) ;
  }

  @Test
  public void test1() {
    bound.unbounded.solve(585,190 ) ;
  }

  @Test
  public void test2() {
    bound.unbounded.solve(-723,-520 ) ;
  }

  @Test
  public void test3() {
    bound.unbounded.solve(-918,-840 ) ;
  }
}
