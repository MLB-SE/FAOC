import org.junit.Test;

public class JpfTargetPowTestTest {

  @Test
  public void test0() {
    concolic.PowExample.test(-14,0 ) ;
  }

  @Test
  public void test1() {
    concolic.PowExample.test(2,4 ) ;
  }

  @Test
  public void test2() {
    concolic.PowExample.test(30,900 ) ;
  }

  @Test
  public void test3() {
    concolic.PowExample.test(315,683 ) ;
  }

  @Test
  public void test4() {
    concolic.PowExample.test(422,-140 ) ;
  }

  @Test
  public void test5() {
    concolic.PowExample.test(541,-121 ) ;
  }

  @Test
  public void test6() {
    concolic.PowExample.test(858,0 ) ;
  }
}
