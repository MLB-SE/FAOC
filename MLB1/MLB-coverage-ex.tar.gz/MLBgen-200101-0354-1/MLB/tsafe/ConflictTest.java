import org.junit.Test;

public class ConflictTest {

  @Test
  public void test0() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,0.0 ) ;
  }

  @Test
  public void test2() {
    tsafe.Conflict.snippet(0.0,0.0,0,0,0,0,-65.39221657322271 ) ;
  }

  @Test
  public void test3() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,-100.0 ) ;
  }

  @Test
  public void test4() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,-1.73E-322 ) ;
  }

  @Test
  public void test5() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,79.23674686930832 ) ;
  }

  @Test
  public void test6() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,-88.21504425952097 ) ;
  }

  @Test
  public void test7() {
    tsafe.Conflict.snippet(-0.004823609037480359,-614.0847309519465,17.50663332090329,-143.12061757500769,-988.4516790132641,-39.10423592163062,-4.40132269765229 ) ;
  }

  @Test
  public void test8() {
    tsafe.Conflict.snippet(0.0,-3.4234056851942896,-84.1484493411144,0,0,0,-23.413493467210145 ) ;
  }

  @Test
  public void test9() {
    tsafe.Conflict.snippet(0.0,37.96585272496684,21.43791333234033,-6.231075517370532,16.487239970801625,31.07494107562318,34.74267141511582 ) ;
  }

  @Test
  public void test10() {
    tsafe.Conflict.snippet(0.0,-42.372848639081276,-26.23485725218363,-1.6212429204080514,-1.171141064529279,39.1981115504594,23.249478607668546 ) ;
  }

  @Test
  public void test11() {
    tsafe.Conflict.snippet(0.0,-63.9163401243396,0,0,0,0,20.393865137349508 ) ;
  }

  @Test
  public void test12() {
    tsafe.Conflict.snippet(0.07925552558358806,-146.32834740948087,-37.876040611335796,1020.3994283993063,-99.13915623239299,94.87495018439714,-25.653441027912805 ) ;
  }

  @Test
  public void test13() {
    tsafe.Conflict.snippet(0.0,-86.36782371422147,-96.68509326982618,-1.8361875814157642,-0.20996344414755796,48.957367853998036,-100.0 ) ;
  }

  @Test
  public void test14() {
    tsafe.Conflict.snippet(0.0,97.32077722278797,58.21858628686229,44.458537458163946,-55.30580499215196,-99.49253683960148,-51.339119427269345 ) ;
  }

  @Test
  public void test15() {
    tsafe.Conflict.snippet(-100.0,0,0,0,0,0,-2.67E-322 ) ;
  }

  @Test
  public void test16() {
    tsafe.Conflict.snippet(100.0,100.0,2.4697907569789987E-14,0,0,0,90.0 ) ;
  }

  @Test
  public void test17() {
    tsafe.Conflict.snippet(-100.0,-69.30870019442486,3.442013104567805E-9,0,0,0,90.0 ) ;
  }

  @Test
  public void test18() {
    tsafe.Conflict.snippet(100.0,-93.1733434278828,100.0,1.1162297757012114,-1.1451412243140844,80.15894892594015,-100.0 ) ;
  }

  @Test
  public void test19() {
    tsafe.Conflict.snippet(-11.921789440076338,-47.152626974345814,-46.838197831213236,-38.20134126932702,24.442671536295464,-34.247656275022024,14.122586781195153 ) ;
  }

  @Test
  public void test20() {
    tsafe.Conflict.snippet(-14.911232746906308,73.78421181781559,0,0,0,0,-87.47408226873057 ) ;
  }

  @Test
  public void test21() {
    tsafe.Conflict.snippet(15.231217292671353,2.712564457748526,-80.82576598492625,0.8929719420165119,-1.7847807430351048,-100.0,6.5315523082391564 ) ;
  }

  @Test
  public void test22() {
    tsafe.Conflict.snippet(-1.58E-322,0,0,0,0,0,89.65009105910899 ) ;
  }

  @Test
  public void test23() {
    tsafe.Conflict.snippet(159.586049235502,99.50286542970092,-34.755985639333716,1072.0929585526333,87.08191600982099,13.208979388663892,100.0 ) ;
  }

  @Test
  public void test24() {
    tsafe.Conflict.snippet(-170.47089231609039,122.24959492298615,-76.05370830033957,1039.8017930994038,100.0,-174.83324380382598,-31.162227496062386 ) ;
  }

  @Test
  public void test25() {
    tsafe.Conflict.snippet(-1.7763568394002505E-15,0,0,0,0,0,100.0 ) ;
  }

  @Test
  public void test26() {
    tsafe.Conflict.snippet(1.7E-322,0,0,0,0,0,78.8529087141478 ) ;
  }

  @Test
  public void test27() {
    tsafe.Conflict.snippet(18.926824453773918,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test28() {
    tsafe.Conflict.snippet(-214.61714469163817,83.11096163655462,-120.27101085338668,968.58938243989,249.9290616210451,80.01341776682912,-15.409578415703123 ) ;
  }

  @Test
  public void test29() {
    tsafe.Conflict.snippet(-26.967611558300526,-49.439762989361476,8.751429009317734,-0.1104277286431048,-1.8494421496180244,-15.622487147992297,9.943505590309233 ) ;
  }

  @Test
  public void test30() {
    tsafe.Conflict.snippet(317.159329902687,-56.64555392675958,-100.18188122872698,-167.00524040087902,-984.8570843101924,106.48352019027843,-64.07639259198868 ) ;
  }

  @Test
  public void test31() {
    tsafe.Conflict.snippet(3.6455610097781987E-304,0,0,0,0,0,45.058554368335194 ) ;
  }

  @Test
  public void test32() {
    tsafe.Conflict.snippet(39.63261071290813,72.77236765675289,57.48816015549903,-45.961670631659835,61.27846402463388,68.68848633612734,-46.11377440870814 ) ;
  }

  @Test
  public void test33() {
    tsafe.Conflict.snippet(-40.68512128223211,-80.55561048103576,56.04065499758048,-1.9310919912832676,0.5160594692374402,53.236314698617775,-59.58032934289711 ) ;
  }

  @Test
  public void test34() {
    tsafe.Conflict.snippet(47.146260919342836,0.0,0,0,0,0,23.071568416894923 ) ;
  }

  @Test
  public void test35() {
    tsafe.Conflict.snippet(56.72280738963454,0,0,0,0,0,-29.381964063084638 ) ;
  }

  @Test
  public void test36() {
    tsafe.Conflict.snippet(-64.72217064808876,0.0,0,0,0,0,-2.5009087776213446 ) ;
  }

  @Test
  public void test37() {
    tsafe.Conflict.snippet(-65.17683541609192,11.924100010757101,30.25035904326913,0,0,0,-30.012407267394366 ) ;
  }

  @Test
  public void test38() {
    tsafe.Conflict.snippet(74.05865069689295,0,0,0,0,0,-89.137258612145 ) ;
  }

  @Test
  public void test39() {
    tsafe.Conflict.snippet(7.533501847524633,-80.76554068779211,0,0,0,0,57.06917128902026 ) ;
  }

  @Test
  public void test40() {
    tsafe.Conflict.snippet(-77.4220384522796,58.17686997781436,-45.54288647752467,-97.96998672492015,-4.658127730560267,-71.8296490021078,77.72036033220994 ) ;
  }

  @Test
  public void test41() {
    tsafe.Conflict.snippet(-77.55595393769276,0,0,0,0,0,0.0 ) ;
  }

  @Test
  public void test42() {
    tsafe.Conflict.snippet(79.68574996536705,0,0,0,0,0,1.487E-321 ) ;
  }

  @Test
  public void test43() {
    tsafe.Conflict.snippet(-8.0948E-320,0,0,0,0,0,23.10324305966426 ) ;
  }

  @Test
  public void test44() {
    tsafe.Conflict.snippet(81.16777271497676,-17.229379490690633,81.16480428811025,0,0,0,46.253215357157615 ) ;
  }

  @Test
  public void test45() {
    tsafe.Conflict.snippet(-82.17536556236604,0,0,0,0,0,-42.978218161174176 ) ;
  }

  @Test
  public void test46() {
    tsafe.Conflict.snippet(8.552847072303498E-50,-65.3188743194251,-2.1121214838077565E-10,0,0,0,-90.0 ) ;
  }

  @Test
  public void test47() {
    tsafe.Conflict.snippet(-87.24529276031005,0,0,0,0,0,-98.87547067438958 ) ;
  }

  @Test
  public void test48() {
    tsafe.Conflict.snippet(87.35526993075919,0,0,0,0,0,28.635437453137826 ) ;
  }

  @Test
  public void test49() {
    tsafe.Conflict.snippet(-88.55045339655061,0,0,0,0,0,97.53463005024369 ) ;
  }

  @Test
  public void test50() {
    tsafe.Conflict.snippet(8.881784197001252E-16,0,0,0,0,0,-56.17028987583592 ) ;
  }

  @Test
  public void test51() {
    tsafe.Conflict.snippet(-94.15280670862877,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test52() {
    tsafe.Conflict.snippet(95.04893205391559,-89.5266814800729,-43.14760174833621,36.50317481047938,-3.5806954787477707,73.36793566354686,42.35929559375501 ) ;
  }

  @Test
  public void test53() {
    tsafe.Conflict.snippet(9.768474976674987,0,0,0,0,0,0.0 ) ;
  }
}
