import org.junit.Test;

public class JpfTargetPowTestTest {

  @Test
  public void test0() {
    concolic.PowExample.test(23,47 ) ;
  }

  @Test
  public void test1() {
    concolic.PowExample.test(2,4 ) ;
  }

  @Test
  public void test2() {
    concolic.PowExample.test(35,937 ) ;
  }

  @Test
  public void test3() {
    concolic.PowExample.test(41,1681 ) ;
  }

  @Test
  public void test4() {
    concolic.PowExample.test(4,16 ) ;
  }

  @Test
  public void test5() {
    concolic.PowExample.test(558,0 ) ;
  }

  @Test
  public void test6() {
    concolic.PowExample.test(-566,0 ) ;
  }

  @Test
  public void test7() {
    concolic.PowExample.test(733,-403 ) ;
  }
}
