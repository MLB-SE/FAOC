import org.junit.Test;

public class TestbessyTest {

  @Test
  public void test0() {
    bess.bessy(-225,4.5988173451461165 ) ;
  }

  @Test
  public void test1() {
    bess.bessy(245,7.944897499383828 ) ;
  }

  @Test
  public void test2() {
    bess.bessy(26,0 ) ;
  }

  @Test
  public void test3() {
    bess.bessy(-271,68.01779985284085 ) ;
  }

  @Test
  public void test4() {
    bess.bessy(-298,17.14838135960379 ) ;
  }

  @Test
  public void test5() {
    bess.bessy(-369,0.0 ) ;
  }

  @Test
  public void test6() {
    bess.bessy(715,8.0 ) ;
  }

  @Test
  public void test7() {
    bess.bessy(-717,8.0 ) ;
  }

  @Test
  public void test8() {
    bess.bessy(-809,0 ) ;
  }

  @Test
  public void test9() {
    bess.bessy(853,74.4445237229128 ) ;
  }

  @Test
  public void test10() {
    bess.bessy(961,-37.31169169251347 ) ;
  }

  @Test
  public void test11() {
    bess.bessy(990,0.0 ) ;
  }
}
