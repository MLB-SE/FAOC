import org.junit.Test;

public class TestbessjTest {

  @Test
  public void test0() {
    bess.bessj(0,-4.0474E-320 ) ;
  }

  @Test
  public void test1() {
    bess.bessj(1055,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test2() {
    bess.bessj(109,69.41053844023654 ) ;
  }

  @Test
  public void test3() {
    bess.bessj(1,0.9999999999999982 ) ;
  }

  @Test
  public void test4() {
    bess.bessj(1,1.0 ) ;
  }

  @Test
  public void test5() {
    bess.bessj(-123,-6.225339369765521 ) ;
  }

  @Test
  public void test6() {
    bess.bessj(128,18.14774250135372 ) ;
  }

  @Test
  public void test7() {
    bess.bessj(-1343,-3.128254836223595E-148 ) ;
  }

  @Test
  public void test8() {
    bess.bessj(-1413,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test9() {
    bess.bessj(-147,89.20215149148493 ) ;
  }

  @Test
  public void test10() {
    bess.bessj(-1535,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test11() {
    bess.bessj(189,0.0 ) ;
  }

  @Test
  public void test12() {
    bess.bessj(20,20.0 ) ;
  }

  @Test
  public void test13() {
    bess.bessj(2,-1.3189807341389317 ) ;
  }

  @Test
  public void test14() {
    bess.bessj(-243,-58.51774720326628 ) ;
  }

  @Test
  public void test15() {
    bess.bessj(26,-56.02324550313782 ) ;
  }

  @Test
  public void test16() {
    bess.bessj(283,-3.1587301655876523E-176 ) ;
  }

  @Test
  public void test17() {
    bess.bessj(-289,35.67085655750546 ) ;
  }

  @Test
  public void test18() {
    bess.bessj(-323,0 ) ;
  }

  @Test
  public void test19() {
    bess.bessj(3,38.77598758635017 ) ;
  }

  @Test
  public void test20() {
    bess.bessj(401,58.647543858355874 ) ;
  }

  @Test
  public void test21() {
    bess.bessj(-401,-85.79163326243813 ) ;
  }

  @Test
  public void test22() {
    bess.bessj(435,5.0539682649402436E-175 ) ;
  }

  @Test
  public void test23() {
    bess.bessj(463,-23.28421472505933 ) ;
  }

  @Test
  public void test24() {
    bess.bessj(482,-86.04669013812862 ) ;
  }

  @Test
  public void test25() {
    bess.bessj(494,0.0 ) ;
  }

  @Test
  public void test26() {
    bess.bessj(-546,-8.0 ) ;
  }

  @Test
  public void test27() {
    bess.bessj(576,1.1380524797363597E-159 ) ;
  }

  @Test
  public void test28() {
    bess.bessj(599,-79.00083625056331 ) ;
  }

  @Test
  public void test29() {
    bess.bessj(-617,6.938893903907228E-18 ) ;
  }

  @Test
  public void test30() {
    bess.bessj(662,0 ) ;
  }

  @Test
  public void test31() {
    bess.bessj(-669,1.0853314206470105E-165 ) ;
  }

  @Test
  public void test32() {
    bess.bessj(-699,-49.48909741287481 ) ;
  }

  @Test
  public void test33() {
    bess.bessj(707,0.0 ) ;
  }

  @Test
  public void test34() {
    bess.bessj(-768,-2.454548299991316 ) ;
  }

  @Test
  public void test35() {
    bess.bessj(-779,-16.672467168503147 ) ;
  }

  @Test
  public void test36() {
    bess.bessj(-853,0.0 ) ;
  }

  @Test
  public void test37() {
    bess.bessj(-858,0.0 ) ;
  }

  @Test
  public void test38() {
    bess.bessj(-876,-51.31816953689396 ) ;
  }

  @Test
  public void test39() {
    bess.bessj(88,-88.0 ) ;
  }

  @Test
  public void test40() {
    bess.bessj(-89,-5.9E-323 ) ;
  }

  @Test
  public void test41() {
    bess.bessj(-901,0.0 ) ;
  }

  @Test
  public void test42() {
    bess.bessj(929,4.440892098500626E-16 ) ;
  }

  @Test
  public void test43() {
    bess.bessj(-941,-6.9E-323 ) ;
  }

  @Test
  public void test44() {
    bess.bessj(-977,58.328226423814954 ) ;
  }

  @Test
  public void test45() {
    bess.bessj(-990,-1.4225655996704496E-160 ) ;
  }
}
