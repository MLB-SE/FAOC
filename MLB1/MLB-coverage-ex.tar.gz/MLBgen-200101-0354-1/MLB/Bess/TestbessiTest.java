import org.junit.Test;

public class TestbessiTest {

  @Test
  public void test0() {
    bess.bessi(0,-70.51403515842303 ) ;
  }

  @Test
  public void test1() {
    bess.bessi(0,9.020567693056392 ) ;
  }

  @Test
  public void test2() {
    bess.bessi(-10,0 ) ;
  }

  @Test
  public void test3() {
    bess.bessi(-1250,-1.265E-321 ) ;
  }

  @Test
  public void test4() {
    bess.bessi(1,41.740561523457814 ) ;
  }

  @Test
  public void test5() {
    bess.bessi(1,-45.88949069607642 ) ;
  }

  @Test
  public void test6() {
    bess.bessi(230,-1.0118E-320 ) ;
  }

  @Test
  public void test7() {
    bess.bessi(246,95.50573100523798 ) ;
  }

  @Test
  public void test8() {
    bess.bessi(-2595,-5.554338629342425E-31 ) ;
  }

  @Test
  public void test9() {
    bess.bessi(259,-57.31257364222462 ) ;
  }

  @Test
  public void test10() {
    bess.bessi(30,-55.7750803449033 ) ;
  }

  @Test
  public void test11() {
    bess.bessi(-364,0.0 ) ;
  }

  @Test
  public void test12() {
    bess.bessi(444,7.696285508483255E-9 ) ;
  }

  @Test
  public void test13() {
    bess.bessi(448,-51.50579900999617 ) ;
  }

  @Test
  public void test14() {
    bess.bessi(-451,-60.68369837309797 ) ;
  }

  @Test
  public void test15() {
    bess.bessi(-453,1.58E-322 ) ;
  }

  @Test
  public void test16() {
    bess.bessi(48,71.53430507380779 ) ;
  }

  @Test
  public void test17() {
    bess.bessi(-564,48.11102819658447 ) ;
  }

  @Test
  public void test18() {
    bess.bessi(-569,-36.4881928394744 ) ;
  }

  @Test
  public void test19() {
    bess.bessi(-573,3.5E-323 ) ;
  }

  @Test
  public void test20() {
    bess.bessi(61,2.17E-322 ) ;
  }

  @Test
  public void test21() {
    bess.bessi(619,0.0 ) ;
  }

  @Test
  public void test22() {
    bess.bessi(623,0 ) ;
  }

  @Test
  public void test23() {
    bess.bessi(-667,-56.00280868064276 ) ;
  }

  @Test
  public void test24() {
    bess.bessi(-679,-95.10608943241546 ) ;
  }

  @Test
  public void test25() {
    bess.bessi(-73,0.0 ) ;
  }

  @Test
  public void test26() {
    bess.bessi(737,-6.4E-323 ) ;
  }

  @Test
  public void test27() {
    bess.bessi(777,71.35883282391191 ) ;
  }

  @Test
  public void test28() {
    bess.bessi(779,-9.542685058663172E-32 ) ;
  }

  @Test
  public void test29() {
    bess.bessi(872,8.409159216309632 ) ;
  }

  @Test
  public void test30() {
    bess.bessi(939,0.0 ) ;
  }

  @Test
  public void test31() {
    bess.bessi(-949,87.05783626874552 ) ;
  }

  @Test
  public void test32() {
    bess.bessi(-953,1.0050151473416454E-8 ) ;
  }

  @Test
  public void test33() {
    bess.bessi(-961,91.87109148928627 ) ;
  }
}
