import org.junit.Test;

public class TestpythagTest {

  @Test
  public void test0() {
    dawson.pythag(0.0060033625393390855,0.006268879328473277 ) ;
  }

  @Test
  public void test1() {
    dawson.pythag(0.007514809632488979,-0.007516047683442415 ) ;
  }

  @Test
  public void test2() {
    dawson.pythag(0.16245450273524012,-0.1627613969665242 ) ;
  }

  @Test
  public void test3() {
    dawson.pythag(0.16534120391955973,0.16534192033454645 ) ;
  }

  @Test
  public void test4() {
    dawson.pythag(-0.18635926895824245,0.18635935038740425 ) ;
  }

  @Test
  public void test5() {
    dawson.pythag(-0.21370886085150154,-0.20645185458303889 ) ;
  }

  @Test
  public void test6() {
    dawson.pythag(-0.3006712746630034,0.3006712746630374 ) ;
  }

  @Test
  public void test7() {
    dawson.pythag(-1.0261341990432241E-289,0.0 ) ;
  }

  @Test
  public void test8() {
    dawson.pythag(1.0837898653493181E-16,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test9() {
    dawson.pythag(-1.0947644252537633E-47,1.0990408487899108E-47 ) ;
  }

  @Test
  public void test10() {
    dawson.pythag(-1.106878289941554E-16,-1.106878289941554E-16 ) ;
  }

  @Test
  public void test11() {
    dawson.pythag(1.1113793747425387E-162,-1.1113793747425387E-162 ) ;
  }

  @Test
  public void test12() {
    dawson.pythag(1.2513019344894381E-147,1.2513019344894381E-147 ) ;
  }

  @Test
  public void test13() {
    dawson.pythag(-1.2776509408607265E-15,-1.41651304614491E-15 ) ;
  }

  @Test
  public void test14() {
    dawson.pythag(-14.266644605657362,14.718724690990229 ) ;
  }

  @Test
  public void test15() {
    dawson.pythag(1.5170536538024635,8.729102017692341 ) ;
  }

  @Test
  public void test16() {
    dawson.pythag(1.63E-322,0.0 ) ;
  }

  @Test
  public void test17() {
    dawson.pythag(1.734723475976807E-18,3.469446951953614E-18 ) ;
  }

  @Test
  public void test18() {
    dawson.pythag(1.778206999588062E-161,-1.778206999588062E-161 ) ;
  }

  @Test
  public void test19() {
    dawson.pythag(-1.82877982605164E-99,-1.82877982605164E-99 ) ;
  }

  @Test
  public void test20() {
    dawson.pythag(18.640525676263024,-95.79178594740935 ) ;
  }

  @Test
  public void test21() {
    dawson.pythag(-1.8991135491519597E-65,-4.244314991204324E-51 ) ;
  }

  @Test
  public void test22() {
    dawson.pythag(-1.9279358920823073E-180,1.9279358920823073E-180 ) ;
  }

  @Test
  public void test23() {
    dawson.pythag(20.428955396429544,0.0 ) ;
  }

  @Test
  public void test24() {
    dawson.pythag(-2.0816681711721685E-17,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test25() {
    dawson.pythag(-21.036286667619166,-65.89890528074018 ) ;
  }

  @Test
  public void test26() {
    dawson.pythag(-21.665659628841198,22.382266796739827 ) ;
  }

  @Test
  public void test27() {
    dawson.pythag(2.3034881435954894E-15,-2.303486230568979E-15 ) ;
  }

  @Test
  public void test28() {
    dawson.pythag(2.511332386524472E-13,2.5012030896789115E-13 ) ;
  }

  @Test
  public void test29() {
    dawson.pythag(-2.630577380284462,0.0 ) ;
  }

  @Test
  public void test30() {
    dawson.pythag(29.371005716120237,38.800702081442864 ) ;
  }

  @Test
  public void test31() {
    dawson.pythag(31.032509493168703,89.41292119984573 ) ;
  }

  @Test
  public void test32() {
    dawson.pythag(32.198387873975605,-32.198387873975605 ) ;
  }

  @Test
  public void test33() {
    dawson.pythag(33.564476774225824,-75.41582238212334 ) ;
  }

  @Test
  public void test34() {
    dawson.pythag(-34.11887894528836,-34.11887894528836 ) ;
  }

  @Test
  public void test35() {
    dawson.pythag(34.18605671495959,34.18605671495959 ) ;
  }

  @Test
  public void test36() {
    dawson.pythag(-34.33153856140248,-34.33153856140248 ) ;
  }

  @Test
  public void test37() {
    dawson.pythag(-35.07452969985452,18.73462264402977 ) ;
  }

  @Test
  public void test38() {
    dawson.pythag(-37.88209527281222,37.88209527281222 ) ;
  }

  @Test
  public void test39() {
    dawson.pythag(-3.796564645020311,0 ) ;
  }

  @Test
  public void test40() {
    dawson.pythag(3.938265714331224E-18,7.703719777548943E-34 ) ;
  }

  @Test
  public void test41() {
    dawson.pythag(41.01468230552982,59.16194279899216 ) ;
  }

  @Test
  public void test42() {
    dawson.pythag(-41.81670919332714,0.0 ) ;
  }

  @Test
  public void test43() {
    dawson.pythag(-4.2168791772922093E-81,4.2827679144374E-81 ) ;
  }

  @Test
  public void test44() {
    dawson.pythag(4.3007674577197434,-4.3007674577197434 ) ;
  }

  @Test
  public void test45() {
    dawson.pythag(4.383618698016806E-193,4.866794409715609E-209 ) ;
  }

  @Test
  public void test46() {
    dawson.pythag(-4.455518803543154E-19,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test47() {
    dawson.pythag(-46.70451628168444,58.34511105300891 ) ;
  }

  @Test
  public void test48() {
    dawson.pythag(4.871278175617746,-38.686621086086625 ) ;
  }

  @Test
  public void test49() {
    dawson.pythag(49.04321864629073,-49.04321864629073 ) ;
  }

  @Test
  public void test50() {
    dawson.pythag(-49.92881031994419,49.92881031994419 ) ;
  }

  @Test
  public void test51() {
    dawson.pythag(-5.556896873712694E-163,-5.556896873712694E-163 ) ;
  }

  @Test
  public void test52() {
    dawson.pythag(-59.2544711222861,-57.001822065705674 ) ;
  }

  @Test
  public void test53() {
    dawson.pythag(-60.572208324658746,-62.11327913042452 ) ;
  }

  @Test
  public void test54() {
    dawson.pythag(6.0834930121445114E-210,6.941510209864403E-276 ) ;
  }

  @Test
  public void test55() {
    dawson.pythag(-61.21861645014599,-8.177006277046843 ) ;
  }

  @Test
  public void test56() {
    dawson.pythag(-6.162975822039155E-33,-3.947299676346921E-17 ) ;
  }

  @Test
  public void test57() {
    dawson.pythag(62.481166230755434,62.481166230755434 ) ;
  }

  @Test
  public void test58() {
    dawson.pythag(66.42698254096001,0.0 ) ;
  }

  @Test
  public void test59() {
    dawson.pythag(-67.9367118764317,2.586730124855535 ) ;
  }

  @Test
  public void test60() {
    dawson.pythag(-67.9384588972517,-67.9384588972517 ) ;
  }

  @Test
  public void test61() {
    dawson.pythag(69.17954874617155,0.0 ) ;
  }

  @Test
  public void test62() {
    dawson.pythag(69.72122741604784,30.945928813964315 ) ;
  }

  @Test
  public void test63() {
    dawson.pythag(-7.1202363472230444E-307,0.0 ) ;
  }

  @Test
  public void test64() {
    dawson.pythag(72.85324201321458,12.745321965880024 ) ;
  }

  @Test
  public void test65() {
    dawson.pythag(74.10265151955478,74.10265151955478 ) ;
  }

  @Test
  public void test66() {
    dawson.pythag(-74.34484294967709,-91.79689914795266 ) ;
  }

  @Test
  public void test67() {
    dawson.pythag(78.84680910631198,-75.61797669095077 ) ;
  }

  @Test
  public void test68() {
    dawson.pythag(-7.896825413969113E-177,8.767237396033612E-193 ) ;
  }

  @Test
  public void test69() {
    dawson.pythag(-81.16008030621542,0.0 ) ;
  }

  @Test
  public void test70() {
    dawson.pythag(9.025663504218458E-64,-9.041094743549164E-64 ) ;
  }

  @Test
  public void test71() {
    dawson.pythag(9.222739838939245E-35,9.222739838939246E-35 ) ;
  }

  @Test
  public void test72() {
    dawson.pythag(-93.6355840513004,93.6355840513004 ) ;
  }

  @Test
  public void test73() {
    dawson.pythag(-93.77485792117422,0 ) ;
  }

  @Test
  public void test74() {
    dawson.pythag(9.442584258415081,-10.069241214735953 ) ;
  }

  @Test
  public void test75() {
    dawson.pythag(95.2056759366804,-53.38831784635754 ) ;
  }

  @Test
  public void test76() {
    dawson.pythag(9.934850588369983,0 ) ;
  }

  @Test
  public void test77() {
    dawson.pythag(-99.41410090930654,-43.276264418219476 ) ;
  }

  @Test
  public void test78() {
    dawson.pythag(-99.4661955113229,40.56267289780712 ) ;
  }
}
