import org.junit.Test;

public class TestbesskTest {

  @Test
  public void test0() {
    bess.bessk(-1,1.1770266274180187E-16 ) ;
  }

  @Test
  public void test1() {
    bess.bessk(113,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test2() {
    bess.bessk(-125,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test3() {
    bess.bessk(1501,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test4() {
    bess.bessk(-152,1.30826763158466E-16 ) ;
  }

  @Test
  public void test5() {
    bess.bessk(1581,1.412139318758074E-16 ) ;
  }

  @Test
  public void test6() {
    bess.bessk(1697,2.0 ) ;
  }

  @Test
  public void test7() {
    bess.bessk(2203,3.7500000000052083 ) ;
  }

  @Test
  public void test8() {
    bess.bessk(-2360,3.75000000000034 ) ;
  }

  @Test
  public void test9() {
    bess.bessk(-273,-44.60048304506354 ) ;
  }

  @Test
  public void test10() {
    bess.bessk(286,2.465190328815662E-32 ) ;
  }

  @Test
  public void test11() {
    bess.bessk(-287,2.0 ) ;
  }

  @Test
  public void test12() {
    bess.bessk(-297,1.9999999999999998 ) ;
  }

  @Test
  public void test13() {
    bess.bessk(300,2.0 ) ;
  }

  @Test
  public void test14() {
    bess.bessk(3118,2.000000000047483 ) ;
  }

  @Test
  public void test15() {
    bess.bessk(322,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test16() {
    bess.bessk(353,3.750000000000001 ) ;
  }

  @Test
  public void test17() {
    bess.bessk(360,-54.44491759909842 ) ;
  }

  @Test
  public void test18() {
    bess.bessk(396,1.9999999999999998 ) ;
  }

  @Test
  public void test19() {
    bess.bessk(-402,3.7500000000000004 ) ;
  }

  @Test
  public void test20() {
    bess.bessk(-416,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test21() {
    bess.bessk(-438,2.220446049250313E-16 ) ;
  }

  @Test
  public void test22() {
    bess.bessk(-451,-47.250866543434626 ) ;
  }

  @Test
  public void test23() {
    bess.bessk(465,-4.9E-324 ) ;
  }

  @Test
  public void test24() {
    bess.bessk(496,-22.333393636584447 ) ;
  }

  @Test
  public void test25() {
    bess.bessk(-512,2.0 ) ;
  }

  @Test
  public void test26() {
    bess.bessk(-574,2.0 ) ;
  }

  @Test
  public void test27() {
    bess.bessk(574,72.50116187003349 ) ;
  }

  @Test
  public void test28() {
    bess.bessk(581,0.0 ) ;
  }

  @Test
  public void test29() {
    bess.bessk(-591,2.0 ) ;
  }

  @Test
  public void test30() {
    bess.bessk(-626,2.0 ) ;
  }

  @Test
  public void test31() {
    bess.bessk(635,2.0 ) ;
  }

  @Test
  public void test32() {
    bess.bessk(-6,51.7730229586011 ) ;
  }

  @Test
  public void test33() {
    bess.bessk(688,2.0 ) ;
  }

  @Test
  public void test34() {
    bess.bessk(749,2.0 ) ;
  }

  @Test
  public void test35() {
    bess.bessk(762,2.0 ) ;
  }

  @Test
  public void test36() {
    bess.bessk(-766,-4.4E-323 ) ;
  }

  @Test
  public void test37() {
    bess.bessk(-778,2.0 ) ;
  }

  @Test
  public void test38() {
    bess.bessk(-795,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test39() {
    bess.bessk(803,2.0 ) ;
  }

  @Test
  public void test40() {
    bess.bessk(-808,2.0 ) ;
  }

  @Test
  public void test41() {
    bess.bessk(823,31.309348278454934 ) ;
  }

  @Test
  public void test42() {
    bess.bessk(-828,0.0 ) ;
  }

  @Test
  public void test43() {
    bess.bessk(-844,2.0 ) ;
  }

  @Test
  public void test44() {
    bess.bessk(845,2.0 ) ;
  }

  @Test
  public void test45() {
    bess.bessk(846,2.0 ) ;
  }

  @Test
  public void test46() {
    bess.bessk(-855,2.0 ) ;
  }

  @Test
  public void test47() {
    bess.bessk(-875,0 ) ;
  }

  @Test
  public void test48() {
    bess.bessk(876,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test49() {
    bess.bessk(925,1.9999999999999998 ) ;
  }

  @Test
  public void test50() {
    bess.bessk(939,0 ) ;
  }

  @Test
  public void test51() {
    bess.bessk(-953,2.0000000000000004 ) ;
  }

  @Test
  public void test52() {
    bess.bessk(-963,-43.146253645694024 ) ;
  }

  @Test
  public void test53() {
    bess.bessk(-971,1.5151894781986314E-16 ) ;
  }
}
