import org.junit.Test;

public class TestprobksTest {

  @Test
  public void test0() {
    dawson.probks(0.09973198397858307 ) ;
  }

  @Test
  public void test1() {
    dawson.probks(-0.16893369658037827 ) ;
  }

  @Test
  public void test2() {
    dawson.probks(-0.6793453772508986 ) ;
  }

  @Test
  public void test3() {
    dawson.probks(0.955680949723875 ) ;
  }

  @Test
  public void test4() {
    dawson.probks(-10.375946169509746 ) ;
  }

  @Test
  public void test5() {
    dawson.probks(-11.19232078484724 ) ;
  }

  @Test
  public void test6() {
    dawson.probks(-12.447764745856787 ) ;
  }

  @Test
  public void test7() {
    dawson.probks(-13.044301441987443 ) ;
  }

  @Test
  public void test8() {
    dawson.probks(-1.3180723714494222 ) ;
  }

  @Test
  public void test9() {
    dawson.probks(13.231899770615271 ) ;
  }

  @Test
  public void test10() {
    dawson.probks(13.573275412235361 ) ;
  }

  @Test
  public void test11() {
    dawson.probks(1.4245288558518352 ) ;
  }

  @Test
  public void test12() {
    dawson.probks(-1.469047291714287 ) ;
  }

  @Test
  public void test13() {
    dawson.probks(1.4743588363119584 ) ;
  }

  @Test
  public void test14() {
    dawson.probks(1.517427129002862 ) ;
  }

  @Test
  public void test15() {
    dawson.probks(1.5174271293836243 ) ;
  }

  @Test
  public void test16() {
    dawson.probks(-1.5174271293851462 ) ;
  }

  @Test
  public void test17() {
    dawson.probks(1.5174271293851462 ) ;
  }

  @Test
  public void test18() {
    dawson.probks(16.05776068832124 ) ;
  }

  @Test
  public void test19() {
    dawson.probks(1.6572052575860852 ) ;
  }

  @Test
  public void test20() {
    dawson.probks(17.652184346260483 ) ;
  }

  @Test
  public void test21() {
    dawson.probks(19.141277043475082 ) ;
  }

  @Test
  public void test22() {
    dawson.probks(19.28841506839983 ) ;
  }

  @Test
  public void test23() {
    dawson.probks(-19.28845000483797 ) ;
  }

  @Test
  public void test24() {
    dawson.probks(-19.28989870573698 ) ;
  }

  @Test
  public void test25() {
    dawson.probks(19.297421161394848 ) ;
  }

  @Test
  public void test26() {
    dawson.probks(-19.298465447756335 ) ;
  }

  @Test
  public void test27() {
    dawson.probks(2.585580048457345 ) ;
  }

  @Test
  public void test28() {
    dawson.probks(-3.758434851970165 ) ;
  }

  @Test
  public void test29() {
    dawson.probks(4.869961478442519 ) ;
  }

  @Test
  public void test30() {
    dawson.probks(-53.454627601982565 ) ;
  }

  @Test
  public void test31() {
    dawson.probks(-57.00375531118305 ) ;
  }

  @Test
  public void test32() {
    dawson.probks(-70.69208989245115 ) ;
  }

  @Test
  public void test33() {
    dawson.probks(7.303044508953647 ) ;
  }

  @Test
  public void test34() {
    dawson.probks(7.960919597278121 ) ;
  }

  @Test
  public void test35() {
    dawson.probks(-8.124608914241335 ) ;
  }

  @Test
  public void test36() {
    dawson.probks(8.34595536489762 ) ;
  }

  @Test
  public void test37() {
    dawson.probks(-8.402914970025705 ) ;
  }

  @Test
  public void test38() {
    dawson.probks(9.65099230067781 ) ;
  }
}
