import org.junit.Test;

public class TestdawsonTest {

  @Test
  public void test0() {
    dawson.dawson(-0.1999999999999993 ) ;
  }

  @Test
  public void test1() {
    dawson.dawson(-0.19999999999999996 ) ;
  }

  @Test
  public void test2() {
    dawson.dawson(0.19999999999999996 ) ;
  }

  @Test
  public void test3() {
    dawson.dawson(-0.20000000000000007 ) ;
  }

  @Test
  public void test4() {
    dawson.dawson(0.20000000000000007 ) ;
  }

  @Test
  public void test5() {
    dawson.dawson(-0.20000000000000018 ) ;
  }

  @Test
  public void test6() {
    dawson.dawson(0.20000000000000018 ) ;
  }

  @Test
  public void test7() {
    dawson.dawson(-0.20000000000000107 ) ;
  }

  @Test
  public void test8() {
    dawson.dawson(0.20000000000000284 ) ;
  }

  @Test
  public void test9() {
    dawson.dawson(0.2858536662129466 ) ;
  }

  @Test
  public void test10() {
    dawson.dawson(-0.39999999999999997 ) ;
  }

  @Test
  public void test11() {
    dawson.dawson(0.39999999999999997 ) ;
  }

  @Test
  public void test12() {
    dawson.dawson(0.40000000000000013 ) ;
  }

  @Test
  public void test13() {
    dawson.dawson(-0.40000000000000413 ) ;
  }

  @Test
  public void test14() {
    dawson.dawson(-0.46013700225572585 ) ;
  }

  @Test
  public void test15() {
    dawson.dawson(0.47892074226138703 ) ;
  }

  @Test
  public void test16() {
    dawson.dawson(-0.5391186494777571 ) ;
  }

  @Test
  public void test17() {
    dawson.dawson(-0.5479140307113219 ) ;
  }

  @Test
  public void test18() {
    dawson.dawson(0.5833789922966535 ) ;
  }

  @Test
  public void test19() {
    dawson.dawson(-0.6075008395842469 ) ;
  }

  @Test
  public void test20() {
    dawson.dawson(0.6336194407605898 ) ;
  }

  @Test
  public void test21() {
    dawson.dawson(0.6355721293173788 ) ;
  }

  @Test
  public void test22() {
    dawson.dawson(-0.6408461874472672 ) ;
  }

  @Test
  public void test23() {
    dawson.dawson(-0.6483885926480379 ) ;
  }

  @Test
  public void test24() {
    dawson.dawson(0.6817914748550322 ) ;
  }

  @Test
  public void test25() {
    dawson.dawson(0.7999999999983932 ) ;
  }

  @Test
  public void test26() {
    dawson.dawson(-0.7999999999999627 ) ;
  }

  @Test
  public void test27() {
    dawson.dawson(-0.7999999999999999 ) ;
  }

  @Test
  public void test28() {
    dawson.dawson(0.7999999999999999 ) ;
  }

  @Test
  public void test29() {
    dawson.dawson(-0.9179563262711676 ) ;
  }

  @Test
  public void test30() {
    dawson.dawson(0.9997910586068279 ) ;
  }

  @Test
  public void test31() {
    dawson.dawson(13.866455672079312 ) ;
  }

  @Test
  public void test32() {
    dawson.dawson(-1.6060895339071806 ) ;
  }

  @Test
  public void test33() {
    dawson.dawson(18.951282255671416 ) ;
  }

  @Test
  public void test34() {
    dawson.dawson(1.9064991715966602 ) ;
  }

  @Test
  public void test35() {
    dawson.dawson(-1.9900161677777124 ) ;
  }

  @Test
  public void test36() {
    dawson.dawson(2.7276002931871646 ) ;
  }

  @Test
  public void test37() {
    dawson.dawson(-2.7444723912368687 ) ;
  }

  @Test
  public void test38() {
    dawson.dawson(29.28226386309035 ) ;
  }

  @Test
  public void test39() {
    dawson.dawson(-31.56214419181876 ) ;
  }

  @Test
  public void test40() {
    dawson.dawson(-31.90773350783816 ) ;
  }

  @Test
  public void test41() {
    dawson.dawson(-32.7286514946758 ) ;
  }

  @Test
  public void test42() {
    dawson.dawson(-3.343755291006179 ) ;
  }

  @Test
  public void test43() {
    dawson.dawson(3.475376794197355 ) ;
  }

  @Test
  public void test44() {
    dawson.dawson(37.49755926999893 ) ;
  }

  @Test
  public void test45() {
    dawson.dawson(39.3021905241211 ) ;
  }

  @Test
  public void test46() {
    dawson.dawson(40.49558695409391 ) ;
  }

  @Test
  public void test47() {
    dawson.dawson(-40.52299065913032 ) ;
  }

  @Test
  public void test48() {
    dawson.dawson(4.158106435520412 ) ;
  }

  @Test
  public void test49() {
    dawson.dawson(42.529945713748845 ) ;
  }

  @Test
  public void test50() {
    dawson.dawson(-42.56295629341409 ) ;
  }

  @Test
  public void test51() {
    dawson.dawson(42.70691400047622 ) ;
  }

  @Test
  public void test52() {
    dawson.dawson(-4.312032566167373 ) ;
  }

  @Test
  public void test53() {
    dawson.dawson(-44.81282479599338 ) ;
  }

  @Test
  public void test54() {
    dawson.dawson(-4.7780475904408775 ) ;
  }

  @Test
  public void test55() {
    dawson.dawson(48.17130369320802 ) ;
  }

  @Test
  public void test56() {
    dawson.dawson(-5.303089874890276 ) ;
  }

  @Test
  public void test57() {
    dawson.dawson(57.26648516160117 ) ;
  }

  @Test
  public void test58() {
    dawson.dawson(-5.949111281190596 ) ;
  }

  @Test
  public void test59() {
    dawson.dawson(-60.96247017268599 ) ;
  }

  @Test
  public void test60() {
    dawson.dawson(-66.80905700380956 ) ;
  }

  @Test
  public void test61() {
    dawson.dawson(-67.75881467362674 ) ;
  }

  @Test
  public void test62() {
    dawson.dawson(-71.10582427854922 ) ;
  }

  @Test
  public void test63() {
    dawson.dawson(-71.6644442488128 ) ;
  }

  @Test
  public void test64() {
    dawson.dawson(-78.71039873295054 ) ;
  }

  @Test
  public void test65() {
    dawson.dawson(79.4362268371869 ) ;
  }

  @Test
  public void test66() {
    dawson.dawson(-85.24102497099493 ) ;
  }

  @Test
  public void test67() {
    dawson.dawson(-89.74198295522595 ) ;
  }

  @Test
  public void test68() {
    dawson.dawson(90.75246163661726 ) ;
  }

  @Test
  public void test69() {
    dawson.dawson(92.0428627378551 ) ;
  }

  @Test
  public void test70() {
    dawson.dawson(94.17782557631205 ) ;
  }

  @Test
  public void test71() {
    dawson.dawson(94.22958817958272 ) ;
  }

  @Test
  public void test72() {
    dawson.dawson(95.96398947533865 ) ;
  }

  @Test
  public void test73() {
    dawson.dawson(97.02085494039375 ) ;
  }
}
