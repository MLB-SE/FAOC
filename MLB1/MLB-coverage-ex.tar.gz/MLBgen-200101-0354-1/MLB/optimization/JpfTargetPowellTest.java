import org.junit.Test;

public class JpfTargetPowellTest {

  @Test
  public void test0() {
    Optimization.powell(-2.6840994947872026,-3.7256443061894794E-5 ) ;
  }

  @Test
  public void test1() {
    Optimization.powell(-2.814520186884457E-5,-3.5530034734160263 ) ;
  }

  @Test
  public void test2() {
    Optimization.powell(51.88142068546628,60.876567505305246 ) ;
  }

  @Test
  public void test3() {
    Optimization.powell(-52.60496892154861,-1.9009611078590893E-6 ) ;
  }

  @Test
  public void test4() {
    Optimization.powell(-73.93202556768924,36.03848617498349 ) ;
  }

  @Test
  public void test5() {
    Optimization.powell(-8.44496402915929,-1.1841376665988612E-5 ) ;
  }
}
