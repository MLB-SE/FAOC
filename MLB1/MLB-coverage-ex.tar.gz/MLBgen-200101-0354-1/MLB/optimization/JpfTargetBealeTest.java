import org.junit.Test;

public class JpfTargetBealeTest {

  @Test
  public void test0() {
    Optimization.beale(-0.1735635642733797,9.64236688316306 ) ;
  }

  @Test
  public void test1() {
    Optimization.beale(-17.578465889672486,17.15538660765803 ) ;
  }

  @Test
  public void test2() {
    Optimization.beale(-91.77283071024225,-55.06531288094823 ) ;
  }
}
