import org.junit.Test;

public class JpfTargetRosenbrockTest {

  @Test
  public void test0() {
    Optimization.rosenbrock(2.0539051423347057,4.220000017776502 ) ;
  }

  @Test
  public void test1() {
    Optimization.rosenbrock(-44.93960144901899,-35.97336246119167 ) ;
  }

  @Test
  public void test2() {
    Optimization.rosenbrock(-6.392935663206662,40.86804359826884 ) ;
  }
}
