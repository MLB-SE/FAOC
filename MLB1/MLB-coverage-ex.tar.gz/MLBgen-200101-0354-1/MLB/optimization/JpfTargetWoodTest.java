import org.junit.Test;

public class JpfTargetWoodTest {

  @Test
  public void test0() {
    Optimization.wood(1.0,0.9999999999999998,1.0,1.0 ) ;
  }

  @Test
  public void test1() {
    Optimization.wood(1.0,1.0,0,0 ) ;
  }

  @Test
  public void test2() {
    Optimization.wood(1.0,1.0000000000000004,1.0,1.0 ) ;
  }

  @Test
  public void test3() {
    Optimization.wood(1.0,1.0000000000000058,1.0,0.9999999999999943 ) ;
  }

  @Test
  public void test4() {
    Optimization.wood(1.0,1.0,1.0,1.0 ) ;
  }

  @Test
  public void test5() {
    Optimization.wood(1.0,1.0,-1.4219829575081633,16.649031859446726 ) ;
  }

  @Test
  public void test6() {
    Optimization.wood(1.0,1.0,-2.431638406358232,5.912865339276402 ) ;
  }

  @Test
  public void test7() {
    Optimization.wood(1.0,1.0,29.19507831701251,-13.932458805087307 ) ;
  }

  @Test
  public void test8() {
    Optimization.wood(1.0,1.0,-4.511608818891237,20.354614134697187 ) ;
  }

  @Test
  public void test9() {
    Optimization.wood(1.0,1.0,6.484135049687706,42.044007342588586 ) ;
  }

  @Test
  public void test10() {
    Optimization.wood(-36.602176550897546,37.63431387708411,0,0 ) ;
  }

  @Test
  public void test11() {
    Optimization.wood(-5.332081678341467,62.69740668153062,0,0 ) ;
  }

  @Test
  public void test12() {
    Optimization.wood(-7.629547816091602,58.209999878028135,0,0 ) ;
  }

  @Test
  public void test13() {
    Optimization.wood(-9.179826343235536,84.26921169196112,0,0 ) ;
  }

  @Test
  public void test14() {
    Optimization.wood(9.99999988341234,99.9999976682468,0,0 ) ;
  }
}
