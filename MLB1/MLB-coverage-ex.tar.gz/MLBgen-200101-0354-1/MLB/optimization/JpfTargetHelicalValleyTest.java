import org.junit.Test;

public class JpfTargetHelicalValleyTest {

  @Test
  public void test0() {
    Optimization.theta(0.18687746821706241,-44.65777533248205 ) ;
  }

  @Test
  public void test1() {
    Optimization.theta(100.0,0.0 ) ;
  }

  @Test
  public void test2() {
    Optimization.theta(100.0,-97.52135633518584 ) ;
  }

  @Test
  public void test3() {
    Optimization.theta(-1.232595164407831E-32,0 ) ;
  }

  @Test
  public void test4() {
    Optimization.theta(-1.3234889800848443E-23,100.0 ) ;
  }

  @Test
  public void test5() {
    Optimization.theta(-1.9705165519626686,79.74088341101688 ) ;
  }

  @Test
  public void test6() {
    Optimization.theta(1.9721522630525295E-31,0 ) ;
  }

  @Test
  public void test7() {
    Optimization.theta(-2.220446049250313E-16,100.0 ) ;
  }

  @Test
  public void test8() {
    Optimization.theta(-2.295601633189875,0 ) ;
  }

  @Test
  public void test9() {
    Optimization.theta(2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test10() {
    Optimization.theta(28.73601744252653,7.932075819331658 ) ;
  }

  @Test
  public void test11() {
    Optimization.theta(-2.9979466590065726,0 ) ;
  }

  @Test
  public void test12() {
    Optimization.theta(-3.0814879110195774E-33,0 ) ;
  }

  @Test
  public void test13() {
    Optimization.theta(34.15919913346039,-90.89211649659946 ) ;
  }

  @Test
  public void test14() {
    Optimization.theta(43.81898146077589,-7.213495075498386 ) ;
  }

  @Test
  public void test15() {
    Optimization.theta(-56.27597632042008,1.827812200294213 ) ;
  }

  @Test
  public void test16() {
    Optimization.theta(-58.5132849506664,84.3464718890473 ) ;
  }

  @Test
  public void test17() {
    Optimization.theta(-68.80981556391424,98.43897623885056 ) ;
  }

  @Test
  public void test18() {
    Optimization.theta(-7.105427357601002E-15,-85.85903172216251 ) ;
  }

  @Test
  public void test19() {
    Optimization.theta(78.85782409288257,0 ) ;
  }

  @Test
  public void test20() {
    Optimization.theta(-80.29394495856779,26.36670165065355 ) ;
  }

  @Test
  public void test21() {
    Optimization.theta(83.62301826275106,-99.13892037140876 ) ;
  }

  @Test
  public void test22() {
    Optimization.theta(-86.53318781698538,-44.49588524509831 ) ;
  }

  @Test
  public void test23() {
    Optimization.theta(88.07531856127636,0 ) ;
  }

  @Test
  public void test24() {
    Optimization.theta(-89.52779706599864,0 ) ;
  }

  @Test
  public void test25() {
    Optimization.theta(-9.311742891772994,0 ) ;
  }

  @Test
  public void test26() {
    Optimization.theta(93.23057075213717,6.552041353930832 ) ;
  }

  @Test
  public void test27() {
    Optimization.theta(99.99575124842998,2.7950226117821013 ) ;
  }
}
