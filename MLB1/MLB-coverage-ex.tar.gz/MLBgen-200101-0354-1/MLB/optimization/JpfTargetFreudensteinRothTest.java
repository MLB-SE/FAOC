import org.junit.Test;

public class JpfTargetFreudensteinRothTest {

  @Test
  public void test0() {
    Optimization.freudensteinRoth(15.98458840241987,-0.5239716076060432 ) ;
  }

  @Test
  public void test1() {
    Optimization.freudensteinRoth(17.11448647646168,0.8595696236957915 ) ;
  }

  @Test
  public void test2() {
    Optimization.freudensteinRoth(-75.8328676562867,17.169683968228085 ) ;
  }
}
