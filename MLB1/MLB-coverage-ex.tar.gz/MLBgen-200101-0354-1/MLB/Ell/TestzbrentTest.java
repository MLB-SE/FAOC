import org.junit.Test;

public class TestzbrentTest {

  @Test
  public void test0() {
    ell.zbrent(0.46830454671522603,-49.797177910721466,-38.16748284765883 ) ;
  }

  @Test
  public void test1() {
    ell.zbrent(-100.0,-100.0,0 ) ;
  }

  @Test
  public void test2() {
    ell.zbrent(-100.0,100.0,0 ) ;
  }

  @Test
  public void test3() {
    ell.zbrent(100.0,-100.0,0 ) ;
  }

  @Test
  public void test4() {
    ell.zbrent(100.0,100.0,0 ) ;
  }

  @Test
  public void test5() {
    ell.zbrent(100.0,-100.0,100.0 ) ;
  }

  @Test
  public void test6() {
    ell.zbrent(-100.0,-100.0,79.0457515704754 ) ;
  }

  @Test
  public void test7() {
    ell.zbrent(-100.0,3.141592653589793,0 ) ;
  }

  @Test
  public void test8() {
    ell.zbrent(-100.0,37.699111843077524,0 ) ;
  }

  @Test
  public void test9() {
    ell.zbrent(-100.0,62.83185307179587,0 ) ;
  }

  @Test
  public void test10() {
    ell.zbrent(10.040275691895948,8.80928022964281,0 ) ;
  }

  @Test
  public void test11() {
    ell.zbrent(-1.0507614211323843E-286,-100.0,0 ) ;
  }

  @Test
  public void test12() {
    ell.zbrent(11.159196181653599,70.31603646567484,0 ) ;
  }

  @Test
  public void test13() {
    ell.zbrent(11.536941071760827,1.029429542598346,0 ) ;
  }

  @Test
  public void test14() {
    ell.zbrent(12.146328243270446,-60.55861660368029,0 ) ;
  }

  @Test
  public void test15() {
    ell.zbrent(12.566370614359172,0,0 ) ;
  }

  @Test
  public void test16() {
    ell.zbrent(-12.566370614359174,-37.2309870817579,0 ) ;
  }

  @Test
  public void test17() {
    ell.zbrent(12.887471976776009,12.887471976776009,0 ) ;
  }

  @Test
  public void test18() {
    ell.zbrent(-12.891438300749313,-2.8165249671996535,0 ) ;
  }

  @Test
  public void test19() {
    ell.zbrent(-13.228920946673028,-6.569313949710292,0 ) ;
  }

  @Test
  public void test20() {
    ell.zbrent(1.3244766218212392,-32.74040315771917,0 ) ;
  }

  @Test
  public void test21() {
    ell.zbrent(-138.97190191651265,-62.09002791323412,0 ) ;
  }

  @Test
  public void test22() {
    ell.zbrent(-15.379315045154371,-35.58041081976735,0 ) ;
  }

  @Test
  public void test23() {
    ell.zbrent(-15.711915968059003,0.0039527001100368424,0 ) ;
  }

  @Test
  public void test24() {
    ell.zbrent(-15.791026016888466,13.09885191631433,0 ) ;
  }

  @Test
  public void test25() {
    ell.zbrent(-15.987277163808727,-3.377017006114542E-226,0 ) ;
  }

  @Test
  public void test26() {
    ell.zbrent(15.993947883700514,-78.167181361587,0 ) ;
  }

  @Test
  public void test27() {
    ell.zbrent(-16.80256655761508,-76.07529447639973,0 ) ;
  }

  @Test
  public void test28() {
    ell.zbrent(17.011055481371912,97.94365308292328,0 ) ;
  }

  @Test
  public void test29() {
    ell.zbrent(18.56851549453127,-28.613393600645438,0 ) ;
  }

  @Test
  public void test30() {
    ell.zbrent(18.84955592153876,47.12388980383015,0 ) ;
  }

  @Test
  public void test31() {
    ell.zbrent(20.369028902052406,74.63290270985479,0 ) ;
  }

  @Test
  public void test32() {
    ell.zbrent(-20.9010132736271,77.78459979078818,0 ) ;
  }

  @Test
  public void test33() {
    ell.zbrent(2.203096522533585,-82.86070985151224,0 ) ;
  }

  @Test
  public void test34() {
    ell.zbrent(24.906965422849822,-65.71969789197429,0 ) ;
  }

  @Test
  public void test35() {
    ell.zbrent(-25.132741228718345,-12.058527855888187,0 ) ;
  }

  @Test
  public void test36() {
    ell.zbrent(-26.08618667234245,15.707963267948967,0 ) ;
  }

  @Test
  public void test37() {
    ell.zbrent(26.77754150214382,78.60973402577005,0 ) ;
  }

  @Test
  public void test38() {
    ell.zbrent(-27.161754790687695,82.01134784839195,0 ) ;
  }

  @Test
  public void test39() {
    ell.zbrent(2.769516572688072,91.106186954104,0 ) ;
  }

  @Test
  public void test40() {
    ell.zbrent(-29.61111606427403,-56.17826653220137,0 ) ;
  }

  @Test
  public void test41() {
    ell.zbrent(-2.976123851474185,-43.982297150257104,0 ) ;
  }

  @Test
  public void test42() {
    ell.zbrent(-29.865619812604265,-53.40707511102648,0 ) ;
  }

  @Test
  public void test43() {
    ell.zbrent(-30.20585639567004,37.09024464810861,0 ) ;
  }

  @Test
  public void test44() {
    ell.zbrent(-30.94438759083984,-28.581192202886086,0 ) ;
  }

  @Test
  public void test45() {
    ell.zbrent(-32.6012698134257,94.24777960769379,0 ) ;
  }

  @Test
  public void test46() {
    ell.zbrent(33.2455547076716,24.76270931951828,0 ) ;
  }

  @Test
  public void test47() {
    ell.zbrent(34.53211999630727,82.65264617841342,0 ) ;
  }

  @Test
  public void test48() {
    ell.zbrent(34.84076359393275,-69.11503837897546,0 ) ;
  }

  @Test
  public void test49() {
    ell.zbrent(35.137876067565855,-56.548667764616276,0 ) ;
  }

  @Test
  public void test50() {
    ell.zbrent(37.46190961299999,19.699971682929075,0 ) ;
  }

  @Test
  public void test51() {
    ell.zbrent(37.699111843077524,-88.55430534103594,0 ) ;
  }

  @Test
  public void test52() {
    ell.zbrent(38.865617370545294,-47.1238898038469,0 ) ;
  }

  @Test
  public void test53() {
    ell.zbrent(-38.88234847996006,-6.542016191143958,0 ) ;
  }

  @Test
  public void test54() {
    ell.zbrent(-41.598087090941014,-1.4475770682822855,0 ) ;
  }

  @Test
  public void test55() {
    ell.zbrent(-42.02152009807099,0,0 ) ;
  }

  @Test
  public void test56() {
    ell.zbrent(-42.81839519094638,-15.707963267948967,0 ) ;
  }

  @Test
  public void test57() {
    ell.zbrent(-43.205394231433175,-49.48857953861276,6.2831853071776065 ) ;
  }

  @Test
  public void test58() {
    ell.zbrent(-44.303600980473824,27.95303005209142,0 ) ;
  }

  @Test
  public void test59() {
    ell.zbrent(44.5393897253497,38.256204418170114,0 ) ;
  }

  @Test
  public void test60() {
    ell.zbrent(-45.55236006691796,89.53465721717501,0 ) ;
  }

  @Test
  public void test61() {
    ell.zbrent(-45.898826355036306,-59.67617059700174,0 ) ;
  }

  @Test
  public void test62() {
    ell.zbrent(4.6212976022139637E-274,-51.84042844586298,0 ) ;
  }

  @Test
  public void test63() {
    ell.zbrent(-47.11776693321283,91.11230982473808,0 ) ;
  }

  @Test
  public void test64() {
    ell.zbrent(4.732208744667099E-271,-41.09742737689715,0 ) ;
  }

  @Test
  public void test65() {
    ell.zbrent(-48.09087166384569,-69.55572237793339,0 ) ;
  }

  @Test
  public void test66() {
    ell.zbrent(-49.605702903917745,96.58056702297756,0 ) ;
  }

  @Test
  public void test67() {
    ell.zbrent(-50.43669125424617,-3.0023369076735094,0 ) ;
  }

  @Test
  public void test68() {
    ell.zbrent(50.683041407842865,-94.24777960769379,0 ) ;
  }

  @Test
  public void test69() {
    ell.zbrent(50.83596712432518,-29.000891405087643,0 ) ;
  }

  @Test
  public void test70() {
    ell.zbrent(-51.92289330682296,-75.6945902290777,0 ) ;
  }

  @Test
  public void test71() {
    ell.zbrent(53.40707511102648,100.0,0 ) ;
  }

  @Test
  public void test72() {
    ell.zbrent(53.40707511102648,4.0087352883188885,0 ) ;
  }

  @Test
  public void test73() {
    ell.zbrent(53.4710465686986,56.612639222288394,0 ) ;
  }

  @Test
  public void test74() {
    ell.zbrent(-54.2110202317042,59.690260418206066,0 ) ;
  }

  @Test
  public void test75() {
    ell.zbrent(-55.2455782798261,-55.245578279826105,0 ) ;
  }

  @Test
  public void test76() {
    ell.zbrent(-56.548667764616276,-34.44630382628125,0 ) ;
  }

  @Test
  public void test77() {
    ell.zbrent(-56.59401185234769,-34.05720067302782,0 ) ;
  }

  @Test
  public void test78() {
    ell.zbrent(56.6001886764708,-31.41592653589793,0 ) ;
  }

  @Test
  public void test79() {
    ell.zbrent(-56.89929451618085,37.69911184307752,0 ) ;
  }

  @Test
  public void test80() {
    ell.zbrent(-57.65313162891544,-48.228353668146056,-9.424777960771312 ) ;
  }

  @Test
  public void test81() {
    ell.zbrent(-59.69026041820607,0,0 ) ;
  }

  @Test
  public void test82() {
    ell.zbrent(59.84403289316131,-96.0205921024311,0 ) ;
  }

  @Test
  public void test83() {
    ell.zbrent(60.24049965682232,37.69911184307752,0 ) ;
  }

  @Test
  public void test84() {
    ell.zbrent(60.793963796520245,1.0E-323,0 ) ;
  }

  @Test
  public void test85() {
    ell.zbrent(-62.33544643000146,-14.573744537198067,0 ) ;
  }

  @Test
  public void test86() {
    ell.zbrent(63.7396592699842,25.17083016418789,0 ) ;
  }

  @Test
  public void test87() {
    ell.zbrent(-64.61998888424668,65.97344572538564,0 ) ;
  }

  @Test
  public void test88() {
    ell.zbrent(65.29256585774598,-59.690260418206066,0 ) ;
  }

  @Test
  public void test89() {
    ell.zbrent(65.52054680043773,18.347880138057945,0 ) ;
  }

  @Test
  public void test90() {
    ell.zbrent(-67.12901677781029,-72.25663103256525,0 ) ;
  }

  @Test
  public void test91() {
    ell.zbrent(-6.754034012229084E-226,4.252210187778229,0 ) ;
  }

  @Test
  public void test92() {
    ell.zbrent(68.2390969013197,97.008224711076,0 ) ;
  }

  @Test
  public void test93() {
    ell.zbrent(69.11503837897544,14.077530299527265,0 ) ;
  }

  @Test
  public void test94() {
    ell.zbrent(69.65157735418501,-55.985963047873646,0 ) ;
  }

  @Test
  public void test95() {
    ell.zbrent(-70.34055677088828,0,0 ) ;
  }

  @Test
  public void test96() {
    ell.zbrent(-7.175988269038226,12.566370614359174,0 ) ;
  }

  @Test
  public void test97() {
    ell.zbrent(73.35105556044536,77.44539181186471,65.83724565256185 ) ;
  }

  @Test
  public void test98() {
    ell.zbrent(73.89428389883287,-40.84070449666731,0 ) ;
  }

  @Test
  public void test99() {
    ell.zbrent(74.09578717545355,-68.71448466205669,0 ) ;
  }

  @Test
  public void test100() {
    ell.zbrent(-75.39822368615505,-69.81668756079351,0 ) ;
  }

  @Test
  public void test101() {
    ell.zbrent(-76.47946827334678,-72.25663103256524,0 ) ;
  }

  @Test
  public void test102() {
    ell.zbrent(78.2210048889902,-15.616323851867975,0 ) ;
  }

  @Test
  public void test103() {
    ell.zbrent(78.53981633974483,-100.0,0 ) ;
  }

  @Test
  public void test104() {
    ell.zbrent(78.5513797596252,119.39208425629242,0 ) ;
  }

  @Test
  public void test105() {
    ell.zbrent(80.49480521855762,-91.06567865644976,0 ) ;
  }

  @Test
  public void test106() {
    ell.zbrent(82.21296400982635,-0.5315550164917265,0 ) ;
  }

  @Test
  public void test107() {
    ell.zbrent(82.9735854136839,-4.639517554184792,0 ) ;
  }

  @Test
  public void test108() {
    ell.zbrent(84.82300164692441,99.99999730519929,0 ) ;
  }

  @Test
  public void test109() {
    ell.zbrent(85.26587375579697,47.1238898038469,0 ) ;
  }

  @Test
  public void test110() {
    ell.zbrent(-85.2903335217517,-10.158653620926145,0 ) ;
  }

  @Test
  public void test111() {
    ell.zbrent(-85.96050975208651,1.557374211108995E-207,0 ) ;
  }

  @Test
  public void test112() {
    ell.zbrent(-8.63449626738857,-75.39822368615503,0 ) ;
  }

  @Test
  public void test113() {
    ell.zbrent(-8.85755934495927,0,0 ) ;
  }

  @Test
  public void test114() {
    ell.zbrent(-89.09153414183952,-38.82605168440283,0 ) ;
  }

  @Test
  public void test115() {
    ell.zbrent(89.81154806376946,50.26548245743669,0 ) ;
  }

  @Test
  public void test116() {
    ell.zbrent(91.106186954104,0,0 ) ;
  }

  @Test
  public void test117() {
    ell.zbrent(91.13242584280735,55.30971277243506,0 ) ;
  }

  @Test
  public void test118() {
    ell.zbrent(-9.183562799409568,6.9159493289108696,0 ) ;
  }

  @Test
  public void test119() {
    ell.zbrent(91.94438606944684,47.1238898038469,0 ) ;
  }

  @Test
  public void test120() {
    ell.zbrent(-91.969729169828,-59.69026041820607,0 ) ;
  }

  @Test
  public void test121() {
    ell.zbrent(92.17433682805017,77.20265261112607,0 ) ;
  }

  @Test
  public void test122() {
    ell.zbrent(-92.17623367278456,31.41592653589793,0 ) ;
  }

  @Test
  public void test123() {
    ell.zbrent(92.47840127395747,77.16760201989136,0 ) ;
  }

  @Test
  public void test124() {
    ell.zbrent(-92.68878575314955,53.143687343833506,0 ) ;
  }

  @Test
  public void test125() {
    ell.zbrent(93.06495838627937,9.424777960769381,0 ) ;
  }

  @Test
  public void test126() {
    ell.zbrent(9.336031668344326,9.336031668344328,0 ) ;
  }

  @Test
  public void test127() {
    ell.zbrent(95.77283022703847,16.851902639496345,0 ) ;
  }

  @Test
  public void test128() {
    ell.zbrent(-9.620684361462466,66.3004148850732,0 ) ;
  }

  @Test
  public void test129() {
    ell.zbrent(-96.31325586778242,-4.1624948318597947E-258,0 ) ;
  }
}
