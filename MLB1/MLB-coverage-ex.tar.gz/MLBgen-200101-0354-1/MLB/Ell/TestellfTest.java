import org.junit.Test;

public class TestellfTest {

  @Test
  public void test0() {
    ell.ellf(0.016329754639759282,-0.7769161744946715 ) ;
  }

  @Test
  public void test1() {
    ell.ellf(11.343864519990632,-1.0638777578468237 ) ;
  }

  @Test
  public void test2() {
    ell.ellf(-12.35157164290493,-4.69150924987331 ) ;
  }

  @Test
  public void test3() {
    ell.ellf(-12.56418919943604,-0.2367394244308496 ) ;
  }

  @Test
  public void test4() {
    ell.ellf(153.9478875360581,1.5003155066587688E-6 ) ;
  }

  @Test
  public void test5() {
    ell.ellf(15.707963267817306,45.74433083409337 ) ;
  }

  @Test
  public void test6() {
    ell.ellf(15.722105167895185,99.99999999999636 ) ;
  }

  @Test
  public void test7() {
    ell.ellf(-169.4885729337977,-2.7137411098275805 ) ;
  }

  @Test
  public void test8() {
    ell.ellf(18.849555891568265,-0.12930057871100556 ) ;
  }

  @Test
  public void test9() {
    ell.ellf(18.849555921457238,79.44095376509445 ) ;
  }

  @Test
  public void test10() {
    ell.ellf(-18.84955592364633,-6.100799198185307 ) ;
  }

  @Test
  public void test11() {
    ell.ellf(18.849555935900476,62.390825235845824 ) ;
  }

  @Test
  public void test12() {
    ell.ellf(18.86604343180828,1.0000000000003708 ) ;
  }

  @Test
  public void test13() {
    ell.ellf(193.20793870193398,0.9999989545557961 ) ;
  }

  @Test
  public void test14() {
    ell.ellf(-20.42035225127264,-0.9999999999999958 ) ;
  }

  @Test
  public void test15() {
    ell.ellf(21.863724006699137,0.34368614701139233 ) ;
  }

  @Test
  public void test16() {
    ell.ellf(2.3285973164324076,27.181837880996795 ) ;
  }

  @Test
  public void test17() {
    ell.ellf(-25.132741211845403,0.9377959785571327 ) ;
  }

  @Test
  public void test18() {
    ell.ellf(25.132741215178026,0.7378736536264496 ) ;
  }

  @Test
  public void test19() {
    ell.ellf(25.13274121558051,-1.3649295564708757 ) ;
  }

  @Test
  public void test20() {
    ell.ellf(-25.13274122923033,8.570987541279663 ) ;
  }

  @Test
  public void test21() {
    ell.ellf(28.274304788952506,5.46505842551108E-4 ) ;
  }

  @Test
  public void test22() {
    ell.ellf(-28.27433431093917,0.2830325125391604 ) ;
  }

  @Test
  public void test23() {
    ell.ellf(-28.284334048982306,-100.0 ) ;
  }

  @Test
  public void test24() {
    ell.ellf(30.459026620672063,70.95607670381403 ) ;
  }

  @Test
  public void test25() {
    ell.ellf(3.110424612912894,31.70965168846368 ) ;
  }

  @Test
  public void test26() {
    ell.ellf(-3.1410674235294422,-2.9135763986870252E-5 ) ;
  }

  @Test
  public void test27() {
    ell.ellf(3.1411753936798203,0.8920115916538991 ) ;
  }

  @Test
  public void test28() {
    ell.ellf(31.415859737845537,5.5058265054559654E-5 ) ;
  }

  @Test
  public void test29() {
    ell.ellf(-3.1415926335231794,-0.38688699753778183 ) ;
  }

  @Test
  public void test30() {
    ell.ellf(3.141592642313491,27.555775449824253 ) ;
  }

  @Test
  public void test31() {
    ell.ellf(31.41592652223094,0.8883587000381312 ) ;
  }

  @Test
  public void test32() {
    ell.ellf(-31.41592652875094,95.4479298518595 ) ;
  }

  @Test
  public void test33() {
    ell.ellf(31.4164462278752,1.0000000004889011 ) ;
  }

  @Test
  public void test34() {
    ell.ellf(34.26209262159372,1.013275887707323 ) ;
  }

  @Test
  public void test35() {
    ell.ellf(-34.55751918813214,-3.8851527902904737 ) ;
  }

  @Test
  public void test36() {
    ell.ellf(34.55751920820306,-23.425514745859925 ) ;
  }

  @Test
  public void test37() {
    ell.ellf(-37.610370517072774,-11.28351080350638 ) ;
  }

  @Test
  public void test38() {
    ell.ellf(37.69911182494496,-0.4124735663784671 ) ;
  }

  @Test
  public void test39() {
    ell.ellf(37.69911184569988,58.101805509745645 ) ;
  }

  @Test
  public void test40() {
    ell.ellf(37.69938552044523,0.0015335422407053326 ) ;
  }

  @Test
  public void test41() {
    ell.ellf(37.76517443210672,-15.148176340688948 ) ;
  }

  @Test
  public void test42() {
    ell.ellf(-39.269908169872416,-1.0 ) ;
  }

  @Test
  public void test43() {
    ell.ellf(40.80359739399323,26.955204106550532 ) ;
  }

  @Test
  public void test44() {
    ell.ellf(40.8407045042981,17.082383974097485 ) ;
  }

  @Test
  public void test45() {
    ell.ellf(40.84135670660382,0.8991623937498567 ) ;
  }

  @Test
  public void test46() {
    ell.ellf(-40.864447322739615,59.56102850766495 ) ;
  }

  @Test
  public void test47() {
    ell.ellf(42.41150082346223,1.0 ) ;
  }

  @Test
  public void test48() {
    ell.ellf(43.05165461960385,-0.5220873731798008 ) ;
  }

  @Test
  public void test49() {
    ell.ellf(43.982297166010504,-0.6840995063459587 ) ;
  }

  @Test
  public void test50() {
    ell.ellf(43.98422011938382,-1.0000000000035518 ) ;
  }

  @Test
  public void test51() {
    ell.ellf(47.12388392858388,7.897313754068255E-4 ) ;
  }

  @Test
  public void test52() {
    ell.ellf(-49.023584214371255,-1.1103888386322258 ) ;
  }

  @Test
  public void test53() {
    ell.ellf(-50.26548217971985,-0.9977604475357776 ) ;
  }

  @Test
  public void test54() {
    ell.ellf(-50.26548244191056,-0.04637529266197983 ) ;
  }

  @Test
  public void test55() {
    ell.ellf(50.26548244710292,-9.57778316611533 ) ;
  }

  @Test
  public void test56() {
    ell.ellf(-50.26626258621861,-9.45560578854793E-6 ) ;
  }

  @Test
  public void test57() {
    ell.ellf(-52.26741267604095,-1.1929749327651495 ) ;
  }

  @Test
  public void test58() {
    ell.ellf(53.40707473740824,1.0012486749322662 ) ;
  }

  @Test
  public void test59() {
    ell.ellf(-53.407075095996724,-0.879309611303392 ) ;
  }

  @Test
  public void test60() {
    ell.ellf(53.40707510470597,-1.6944034646897848 ) ;
  }

  @Test
  public void test61() {
    ell.ellf(-56.548667744323225,0.595709392548514 ) ;
  }

  @Test
  public void test62() {
    ell.ellf(-56.5486677466285,42.02668879447876 ) ;
  }

  @Test
  public void test63() {
    ell.ellf(58.119464077954,-0.9999999999999983 ) ;
  }

  @Test
  public void test64() {
    ell.ellf(-59.6816796859442,-116.54160053949175 ) ;
  }

  @Test
  public void test65() {
    ell.ellf(-59.6901459459171,-0.9999999930611144 ) ;
  }

  @Test
  public void test66() {
    ell.ellf(62.83185306703801,-3.0153226518598153 ) ;
  }

  @Test
  public void test67() {
    ell.ellf(-65.97344570654559,1.3113956793039039 ) ;
  }

  @Test
  public void test68() {
    ell.ellf(65.97344570802218,-27.719383193506424 ) ;
  }

  @Test
  public void test69() {
    ell.ellf(-65.97344574808335,-0.9571287426629452 ) ;
  }

  @Test
  public void test70() {
    ell.ellf(67.54424205218055,-0.9999999999999999 ) ;
  }

  @Test
  public void test71() {
    ell.ellf(69.11503826882172,-0.05991278578962689 ) ;
  }

  @Test
  public void test72() {
    ell.ellf(69.11503836949005,8.054236179906596 ) ;
  }

  @Test
  public void test73() {
    ell.ellf(70.67051838153401,1.0001173063602269 ) ;
  }

  @Test
  public void test74() {
    ell.ellf(-71.50466446003688,-0.010200068223300107 ) ;
  }

  @Test
  public void test75() {
    ell.ellf(72.25663104531472,-0.18510038167915377 ) ;
  }

  @Test
  public void test76() {
    ell.ellf(72.25663104892944,-0.9102892877862426 ) ;
  }

  @Test
  public void test77() {
    ell.ellf(-72.256698242307,-41.16565585713253 ) ;
  }

  @Test
  public void test78() {
    ell.ellf(-72.41635404815625,4.654082034318051 ) ;
  }

  @Test
  public void test79() {
    ell.ellf(75.3982217104993,1.0000176213445586 ) ;
  }

  @Test
  public void test80() {
    ell.ellf(-75.39822368359057,1.8741464114992274 ) ;
  }

  @Test
  public void test81() {
    ell.ellf(-78.53981583986753,-1.1012874808339888 ) ;
  }

  @Test
  public void test82() {
    ell.ellf(7.85398162345168,0.25022561313512454 ) ;
  }

  @Test
  public void test83() {
    ell.ellf(-78.53981635332187,0.6333908990053697 ) ;
  }

  @Test
  public void test84() {
    ell.ellf(78.53982385593488,-3.8798611898113337E-4 ) ;
  }

  @Test
  public void test85() {
    ell.ellf(81.50557901474235,5.716723342176112 ) ;
  }

  @Test
  public void test86() {
    ell.ellf(81.62558808877098,17.92374246839398 ) ;
  }

  @Test
  public void test87() {
    ell.ellf(81.68139826777099,1.0000006421723378 ) ;
  }

  @Test
  public void test88() {
    ell.ellf(81.68140900120925,5.361869825780723 ) ;
  }

  @Test
  public void test89() {
    ell.ellf(-81.68141107444737,-0.9999949227525123 ) ;
  }

  @Test
  public void test90() {
    ell.ellf(81.69034970424242,0.9999999999994065 ) ;
  }

  @Test
  public void test91() {
    ell.ellf(-81.69616837475296,-95.81620338154163 ) ;
  }

  @Test
  public void test92() {
    ell.ellf(-81.70284612795918,-0.7972638887532852 ) ;
  }

  @Test
  public void test93() {
    ell.ellf(-84.61154886062073,-3.052487470858537 ) ;
  }

  @Test
  public void test94() {
    ell.ellf(-84.82300165456161,-18.907429115698328 ) ;
  }

  @Test
  public void test95() {
    ell.ellf(-84.8230016766064,-0.9963277588015738 ) ;
  }

  @Test
  public void test96() {
    ell.ellf(84.82300169534943,-1.0624507879234337 ) ;
  }

  @Test
  public void test97() {
    ell.ellf(86.3937979737203,-1.0 ) ;
  }

  @Test
  public void test98() {
    ell.ellf(-87.96459431741707,100.0 ) ;
  }

  @Test
  public void test99() {
    ell.ellf(91.03873156246917,20.957230456623655 ) ;
  }

  @Test
  public void test100() {
    ell.ellf(91.10618663276804,-1.0008995770368012 ) ;
  }

  @Test
  public void test101() {
    ell.ellf(91.10618695991083,38.06689938751501 ) ;
  }

  @Test
  public void test102() {
    ell.ellf(-91.1094406767643,1.0000000000056182 ) ;
  }

  @Test
  public void test103() {
    ell.ellf(9.42477018273384,0.0010724471765338056 ) ;
  }

  @Test
  public void test104() {
    ell.ellf(-94.2477796023235,0.9786463974087454 ) ;
  }

  @Test
  public void test105() {
    ell.ellf(-94.24777963534251,-0.8970768311122987 ) ;
  }

  @Test
  public void test106() {
    ell.ellf(95.79024201544695,-0.4058176775634683 ) ;
  }

  @Test
  public void test107() {
    ell.ellf(95.81857593448869,0.2258915004302236 ) ;
  }

  @Test
  public void test108() {
    ell.ellf(96.16209871230186,19.523453345584784 ) ;
  }

  @Test
  public void test109() {
    ell.ellf(97.38030929021488,110.3406026703262 ) ;
  }

  @Test
  public void test110() {
    ell.ellf(-97.38937215250337,-0.9956821614365938 ) ;
  }

  @Test
  public void test111() {
    ell.ellf(97.38937224630938,-1.096631381226503 ) ;
  }

  @Test
  public void test112() {
    ell.ellf(-97.38937225283216,0.5504856590119447 ) ;
  }

  @Test
  public void test113() {
    ell.ellf(97.38937226772629,-66.46244303528951 ) ;
  }
}
