import org.junit.Test;

public class TestplgndrTest {

  @Test
  public void test0() {
    plgndr.plgndr(0,0,0 ) ;
  }

  @Test
  public void test1() {
    plgndr.plgndr(0,-1,0 ) ;
  }

  @Test
  public void test2() {
    plgndr.plgndr(0,-12,0 ) ;
  }

  @Test
  public void test3() {
    plgndr.plgndr(0,-179,0 ) ;
  }

  @Test
  public void test4() {
    plgndr.plgndr(0,454,0 ) ;
  }

  @Test
  public void test5() {
    plgndr.plgndr(1,0,0 ) ;
  }

  @Test
  public void test6() {
    plgndr.plgndr(2,0,0 ) ;
  }

  @Test
  public void test7() {
    plgndr.plgndr(233,29,1.0 ) ;
  }

  @Test
  public void test8() {
    plgndr.plgndr(244,217,1.0000000000000007 ) ;
  }

  @Test
  public void test9() {
    plgndr.plgndr(-315,-497,0 ) ;
  }

  @Test
  public void test10() {
    plgndr.plgndr(317,255,0.9882838966713493 ) ;
  }

  @Test
  public void test11() {
    plgndr.plgndr(363,203,67.02745627679391 ) ;
  }

  @Test
  public void test12() {
    plgndr.plgndr(-3,-949,0 ) ;
  }

  @Test
  public void test13() {
    plgndr.plgndr(-445,0,0 ) ;
  }

  @Test
  public void test14() {
    plgndr.plgndr(457,555,0 ) ;
  }

  @Test
  public void test15() {
    plgndr.plgndr(-480,0,0 ) ;
  }

  @Test
  public void test16() {
    plgndr.plgndr(488,0,0.0 ) ;
  }

  @Test
  public void test17() {
    plgndr.plgndr(-561,-561,0 ) ;
  }

  @Test
  public void test18() {
    plgndr.plgndr(-603,0,0 ) ;
  }

  @Test
  public void test19() {
    plgndr.plgndr(-622,-329,0 ) ;
  }

  @Test
  public void test20() {
    plgndr.plgndr(695,3,-60.48779713930092 ) ;
  }

  @Test
  public void test21() {
    plgndr.plgndr(-696,994,0 ) ;
  }

  @Test
  public void test22() {
    plgndr.plgndr(-710,0,0 ) ;
  }

  @Test
  public void test23() {
    plgndr.plgndr(-741,-90,0 ) ;
  }

  @Test
  public void test24() {
    plgndr.plgndr(747,956,0 ) ;
  }

  @Test
  public void test25() {
    plgndr.plgndr(757,383,9.871864235431076 ) ;
  }

  @Test
  public void test26() {
    plgndr.plgndr(803,49,-1.0 ) ;
  }

  @Test
  public void test27() {
    plgndr.plgndr(-823,0,0 ) ;
  }

  @Test
  public void test28() {
    plgndr.plgndr(827,680,0.0 ) ;
  }

  @Test
  public void test29() {
    plgndr.plgndr(-835,1,0 ) ;
  }

  @Test
  public void test30() {
    plgndr.plgndr(839,189,-0.9999999999999991 ) ;
  }

  @Test
  public void test31() {
    plgndr.plgndr(839,435,0.0 ) ;
  }

  @Test
  public void test32() {
    plgndr.plgndr(855,444,0.0 ) ;
  }

  @Test
  public void test33() {
    plgndr.plgndr(859,824,0.0 ) ;
  }

  @Test
  public void test34() {
    plgndr.plgndr(887,900,0 ) ;
  }

  @Test
  public void test35() {
    plgndr.plgndr(928,898,-71.42365621628201 ) ;
  }

  @Test
  public void test36() {
    plgndr.plgndr(-972,-973,0 ) ;
  }

  @Test
  public void test37() {
    plgndr.plgndr(985,439,0 ) ;
  }
}
