import org.junit.Test;

public class TestcisiTest {

  @Test
  public void test0() {
    frenel.cisi(-0.1908246707001524 ) ;
  }

  @Test
  public void test1() {
    frenel.cisi(0.30149208630614055 ) ;
  }

  @Test
  public void test2() {
    frenel.cisi(-0.3149053661981611 ) ;
  }

  @Test
  public void test3() {
    frenel.cisi(-0.5371280213998517 ) ;
  }

  @Test
  public void test4() {
    frenel.cisi(-0.5586274116840788 ) ;
  }

  @Test
  public void test5() {
    frenel.cisi(0.7544636868695904 ) ;
  }

  @Test
  public void test6() {
    frenel.cisi(0.7869196634517692 ) ;
  }

  @Test
  public void test7() {
    frenel.cisi(-0.7881432119250462 ) ;
  }

  @Test
  public void test8() {
    frenel.cisi(-0.8482886215254016 ) ;
  }

  @Test
  public void test9() {
    frenel.cisi(-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test10() {
    frenel.cisi(1.1102230246251565E-16 ) ;
  }

  @Test
  public void test11() {
    frenel.cisi(1.154122327223217E-128 ) ;
  }

  @Test
  public void test12() {
    frenel.cisi(-1.291018538057 ) ;
  }

  @Test
  public void test13() {
    frenel.cisi(16.784536058821146 ) ;
  }

  @Test
  public void test14() {
    frenel.cisi(1.734723475976807E-18 ) ;
  }

  @Test
  public void test15() {
    frenel.cisi(1.7763568394002505E-15 ) ;
  }

  @Test
  public void test16() {
    frenel.cisi(-18.42938480658627 ) ;
  }

  @Test
  public void test17() {
    frenel.cisi(-2.0 ) ;
  }

  @Test
  public void test18() {
    frenel.cisi(2.0 ) ;
  }

  @Test
  public void test19() {
    frenel.cisi(2.465190328815662E-32 ) ;
  }

  @Test
  public void test20() {
    frenel.cisi(-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test21() {
    frenel.cisi(34.68276403532812 ) ;
  }

  @Test
  public void test22() {
    frenel.cisi(3.469446951953614E-18 ) ;
  }

  @Test
  public void test23() {
    frenel.cisi(-36.726349706576336 ) ;
  }

  @Test
  public void test24() {
    frenel.cisi(4.4455174989701545E-162 ) ;
  }

  @Test
  public void test25() {
    frenel.cisi(-4.7477838728798994E-66 ) ;
  }

  @Test
  public void test26() {
    frenel.cisi(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test27() {
    frenel.cisi(4.930380657631324E-32 ) ;
  }

  @Test
  public void test28() {
    frenel.cisi(55.069857400432255 ) ;
  }

  @Test
  public void test29() {
    frenel.cisi(-5.551115123125783E-17 ) ;
  }

  @Test
  public void test30() {
    frenel.cisi(5.573332198717324 ) ;
  }

  @Test
  public void test31() {
    frenel.cisi(-56.06836337188914 ) ;
  }

  @Test
  public void test32() {
    frenel.cisi(6.162975822039155E-33 ) ;
  }

  @Test
  public void test33() {
    frenel.cisi(-7.296826050058229 ) ;
  }

  @Test
  public void test34() {
    frenel.cisi(-7.490682167507517E-96 ) ;
  }

  @Test
  public void test35() {
    frenel.cisi(7.788198821020686 ) ;
  }

  @Test
  public void test36() {
    frenel.cisi(-8.881784197001252E-16 ) ;
  }

  @Test
  public void test37() {
    frenel.cisi(8.881784197001252E-16 ) ;
  }

  @Test
  public void test38() {
    frenel.cisi(-8.89103499794031E-162 ) ;
  }

  @Test
  public void test39() {
    frenel.cisi(-92.30469907674481 ) ;
  }

  @Test
  public void test40() {
    frenel.cisi(-9.860761315262648E-32 ) ;
  }
}
