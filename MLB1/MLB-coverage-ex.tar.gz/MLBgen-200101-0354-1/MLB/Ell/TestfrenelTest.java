import org.junit.Test;

public class TestfrenelTest {

  @Test
  public void test0() {
    frenel.frenel(0.05884792165493294 ) ;
  }

  @Test
  public void test1() {
    frenel.frenel(0.24453945578679281 ) ;
  }

  @Test
  public void test2() {
    frenel.frenel(0.33037863214080687 ) ;
  }

  @Test
  public void test3() {
    frenel.frenel(1.0157397574219365 ) ;
  }

  @Test
  public void test4() {
    frenel.frenel(-13.215577216580712 ) ;
  }

  @Test
  public void test5() {
    frenel.frenel(1.4188616860636845 ) ;
  }

  @Test
  public void test6() {
    frenel.frenel(1.4188616860636847 ) ;
  }

  @Test
  public void test7() {
    frenel.frenel(1.418861686063685 ) ;
  }

  @Test
  public void test8() {
    frenel.frenel(1.4188616860636856 ) ;
  }

  @Test
  public void test9() {
    frenel.frenel(1.4188616860636887 ) ;
  }

  @Test
  public void test10() {
    frenel.frenel(1.41886168606381 ) ;
  }

  @Test
  public void test11() {
    frenel.frenel(1.418861686063999 ) ;
  }

  @Test
  public void test12() {
    frenel.frenel(1.4188616860654868 ) ;
  }

  @Test
  public void test13() {
    frenel.frenel(1.4188616860908778 ) ;
  }

  @Test
  public void test14() {
    frenel.frenel(1.4188616860986265 ) ;
  }

  @Test
  public void test15() {
    frenel.frenel(1.4188616889060008 ) ;
  }

  @Test
  public void test16() {
    frenel.frenel(1.4188616992904184 ) ;
  }

  @Test
  public void test17() {
    frenel.frenel(1.4188620019610765 ) ;
  }

  @Test
  public void test18() {
    frenel.frenel(1.4188793862373617 ) ;
  }

  @Test
  public void test19() {
    frenel.frenel(1.418956033157459 ) ;
  }

  @Test
  public void test20() {
    frenel.frenel(1.4199701414959907 ) ;
  }

  @Test
  public void test21() {
    frenel.frenel(1.4267498467156832 ) ;
  }

  @Test
  public void test22() {
    frenel.frenel(1.4275884283360365 ) ;
  }

  @Test
  public void test23() {
    frenel.frenel(1.4278710446340197 ) ;
  }

  @Test
  public void test24() {
    frenel.frenel(1.4330842109379502 ) ;
  }

  @Test
  public void test25() {
    frenel.frenel(1.4339046425189412 ) ;
  }

  @Test
  public void test26() {
    frenel.frenel(1.4359484747743192 ) ;
  }

  @Test
  public void test27() {
    frenel.frenel(1.4368591878099668 ) ;
  }

  @Test
  public void test28() {
    frenel.frenel(1.4390355364143605 ) ;
  }

  @Test
  public void test29() {
    frenel.frenel(1.441233517537289 ) ;
  }

  @Test
  public void test30() {
    frenel.frenel(1.4414840328060525 ) ;
  }

  @Test
  public void test31() {
    frenel.frenel(1.4440820254708937 ) ;
  }

  @Test
  public void test32() {
    frenel.frenel(1.452879663904292 ) ;
  }

  @Test
  public void test33() {
    frenel.frenel(1.4585585357053028 ) ;
  }

  @Test
  public void test34() {
    frenel.frenel(1.46298185856289 ) ;
  }

  @Test
  public void test35() {
    frenel.frenel(1.4657729206086756 ) ;
  }

  @Test
  public void test36() {
    frenel.frenel(1.4735282027642804 ) ;
  }

  @Test
  public void test37() {
    frenel.frenel(1.4739850076090528 ) ;
  }

  @Test
  public void test38() {
    frenel.frenel(1.47919233476665 ) ;
  }

  @Test
  public void test39() {
    frenel.frenel(1.4821855205321612 ) ;
  }

  @Test
  public void test40() {
    frenel.frenel(1.482308962266199 ) ;
  }

  @Test
  public void test41() {
    frenel.frenel(1.4905657796633616 ) ;
  }

  @Test
  public void test42() {
    frenel.frenel(1.492496723262444 ) ;
  }

  @Test
  public void test43() {
    frenel.frenel(1.4977656904175962 ) ;
  }

  @Test
  public void test44() {
    frenel.frenel(1.4999999999593654 ) ;
  }

  @Test
  public void test45() {
    frenel.frenel(1.4999999999703708 ) ;
  }

  @Test
  public void test46() {
    frenel.frenel(1.4999999999985913 ) ;
  }

  @Test
  public void test47() {
    frenel.frenel(1.4999999999990041 ) ;
  }

  @Test
  public void test48() {
    frenel.frenel(1.4999999999990976 ) ;
  }

  @Test
  public void test49() {
    frenel.frenel(1.4999999999993148 ) ;
  }

  @Test
  public void test50() {
    frenel.frenel(1.4999999999997582 ) ;
  }

  @Test
  public void test51() {
    frenel.frenel(1.4999999999999165 ) ;
  }

  @Test
  public void test52() {
    frenel.frenel(1.4999999999999716 ) ;
  }

  @Test
  public void test53() {
    frenel.frenel(1.4999999999999787 ) ;
  }

  @Test
  public void test54() {
    frenel.frenel(1.4999999999999902 ) ;
  }

  @Test
  public void test55() {
    frenel.frenel(1.4999999999999911 ) ;
  }

  @Test
  public void test56() {
    frenel.frenel(1.4999999999999956 ) ;
  }

  @Test
  public void test57() {
    frenel.frenel(1.4999999999999978 ) ;
  }

  @Test
  public void test58() {
    frenel.frenel(1.4999999999999982 ) ;
  }

  @Test
  public void test59() {
    frenel.frenel(1.4999999999999987 ) ;
  }

  @Test
  public void test60() {
    frenel.frenel(1.4999999999999991 ) ;
  }

  @Test
  public void test61() {
    frenel.frenel(1.4999999999999993 ) ;
  }

  @Test
  public void test62() {
    frenel.frenel(1.4999999999999996 ) ;
  }

  @Test
  public void test63() {
    frenel.frenel(1.4999999999999998 ) ;
  }

  @Test
  public void test64() {
    frenel.frenel(1.5 ) ;
  }

  @Test
  public void test65() {
    frenel.frenel(1.61895E-319 ) ;
  }

  @Test
  public void test66() {
    frenel.frenel(16.957698715593736 ) ;
  }

  @Test
  public void test67() {
    frenel.frenel(1.734723475976807E-18 ) ;
  }

  @Test
  public void test68() {
    frenel.frenel(1.9548078935095958 ) ;
  }

  @Test
  public void test69() {
    frenel.frenel(2.220446049250313E-16 ) ;
  }

  @Test
  public void test70() {
    frenel.frenel(-2.465190328815662E-32 ) ;
  }

  @Test
  public void test71() {
    frenel.frenel(2.465190328815662E-32 ) ;
  }

  @Test
  public void test72() {
    frenel.frenel(2.5721556013999987 ) ;
  }

  @Test
  public void test73() {
    frenel.frenel(-2.7122474350927916 ) ;
  }

  @Test
  public void test74() {
    frenel.frenel(-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test75() {
    frenel.frenel(-33.58361142615507 ) ;
  }

  @Test
  public void test76() {
    frenel.frenel(3.8518598887744717E-34 ) ;
  }

  @Test
  public void test77() {
    frenel.frenel(4.440892098500626E-16 ) ;
  }

  @Test
  public void test78() {
    frenel.frenel(4.5569512622227484E-305 ) ;
  }

  @Test
  public void test79() {
    frenel.frenel(6.162975822039155E-33 ) ;
  }

  @Test
  public void test80() {
    frenel.frenel(65.80560818841218 ) ;
  }

  @Test
  public void test81() {
    frenel.frenel(-72.75077699490875 ) ;
  }

  @Test
  public void test82() {
    frenel.frenel(-83.86583539154128 ) ;
  }

  @Test
  public void test83() {
    frenel.frenel(8.881784197001252E-16 ) ;
  }

  @Test
  public void test84() {
    frenel.frenel(8.967066614819785 ) ;
  }

  @Test
  public void test85() {
    frenel.frenel(9.860761315262648E-32 ) ;
  }

  @Test
  public void test86() {
    frenel.frenel(99.04701588510653 ) ;
  }
}
