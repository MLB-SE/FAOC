import org.junit.Test;

public class TestellpiTest {

  @Test
  public void test0() {
    ell.ellpi(-0.8826817359917101,0,-0.44280302074039923 ) ;
  }

  @Test
  public void test1() {
    ell.ellpi(100.0,0,0.5777784418599614 ) ;
  }

  @Test
  public void test2() {
    ell.ellpi(-100.0,0,2.607704841205189 ) ;
  }

  @Test
  public void test3() {
    ell.ellpi(-100.5347208733669,0,3.379017228024423E-5 ) ;
  }

  @Test
  public void test4() {
    ell.ellpi(-12.154291711304484,0,3.386424392259405 ) ;
  }

  @Test
  public void test5() {
    ell.ellpi(-12.566368894050338,0,0.005401908286241916 ) ;
  }

  @Test
  public void test6() {
    ell.ellpi(-12.566370594137002,0,0.8338363210684293 ) ;
  }

  @Test
  public void test7() {
    ell.ellpi(12.566370613404368,0,-13.065086788974895 ) ;
  }

  @Test
  public void test8() {
    ell.ellpi(-12.566370618130135,0,-0.9425020645904378 ) ;
  }

  @Test
  public void test9() {
    ell.ellpi(12.566929156422988,0,-1.0000000003777985 ) ;
  }

  @Test
  public void test10() {
    ell.ellpi(-138.23106475761116,0,1.0000000000056013 ) ;
  }

  @Test
  public void test11() {
    ell.ellpi(-15.70796328242133,0,72.63754820664921 ) ;
  }

  @Test
  public void test12() {
    ell.ellpi(15.780982079668988,0,-13.707278357029315 ) ;
  }

  @Test
  public void test13() {
    ell.ellpi(160.22122530998362,0,-0.5839099399590401 ) ;
  }

  @Test
  public void test14() {
    ell.ellpi(18.848661798006816,0,-0.24297863617394722 ) ;
  }

  @Test
  public void test15() {
    ell.ellpi(18.849521593606053,0,-1.8769204528345466E-4 ) ;
  }

  @Test
  public void test16() {
    ell.ellpi(-18.849555913791846,0,1.0393339738102536 ) ;
  }

  @Test
  public void test17() {
    ell.ellpi(-21.991148592549642,0,0.951189005848633 ) ;
  }

  @Test
  public void test18() {
    ell.ellpi(-25.13274122318123,0,0.2821730647767757 ) ;
  }

  @Test
  public void test19() {
    ell.ellpi(-25.132741240685274,0,-0.8522608310244513 ) ;
  }

  @Test
  public void test20() {
    ell.ellpi(25.290664245713344,0,-6.358596475755242 ) ;
  }

  @Test
  public void test21() {
    ell.ellpi(27.079695845849155,0,-1.075173152372453 ) ;
  }

  @Test
  public void test22() {
    ell.ellpi(-28.273921480941556,0,-3.2485924995364767E-5 ) ;
  }

  @Test
  public void test23() {
    ell.ellpi(28.27433386677818,0,0.3188980645708255 ) ;
  }

  @Test
  public void test24() {
    ell.ellpi(-28.274333871416506,0,1.9272411634278575 ) ;
  }

  @Test
  public void test25() {
    ell.ellpi(-28.274333882477162,0,-15.383229829768526 ) ;
  }

  @Test
  public void test26() {
    ell.ellpi(28.274337458514804,0,-0.004632290529552576 ) ;
  }

  @Test
  public void test27() {
    ell.ellpi(28.58320530294509,0,-2.988131748345836 ) ;
  }

  @Test
  public void test28() {
    ell.ellpi(-30.981949319401878,0,89.67031544470171 ) ;
  }

  @Test
  public void test29() {
    ell.ellpi(-3.1415926468974082,0,-100.0 ) ;
  }

  @Test
  public void test30() {
    ell.ellpi(-31.41592654153747,0,99.27694632595967 ) ;
  }

  @Test
  public void test31() {
    ell.ellpi(-3.1415926592245045,0,-1.580845585577996 ) ;
  }

  @Test
  public void test32() {
    ell.ellpi(3.1415926717174285,0,-0.6632828017779424 ) ;
  }

  @Test
  public void test33() {
    ell.ellpi(31.43373116441489,0,-56.168138253170795 ) ;
  }

  @Test
  public void test34() {
    ell.ellpi(-33.292321096066516,0,1.095014322927531 ) ;
  }

  @Test
  public void test35() {
    ell.ellpi(-34.552740296593754,0,-0.6676200099980036 ) ;
  }

  @Test
  public void test36() {
    ell.ellpi(-34.55751919448837,0,100.0 ) ;
  }

  @Test
  public void test37() {
    ell.ellpi(-37.66710878412837,0,31.25234751106458 ) ;
  }

  @Test
  public void test38() {
    ell.ellpi(-37.69344145279536,0,176.35564910840642 ) ;
  }

  @Test
  public void test39() {
    ell.ellpi(37.6990853452711,0,-2.0508014297386176E-4 ) ;
  }

  @Test
  public void test40() {
    ell.ellpi(-40.178294060758574,0,1.6259652481954936 ) ;
  }

  @Test
  public void test41() {
    ell.ellpi(-40.84070411476451,0,2.4099551204646983 ) ;
  }

  @Test
  public void test42() {
    ell.ellpi(-42.30118118855626,0,1.0166443708220254 ) ;
  }

  @Test
  public void test43() {
    ell.ellpi(43.982286726664924,0,0.001184970757136694 ) ;
  }

  @Test
  public void test44() {
    ell.ellpi(4.71238896984797,0,-1.0000000000000002 ) ;
  }

  @Test
  public void test45() {
    ell.ellpi(47.38446129637211,0,-5.3974051668708505 ) ;
  }

  @Test
  public void test46() {
    ell.ellpi(-48.69491725202683,0,1.0 ) ;
  }

  @Test
  public void test47() {
    ell.ellpi(-49.81786318145879,0,2.3104261420103205 ) ;
  }

  @Test
  public void test48() {
    ell.ellpi(50.2585874369213,0,0.41590804505721835 ) ;
  }

  @Test
  public void test49() {
    ell.ellpi(50.265482396631754,0,0.9728970396789028 ) ;
  }

  @Test
  public void test50() {
    ell.ellpi(50.26548245563967,0,7.270690547641635 ) ;
  }

  @Test
  public void test51() {
    ell.ellpi(-50.265508548179334,0,-2.462232879486617E-4 ) ;
  }

  @Test
  public void test52() {
    ell.ellpi(-53.4070751081861,0,1.817429388136266 ) ;
  }

  @Test
  public void test53() {
    ell.ellpi(-56.54866776899418,0,0.9188908049707124 ) ;
  }

  @Test
  public void test54() {
    ell.ellpi(56.54866776940161,0,0.9853607378621586 ) ;
  }

  @Test
  public void test55() {
    ell.ellpi(-56.548668951239556,0,-0.7060734555586725 ) ;
  }

  @Test
  public void test56() {
    ell.ellpi(58.11946409803795,0,0.9999999999998908 ) ;
  }

  @Test
  public void test57() {
    ell.ellpi(-58.119467872774116,0,1.0000000000070386 ) ;
  }

  @Test
  public void test58() {
    ell.ellpi(-59.68925903674646,0,0.19864346476780526 ) ;
  }

  @Test
  public void test59() {
    ell.ellpi(59.69026041225985,0,2.8107048663712746 ) ;
  }

  @Test
  public void test60() {
    ell.ellpi(-59.69026041458907,0,0.17695234627026935 ) ;
  }

  @Test
  public void test61() {
    ell.ellpi(59.74909294865082,0,17.007208482208647 ) ;
  }

  @Test
  public void test62() {
    ell.ellpi(62.82547529577883,0,-156.79553134180165 ) ;
  }

  @Test
  public void test63() {
    ell.ellpi(62.83185306068431,0,1.7842895524645037 ) ;
  }

  @Test
  public void test64() {
    ell.ellpi(6.2831853069514585,0,65.66773913765986 ) ;
  }

  @Test
  public void test65() {
    ell.ellpi(-62.83185307209969,0,37.633035709462234 ) ;
  }

  @Test
  public void test66() {
    ell.ellpi(62.83185307412942,0,4.710272306587282 ) ;
  }

  @Test
  public void test67() {
    ell.ellpi(62.83185309164036,0,0.8535245388466449 ) ;
  }

  @Test
  public void test68() {
    ell.ellpi(-6.283185323555805,0,-0.637209518840948 ) ;
  }

  @Test
  public void test69() {
    ell.ellpi(-6.2831853384949365,0,1.0078109270474294 ) ;
  }

  @Test
  public void test70() {
    ell.ellpi(64.23366364831092,0,1.0144499744654516 ) ;
  }

  @Test
  public void test71() {
    ell.ellpi(-64.40264939859077,0,1.0 ) ;
  }

  @Test
  public void test72() {
    ell.ellpi(-65.95064733480817,0,0.49966101286341313 ) ;
  }

  @Test
  public void test73() {
    ell.ellpi(-65.97250323351014,0,-9.544407681878649E-4 ) ;
  }

  @Test
  public void test74() {
    ell.ellpi(65.97339365207337,0,0.9999999720354213 ) ;
  }

  @Test
  public void test75() {
    ell.ellpi(-65.97339521255907,0,-1.6875241097326354E-4 ) ;
  }

  @Test
  public void test76() {
    ell.ellpi(65.97344570741035,0,0.5035358251154971 ) ;
  }

  @Test
  public void test77() {
    ell.ellpi(-65.97344579870801,0,0.03328788716782358 ) ;
  }

  @Test
  public void test78() {
    ell.ellpi(-67.54424206271729,0,-1.0 ) ;
  }

  @Test
  public void test79() {
    ell.ellpi(-69.11503838069027,0,-1.4211350036065031 ) ;
  }

  @Test
  public void test80() {
    ell.ellpi(72.18959598599771,0,21.088742399633258 ) ;
  }

  @Test
  public void test81() {
    ell.ellpi(72.25663102915543,0,1.6586982715662455 ) ;
  }

  @Test
  public void test82() {
    ell.ellpi(72.25663103759352,0,-83.00566641742371 ) ;
  }

  @Test
  public void test83() {
    ell.ellpi(72.25663104872778,0,-0.6491737044384883 ) ;
  }

  @Test
  public void test84() {
    ell.ellpi(74.53765834792577,0,0.16318056016604876 ) ;
  }

  @Test
  public void test85() {
    ell.ellpi(-75.39822366814599,0,-0.6852085334203366 ) ;
  }

  @Test
  public void test86() {
    ell.ellpi(75.39822370320672,0,1.1520809614039123 ) ;
  }

  @Test
  public void test87() {
    ell.ellpi(76.96902000726165,0,-0.9999999999999644 ) ;
  }

  @Test
  public void test88() {
    ell.ellpi(76.96902001417698,0,-0.17505515534838467 ) ;
  }

  @Test
  public void test89() {
    ell.ellpi(77.38186346453047,0,-1.0917224950754425 ) ;
  }

  @Test
  public void test90() {
    ell.ellpi(78.53981633437208,0,-0.022898828681080785 ) ;
  }

  @Test
  public void test91() {
    ell.ellpi(-78.5398163479055,0,-1.1564915759186545 ) ;
  }

  @Test
  public void test92() {
    ell.ellpi(78.5398163798043,0,-0.9434541578586052 ) ;
  }

  @Test
  public void test93() {
    ell.ellpi(-78.54804238002069,0,-25.498588609005495 ) ;
  }

  @Test
  public void test94() {
    ell.ellpi(80.11067346216916,0,-1.000000000647473 ) ;
  }

  @Test
  public void test95() {
    ell.ellpi(-81.68140899391793,0,18.11082767151391 ) ;
  }

  @Test
  public void test96() {
    ell.ellpi(-84.82300100944568,0,1.1124096582598466 ) ;
  }

  @Test
  public void test97() {
    ell.ellpi(-84.82300164715463,0,28.146361136181252 ) ;
  }

  @Test
  public void test98() {
    ell.ellpi(84.8287052260979,0,-175.3294539109484 ) ;
  }

  @Test
  public void test99() {
    ell.ellpi(86.39376008226084,0,0.9999997404068027 ) ;
  }

  @Test
  public void test100() {
    ell.ellpi(-86.39379798151651,0,-1.0 ) ;
  }

  @Test
  public void test101() {
    ell.ellpi(-87.94449575137962,0,-0.8398078691799311 ) ;
  }

  @Test
  public void test102() {
    ell.ellpi(-87.96459430516694,0,-41.219944054368106 ) ;
  }

  @Test
  public void test103() {
    ell.ellpi(89.53539062730864,0,1.0 ) ;
  }

  @Test
  public void test104() {
    ell.ellpi(91.1061869578635,0,-4.42277141899107 ) ;
  }

  @Test
  public void test105() {
    ell.ellpi(91.1061869597689,0,-1.173812856422928 ) ;
  }

  @Test
  public void test106() {
    ell.ellpi(91.10618696160292,0,23.23527520859605 ) ;
  }

  @Test
  public void test107() {
    ell.ellpi(-91.10618704029802,0,-0.15307902334591716 ) ;
  }

  @Test
  public void test108() {
    ell.ellpi(92.6769832808989,0,0.9049780952381581 ) ;
  }

  @Test
  public void test109() {
    ell.ellpi(-94.20726155652423,0,-34.898524429349585 ) ;
  }

  @Test
  public void test110() {
    ell.ellpi(-94.2390090653665,0,-114.01949653727787 ) ;
  }

  @Test
  public void test111() {
    ell.ellpi(-9.424777882246723,0,1.0621854735025709 ) ;
  }

  @Test
  public void test112() {
    ell.ellpi(9.424777948475889,0,0.7285801390656439 ) ;
  }

  @Test
  public void test113() {
    ell.ellpi(-94.24777959801236,0,40.31070502223098 ) ;
  }

  @Test
  public void test114() {
    ell.ellpi(94.24777960701671,0,-1.012843766518495 ) ;
  }

  @Test
  public void test115() {
    ell.ellpi(94.24777961181243,0,2.0601196181141312 ) ;
  }

  @Test
  public void test116() {
    ell.ellpi(-9.42477798855372,0,1.0088197220096307 ) ;
  }

  @Test
  public void test117() {
    ell.ellpi(-9.424789572003398,0,-0.0011451697514467118 ) ;
  }

  @Test
  public void test118() {
    ell.ellpi(-9.42702390041627,0,0.9999999999915363 ) ;
  }

  @Test
  public void test119() {
    ell.ellpi(-95.30657163670568,0,1.1456620022890522 ) ;
  }

  @Test
  public void test120() {
    ell.ellpi(9.58506401538993,0,6.26564056539416 ) ;
  }

  @Test
  public void test121() {
    ell.ellpi(96.48573758322249,0,66.89388428467427 ) ;
  }

  @Test
  public void test122() {
    ell.ellpi(97.3893722445414,0,0.5140483333875204 ) ;
  }

  @Test
  public void test123() {
    ell.ellpi(97.38937227222176,0,0.06426685083692973 ) ;
  }

  @Test
  public void test124() {
    ell.ellpi(97.3900407404227,0,1.0000000003187457 ) ;
  }

  @Test
  public void test125() {
    ell.ellpi(-97.48066222441771,0,-70.34607979565403 ) ;
  }

  @Test
  public void test126() {
    ell.ellpi(9.821900876310659,0,-2.5855375724218352 ) ;
  }
}
