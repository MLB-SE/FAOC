import org.junit.Test;

public class TestsncndnTest {

  @Test
  public void test0() {
    ell.sncndn(0,-0.0802939138144847 ) ;
  }

  @Test
  public void test1() {
    ell.sncndn(0,0.5302319270824203 ) ;
  }

  @Test
  public void test2() {
    ell.sncndn(0,-0.6180339887498948 ) ;
  }

  @Test
  public void test3() {
    ell.sncndn(0,0.7521541583724296 ) ;
  }

  @Test
  public void test4() {
    ell.sncndn(0,0.9154939250544665 ) ;
  }

  @Test
  public void test5() {
    ell.sncndn(0,0.9999999392426091 ) ;
  }

  @Test
  public void test6() {
    ell.sncndn(0,0.9999999799958809 ) ;
  }

  @Test
  public void test7() {
    ell.sncndn(0,0.9999999799999999 ) ;
  }

  @Test
  public void test8() {
    ell.sncndn(0,0.99999998 ) ;
  }

  @Test
  public void test9() {
    ell.sncndn(0,0.9999999800562704 ) ;
  }

  @Test
  public void test10() {
    ell.sncndn(0,1.0 ) ;
  }

  @Test
  public void test11() {
    ell.sncndn(0,1.0000000000000002 ) ;
  }

  @Test
  public void test12() {
    ell.sncndn(0,1.000000000148479 ) ;
  }

  @Test
  public void test13() {
    ell.sncndn(0,1.00000002 ) ;
  }

  @Test
  public void test14() {
    ell.sncndn(0,1.0000000200004053 ) ;
  }

  @Test
  public void test15() {
    ell.sncndn(0,1.0000000200229793 ) ;
  }

  @Test
  public void test16() {
    ell.sncndn(0,14.143659650044157 ) ;
  }

  @Test
  public void test17() {
    ell.sncndn(0,17.295084953003823 ) ;
  }

  @Test
  public void test18() {
    ell.sncndn(0,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test19() {
    ell.sncndn(0,2.485160398384508 ) ;
  }

  @Test
  public void test20() {
    ell.sncndn(0,-2641.3989571842894 ) ;
  }

  @Test
  public void test21() {
    ell.sncndn(-0.2675780700732769,1.0000000198562593 ) ;
  }

  @Test
  public void test22() {
    ell.sncndn(0,34.43915766858726 ) ;
  }

  @Test
  public void test23() {
    ell.sncndn(0,3.617786384659553 ) ;
  }

  @Test
  public void test24() {
    ell.sncndn(0,-36.58092758312883 ) ;
  }

  @Test
  public void test25() {
    ell.sncndn(0,-4.1105209761472565 ) ;
  }

  @Test
  public void test26() {
    ell.sncndn(0,54.89248704629165 ) ;
  }

  @Test
  public void test27() {
    ell.sncndn(0,-61.21913117640803 ) ;
  }

  @Test
  public void test28() {
    ell.sncndn(0,-62.22393377299527 ) ;
  }

  @Test
  public void test29() {
    ell.sncndn(0,-69.63774897894396 ) ;
  }

  @Test
  public void test30() {
    ell.sncndn(0,72.34561555315878 ) ;
  }

  @Test
  public void test31() {
    ell.sncndn(0,-7.302323201544112 ) ;
  }

  @Test
  public void test32() {
    ell.sncndn(0,-8.840990677929454 ) ;
  }

  @Test
  public void test33() {
    ell.sncndn(0,93.70542710772 ) ;
  }

  @Test
  public void test34() {
    ell.sncndn(100.0,0.999999986197837 ) ;
  }

  @Test
  public void test35() {
    ell.sncndn(-100.0,1.0000000000000002 ) ;
  }

  @Test
  public void test36() {
    ell.sncndn(-42.494578916852824,1.144941090721152 ) ;
  }

  @Test
  public void test37() {
    ell.sncndn(-49.59945134619291,0.8103201902154102 ) ;
  }

  @Test
  public void test38() {
    ell.sncndn(70.5755047952558,1.0000000039667114 ) ;
  }

  @Test
  public void test39() {
    ell.sncndn(-83.99877257691284,1.0 ) ;
  }

  @Test
  public void test40() {
    ell.sncndn(87.08421811320014,3.0336085263414745 ) ;
  }

  @Test
  public void test41() {
    ell.sncndn(89.0219311566406,0.9999999999999746 ) ;
  }
}
