import org.junit.Test;

public class TestelleTest {

  @Test
  public void test0() {
    ell.elle(0.005609985649404297,-178.25451041013102 ) ;
  }

  @Test
  public void test1() {
    ell.elle(100.0,-0.8088365609509154 ) ;
  }

  @Test
  public void test2() {
    ell.elle(100.0,-0.8138764732436937 ) ;
  }

  @Test
  public void test3() {
    ell.elle(105.24470054802252,0.9912534644830922 ) ;
  }

  @Test
  public void test4() {
    ell.elle(-110.95035329251425,1.3580500968801945 ) ;
  }

  @Test
  public void test5() {
    ell.elle(-11.77003605958026,-0.17569954483001538 ) ;
  }

  @Test
  public void test6() {
    ell.elle(-12.566189414257018,0.9999999996228576 ) ;
  }

  @Test
  public void test7() {
    ell.elle(-12.62511705780203,17.032102095137166 ) ;
  }

  @Test
  public void test8() {
    ell.elle(-1.3664080784902298E-8,23.781992887989233 ) ;
  }

  @Test
  public void test9() {
    ell.elle(144.5180690512401,-1.2294859307543718E-4 ) ;
  }

  @Test
  public void test10() {
    ell.elle(-15.32203109736514,1.3979947081835036 ) ;
  }

  @Test
  public void test11() {
    ell.elle(-15.66597734024397,-17.387731134071018 ) ;
  }

  @Test
  public void test12() {
    ell.elle(-15.707918090061474,1.0000000096457569 ) ;
  }

  @Test
  public void test13() {
    ell.elle(-15.707963204395561,-1.0036688119999317 ) ;
  }

  @Test
  public void test14() {
    ell.elle(-15.707963264972935,3.2339274233856976 ) ;
  }

  @Test
  public void test15() {
    ell.elle(-1.571263170204527,-0.9999999816592303 ) ;
  }

  @Test
  public void test16() {
    ell.elle(16.142984338159195,-0.4677687266372317 ) ;
  }

  @Test
  public void test17() {
    ell.elle(-17.347521474995986,40.40807086023432 ) ;
  }

  @Test
  public void test18() {
    ell.elle(18.849555910407133,-1.5220735977264475 ) ;
  }

  @Test
  public void test19() {
    ell.elle(-18.849555935321593,-0.12704387744985615 ) ;
  }

  @Test
  public void test20() {
    ell.elle(18.84955595292912,0.9235038301868865 ) ;
  }

  @Test
  public void test21() {
    ell.elle(-18.962862718483237,0.3868718796482824 ) ;
  }

  @Test
  public void test22() {
    ell.elle(193.14373133047684,-1.0020654454675377 ) ;
  }

  @Test
  public void test23() {
    ell.elle(-199.2459019793504,-1.0308415947439096 ) ;
  }

  @Test
  public void test24() {
    ell.elle(21.991148560925698,0.049310712601800866 ) ;
  }

  @Test
  public void test25() {
    ell.elle(21.99124349619845,0.876729291391251 ) ;
  }

  @Test
  public void test26() {
    ell.elle(25.12856707752965,239.57031380609027 ) ;
  }

  @Test
  public void test27() {
    ell.elle(-25.13274091021979,1.000530049392568 ) ;
  }

  @Test
  public void test28() {
    ell.elle(25.132741112274,-0.9980809912998341 ) ;
  }

  @Test
  public void test29() {
    ell.elle(25.13274121771941,-1.3327623386219378 ) ;
  }

  @Test
  public void test30() {
    ell.elle(-25.132741240010972,1.216685468819438 ) ;
  }

  @Test
  public void test31() {
    ell.elle(25.155097705470578,44.73349347260989 ) ;
  }

  @Test
  public void test32() {
    ell.elle(254.46900494333042,-14.964848304312298 ) ;
  }

  @Test
  public void test33() {
    ell.elle(-26.172564455506834,1.1596693968062854 ) ;
  }

  @Test
  public void test34() {
    ell.elle(26.674996783945133,1.0004074240925978 ) ;
  }

  @Test
  public void test35() {
    ell.elle(28.27433387015133,-0.38063508700924586 ) ;
  }

  @Test
  public void test36() {
    ell.elle(-28.274333897309653,-0.8342739738093963 ) ;
  }

  @Test
  public void test37() {
    ell.elle(-28.283811780175576,2.0693508778097964 ) ;
  }

  @Test
  public void test38() {
    ell.elle(-290.5216339920913,1.0057339498059332 ) ;
  }

  @Test
  public void test39() {
    ell.elle(29.845130209103036,1.0 ) ;
  }

  @Test
  public void test40() {
    ell.elle(-3.138945352824467,3.2962184775409626E-6 ) ;
  }

  @Test
  public void test41() {
    ell.elle(-3.1415926539219856,49.5738118080672 ) ;
  }

  @Test
  public void test42() {
    ell.elle(31.415927101867613,-0.6109350519315058 ) ;
  }

  @Test
  public void test43() {
    ell.elle(31.41601427712053,-0.9999999875915844 ) ;
  }

  @Test
  public void test44() {
    ell.elle(3.141678323710344,-1.0000000030667955 ) ;
  }

  @Test
  public void test45() {
    ell.elle(31.4368948430183,47.69451707928999 ) ;
  }

  @Test
  public void test46() {
    ell.elle(34.540232835597244,-8.130625448968067E-7 ) ;
  }

  @Test
  public void test47() {
    ell.elle(34.557176803595404,0.9999999998081662 ) ;
  }

  @Test
  public void test48() {
    ell.elle(-34.55751917996054,-33.19230938553568 ) ;
  }

  @Test
  public void test49() {
    ell.elle(34.55751920280727,0.6631640043066973 ) ;
  }

  @Test
  public void test50() {
    ell.elle(36.24249995173335,44.43677751069475 ) ;
  }

  @Test
  public void test51() {
    ell.elle(-37.69910602022076,0.0017892073157563682 ) ;
  }

  @Test
  public void test52() {
    ell.elle(-37.69911182544301,-1.0170864951341436 ) ;
  }

  @Test
  public void test53() {
    ell.elle(-37.699111832011,1.3695950297804824 ) ;
  }

  @Test
  public void test54() {
    ell.elle(37.699111841752824,12.070267961990112 ) ;
  }

  @Test
  public void test55() {
    ell.elle(-37.69911184313924,86.3304057261767 ) ;
  }

  @Test
  public void test56() {
    ell.elle(-39.269908169872416,-0.46626428649631857 ) ;
  }

  @Test
  public void test57() {
    ell.elle(-40.43665012820547,2.543561982891439 ) ;
  }

  @Test
  public void test58() {
    ell.elle(40.84070449472274,7.843149593544808 ) ;
  }

  @Test
  public void test59() {
    ell.elle(-40.840704496431925,100.0 ) ;
  }

  @Test
  public void test60() {
    ell.elle(40.840704519282816,-1.094501960642404 ) ;
  }

  @Test
  public void test61() {
    ell.elle(-42.41150081334743,1.0000000000000002 ) ;
  }

  @Test
  public void test62() {
    ell.elle(44.00300849657074,-48.28616555122604 ) ;
  }

  @Test
  public void test63() {
    ell.elle(-46.29916304388028,-1.6457842929330901 ) ;
  }

  @Test
  public void test64() {
    ell.elle(-47.11270784855032,89.43166138074213 ) ;
  }

  @Test
  public void test65() {
    ell.elle(47.12388776220588,-0.999991352333347 ) ;
  }

  @Test
  public void test66() {
    ell.elle(47.123889894598385,3.4867833660965957 ) ;
  }

  @Test
  public void test67() {
    ell.elle(49.085262986261,-1.1572116734362006 ) ;
  }

  @Test
  public void test68() {
    ell.elle(50.26548245814632,15.800847884415916 ) ;
  }

  @Test
  public void test69() {
    ell.elle(50.26548246647786,-100.0 ) ;
  }

  @Test
  public void test70() {
    ell.elle(53.40707512134973,-13.528272648728933 ) ;
  }

  @Test
  public void test71() {
    ell.elle(-53.442939754904614,-20.880389309608688 ) ;
  }

  @Test
  public void test72() {
    ell.elle(56.715239616900064,-6.031267366754215 ) ;
  }

  @Test
  public void test73() {
    ell.elle(57.024384314743656,2.1835226672666392 ) ;
  }

  @Test
  public void test74() {
    ell.elle(-58.11946408755001,-0.0305171144012593 ) ;
  }

  @Test
  public void test75() {
    ell.elle(-59.54606590542464,6.95916750264882 ) ;
  }

  @Test
  public void test76() {
    ell.elle(-59.690251764809126,-0.09653810645205091 ) ;
  }

  @Test
  public void test77() {
    ell.elle(59.69026032088024,-0.12331518210727249 ) ;
  }

  @Test
  public void test78() {
    ell.elle(59.69026040676531,0.4938059908364707 ) ;
  }

  @Test
  public void test79() {
    ell.elle(59.690260413255025,2.848928479904899 ) ;
  }

  @Test
  public void test80() {
    ell.elle(-59.690260429882294,1.2036933014175648 ) ;
  }

  @Test
  public void test81() {
    ell.elle(60.739697334123086,-1.288331435615973 ) ;
  }

  @Test
  public void test82() {
    ell.elle(-61.26105674500097,-1.0 ) ;
  }

  @Test
  public void test83() {
    ell.elle(-62.679351820118015,-0.9999999999999983 ) ;
  }

  @Test
  public void test84() {
    ell.elle(-62.831775492439014,1.5267636480083944E-4 ) ;
  }

  @Test
  public void test85() {
    ell.elle(-62.831852887119865,-0.05135381343203704 ) ;
  }

  @Test
  public void test86() {
    ell.elle(62.83185306540718,5.41125340414392 ) ;
  }

  @Test
  public void test87() {
    ell.elle(62.83185307393171,4.608771128236956 ) ;
  }

  @Test
  public void test88() {
    ell.elle(-62.83185308855593,23.625071887659885 ) ;
  }

  @Test
  public void test89() {
    ell.elle(62.856682611730974,40.278747049422456 ) ;
  }

  @Test
  public void test90() {
    ell.elle(6.325199232683562,-13.79183422133585 ) ;
  }

  @Test
  public void test91() {
    ell.elle(-65.97344571173356,-69.806979628381 ) ;
  }

  @Test
  public void test92() {
    ell.elle(65.9734457183242,-12.32952240312491 ) ;
  }

  @Test
  public void test93() {
    ell.elle(-65.97344572527618,98.86870397900208 ) ;
  }

  @Test
  public void test94() {
    ell.elle(-65.97369700261964,-0.9999999997765222 ) ;
  }

  @Test
  public void test95() {
    ell.elle(65.97491673646988,1.0000000000071985 ) ;
  }

  @Test
  public void test96() {
    ell.elle(-65.9838055374631,-96.52857410602554 ) ;
  }

  @Test
  public void test97() {
    ell.elle(67.54424205218055,-0.9999999999999999 ) ;
  }

  @Test
  public void test98() {
    ell.elle(-69.11494506667002,6.897672801052862E-5 ) ;
  }

  @Test
  public void test99() {
    ell.elle(-70.87693435676836,-0.5114788573752307 ) ;
  }

  @Test
  public void test100() {
    ell.elle(72.07045230576321,1.2458484191087962 ) ;
  }

  @Test
  public void test101() {
    ell.elle(72.25663097736441,-1.0340319702886758 ) ;
  }

  @Test
  public void test102() {
    ell.elle(-72.25663102196077,21.867847972052804 ) ;
  }

  @Test
  public void test103() {
    ell.elle(75.39822372850483,0.9579951462386015 ) ;
  }

  @Test
  public void test104() {
    ell.elle(78.53977942707186,-3.255702905892209E-4 ) ;
  }

  @Test
  public void test105() {
    ell.elle(78.53981632858498,-40.08143807720181 ) ;
  }

  @Test
  public void test106() {
    ell.elle(7.948887045295791,-0.16721150527349948 ) ;
  }

  @Test
  public void test107() {
    ell.elle(-80.28208335708102,1.390010845216949 ) ;
  }

  @Test
  public void test108() {
    ell.elle(-81.6080764334578,19.27630814879523 ) ;
  }

  @Test
  public void test109() {
    ell.elle(-84.82295993398648,-1.0419975774622083E-4 ) ;
  }

  @Test
  public void test110() {
    ell.elle(87.95822813355477,-157.08145279305538 ) ;
  }

  @Test
  public void test111() {
    ell.elle(87.96428364295252,4.633715278397712E-5 ) ;
  }

  @Test
  public void test112() {
    ell.elle(-87.96458220270269,6.631369016253498E-4 ) ;
  }

  @Test
  public void test113() {
    ell.elle(87.96459420287464,0.6359071864897811 ) ;
  }

  @Test
  public void test114() {
    ell.elle(87.98726905382348,62.36685187911473 ) ;
  }

  @Test
  public void test115() {
    ell.elle(-91.02580113832973,-12.453413363134251 ) ;
  }

  @Test
  public void test116() {
    ell.elle(-91.10618695608086,-57.80302875980461 ) ;
  }

  @Test
  public void test117() {
    ell.elle(-91.10618696548633,28.901821485580687 ) ;
  }

  @Test
  public void test118() {
    ell.elle(91.13102210492184,-40.26964894177515 ) ;
  }

  @Test
  public void test119() {
    ell.elle(-9.424777941557013,-1.0434217128415013 ) ;
  }

  @Test
  public void test120() {
    ell.elle(-94.37875365696004,-0.732455578863827 ) ;
  }

  @Test
  public void test121() {
    ell.elle(97.39862621549167,108.06345593112903 ) ;
  }
}
