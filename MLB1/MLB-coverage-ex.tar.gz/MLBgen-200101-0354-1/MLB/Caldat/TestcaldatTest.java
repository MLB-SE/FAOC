import org.junit.Test;

public class TestcaldatTest {

  @Test
  public void test0() {
    caldat.caldat(0 ) ;
  }

  @Test
  public void test1() {
    caldat.caldat(-1 ) ;
  }

  @Test
  public void test2() {
    caldat.caldat(10838 ) ;
  }

  @Test
  public void test3() {
    caldat.caldat(-119 ) ;
  }

  @Test
  public void test4() {
    caldat.caldat(-196 ) ;
  }

  @Test
  public void test5() {
    caldat.caldat(-2 ) ;
  }

  @Test
  public void test6() {
    caldat.caldat(21 ) ;
  }

  @Test
  public void test7() {
    caldat.caldat(26178 ) ;
  }

  @Test
  public void test8() {
    caldat.caldat(268 ) ;
  }

  @Test
  public void test9() {
    caldat.caldat(-329 ) ;
  }

  @Test
  public void test10() {
    caldat.caldat(-348 ) ;
  }

  @Test
  public void test11() {
    caldat.caldat(-349 ) ;
  }

  @Test
  public void test12() {
    caldat.caldat(-393 ) ;
  }

  @Test
  public void test13() {
    caldat.caldat(42 ) ;
  }

  @Test
  public void test14() {
    caldat.caldat(429 ) ;
  }

  @Test
  public void test15() {
    caldat.caldat(-44 ) ;
  }

  @Test
  public void test16() {
    caldat.caldat(453 ) ;
  }

  @Test
  public void test17() {
    caldat.caldat(547 ) ;
  }

  @Test
  public void test18() {
    caldat.caldat(57 ) ;
  }

  @Test
  public void test19() {
    caldat.caldat(595 ) ;
  }

  @Test
  public void test20() {
    caldat.caldat(6244 ) ;
  }

  @Test
  public void test21() {
    caldat.caldat(-653 ) ;
  }

  @Test
  public void test22() {
    caldat.caldat(-686 ) ;
  }

  @Test
  public void test23() {
    caldat.caldat(7 ) ;
  }

  @Test
  public void test24() {
    caldat.caldat(-715 ) ;
  }

  @Test
  public void test25() {
    caldat.caldat(-728 ) ;
  }

  @Test
  public void test26() {
    caldat.caldat(785 ) ;
  }

  @Test
  public void test27() {
    caldat.caldat(894 ) ;
  }

  @Test
  public void test28() {
    caldat.caldat(-905 ) ;
  }

  @Test
  public void test29() {
    caldat.caldat(-971 ) ;
  }
}
