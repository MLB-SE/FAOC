import org.junit.Test;

public class TestjuldayTest {

  @Test
  public void test0() {
    caldat.julday(0,0,0 ) ;
  }

  @Test
  public void test1() {
    caldat.julday(0,0,-1 ) ;
  }

  @Test
  public void test2() {
    caldat.julday(0,0,469 ) ;
  }

  @Test
  public void test3() {
    caldat.julday(0,0,-562 ) ;
  }

  @Test
  public void test4() {
    caldat.julday(0,0,-713 ) ;
  }

  @Test
  public void test5() {
    caldat.julday(0,0,730 ) ;
  }

  @Test
  public void test6() {
    caldat.julday(-1,0,-292 ) ;
  }

  @Test
  public void test7() {
    caldat.julday(-1,0,-814 ) ;
  }

  @Test
  public void test8() {
    caldat.julday(-112,0,465 ) ;
  }

  @Test
  public void test9() {
    caldat.julday(-11,716,1798 ) ;
  }

  @Test
  public void test10() {
    caldat.julday(-12,0,159 ) ;
  }

  @Test
  public void test11() {
    caldat.julday(-1,22587,0 ) ;
  }

  @Test
  public void test12() {
    caldat.julday(129,0,148 ) ;
  }

  @Test
  public void test13() {
    caldat.julday(-13,0,0 ) ;
  }

  @Test
  public void test14() {
    caldat.julday(13,0,0 ) ;
  }

  @Test
  public void test15() {
    caldat.julday(-13,0,111 ) ;
  }

  @Test
  public void test16() {
    caldat.julday(-13,0,-204 ) ;
  }

  @Test
  public void test17() {
    caldat.julday(-13,0,-417 ) ;
  }

  @Test
  public void test18() {
    caldat.julday(-13,0,777 ) ;
  }

  @Test
  public void test19() {
    caldat.julday(131,0,-509 ) ;
  }

  @Test
  public void test20() {
    caldat.julday(-13,1297,2122 ) ;
  }

  @Test
  public void test21() {
    caldat.julday(-13,-1362,-940 ) ;
  }

  @Test
  public void test22() {
    caldat.julday(-13,1396,-898 ) ;
  }

  @Test
  public void test23() {
    caldat.julday(-13,17271,4 ) ;
  }

  @Test
  public void test24() {
    caldat.julday(-13,-518,1629 ) ;
  }

  @Test
  public void test25() {
    caldat.julday(-13,575,957 ) ;
  }

  @Test
  public void test26() {
    caldat.julday(-13,-576,0 ) ;
  }

  @Test
  public void test27() {
    caldat.julday(-1,-4,2317 ) ;
  }

  @Test
  public void test28() {
    caldat.julday(-16,17967,-20 ) ;
  }

  @Test
  public void test29() {
    caldat.julday(1637,1134,1736 ) ;
  }

  @Test
  public void test30() {
    caldat.julday(-17,0,481 ) ;
  }

  @Test
  public void test31() {
    caldat.julday(-181,-922,-766 ) ;
  }

  @Test
  public void test32() {
    caldat.julday(19176,-60,0 ) ;
  }

  @Test
  public void test33() {
    caldat.julday(-19,20493,0 ) ;
  }

  @Test
  public void test34() {
    caldat.julday(19339,1479,-3 ) ;
  }

  @Test
  public void test35() {
    caldat.julday(1,95,905 ) ;
  }

  @Test
  public void test36() {
    caldat.julday(-2,0,0 ) ;
  }

  @Test
  public void test37() {
    caldat.julday(-2,0,1373 ) ;
  }

  @Test
  public void test38() {
    caldat.julday(-2,0,-198 ) ;
  }

  @Test
  public void test39() {
    caldat.julday(-2,0,-441 ) ;
  }

  @Test
  public void test40() {
    caldat.julday(-2,0,572 ) ;
  }

  @Test
  public void test41() {
    caldat.julday(21118,-1459,-153 ) ;
  }

  @Test
  public void test42() {
    caldat.julday(215,0,679 ) ;
  }

  @Test
  public void test43() {
    caldat.julday(215,48,986 ) ;
  }

  @Test
  public void test44() {
    caldat.julday(-219,0,0 ) ;
  }

  @Test
  public void test45() {
    caldat.julday(2,-21,0 ) ;
  }

  @Test
  public void test46() {
    caldat.julday(-23,14006,-2 ) ;
  }

  @Test
  public void test47() {
    caldat.julday(-23,15653,0 ) ;
  }

  @Test
  public void test48() {
    caldat.julday(-261,0,1 ) ;
  }

  @Test
  public void test49() {
    caldat.julday(276,0,-404 ) ;
  }

  @Test
  public void test50() {
    caldat.julday(-277,0,-16 ) ;
  }

  @Test
  public void test51() {
    caldat.julday(-312,0,642 ) ;
  }

  @Test
  public void test52() {
    caldat.julday(312,271,-549 ) ;
  }

  @Test
  public void test53() {
    caldat.julday(-3,14985,-48 ) ;
  }

  @Test
  public void test54() {
    caldat.julday(-329,0,2 ) ;
  }

  @Test
  public void test55() {
    caldat.julday(-34,20386,-1 ) ;
  }

  @Test
  public void test56() {
    caldat.julday(-350,815,61 ) ;
  }

  @Test
  public void test57() {
    caldat.julday(-36,0,-1 ) ;
  }

  @Test
  public void test58() {
    caldat.julday(370,0,1 ) ;
  }

  @Test
  public void test59() {
    caldat.julday(-371,0,753 ) ;
  }

  @Test
  public void test60() {
    caldat.julday(-381,0,-559 ) ;
  }

  @Test
  public void test61() {
    caldat.julday(388,0,-563 ) ;
  }

  @Test
  public void test62() {
    caldat.julday(4,0,0 ) ;
  }

  @Test
  public void test63() {
    caldat.julday(4,0,1160 ) ;
  }

  @Test
  public void test64() {
    caldat.julday(4,0,131 ) ;
  }

  @Test
  public void test65() {
    caldat.julday(4,0,-397 ) ;
  }

  @Test
  public void test66() {
    caldat.julday(4,0,-674 ) ;
  }

  @Test
  public void test67() {
    caldat.julday(-426,0,0 ) ;
  }

  @Test
  public void test68() {
    caldat.julday(-491,0,0 ) ;
  }

  @Test
  public void test69() {
    caldat.julday(-508,387,0 ) ;
  }

  @Test
  public void test70() {
    caldat.julday(-5,1079,350 ) ;
  }

  @Test
  public void test71() {
    caldat.julday(516,0,-1 ) ;
  }

  @Test
  public void test72() {
    caldat.julday(-52,0,395 ) ;
  }

  @Test
  public void test73() {
    caldat.julday(-53,560,294 ) ;
  }

  @Test
  public void test74() {
    caldat.julday(536,0,-1 ) ;
  }

  @Test
  public void test75() {
    caldat.julday(-5,-378,-148 ) ;
  }

  @Test
  public void test76() {
    caldat.julday(573,0,615 ) ;
  }

  @Test
  public void test77() {
    caldat.julday(574,0,-57 ) ;
  }

  @Test
  public void test78() {
    caldat.julday(58,0,1 ) ;
  }

  @Test
  public void test79() {
    caldat.julday(580,387,-486 ) ;
  }

  @Test
  public void test80() {
    caldat.julday(-599,559,-736 ) ;
  }

  @Test
  public void test81() {
    caldat.julday(-6,0,0 ) ;
  }

  @Test
  public void test82() {
    caldat.julday(611,0,0 ) ;
  }

  @Test
  public void test83() {
    caldat.julday(618,0,-734 ) ;
  }

  @Test
  public void test84() {
    caldat.julday(-6,20252,-7 ) ;
  }

  @Test
  public void test85() {
    caldat.julday(623,0,0 ) ;
  }

  @Test
  public void test86() {
    caldat.julday(-638,0,-479 ) ;
  }

  @Test
  public void test87() {
    caldat.julday(-6,-609,-53 ) ;
  }

  @Test
  public void test88() {
    caldat.julday(-67,0,-320 ) ;
  }

  @Test
  public void test89() {
    caldat.julday(-671,947,2233 ) ;
  }

  @Test
  public void test90() {
    caldat.julday(673,0,126 ) ;
  }

  @Test
  public void test91() {
    caldat.julday(677,-970,1921 ) ;
  }

  @Test
  public void test92() {
    caldat.julday(-737,0,1 ) ;
  }

  @Test
  public void test93() {
    caldat.julday(754,0,236 ) ;
  }

  @Test
  public void test94() {
    caldat.julday(-819,880,1786 ) ;
  }

  @Test
  public void test95() {
    caldat.julday(-861,-90,408 ) ;
  }

  @Test
  public void test96() {
    caldat.julday(867,116,828 ) ;
  }

  @Test
  public void test97() {
    caldat.julday(-89,0,-557 ) ;
  }

  @Test
  public void test98() {
    caldat.julday(960,187,0 ) ;
  }
}
