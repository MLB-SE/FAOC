import org.junit.Test;

public class TestbnldevTest {

  @Test
  public void test0() {
    dev.bnldev(0.0,32,0 ) ;
  }

  @Test
  public void test1() {
    dev.bnldev(0.0,553,0 ) ;
  }

  @Test
  public void test2() {
    dev.bnldev(1.0,184,0 ) ;
  }

  @Test
  public void test3() {
    dev.bnldev(1.0,-189,0 ) ;
  }

  @Test
  public void test4() {
    dev.bnldev(1.0,200,401 ) ;
  }

  @Test
  public void test5() {
    dev.bnldev(1.0,-240,0 ) ;
  }

  @Test
  public void test6() {
    dev.bnldev(1.0,532,852 ) ;
  }

  @Test
  public void test7() {
    dev.bnldev(1.0,72,0 ) ;
  }

  @Test
  public void test8() {
    dev.bnldev(1.0,764,162 ) ;
  }

  @Test
  public void test9() {
    dev.bnldev(-153.0,-504,0 ) ;
  }

  @Test
  public void test10() {
    dev.bnldev(-156.0,16,582 ) ;
  }

  @Test
  public void test11() {
    dev.bnldev(161.0,951,30 ) ;
  }

  @Test
  public void test12() {
    dev.bnldev(-185.0,22,0 ) ;
  }

  @Test
  public void test13() {
    dev.bnldev(191.0,848,-963 ) ;
  }

  @Test
  public void test14() {
    dev.bnldev(217.0,595,179 ) ;
  }

  @Test
  public void test15() {
    dev.bnldev(-235.0,473,394 ) ;
  }

  @Test
  public void test16() {
    dev.bnldev(-235.0,552,196 ) ;
  }

  @Test
  public void test17() {
    dev.bnldev(240.0,25,642 ) ;
  }

  @Test
  public void test18() {
    dev.bnldev(247.0,426,0 ) ;
  }

  @Test
  public void test19() {
    dev.bnldev(256.0,176,0 ) ;
  }

  @Test
  public void test20() {
    dev.bnldev(-26.0,27,3 ) ;
  }

  @Test
  public void test21() {
    dev.bnldev(30.58969712935979,0,0 ) ;
  }

  @Test
  public void test22() {
    dev.bnldev(351.0,12,0 ) ;
  }

  @Test
  public void test23() {
    dev.bnldev(363.0,25,0 ) ;
  }

  @Test
  public void test24() {
    dev.bnldev(-377.0,827,0 ) ;
  }

  @Test
  public void test25() {
    dev.bnldev(38.0,-226,665 ) ;
  }

  @Test
  public void test26() {
    dev.bnldev(381.0,24,262 ) ;
  }

  @Test
  public void test27() {
    dev.bnldev(-383.0,434,0 ) ;
  }

  @Test
  public void test28() {
    dev.bnldev(-397.0,215,-971 ) ;
  }

  @Test
  public void test29() {
    dev.bnldev(-398.0,-644,0 ) ;
  }

  @Test
  public void test30() {
    dev.bnldev(404.0,820,540 ) ;
  }

  @Test
  public void test31() {
    dev.bnldev(414.0,571,0 ) ;
  }

  @Test
  public void test32() {
    dev.bnldev(-435.0,-380,752 ) ;
  }

  @Test
  public void test33() {
    dev.bnldev(4.821627322439042,0,0 ) ;
  }

  @Test
  public void test34() {
    dev.bnldev(-494.0,661,-824 ) ;
  }

  @Test
  public void test35() {
    dev.bnldev(-498.0,677,589 ) ;
  }

  @Test
  public void test36() {
    dev.bnldev(-504.0,25,0 ) ;
  }

  @Test
  public void test37() {
    dev.bnldev(524.0,974,-447 ) ;
  }

  @Test
  public void test38() {
    dev.bnldev(530.0,264,0 ) ;
  }

  @Test
  public void test39() {
    dev.bnldev(539.0,-439,0 ) ;
  }

  @Test
  public void test40() {
    dev.bnldev(-58.20701929482111,0,0 ) ;
  }

  @Test
  public void test41() {
    dev.bnldev(-592.0,365,0 ) ;
  }

  @Test
  public void test42() {
    dev.bnldev(-599.0,156,48 ) ;
  }

  @Test
  public void test43() {
    dev.bnldev(-640.0,368,760 ) ;
  }

  @Test
  public void test44() {
    dev.bnldev(727.0,-529,0 ) ;
  }

  @Test
  public void test45() {
    dev.bnldev(-738.0,25,15 ) ;
  }

  @Test
  public void test46() {
    dev.bnldev(758.0,8,-696 ) ;
  }

  @Test
  public void test47() {
    dev.bnldev(783.0,210,-1 ) ;
  }

  @Test
  public void test48() {
    dev.bnldev(-810.0,15,-258 ) ;
  }

  @Test
  public void test49() {
    dev.bnldev(-815.0,379,72 ) ;
  }

  @Test
  public void test50() {
    dev.bnldev(-837.0,-665,0 ) ;
  }

  @Test
  public void test51() {
    dev.bnldev(871.0,680,713 ) ;
  }

  @Test
  public void test52() {
    dev.bnldev(-872.0,396,-1 ) ;
  }

  @Test
  public void test53() {
    dev.bnldev(-889.0,-857,0 ) ;
  }

  @Test
  public void test54() {
    dev.bnldev(-912.0,779,0 ) ;
  }

  @Test
  public void test55() {
    dev.bnldev(930.0,573,791 ) ;
  }

  @Test
  public void test56() {
    dev.bnldev(-936.0,-995,0 ) ;
  }

  @Test
  public void test57() {
    dev.bnldev(941.0,7,0 ) ;
  }

  @Test
  public void test58() {
    dev.bnldev(-964.0,646,638 ) ;
  }
}
