import org.junit.Test;

public class Testran3Test {

  @Test
  public void test0() {
    ran.ran3(0 ) ;
  }

  @Test
  public void test1() {
    ran.ran3(10 ) ;
  }

  @Test
  public void test2() {
    ran.ran3(11126 ) ;
  }

  @Test
  public void test3() {
    ran.ran3(182 ) ;
  }

  @Test
  public void test4() {
    ran.ran3(208 ) ;
  }

  @Test
  public void test5() {
    ran.ran3(26030 ) ;
  }

  @Test
  public void test6() {
    ran.ran3(26146 ) ;
  }

  @Test
  public void test7() {
    ran.ran3(26163 ) ;
  }

  @Test
  public void test8() {
    ran.ran3(26263 ) ;
  }

  @Test
  public void test9() {
    ran.ran3(26347 ) ;
  }

  @Test
  public void test10() {
    ran.ran3(26367 ) ;
  }

  @Test
  public void test11() {
    ran.ran3(26413 ) ;
  }

  @Test
  public void test12() {
    ran.ran3(26433 ) ;
  }

  @Test
  public void test13() {
    ran.ran3(26448 ) ;
  }

  @Test
  public void test14() {
    ran.ran3(27081 ) ;
  }

  @Test
  public void test15() {
    ran.ran3(27209 ) ;
  }

  @Test
  public void test16() {
    ran.ran3(27259 ) ;
  }

  @Test
  public void test17() {
    ran.ran3(27271 ) ;
  }

  @Test
  public void test18() {
    ran.ran3(302 ) ;
  }

  @Test
  public void test19() {
    ran.ran3(304 ) ;
  }

  @Test
  public void test20() {
    ran.ran3(320 ) ;
  }

  @Test
  public void test21() {
    ran.ran3(360 ) ;
  }

  @Test
  public void test22() {
    ran.ran3(369 ) ;
  }

  @Test
  public void test23() {
    ran.ran3(3996 ) ;
  }

  @Test
  public void test24() {
    ran.ran3(482 ) ;
  }

  @Test
  public void test25() {
    ran.ran3(50 ) ;
  }

  @Test
  public void test26() {
    ran.ran3(542 ) ;
  }

  @Test
  public void test27() {
    ran.ran3(57 ) ;
  }

  @Test
  public void test28() {
    ran.ran3(609 ) ;
  }

  @Test
  public void test29() {
    ran.ran3(661 ) ;
  }

  @Test
  public void test30() {
    ran.ran3(683 ) ;
  }

  @Test
  public void test31() {
    ran.ran3(708 ) ;
  }

  @Test
  public void test32() {
    ran.ran3(750 ) ;
  }

  @Test
  public void test33() {
    ran.ran3(756 ) ;
  }

  @Test
  public void test34() {
    ran.ran3(772 ) ;
  }

  @Test
  public void test35() {
    ran.ran3(795 ) ;
  }

  @Test
  public void test36() {
    ran.ran3(809 ) ;
  }

  @Test
  public void test37() {
    ran.ran3(-886 ) ;
  }

  @Test
  public void test38() {
    ran.ran3(9202 ) ;
  }

  @Test
  public void test39() {
    ran.ran3(9213 ) ;
  }

  @Test
  public void test40() {
    ran.ran3(9263 ) ;
  }

  @Test
  public void test41() {
    ran.ran3(938 ) ;
  }

  @Test
  public void test42() {
    ran.ran3(9399 ) ;
  }

  @Test
  public void test43() {
    ran.ran3(9479 ) ;
  }

  @Test
  public void test44() {
    ran.ran3(965 ) ;
  }

  @Test
  public void test45() {
    ran.ran3(976 ) ;
  }
}
