import org.junit.Test;

public class Testran2Test {

  @Test
  public void test0() {
    ran.ran2(0 ) ;
  }

  @Test
  public void test1() {
    ran.ran2(-1 ) ;
  }

  @Test
  public void test2() {
    ran.ran2(1 ) ;
  }

  @Test
  public void test3() {
    ran.ran2(-185 ) ;
  }

  @Test
  public void test4() {
    ran.ran2(-283 ) ;
  }

  @Test
  public void test5() {
    ran.ran2(3 ) ;
  }

  @Test
  public void test6() {
    ran.ran2(354 ) ;
  }

  @Test
  public void test7() {
    ran.ran2(-38 ) ;
  }

  @Test
  public void test8() {
    ran.ran2(-466 ) ;
  }

  @Test
  public void test9() {
    ran.ran2(-501 ) ;
  }

  @Test
  public void test10() {
    ran.ran2(-523 ) ;
  }

  @Test
  public void test11() {
    ran.ran2(-566 ) ;
  }

  @Test
  public void test12() {
    ran.ran2(-664 ) ;
  }

  @Test
  public void test13() {
    ran.ran2(-735 ) ;
  }

  @Test
  public void test14() {
    ran.ran2(816 ) ;
  }
}
