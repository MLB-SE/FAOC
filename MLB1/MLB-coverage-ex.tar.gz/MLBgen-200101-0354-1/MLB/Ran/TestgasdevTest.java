import org.junit.Test;

public class TestgasdevTest {

  @Test
  public void test0() {
    dev.gasdev(0 ) ;
  }

  @Test
  public void test1() {
    dev.gasdev(-1 ) ;
  }

  @Test
  public void test2() {
    dev.gasdev(1 ) ;
  }

  @Test
  public void test3() {
    dev.gasdev(-221 ) ;
  }

  @Test
  public void test4() {
    dev.gasdev(-252 ) ;
  }

  @Test
  public void test5() {
    dev.gasdev(-266 ) ;
  }

  @Test
  public void test6() {
    dev.gasdev(-391 ) ;
  }

  @Test
  public void test7() {
    dev.gasdev(-407 ) ;
  }

  @Test
  public void test8() {
    dev.gasdev(-446 ) ;
  }

  @Test
  public void test9() {
    dev.gasdev(-532 ) ;
  }

  @Test
  public void test10() {
    dev.gasdev(-577 ) ;
  }

  @Test
  public void test11() {
    dev.gasdev(-592 ) ;
  }

  @Test
  public void test12() {
    dev.gasdev(-631 ) ;
  }

  @Test
  public void test13() {
    dev.gasdev(-757 ) ;
  }

  @Test
  public void test14() {
    dev.gasdev(-802 ) ;
  }

  @Test
  public void test15() {
    dev.gasdev(-847 ) ;
  }

  @Test
  public void test16() {
    dev.gasdev(92 ) ;
  }

  @Test
  public void test17() {
    dev.gasdev(-976 ) ;
  }
}
