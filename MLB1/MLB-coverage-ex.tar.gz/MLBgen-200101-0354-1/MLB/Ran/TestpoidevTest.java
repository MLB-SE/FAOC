import org.junit.Test;

public class TestpoidevTest {

  @Test
  public void test0() {
    dev.poidev(0.0,579 ) ;
  }

  @Test
  public void test1() {
    dev.poidev(0.2730266886122905,0 ) ;
  }

  @Test
  public void test2() {
    dev.poidev(-1.0,0 ) ;
  }

  @Test
  public void test3() {
    dev.poidev(-1.0000000000000009,0 ) ;
  }

  @Test
  public void test4() {
    dev.poidev(10.0,-174 ) ;
  }

  @Test
  public void test5() {
    dev.poidev(-1.0,-1 ) ;
  }

  @Test
  public void test6() {
    dev.poidev(-1.0,-110 ) ;
  }

  @Test
  public void test7() {
    dev.poidev(-1.0,110 ) ;
  }

  @Test
  public void test8() {
    dev.poidev(-1.0,181 ) ;
  }

  @Test
  public void test9() {
    dev.poidev(-1.0,-714 ) ;
  }

  @Test
  public void test10() {
    dev.poidev(14.339891115648285,0 ) ;
  }

  @Test
  public void test11() {
    dev.poidev(-1.999999999999999,0 ) ;
  }

  @Test
  public void test12() {
    dev.poidev(2.0,-1 ) ;
  }

  @Test
  public void test13() {
    dev.poidev(-2.9999999999999987,0 ) ;
  }

  @Test
  public void test14() {
    dev.poidev(3.0,511 ) ;
  }

  @Test
  public void test15() {
    dev.poidev(3.0,719 ) ;
  }

  @Test
  public void test16() {
    dev.poidev(-309.0,510 ) ;
  }

  @Test
  public void test17() {
    dev.poidev(-33.37199104390453,0 ) ;
  }

  @Test
  public void test18() {
    dev.poidev(-349.0,811 ) ;
  }

  @Test
  public void test19() {
    dev.poidev(35.521225691254415,0 ) ;
  }

  @Test
  public void test20() {
    dev.poidev(-419.0,310 ) ;
  }

  @Test
  public void test21() {
    dev.poidev(-461.0,743 ) ;
  }

  @Test
  public void test22() {
    dev.poidev(5.0,-627 ) ;
  }

  @Test
  public void test23() {
    dev.poidev(6.0,574 ) ;
  }

  @Test
  public void test24() {
    dev.poidev(-645.0,392 ) ;
  }

  @Test
  public void test25() {
    dev.poidev(6.463753877507926,0 ) ;
  }

  @Test
  public void test26() {
    dev.poidev(-66.03730072687742,0 ) ;
  }

  @Test
  public void test27() {
    dev.poidev(-733.0,-881 ) ;
  }

  @Test
  public void test28() {
    dev.poidev(-777.0,0 ) ;
  }

  @Test
  public void test29() {
    dev.poidev(-784.0,-1 ) ;
  }

  @Test
  public void test30() {
    dev.poidev(8.0,0 ) ;
  }

  @Test
  public void test31() {
    dev.poidev(86.54671211969585,0 ) ;
  }

  @Test
  public void test32() {
    dev.poidev(9.0,41 ) ;
  }

  @Test
  public void test33() {
    dev.poidev(-921.0,-983 ) ;
  }

  @Test
  public void test34() {
    dev.poidev(99.1867261571762,0 ) ;
  }
}
