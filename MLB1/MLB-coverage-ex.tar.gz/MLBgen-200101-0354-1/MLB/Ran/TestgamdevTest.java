import org.junit.Test;

public class TestgamdevTest {

  @Test
  public void test0() {
    dev.gamdev(1,0 ) ;
  }

  @Test
  public void test1() {
    dev.gamdev(-154,0 ) ;
  }

  @Test
  public void test2() {
    dev.gamdev(1,880 ) ;
  }

  @Test
  public void test3() {
    dev.gamdev(2,0 ) ;
  }

  @Test
  public void test4() {
    dev.gamdev(2,489 ) ;
  }

  @Test
  public void test5() {
    dev.gamdev(-260,0 ) ;
  }

  @Test
  public void test6() {
    dev.gamdev(263,-376 ) ;
  }

  @Test
  public void test7() {
    dev.gamdev(2,-879 ) ;
  }

  @Test
  public void test8() {
    dev.gamdev(289,231 ) ;
  }

  @Test
  public void test9() {
    dev.gamdev(3,0 ) ;
  }

  @Test
  public void test10() {
    dev.gamdev(3,-1 ) ;
  }

  @Test
  public void test11() {
    dev.gamdev(33,479 ) ;
  }

  @Test
  public void test12() {
    dev.gamdev(3,537 ) ;
  }

  @Test
  public void test13() {
    dev.gamdev(3,876 ) ;
  }

  @Test
  public void test14() {
    dev.gamdev(4,0 ) ;
  }

  @Test
  public void test15() {
    dev.gamdev(-470,0 ) ;
  }

  @Test
  public void test16() {
    dev.gamdev(480,0 ) ;
  }

  @Test
  public void test17() {
    dev.gamdev(584,0 ) ;
  }

  @Test
  public void test18() {
    dev.gamdev(5,-877 ) ;
  }

  @Test
  public void test19() {
    dev.gamdev(6,0 ) ;
  }

  @Test
  public void test20() {
    dev.gamdev(6,436 ) ;
  }

  @Test
  public void test21() {
    dev.gamdev(6,744 ) ;
  }

  @Test
  public void test22() {
    dev.gamdev(73,-1 ) ;
  }

  @Test
  public void test23() {
    dev.gamdev(87,40 ) ;
  }

  @Test
  public void test24() {
    dev.gamdev(887,0 ) ;
  }

  @Test
  public void test25() {
    dev.gamdev(957,-973 ) ;
  }
}
