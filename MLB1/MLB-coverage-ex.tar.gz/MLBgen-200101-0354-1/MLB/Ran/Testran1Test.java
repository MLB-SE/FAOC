import org.junit.Test;

public class Testran1Test {

  @Test
  public void test0() {
    ran.ran1(0 ) ;
  }

  @Test
  public void test1() {
    ran.ran1(-1 ) ;
  }

  @Test
  public void test2() {
    ran.ran1(-144 ) ;
  }

  @Test
  public void test3() {
    ran.ran1(-160 ) ;
  }

  @Test
  public void test4() {
    ran.ran1(-218 ) ;
  }

  @Test
  public void test5() {
    ran.ran1(-229 ) ;
  }

  @Test
  public void test6() {
    ran.ran1(-274 ) ;
  }

  @Test
  public void test7() {
    ran.ran1(-517 ) ;
  }

  @Test
  public void test8() {
    ran.ran1(-532 ) ;
  }

  @Test
  public void test9() {
    ran.ran1(-620 ) ;
  }

  @Test
  public void test10() {
    ran.ran1(-622 ) ;
  }

  @Test
  public void test11() {
    ran.ran1(-631 ) ;
  }

  @Test
  public void test12() {
    ran.ran1(651 ) ;
  }

  @Test
  public void test13() {
    ran.ran1(-712 ) ;
  }

  @Test
  public void test14() {
    ran.ran1(-743 ) ;
  }

  @Test
  public void test15() {
    ran.ran1(-757 ) ;
  }

  @Test
  public void test16() {
    ran.ran1(-847 ) ;
  }

  @Test
  public void test17() {
    ran.ran1(-892 ) ;
  }

  @Test
  public void test18() {
    ran.ran1(903 ) ;
  }

  @Test
  public void test19() {
    ran.ran1(-912 ) ;
  }
}
