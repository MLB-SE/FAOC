import org.junit.Test;

public class JpfTargetVector3DNormalizeTest {

  @Test
  public void test0() {
    TestDrivers.vector3DNormalize(-0.13903266f,0.22720219f,-0.9519796f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.vector3DNormalize(-0.14094417f,0.03498052f,-0.39929172f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.vector3DNormalize(0.26036456f,0.8107428f,-0.5243152f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.vector3DNormalize(0.35822034f,-0.9032284f,0.23634008f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.vector3DNormalize(1.0320393E-8f,-6.270186E-9f,-8.7838E-10f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.vector3DNormalize(-1.2438E-5f,-2.4606436E-4f,-0.002059764f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.vector3DNormalize(4.0506828E-5f,-5.58564E-5f,-3.3657187E-5f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.vector3DNormalize(-41.337364f,-98.5813f,93.44552f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.vector3DNormalize(-63.874393f,18.823298f,-31.715534f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.vector3DNormalize(84.20326f,-36.396408f,-17.304197f ) ;
  }
}
