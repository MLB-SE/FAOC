import org.junit.Test;

public class JpfTargetSphereShadeTest {

  @Test
  public void test0() {
    TestDrivers.sphereShade(-0.0012548087f,-0.07234663f,0f,-12.207139f,0f,0f,0f,-95.928566f,0f,0f,-9.312271f,23.931849f,62.850414f,0f,51.20812f,-28.089005f,-10.018478f,0.15166909f,0.5287632f,0.65306973f,0,0.23514862f,-0.055652656f,-0.13900405f,65.28414f,1.1323166f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.sphereShade(0.0014647851f,84.034164f,-99.99562f,6.279675E-4f,0f,0f,0f,0.0f,0f,0f,-17.419096f,7.2207675f,99.91816f,0f,94.56323f,80.737404f,-9.700643f,-0.4355591f,-0.19825245f,0.84682906f,0,-0.5524784f,-0.50079954f,-0.15228353f,85.14651f,-100.0f,-0.005388508f,0f,0f,0f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.sphereShade(0.0022936638f,0f,0f,99.75136f,0f,0f,0f,21.767714f,0f,0f,-52.600433f,-66.66534f,-24.384089f,0f,100.0f,-100.0f,100.0f,0.52471995f,0.69223833f,1.4069625f,0,-0.74982655f,0.35422274f,-0.4146502f,4.3707047f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.sphereShade(0.0026513601f,-33.556767f,-24.774801f,21.983515f,0f,0f,0f,4.0246086f,0f,0f,-40.53577f,26.272945f,-24.054276f,0f,-41.191647f,26.727396f,-25.34064f,0.44769144f,-0.401728f,-1.7600595f,0,-100.0f,100.0f,-49.56632f,16.516947f,69.23383f,-34.71773f,0f,0f,0f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.sphereShade(-0.0056219455f,0f,0f,8.519696f,0f,0f,0f,80.52579f,0f,0f,-90.45661f,-87.26003f,27.352713f,0f,-91.20693f,-86.05979f,27.792168f,0.66865754f,1.2360865f,0.14496915f,0,62.888237f,-40.913353f,22.244308f,-20.983923f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.sphereShade(-0.006564493f,0f,0f,-55.366932f,0f,0f,0f,0.0f,0f,0f,100.0f,100.0f,18.122477f,0f,-34.16891f,98.18009f,-100.0f,-0.055531334f,-0.28508297f,0.20572121f,0,53.867474f,-13.1797695f,46.435726f,2.7513661f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.sphereShade(0.008247294f,46.001717f,-4.355895f,32.681694f,0f,0f,0f,0.0f,0f,0f,-27.207264f,-33.069145f,-100.0f,0f,100.0f,20.199347f,47.971615f,-0.8310634f,-0.07440406f,-0.51131636f,0,48.04097f,-100.0f,-11.55416f,3.7100859f,-2.4200554f,-46.620674f,0f,0f,0f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.sphereShade(-0.012782336f,-57.46843f,0f,4.977047f,0f,0f,0f,-11.096463f,0f,0f,99.482056f,36.79191f,7.3484626f,0f,100.0f,36.051376f,6.9213467f,0.6705364f,-0.30627608f,-0.062448725f,0,-90.22907f,6.12353f,-6.7864437f,-15.718751f,-3.7185872f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.sphereShade(-0.040964197f,25.041185f,44.468735f,-5.0159297f,0f,0f,0f,-39.993362f,0f,0f,44.385635f,99.13791f,-46.3443f,0f,55.433903f,96.71196f,-40.5324f,0.29633927f,-0.81110907f,0.09215352f,0,49.380177f,21.81495f,59.686295f,4.8668065f,-6.3895926f,41.552086f,0f,0f,0f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.sphereShade(0.07825182f,-30.950188f,97.884254f,27.702787f,0f,0f,0f,0.0f,0f,0f,73.807175f,93.66069f,-98.87793f,0f,-100.0f,100.0f,-44.14665f,0.69710535f,-0.44987082f,0.37253135f,0,0.39645645f,-0.2846242f,-0.13127387f,-24.24192f,-17.039448f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.sphereShade(0.56835866f,0f,0f,43.831394f,0f,0f,0f,-68.04548f,0f,0f,-88.439f,100.0f,10.646019f,0f,-3.7280521f,-75.610245f,-3.0124211f,0.75104326f,0.24920766f,0.084933475f,0,-3.1824145f,-100.0f,-66.60389f,0.040141374f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.sphereShade(-0.6326761f,0f,-29.017195f,0.023954237f,0f,0f,0f,0.0f,0f,0f,-14.224305f,-27.552109f,-30.163696f,0f,-13.792874f,-26.818047f,-29.699022f,0.14793678f,0.29773822f,0.014320707f,0,28.952961f,-53.69552f,59.74468f,-65.983635f,0f,-1.4386735f,0f,0f,0f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.sphereShade(0.7386314f,0f,0f,0.19345844f,0f,0f,0f,0.0f,0f,0f,87.08698f,66.4346f,67.928f,0f,-100.0f,30.94366f,-99.99966f,0.47632197f,0.08623371f,-0.16818653f,0,-0.43654016f,0.228809f,-0.7008531f,6.998171f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.sphereShade(0.9506497f,-46.788048f,100.0f,-0.0022301984f,0f,0f,0f,0.0f,0f,0f,7.479886f,-74.624626f,-5.729341f,0f,7.0582924f,-74.86078f,-5.011942f,-0.12343452f,0.23064789f,-0.28990006f,0,72.12125f,-11.661437f,56.48401f,48.738262f,14.107641f,-4.4839063f,0f,0f,0f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.sphereShade(0f,0.018727768f,4.6421788E-4f,-51.464245f,0f,0f,0f,95.80338f,0f,0f,-97.42536f,87.67366f,9.203924f,0f,-100.0f,-66.183044f,87.08786f,0.11019751f,0.39315024f,1.5609531f,0,-0.5826452f,-0.030794874f,-0.13703461f,0f,74.710464f,-96.054474f,0f,0f,0f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.sphereShade(0f,0.027398588f,0f,-4.219826f,0f,0f,0f,11.949889f,0f,0f,97.88604f,-100.0f,-88.71184f,-17.448225f,4.2111034f,-99.72435f,-60.252945f,0.057955768f,0.0017905098f,0.046449237f,0,99.341896f,-100.0f,-99.229385f,0f,8.90804f,0f,0f,43.316853f,0f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.sphereShade(0f,-0.25194487f,-16.90384f,-0.09095025f,0f,0f,0f,52.607437f,0f,0f,8.378953f,-99.90544f,72.166145f,22.808567f,-60.203327f,-100.0f,-1.5591346f,-0.27086657f,-0.27525732f,0.7637392f,0,-14.301761f,33.898205f,75.835464f,0f,85.013084f,2.823662f,0f,-4.595313f,-33.129505f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.sphereShade(0f,-0.9943882f,100.0f,22.897755f,0f,0f,0f,99.56826f,0f,0f,99.568085f,-16.274582f,-99.68379f,0f,-99.42064f,89.5467f,-21.0288f,-1.0476495f,0.40700543f,-0.20477639f,0,-0.69259757f,-0.40340614f,0.5261588f,0f,-32.902016f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0.0082344515f,0f,0f,100.0f,-0.06260977f,61.141785f,0f,99.95984f,-30.155642f,77.26711f,-0.6253499f,-13.377376f,-25.791216f,0,-24.243082f,-98.527626f,-92.839355f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,-100.0f,-100.0f,-79.473755f,0f,-100.0f,-100.0f,-80.53314f,0.2199807f,0.37017238f,-0.9087267f,0,100.0f,90.591774f,-16.859013f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,100.0f,-18.240028f,92.48427f,0f,-8.0536785f,37.543087f,-95.094315f,0.5131749f,-0.6914927f,-7.210157E-4f,0,0.33732444f,-0.7220749f,-0.0010135758f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,-50.025833f,75.610214f,99.37441f,0f,-50.536972f,76.443375f,99.25256f,0.27503902f,0.62218726f,-0.2296113f,0,-100.0f,-100.0f,-90.65043f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,-97.63719f,-66.47647f,-24.756935f,0f,-99.80726f,-100.0f,35.89772f,-0.27856636f,-0.10721259f,-0.5465316f,0,83.52963f,100.0f,-100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0.46422842f,0f,0f,11.836778f,-100.0f,-26.115345f,-73.275185f,100.0f,0.098497406f,-53.10738f,-0.40800214f,0.28480652f,0.45232332f,0,-0.06672566f,19.346457f,100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.0013571851f,2.7361233E-4f,-8.6658023E-4f,0,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.012070594f,-0.2425002f,-0.603427f,0,-0.004424439f,0.14689827f,0.011557081f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.014976887f,-0.22643387f,-0.008489785f,0,-0.47173715f,0.088728316f,-0.2866716f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.07568714f,-0.45916796f,0.5066905f,0,-0.75281435f,0.6403169f,-0.15252826f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.0f,0.0f,-1.0f,0,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.0f,0.0f,-1.0f,1,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.0f,0.0f,1.0f,954,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.0f,-1.0f,0.0f,-1028,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.0f,-1.0f,0.0f,652,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.0f,-1.0f,0.0f,-802,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.10668285f,0.10426179f,-0.009074687f,0,49.60103f,34.233894f,-64.027374f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.13143672f,-0.060556974f,-0.32587197f,0,0.33557177f,0.41820458f,-0.8440951f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.16762337f,0.3408926f,0.9250376f,0,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.19066541f,0.012736852f,-0.02114412f,0,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.24100599f,0.65702635f,-0.09463244f,0,-100.0f,-100.0f,-39.84841f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.24700175f,-0.77290165f,-0.31052595f,0,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.2624791f,0.19405013f,0.18171036f,0,-4.8881647E-4f,-2.9204338E-4f,0.0012383927f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.38423964f,-0.26954868f,0.2448381f,0,17.41037f,8.450418f,-6.3842015f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.55931014f,0.54538304f,-0.22103424f,0,0.024381638f,0.012968084f,0.027699737f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.58954674f,0.5324552f,-0.40791935f,0,0.11840363f,0.029675324f,-0.226276f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1.0f,0.0f,0.0f,0,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1.0f,5.0f,0.0f,1,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1.6714465E-4f,7.72936E-5f,-7.563601E-4f,0,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-16.87564f,-53.704227f,67.57469f,0,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-192.0f,-642.0f,492.0f,-520,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test49() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,20.0f,1698.0f,-140.0f,3,0.017140646f,-0.07800636f,0.017866258f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test50() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-2.1893183E-9f,4.6281383E-9f,4.197382E-10f,0,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test51() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,26.47825f,3.2225146f,-65.08799f,0,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test52() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,331.0f,-938.0f,242.0f,2,0.27477002f,-0.028032677f,0.14866751f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test53() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-403.0f,-548.0f,327.0f,1,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test54() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,45.0f,71.0f,-224.0f,968,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test55() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,495.0f,946.0f,668.0f,2,-12.547991f,97.276276f,65.719086f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test56() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,70.915955f,-62.855934f,19.79711f,0,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test57() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-899.0f,-134.0f,-231.0f,0,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test58() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,100.0f,-100.0f,0f,-100.0f,100.0f,-100.0f,0.48383865f,-0.24880563f,-0.55863404f,0,96.71151f,4.0564704f,84.2873f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test59() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-100.0f,100.0f,0f,-100.0f,-89.70638f,-93.96504f,0.15795939f,-0.16026853f,0.87755966f,0,0.91327125f,0.124973044f,0.38770783f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test60() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,-68.801254f,0f,-100.0f,-100.0f,-69.0f,352.0f,-237.0f,1493.0f,2,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test61() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,69.70723f,0f,-100.0f,-100.0f,70.4723f,-0.35053247f,-0.810426f,-0.36575794f,0,0.0872811f,1.0113413f,0.13301006f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test62() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,100.0f,83.0f,0f,-100.0f,100.0f,83.0f,-2508.0f,358.0f,2287.0f,659,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test63() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,86.00002f,0f,-100.0f,-100.0f,86.0f,-643.0f,-727.0f,916.0f,-850,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test64() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,11.908494f,-89.71864f,0f,99.99771f,12.435139f,-88.36913f,0.34119096f,-0.81830525f,0.36039147f,0,0.098980375f,-0.8378872f,0.3020699f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test65() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,43.965084f,-72.49683f,0f,100.0f,44.15158f,-71.51435f,-0.043522518f,0.43457156f,0.08610585f,0,16.13164f,100.0f,97.48186f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test66() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-63.63539f,66.99948f,0f,99.3009f,-64.10024f,59.0f,-8.0f,-26.0f,13.0f,2,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test67() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,68.93789f,-100.0f,0f,100.0f,68.93824f,-100.0f,-173.0f,-572.0f,-180.0f,2946,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test68() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,69.93591f,-100.0f,0f,100.0f,69.80574f,-102.0f,-3.0f,0.0f,-5.0f,1,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test69() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,86.45825f,19.82796f,0f,-100.0f,86.61689f,20.0f,-636.0f,-895.0f,-9.0f,-1,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test70() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-90.48249f,-100.0f,0f,-100.0f,-90.48249f,-100.0f,0.03797506f,-0.07976691f,0.28134352f,0,0.09943629f,-0.22714406f,0.57214737f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test71() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1017.0f,-789.0f,1284.0f,0f,-230.0f,359.0f,-950.0f,-3.0f,43.0f,27.0f,0,0.55246454f,0.59396356f,-0.025682343f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test72() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,103.0f,121.0f,-8.0f,0f,100.0f,79.0f,-31.0f,1325.0f,1277.0f,-2071.0f,11,98.740524f,92.11699f,-28.740955f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test73() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-105.0f,-230.0f,221.0f,0f,-105.0f,-231.0f,220.0f,-272.0f,-1052.0f,518.0f,997,-49.037964f,-99.58151f,-45.191048f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test74() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1087.0f,-506.0f,-131.0f,-563.0f,-1312.0f,-13.0f,-316.0f,-278.0f,-47.0f,-13.0f,-813,-3.103254f,-3.1109443f,-1.8272246f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test75() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1172.0f,858.0f,199.0f,0f,1228.0f,857.0f,965.0f,646.0f,-1987.0f,1855.0f,1268,0.0037930754f,-0.57288086f,0.119816035f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test76() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-11.954102f,-53.80736f,-3.055869f,0f,-46.3347f,-97.634476f,577.0f,239.0f,984.0f,-674.0f,2,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test77() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1208.0f,-572.0f,865.0f,0f,-298.0f,-782.0f,417.0f,-15.0f,-2.0f,1.0f,1,-97.340096f,126.7969f,-41.024704f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test78() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1239.0f,-216.0f,-366.0f,1432.0f,814.0f,-318.0f,977.0f,690.0f,-325.0f,982.0f,248,-0.46226797f,0.02001814f,0.06626008f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test79() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1294.0f,232.0f,-999.0f,0f,-983.0f,358.0f,1326.0f,7.0f,5.0f,0.0f,312,-33.934727f,-9.25185f,-35.35907f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test80() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,15.428794f,-56.530273f,-35.48872f,0f,15.070171f,-57.127518f,-35.053345f,0.2823825f,-0.29886168f,0.528053f,0,78.15318f,100.0f,-100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test81() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1781.0f,1238.0f,-1226.0f,0f,148.0f,167.0f,-111.0f,1591.0f,-213.0f,639.0f,12,148.18248f,165.02727f,-111.272705f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test82() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-18.11926f,24.790539f,-60.442284f,0f,-17.980343f,26.115078f,-60.452484f,0.12053505f,-0.013441059f,0.026061986f,0,-0.06780633f,-0.07065141f,-1.0039107f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test83() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-189.0f,941.0f,625.0f,0f,-188.0f,952.0f,618.0f,-7.0f,-8.0f,-23.0f,-277,-3.0600693f,-61.326973f,109.668045f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test84() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-195.0f,175.0f,395.0f,0f,-193.0f,182.0f,415.0f,-1.0f,-14.0f,17.0f,2905,-12.599741f,-143.76953f,29.82185f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test85() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,20.257303f,100.0f,94.09229f,0f,20.339172f,100.0f,93.55661f,-0.43700346f,-0.040876262f,0.18274364f,0,58.308537f,100.0f,-16.50688f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test86() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2030.0f,-681.0f,529.0f,0f,134.0f,1954.0f,1128.0f,359.0f,-1354.0f,-255.0f,662,0.20744558f,0.45145312f,-0.7232728f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test87() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,21.66462f,9.548765f,-77.4055f,0f,23.386074f,10.202702f,-74.947586f,-0.057503596f,0.22303754f,-0.2464818f,0,-0.81016797f,0.8346069f,0.21644872f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test88() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,217.0f,895.0f,-777.0f,0f,195.0f,896.0f,-778.0f,1879.0f,-721.0f,-1485.0f,956,-1.3993236f,0.36584532f,0.24521837f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test89() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,22.0f,859.0f,-1447.0f,-371.0f,-923.0f,-350.0f,284.0f,555.0f,-1856.0f,-949.0f,358,-4.974835f,-5.7161055f,-6.689769f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test90() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,24.0f,-323.0f,-1651.0f,0f,-1910.0f,151.0f,781.0f,-515.0f,-1613.0f,1394.0f,-122,-0.09262108f,-0.0853712f,5.5611716E-4f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test91() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2708.0f,-1387.0f,1055.0f,0f,206.0f,1120.0f,-653.0f,-1617.0f,-364.0f,266.0f,-1281,-0.024400992f,0.0028874413f,-0.0028762075f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test92() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-27.59783f,100.0f,2.3400204f,0f,-27.08975f,100.0f,2.569524f,0.017413452f,-0.14672607f,0.016290393f,0,-0.84806585f,-0.0074465526f,0.19821325f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test93() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-35.55536f,-21.319504f,18.757782f,0f,-35.544983f,-21.224567f,19.0f,-13.0f,-1.0f,-6.0f,193,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test94() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-38.020878f,3.1535378f,69.56086f,0f,76.661385f,91.044556f,-318.0f,-555.0f,484.0f,-666.0f,-616,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test95() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-41.511383f,-99.14263f,63.465103f,0f,-41.756798f,-99.07786f,64.0f,-272.0f,-551.0f,-1158.0f,714,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test96() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,428.0f,-398.0f,372.0f,0f,-940.0f,259.0f,-1590.0f,-2245.0f,945.0f,1740.0f,-597,-0.8435808f,0.41224456f,-0.3441306f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test97() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-472.0f,-609.0f,-158.0f,0f,36.0f,-16.0f,104.0f,-1430.0f,2456.0f,930.0f,3,35.800232f,-15.054761f,100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test98() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-48.203457f,-64.02176f,-100.0f,0f,-27.747204f,86.44461f,84.10893f,-0.10906247f,-0.29422152f,0.11878978f,0,0.14648968f,-0.9655314f,-0.047852453f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test99() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,49.15775f,-46.367504f,-70.95711f,0f,49.18397f,-47.008354f,-71.15599f,0.4647819f,0.56732184f,0.42028618f,0,0.5029371f,0.10645696f,-0.61316335f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test100() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-49.184536f,-21.042986f,-23.925278f,0f,-83.3341f,-92.20146f,26.806334f,-0.8038858f,-0.18714716f,-0.31830138f,0,-17.676226f,91.6905f,-24.239887f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test101() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-499.0f,-372.0f,1437.0f,0f,-523.0f,-369.0f,1425.0f,24.0f,-11.0f,23.0f,14,97.65149f,54.45031f,275.3311f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test102() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-50.792065f,100.0f,-102.12508f,0f,-50.721813f,100.0f,-103.0f,354.0f,22.0f,-904.0f,-1631,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test103() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,519.0f,2069.0f,-998.0f,2492.0f,-747.0f,-668.0f,951.0f,466.0f,-748.0f,1495.0f,-345,-0.12026455f,-0.073906645f,-0.9646287f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test104() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-530.0f,-925.0f,87.0f,0f,-688.0f,137.0f,828.0f,831.0f,309.0f,-591.0f,-9,-30.10719f,-85.418015f,-41.69309f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test105() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-54.53071f,-36.380676f,39.170643f,0f,-54.07305f,-37.20425f,39.50572f,0.6712147f,0.3159265f,-0.32140946f,0,100.0f,36.115303f,-0.8786761f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test106() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-559.0f,590.0f,-778.0f,879.0f,334.0f,-898.0f,615.0f,-830.0f,834.0f,-5.0f,-308,-0.9084713f,0.20830375f,0.2342871f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test107() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-60.77883f,26.610884f,-53.627724f,0f,68.83285f,0.49407274f,-144.0f,-819.0f,806.0f,-452.0f,858,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test108() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,61.518536f,-15.271496f,131.10638f,0f,62.754654f,-13.479791f,130.0f,-17.0f,-13.0f,0.0f,-269,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test109() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-6.187308f,19.434923f,55.869293f,0f,-42.708668f,43.116035f,-1159.0f,891.0f,70.0f,-278.0f,-2,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test110() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,634.0f,-455.0f,-703.0f,-626.0f,-77.0f,-885.0f,-958.0f,-975.0f,-63.0f,-676.0f,557,-0.18831888f,-0.8264513f,0.24971613f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test111() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,63.420006f,100.0f,51.116734f,0f,-30.058153f,-35.551975f,11.926771f,0.2207583f,0.5710302f,0.45732328f,0,-0.47619104f,0.7515006f,0.034315147f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test112() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,657.0f,841.0f,-62.0f,0f,660.0f,853.0f,-65.0f,-840.0f,1890.0f,-806.0f,-445,-0.25272235f,-0.56743276f,-0.036965903f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test113() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-66.18149f,-0.7894287f,25.971144f,0f,-66.15985f,-0.5519181f,25.0f,-873.0f,-476.0f,-1602.0f,-949,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test114() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-67.75713f,99.99223f,-99.99921f,0f,-67.75848f,99.990906f,-100.0f,-0.59518427f,-0.6011699f,0.43968996f,0,99.9979f,99.99683f,99.99869f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test115() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-70.72374f,13.830062f,-158.09323f,0f,-47.246628f,-32.358738f,295.0f,0.0f,4.0f,0.0f,-2,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test116() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,709.0f,593.0f,-958.0f,0f,-788.0f,-169.0f,196.0f,59.0f,888.0f,18.0f,-627,2.7874901f,26.448456f,-86.446175f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test117() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-71.0f,9.0f,191.0f,0f,-101.0f,17.0f,194.0f,847.0f,-1774.0f,648.0f,-26,-119.17587f,18.001062f,220.52959f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test118() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-769.0f,990.0f,526.0f,772.0f,-1100.0f,212.0f,-917.0f,653.0f,706.0f,205.0f,-157,0.49248925f,-0.64283735f,0.3936575f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test119() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-78.985054f,-47.612793f,-25.57727f,0f,8.147896f,-68.026f,847.0f,-2.0f,-1.0f,-1.0f,766,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test120() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-790.0f,983.0f,-729.0f,0f,168.0f,525.0f,-407.0f,-930.0f,-527.0f,503.0f,4,-45.397278f,-40.699566f,70.27992f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test121() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,81.45031f,-57.316902f,74.82465f,0f,-11.720756f,29.603075f,-275.0f,845.0f,-777.0f,552.0f,-831,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test122() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-822.0f,1135.0f,-626.0f,0f,-845.0f,1160.0f,-639.0f,-15.0f,-14.0f,59.0f,51,-54.43275f,-162.83893f,42.13857f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test123() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,83.67126f,76.91011f,8.640917f,0f,41.931614f,100.0f,45.716362f,-0.68861115f,0.50773007f,0.37167206f,0,0.3739906f,-0.35822552f,-0.36402076f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test124() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,845.0f,-801.0f,1651.0f,0f,801.0f,982.0f,-483.0f,10.0f,10.0f,-6.0f,-696,0.26858133f,-0.056246907f,-0.7110294f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test125() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-84.77432f,88.988884f,99.99187f,0f,-84.79473f,88.957016f,100.0f,-0.66014785f,-0.382615f,0.2349009f,0,0.38158986f,-0.3756767f,0.034368504f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test126() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-850.0f,808.0f,-747.0f,0f,-854.0f,802.0f,-730.0f,290.0f,721.0f,-426.0f,2,62.976562f,156.16583f,45.357616f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test127() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,87.51947f,48.574375f,12.193113f,0f,32.669365f,78.03378f,880.0f,-391.0f,945.0f,686.0f,689,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test128() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,89.59664f,69.70915f,80.844604f,0f,89.596825f,69.70892f,80.84457f,0.09391883f,0.34616825f,0.25979996f,0,34.30237f,-74.070114f,74.033905f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test129() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-90.21435f,85.787415f,2.172689f,0f,95.87221f,8.588501f,-87.183266f,0.22599354f,0.8300493f,-0.17064218f,0,0.54927015f,0.23687991f,0.3020894f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test130() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-91.0f,1.0f,-1554.0f,1118.0f,-916.0f,-366.0f,418.0f,283.0f,-196.0f,-236.0f,1189,-0.40545213f,-0.57181716f,0.42662132f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test131() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-91.29449f,-9.653512f,-48.74854f,0f,-91.30364f,-9.714877f,-49.0f,1355.0f,1253.0f,-1682.0f,771,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test132() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-91.76287f,-38.49238f,95.887314f,0f,-91.45551f,-37.74331f,96.0f,212.0f,-1599.0f,1498.0f,-93,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test133() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-92.072495f,-55.151535f,29.194891f,0f,-99.15341f,76.51842f,28.3325f,-0.35571325f,0.06885146f,-0.2793941f,0,-56.471447f,-55.81712f,-16.173393f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test134() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-9.407183f,89.40912f,88.168465f,0f,-6.1217384f,27.52354f,-389.0f,152.0f,-267.0f,726.0f,-323,0f,0f,0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test135() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,954.0f,-41.0f,644.0f,641.0f,593.0f,-754.0f,1303.0f,350.0f,631.0f,-417.0f,623,0.5464255f,-0.69308275f,-0.36773983f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test136() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-97.80071f,-76.62354f,-100.0f,0f,100.0f,-100.0f,42.479935f,0.022369586f,0.09462633f,-0.2543048f,0,-82.925026f,99.05816f,-100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test137() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,99.49497f,100.0f,-97.59794f,0f,99.27311f,100.0f,-97.64231f,0.60814995f,0.011732593f,-0.51554567f,0,0.76852524f,-0.32189205f,-0.5114322f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test138() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,-100.0f,-100.0f,-32.479546f,0f,-96.29395f,-30.929165f,-100.0f,0.29046378f,-0.7669426f,0.405256f,0,46.593323f,100.0f,100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test139() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,-100.0f,67.52675f,41.549873f,0f,3.5670407f,-16.69057f,85.526024f,-0.7968382f,0.41213924f,-0.037352763f,0,-5.9363117f,52.433636f,-95.98435f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test140() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,-19.687176f,19.201344f,9.402715f,0f,100.0f,-100.0f,100.0f,-0.895528f,0.20032097f,-0.20956907f,0,-60.973076f,-100.0f,-100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test141() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,-22.364693f,8.367304f,99.997185f,0f,-37.983246f,-18.125587f,94.2321f,0.38441807f,0.21080989f,0.22629943f,0,0.10571791f,-0.404891f,-0.097746745f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test142() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,-26.754362f,-100.0f,-100.0f,0f,-100.0f,-100.0f,100.0f,-0.7071289f,-0.4296499f,-0.41046152f,0,100.0f,-55.41705f,100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test143() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,28.909008f,10.38941f,92.40731f,0f,-18.772528f,-99.999756f,-76.21959f,12.099879f,-0.44541085f,-3.129823f,0,-17.200901f,-99.99917f,-99.94456f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test144() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,37.839092f,-40.65368f,-52.55001f,0f,-49.78761f,100.0f,-36.838203f,0.8348129f,-0.10254567f,0.011005501f,0,0.39459494f,-0.14826931f,0.07382198f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test145() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,-100.0f,0f,0f,43.439007f,-99.986626f,-100.0f,0f,43.299908f,-100.0f,-100.0f,-0.32611382f,-0.53605896f,0.6927407f,0,127.37575f,64.15334f,146.1135f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test146() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,-100.0f,0f,0f,53.03499f,69.683395f,9.14124f,0f,52.669483f,69.39338f,8.447149f,-0.26503018f,0.69121164f,-0.4588298f,0,2.4063423f,87.60188f,-86.980156f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test147() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,-74.959816f,45.32544f,49.914143f,0f,100.0f,-7.3545604f,-34.75227f,-0.82436943f,-0.3570966f,-0.1297411f,0,0.03573074f,-0.4032089f,-0.29355344f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test148() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,77.58612f,-69.98869f,-66.679085f,0f,76.908806f,-70.15763f,-66.61446f,1.2423205f,-0.03037211f,-0.8256226f,0,-74.23663f,30.090164f,-62.02848f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test149() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,1004.0f,0f,0f,728.0f,129.0f,353.0f,-55.0f,800.0f,365.0f,439.0f,348.0f,-807.0f,613.0f,-686,0.053647336f,0.007488202f,1.2117329f,0f,0f,0f,0f,72.567345f,0f ) ;
  }

  @Test
  public void test150() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,1028.0f,0f,0f,-1460.0f,-1191.0f,802.0f,-297.0f,-911.0f,465.0f,568.0f,-481.0f,-41.0f,750.0f,-1410,2.8656538f,-1.0025162f,-2.181058f,0f,0f,0f,70.74953f,-81.38842f,0f ) ;
  }

  @Test
  public void test151() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,1048.0f,0f,0f,-1350.0f,877.0f,2237.0f,-213.0f,-884.0f,467.0f,-852.0f,-574.0f,15.0f,294.0f,-2658,0.0010421379f,-0.2753524f,-0.6846011f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test152() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,11.0f,0f,0f,-687.0f,1500.0f,1297.0f,-628.0f,1336.0f,-22.0f,1965.0f,-122.0f,188.0f,-765.0f,932,0.06932151f,-0.31472278f,-0.6858568f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test153() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,11.1525755f,0f,0f,7.0096765f,-98.16135f,91.49137f,-48.634674f,-100.0f,-34.72159f,48.100018f,0.48783675f,0.12875313f,-0.06086035f,0,-33.21215f,9.079047f,-98.28357f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test154() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,1152.0f,0f,0f,-763.0f,-910.0f,-567.0f,-1247.0f,-548.0f,-816.0f,1187.0f,-772.0f,-1806.0f,191.0f,-830,1.826765f,-4.6692863f,3.9693267f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test155() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,12.186905f,0f,0f,-68.938255f,-100.0f,-60.092693f,-100.0f,100.0f,-42.183266f,100.0f,-2.4359088f,0.20038894f,-0.2492064f,0,16.915981f,9.354679f,-53.125927f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test156() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,1234.0f,0f,0f,-1883.0f,-540.0f,-1053.0f,845.0f,-476.0f,-1877.0f,-523.0f,-919.0f,-1192.0f,-597.0f,-972,1.0361139f,-0.19985966f,-0.8049632f,0f,0f,0f,-49.970642f,0f,0f ) ;
  }

  @Test
  public void test157() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,1235.0f,0f,0f,1001.0f,-163.0f,1002.0f,902.0f,1298.0f,-277.0f,-64.0f,-1101.0f,-639.0f,774.0f,74,-1.3475995f,-0.28352067f,-0.61003965f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test158() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,1239.0f,0f,0f,146.0f,776.0f,321.0f,620.0f,-383.0f,769.0f,791.0f,2247.0f,611.0f,703.0f,427,4.4680924f,-3.794101f,7.043274f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test159() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,125.0f,0f,0f,-2013.0f,333.0f,175.0f,-2014.0f,1613.0f,-284.0f,-795.0f,-87.0f,-1573.0f,862.0f,-800,0.6541943f,0.83715844f,-0.30447206f,0f,0f,0f,2.0400045f,0f,0f ) ;
  }

  @Test
  public void test160() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,13.004177f,0f,0f,100.0f,84.351166f,-86.257805f,-97.53396f,-35.719772f,79.355515f,-53.97205f,0.12550801f,-0.016982302f,-0.26067397f,0,-95.5845f,67.971535f,-42.107536f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test161() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,131.0f,0f,0f,2377.0f,-391.0f,-3171.0f,-849.0f,-139.0f,1964.0f,-870.0f,840.0f,-993.0f,-1432.0f,85,0.19416957f,0.24555959f,0.23230262f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test162() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,1327.0f,0f,0f,982.0f,399.0f,2457.0f,1884.0f,1588.0f,-1351.0f,-2609.0f,605.0f,350.0f,978.0f,-471,-0.95457f,0.20351638f,-0.18996681f,0f,0f,0f,-27.920702f,0f,0f ) ;
  }

  @Test
  public void test163() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,133.0f,0f,0f,-1523.0f,412.0f,-630.0f,-24.0f,397.0f,286.0f,-846.0f,-36.0f,718.0f,717.0f,828,0.8386066f,0.46031702f,0.04139683f,0f,0f,0f,-51.654827f,-3.4099956f,-88.279655f ) ;
  }

  @Test
  public void test164() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,1413.0f,0f,0f,-982.0f,582.0f,-1010.0f,747.0f,-164.0f,149.0f,-263.0f,-877.0f,230.0f,116.0f,-461,0.2034225f,-0.039148718f,-0.0062283813f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test165() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,1471.0f,0f,0f,527.0f,330.0f,352.0f,-531.0f,1902.0f,1252.0f,-1844.0f,-1284.0f,-1652.0f,81.0f,691,-0.2945941f,-0.82202953f,-0.77839583f,0f,0f,0f,-100.0f,26.363668f,0f ) ;
  }

  @Test
  public void test166() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,148.0f,0f,0f,389.0f,918.0f,1479.0f,-337.0f,1217.0f,868.0f,311.0f,-536.0f,-822.0f,812.0f,1046,1.4538894f,-0.17299013f,-0.033054538f,0f,0f,0f,1.7229768f,0f,0f ) ;
  }

  @Test
  public void test167() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,14.947637f,0f,0f,-100.0f,100.0f,-100.0f,-100.0f,-32.446247f,-100.0f,-100.0f,0.5217034f,0.40474164f,-0.5615625f,0,81.957596f,-25.172886f,-99.07091f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test168() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,15.0f,0f,0f,901.0f,1219.0f,-2282.0f,914.0f,-653.0f,-516.0f,-30.0f,1044.0f,-435.0f,-968.0f,1043,0.5616179f,-0.027381599f,0.54346204f,0f,0f,0f,17.000038f,83.3916f,17.000038f ) ;
  }

  @Test
  public void test169() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,152.0f,0f,0f,-500.0f,1770.0f,249.0f,307.0f,620.0f,-944.0f,803.0f,-332.0f,746.0f,34.0f,-119,-0.8095184f,-0.3132974f,0.49613687f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test170() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,153.0f,0f,0f,-1250.0f,1221.0f,752.0f,354.0f,724.0f,-2522.0f,-1107.0f,-383.0f,933.0f,1581.0f,539,0.10034223f,-0.0798984f,-1.5296172f,0f,0f,0f,-96.512825f,-48.292492f,1.7787136f ) ;
  }

  @Test
  public void test171() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,1546.0f,0f,0f,299.0f,-881.0f,-1429.0f,-1245.0f,-194.0f,1252.0f,-314.0f,306.0f,-2021.0f,-625.0f,423,-0.10980583f,-0.15157032f,2.4131742f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test172() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,1576.0f,0f,0f,258.0f,-439.0f,-2382.0f,246.0f,1885.0f,-1843.0f,1165.0f,-1325.0f,-667.0f,-675.0f,98,0.32518378f,-0.052582342f,0.8075817f,0f,0f,0f,-8.680186f,-1.8312061f,0f ) ;
  }

  @Test
  public void test173() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,1628.0f,0f,0f,-1383.0f,-466.0f,-1033.0f,385.0f,-1404.0f,-860.0f,-310.0f,-1248.0f,-307.0f,-571.0f,1475,0.0075688674f,-2.1474655f,-0.15179309f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test174() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,1630.0f,0f,0f,-500.0f,1840.0f,803.0f,797.0f,-369.0f,-2155.0f,-735.0f,-10.0f,905.0f,-771.0f,-2462,-0.1319755f,-0.5300028f,0.19438486f,0f,0f,0f,8.391907f,0f,0f ) ;
  }

  @Test
  public void test175() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,1657.0f,0f,0f,-675.0f,-980.0f,-1528.0f,40.0f,2445.0f,472.0f,-553.0f,-466.0f,-1375.0f,-30.0f,379,0.3078776f,0.035059866f,0.8645246f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test176() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,1690.0f,0f,0f,1972.0f,532.0f,-603.0f,-189.0f,-454.0f,-1441.0f,781.0f,597.0f,1673.0f,-299.0f,-959,-0.8990001f,0.3006662f,-0.18999071f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test177() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,17.683334f,0f,0f,-100.0f,-43.51351f,100.0f,100.0f,-37.31901f,-26.364239f,-30.73782f,-0.09403533f,0.80303067f,0.27927902f,0,100.0f,88.24796f,-2.1482296f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test178() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,1773.0f,0f,0f,857.0f,-3144.0f,749.0f,425.0f,-306.0f,-397.0f,-807.0f,-531.0f,-636.0f,-312.0f,-1469,-3.5471342f,-0.7370296f,0.49392283f,0f,0f,0f,0f,-100.0f,0f ) ;
  }

  @Test
  public void test179() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,179.0f,0f,0f,-1234.0f,12.0f,937.0f,203.0f,-985.0f,142.0f,864.0f,-330.0f,-988.0f,719.0f,-70,0.066099f,-0.7050655f,-2.8773668f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test180() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,1796.0f,0f,0f,1206.0f,1174.0f,-459.0f,308.0f,14.0f,-1855.0f,-519.0f,881.0f,715.0f,-228.0f,-842,-0.073551185f,0.0025298712f,-0.06337178f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test181() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,186.0f,0f,0f,-737.0f,1547.0f,501.0f,-648.0f,-933.0f,-387.0f,-1134.0f,-829.0f,-74.0f,883.0f,-559,-0.37586653f,-0.70892555f,0.19015618f,0f,0f,0f,100.0f,0f,0f ) ;
  }

  @Test
  public void test182() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,188.0f,0f,0f,-1790.0f,-525.0f,-562.0f,-490.0f,71.0f,-146.0f,-238.0f,-510.0f,-542.0f,580.0f,682,0.0069687944f,-0.030705974f,-5.147523E-4f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test183() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,19.13033f,0f,0f,30.95203f,29.704988f,80.858955f,0f,99.96018f,100.0f,-84.36575f,0.039531387f,0.06104305f,0.59919155f,0,-1.1435144f,0.797914f,-0.07103699f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test184() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,1923.0f,0f,0f,-2804.0f,-1454.0f,-802.0f,488.0f,-870.0f,896.0f,1921.0f,-1518.0f,43.0f,-962.0f,1616,-0.0890347f,0.3335325f,-0.059592202f,0f,0f,0f,-89.67329f,-64.032555f,29.590723f ) ;
  }

  @Test
  public void test185() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,19.785593f,0f,0f,100.0f,-31.280895f,-29.59076f,64.542496f,89.06954f,-36.154686f,-21.20213f,-0.254508f,-0.2727813f,-3.872542f,0,-78.32771f,-90.60505f,85.727135f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test186() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,-1.9787436f,0f,0f,145.299f,-57.356987f,94.0853f,0f,100.0f,66.607445f,-58.50527f,0.23317577f,-0.09714134f,0.41129607f,0,-16.436295f,53.4799f,-100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test187() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,1984.0f,0f,0f,508.0f,-1228.0f,-312.0f,-541.0f,83.0f,-617.0f,424.0f,740.0f,599.0f,-1126.0f,459,0.027521085f,1.4173715f,-0.47666138f,0f,0f,0f,100.0f,17.227106f,0f ) ;
  }

  @Test
  public void test188() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,2.0f,0f,0f,-850.0f,-1255.0f,-84.0f,669.0f,684.0f,822.0f,851.0f,-170.0f,-524.0f,-785.0f,-589,1.0472206f,-0.39662018f,0.13794024f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test189() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,21.0f,0f,0f,-649.0f,1049.0f,-890.0f,1238.0f,-741.0f,-2831.0f,-494.0f,-173.0f,976.0f,-1633.0f,-898,-0.41672733f,-2.2165153f,-0.418299f,0f,0f,0f,28.80895f,12.149384f,0f ) ;
  }

  @Test
  public void test190() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,2.1316282E-14f,0f,0f,-64.45298f,-100.0f,-100.0f,-99.99912f,-1.2029933f,100.0f,-99.3303f,-0.91136664f,0.07005727f,0.34767976f,0,-100.0f,100.0f,100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test191() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,214.0f,0f,0f,-423.0f,997.0f,-3168.0f,957.0f,-2522.0f,-236.0f,646.0f,-542.0f,-978.0f,435.0f,-465,0.004062154f,-0.149518f,0.019747071f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test192() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,2.285739f,0f,0f,100.0f,46.972443f,22.333382f,0f,-100.0f,1.4089442f,-100.0f,0.09858842f,0.7708649f,-0.1275177f,0,-0.6173485f,0.6448702f,-0.25159824f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test193() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,22.859976f,0f,0f,42.91673f,-99.20799f,-52.340164f,0f,44.05331f,-98.91175f,-52.501057f,-0.12458533f,0.19361146f,-0.48289785f,0,-34.168182f,-31.526283f,-100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test194() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,245.0f,0f,0f,-44.0f,-794.0f,-632.0f,1265.0f,230.0f,1812.0f,-275.0f,-545.0f,-1153.0f,-646.0f,-145,-0.6347365f,0.32407945f,-0.7185856f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test195() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,26.0787f,0f,0f,-17.904734f,-7.45105f,43.771717f,0f,-17.721312f,-7.378825f,43.52316f,0.12756461f,-0.10557217f,-0.8366371f,0,-8.735611f,10.646079f,-17.001163f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test196() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,266.0f,0f,0f,1573.0f,-1588.0f,-899.0f,-160.0f,-542.0f,-36.0f,1758.0f,1173.0f,-1036.0f,-980.0f,1502,-0.9580029f,-0.03679794f,-0.009492745f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test197() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,2716.0f,0f,0f,119.0f,-835.0f,521.0f,433.0f,-96.0f,2434.0f,621.0f,-577.0f,-293.0f,-259.0f,1229,0.4865193f,0.8545402f,-0.11669213f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test198() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,305.0f,0f,0f,-153.0f,-2011.0f,-964.0f,-63.0f,269.0f,-707.0f,1044.0f,-442.0f,-1731.0f,-359.0f,665,-0.3135726f,-0.33990273f,0.5771884f,0f,0f,0f,-12.565606f,0.83606744f,0f ) ;
  }

  @Test
  public void test199() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,329.0f,0f,0f,-340.0f,301.0f,-275.0f,-323.0f,-480.0f,-25.0f,-300.0f,-140.0f,1053.0f,92.0f,991,12.232835f,-12.659614f,1.7348509f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test200() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,33.07378f,0f,0f,-65.700714f,7.2659063f,-33.045044f,0f,-100.0f,-87.02525f,-72.97041f,0.18147881f,0.39960924f,0.060401052f,0,70.586555f,-100.0f,100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test201() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,337.0f,0f,0f,1202.0f,-794.0f,704.0f,-623.0f,-261.0f,-654.0f,-1018.0f,859.0f,-250.0f,19.0f,-1540,0.23131429f,0.28258786f,-0.9233235f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test202() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,34.215412f,0f,0f,-52.57305f,100.0f,-48.3619f,0f,33.943142f,56.82369f,-100.0f,-8.970052f,-16.525146f,-1.2115072f,0,-3.4821863f,-2.553484f,-2.2300336f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test203() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,347.0f,0f,0f,3044.0f,-1290.0f,291.0f,767.0f,-1362.0f,-1386.0f,441.0f,714.0f,514.0f,-1013.0f,-748,-0.6047422f,0.24333017f,-0.5051133f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test204() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,35.0f,0f,0f,1309.0f,-601.0f,-1544.0f,-155.0f,1059.0f,-1069.0f,-906.0f,-1015.0f,906.0f,-1035.0f,1988,-0.13074325f,-0.9635139f,0.034071762f,0f,0f,0f,-43.610897f,-100.0f,0f ) ;
  }

  @Test
  public void test205() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,35.135284f,0f,0f,-65.16711f,11.04842f,77.17649f,0f,7.5247602f,2.603161f,59.86649f,-0.6870792f,-0.12652366f,-0.14525747f,0,0.21716794f,0.44406578f,0.4372235f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test206() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,36.165386f,0f,0f,71.7239f,74.437256f,9.305779f,0f,21.627552f,84.04804f,-15.29189f,-0.36582825f,-0.12476581f,0.8057676f,0,-45.166912f,-63.3914f,-43.259346f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test207() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,391.0f,0f,0f,-1638.0f,-311.0f,-3119.0f,244.0f,438.0f,558.0f,-638.0f,-931.0f,595.0f,115.0f,552,-0.1141021f,-0.8565735f,0.47202703f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test208() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,40.12763f,0f,0f,61.19236f,-61.53324f,41.60856f,0f,36.535316f,98.22671f,100.0f,0.046293944f,0.3076111f,-0.15452681f,0,89.28642f,-74.701904f,10.70199f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test209() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,41.9967f,0f,0f,3.1111543f,-56.407604f,63.64496f,0f,32.145733f,-71.68065f,-28.941721f,-0.5656317f,0.6342238f,0.14287606f,0,5.5266814f,23.03135f,-18.116999f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test210() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,422.0f,0f,0f,-466.0f,1604.0f,2670.0f,-60.0f,-1434.0f,-945.0f,-996.0f,-276.0f,1552.0f,1547.0f,445,-0.0068892157f,0.31911266f,-0.57980096f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test211() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,426.0f,0f,0f,1481.0f,-741.0f,467.0f,857.0f,618.0f,2264.0f,1185.0f,185.0f,-793.0f,267.0f,975,0.0020194137f,-0.00844491f,0.06386899f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test212() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,43.0f,0f,0f,160.0f,477.0f,405.0f,681.0f,-165.0f,-1381.0f,-684.0f,-1597.0f,975.0f,1351.0f,202,0.22315246f,0.6782444f,-1.2637819f,0f,0f,0f,6.030568f,0f,0f ) ;
  }

  @Test
  public void test213() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,43.54831f,0f,0f,-100.0f,-100.0f,-12.420839f,0f,76.80292f,-12.630124f,-37.222805f,-0.8612799f,0.359848f,-0.5799057f,0,-0.5821975f,0.06971969f,-0.19222192f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test214() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,455.0f,0f,0f,439.0f,517.0f,-868.0f,-462.0f,-625.0f,-291.0f,930.0f,-814.0f,-710.0f,-1209.0f,-775,-0.1599754f,-0.5785548f,0.059826106f,0f,0f,0f,-76.779076f,70.65031f,0f ) ;
  }

  @Test
  public void test215() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,47.085815f,0f,0f,-99.64516f,57.50959f,-0.26529065f,0f,-99.97868f,56.948654f,-0.7737216f,-0.25570732f,0.7293636f,0.4125937f,0,100.0f,93.74891f,-86.27185f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test216() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,567.0f,0f,0f,-484.0f,-1094.0f,234.0f,308.0f,131.0f,-696.0f,142.0f,-855.0f,-1265.0f,-36.0f,851,3.2539232f,-0.16472495f,0.27982235f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test217() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,571.0f,0f,0f,62.0f,2594.0f,45.0f,67.0f,955.0f,-83.0f,-242.0f,935.0f,1556.0f,857.0f,-1809,0.81720906f,-1.066348f,0.019561509f,0f,0f,0f,0.87140256f,0f,0f ) ;
  }

  @Test
  public void test218() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,57.61786f,0f,0f,84.72463f,92.28921f,35.185036f,100.0f,-72.96819f,-2.8238266f,22.982603f,0.76328886f,0.38801554f,-0.49010652f,0,-18.522472f,73.64917f,-29.113937f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test219() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,-613.0f,0f,0f,-483.0f,72.0f,-897.0f,-37.0f,-189.0f,501.0f,828.0f,-962.0f,830.0f,-695.0f,929,0.5988536f,-0.36198035f,0.45169577f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test220() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,62.03405f,0f,0f,-57.42364f,68.78062f,100.0f,0f,35.8297f,18.965563f,80.35029f,-0.37327668f,0.4490759f,0.2703761f,0,-28.202002f,-38.56863f,1.8370351f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test221() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,625.0f,0f,0f,-837.0f,-939.0f,573.0f,279.0f,343.0f,1525.0f,-234.0f,300.0f,-2173.0f,-1419.0f,1244,-0.002215803f,1.0253006f,-0.50243f,0f,0f,0f,0f,0.401529f,0f ) ;
  }

  @Test
  public void test222() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,63.0f,0f,0f,-951.0f,150.0f,-692.0f,-1053.0f,-1114.0f,470.0f,-1952.0f,-2473.0f,-1448.0f,217.0f,989,-0.5126945f,-0.48233056f,-0.20747985f,0f,0f,0f,-100.0f,-53.238743f,4.047628f ) ;
  }

  @Test
  public void test223() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,637.0f,0f,0f,-973.0f,2241.0f,-1578.0f,-498.0f,1395.0f,-1285.0f,1996.0f,-960.0f,1734.0f,-1295.0f,654,-0.56907904f,0.24864988f,0.71126926f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test224() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,6.3948846E-14f,0f,0f,-76.246544f,19.971659f,-75.512436f,0f,100.0f,100.0f,174.43372f,-3.8650246f,-0.1663427f,-0.43318665f,0,-100.0f,35.399246f,100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test225() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,645.0f,0f,0f,-673.0f,-519.0f,1677.0f,-372.0f,661.0f,-114.0f,-1236.0f,815.0f,2034.0f,1152.0f,-757,0.4995272f,-0.4839397f,-4.7895007f,0f,0f,0f,-9.464189f,0.39261067f,0f ) ;
  }

  @Test
  public void test226() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,648.0f,0f,0f,-813.0f,390.0f,887.0f,326.0f,1378.0f,823.0f,226.0f,-1108.0f,-1453.0f,511.0f,850,0.8735375f,-0.31466383f,-0.14777476f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test227() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,-65.135925f,0f,0f,-92.92202f,-22.57736f,97.4107f,0f,-100.0f,-99.99781f,-4.2085814f,0.23980719f,0.45884618f,0.09029426f,0,-0.6223003f,0.0495825f,-0.5860395f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test228() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,653.0f,0f,0f,387.0f,-474.0f,452.0f,-831.0f,-973.0f,1425.0f,-407.0f,367.0f,1055.0f,-262.0f,165,-0.21948172f,0.06626868f,0.43358454f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test229() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,65.51712f,0f,0f,-37.097435f,-6.1167665f,-95.92454f,0f,-36.53129f,-6.35309f,-94.67316f,-0.023397626f,-0.44486758f,-0.5933927f,0,-18.492786f,-100.0f,-100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test230() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,684.0f,0f,0f,-619.0f,-2173.0f,-423.0f,-1172.0f,-1421.0f,-777.0f,273.0f,-302.0f,-1554.0f,1117.0f,146,-0.6447261f,-0.078101374f,-0.15564573f,0f,0f,0f,0.37280783f,-100.0f,-63.00601f ) ;
  }

  @Test
  public void test231() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,69.56248f,0f,0f,100.0f,100.0f,-99.99942f,0f,-47.64835f,-61.37294f,-99.99384f,1.1728232f,0.010643983f,0.523729f,0,-0.6513346f,-0.4896778f,0.17794475f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test232() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,715.0f,0f,0f,1348.0f,-920.0f,245.0f,-557.0f,-1720.0f,704.0f,472.0f,694.0f,-154.0f,-1057.0f,374,-0.9486808f,0.0056228316f,-2.6146407f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test233() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,7.1717405f,0f,0f,-3.6506252f,61.73477f,-99.8364f,0f,-3.6335382f,61.5569f,-100.0f,0.6240021f,-0.61007357f,0.13723817f,0,-57.61999f,83.121666f,60.202145f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test234() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,742.0f,0f,0f,1703.0f,1219.0f,1705.0f,854.0f,-881.0f,254.0f,-723.0f,-431.0f,613.0f,2617.0f,-656,0.8348056f,-2.4740288f,-0.2568916f,0f,0f,0f,-100.0f,0.32360476f,0.43965614f ) ;
  }

  @Test
  public void test235() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,761.0f,0f,0f,1172.0f,371.0f,-2038.0f,549.0f,-766.0f,1406.0f,-222.0f,788.0f,-886.0f,157.0f,910,-0.0054017412f,0.23083371f,0.5935631f,0f,0f,0f,-70.395905f,62.816372f,-99.30262f ) ;
  }

  @Test
  public void test236() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,82.05962f,0f,0f,65.32285f,-100.0f,10.3120365f,0f,-100.0f,100.0f,33.903072f,-0.042840917f,0.6401765f,0.5809392f,0,0.3668531f,0.61669904f,-0.134221f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test237() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,85.99776f,0f,0f,-100.0f,-100.0f,-34.598015f,-49.292553f,-94.16138f,-76.26033f,32.951996f,-0.02418613f,-0.360982f,-0.91528237f,0,-13.555818f,-80.2168f,-15.69421f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test238() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,87.53531f,0f,0f,99.78162f,-100.0f,8.849224f,-25.677824f,72.90217f,-100.0f,8.249284f,1.4100094f,-4.310206f,1.4985173f,0,-94.57543f,35.257473f,53.980206f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test239() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,90.43137f,0f,0f,67.7376f,-28.173155f,-100.0f,0f,12.586962f,31.157715f,-95.098305f,0.4652738f,-0.66238946f,0.18878895f,0,-49.450497f,-100.0f,99.589806f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test240() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,929.0f,0f,0f,-495.0f,-317.0f,-841.0f,-162.0f,427.0f,825.0f,566.0f,291.0f,-1589.0f,406.0f,980,-0.033884782f,0.6729945f,0.27383205f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test241() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,93.0f,0f,0f,981.0f,137.0f,721.0f,-42.0f,-646.0f,-956.0f,-498.0f,1268.0f,424.0f,-628.0f,189,-0.3788757f,-0.01456219f,-0.34596244f,0f,0f,0f,-6.2560453f,0f,0f ) ;
  }

  @Test
  public void test242() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,9.338111f,0f,0f,-11.135193f,109.297386f,-158.90018f,0f,97.778984f,-42.69753f,-100.0f,-0.5572464f,0.5139427f,-0.20841895f,0,-30.430267f,171.41678f,74.70775f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test243() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,98.66204f,0f,0f,-100.0f,78.575356f,52.62367f,0f,100.0f,-88.59207f,35.962505f,-0.9405316f,-0.03415365f,-0.09807103f,0,100.0f,-88.133545f,-23.931118f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test244() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,99.33903f,0f,0f,44.11868f,85.10581f,34.088413f,0f,43.984745f,85.41999f,34.9965f,-0.12993789f,-0.2739834f,0.843824f,0,61.99159f,-100.0f,24.47324f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test245() {
    TestDrivers.sphereShade(0f,0f,0f,0f,0f,0f,0f,99.490944f,0f,0f,36.376995f,100.0f,51.098522f,100.0f,-78.9695f,100.0f,-100.0f,0.94316506f,-0.07068867f,2.00272f,0,-86.308365f,73.78273f,100.0f,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test246() {
    TestDrivers.sphereShade(0f,-15.157994f,24.748217f,-11.744434f,0f,0f,0f,62.041473f,0f,0f,-75.46534f,-69.538635f,-43.67841f,-48.120136f,-175.61398f,-185.99782f,-1.021244f,2.2529213f,0.42708713f,0.54927695f,0,121.66163f,-121.5628f,-14.041094f,0f,-0.055948224f,-17.28447f,0f,43.63284f,-60.18824f ) ;
  }

  @Test
  public void test247() {
    TestDrivers.sphereShade(0f,19.786121f,-0.0018692501f,0.009752543f,0f,0f,0f,59.88653f,0f,0f,12.812302f,97.33994f,9.280905f,0f,75.01972f,32.38559f,-100.0f,-0.29555753f,-0.87689775f,-0.36283362f,0,-0.50424576f,0.92232466f,1.4889363f,0f,76.45328f,-20.015953f,0f,0f,0f ) ;
  }

  @Test
  public void test248() {
    TestDrivers.sphereShade(0f,50.388283f,-2.706675f,-100.0f,0f,0f,0f,79.15378f,0f,0f,-100.0f,-72.15764f,100.0f,100.0f,62.695587f,100.0f,100.0f,-1.8693913f,-1.044781f,-1.3704119f,0,100.0f,-100.0f,41.01468f,0f,-100.0f,38.099987f,0f,-79.38172f,-100.0f ) ;
  }

  @Test
  public void test249() {
    TestDrivers.sphereShade(0f,54.26651f,-1.7978544f,-0.0515348f,0f,0f,0f,52.248924f,0f,0f,17.926422f,-100.0f,61.49662f,36.48599f,-42.819477f,59.75058f,-100.0f,0.051072907f,-0.4129683f,0.34068325f,0,-41.453197f,-100.0f,98.13049f,0f,-37.27609f,-5.830825f,0f,100.0f,7.5171223f ) ;
  }

  @Test
  public void test250() {
    TestDrivers.sphereShade(0f,-59.086136f,0f,-12.908674f,0f,0f,0f,19.463842f,0f,0f,58.990154f,-20.995272f,-51.910156f,0f,-100.0f,21.606672f,100.0f,-0.20659202f,-0.7707396f,0.50003254f,0,-0.55282485f,0.24704422f,0.75763744f,0f,24.504026f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test251() {
    TestDrivers.sphereShade(0f,-6.2185407f,-105.4715f,-0.0016080943f,0f,0f,0f,1.4210855E-14f,0f,0f,81.503075f,100.0f,-46.197178f,31.32615f,-100.0f,100.0f,-51.783463f,0.2466445f,1.071901f,-0.15434161f,0,-12.012683f,96.654976f,75.06343f,0f,100.0f,0.7814768f,0f,21.450575f,-26.080029f ) ;
  }

  @Test
  public void test252() {
    TestDrivers.sphereShade(0f,6.2930164f,0f,-0.11161673f,0f,0f,0f,79.85647f,0f,0f,3.958046f,-17.886744f,-51.6786f,0f,-10.125144f,23.633469f,28.61554f,-1.2506623f,-1.3443938f,2.2959871f,0,0.18010686f,-0.50021714f,-0.07779307f,0f,-1.5569446f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test253() {
    TestDrivers.sphereShade(0f,-63.196526f,-100.0f,-5.3874364f,0f,0f,0f,10.468612f,0f,0f,30.163755f,5.933068f,-28.02651f,0f,-94.605316f,99.99887f,100.0f,-0.14408702f,0.5426705f,-0.085532345f,0,-0.10434638f,-0.42992344f,0.1141337f,0f,-99.82461f,-77.0236f,0f,0f,0f ) ;
  }

  @Test
  public void test254() {
    TestDrivers.sphereShade(0f,-66.178246f,0f,-100.0f,0f,0f,0f,88.78121f,0f,0f,-45.6613f,71.54186f,18.129023f,-77.67517f,-98.18567f,-6.4165783f,-93.10679f,0.7034044f,-0.11125546f,0.13253193f,0,-77.97554f,-74.41985f,31.264967f,0f,71.6485f,0f,0f,-31.490242f,0f ) ;
  }

  @Test
  public void test255() {
    TestDrivers.sphereShade(0f,6.673289E-5f,-3.0802877E-4f,99.999664f,0f,0f,0f,4.9636045f,0f,0f,74.718666f,-9.545724f,-100.0f,80.764656f,41.62903f,-8.205828f,44.718113f,-1.3412579f,-0.6752917f,-0.39618608f,0,3.270663f,-47.27087f,85.54582f,0f,-99.999794f,-67.425835f,0f,81.38408f,-100.0f ) ;
  }

  @Test
  public void test256() {
    TestDrivers.sphereShade(0f,-69.49976f,68.21266f,1.4287488E-4f,0f,0f,0f,100.0f,0f,0f,1.317411f,-100.0f,52.420887f,0f,-76.45481f,56.4519f,99.89055f,-0.2728716f,-0.33989814f,0.8308479f,0,-0.14220597f,-0.032527667f,-0.98230475f,0f,-100.0f,70.218346f,0f,0f,0f ) ;
  }

  @Test
  public void test257() {
    TestDrivers.sphereShade(0f,76.34145f,0f,67.6146f,0f,0f,0f,41.917686f,0f,0f,-23.975294f,30.851849f,-12.521781f,0f,-95.36696f,61.348026f,-15.510653f,0.07790322f,0.39147085f,0.21077776f,0,0.5116938f,-0.77329487f,0.2993356f,0f,1.293163E-4f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test258() {
    TestDrivers.sphereShade(0f,-87.740395f,-72.587234f,100.0f,0f,0f,0f,53.646217f,0f,0f,98.15261f,60.250904f,97.57007f,0f,43.32301f,-27.921213f,-75.05742f,-0.75528264f,-0.5086508f,-0.6701207f,0,-0.16766627f,0.5846442f,0.28880426f,0f,-99.70904f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test259() {
    TestDrivers.sphereShade(0f,97.83507f,0f,100.0f,0f,0f,0f,15.885652f,0f,0f,-5.1666803f,76.926125f,-100.0f,-26.951479f,-98.88425f,-5.5624537f,26.461193f,-0.24798357f,1.9957783f,0.14021106f,0,-100.0f,100.0f,-88.53307f,0f,-2.6550279f,0f,0f,98.28982f,0f ) ;
  }

  @Test
  public void test260() {
    TestDrivers.sphereShade(-100.0f,-0.52224475f,-17.145546f,21.7946f,0f,0f,0f,-27.238487f,0f,0f,96.51408f,-77.34895f,13.699654f,0f,-100.0f,95.74796f,97.765854f,0.27876323f,0.34636307f,0.7560474f,0,98.86261f,-86.023254f,-53.558113f,94.301636f,-34.631615f,12.875478f,0f,0f,0f ) ;
  }

  @Test
  public void test261() {
    TestDrivers.sphereShade(-100.0f,0f,0f,100.0f,0f,0f,0f,100.0f,0f,0f,100.0f,100.0f,100.0f,0f,100.0f,87.064766f,100.0f,0.37303734f,-0.098304704f,0.15098171f,0,-48.96939f,-100.0f,-100.0f,17.445879f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test262() {
    TestDrivers.sphereShade(100.0f,0f,0f,-100.0f,0f,0f,0f,100.0f,0f,0f,14.974672f,63.606346f,37.571568f,56.28701f,77.19335f,65.16489f,99.82556f,-0.10841878f,0.10354203f,-1.6410131f,0,32.506252f,-3.243961f,-23.479292f,100.0f,0f,0f,15.163551f,0f,0f ) ;
  }

  @Test
  public void test263() {
    TestDrivers.sphereShade(100.0f,0f,0f,100.0f,0f,0f,0f,-93.58789f,0f,0f,18.874746f,-41.914032f,-100.0f,0f,-29.870153f,100.0f,-25.323471f,-0.23199277f,-0.8685121f,-0.049841445f,0,-0.5395555f,-0.19788967f,0.7991037f,100.0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test264() {
    TestDrivers.sphereShade(100.0f,0f,0f,-20.967571f,0f,0f,0f,100.0f,0f,0f,100.0f,-99.125496f,-34.205666f,87.66033f,-52.3428f,27.316738f,-35.14872f,-0.06525446f,-0.47103682f,-0.8336365f,0,-100.0f,-24.874872f,100.0f,-58.720978f,0f,0f,-97.40084f,0f,0f ) ;
  }

  @Test
  public void test265() {
    TestDrivers.sphereShade(-100.0f,0f,0f,3.2352781f,0f,0f,0f,100.0f,0f,0f,83.53519f,63.590405f,100.0f,0f,-100.0f,99.20829f,-93.10025f,-0.39102012f,-0.8387151f,-0.0063928096f,0,-96.0389f,100.0f,-100.0f,-0.0030909244f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test266() {
    TestDrivers.sphereShade(-100.0f,0f,0f,43.126907f,0f,0f,0f,0.0f,0f,0f,92.97766f,100.0f,-100.0f,0f,-45.616463f,100.0f,-78.51866f,0.034639306f,-0.29039603f,0.09655464f,0,98.193985f,51.184296f,-30.523464f,11.194895f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test267() {
    TestDrivers.sphereShade(100.0f,0f,0f,-49.68288f,0f,0f,0f,-100.0f,0f,0f,-12.565911f,-100.0f,100.0f,0f,-12.240063f,-100.0f,99.52928f,0.100370236f,0.1419726f,-0.32289028f,0,100.0f,-1.7186322f,86.63623f,-20.69152f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test268() {
    TestDrivers.sphereShade(-100.0f,0f,0f,8.435395f,0f,0f,0f,0.0f,0f,0f,2.9968684f,-10.354529f,-34.469437f,0f,3.6096199f,-9.749712f,-34.86766f,-0.21339649f,-0.2384201f,0.5296323f,0,-5.987072f,41.126736f,7.975929f,100.0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test269() {
    TestDrivers.sphereShade(-100.0f,100.0f,0.25910914f,1.5779932f,0f,0f,0f,80.95525f,0f,0f,-15.836491f,-10.134271f,100.0f,0f,100.0f,100.0f,-0.55854386f,-0.19558455f,0.76110506f,-0.18996917f,0,-66.50762f,-3.5243523f,100.0f,8.295034f,39.59729f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test270() {
    TestDrivers.sphereShade(-100.0f,-100.0f,0f,0.0012016289f,0f,0f,0f,-100.0f,0f,0f,-3.8092759f,38.46409f,-99.69598f,0f,-79.20971f,-56.570168f,-100.0f,-0.40343076f,0.6424466f,0.026020525f,0,-0.54592496f,-0.63814783f,-0.42476547f,-8.322037f,-100.0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test271() {
    TestDrivers.sphereShade(100.0f,100.0f,0f,-100.0f,0f,0f,0f,99.98995f,0f,0f,100.0f,100.0f,-100.0f,0f,-100.0f,100.0f,-100.0f,-0.42068693f,0.024789266f,-0.52989584f,0,99.999405f,-100.0f,-100.0f,100.0f,40.23339f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test272() {
    TestDrivers.sphereShade(100.0f,100.0f,0f,-1.0E-4f,0f,0f,0f,80.9272f,0f,0f,100.0f,71.45139f,100.0f,0f,100.0f,100.0f,21.547583f,0.06562972f,-0.00516043f,-0.64999986f,0,-100.0f,100.0f,-100.0f,100.0f,-100.0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test273() {
    TestDrivers.sphereShade(-100.0f,100.0f,0f,16.811136f,0f,0f,0f,-81.28164f,0f,0f,-35.01377f,42.542336f,100.0f,0f,-34.81397f,42.52738f,100.0f,0.76376736f,-0.41035813f,-0.31321648f,0,-17.20602f,-52.63408f,-16.678272f,61.917576f,65.724335f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test274() {
    TestDrivers.sphereShade(100.0f,-100.0f,0f,2.2137348E-4f,0f,0f,0f,100.0f,0f,0f,-100.0f,100.0f,-30.282972f,0f,-100.0f,-100.0f,100.0f,0.5120623f,-0.3281032f,0.091105916f,0,-100.0f,68.768456f,100.0f,-100.0f,-100.0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test275() {
    TestDrivers.sphereShade(-100.0f,-100.0f,100.0f,-1.0E-4f,0f,0f,0f,-7.071479f,0f,0f,80.11027f,100.0f,-72.097725f,0f,-20.592249f,23.278006f,100.0f,-0.51032144f,0.029415019f,0.50417477f,0,100.0f,10.365062f,61.510197f,100.0f,100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test276() {
    TestDrivers.sphereShade(-100.0f,100.0f,-100.0f,1.0E-4f,0f,0f,0f,-84.32915f,0f,0f,1.7230221f,73.42421f,99.99999f,0f,99.997635f,-79.09717f,-100.0f,-0.20484224f,0.89243037f,0.03612081f,0,-0.13658944f,0.62834674f,0.12144515f,-46.137466f,100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test277() {
    TestDrivers.sphereShade(100.0f,-100.0f,-100.0f,-2.4054453E-4f,0f,0f,0f,91.37646f,0f,0f,-100.0f,-100.0f,-100.0f,0f,-100.0f,-35.83284f,-100.0f,0.40320927f,0.42707434f,0.57187545f,0,100.0f,100.0f,-3.1813717f,86.39279f,53.842304f,41.572346f,0f,0f,0f ) ;
  }

  @Test
  public void test278() {
    TestDrivers.sphereShade(-100.0f,-100.0f,-1.3126186f,-100.0f,0f,0f,0f,-98.18756f,0f,0f,-72.530334f,100.0f,75.96641f,0f,28.208708f,100.0f,3.02182f,0.2125623f,-0.46411887f,0.66572255f,0,0.56465846f,-0.32735506f,0.42302725f,-100.0f,-26.948421f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test279() {
    TestDrivers.sphereShade(100.0f,-100.0f,-47.762997f,-2.0936709E-4f,0f,0f,0f,0.0f,0f,0f,100.0f,8.340399f,-59.820892f,0f,-100.0f,35.135082f,100.0f,-0.065686636f,0.3331961f,0.5510686f,0,-65.09617f,-100.0f,100.0f,-100.0f,-100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test280() {
    TestDrivers.sphereShade(-100.0f,-100.0f,-56.853115f,2.192967E-4f,0f,0f,0f,-7.554145f,0f,0f,77.658264f,57.524033f,-100.0f,0f,-100.0f,-15.088591f,-47.666798f,0.4261626f,-0.08169072f,0.19946618f,0,-0.5098357f,-0.45963672f,-0.6957987f,-67.00709f,0.24849425f,-80.20725f,0f,0f,0f ) ;
  }

  @Test
  public void test281() {
    TestDrivers.sphereShade(-100.0f,-100.0f,-68.079865f,-30.467775f,0f,0f,0f,-69.130806f,0f,0f,-98.5079f,-85.88282f,-100.0f,0f,-99.01449f,-85.55415f,-100.0f,0.5673484f,0.23575829f,0.67342687f,0,-15.33046f,-100.0f,99.10773f,34.675438f,62.410217f,-96.86223f,0f,0f,0f ) ;
  }

  @Test
  public void test282() {
    TestDrivers.sphereShade(-100.0f,100.0f,89.75597f,7.532234f,0f,0f,0f,0.0f,0f,0f,86.048874f,100.0f,-100.0f,0f,-38.801872f,100.0f,55.50276f,-0.8192443f,-0.49491924f,-0.2564059f,0,12.2189245f,-99.35961f,94.35022f,-83.28955f,-14.692741f,-11.099874f,0f,0f,0f ) ;
  }

  @Test
  public void test283() {
    TestDrivers.sphereShade(-100.0f,-100.0f,93.350136f,4.1492243f,0f,0f,0f,0.0f,0f,0f,-25.00167f,87.961006f,-55.2127f,0f,18.642344f,-93.53933f,-60.054325f,-0.69894755f,-0.26055485f,-0.22178124f,0,100.0f,-78.67147f,100.0f,1.7201825f,-48.60388f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test284() {
    TestDrivers.sphereShade(-100.0f,100.0f,-98.83531f,-1.9555271E-4f,0f,0f,0f,-100.0f,0f,0f,-81.23066f,-58.786903f,-99.99998f,0f,-69.02861f,27.170979f,-28.299887f,-0.14926359f,0.40405977f,0.6697876f,0,-100.0f,-17.653093f,-20.265642f,40.231384f,-51.137108f,82.371574f,0f,0f,0f ) ;
  }

  @Test
  public void test285() {
    TestDrivers.sphereShade(-100.0f,1.2533569E-4f,100.0f,-100.0f,0f,0f,0f,-100.0f,0f,0f,-27.469503f,100.0f,-56.469357f,0f,-100.0f,-64.300125f,-100.0f,0.71863747f,-0.6056902f,-0.1680471f,0,-74.615974f,0.6409364f,8.657721f,100.0f,-54.52446f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test286() {
    TestDrivers.sphereShade(-100.0f,1.3678575f,0f,-9.02542f,0f,0f,0f,63.712734f,0f,0f,-67.575005f,-35.84654f,-34.692123f,0f,-100.0f,-100.0f,74.585236f,-0.03955204f,-0.33494097f,0.1295441f,0,16.743519f,66.96316f,64.564926f,41.550533f,0.6018413f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test287() {
    TestDrivers.sphereShade(-100.0f,-1.4714675E-4f,0f,-77.124115f,0f,0f,0f,100.0f,0f,0f,78.73029f,-15.98417f,-75.00199f,0f,79.106155f,-16.728542f,-74.49438f,-0.078687474f,-0.10597535f,0.0049387557f,0,89.46356f,-29.696302f,4.083928f,-24.04703f,98.61674f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test288() {
    TestDrivers.sphereShade(100.0f,16.79665f,0f,95.57697f,0f,0f,0f,0.0f,0f,0f,29.36841f,98.47118f,-55.004368f,0f,48.35461f,100.0f,-54.071495f,-0.033886652f,0.20422556f,-0.17535055f,0,11.810277f,5.6819654f,-100.0f,-25.038788f,-0.5714905f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test289() {
    TestDrivers.sphereShade(-100.0f,22.25085f,100.0f,9.0870896E-4f,0f,0f,0f,-100.0f,0f,0f,65.78892f,100.0f,18.702124f,0f,-47.26885f,-100.0f,-100.0f,-0.13403526f,-0.33523774f,-0.15962094f,0,-0.66590834f,-38.048134f,-100.0f,-14.110639f,49.457092f,74.70633f,0f,0f,0f ) ;
  }

  @Test
  public void test290() {
    TestDrivers.sphereShade(-100.0f,-25.3367f,0f,6.9950633f,0f,0f,0f,0.0f,0f,0f,19.188972f,63.392387f,-100.0f,0f,-72.532524f,-31.492495f,-100.0f,0.7346925f,-0.0054732156f,-0.24303666f,0,4.9439287f,-21.484774f,-67.180244f,-100.0f,53.230354f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test291() {
    TestDrivers.sphereShade(100.0f,25.781408f,-33.22137f,-13.506872f,0f,0f,0f,0.0f,0f,0f,48.676228f,44.81633f,-15.626488f,0f,11.438271f,44.810867f,37.985725f,-0.66329825f,0.46110472f,-0.19362113f,0,-19.9832f,-8.066027f,-1.6984091f,0.8545742f,-0.0028716968f,-42.87714f,0f,0f,0f ) ;
  }

  @Test
  public void test292() {
    TestDrivers.sphereShade(-100.0f,-25.96372f,0f,-90.93292f,0f,0f,0f,-100.0f,0f,0f,92.66704f,100.0f,100.0f,0f,100.0f,100.0f,1.8999268f,-0.9062585f,0.102161966f,-0.10049674f,0,0.7042849f,0.6747668f,-0.1936671f,70.24927f,0.054687347f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test293() {
    TestDrivers.sphereShade(-100.0f,-27.109833f,0.21885684f,-0.16247265f,0f,0f,0f,0.0f,0f,0f,-56.86279f,-28.6149f,19.038292f,0f,-42.50176f,99.19393f,52.55703f,0.25725374f,-0.02540389f,0.8065875f,0,52.94968f,-74.32432f,97.07237f,96.333115f,39.9302f,-28.122868f,0f,0f,0f ) ;
  }

  @Test
  public void test294() {
    TestDrivers.sphereShade(100.0f,30.778088f,42.63273f,1.261733E-4f,0f,0f,0f,1.7326117E-17f,0f,0f,-100.0f,-14.735087f,39.086044f,0f,-56.199665f,28.274982f,-23.29444f,0.31624034f,-0.12508434f,0.44837406f,0,70.784065f,-84.20727f,100.0f,78.08921f,65.46275f,184.16225f,0f,0f,0f ) ;
  }

  @Test
  public void test295() {
    TestDrivers.sphereShade(-100.0f,-3.4650362f,0f,0.10632504f,0f,0f,0f,100.0f,0f,0f,100.0f,100.0f,-47.15176f,0f,-100.0f,64.98705f,-44.640118f,-0.41257074f,0.15208341f,-0.09004867f,0,-99.89184f,-0.86427534f,-39.05336f,-97.05139f,-2.7142928f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test296() {
    TestDrivers.sphereShade(100.0f,-37.96105f,100.0f,5.7193646f,0f,0f,0f,0.0f,0f,0f,-48.90927f,20.521748f,-36.154842f,0f,-48.097595f,20.840675f,-36.441254f,-0.03850259f,-0.6952384f,-0.22626343f,0,-19.101833f,38.514618f,59.027493f,-100.0f,8.954177f,-48.99506f,0f,0f,0f ) ;
  }

  @Test
  public void test297() {
    TestDrivers.sphereShade(100.0f,39.625088f,-79.314964f,-0.0012185557f,0f,0f,0f,1.7763568E-15f,0f,0f,100.0f,38.28867f,-20.758942f,0f,25.450613f,100.0f,-48.635803f,-0.08010844f,-0.010905349f,-0.71514493f,0,100.0f,-85.274635f,-14.564882f,48.495747f,-20.710203f,10.346643f,0f,0f,0f ) ;
  }

  @Test
  public void test298() {
    TestDrivers.sphereShade(100.0f,45.44807f,-17.466818f,-0.0012238293f,0f,0f,0f,0.0f,0f,0f,100.0f,1.470262f,-69.168045f,0f,76.32966f,-69.48533f,-16.750366f,-0.67033046f,0.5050397f,-0.48094043f,0,-100.0f,100.0f,0.5497099f,-85.89352f,-17.978924f,46.78055f,0f,0f,0f ) ;
  }

  @Test
  public void test299() {
    TestDrivers.sphereShade(100.0f,45.66109f,-100.0f,-4.528639E-4f,0f,0f,0f,0.0f,0f,0f,-98.81468f,2.3810804f,-66.0688f,0f,-23.691818f,88.21842f,49.07648f,0.60468966f,0.268884f,-0.15850993f,0,0.35177064f,-0.98175764f,0.19846033f,-100.0f,-80.44861f,99.99715f,0f,0f,0f ) ;
  }

  @Test
  public void test300() {
    TestDrivers.sphereShade(-100.0f,45.666695f,0f,-1.8230776E-4f,0f,0f,0f,8.365257f,0f,0f,32.259853f,-99.37055f,-100.0f,0f,32.10937f,-98.929565f,-100.0f,-0.72425634f,0.16045617f,1.4655981f,0,36.92574f,59.451797f,100.0f,-82.10403f,-86.684586f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test301() {
    TestDrivers.sphereShade(100.0f,-48.505104f,93.36264f,4.4362215E-4f,0f,0f,0f,-88.867516f,0f,0f,52.45834f,100.0f,62.512383f,0f,-26.547752f,-86.54514f,55.007298f,-0.380208f,0.5725458f,-0.66751266f,0,-37.84774f,-26.516867f,99.33284f,92.308266f,-46.472855f,24.144247f,0f,0f,0f ) ;
  }

  @Test
  public void test302() {
    TestDrivers.sphereShade(100.0f,-49.158092f,-10.116142f,15.389214f,0f,0f,0f,-32.217514f,0f,0f,84.77457f,-34.151722f,46.973312f,0f,31.779152f,30.849203f,-98.904205f,-0.24950793f,-0.07369902f,0.27279344f,0,100.0f,16.927582f,63.92177f,27.767859f,6.8254237f,-99.078835f,0f,0f,0f ) ;
  }

  @Test
  public void test303() {
    TestDrivers.sphereShade(-100.0f,-51.478355f,69.921616f,0.0023030376f,0f,0f,0f,100.0f,0f,0f,-100.0f,-70.18934f,-100.0f,0f,-75.23846f,-14.332315f,-100.0f,0.011371677f,0.3866651f,0.9166598f,0,-100.0f,73.13869f,33.775215f,100.0f,-8.434791f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test304() {
    TestDrivers.sphereShade(-100.0f,55.955967f,43.581413f,-28.507658f,0f,0f,0f,-11.518206f,0f,0f,100.0f,-112.57537f,93.36906f,0f,93.25633f,80.21264f,-8.467802f,0.27640378f,-0.38332024f,-0.03747289f,0,44.05744f,100.0f,17.771896f,93.20033f,-27.36426f,-84.486534f,0f,0f,0f ) ;
  }

  @Test
  public void test305() {
    TestDrivers.sphereShade(-100.0f,60.12786f,6.9932327f,-0.0014300356f,0f,0f,0f,0.0f,0f,0f,-62.074356f,-100.0f,100.0f,0f,20.608915f,99.123375f,100.0f,0.62320936f,-0.6909912f,-0.20755246f,0,-0.19610602f,-0.8891722f,-0.21425982f,31.131464f,-100.0f,-99.994286f,0f,0f,0f ) ;
  }

  @Test
  public void test306() {
    TestDrivers.sphereShade(100.0f,67.299416f,-100.0f,-0.032524176f,0f,0f,0f,-13.333361f,0f,0f,40.535442f,-76.45097f,-100.0f,0f,100.0f,-99.90143f,98.84801f,-0.40526146f,-0.4879036f,0.5015678f,0,-31.347378f,28.112196f,100.0f,-66.18724f,-7.631856f,0.30746362f,0f,0f,0f ) ;
  }

  @Test
  public void test307() {
    TestDrivers.sphereShade(100.0f,-75.30633f,-61.01293f,2.5890712E-4f,0f,0f,0f,-63.82406f,0f,0f,-100.0f,51.81098f,-2.8636613f,0f,64.89136f,100.0f,97.38206f,-0.6072731f,-0.24723125f,0.5809839f,0,0.2595547f,-0.5870758f,0.13690941f,60.74124f,-51.289032f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test308() {
    TestDrivers.sphereShade(-100.0f,77.01054f,-209.25099f,-0.002520903f,0f,0f,0f,-120.86457f,0f,0f,47.706917f,-98.2423f,-55.703457f,0f,-94.140526f,121.031586f,100.0f,-0.24913672f,0.017958466f,-0.005247689f,0,100.0f,40.531437f,-93.259026f,3.9668326f,93.54531f,1.8628211f,0f,0f,0f ) ;
  }

  @Test
  public void test309() {
    TestDrivers.sphereShade(100.0f,85.78053f,-69.604164f,-1.4117529E-4f,0f,0f,0f,0.0f,0f,0f,100.0f,-64.1904f,-100.0f,0f,50.3835f,-5.807706f,4.6052737f,0.45256f,0.7311002f,0.3052723f,0,-41.253548f,-98.12831f,-77.70705f,-77.65683f,-82.57576f,-99.6408f,0f,0f,0f ) ;
  }

  @Test
  public void test310() {
    TestDrivers.sphereShade(100.0f,93.16649f,-19.892282f,0.04728287f,0f,0f,0f,0.0f,0f,0f,-20.564747f,100.0f,-70.06794f,0f,85.838585f,-96.33505f,100.0f,-0.47323143f,0.6904849f,0.37508774f,0,-0.0064599337f,62.945206f,100.0f,0.21149309f,71.77239f,94.34737f,0f,0f,0f ) ;
  }

  @Test
  public void test311() {
    TestDrivers.sphereShade(-100.0f,-9.548314f,0f,-100.0f,0f,0f,0f,-97.87637f,0f,0f,79.98479f,75.19689f,28.31335f,0f,79.43647f,75.58481f,28.857483f,0.19162227f,-0.9614274f,-0.19660713f,0,-85.275604f,-96.43336f,47.62164f,100.0f,62.31648f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test312() {
    TestDrivers.sphereShade(-100.0f,96.66418f,-70.364426f,1.4806309E-4f,0f,0f,0f,-47.154522f,0f,0f,-98.84781f,-100.0f,-20.390581f,0f,-51.165215f,19.48002f,-10.608212f,-0.14812097f,-0.4217906f,0.055262994f,0,-95.59088f,-50.37751f,64.467255f,100.0f,100.0f,-95.98426f,0f,0f,0f ) ;
  }

  @Test
  public void test313() {
    TestDrivers.sphereShade(-100.0f,-99.83519f,8.1111974E-4f,-31.504597f,0f,0f,0f,15.476948f,0f,0f,15.335818f,-45.11868f,52.060654f,0f,16.839153f,-45.531883f,52.2639f,0.29505748f,-0.3879792f,0.545554f,0,97.41669f,3.378202f,-8.581305f,-32.45081f,-6.5170026f,-39.188766f,0f,0f,0f ) ;
  }

  @Test
  public void test314() {
    TestDrivers.sphereShade(-100.0f,99.999916f,-26.204416f,3.8161507E-4f,0f,0f,0f,43.775997f,0f,0f,-51.694218f,2.9313602f,-99.29553f,0f,100.0f,-12.365263f,100.0f,-0.14117417f,0.02088747f,0.43960023f,0,-1.9932323f,19.677383f,-100.0f,-37.958755f,-100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test315() {
    TestDrivers.sphereShade(1.0291043E-4f,-100.0f,0f,97.17188f,0f,0f,0f,-49.42879f,0f,0f,-32.10564f,-31.845411f,-63.03094f,0f,100.0f,31.323385f,-63.731796f,-0.2746603f,0.02340699f,-0.045614373f,0,100.0f,33.864433f,13.144866f,100.0f,73.96608f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test316() {
    TestDrivers.sphereShade(10.4151f,0.18243363f,0f,-0.05481445f,0f,0f,0f,-8.881784E-16f,0f,0f,-42.871727f,-29.462696f,76.51129f,0f,-40.93372f,-28.883738f,77.41722f,0.6641783f,-0.09484293f,-0.44650802f,0,100.0f,6.0463634f,-84.869995f,-0.652148f,-100.0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test317() {
    TestDrivers.sphereShade(106.07077f,65.17079f,-100.0f,3.1617837E-4f,0f,0f,0f,93.34765f,0f,0f,99.90247f,-28.718327f,62.424515f,0f,-100.0f,58.97904f,100.0f,-0.57699656f,0.018160215f,-0.34209666f,0,27.298576f,-12.53451f,-33.640858f,100.0f,48.530506f,-65.292564f,0f,0f,0f ) ;
  }

  @Test
  public void test318() {
    TestDrivers.sphereShade(-10.659314f,90.49747f,-22.858505f,-0.0014080766f,0f,0f,0f,100.0f,0f,0f,-100.0f,-100.0f,100.0f,0f,-50.73507f,99.95568f,40.655857f,0.13409686f,0.12244156f,0.3699351f,0,-41.21062f,-100.0f,99.905014f,66.62611f,-11.692901f,-25.558243f,0f,0f,0f ) ;
  }

  @Test
  public void test319() {
    TestDrivers.sphereShade(-1.0758119f,-84.650505f,-88.95438f,14.620966f,0f,0f,0f,0.0f,0f,0f,22.83455f,62.583496f,99.96612f,0f,-81.90652f,-7.943583f,-100.0f,0.29175162f,-0.5069207f,0.6581429f,0,0.09221234f,-1.5457547f,-0.39579374f,0.9812986f,4.677997f,-0.0015137414f,0f,0f,0f ) ;
  }

  @Test
  public void test320() {
    TestDrivers.sphereShade(-10.914949f,28.39552f,-43.03679f,9.164509E-4f,0f,0f,0f,14.064065f,0f,0f,99.94098f,39.735844f,-47.228905f,0f,-45.871002f,99.96804f,100.0f,-0.07746704f,0.513153f,0.66148746f,0,-15.239417f,-59.419243f,-42.47172f,-99.96985f,-78.64049f,-25.354258f,0f,0f,0f ) ;
  }

  @Test
  public void test321() {
    TestDrivers.sphereShade(11.06619f,37.364265f,-21.93614f,-0.0021648249f,0f,0f,0f,-95.113976f,0f,0f,37.528687f,100.0f,47.83637f,0f,62.56073f,-29.627623f,-17.718925f,-0.3703813f,0.69998777f,-0.029052561f,0,-36.11555f,91.0487f,-13.059492f,-41.742565f,-43.771107f,24.41229f,0f,0f,0f ) ;
  }

  @Test
  public void test322() {
    TestDrivers.sphereShade(-11.31797f,-93.69104f,-78.669304f,0.0012090054f,0f,0f,0f,-80.77403f,0f,0f,-57.48899f,-16.914501f,63.296104f,0f,-53.223885f,83.811066f,-4.4866257f,-0.1088585f,0.09551936f,0.5981326f,0,-0.18701388f,0.06079016f,0.8471972f,-73.08079f,-43.3513f,-99.95393f,0f,0f,0f ) ;
  }

  @Test
  public void test323() {
    TestDrivers.sphereShade(-11.365454f,99.978905f,86.77767f,-8.8530383E-4f,0f,0f,0f,-38.108738f,0f,0f,82.03281f,-100.0f,13.993319f,0f,-5.439535f,-100.0f,100.0f,-0.14203115f,0.54436076f,-0.80867565f,0,-0.7986257f,0.048827153f,-0.31339094f,99.38501f,-12.739173f,-7.873907f,0f,0f,0f ) ;
  }

  @Test
  public void test324() {
    TestDrivers.sphereShade(-11.545872f,-93.07759f,-47.869976f,-0.0019530513f,0f,0f,0f,70.34093f,0f,0f,38.132168f,32.59899f,38.070972f,0f,57.5571f,14.836923f,57.273785f,0.17726931f,-0.005814906f,0.9408609f,0,-68.6486f,22.039036f,-31.329845f,44.346527f,-99.9985f,39.645233f,0f,0f,0f ) ;
  }

  @Test
  public void test325() {
    TestDrivers.sphereShade(1.1558326f,-52.483677f,0f,-0.08659885f,0f,0f,0f,0.0f,0f,0f,31.854235f,-100.0f,-100.0f,0f,-99.99991f,99.6208f,90.18915f,-0.6089877f,-0.52206063f,0.10897683f,0,76.85301f,-100.0f,-100.0f,-9.990631f,9.143824f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test326() {
    TestDrivers.sphereShade(-11.660893f,53.952713f,-29.067549f,-4.9981417E-4f,0f,0f,0f,-32.426323f,0f,0f,-100.0f,-66.70912f,100.0f,0f,100.0f,-100.0f,80.22381f,0.1964745f,0.026023086f,-0.4102416f,0,-0.7694719f,0.25059652f,-0.20707794f,65.70508f,-100.0f,68.42797f,0f,0f,0f ) ;
  }

  @Test
  public void test327() {
    TestDrivers.sphereShade(11.758843f,0f,0f,-45.119473f,0f,0f,0f,-97.36643f,0f,0f,47.208256f,14.11929f,-43.222f,0f,46.588448f,14.320204f,-43.29277f,-0.5160531f,0.5116753f,0.5388554f,0,76.369064f,45.368267f,6.884112f,100.0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test328() {
    TestDrivers.sphereShade(12.363077f,0f,0f,2.630761f,0f,0f,0f,-99.51412f,0f,0f,53.18206f,-58.157608f,-37.094913f,0f,-57.085323f,18.280508f,10.207155f,-0.15419225f,0.28541997f,0.4740445f,0,100.0f,67.283f,-18.041782f,97.03646f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test329() {
    TestDrivers.sphereShade(-13.3047905f,86.81134f,0f,0.0015491177f,0f,0f,0f,12.804791f,0f,0f,78.16092f,-23.268908f,-99.42596f,0f,26.698809f,75.73376f,22.403095f,0.3617624f,-0.43713862f,0.7292174f,0,-18.16297f,37.073338f,-20.04299f,-48.518517f,7.5380898f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test330() {
    TestDrivers.sphereShade(13.678587f,-2.6554122f,0.0010137989f,-22.336233f,0f,0f,0f,59.195534f,0f,0f,-95.33681f,-63.5686f,-20.173609f,0f,-96.47788f,-1.2356166f,19.525099f,-0.18334633f,-0.30449185f,0.76882994f,0,-30.16911f,49.779762f,-47.25758f,-49.046238f,0.017155636f,-44.160934f,0f,0f,0f ) ;
  }

  @Test
  public void test331() {
    TestDrivers.sphereShade(-1.438193f,-0.6144101f,0f,-86.49871f,0f,0f,0f,0.0f,0f,0f,5.295224f,62.293816f,-71.72997f,0f,5.1124377f,61.981216f,-70.96767f,-0.27199286f,0.26946414f,0.724487f,0,80.77407f,-100.0f,9.7422f,0.028519643f,-72.67122f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test332() {
    TestDrivers.sphereShade(14.564788f,-98.26195f,0f,-95.26407f,0f,0f,0f,-1.4210855E-14f,0f,0f,68.046104f,87.72288f,46.35697f,0f,16.138714f,100.0f,100.0f,-0.23525204f,-0.08036506f,-0.84539926f,0,90.42525f,47.119343f,-20.749645f,-100.0f,24.013077f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test333() {
    TestDrivers.sphereShade(15.277789f,0f,0f,15.16557f,0f,0f,0f,-38.496834f,0f,0f,98.52555f,63.174744f,99.76816f,0f,83.9402f,-49.524616f,34.664642f,-0.46856457f,0.3117732f,0.17017744f,0,-0.46631503f,-0.3913652f,0.09824826f,-65.75954f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test334() {
    TestDrivers.sphereShade(-15.575942f,-8.844383f,0f,0.002825596f,0f,0f,0f,-50.614796f,0f,0f,-25.49111f,90.62516f,77.45115f,0f,-45.71167f,18.003946f,78.85177f,0.058633637f,0.4772018f,-0.37699372f,0,0.23450513f,-0.8307989f,0.1594062f,-6.573239f,-40.014957f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test335() {
    TestDrivers.sphereShade(-15.824009f,80.80037f,-42.798977f,-7.433769E-4f,0f,0f,0f,0.0f,0f,0f,29.698833f,11.405356f,-99.74309f,0f,13.084088f,-31.553913f,-100.0f,0.6973259f,-0.41719705f,-0.44775042f,0,99.724236f,-52.731846f,-14.917957f,85.010864f,26.594765f,31.430954f,0f,0f,0f ) ;
  }

  @Test
  public void test336() {
    TestDrivers.sphereShade(16.223066f,-56.90364f,-100.0f,3.3211951f,0f,0f,0f,0.0f,0f,0f,-88.17693f,-57.820335f,16.81374f,0f,-83.388504f,27.806236f,22.621593f,0.838961f,0.36086175f,0.15541801f,0,52.213394f,-84.22933f,33.580334f,73.60682f,-100.0f,29.282028f,0f,0f,0f ) ;
  }

  @Test
  public void test337() {
    TestDrivers.sphereShade(-1.7010814f,-1.6844497f,-33.45908f,0.023149017f,0f,0f,0f,-43.181908f,0f,0f,86.3183f,57.64051f,-3.6633017f,0f,31.98154f,-19.064754f,97.82799f,-0.07116203f,-0.28921953f,0.92191887f,0,0.48214856f,0.060939156f,-0.11748368f,-21.680977f,-25.645393f,-1.2560624f,0f,0f,0f ) ;
  }

  @Test
  public void test338() {
    TestDrivers.sphereShade(-18.445044f,-87.361946f,0f,14.735327f,0f,0f,0f,-3.5527137E-15f,0f,0f,38.67147f,-90.46968f,1.3134663f,0f,64.838875f,-12.160815f,-15.640645f,-0.36475733f,-0.40391788f,0.20159487f,0,30.3246f,87.96439f,5.6035137f,28.932858f,-25.14283f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test339() {
    TestDrivers.sphereShade(18.755274f,79.64339f,-3.8208315f,0.14194052f,0f,0f,0f,99.9019f,0f,0f,-72.42213f,-99.99457f,68.535545f,0f,-72.64088f,-99.84666f,68.76668f,-0.75815904f,0.37009457f,0.3539034f,0,-44.957424f,-13.906537f,54.244503f,-17.442318f,31.909775f,-1.8438932f,0f,0f,0f ) ;
  }

  @Test
  public void test340() {
    TestDrivers.sphereShade(-18.770409f,-100.0f,0f,-66.091805f,0f,0f,0f,0.0f,0f,0f,43.89507f,-42.444534f,100.0f,0f,-23.873013f,-68.70624f,25.816153f,-0.0036570258f,0.113957204f,-0.066876665f,0,35.30091f,100.0f,-34.760925f,11.134439f,36.61513f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test341() {
    TestDrivers.sphereShade(-20.137661f,-93.21431f,-7.9551897f,2.1442723f,0f,0f,0f,-36.478153f,0f,0f,-34.38043f,-35.32849f,-100.0f,0f,45.679775f,-37.11162f,-11.616742f,-0.0140645895f,-0.2070444f,-0.560498f,0,-69.681595f,53.09593f,53.94706f,-12.215109f,-23.490696f,76.56572f,0f,0f,0f ) ;
  }

  @Test
  public void test342() {
    TestDrivers.sphereShade(-20.155207f,-42.45556f,0f,-0.092612244f,0f,0f,0f,0.0f,0f,0f,-88.78816f,30.031923f,-86.51226f,0f,85.94515f,100.0f,70.38169f,-0.08129916f,-0.34100878f,0.3014437f,0,21.001139f,-60.06492f,68.13771f,0.53572804f,-100.0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test343() {
    TestDrivers.sphereShade(20.273205f,4.285448f,88.55302f,-4.932619E-4f,0f,0f,0f,-95.423615f,0f,0f,-86.13669f,-19.229805f,-94.1042f,0f,18.406734f,99.76692f,-7.168995f,-0.39183283f,-0.24024145f,0.14324842f,0,0.60101056f,0.113009825f,0.43928564f,-100.0f,79.75316f,-22.924147f,0f,0f,0f ) ;
  }

  @Test
  public void test344() {
    TestDrivers.sphereShade(2.295631f,100.0f,-100.0f,-100.0f,0f,0f,0f,27.66625f,0f,0f,100.0f,-40.505116f,-39.474663f,0f,-29.497759f,100.0f,-100.0f,0.4183173f,0.710598f,-0.13717613f,0,-72.93512f,42.54928f,6.612299f,83.45064f,-37.47465f,47.702496f,0f,0f,0f ) ;
  }

  @Test
  public void test345() {
    TestDrivers.sphereShade(-23.462612f,0f,0f,-12.892123f,0f,0f,0f,0.0f,0f,0f,93.406006f,75.6725f,99.987656f,0f,92.646034f,75.786865f,99.99999f,0.4534025f,-0.6571036f,-0.13991565f,0,76.94999f,-98.65841f,-68.31406f,0.003305972f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test346() {
    TestDrivers.sphereShade(23.669361f,-98.90504f,10.140694f,2.9487484f,0f,0f,0f,-25.859564f,0f,0f,80.70315f,-100.0f,63.634663f,0f,-99.35393f,-58.360905f,-28.374279f,-0.078714855f,0.57660437f,-0.5071084f,0,-0.33099577f,0.3373096f,-0.5026213f,-44.494724f,-5.84949E-4f,-61.963f,0f,0f,0f ) ;
  }

  @Test
  public void test347() {
    TestDrivers.sphereShade(2.5126865f,-84.42287f,-33.6323f,98.946236f,0f,0f,0f,-3.9443045E-31f,0f,0f,77.548164f,9.553942f,95.43729f,0f,5.58456f,46.90896f,-54.92903f,0.6073648f,-0.44521338f,-0.1447721f,0,0.40204906f,0.5481702f,-0.13099845f,26.639753f,22.923262f,-54.07593f,0f,0f,0f ) ;
  }

  @Test
  public void test348() {
    TestDrivers.sphereShade(-25.244812f,100.0f,-19.706524f,3.96121E-4f,0f,0f,0f,-42.696888f,0f,0f,100.0f,-26.302782f,-80.69698f,0f,-100.0f,85.49388f,15.819249f,0.24839856f,-0.555872f,-0.4726741f,0,100.0f,100.0f,100.0f,-100.0f,25.244812f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test349() {
    TestDrivers.sphereShade(-2.5413828f,-100.0f,0f,-3.9549966f,0f,0f,0f,-0.5594845f,0f,0f,-100.0f,-21.258669f,-100.0f,0f,-100.0f,57.35506f,-99.99957f,-0.3779384f,-0.2402965f,-0.10810293f,0,100.0f,19.81213f,64.91112f,0.099491f,90.93695f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test350() {
    TestDrivers.sphereShade(25.841824f,99.762726f,81.29017f,1.2589707E-4f,0f,0f,0f,-3.2618582f,0f,0f,-100.0f,22.638748f,-80.14415f,0f,-100.0f,22.227129f,-80.24707f,-0.42677775f,-0.6230438f,-0.56689876f,0,20.675436f,95.13658f,92.13601f,26.257425f,100.0f,97.94839f,0f,0f,0f ) ;
  }

  @Test
  public void test351() {
    TestDrivers.sphereShade(-27.441301f,-100.0f,-96.80059f,-34.169495f,0f,0f,0f,8.84956f,0f,0f,100.0f,-8.333728f,-100.0f,0f,-100.0f,-65.48165f,-100.0f,-0.67524195f,-0.18593134f,-0.30253562f,0,56.10467f,-43.357502f,96.32668f,49.777584f,100.0f,-54.11414f,0f,0f,0f ) ;
  }

  @Test
  public void test352() {
    TestDrivers.sphereShade(2.8070982f,59.85034f,-100.0f,39.87822f,0f,0f,0f,0.0f,0f,0f,-100.0f,-13.452458f,98.88064f,0f,-6.3720555f,-46.42307f,20.283674f,0.34352323f,-0.0782924f,-0.03136292f,0,62.3119f,11.281801f,-65.471664f,4.7443075f,-16.01821f,-62.007324f,0f,0f,0f ) ;
  }

  @Test
  public void test353() {
    TestDrivers.sphereShade(-28.224512f,12.468989f,21.203777f,7.072968E-4f,0f,0f,0f,-18.488407f,0f,0f,-46.560413f,65.58402f,22.201477f,0f,40.552074f,-79.93889f,-88.85168f,-0.46166456f,-0.15955128f,0.12555397f,0,-99.98947f,5.685331f,81.71326f,-50.092403f,-22.712307f,-93.564964f,0f,0f,0f ) ;
  }

  @Test
  public void test354() {
    TestDrivers.sphereShade(-28.69641f,7.275523f,0f,-0.016049687f,0f,0f,0f,0.0f,0f,0f,-22.320618f,-35.98001f,-20.386627f,0f,-22.198696f,-36.385777f,-19.728745f,0.20694654f,-0.42562804f,-0.31305087f,0,-99.99238f,-18.195202f,28.639114f,-49.874016f,-8.563852f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test355() {
    TestDrivers.sphereShade(-2.8861582f,-100.0f,0f,-2.539671f,0f,0f,0f,-60.900696f,0f,0f,20.188288f,-99.723755f,73.75841f,0f,19.607626f,-100.0f,73.59724f,0.4806385f,-0.11631533f,-0.1107689f,0,-25.771513f,-94.13562f,82.75953f,-56.890636f,-52.70988f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test356() {
    TestDrivers.sphereShade(2.9049597f,-53.392696f,-42.068455f,100.0f,0f,0f,0f,-99.57339f,0f,0f,-10.303702f,-99.08478f,43.293625f,0f,-15.07476f,-3.5658891f,-11.40783f,-0.8096706f,0.116735674f,-0.25961468f,0,0.39412084f,0.07620564f,-0.27639556f,-47.520786f,-99.61924f,45.21738f,0f,0f,0f ) ;
  }

  @Test
  public void test357() {
    TestDrivers.sphereShade(2.9152381f,-57.228f,-49.321358f,-0.014638518f,0f,0f,0f,98.28609f,0f,0f,-7.079896f,-1.0841937f,51.74571f,0f,-7.436628f,-1.0417157f,52.629078f,-0.31052485f,-0.524894f,0.67553467f,0,63.730125f,100.0f,90.01165f,52.688103f,93.56308f,-50.73537f,0f,0f,0f ) ;
  }

  @Test
  public void test358() {
    TestDrivers.sphereShade(-29.695704f,0f,0f,-20.09668f,0f,0f,0f,-29.56869f,0f,0f,41.87921f,86.65617f,58.539505f,0f,-62.429504f,39.07035f,-85.678734f,-0.7557906f,0.055666596f,0.34847933f,0,-82.71787f,46.399303f,2.4495394f,-100.0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test359() {
    TestDrivers.sphereShade(-2.9951339f,-23.377033f,0f,0.069777794f,0f,0f,0f,-34.671387f,0f,0f,-100.0f,-71.900826f,58.949684f,0f,-37.195324f,-82.81289f,-6.062326f,0.4834501f,0.5113903f,-0.26968f,0,62.133022f,71.28299f,68.1338f,-4.78483f,-0.6130464f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test360() {
    TestDrivers.sphereShade(31.091946f,-57.670296f,-0.0026527233f,27.85737f,0f,0f,0f,-66.65634f,0f,0f,97.266556f,76.23385f,6.235623f,0f,79.49733f,-4.015717f,-12.844772f,0.44325024f,0.08522352f,0.03276744f,0,2.3332446f,-78.53507f,50.000324f,-43.373306f,41.679447f,-13.532186f,0f,0f,0f ) ;
  }

  @Test
  public void test361() {
    TestDrivers.sphereShade(-31.896215f,-24.049797f,-26.10458f,0.004507459f,0f,0f,0f,-0.18460959f,0f,0f,-81.70968f,25.870577f,-98.921455f,0f,-21.067598f,-100.0f,-53.39354f,0.3744595f,0.71103686f,0.5161983f,0,-0.47468534f,0.1576753f,-0.58467823f,99.80124f,-81.488556f,-8.498681f,0f,0f,0f ) ;
  }

  @Test
  public void test362() {
    TestDrivers.sphereShade(-32.783787f,0f,0f,29.611628f,0f,0f,0f,62.706894f,0f,0f,-47.36105f,51.808926f,16.457388f,0f,-47.39281f,50.858345f,17.94025f,0.12299548f,-1.4503735f,0.11537507f,0,-77.74269f,100.0f,84.330986f,-18.026316f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test363() {
    TestDrivers.sphereShade(-32.90518f,0f,87.61464f,3.4900114E-4f,0f,0f,0f,-18.333206f,0f,0f,9.439275f,29.492361f,-77.617065f,0f,9.123627f,29.765371f,-77.253296f,-0.2542998f,0.019489095f,0.04769139f,0,-15.063179f,-53.534855f,21.650444f,-87.07808f,0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test364() {
    TestDrivers.sphereShade(33.07865f,0f,0f,43.801086f,0f,0f,0f,100.0f,0f,0f,-91.26297f,24.398499f,-9.722509f,0f,97.59072f,100.0f,-65.11598f,0.8229921f,0.12919365f,-0.13939331f,0,0.13177538f,0.045062937f,-0.9585458f,100.0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test365() {
    TestDrivers.sphereShade(-3.3745914f,0f,-87.49747f,-63.481167f,0f,0f,0f,0.0f,0f,0f,-96.83862f,100.0f,-96.20251f,0f,-96.21612f,100.0f,-96.36389f,-0.9582866f,-0.13745818f,-0.048757788f,0,-41.593758f,49.096706f,-43.256645f,0.004570363f,0f,-14.102951f,0f,0f,0f ) ;
  }

  @Test
  public void test366() {
    TestDrivers.sphereShade(34.009686f,78.378f,19.734793f,6.8921724E-4f,0f,0f,0f,0.0f,0f,0f,-100.0f,-15.504174f,-46.60438f,0f,-99.99977f,-15.936858f,-47.43305f,0.4706241f,-0.43380457f,0.07584641f,0,-28.008598f,100.0f,-82.39726f,-6.772488f,18.511845f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test367() {
    TestDrivers.sphereShade(-3.4653273E-4f,0f,96.68807f,64.42824f,0f,0f,0f,0.0f,0f,0f,-16.74539f,-25.144764f,27.287352f,0f,-16.70038f,-25.901924f,27.296839f,-0.29940227f,0.3139919f,-0.70477384f,0,100.0f,14.489031f,-69.237305f,-14.173839f,0f,99.05977f,0f,0f,0f ) ;
  }

  @Test
  public void test368() {
    TestDrivers.sphereShade(34.86456f,-64.75053f,40.6548f,6.280877E-4f,0f,0f,0f,0.0f,0f,0f,13.219163f,100.0f,8.093601f,0f,13.203546f,99.99138f,8.091955f,0.054891326f,-0.23694946f,0.46313244f,0,77.4197f,77.54052f,-43.56178f,-100.0f,-23.162699f,39.066837f,0f,0f,0f ) ;
  }

  @Test
  public void test369() {
    TestDrivers.sphereShade(-35.064037f,77.21534f,0f,-2.630001E-4f,0f,0f,0f,-95.967064f,0f,0f,98.68646f,-47.566925f,-72.60295f,0f,98.464226f,-47.059666f,-72.14848f,-0.012537395f,0.17987663f,0.15873177f,0,41.4443f,38.943733f,119.5993f,110.11904f,-49.242546f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test370() {
    TestDrivers.sphereShade(-36.550888f,100.0f,4.8379602f,0.0024741734f,0f,0f,0f,-92.759186f,0f,0f,-48.36252f,30.083515f,99.930626f,0f,-48.621243f,29.484491f,99.81263f,-0.39343396f,0.052290477f,0.55030054f,0,68.32781f,67.08401f,100.0f,-11.014292f,4.350089f,83.6378f,0f,0f,0f ) ;
  }

  @Test
  public void test371() {
    TestDrivers.sphereShade(36.709965f,0f,41.938007f,2.724056E-4f,0f,0f,0f,-13.143523f,0f,0f,-99.9913f,-33.100082f,99.4719f,0f,-100.0f,-34.069324f,99.58427f,-0.26743105f,-0.4033679f,-0.04359873f,0,-100.0f,-86.68317f,-72.3959f,100.0f,0f,76.47631f,0f,0f,0f ) ;
  }

  @Test
  public void test372() {
    TestDrivers.sphereShade(-37.186363f,12.201568f,-0.9501691f,-0.07684651f,0f,0f,0f,-31.597383f,0f,0f,-22.749132f,-100.0f,-86.22001f,0f,73.98854f,-100.0f,-96.249695f,0.15254107f,0.13347346f,0.051375654f,0,-68.50199f,6.550283f,-58.763943f,-90.49601f,-1.0664984f,13.695407f,0f,0f,0f ) ;
  }

  @Test
  public void test373() {
    TestDrivers.sphereShade(-37.389763f,-5.2406493E-4f,0f,-100.0f,0f,0f,0f,-98.54126f,0f,0f,18.35681f,94.39102f,20.110334f,0f,17.537071f,94.08501f,20.301374f,0.047793407f,-0.48632863f,-0.8069799f,0,-63.466667f,71.32929f,-35.00294f,-100.0f,19.081604f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test374() {
    TestDrivers.sphereShade(-37.581924f,-18.797474f,93.96912f,16.489351f,0f,0f,0f,-41.800682f,0f,0f,55.06173f,97.2589f,-87.11356f,0f,-37.507965f,-16.967037f,-100.0f,0.16991815f,0.022366598f,0.014238901f,0,0.52087957f,-0.38059607f,0.5797905f,-74.25381f,-7.204282f,17.371037f,0f,0f,0f ) ;
  }

  @Test
  public void test375() {
    TestDrivers.sphereShade(-3.7970717f,100.0f,0f,8.670851f,0f,0f,0f,0.0f,0f,0f,-39.96826f,100.0f,100.0f,0f,-6.7336345f,3.7639842f,-100.0f,0.3294795f,0.29844794f,-0.48943663f,0,0.37383544f,0.24303757f,0.2278652f,96.04624f,-1.9684186f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test376() {
    TestDrivers.sphereShade(-38.22247f,-100.0f,100.0f,0.0027971955f,0f,0f,0f,13.732809f,0f,0f,-25.11215f,-99.9993f,17.28607f,0f,-59.388855f,-100.0f,6.208923f,-0.2826122f,-0.46462065f,-0.6653523f,0,-81.23082f,-100.0f,100.0f,-9.353162f,-28.759119f,43.95371f,0f,0f,0f ) ;
  }

  @Test
  public void test377() {
    TestDrivers.sphereShade(38.40789f,-22.799536f,-11.123f,-0.0017987412f,0f,0f,0f,0.0f,0f,0f,46.792812f,100.0f,-100.0f,0f,-100.0f,38.00824f,-26.674278f,0.19660059f,-0.32986265f,0.8479891f,0,-58.16711f,-100.0f,-21.291656f,-14.474744f,24.384022f,49.98151f,0f,0f,0f ) ;
  }

  @Test
  public void test378() {
    TestDrivers.sphereShade(38.541973f,-8.235944f,-2.9161735f,0.0315429f,0f,0f,0f,-2.1684043E-19f,0f,0f,50.41416f,33.31228f,-38.469093f,0f,-94.00872f,91.689896f,100.0f,-0.71014434f,0.24220647f,0.10240312f,0,96.34483f,95.25234f,-100.0f,-91.749626f,-0.8526026f,-10.513115f,0f,0f,0f ) ;
  }

  @Test
  public void test379() {
    TestDrivers.sphereShade(-39.69887f,13.031304f,0f,-9.488458E-4f,0f,0f,0f,0.0f,0f,0f,-5.5566688f,-100.0f,14.924256f,0f,70.830666f,35.861855f,98.84418f,-0.06984697f,-0.8914382f,-0.16357403f,0,-0.026622945f,0.12736408f,0.39722377f,99.97212f,-80.875404f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test380() {
    TestDrivers.sphereShade(41.115387f,86.70042f,100.0f,7.2629435E-4f,0f,0f,0f,91.47333f,0f,0f,100.0f,-79.01098f,7.719196f,0f,100.0f,9.690235f,100.0f,0.08833544f,1.2045333f,-0.2664501f,0,-100.0f,100.0f,100.0f,100.0f,15.880571f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test381() {
    TestDrivers.sphereShade(-41.622757f,-26.618015f,18.878391f,74.68922f,0f,0f,0f,-100.0f,0f,0f,1.8181354f,36.272804f,-39.700207f,0f,30.494791f,-8.696061f,42.52745f,0.0030256289f,-0.115183726f,-0.11873744f,0,19.549698f,71.82596f,12.435789f,28.176622f,-100.0f,65.56014f,0f,0f,0f ) ;
  }

  @Test
  public void test382() {
    TestDrivers.sphereShade(4.277859f,-0.15781192f,0f,-0.087829575f,0f,0f,0f,86.09151f,0f,0f,-55.43924f,79.544174f,-35.065193f,0f,-99.99297f,-73.03542f,-29.238016f,-0.26249883f,-0.11549602f,-0.08167489f,0,79.169945f,44.91529f,11.481505f,-2.6615384f,72.14719f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test383() {
    TestDrivers.sphereShade(42.77897f,43.511192f,68.43423f,6.479572E-4f,0f,0f,0f,99.99968f,0f,0f,38.510025f,14.729456f,-34.14237f,0f,-9.362244f,-31.531292f,100.0f,0.01973109f,-0.4793716f,0.53740627f,0,-100.0f,-31.531292f,-8.611935f,36.076412f,-100.0f,0.77615094f,0f,0f,0f ) ;
  }

  @Test
  public void test384() {
    TestDrivers.sphereShade(-4.3060308f,0f,0f,6.886015f,0f,0f,0f,0.0f,0f,0f,97.747955f,52.56035f,53.65642f,0f,97.14013f,52.851032f,53.917316f,0.3428511f,-0.17620178f,1.3348451f,0,-99.986824f,59.834564f,22.827337f,-33.997757f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test385() {
    TestDrivers.sphereShade(-43.5181f,82.55542f,0f,0.041352317f,0f,0f,0f,-59.25898f,0f,0f,16.13934f,32.653f,90.80602f,0f,-178.7498f,100.0f,-61.838394f,0.1793226f,-0.22725107f,0.13565321f,0,-0.3306557f,0.28551218f,0.4591035f,-0.39092588f,-80.23255f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test386() {
    TestDrivers.sphereShade(-43.780468f,4.696331f,100.0f,0.0054703224f,0f,0f,0f,0.0f,0f,0f,55.50809f,-54.39177f,-98.91678f,0f,-25.262583f,-68.46898f,5.1791096f,0.48469445f,0.27339563f,0.50006706f,0,-27.218845f,-17.117304f,-48.701065f,12.564053f,38.924976f,62.170174f,0f,0f,0f ) ;
  }

  @Test
  public void test387() {
    TestDrivers.sphereShade(4.388614E-4f,-34.76974f,0f,-48.328217f,0f,0f,0f,0.0f,0f,0f,-74.877335f,-15.291654f,100.0f,0f,-98.25494f,51.37234f,4.9269047f,-0.88787264f,-0.12397684f,-0.38694653f,0,-0.62633353f,-0.21113443f,-0.4407103f,-46.52181f,66.23721f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test388() {
    TestDrivers.sphereShade(44.561768f,-90.516495f,0f,-26.435463f,0f,0f,0f,0.0f,0f,0f,56.258392f,100.0f,25.800655f,0f,56.733532f,100.0f,26.300018f,-0.7885943f,0.16848741f,-0.01929276f,0,-50.580807f,17.754803f,0.30448696f,100.0f,-88.92936f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test389() {
    TestDrivers.sphereShade(-4.4589524f,98.30793f,-32.40474f,77.2831f,0f,0f,0f,28.720186f,0f,0f,84.115555f,-99.540085f,21.322168f,0f,86.23253f,-100.0f,21.818846f,-0.084943295f,-0.4042001f,0.14234756f,0,-1.0354017f,-5.7124205f,-7.6203704f,56.892715f,-71.59215f,38.43904f,0f,0f,0f ) ;
  }

  @Test
  public void test390() {
    TestDrivers.sphereShade(-44.686302f,99.995766f,-17.846476f,1.3004933E-4f,0f,0f,0f,-19.596163f,0f,0f,53.242535f,99.98015f,13.706303f,0f,53.041317f,99.89209f,13.883841f,-0.32945317f,0.61232376f,0.7085859f,0,-30.650845f,43.23466f,-51.783073f,100.0f,76.89715f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test391() {
    TestDrivers.sphereShade(44.934067f,48.052357f,0f,26.757824f,0f,0f,0f,0.0f,0f,0f,3.0271785f,-50.69062f,-60.760506f,0f,3.5672336f,-51.488384f,-60.2721f,0.44458774f,-0.5695976f,-0.59221745f,0,-17.960125f,-90.933754f,-57.437084f,-8.758002f,52.89569f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test392() {
    TestDrivers.sphereShade(-4.5573854E-4f,0f,0f,57.84779f,0f,0f,0f,-4.597252f,0f,0f,100.0f,-96.82832f,-100.0f,0f,-51.99831f,-100.0f,-100.0f,-0.13687131f,-0.2101101f,-0.3849695f,0,-0.44474778f,-0.16485247f,0.5955797f,-37.93128f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test393() {
    TestDrivers.sphereShade(-45.64806f,57.366245f,84.31659f,-0.015112051f,0f,0f,0f,0.0f,0f,0f,100.0f,42.472992f,100.0f,0f,100.0f,-99.81569f,100.0f,-0.05910178f,0.24940246f,0.24568053f,0,100.0f,100.0f,-100.0f,-100.0f,100.0f,46.611744f,0f,0f,0f ) ;
  }

  @Test
  public void test394() {
    TestDrivers.sphereShade(45.79693f,-0.39540628f,0f,-0.10597772f,0f,0f,0f,-100.0f,0f,0f,-20.800999f,38.930664f,7.33412f,0f,92.35723f,-86.271416f,-44.238857f,-0.3847626f,0.15309064f,0.38320792f,0,-0.26609567f,-0.6766533f,0.10062936f,-51.022694f,23.863926f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test395() {
    TestDrivers.sphereShade(4.65806f,-73.0846f,-0.0017088759f,-15.0619955f,0f,0f,0f,-100.0f,0f,0f,-100.0f,-67.15096f,-65.92753f,0f,-74.29864f,50.466152f,98.94743f,-0.78590006f,0.02463586f,0.17394657f,0,0.06528384f,-0.033981644f,0.10542113f,37.173157f,-100.0f,38.851425f,0f,0f,0f ) ;
  }

  @Test
  public void test396() {
    TestDrivers.sphereShade(-46.731564f,-18.77827f,0f,95.70915f,0f,0f,0f,0.0f,0f,0f,-20.5215f,46.318047f,20.489067f,0f,55.713066f,51.019665f,-95.57217f,-0.4845171f,0.78305656f,0.17426977f,0,0.68882316f,0.06090151f,-0.114352316f,-5.5542564f,44.553547f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test397() {
    TestDrivers.sphereShade(-46.973404f,-3.8126342f,-13.056723f,0.0026228586f,0f,0f,0f,-97.37024f,0f,0f,2.475617f,-47.207485f,-86.527695f,0f,2.1286054f,-46.929367f,-86.68504f,-0.03438506f,0.15112856f,0.34746236f,0,72.433174f,-91.84799f,-85.203865f,3.4869163f,-100.0f,-3.0430713f,0f,0f,0f ) ;
  }

  @Test
  public void test398() {
    TestDrivers.sphereShade(-4.736623E-4f,-98.84551f,0f,21.142002f,0f,0f,0f,-65.086494f,0f,0f,93.274956f,-17.009357f,-78.65452f,0f,93.516205f,-19.127764f,-78.24559f,0.27075976f,0.1966552f,-0.8359933f,0,-21.551449f,91.244934f,100.0f,-100.0f,99.56081f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test399() {
    TestDrivers.sphereShade(47.480198f,3.1341302f,0f,6.035223f,0f,0f,0f,0.0f,0f,0f,99.27623f,-54.112793f,100.0f,0f,-61.610287f,-100.0f,100.0f,0.4898202f,0.16140236f,0.27072403f,0,-0.16317426f,-0.48269033f,-0.57745326f,17.839579f,100.0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test400() {
    TestDrivers.sphereShade(47.50668f,-78.70241f,-100.0f,99.01846f,0f,0f,0f,-32.574833f,0f,0f,-99.6545f,100.0f,-99.23033f,0f,-99.965126f,100.0f,-100.0f,-0.037370548f,0.47841597f,-0.77277994f,0,-19.253866f,-9.591988f,-77.827576f,-93.439095f,100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test401() {
    TestDrivers.sphereShade(4.755351f,-69.72406f,-7.505548f,-17.1915f,0f,0f,0f,0.0f,0f,0f,45.928635f,66.03372f,-100.0f,0f,-62.442146f,-86.211334f,-90.128075f,-0.56527585f,0.19491845f,0.41628984f,0,17.936234f,-55.790924f,-80.87638f,7.856984f,-25.032848f,9.912352f,0f,0f,0f ) ;
  }

  @Test
  public void test402() {
    TestDrivers.sphereShade(47.595356f,100.0f,-0.4648f,100.0f,0f,0f,0f,21.147999f,0f,0f,100.0f,-23.64034f,97.357864f,0f,6.808228f,100.0f,-98.38615f,-0.2989369f,0.48404962f,-0.56228495f,0,-100.0f,-99.49979f,21.030716f,12.877977f,-60.008137f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test403() {
    TestDrivers.sphereShade(-49.01369f,0f,0f,62.486206f,0f,0f,0f,0.0f,0f,0f,-13.786415f,35.233578f,-100.0f,0f,-75.08892f,-62.957226f,39.055717f,-0.38351527f,-0.09797097f,0.59073937f,0,-0.009181301f,-0.08362138f,9.7454817E-4f,1.2764069f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test404() {
    TestDrivers.sphereShade(49.15985f,5.485813E-4f,100.0f,-18.264267f,0f,0f,0f,-6.901824f,0f,0f,-100.0f,12.112664f,-100.0f,0f,-100.0f,12.256795f,-99.66505f,0.33242035f,0.18328877f,-0.8033904f,0,22.057642f,-100.0f,-43.52274f,46.90546f,-99.80602f,-60.425907f,0f,0f,0f ) ;
  }

  @Test
  public void test405() {
    TestDrivers.sphereShade(-49.909603f,17.080973f,0f,5.6238443E-4f,0f,0f,0f,2.343413f,0f,0f,-23.937487f,-25.480988f,50.1365f,0f,-24.890413f,-25.675812f,50.033016f,-0.4384878f,0.7272825f,0.23998366f,0,-94.46043f,-12.734178f,14.510317f,48.634968f,100.0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test406() {
    TestDrivers.sphereShade(5.0764024E-4f,-5.314848f,0f,25.775677f,0f,0f,0f,-13.207593f,0f,0f,-5.4688587f,78.7252f,-99.824615f,0f,-89.274895f,-100.0f,-79.94155f,0.07459247f,-0.33754358f,0.819699f,0,-0.33232468f,0.21867885f,-0.7837888f,76.42473f,9.227807f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test407() {
    TestDrivers.sphereShade(50.823246f,33.640465f,0f,0.0015641513f,0f,0f,0f,0.0f,0f,0f,-62.39947f,-1.0877912f,8.301811f,0f,-39.140083f,-100.0f,100.0f,0.3381371f,0.46091455f,-0.5370599f,0,98.207085f,-100.0f,51.29489f,12.563314f,19.004623f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test408() {
    TestDrivers.sphereShade(-52.166164f,-100.0f,-71.142624f,1.9606913E-4f,0f,0f,0f,0.0f,0f,0f,-100.0f,-30.041492f,99.87456f,0f,95.61094f,-60.327812f,-95.161865f,0.4611401f,0.15879337f,0.36557272f,0,0.011893672f,0.013814488f,0.90874034f,100.0f,-38.41685f,8.500569f,0f,0f,0f ) ;
  }

  @Test
  public void test409() {
    TestDrivers.sphereShade(53.109837f,38.119167f,100.0f,-2.7086065E-4f,0f,0f,0f,76.88026f,0f,0f,45.932693f,-76.66871f,-100.0f,0f,100.0f,-99.99984f,-100.0f,0.36175323f,0.06843042f,0.015195838f,0,-100.0f,-56.395584f,-77.63878f,-8.192299f,-96.85246f,-99.99999f,0f,0f,0f ) ;
  }

  @Test
  public void test410() {
    TestDrivers.sphereShade(-5.319967f,74.81794f,13.094842f,-14.419377f,0f,0f,0f,-92.00292f,0f,0f,76.51405f,-23.350338f,-21.88848f,0f,76.405716f,-24.074347f,-21.851284f,0.733548f,0.11120786f,-0.38588965f,0,27.501345f,51.92092f,36.358093f,52.095478f,51.200157f,64.34164f,0f,0f,0f ) ;
  }

  @Test
  public void test411() {
    TestDrivers.sphereShade(-53.987354f,14.958175f,-30.20645f,-8.679259f,0f,0f,0f,78.787636f,0f,0f,-1.1080315f,-50.565063f,100.0f,0f,27.320002f,-74.826004f,-100.0f,0.33309737f,0.567762f,-0.6919646f,0,-80.69324f,-5.6891513f,-100.0f,-13.173623f,21.611084f,30.818771f,0f,0f,0f ) ;
  }

  @Test
  public void test412() {
    TestDrivers.sphereShade(-54.742218f,-100.0f,-100.0f,-0.5120867f,0f,0f,0f,8.079682f,0f,0f,-63.14319f,-55.000576f,-52.461967f,0f,-19.94723f,33.034187f,35.016956f,-0.4045585f,-0.10135091f,0.42048478f,0,-46.124508f,50.63364f,100.0f,100.0f,-22.53893f,-12.768177f,0f,0f,0f ) ;
  }

  @Test
  public void test413() {
    TestDrivers.sphereShade(-5.5629964f,-100.0f,0f,0.003637678f,0f,0f,0f,0.0f,0f,0f,-99.042046f,-17.366924f,-17.44912f,0f,-99.1669f,-17.967543f,-16.882326f,0.067720175f,-0.22139564f,-0.91460985f,0,57.96817f,-100.0f,-100.0f,-49.415928f,-23.17221f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test414() {
    TestDrivers.sphereShade(55.877476f,-1.067126f,0f,100.0f,0f,0f,0f,-100.0f,0f,0f,-11.566145f,-99.09354f,-85.50598f,0f,100.0f,-99.00014f,55.669346f,-0.23854753f,-0.0081469705f,0.08127216f,0,-36.894814f,-100.0f,-78.34291f,-41.117344f,70.63269f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test415() {
    TestDrivers.sphereShade(56.037197f,61.02276f,-45.258457f,1.8843067E-4f,0f,0f,0f,-100.0f,0f,0f,46.162033f,47.590065f,43.54426f,0f,3.7130637f,-46.974487f,15.699465f,0.09729722f,0.5288955f,-0.16310771f,0,-34.681156f,-57.2725f,51.389214f,-35.037796f,86.967415f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test416() {
    TestDrivers.sphereShade(5.7960034E-4f,0f,3.3153084E-4f,-99.43788f,0f,0f,0f,-67.53691f,0f,0f,-59.661446f,-46.603607f,-52.914486f,0f,-59.60276f,-46.271156f,-52.642796f,0.9124796f,0.66980606f,-1.4775476f,0,100.0f,66.15553f,50.263924f,-21.79327f,0f,-30.847654f,0f,0f,0f ) ;
  }

  @Test
  public void test417() {
    TestDrivers.sphereShade(-58.705383f,67.018745f,1.0373474f,89.24275f,0f,0f,0f,-96.60858f,0f,0f,-96.99855f,-100.0f,20.278034f,0f,-40.408f,-100.0f,86.33296f,-0.2091574f,0.25150004f,-0.60356814f,0,-0.07181357f,-0.636834f,-0.66883045f,-12.512188f,-99.763084f,-56.898243f,0f,0f,0f ) ;
  }

  @Test
  public void test418() {
    TestDrivers.sphereShade(59.102524f,0.024932368f,0f,-4.079451f,0f,0f,0f,-90.40968f,0f,0f,-100.0f,-6.063592f,61.983658f,0f,-72.08482f,-48.73535f,-57.904167f,-0.10607578f,0.57962364f,-0.46830523f,0,-22.95829f,-92.11013f,-82.94688f,92.63023f,-9.831838f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test419() {
    TestDrivers.sphereShade(-59.317387f,100.0f,-14.910978f,-0.0010487614f,0f,0f,0f,0.0f,0f,0f,97.47677f,69.46461f,85.108765f,0f,80.5593f,-100.0f,-100.0f,0.50930375f,0.28078276f,0.5525247f,0,9.25969f,100.0f,-52.364048f,-100.0f,-32.859917f,63.946556f,0f,0f,0f ) ;
  }

  @Test
  public void test420() {
    TestDrivers.sphereShade(-59.397877f,-99.19167f,0f,32.348595f,0f,0f,0f,-98.773964f,0f,0f,52.913227f,24.909937f,24.103037f,0f,85.954704f,85.44097f,-66.43555f,0.41638416f,0.4586529f,-0.41568804f,0,-0.118957594f,0.6736598f,-0.59819794f,-22.149752f,61.633907f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test421() {
    TestDrivers.sphereShade(59.54299f,67.8837f,0f,-1.6808198E-4f,0f,0f,0f,0.0f,0f,0f,-84.881f,-27.693108f,49.201923f,0f,78.48969f,82.37033f,-16.581022f,-0.38980752f,-0.7046675f,0.31244794f,0,-100.0f,-9.001597f,-28.325045f,-99.91903f,-87.64221f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test422() {
    TestDrivers.sphereShade(6.007773f,-100.0f,-65.50487f,-5.6127043f,0f,0f,0f,-31.521147f,0f,0f,-19.828024f,-37.996708f,-34.991997f,0f,-44.17157f,-28.398575f,-48.355133f,-0.40567663f,-0.770106f,0.4817532f,0,0.8655549f,0.023516363f,-0.11965936f,-100.0f,-61.848705f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test423() {
    TestDrivers.sphereShade(-60.25143f,17.09011f,42.77635f,-5.6783147f,0f,0f,0f,0.0f,0f,0f,-100.0f,37.706856f,-100.0f,0f,-50.059784f,63.804737f,7.098233f,0.029870925f,-0.43144545f,-0.8519745f,0,55.470108f,-22.583933f,-22.937664f,-100.0f,-45.30147f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test424() {
    TestDrivers.sphereShade(-60.947445f,-4.473354f,-56.594257f,-83.41253f,0f,0f,0f,0.0f,0f,0f,-15.258949f,-79.50033f,44.066467f,0f,100.0f,7.1365824f,25.05778f,-0.58088917f,-0.5255569f,0.18266666f,0,-64.34857f,28.649511f,-34.707405f,89.77466f,11.94591f,65.06946f,0f,0f,0f ) ;
  }

  @Test
  public void test425() {
    TestDrivers.sphereShade(61.810764f,-44.409626f,100.0f,45.15147f,0f,0f,0f,0.0f,0f,0f,-32.90863f,-89.625854f,-56.087036f,0f,53.65471f,19.024714f,100.0f,-0.20108326f,-0.76588035f,0.19550729f,0,-0.003347458f,0.5137435f,-0.5737649f,67.8447f,-64.36813f,96.570656f,0f,0f,0f ) ;
  }

  @Test
  public void test426() {
    TestDrivers.sphereShade(66.30612f,-32.16234f,-37.607525f,-18.994347f,0f,0f,0f,0.0f,0f,0f,-65.674446f,80.52487f,-16.371964f,0f,-100.0f,98.44951f,22.67797f,0.06401535f,0.23084615f,-0.42019695f,0,0.34669378f,0.62941515f,-0.05244645f,0.5599188f,-99.32352f,-41.045105f,0f,0f,0f ) ;
  }

  @Test
  public void test427() {
    TestDrivers.sphereShade(-66.927505f,-50.37148f,-47.07675f,-46.18393f,0f,0f,0f,-40.026493f,0f,0f,-100.0f,100.0f,5.6606855f,0f,-89.03482f,-100.0f,-42.75387f,-0.83119553f,0.42175674f,0.060680263f,0,0.109715044f,-0.17271759f,-0.0490866f,-57.326813f,44.397068f,11.890141f,0f,0f,0f ) ;
  }

  @Test
  public void test428() {
    TestDrivers.sphereShade(67.153534f,17.416044f,-14.928915f,0.0019455461f,0f,0f,0f,0.0f,0f,0f,36.784027f,20.562159f,-100.0f,0f,93.60326f,-93.66976f,0.87119776f,0.2984457f,0.21589711f,-0.9057216f,0,-0.5191887f,0.7833427f,-0.28166863f,100.0f,29.5127f,-34.42946f,0f,0f,0f ) ;
  }

  @Test
  public void test429() {
    TestDrivers.sphereShade(67.69167f,89.40757f,67.88644f,1.4772921E-4f,0f,0f,0f,61.638638f,0f,0f,99.45032f,100.0f,-100.0f,0f,-100.0f,-100.0f,-54.584167f,-0.456083f,0.07683076f,0.2612322f,0,82.00281f,100.0f,-99.794044f,100.0f,75.526184f,99.71273f,0f,0f,0f ) ;
  }

  @Test
  public void test430() {
    TestDrivers.sphereShade(68.79668f,-100.0f,89.00899f,0.0014572724f,0f,0f,0f,-82.91287f,0f,0f,-6.135324f,-69.26742f,-60.254955f,0f,15.0418825f,100.0f,-18.514801f,-0.3697504f,0.5688705f,0.70060897f,0,-0.11270606f,0.20393915f,0.18880971f,9.974514f,67.27257f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test431() {
    TestDrivers.sphereShade(69.07507f,100.0f,76.92091f,-34.99556f,0f,0f,0f,92.509026f,0f,0f,-100.0f,-68.81813f,100.0f,0f,100.0f,100.0f,-34.714752f,-0.0109997345f,0.97610235f,-0.0064396583f,0,-61.24765f,-188.33339f,-85.19572f,98.423904f,53.595654f,89.82589f,0f,0f,0f ) ;
  }

  @Test
  public void test432() {
    TestDrivers.sphereShade(69.551476f,61.0167f,50.52897f,0.0023817297f,0f,0f,0f,0.0f,0f,0f,43.74397f,61.74784f,18.240768f,0f,100.0f,-2.6922166f,-87.84652f,0.28504476f,0.45474583f,0.5522822f,0,-46.581894f,-49.125076f,100.0f,6.0367227f,-5.04059f,7.0006623f,0f,0f,0f ) ;
  }

  @Test
  public void test433() {
    TestDrivers.sphereShade(-71.22503f,63.730972f,100.0f,-1.5690958E-4f,0f,0f,0f,-58.249992f,0f,0f,100.0f,-100.0f,-100.0f,0f,-87.16963f,0.82526225f,100.0f,0.09966481f,0.33532637f,-0.531117f,0,-0.37620452f,0.53388345f,0.108620144f,89.47834f,-100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test434() {
    TestDrivers.sphereShade(-72.02989f,98.04437f,98.112335f,7.697559E-4f,0f,0f,0f,0.0f,0f,0f,-100.0f,-14.91847f,9.169715f,0f,-62.20158f,30.170338f,-98.483475f,0.09302062f,0.97128916f,-0.118095435f,0,100.0f,82.937645f,5.5493574f,-18.03575f,59.891865f,68.850685f,0f,0f,0f ) ;
  }

  @Test
  public void test435() {
    TestDrivers.sphereShade(-72.38321f,-90.12147f,77.12843f,2.867789f,0f,0f,0f,-77.92542f,0f,0f,-12.233358f,-23.136028f,40.852413f,0f,-11.956411f,-23.57789f,40.73833f,0.13723f,0.062342472f,0.5048305f,0,-89.03492f,-91.14766f,49.642212f,-96.177f,95.00329f,1.2719284f,0f,0f,0f ) ;
  }

  @Test
  public void test436() {
    TestDrivers.sphereShade(7.2402506f,-16.649923f,-5.847709f,-41.47986f,0f,0f,0f,-88.89171f,0f,0f,-9.323125f,-12.712375f,-22.835726f,0f,-9.283151f,-12.869345f,-23.119997f,0.8238976f,0.47636926f,-0.29690298f,0,-51.381664f,-82.37015f,87.491066f,-73.33676f,59.50667f,71.85633f,0f,0f,0f ) ;
  }

  @Test
  public void test437() {
    TestDrivers.sphereShade(73.25112f,-85.263245f,0f,-0.0011372113f,0f,0f,0f,0.0f,0f,0f,5.3276353f,-76.29671f,26.93691f,0f,7.220156f,51.262367f,13.597128f,0.5353878f,-0.24979538f,0.12969323f,0,-22.478586f,-80.80515f,67.64176f,-51.319096f,10.313284f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test438() {
    TestDrivers.sphereShade(-73.47125f,4.8149004f,0f,-1.8219712f,0f,0f,0f,3.5527137E-15f,0f,0f,66.390236f,-45.559822f,-71.91566f,0f,-98.42562f,13.898344f,-100.0f,0.47442386f,-0.26279283f,-0.062324315f,0,-0.15813358f,-0.86204094f,-0.19870685f,-79.842255f,-0.80714774f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test439() {
    TestDrivers.sphereShade(73.47972f,59.274605f,24.659433f,-14.550655f,0f,0f,0f,100.0f,0f,0f,34.473423f,-31.88115f,100.0f,0f,35.229927f,-31.951466f,100.0f,0.21504134f,0.35262096f,-0.34741738f,0,25.22814f,100.0f,-100.0f,7.116377f,-15.387189f,-55.65753f,0f,0f,0f ) ;
  }

  @Test
  public void test440() {
    TestDrivers.sphereShade(78.954216f,0f,0f,-8.956737f,0f,0f,0f,100.0f,0f,0f,-34.40846f,-144.93286f,1.6464169f,0f,-47.60938f,-94.59577f,36.837193f,-0.5341953f,0.6759476f,-0.43712544f,0,99.97946f,68.46657f,93.54097f,-100.0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test441() {
    TestDrivers.sphereShade(-8.012823f,-83.24631f,100.0f,1.0512918E-4f,0f,0f,0f,-40.216114f,0f,0f,-24.422321f,99.448616f,-67.65999f,0f,-99.99999f,70.884315f,99.99783f,-0.11328284f,0.2746442f,-0.79999506f,0,-0.41821232f,-0.47990778f,-0.85078084f,-76.94331f,19.497759f,99.99801f,0f,0f,0f ) ;
  }

  @Test
  public void test442() {
    TestDrivers.sphereShade(80.199234f,-28.342325f,18.032047f,4.0894287E-4f,0f,0f,0f,0.0f,0f,0f,-87.39819f,-82.37465f,-21.061674f,0f,-87.12132f,-82.09646f,-20.163273f,-0.36895198f,-0.54082453f,-0.47830638f,0,-6.7246485f,21.775457f,1.4468842f,-83.82517f,-86.27836f,95.96681f,0f,0f,0f ) ;
  }

  @Test
  public void test443() {
    TestDrivers.sphereShade(80.2156f,0f,0f,99.3992f,0f,0f,0f,40.409092f,0f,0f,69.462456f,-37.11936f,-39.33426f,0f,96.91821f,-75.09852f,-1.4064935f,-0.534532f,-0.40053058f,0.13061887f,0,1.7592521f,-0.27960315f,1.2504078f,-33.325603f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test444() {
    TestDrivers.sphereShade(-81.73156f,-84.434906f,-62.046013f,-25.10872f,0f,0f,0f,-99.99559f,0f,0f,-80.85038f,11.790406f,-63.23842f,0f,-80.17601f,12.053344f,-63.210102f,-0.82856846f,0.23875695f,-0.45345384f,0,100.0f,-100.0f,-99.76316f,-36.251266f,62.052082f,-3.8042767f,0f,0f,0f ) ;
  }

  @Test
  public void test445() {
    TestDrivers.sphereShade(-8.178909f,0f,0f,9.785417E-4f,0f,0f,0f,73.181076f,0f,0f,-32.346233f,72.999214f,62.29208f,61.728897f,-180.67897f,50.551834f,100.0f,0.6080809f,-0.30860695f,1.3672603f,0,-83.81651f,-68.066246f,-5.4406557f,75.61619f,0f,0f,5.593298f,0f,0f ) ;
  }

  @Test
  public void test446() {
    TestDrivers.sphereShade(-81.90702f,-52.779915f,-74.86326f,0.003046392f,0f,0f,0f,-23.948654f,0f,0f,-52.262318f,40.74179f,100.0f,0f,-53.00691f,40.795387f,99.886475f,0.1649597f,-0.042753577f,0.90908f,0,21.160479f,-5.2466865f,-79.50829f,30.038551f,5.0497327f,-4.3847566f,0f,0f,0f ) ;
  }

  @Test
  public void test447() {
    TestDrivers.sphereShade(82.2711f,36.222538f,-76.52363f,3.5475052E-4f,0f,0f,0f,0.0f,0f,0f,100.0f,-25.170637f,-77.720955f,0f,6.4826884f,-21.422852f,-100.0f,-0.19257924f,0.6577098f,0.3180603f,0,20.599262f,80.305305f,35.110195f,45.41214f,77.82123f,-69.825836f,0f,0f,0f ) ;
  }

  @Test
  public void test448() {
    TestDrivers.sphereShade(-85.59344f,-41.619926f,0f,-2.4159666E-4f,0f,0f,0f,-31.597727f,0f,0f,1.8241478f,8.947319f,-91.27763f,0f,2.2859874f,8.441257f,-90.847565f,-0.33322644f,0.87511104f,-1.7682402f,0,96.375786f,-2.2867951f,-75.02646f,80.71294f,44.20793f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test449() {
    TestDrivers.sphereShade(86.25235f,-13.175047f,0.14300494f,10.046116f,0f,0f,0f,0.0f,0f,0f,93.850525f,-98.73394f,-63.764065f,0f,21.71737f,-36.69129f,-100.0f,-0.553077f,-0.3118526f,0.22007857f,0,0.47547868f,-0.30497792f,0.34137633f,-11.152365f,-99.85074f,0.69606656f,0f,0f,0f ) ;
  }

  @Test
  public void test450() {
    TestDrivers.sphereShade(8.7273655f,-100.0f,-81.36123f,100.0f,0f,0f,0f,60.258213f,0f,0f,-89.543755f,-61.621532f,46.26911f,0f,-100.0f,-22.149803f,5.0636854f,-0.045642346f,0.31133458f,0.04131322f,0,-9.577949f,-99.608185f,-84.252754f,36.681213f,-12.6777f,-70.48058f,0f,0f,0f ) ;
  }

  @Test
  public void test451() {
    TestDrivers.sphereShade(87.68809f,28.227869f,-19.619564f,-6.327382E-4f,0f,0f,0f,-94.48212f,0f,0f,100.0f,-40.15294f,71.40559f,0f,-78.260605f,-56.46638f,-100.0f,0.05146445f,-0.44803923f,-0.278169f,0,70.43309f,-97.4286f,54.974663f,-18.023342f,-55.98837f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test452() {
    TestDrivers.sphereShade(8.804114f,-99.790306f,99.9731f,0.18141074f,0f,0f,0f,-3.593855E-5f,0f,0f,91.20044f,-34.37372f,-95.63914f,0f,19.264639f,88.648964f,59.37355f,0.7044671f,-1.6090468f,0.29656377f,0,0.11584713f,-0.13627027f,-0.9053028f,99.707855f,-100.0f,-19.752277f,0f,0f,0f ) ;
  }

  @Test
  public void test453() {
    TestDrivers.sphereShade(88.38577f,53.222305f,100.0f,-0.0011206925f,0f,0f,0f,-82.86026f,0f,0f,12.140911f,-70.65301f,100.0f,0f,67.618385f,-64.10351f,-6.382562f,0.80194336f,0.45564133f,-0.16426906f,0,-99.99831f,18.21036f,23.21009f,-10.095577f,34.431503f,-85.074615f,0f,0f,0f ) ;
  }

  @Test
  public void test454() {
    TestDrivers.sphereShade(-89.53096f,18.440985f,0f,-6.708993f,0f,0f,0f,-95.75053f,0f,0f,-17.634258f,-42.64957f,-57.80278f,0f,-17.597166f,-42.33476f,-58.714672f,0.68980706f,-0.055382818f,-0.3041493f,0,-100.0f,-60.534798f,88.87058f,12.795633f,40.561466f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test455() {
    TestDrivers.sphereShade(89.82739f,0f,0f,-78.29243f,0f,0f,0f,0.0f,0f,0f,100.0f,-100.0f,100.0f,0f,-100.0f,100.0f,65.62684f,-0.31703043f,0.044960354f,-0.10114132f,0,-37.410175f,11.047166f,-79.269f,-18.657734f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test456() {
    TestDrivers.sphereShade(90.06681f,-96.66691f,0f,70.41646f,0f,0f,0f,-93.414986f,0f,0f,89.2638f,25.627785f,100.0f,0f,100.0f,-80.63999f,-100.0f,0.7898858f,0.07763365f,-0.03644927f,0,-0.20652094f,0.43021291f,0.6784618f,-4.3575873f,-39.368282f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test457() {
    TestDrivers.sphereShade(-90.96002f,0f,0f,-4.819039f,0f,0f,0f,100.0f,0f,0f,-100.0f,42.40775f,-76.071396f,0f,-100.0f,42.38848f,-76.29327f,-0.25260255f,0.52450424f,-0.7860555f,0,58.905243f,-95.79887f,26.013721f,-32.180126f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test458() {
    TestDrivers.sphereShade(-91.38759f,-100.0f,-31.986343f,-3.1263343E-4f,0f,0f,0f,100.0f,0f,0f,-62.689175f,95.73406f,87.58435f,0f,-11.45228f,-92.28478f,-100.0f,-0.33817276f,-0.06938277f,-0.12736063f,0,76.4924f,-18.058554f,-100.0f,35.00075f,75.234886f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test459() {
    TestDrivers.sphereShade(91.77088f,100.0f,-100.0f,-1.1147753E-4f,0f,0f,0f,60.06956f,0f,0f,100.0f,-96.64169f,73.90582f,0f,100.0f,1.6906639f,-24.08374f,0.08806325f,0.73946947f,0.18006404f,0,-100.0f,91.04891f,-100.0f,100.0f,-27.251402f,89.70418f,0f,0f,0f ) ;
  }

  @Test
  public void test460() {
    TestDrivers.sphereShade(-92.150665f,-30.815882f,-2.778612f,-5.633039E-4f,0f,0f,0f,-5.8017594E-8f,0f,0f,-62.780323f,83.19205f,-11.939675f,0f,32.522545f,49.291855f,75.58077f,0.8277668f,2.011081f,-0.35598612f,0,-0.9654492f,-0.27442262f,-0.8746554f,99.479965f,57.60797f,14.768118f,0f,0f,0f ) ;
  }

  @Test
  public void test461() {
    TestDrivers.sphereShade(-9.2696364E-4f,0f,0f,81.66306f,0f,0f,0f,-87.75511f,0f,0f,23.010967f,0.84718114f,-34.835472f,0f,22.253798f,0.39785376f,-35.067516f,-0.5297123f,0.16871792f,-0.26081175f,0,-100.0f,-11.834027f,39.982742f,-13.210268f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test462() {
    TestDrivers.sphereShade(-93.45331f,24.042128f,4.1783376f,0.036070317f,0f,0f,0f,-100.0f,0f,0f,1.3083129f,49.23312f,-10.514437f,0f,100.0f,-73.39248f,-93.46939f,-0.62516975f,0.21398942f,0.09148341f,0,-100.0f,-17.55311f,53.353634f,-100.0f,-99.99997f,6.635086f,0f,0f,0f ) ;
  }

  @Test
  public void test463() {
    TestDrivers.sphereShade(9.475036f,-100.0f,-99.81347f,13.515319f,0f,0f,0f,-18.092705f,0f,0f,-54.01645f,28.414614f,-72.586105f,0f,-53.561523f,28.50698f,-71.90074f,-0.4652905f,0.360914f,-0.51250625f,0,66.373314f,74.893616f,-79.3018f,-57.459854f,19.62687f,-44.125446f,0f,0f,0f ) ;
  }

  @Test
  public void test464() {
    TestDrivers.sphereShade(9.483006f,-99.99323f,-9.168826f,-0.0017001213f,0f,0f,0f,-4.749314f,0f,0f,-25.164013f,63.678116f,15.114536f,0f,-25.534517f,63.219536f,15.176169f,0.43276f,0.13016202f,0.44538108f,0,-60.815838f,65.0688f,-53.513832f,-37.219105f,56.50703f,64.151436f,0f,0f,0f ) ;
  }

  @Test
  public void test465() {
    TestDrivers.sphereShade(-95.02578f,81.30695f,10.619756f,99.59878f,0f,0f,0f,-5.551115E-17f,0f,0f,-96.2475f,33.793274f,98.06527f,0f,37.39831f,12.572141f,100.0f,-0.2509184f,-0.3866039f,0.13208584f,0,-0.8525254f,-0.16623196f,-0.4112565f,-0.8797569f,-95.30014f,9.4591366E-4f,0f,0f,0f ) ;
  }

  @Test
  public void test466() {
    TestDrivers.sphereShade(95.67926f,19.917269f,0f,2.1103313E-4f,0f,0f,0f,100.0f,0f,0f,-96.19954f,100.0f,-23.896973f,0f,100.0f,-100.0f,100.0f,-0.0074487925f,0.31802332f,0.7773647f,0,-57.808014f,66.79803f,-16.804632f,49.525806f,1.3649153f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test467() {
    TestDrivers.sphereShade(96.27191f,-99.66213f,-48.709858f,3.9578558E-4f,0f,0f,0f,-40.71382f,0f,0f,4.639348f,-97.179306f,100.0f,0f,-18.273466f,-99.981346f,100.0f,-0.29687658f,-0.23395981f,-0.5469353f,0,0.31187823f,-0.47691932f,-0.2638413f,88.808174f,-25.35186f,-51.86694f,0f,0f,0f ) ;
  }

  @Test
  public void test468() {
    TestDrivers.sphereShade(96.70906f,49.792664f,-3.8969035f,0.0025702303f,0f,0f,0f,-99.910995f,0f,0f,-1.5019892f,-8.981504f,25.229778f,0f,-2.0539896f,-8.197841f,25.483791f,-0.43994626f,-0.31245524f,-0.29635116f,0,-94.00341f,-26.156227f,-25.640808f,58.342884f,-100.0f,-99.84086f,0f,0f,0f ) ;
  }

  @Test
  public void test469() {
    TestDrivers.sphereShade(-97.29675f,-100.0f,-54.860886f,-7.2150004E-5f,0f,0f,0f,-100.0f,0f,0f,100.0f,15.387522f,3.1907172f,0f,-98.48725f,-16.611305f,100.0f,-0.40585628f,-0.27098233f,0.26551813f,0,-0.44187284f,-0.5757267f,0.62191266f,100.0f,100.0f,25.585157f,0f,0f,0f ) ;
  }

  @Test
  public void test470() {
    TestDrivers.sphereShade(97.7539f,65.50543f,-99.7186f,-96.746506f,0f,0f,0f,0.0f,0f,0f,100.0f,-32.770096f,-100.0f,0f,99.767075f,-32.753742f,-100.0f,-0.32906035f,-0.6551996f,0.4679379f,0,100.0f,-68.21359f,-35.93334f,36.059383f,78.11547f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test471() {
    TestDrivers.sphereShade(-97.8292f,-69.87511f,-95.779144f,0.5149611f,0f,0f,0f,-15.527602f,0f,0f,45.679245f,8.505467f,34.927273f,0f,-26.483917f,81.29846f,-100.0f,0.4247817f,0.007440844f,-0.8288995f,0,99.81784f,-100.0f,23.89718f,79.97515f,82.70182f,0.038021073f,0f,0f,0f ) ;
  }

  @Test
  public void test472() {
    TestDrivers.sphereShade(-98.15545f,-99.99997f,99.99992f,7.7310554E-4f,0f,0f,0f,-23.838337f,0f,0f,99.999954f,-96.86093f,51.738552f,0f,50.798798f,-100.0f,100.0f,0.21202244f,-0.66580945f,0.39746326f,0,-0.40898606f,-0.23527351f,0.8040649f,19.126654f,-12.941929f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test473() {
    TestDrivers.sphereShade(98.56983f,0f,0f,-100.0f,0f,0f,0f,0.0f,0f,0f,63.951492f,35.703495f,-42.248863f,0f,-22.013874f,20.112852f,-3.0795474f,-0.44534692f,-0.115639485f,-0.35882923f,0,-0.21727335f,-0.3711847f,-0.7856067f,-87.56305f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test474() {
    TestDrivers.sphereShade(99.527596f,100.0f,0f,-2.7068282E-4f,0f,0f,0f,-100.0f,0f,0f,-95.9267f,63.25194f,85.15225f,0f,-65.999954f,100.0f,-17.11593f,-0.79246306f,-0.22415878f,-0.41623423f,0,43.0105f,0.2610579f,-61.25029f,-37.118958f,67.85731f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test475() {
    TestDrivers.sphereShade(99.58447f,23.790792f,0f,30.863388f,0f,0f,0f,100.0f,0f,0f,-2.336634f,-59.106033f,29.897015f,0f,13.459111f,11.84085f,-10.314149f,0.29725093f,0.7410234f,0.22202905f,0,75.81681f,-9.278379f,-54.97146f,5.6846266f,70.58211f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test476() {
    TestDrivers.sphereShade(-99.782104f,-5.966684E-4f,0f,-50.278057f,0f,0f,0f,-0.015146775f,0f,0f,-90.42622f,100.0f,100.0f,0f,-99.130745f,99.624146f,-34.676495f,-0.664399f,-0.23137169f,-0.024634024f,0,-100.0f,-33.610603f,34.969994f,65.63897f,33.33408f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test477() {
    TestDrivers.sphereShade(99.80889f,96.39795f,0f,-75.72144f,0f,0f,0f,0.0f,0f,0f,87.62345f,-65.848175f,94.921745f,0f,-39.738327f,94.46639f,20.510723f,0.57206124f,-0.3046773f,0.08873083f,0,-100.0f,100.0f,-37.472275f,100.0f,-86.66314f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test478() {
    TestDrivers.sphereShade(99.91761f,-9.440304f,-3.9668522f,-0.026507651f,0f,0f,0f,4.4647853E-16f,0f,0f,-27.110285f,33.38405f,-99.53798f,0f,100.0f,31.15968f,28.978193f,0.18998682f,0.050388765f,-0.51613694f,0,-0.35009348f,1.2089177f,-0.5605121f,-6.1685348f,-73.96135f,-48.89971f,0f,0f,0f ) ;
  }

  @Test
  public void test479() {
    TestDrivers.sphereShade(9.992501f,-100.0f,-96.01815f,-96.78346f,0f,0f,0f,-100.0f,0f,0f,-100.0f,-82.96135f,23.130676f,0f,-65.09016f,-77.53681f,-100.0f,0.8496598f,0.221152f,-0.3064524f,0,-83.97134f,100.0f,46.474712f,94.96312f,-95.42453f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test480() {
    TestDrivers.sphereShade(99.991295f,68.551384f,24.545921f,3.6288894E-4f,0f,0f,0f,-30.798698f,0f,0f,-65.88233f,-73.72038f,-97.97293f,0f,-84.341896f,-68.63103f,-62.994576f,0.91059613f,-0.35968113f,0.13087766f,0,-62.94265f,-91.51832f,-10.59018f,27.55904f,40.19852f,113.08523f,0f,0f,0f ) ;
  }

  @Test
  public void test481() {
    TestDrivers.sphereShade(-99.99872f,71.27661f,-73.85781f,-1.4220602E-4f,0f,0f,0f,-18.544397f,0f,0f,100.0f,100.0f,-50.796043f,0f,34.21191f,37.74643f,-82.30106f,0.20764187f,0.3394309f,-0.20561402f,0,0.24768248f,-0.39978397f,-0.6960626f,100.0f,-98.6586f,90.96904f,0f,0f,0f ) ;
  }

  @Test
  public void test482() {
    TestDrivers.sphereShade(-99.9996f,51.052853f,99.99945f,-4.027133E-4f,0f,0f,0f,-99.9989f,0f,0f,39.00976f,-100.0f,-2.079857f,0f,-68.97571f,-29.463717f,-99.99918f,0.095264316f,0.6836212f,0.68731636f,0,-54.640743f,-100.0f,-62.900745f,99.999756f,-48.63893f,80.715866f,0f,0f,0f ) ;
  }
}
