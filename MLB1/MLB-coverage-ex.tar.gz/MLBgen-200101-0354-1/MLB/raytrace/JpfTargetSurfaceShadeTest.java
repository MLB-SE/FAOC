import org.junit.Test;

public class JpfTargetSurfaceShadeTest {

  @Test
  public void test0() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,46.641373f,25.724716f,-15.061057f,0f,0f,0f,-936,3.3164456f,-100.0f,-17.829563f,0f,0f,0f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-50.05688f,-0.1503592f,-22.626291f,0f,0f,0f,-1314,0.42259496f,-0.20307817f,-0.86610746f,0f,0f,0f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,-0.72546023f,0f,0f,0f,0f,0f,50.402683f,-96.779755f,36.325916f,0f,0f,0f,-409,0.48849812f,0.24015868f,-0.46731067f,0f,0f,0f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,-100.0f,-3085.0f,435.0f,713.0f,-2371,0.7408454f,0.3885194f,0.54828095f,0f,0f,0f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,26.259607f,-72.955734f,0f,0f,0f,-439,-0.2034156f,0.66990894f,0.7140337f,0f,0f,0f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,100.0f,39.601574f,69.00003f,191.0f,-1075.0f,-444.0f,-1325,-0.047225423f,-0.7413419f,-0.66946393f,0f,0f,0f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-14.996827f,83.15119f,40.742683f,0f,0f,0f,1521,86.36413f,16.764902f,-31.832176f,0f,0f,0f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,22.032938f,100.0f,-22.448708f,0f,0f,0f,-2241,-0.07279095f,-0.3068371f,-0.5341335f,0f,0f,0f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-9.600442f,-40.487217f,126.15778f,0f,0f,0f,1,-0.06136339f,0.1549409f,-0.2855814f,0f,0f,0f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,-99.999245f,78.77907f,100.0f,0f,0f,0f,935,-0.490668f,-0.3012741f,-0.81760556f,0f,0f,0f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,2.3090692f,0f,0f,0f,0f,0f,-100.0f,-82.31863f,100.0f,0f,0f,0f,1563,0.9917197f,-0.111944236f,0.062932044f,0f,0f,0f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,73.46699f,0f,0f,0f,0f,0f,-7.714361f,-90.26041f,14.29727f,0f,0f,0f,-482,-45.488815f,29.040966f,-22.038284f,0f,0f,0f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,-8.629216f,0f,0f,0f,0f,0f,-34.544037f,-35.880367f,-32.215755f,0f,0f,0f,-996,91.50995f,19.183126f,12.121603f,0f,0f,0f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0.0f,0f,95.29548f,0f,0f,0f,0f,0f,86.87004f,-100.0f,-31.520605f,0f,0f,0f,-885,0.100469604f,0.9665374f,0.22377309f,0f,0f,0f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-33.657433f,-100.0f,0f,0f,0f,1,0.24983014f,-0.5405888f,0.6004691f,0f,0f,0f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,-10.191352f,-75.28837f,-39.423454f,0f,0f,0f,-156,-81.05539f,66.82948f,63.900707f,0f,0f,0f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,17.378557f,-71.770195f,93.90418f,0f,0f,0f,1,-3.720582f,0.046109535f,0.64927965f,0f,0f,0f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,-18.55201f,-97.23784f,44.260773f,0f,0f,0f,889,0.8680646f,0.41554543f,0.0038451424f,0f,0f,0f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,-55.151333f,-44.302418f,51.66461f,595.0f,-434.0f,263.0f,-4,12.185328f,-6.426023f,-0.22120588f,0f,0f,0f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,55.300385f,100.0f,-17.137764f,-165.0f,-330.0f,838.0f,-2,-2.3725915f,0.601679f,0.013138306f,0f,0f,0f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,-67.64799f,-28.001175f,-26.782816f,-1152.0f,-564.0f,202.0f,5,0.026821755f,0.06487425f,0.78612626f,0f,0f,0f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,99.87293f,-100.0f,-100.0f,0f,0f,0f,947,-0.9466739f,-0.31692246f,0.05804023f,0f,0f,0f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,28.769138f,0f,0f,0f,0f,0f,-84.37977f,31.774832f,15.542536f,0f,0f,0f,1,0.26064906f,-0.25927415f,-0.18961607f,0f,0f,0f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,-60.431355f,0f,0f,0f,0f,0f,4.5311794f,67.11311f,-19.807661f,0f,0f,0f,2,-0.29528353f,-0.38500434f,0.018245537f,0f,0f,0f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,8.6736174E-19f,0f,0f,0f,0f,0f,-9.783065f,22.223885f,100.0f,0f,0f,0f,-1,-0.56047356f,0.27175772f,-0.5505029f,0f,0f,0f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,81.4649f,100.0f,3.1412113f,0f,0f,0f,485,100.0f,-100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,83.180084f,11.221133f,-66.17024f,0f,0f,0f,-865,-0.0032469723f,0.51727486f,0.81671023f,0f,0f,0f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-104.0f,0f,1082.0f,0f,0f,0f,0f,0f,303.0f,-820.0f,617.0f,460.0f,766.0f,-939.0f,-270,-2.5963616f,78.09855f,103.860054f,0f,0f,0f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-1046.0f,0f,2593.0f,0f,0f,0f,0f,0f,967.0f,-691.0f,173.0f,867.0f,-577.0f,953.0f,839,0.17521767f,0.17838618f,-0.96913964f,0f,0f,0f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,1066.0f,0f,3.0f,0f,0f,0f,0f,0f,1970.0f,-201.0f,-95.0f,1403.0f,470.0f,-653.0f,-1285,-0.107464425f,-0.93946797f,0.0069745556f,0f,0f,0f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-11.451771f,0f,36.514076f,0f,0f,0f,0f,0f,-66.69523f,-98.20269f,-55.69208f,0f,0f,0f,727,91.80983f,-52.70723f,49.10643f,0f,0f,0f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-11.543794f,0f,100.0f,0f,0f,0f,0f,0f,67.76112f,-100.0f,0.346474f,0f,0f,0f,-502,-0.5855479f,-0.17938092f,-0.53156036f,0f,0f,0f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,1.4180759f,0f,0f,0f,0f,0f,0f,0f,100.0f,-13.296917f,74.08973f,0f,0f,0f,2,-0.74849504f,0.18828684f,0.9837556f,0f,0f,0f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,1725.0f,0f,1327.0f,0f,0f,0f,0f,0f,-425.0f,252.0f,-404.0f,-874.0f,193.0f,-1252.0f,86,63.80259f,-34.141937f,-85.16889f,0f,0f,0f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,22.74148f,0f,0f,0f,0f,0f,0f,0f,37.72291f,21.357937f,-21.406157f,370.0f,-989.0f,-916.0f,-1237,-0.7569817f,-0.38858104f,-0.5060093f,0f,0f,0f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,22.749544f,0f,0f,0f,0f,0f,0f,0f,-68.98447f,78.08245f,43.18657f,0f,0f,0f,-111,44.99424f,-7.8671737f,17.604137f,0f,0f,0f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,239.0f,0f,-1531.0f,0f,0f,0f,0f,0f,-537.0f,422.0f,-450.0f,-288.0f,339.0f,485.0f,-702,-29.398935f,-88.48253f,14.837874f,0f,0f,0f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,3.0f,0f,1143.0f,0f,0f,0f,0f,0f,1023.0f,-737.0f,1869.0f,-459.0f,-643.0f,430.0f,-936,-100.0f,32.359562f,-37.138546f,0f,0f,0f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-3349.0f,0f,928.0f,0f,0f,0f,0f,0f,-1058.0f,1128.0f,529.0f,-683.0f,92.0f,-982.0f,366,0.8225947f,-0.39287743f,0.30260962f,0f,0f,0f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-34.212467f,0f,99.99991f,0f,0f,0f,0f,0f,-32.28555f,-20.006744f,100.0f,0f,0f,0f,-76,0.8231485f,0.37547064f,-0.42596757f,0f,0f,0f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-3.836209f,0f,-69.025734f,0f,0f,0f,0f,0f,25.92628f,11.27121f,-99.62099f,0f,0f,0f,-748,-0.27398244f,-0.035197195f,0.037087016f,0f,0f,0f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-38.76084f,0f,-68.81446f,0f,0f,0f,0f,0f,-100.0f,-56.479534f,-55.727936f,0f,0f,0f,-160,0.37123948f,0.46474054f,-0.80386406f,0f,0f,0f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-4.012672f,0f,0f,0f,0f,0f,0f,0f,-57.62211f,-14.497095f,100.0f,0f,0f,0f,2,-0.46423373f,0.29402998f,-0.7224684f,0f,0f,0f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-40.189316f,0f,0.0f,0f,0f,0f,0f,0f,99.554756f,9.681344f,100.0f,0f,0f,0f,1049,-0.15293466f,-0.38561624f,-0.9098962f,0f,0f,0f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-416.0f,0f,1193.0f,0f,0f,0f,0f,0f,-523.0f,-152.0f,-948.0f,1009.0f,-1181.0f,-375.0f,-845,1.7247999f,0.91905606f,2.0607603f,0f,0f,0f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,43.02365f,0f,0f,0f,0f,0f,0f,0f,100.0f,-100.0f,-100.0f,0f,0f,0f,664,-0.9619335f,-0.008387157f,-0.27071747f,0f,0f,0f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,43.499844f,0f,0f,0f,0f,0f,0f,0f,28.996922f,6.813675f,59.265705f,495.0f,-822.0f,-148.0f,-1467,76.688576f,10.530019f,-55.681717f,0f,0f,0f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,47.27537f,0f,0f,0f,0f,0f,0f,0f,56.72852f,48.52092f,-10.903004f,1136.0f,728.0f,-306.0f,879,0.27033922f,-0.1953721f,0.5371282f,0f,0f,0f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-586.0f,0f,520.0f,0f,0f,0f,0f,0f,734.0f,1869.0f,-199.0f,-1330.0f,-444.0f,-499.0f,-920,0.21472749f,-0.21552017f,0.9527025f,0f,0f,0f ) ;
  }

  @Test
  public void test49() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,60.86672f,0f,0f,0f,0f,0f,0f,0f,-40.70091f,87.94944f,-88.707596f,-171.0f,303.0f,490.0f,731,34.332764f,-82.93378f,44.78398f,0f,0f,0f ) ;
  }

  @Test
  public void test50() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,61.374268f,0f,0f,0f,0f,0f,0f,0f,13.559757f,-49.7623f,13.262773f,71.0f,-885.0f,-349.0f,973,21.62124f,7.1342006f,-67.633835f,0f,0f,0f ) ;
  }

  @Test
  public void test51() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-646.0f,0f,1096.0f,0f,0f,0f,0f,0f,1540.0f,-868.0f,-809.0f,21.0f,685.0f,-695.0f,2285,-46.43007f,34.48375f,92.51792f,0f,0f,0f ) ;
  }

  @Test
  public void test52() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-68.72679f,0f,0f,0f,0f,0f,0f,0f,1.6898527f,-34.54097f,97.849846f,0f,0f,0f,-1458,-0.7274196f,0.6847975f,-0.043739334f,0f,0f,0f ) ;
  }

  @Test
  public void test53() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-89.31177f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,-100.0f,-22.996765f,0f,0f,0f,-1404,-100.0f,64.73094f,30.314789f,0f,0f,0f ) ;
  }

  @Test
  public void test54() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-89.78629f,0f,-45.455994f,0f,0f,0f,0f,0f,-65.81079f,-93.53923f,-26.484695f,0f,0f,0f,813,-29.165928f,61.660484f,-26.499317f,0f,0f,0f ) ;
  }

  @Test
  public void test55() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,94.55942f,0f,0f,0f,0f,0f,0f,0f,40.779667f,2.735813f,53.657223f,0f,0f,0f,-297,-0.3720532f,-0.33071986f,-0.60453296f,0f,0f,0f ) ;
  }

  @Test
  public void test56() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,98.20934f,0f,0f,0f,0f,0f,0f,0f,17.820549f,77.552925f,-1.7117724f,-115.0f,-288.0f,985.0f,-246,-0.5180584f,0.024166284f,0.6222509f,0f,0f,0f ) ;
  }

  @Test
  public void test57() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,-99.99116f,0f,0.0f,0f,0f,0f,0f,0f,-99.16439f,-6.086109f,100.0f,0f,0f,0f,767,-0.1681437f,0.85173917f,-0.14556642f,0f,0f,0f ) ;
  }

  @Test
  public void test58() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.969471f,48.3001f,0f,0f,0f,0f,0f,0f,0f,-28.806978f,-43.39536f,1.1077434f,723.0f,-2422.0f,-54.0f,-555,-0.01035993f,0.22120358f,0.78919256f,0f,0f,0f ) ;
  }

  @Test
  public void test59() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test60() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,5.781979f,0f,0f,0f,451,0.013660766f,-0.53873205f,0.11447703f,0f,0f,0f ) ;
  }

  @Test
  public void test61() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,23.730995f,-70.968056f,-73.52239f,0f,0f,0f,-365,-88.52836f,-33.994473f,-44.34651f,0f,0f,0f ) ;
  }

  @Test
  public void test62() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,38.160778f,-99.37742f,-100.0f,0f,0f,0f,1,0.07853566f,-0.29215148f,-0.73553014f,0f,0f,0f ) ;
  }

  @Test
  public void test63() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,40.867294f,-11.827957f,-69.51568f,0f,0f,0f,-2123,0.94820136f,-0.04710625f,0.31415784f,0f,0f,0f ) ;
  }

  @Test
  public void test64() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,53.8877f,54.61357f,-35.836224f,0f,0f,0f,1,-0.9902652f,0.011957827f,-2.2870052f,0f,0f,0f ) ;
  }

  @Test
  public void test65() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,77.497215f,-22.927568f,-89.749535f,0f,0f,0f,157,-85.19797f,93.25034f,-97.3889f,0f,0f,0f ) ;
  }

  @Test
  public void test66() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.14557792f,0.44916207f,0.9085177f,0f,0f,0f,0f,0f,0f,1,0.11729102f,0.47457543f,0.8729535f,0f,0f,0f ) ;
  }

  @Test
  public void test67() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.28171825f,-0.56885403f,-1.5868341f,0f,0f,0f,0f,0f,0f,3,0.8898296f,0.07052924f,-0.45080924f,0f,0f,0f ) ;
  }

  @Test
  public void test68() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test69() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.0016805528f,-7.734404E-5f,0.002860826f,0f,0f,0f ) ;
  }

  @Test
  public void test70() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.007625795f,0.25841606f,0.9588276f,0f,0f,0f ) ;
  }

  @Test
  public void test71() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.023012199f,0.018787712f,0.16676469f,0f,0f,0f ) ;
  }

  @Test
  public void test72() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.034165062f,-0.7739916f,0.6322735f,0f,0f,0f ) ;
  }

  @Test
  public void test73() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.0508338f,-0.98835224f,-0.100745864f,0f,0f,0f ) ;
  }

  @Test
  public void test74() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.0593472f,-0.052058436f,-0.99687904f,0f,0f,0f ) ;
  }

  @Test
  public void test75() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.08756603f,-0.7951265f,0.07070203f,0f,0f,0f ) ;
  }

  @Test
  public void test76() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.0958952f,-0.3882624f,0.88201106f,0f,0f,0f ) ;
  }

  @Test
  public void test77() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.107726865f,0.18994014f,0.90512776f,0f,0f,0f ) ;
  }

  @Test
  public void test78() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-101,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test79() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.116541035f,-0.0859672f,-0.2540271f,0f,0f,0f ) ;
  }

  @Test
  public void test80() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.18746841f,-0.052596077f,-0.5763888f,0f,0f,0f ) ;
  }

  @Test
  public void test81() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.19791442f,-0.7794554f,0.50291514f,0f,0f,0f ) ;
  }

  @Test
  public void test82() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.19838591f,-0.5023244f,-0.22922978f,0f,0f,0f ) ;
  }

  @Test
  public void test83() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.20352614f,-0.034281913f,0.11628304f,0f,0f,0f ) ;
  }

  @Test
  public void test84() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.22602044f,0.46979424f,-0.19902146f,0f,0f,0f ) ;
  }

  @Test
  public void test85() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.43895105f,0.40432197f,-0.16759112f,0f,0f,0f ) ;
  }

  @Test
  public void test86() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.663841f,0.043565143f,0.15795483f,0f,0f,0f ) ;
  }

  @Test
  public void test87() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.7555752f,0.47567394f,-0.45037815f,0f,0f,0f ) ;
  }

  @Test
  public void test88() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.8215395f,-0.52764857f,-0.19573176f,0f,0f,0f ) ;
  }

  @Test
  public void test89() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.88287014f,0.103117086f,-0.45815626f,0f,0f,0f ) ;
  }

  @Test
  public void test90() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test91() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test92() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,1.0337708E-5f,-4.2289303E-4f,0.025086934f,0f,0f,0f ) ;
  }

  @Test
  public void test93() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1110,5.532929E-5f,8.005158E-5f,-1.5061437E-4f,0f,0f,0f ) ;
  }

  @Test
  public void test94() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-1.5751833E-6f,-1.5177992E-6f,-7.9433846E-7f,0f,0f,0f ) ;
  }

  @Test
  public void test95() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1351,0.8675773f,0.4957258f,0.039566953f,0f,0f,0f ) ;
  }

  @Test
  public void test96() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1528,-3.1291274E-5f,0.0018968133f,-2.0842685E-4f,0f,0f,0f ) ;
  }

  @Test
  public void test97() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-160,-84.22301f,23.994904f,-65.1558f,0f,0f,0f ) ;
  }

  @Test
  public void test98() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1708,0.7034863f,0.076110296f,-0.22105034f,0f,0f,0f ) ;
  }

  @Test
  public void test99() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1815,-6.0795196E-7f,1.6196899E-6f,7.736895E-7f,0f,0f,0f ) ;
  }

  @Test
  public void test100() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,97.76643f,-64.24845f,-3.3569472f,0f,0f,0f ) ;
  }

  @Test
  public void test101() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0.34066385f,0.16916762f,-0.04485206f,0f,0f,0f ) ;
  }

  @Test
  public void test102() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test103() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,3,0.10792474f,0.8771792f,-0.46787706f,0f,0f,0f ) ;
  }

  @Test
  public void test104() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,346,55.431664f,-66.56909f,-74.03321f,0f,0f,0f ) ;
  }

  @Test
  public void test105() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-607,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test106() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,641,-0.26567742f,-0.8780447f,0.39806145f,0f,0f,0f ) ;
  }

  @Test
  public void test107() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,660,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test108() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-691,0.5433441f,0.3132878f,0.08841611f,0f,0f,0f ) ;
  }

  @Test
  public void test109() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-722,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test110() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,8,-74.60477f,76.38409f,-44.88257f,0f,0f,0f ) ;
  }

  @Test
  public void test111() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,892,-45.347393f,88.35444f,-15.963869f,0f,0f,0f ) ;
  }

  @Test
  public void test112() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-100.0f,-100.0f,0f,0f,0f,380,0.06538517f,0.04585659f,-0.1874709f,0f,0f,0f ) ;
  }

  @Test
  public void test113() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-21.95381f,-51.13432f,0f,0f,0f,2,0.018742174f,-0.44467878f,0.91549313f,0f,0f,0f ) ;
  }

  @Test
  public void test114() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,42.726658f,87.60143f,0f,0f,0f,-193,-0.8793576f,0.42813864f,-0.20839293f,0f,0f,0f ) ;
  }

  @Test
  public void test115() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-51.04525f,-93.69594f,0f,0f,0f,1,0.003856975f,0.05976775f,0.74684066f,0f,0f,0f ) ;
  }

  @Test
  public void test116() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,137.83398f,-17.622652f,74.40706f,0f,0f,0f,-2717,-0.12574083f,5.149944f,1.4511762f,0f,0f,0f ) ;
  }

  @Test
  public void test117() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,15.82793f,6.2697487f,9.804449f,0f,0f,0f,1,-0.8395936f,9.424749f,-4.67153f,0f,0f,0f ) ;
  }

  @Test
  public void test118() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-28.854694f,-11.726569f,26.66001f,0f,0f,0f,-609,0.4099662f,-0.2632604f,0.3279184f,0f,0f,0f ) ;
  }

  @Test
  public void test119() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-31.45713f,100.0f,100.0f,0f,0f,0f,1,0.39315864f,0.4345681f,-0.7770531f,0f,0f,0f ) ;
  }

  @Test
  public void test120() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,4.726978f,-76.85744f,68.633316f,0f,0f,0f,1,-0.59086466f,-0.5642914f,0.40017137f,0f,0f,0f ) ;
  }

  @Test
  public void test121() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,48.830986f,44.21381f,-2.6418998f,0f,0f,0f,402,-20.067888f,22.524157f,6.035052f,0f,0f,0f ) ;
  }

  @Test
  public void test122() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,5.582819f,-88.38458f,14.276359f,0f,0f,0f,147,-55.761887f,-23.153193f,-37.90386f,0f,0f,0f ) ;
  }

  @Test
  public void test123() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-69.27616f,100.0f,-100.0f,0f,0f,0f,-2333,0.35934755f,0.18539388f,0.9146029f,0f,0f,0f ) ;
  }

  @Test
  public void test124() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-78.26754f,8.531213f,53.37218f,0f,0f,0f,1,-23.440105f,-7.1015115f,-33.238567f,0f,0f,0f ) ;
  }

  @Test
  public void test125() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-79.26697f,-64.72834f,75.93931f,0f,0f,0f,1,-0.6657082f,-0.50671774f,-0.045281433f,0f,0f,0f ) ;
  }

  @Test
  public void test126() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,8.478889f,30.94193f,92.67866f,0f,0f,0f,1,-4.63022f,32.108574f,-10.296246f,0f,0f,0f ) ;
  }

  @Test
  public void test127() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,8.484949f,-38.53588f,16.78289f,0f,0f,0f,477,-1.2263205f,-0.30186298f,-0.03225822f,0f,0f,0f ) ;
  }

  @Test
  public void test128() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,85.2237f,-29.429216f,-59.491096f,0f,0f,0f,-641,-85.59445f,-34.50229f,51.874603f,0f,0f,0f ) ;
  }

  @Test
  public void test129() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-95.271255f,99.381676f,-100.0f,0f,0f,0f,1,-0.88720584f,0.11491093f,-0.71036154f,0f,0f,0f ) ;
  }

  @Test
  public void test130() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-51.497513f,-46.4366f,0f,0f,0f,0f,0f,0f,2,100.0f,38.09369f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test131() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,94.7502f,8.629548f,0f,0f,0f,0f,0f,0f,4,100.0f,94.7502f,8.629548f,0f,0f,0f ) ;
  }

  @Test
  public void test132() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-99.98782f,-100.0f,-54.93711f,5.390247f,23.908825f,0f,0f,0f,1,0.19558041f,3.9272404f,-6.5172224f,0f,0f,0f ) ;
  }

  @Test
  public void test133() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,99.999954f,27.210539f,0f,0f,0f,0f,0f,0f,1,0.42488784f,-0.053021967f,0.9036919f,0f,0f,0f ) ;
  }

  @Test
  public void test134() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-105.05043f,-62.184914f,-64.019745f,0f,0f,0f,0f,0f,0f,2,89.70072f,55.1679f,95.82005f,0f,0f,0f ) ;
  }

  @Test
  public void test135() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1.4029138f,-2.6645973f,1.2646943f,0f,0f,0f,0f,0f,0f,4,-0.058290545f,-0.4136705f,0.9085587f,0f,0f,0f ) ;
  }

  @Test
  public void test136() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-15.257928f,-76.93647f,-40.782433f,0f,0f,0f,0f,0f,0f,2,-29.52835f,-54.510902f,90.566765f,0f,0f,0f ) ;
  }

  @Test
  public void test137() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1.9109323f,-1.7802644f,2.8298745f,0f,0f,0f,0f,0f,0f,4,0.39200032f,-0.23179114f,0.8902857f,0f,0f,0f ) ;
  }

  @Test
  public void test138() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-19.30446f,-4.757418f,25.41137f,0f,0f,0f,0f,0f,0f,3,-19.309818f,-4.7485666f,25.407267f,0f,0f,0f ) ;
  }

  @Test
  public void test139() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,197.84143f,-26.708652f,100.0f,100.0f,98.97882f,59.328724f,0f,0f,0f,2,-0.8087384f,0.5881456f,-0.0051903804f,0f,0f,0f ) ;
  }

  @Test
  public void test140() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,25.708767f,67.03451f,-21.666513f,0f,0f,0f,0f,0f,0f,3,25.21371f,67.03176f,-22.371675f,0f,0f,0f ) ;
  }

  @Test
  public void test141() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2.7739878f,-3.5749009f,-0.97876513f,0f,0f,0f,0f,0f,0f,3,0.30977604f,0.43383375f,-0.84606564f,0f,0f,0f ) ;
  }

  @Test
  public void test142() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,34.675983f,48.098114f,-66.74848f,0f,0f,0f,0f,0f,0f,-1,9.726023f,24.342266f,-69.0662f,0f,0f,0f ) ;
  }

  @Test
  public void test143() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-36.753616f,-39.31199f,32.94612f,0f,0f,0f,0f,0f,0f,2,42.45314f,99.178474f,-69.88665f,0f,0f,0f ) ;
  }

  @Test
  public void test144() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-37.07117f,95.61212f,-72.79683f,0f,0f,0f,0f,0f,0f,2,41.158974f,169.47726f,-75.58762f,0f,0f,0f ) ;
  }

  @Test
  public void test145() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-40.63866f,99.728714f,-100.0f,43.091724f,-67.104576f,-33.63648f,0f,0f,0f,3,0.06297466f,-0.21908066f,0.97367233f,0f,0f,0f ) ;
  }

  @Test
  public void test146() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-43.30384f,100.0f,100.0f,0f,0f,0f,0f,0f,0f,1,0.88932306f,-0.45608374f,0.033047628f,0f,0f,0f ) ;
  }

  @Test
  public void test147() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,47.413647f,-100.0f,100.0f,0f,0f,0f,0f,0f,0f,1,0.5854273f,0.00826299f,0.81068283f,0f,0f,0f ) ;
  }

  @Test
  public void test148() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,53.156612f,44.171497f,-4.206341f,0f,0f,0f,0f,0f,0f,2,-0.8879197f,0.42383996f,-0.17876875f,0f,0f,0f ) ;
  }

  @Test
  public void test149() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-88.61093f,-17.120827f,41.768192f,0f,0f,0f,0f,0f,0f,2,-88.47801f,-17.234241f,40.783573f,0f,0f,0f ) ;
  }

  @Test
  public void test150() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,89.835205f,-42.60289f,80.11743f,0f,0f,0f,0f,0f,0f,6,89.75321f,-42.662556f,80.09082f,0f,0f,0f ) ;
  }

  @Test
  public void test151() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,92.90977f,96.921295f,-16.876188f,0f,0f,0f,0f,0f,0f,1,0.04762494f,-0.9632921f,0.2641973f,0f,0f,0f ) ;
  }

  @Test
  public void test152() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,98.41203f,-16.718119f,57.686523f,0f,0f,0f,0f,0f,0f,1,0.68810564f,-0.37940675f,0.61851525f,0f,0f,0f ) ;
  }

  @Test
  public void test153() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,99.85927f,-100.0f,100.0f,0f,0f,0f,0f,0f,0f,3,-0.47843614f,0.587502f,-0.6526414f,0f,0f,0f ) ;
  }

  @Test
  public void test154() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.99564f,-99.99648f,-1.371703f,0f,0f,0f,0f,0f,0f,-1,0.726727f,-0.20028102f,-0.6570809f,0f,0f,0f ) ;
  }

  @Test
  public void test155() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,99.999695f,47.117855f,94.17094f,0f,0f,0f,0f,0f,0f,1,0.23698574f,0.96534455f,-0.109305255f,0f,0f,0f ) ;
  }

  @Test
  public void test156() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,100.0f,100.0f,-100.0f,0f,0f,0f,-463,0.031810142f,-0.09299799f,-0.995158f,0f,0f,0f ) ;
  }

  @Test
  public void test157() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,100.0f,-100.0f,100.0f,631.0f,1761.0f,634.0f,2609,0.81163365f,-0.45033917f,-0.37208256f,0f,0f,0f ) ;
  }

  @Test
  public void test158() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,100.0f,100.0f,-100.0f,991.0f,-387.0f,-1501.0f,1730,0.24826565f,0.23503515f,-0.939746f,0f,0f,0f ) ;
  }

  @Test
  public void test159() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-13.934494f,58.53959f,161.3116f,1070.0f,938.0f,248.0f,-279,0.029536918f,-0.31066003f,0.28508306f,0f,0f,0f ) ;
  }

  @Test
  public void test160() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-1.845115f,84.93156f,60.411118f,78.0f,-580.0f,818.0f,733,-79.789474f,0.63301104f,-3.3269267f,0f,0f,0f ) ;
  }

  @Test
  public void test161() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-33.438564f,13.376115f,80.58088f,0f,0f,0f,-1118,0.053205084f,0.025156938f,0.2616961f,0f,0f,0f ) ;
  }

  @Test
  public void test162() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-48.869675f,-20.82454f,27.032572f,-209.0f,262.0f,-176.0f,-763,0.287272f,-0.86688393f,-0.031079141f,0f,0f,0f ) ;
  }

  @Test
  public void test163() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,55.85046f,30.040197f,22.240232f,1285.0f,-680.0f,-713.0f,4,0.5226628f,-0.66767526f,0.457694f,0f,0f,0f ) ;
  }

  @Test
  public void test164() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-68.655205f,-31.707142f,-4.073332f,401.0f,-793.0f,-586.0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test165() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,99.998184f,8.485088f,9.649316f,265.0f,649.0f,-239.0f,-1215,-0.025244435f,0.98319966f,-0.1807792f,0f,0f,0f ) ;
  }

  @Test
  public void test166() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,10.973512f,0f,0f,0f,0f,0f,-86.56587f,-95.39341f,-53.49722f,-622.0f,814.0f,-445.0f,459,-25.565535f,54.637173f,-84.592f,0f,0f,0f ) ;
  }

  @Test
  public void test167() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,13.79744f,0f,0f,0f,0f,0f,-100.0f,-41.47209f,33.612404f,0f,0f,0f,-2,-0.2651572f,0.497856f,0.13089918f,0f,0f,0f ) ;
  }

  @Test
  public void test168() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-1.4210855E-14f,0f,0f,0f,0f,0f,100.0f,-100.0f,-100.0f,0f,0f,0f,-1,0.3672508f,0.21464068f,0.053785544f,0f,0f,0f ) ;
  }

  @Test
  public void test169() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,14.33954f,0f,0f,0f,0f,0f,-32.51586f,95.35263f,39.11812f,765.0f,2609.0f,-450.0f,-286,-0.52092445f,0.2620272f,-0.8123912f,0f,0f,0f ) ;
  }

  @Test
  public void test170() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,1.4871036f,0f,0f,0f,0f,0f,-37.52894f,98.42677f,-83.58777f,-728.0f,192.0f,-963.0f,237,-69.352615f,74.20186f,99.46928f,0f,0f,0f ) ;
  }

  @Test
  public void test171() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,1.5855863f,0f,0f,0f,0f,0f,29.943512f,22.932161f,-37.69633f,246.0f,790.0f,-1756.0f,-201,-0.3823034f,0.8602228f,0.18428484f,0f,0f,0f ) ;
  }

  @Test
  public void test172() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,16.43954f,0f,0f,0f,0f,0f,-67.59789f,-36.680458f,-33.430374f,-995.0f,924.0f,-882.0f,-472,-62.11096f,-35.75042f,-63.675232f,0f,0f,0f ) ;
  }

  @Test
  public void test173() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,17.628721f,0f,0f,0f,0f,0f,-42.91867f,47.531574f,66.270905f,-1109.0f,-1615.0f,1199.0f,-1569,-0.25040835f,0.6981526f,-0.41203767f,0f,0f,0f ) ;
  }

  @Test
  public void test174() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,22.246723f,0f,0f,0f,0f,0f,-6.445652f,-5.7658415f,-1.1555835f,600.0f,-911.0f,87.0f,51,-18.57387f,33.33015f,-62.700504f,0f,0f,0f ) ;
  }

  @Test
  public void test175() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,2.248131f,0f,0f,0f,0f,0f,-38.89564f,7.6879644f,-53.95336f,-235.0f,-431.0f,108.0f,2079,0.024869012f,0.05251704f,-1.1773915f,0f,0f,0f ) ;
  }

  @Test
  public void test176() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-22.61965f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test177() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,23.561562f,0f,0f,0f,0f,0f,-9.531808f,9.327799f,-22.823853f,1184.0f,192.0f,-416.0f,-160,-27.07816f,-60.34111f,-77.47211f,0f,0f,0f ) ;
  }

  @Test
  public void test178() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,25.118803f,0f,0f,0f,0f,0f,-45.347256f,-59.7931f,3.2634802f,-104.0f,-509.0f,-734.0f,-53,-71.08442f,55.718765f,33.12848f,0f,0f,0f ) ;
  }

  @Test
  public void test179() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,25.163273f,0f,0f,0f,0f,0f,37.8384f,-74.50066f,-30.024563f,-797.0f,-775.0f,167.0f,474,95.934715f,10.489877f,1.1639993f,0f,0f,0f ) ;
  }

  @Test
  public void test180() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,251.69006f,0f,0f,0f,0f,0f,-127.29697f,-96.76662f,-5.3899546f,-93.0f,-32.0f,-103.0f,-5390,-2.384575f,-1.0456188f,-0.37460062f,0f,0f,0f ) ;
  }

  @Test
  public void test181() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,251.95045f,0f,0f,0f,0f,0f,-17.120724f,-52.605736f,17.77382f,784.0f,-1349.0f,-163.0f,-1007,50.19831f,-114.74999f,-94.66787f,0f,0f,0f ) ;
  }

  @Test
  public void test182() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,252.37234f,0f,0f,0f,0f,0f,120.32584f,29.18851f,84.869125f,1005.0f,-757.0f,997.0f,-57,13.731922f,74.04884f,-44.971165f,0f,0f,0f ) ;
  }

  @Test
  public void test183() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,252.91887f,0f,0f,0f,0f,0f,-81.54073f,-77.72324f,-65.78584f,-290.0f,-656.0f,211.0f,970,-78.86901f,106.12591f,-27.611591f,0f,0f,0f ) ;
  }

  @Test
  public void test184() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.37712f,0f,0f,0f,0f,0f,58.974113f,183.51343f,-30.021208f,-634.0f,961.0f,-1203.0f,-695,26.153185f,94.24841f,0.8779802f,0f,0f,0f ) ;
  }

  @Test
  public void test185() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.61516f,0f,0f,0f,0f,0f,-4.5605025f,-11.789618f,-187.13768f,1021.0f,264.0f,-240.0f,-278,-0.09962166f,0.35803953f,-2.985489f,0f,0f,0f ) ;
  }

  @Test
  public void test186() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.72104f,0f,0f,0f,0f,0f,-66.75337f,-91.53194f,-232.1632f,-1253.0f,-688.0f,124.0f,579,-0.11178884f,1.2223924f,-0.5378382f,0f,0f,0f ) ;
  }

  @Test
  public void test187() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.84741f,0f,0f,0f,0f,0f,100.0f,140.99254f,100.0f,1285.0f,1040.0f,682.0f,1042,-186.03674f,149.21971f,127.886185f,0f,0f,0f ) ;
  }

  @Test
  public void test188() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.902f,0f,0f,0f,0f,0f,10.307096f,179.47336f,47.58203f,1559.0f,779.0f,725.0f,-244,-0.13546884f,0.032331888f,1.914705f,0f,0f,0f ) ;
  }

  @Test
  public void test189() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.19107f,0f,0f,0f,0f,0f,17.581297f,-134.31627f,-6.9051948f,862.0f,-606.0f,-290.0f,587,-0.11167299f,-1.7041653f,0.22738092f,0f,0f,0f ) ;
  }

  @Test
  public void test190() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.21204f,0f,0f,0f,0f,0f,26.489016f,3.430764f,96.97367f,1252.0f,-496.0f,1284.0f,-839,-0.50420374f,0.45609894f,0.28281957f,0f,0f,0f ) ;
  }

  @Test
  public void test191() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.37946f,0f,0f,0f,0f,0f,-125.287445f,29.208311f,60.167942f,-305.0f,1255.0f,613.0f,530,-94.26321f,-92.88442f,-151.09497f,0f,0f,0f ) ;
  }

  @Test
  public void test192() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.42961f,0f,0f,0f,0f,0f,74.00362f,-15.408407f,59.36369f,-257.0f,-997.0f,575.0f,911,85.51174f,-7.322702f,41.29619f,0f,0f,0f ) ;
  }

  @Test
  public void test193() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.48447f,0f,0f,0f,0f,0f,-100.0f,-100.0f,-100.0f,-23.0f,18.0f,-521.0f,1088,100.0f,-130.09848f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test194() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.80157f,0f,0f,0f,0f,0f,72.48672f,-25.608685f,-82.88361f,901.0f,432.0f,-1035.0f,-821,33.68667f,85.42355f,3.104269f,0f,0f,0f ) ;
  }

  @Test
  public void test195() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.89456f,0f,0f,0f,0f,0f,-40.549294f,-31.6557f,71.32771f,-1039.0f,-1082.0f,-428.0f,-652,-72.09681f,46.396988f,37.73549f,0f,0f,0f ) ;
  }

  @Test
  public void test196() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.91345f,0f,0f,0f,0f,0f,136.76268f,-194.55348f,-97.14628f,-414.0f,517.0f,-2382.0f,-512,0.8209602f,-2.8503654f,-0.27889878f,0f,0f,0f ) ;
  }

  @Test
  public void test197() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.99792f,0f,0f,0f,0f,0f,159.91911f,-179.39452f,86.153984f,672.0f,-84.0f,705.0f,-92,100.0f,-161.75592f,-67.05699f,0f,0f,0f ) ;
  }

  @Test
  public void test198() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.08522f,0f,0f,0f,0f,0f,-89.978745f,10.992976f,39.27651f,-2210.0f,-924.0f,-377.0f,-1135,41.496635f,-21.671167f,101.740204f,0f,0f,0f ) ;
  }

  @Test
  public void test199() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.13919f,0f,0f,0f,0f,0f,-47.01749f,182.30768f,92.24604f,-1463.0f,376.0f,-583.0f,98,-18.40215f,72.011f,154.26682f,0f,0f,0f ) ;
  }

  @Test
  public void test200() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.54468f,0f,0f,0f,0f,0f,-218.64355f,-37.376595f,53.775894f,-1845.0f,238.0f,768.0f,-545,0.22485581f,-1.1953075f,0.21057269f,0f,0f,0f ) ;
  }

  @Test
  public void test201() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.7596f,0f,0f,0f,0f,0f,100.0f,-8.46674f,50.901474f,1110.0f,-399.0f,-519.0f,-167,126.04232f,63.747044f,54.27051f,0f,0f,0f ) ;
  }

  @Test
  public void test202() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,256.4429f,0f,0f,0f,0f,0f,78.91101f,-37.845345f,-210.37872f,502.0f,609.0f,-531.0f,716,0.1076853f,-2.4420874f,-0.47676298f,0f,0f,0f ) ;
  }

  @Test
  public void test203() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,256.70267f,0f,0f,0f,0f,0f,-100.0f,100.0f,100.0f,-458.0f,315.0f,-596.0f,-433,-174.69923f,55.585114f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test204() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,257.00433f,0f,0f,0f,0f,0f,107.48539f,-94.39529f,-22.932283f,193.0f,-826.0f,-1858.0f,10,0.18260634f,-0.24995165f,1.0750203f,0f,0f,0f ) ;
  }

  @Test
  public void test205() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,259.67993f,0f,0f,0f,0f,0f,56.06837f,39.428043f,-156.7935f,-917.0f,-1252.0f,-756.0f,-1214,1.8983883f,0.066003144f,-0.83714783f,0f,0f,0f ) ;
  }

  @Test
  public void test206() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,259.72638f,0f,0f,0f,0f,0f,17.680084f,91.680016f,69.905754f,-348.0f,1406.0f,909.0f,378,-54.541534f,58.38497f,-62.78542f,0f,0f,0f ) ;
  }

  @Test
  public void test207() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,25.99192f,0f,0f,0f,0f,0f,-3.1333249f,61.32376f,67.48735f,-179.0f,-580.0f,897.0f,812,-20.56781f,89.3719f,21.258453f,0f,0f,0f ) ;
  }

  @Test
  public void test208() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,262.64386f,0f,0f,0f,0f,0f,-100.0f,100.0f,100.0f,-813.0f,-598.0f,-97.0f,201,-100.0f,154.20921f,-37.319134f,0f,0f,0f ) ;
  }

  @Test
  public void test209() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,270.00208f,0f,0f,0f,0f,0f,-38.840157f,89.44309f,-94.95564f,101.0f,-386.0f,-1080.0f,109,-0.68349314f,-0.13982427f,0.025522066f,0f,0f,0f ) ;
  }

  @Test
  public void test210() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,2.748196f,0f,0f,0f,0f,0f,61.380177f,69.60884f,24.009642f,-242.0f,291.0f,-225.0f,-536,0.6436718f,-0.62984794f,0.25154695f,0f,0f,0f ) ;
  }

  @Test
  public void test211() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,293.05676f,0f,0f,0f,0f,0f,-100.0f,100.0f,-100.0f,-965.0f,692.0f,-614.0f,-1273,-100.0f,-82.698135f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test212() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,295.86957f,0f,0f,0f,0f,0f,-70.13234f,-57.95059f,-51.554874f,-789.0f,-667.0f,-779.0f,-1602,0.13064885f,-1.3221345f,-0.35220876f,0f,0f,0f ) ;
  }

  @Test
  public void test213() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,2.9646568f,0f,0f,0f,0f,0f,51.667294f,-85.298775f,-81.402916f,997.0f,-22.0f,130.0f,63,88.05079f,-87.00841f,97.91736f,0f,0f,0f ) ;
  }

  @Test
  public void test214() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,31.479656f,0f,0f,0f,0f,0f,11.128098f,-12.408066f,-67.30153f,-844.0f,-681.0f,-14.0f,-1146,-0.38019976f,0.09382063f,-0.58191633f,0f,0f,0f ) ;
  }

  @Test
  public void test215() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,36.311497f,0f,0f,0f,0f,0f,66.30269f,-36.341656f,-31.304564f,-239.0f,-573.0f,159.0f,-1001,0.85638016f,0.38324228f,-0.08726102f,0f,0f,0f ) ;
  }

  @Test
  public void test216() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,36.63022f,0f,0f,0f,0f,0f,-14.98651f,-19.93259f,-79.874306f,194.0f,1861.0f,-501.0f,-1291,95.33862f,-84.83955f,3.2836413f,0f,0f,0f ) ;
  }

  @Test
  public void test217() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,36.758743f,0f,0f,0f,0f,0f,-31.4781f,-7.3365226f,-47.627434f,299.0f,-51.0f,-282.0f,-74,-0.72073793f,-0.07192371f,0.30047473f,0f,0f,0f ) ;
  }

  @Test
  public void test218() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,37.39888f,0f,0f,0f,0f,0f,-67.99511f,70.57149f,-6.781452f,-73.0f,-22.0f,503.0f,531,0.01647579f,0.23132102f,-0.045586996f,0f,0f,0f ) ;
  }

  @Test
  public void test219() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,41.613556f,0f,0f,0f,0f,0f,13.974641f,-67.32481f,87.2232f,901.0f,993.0f,1316.0f,775,-0.51551f,-0.43831804f,0.6438155f,0f,0f,0f ) ;
  }

  @Test
  public void test220() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,420.09695f,0f,0f,0f,0f,0f,47.878414f,89.8774f,35.749596f,1124.0f,1017.0f,479.0f,-327,-0.4594319f,0.4626415f,0.027144263f,0f,0f,0f ) ;
  }

  @Test
  public void test221() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,43.1987f,0f,0f,0f,0f,0f,-100.0f,-61.99789f,-15.776152f,577.0f,-892.0f,-784.0f,-308,-0.1306227f,0.07437338f,0.5356996f,0f,0f,0f ) ;
  }

  @Test
  public void test222() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,43.351482f,0f,0f,0f,0f,0f,-3.1383138f,4.4312506f,6.5889993f,-640.0f,262.0f,-480.0f,-1137,52.591045f,-54.42289f,61.64952f,0f,0f,0f ) ;
  }

  @Test
  public void test223() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,44.30425f,0f,0f,0f,0f,0f,27.673338f,18.741035f,-26.442732f,1050.0f,-693.0f,-1374.0f,2,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test224() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,45.124634f,0f,0f,0f,0f,0f,49.46921f,-99.170135f,100.0f,0f,0f,0f,1,0.117353864f,0.023461044f,0.21480232f,0f,0f,0f ) ;
  }

  @Test
  public void test225() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-45.93694f,0f,0f,0f,0f,0f,44.338737f,52.18191f,-50.627857f,0f,0f,0f,-735,37.211452f,73.04399f,74.89471f,0f,0f,0f ) ;
  }

  @Test
  public void test226() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,51.324768f,0f,0f,0f,0f,0f,45.895897f,-46.326847f,-76.328f,356.0f,-709.0f,644.0f,663,-39.584663f,-78.78087f,24.013409f,0f,0f,0f ) ;
  }

  @Test
  public void test227() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,54.79048f,0f,0f,0f,0f,0f,-75.31624f,-30.606003f,81.610214f,93.0f,-830.0f,68.0f,487,-25.147903f,70.534294f,34.894917f,0f,0f,0f ) ;
  }

  @Test
  public void test228() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,55.69508f,0f,0f,0f,0f,0f,-6.931904f,-5.3914375f,-0.8309894f,49.0f,62.0f,-811.0f,670,-75.83924f,39.968407f,1.9516544f,0f,0f,0f ) ;
  }

  @Test
  public void test229() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,56.579056f,0f,0f,0f,0f,0f,66.93373f,17.315784f,-85.13924f,-646.0f,134.0f,-176.0f,-542,95.81899f,-4.649046f,-9.95691f,0f,0f,0f ) ;
  }

  @Test
  public void test230() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,5.81864f,0f,0f,0f,0f,0f,9.723869f,40.842087f,-42.36077f,-1009.0f,987.0f,720.0f,445,-0.63018054f,-0.066073924f,-0.2539553f,0f,0f,0f ) ;
  }

  @Test
  public void test231() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,59.612297f,0f,0f,0f,0f,0f,39.004395f,12.77267f,-50.984463f,673.0f,267.0f,777.0f,442,0.41942367f,-0.3289382f,0.2384638f,0f,0f,0f ) ;
  }

  @Test
  public void test232() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,5.967235f,0f,0f,0f,0f,0f,60.29503f,35.725407f,-38.053f,385.0f,-858.0f,-197.0f,-3,-10.876149f,40.868637f,21.135546f,0f,0f,0f ) ;
  }

  @Test
  public void test233() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,60.457855f,0f,0f,0f,0f,0f,-54.086376f,83.192276f,-55.06258f,-846.0f,844.0f,405.0f,137,60.000546f,24.023615f,-22.64029f,0f,0f,0f ) ;
  }

  @Test
  public void test234() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,61.04974f,0f,0f,0f,0f,0f,99.32823f,-100.0f,100.0f,909.0f,-624.0f,608.0f,846,0.8213227f,0.3450126f,-0.4543076f,0f,0f,0f ) ;
  }

  @Test
  public void test235() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,6.3108872E-30f,0f,0f,0f,0f,0f,-22.269989f,14.756313f,6.411875f,-220.0f,-451.0f,275.0f,-752,0.054920614f,-0.322164f,0.94524527f,0f,0f,0f ) ;
  }

  @Test
  public void test236() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,63.21872f,0f,0f,0f,0f,0f,-11.688848f,-9.637353f,9.132571f,1250.0f,-740.0f,833.0f,622,-0.956342f,-0.13911778f,-0.25583404f,0f,0f,0f ) ;
  }

  @Test
  public void test237() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,63.75376f,0f,0f,0f,0f,0f,3.5239544f,-76.16798f,43.188564f,0f,0f,0f,473,-51.179493f,2.3699734f,8.355691f,0f,0f,0f ) ;
  }

  @Test
  public void test238() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,65.99301f,0f,0f,0f,0f,0f,-26.743229f,3.1903834f,55.62525f,0f,0f,0f,524,-96.86395f,86.18f,7.8391895f,0f,0f,0f ) ;
  }

  @Test
  public void test239() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,70.51589f,0f,0f,0f,0f,0f,98.57265f,52.21457f,-39.765022f,663.0f,204.0f,142.0f,554,92.630806f,-41.20038f,-64.017525f,0f,0f,0f ) ;
  }

  @Test
  public void test240() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,73.55361f,0f,0f,0f,0f,0f,-9.072773f,15.143587f,5.1753874f,-529.0f,-482.0f,483.0f,-29,-0.788648f,0.053720865f,-0.49206504f,0f,0f,0f ) ;
  }

  @Test
  public void test241() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,75.32331f,0f,0f,0f,0f,0f,88.3604f,-43.742317f,-72.21628f,-288.0f,-1159.0f,640.0f,3,0.72402096f,0.10092465f,0.2748696f,0f,0f,0f ) ;
  }

  @Test
  public void test242() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,76.110794f,0f,0f,0f,0f,0f,-44.75686f,42.66187f,-90.82246f,-778.0f,-20.0f,374.0f,436,-30.515852f,-16.801113f,-88.35785f,0f,0f,0f ) ;
  }

  @Test
  public void test243() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,77.04665f,0f,0f,0f,0f,0f,-62.043476f,-16.743923f,12.04349f,-1860.0f,-149.0f,266.0f,-978,-19.237316f,14.137139f,-79.44862f,0f,0f,0f ) ;
  }

  @Test
  public void test244() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-77.72976f,0f,0f,0f,0f,0f,-100.9297f,71.105385f,-3.5985885f,0f,0f,0f,2,-0.6303756f,-0.7693873f,0.07742556f,0f,0f,0f ) ;
  }

  @Test
  public void test245() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,78.21932f,0f,0f,0f,0f,0f,42.3169f,-71.64338f,-45.18437f,139.0f,-156.0f,-93.0f,-795,59.221806f,18.762257f,25.714458f,0f,0f,0f ) ;
  }

  @Test
  public void test246() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,83.0232f,0f,0f,0f,0f,0f,40.01601f,-42.75241f,26.51194f,-559.0f,-750.0f,-475.0f,361,-33.662453f,-40.49164f,-14.486982f,0f,0f,0f ) ;
  }

  @Test
  public void test247() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,83.15161f,0f,0f,0f,0f,0f,-100.0f,44.09642f,-27.667719f,-974.0f,70.0f,-2746.0f,1593,-0.26571178f,-0.68101466f,-0.6823608f,0f,0f,0f ) ;
  }

  @Test
  public void test248() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,83.434105f,0f,0f,0f,0f,0f,-53.158817f,-14.1820965f,65.5979f,-156.0f,-429.0f,934.0f,-67,46.987118f,-97.99519f,16.890818f,0f,0f,0f ) ;
  }

  @Test
  public void test249() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,8.389385f,0f,0f,0f,0f,0f,-69.36837f,-18.69508f,5.3725057f,159.0f,638.0f,652.0f,1,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test250() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,8.411183f,0f,0f,0f,0f,0f,77.17858f,-15.932181f,65.270905f,980.0f,1052.0f,-902.0f,-1,7.8460674f,0.8368589f,4.9926395f,0f,0f,0f ) ;
  }

  @Test
  public void test251() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,8.418839f,0f,0f,0f,0f,0f,38.717274f,-3.397983f,-16.017641f,-288.0f,433.0f,-788.0f,695,53.766613f,53.853394f,95.55581f,0f,0f,0f ) ;
  }

  @Test
  public void test252() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-86.156815f,0f,0f,0f,0f,0f,-76.32097f,93.98813f,25.407917f,0f,0f,0f,617,75.35279f,67.75828f,-24.302479f,0f,0f,0f ) ;
  }

  @Test
  public void test253() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,86.81901f,0f,0f,0f,0f,0f,-26.592995f,-70.957565f,-0.20654891f,-318.0f,120.0f,-450.0f,1182,0.08168432f,-0.027534386f,-1.0577679f,0f,0f,0f ) ;
  }

  @Test
  public void test254() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-87.59058f,0f,0f,0f,0f,0f,-10.367915f,63.200245f,-40.43415f,0f,0f,0f,1659,0.7029729f,0.50199944f,0.24047272f,0f,0f,0f ) ;
  }

  @Test
  public void test255() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,89.199524f,0f,0f,0f,0f,0f,47.743f,-38.789837f,-21.377813f,649.0f,-703.0f,-616.0f,-985,27.972645f,85.65897f,-92.95616f,0f,0f,0f ) ;
  }

  @Test
  public void test256() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,95.367546f,0f,0f,0f,0f,0f,27.582144f,13.619126f,43.79935f,-205.0f,-1106.0f,473.0f,996,60.951084f,27.192295f,-46.83852f,0f,0f,0f ) ;
  }

  @Test
  public void test257() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,9.823188E-6f,0f,0f,0f,0f,0f,-2.0283055f,-22.518301f,-12.389723f,1103.0f,436.0f,-973.0f,1252,-0.42261675f,-0.4739831f,-0.77286875f,0f,0f,0f ) ;
  }

  @Test
  public void test258() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,98.31903f,0f,0f,0f,0f,0f,-93.72602f,10.8308115f,17.766472f,-33.0f,843.0f,-688.0f,557,-65.8737f,-18.586094f,94.60718f,0f,0f,0f ) ;
  }

  @Test
  public void test259() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-99.93579f,0f,0f,0f,0f,0f,-24.950956f,52.97675f,-31.982508f,0f,0f,0f,-200,-0.7915443f,-0.48623207f,-0.37018365f,0f,0f,0f ) ;
  }

  @Test
  public void test260() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,99.957466f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test261() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,99.98839f,0f,0f,0f,0f,0f,100.0f,-39.400368f,100.0f,-695.0f,-405.0f,1286.0f,-1527,0.525587f,0.42420238f,0.37855157f,0f,0f,0f ) ;
  }

  @Test
  public void test262() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-0.0476837f,0f,0f,0f,0f,0f,0f,0f,-10.106842f,81.05541f,-43.326073f,0f,0f,0f,-408,0.008509039f,0.07160673f,0.13278228f,0f,0f,0f ) ;
  }

  @Test
  public void test263() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0.0f,0f,-100.0f,0f,0f,0f,0f,0f,-100.0f,-92.8347f,0.590658f,0f,0f,0f,575,-16.517353f,64.313156f,-14.527661f,0f,0f,0f ) ;
  }

  @Test
  public void test264() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-16.939358f,6.1643386f,0f,0f,0f,-460,0.63730574f,-0.18920457f,-0.7454882f,0f,0f,0f ) ;
  }

  @Test
  public void test265() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,-45.071938f,-20.929384f,-25.689535f,0f,0f,0f,1,-0.09855279f,0.87154496f,0.45314178f,0f,0f,0f ) ;
  }

  @Test
  public void test266() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,0f,0f,0f,5.328156f,0.21360075f,-2.5081959f,528.0f,-217.0f,-420.0f,-6,1.2807435f,-1.9351051f,2.5567837f,0f,0f,0f ) ;
  }

  @Test
  public void test267() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,0f,0f,0f,84.42107f,65.88224f,-63.344345f,57.0f,-510.0f,767.0f,-2,-0.17967232f,0.0030622452f,0.28246158f,0f,0f,0f ) ;
  }

  @Test
  public void test268() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,100.0f,100.0f,100.0f,0f,0f,0f,904,0.7461704f,-0.65885895f,-0.09557529f,0f,0f,0f ) ;
  }

  @Test
  public void test269() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,100.0f,0f,0f,0f,0f,0f,0f,0f,-46.9606f,-17.10882f,-79.3054f,-953.0f,1525.0f,-1177.0f,-143,-0.09979092f,-0.8487138f,0.51935214f,0f,0f,0f ) ;
  }

  @Test
  public void test270() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,-100.0f,0f,2.7694976f,0f,0f,0f,0f,0f,100.0f,-43.46817f,100.0f,0f,0f,0f,-1850,-0.042575996f,0.1611166f,-0.9860166f,0f,0f,0f ) ;
  }

  @Test
  public void test271() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,18.658274f,0f,0f,0f,0f,0f,0f,0f,57.23131f,-31.785221f,-48.72086f,1188.0f,-58.0f,1437.0f,462,0.29259506f,-0.22036317f,1.0272052f,0f,0f,0f ) ;
  }

  @Test
  public void test272() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-26.409506f,0f,0.0f,0f,0f,0f,0f,0f,71.02791f,-125.78137f,-100.0f,0f,0f,0f,1249,-0.9943996f,0.1013321f,0.030021254f,0f,0f,0f ) ;
  }

  @Test
  public void test273() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,32.548805f,0f,0f,0f,0f,0f,0f,0f,-75.10991f,-100.0f,-100.0f,0f,0f,0f,-1779,-0.28589115f,0.4276484f,0.8575448f,0f,0f,0f ) ;
  }

  @Test
  public void test274() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,69.34617f,0f,0f,0f,0f,0f,0f,0f,96.33287f,-60.60324f,-60.660526f,1496.0f,-240.0f,840.0f,-498,-0.54908943f,-0.13960256f,-0.33246127f,0f,0f,0f ) ;
  }

  @Test
  public void test275() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-74.88557f,0f,0f,0f,0f,0f,0f,0f,-100.0f,100.0f,-100.0f,0f,0f,0f,-1250,0.4986863f,0.4112802f,0.76299447f,0f,0f,0f ) ;
  }

  @Test
  public void test276() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,100.0f,7.953466f,0f,0f,0f,0f,0f,0f,0f,63.5443f,100.0f,-100.0f,0f,0f,0f,1,-0.860662f,-0.07673509f,0.28011075f,0f,0f,0f ) ;
  }

  @Test
  public void test277() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,99.966736f,0f,0f,0f,0f,0f,0f,0f,99.959404f,-37.72128f,98.44226f,0f,0f,0f,1,-0.19212872f,1.4352787f,0.47203302f,0f,0f,0f ) ;
  }

  @Test
  public void test278() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1008.0f,-1.0f,0f,652.0f,0f,0f,0f,0f,0f,-234.0f,1224.0f,-2042.0f,203.0f,-1091.0f,89.0f,490,0.036544904f,-0.07359348f,0.911472f,0f,0f,0f ) ;
  }

  @Test
  public void test279() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1008.0f,381.0f,0f,246.0f,0f,0f,0f,0f,0f,-49.0f,-1041.0f,-660.0f,127.0f,294.0f,-1334.0f,1206,47.28068f,-39.86464f,59.367283f,0f,0f,0f ) ;
  }

  @Test
  public void test280() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,10.0f,-916.0f,0f,2972.0f,0f,0f,0f,0f,0f,-198.0f,556.0f,125.0f,-515.0f,-564.0f,1694.0f,533,-3.2700746f,-1.3547517f,-1.494664f,0f,0f,0f ) ;
  }

  @Test
  public void test281() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1010.0f,1977.0f,0f,454.0f,0f,0f,0f,0f,0f,6.0f,-194.0f,230.0f,-1019.0f,497.0f,446.0f,945,0.94821423f,0.30555886f,0.08731393f,0f,0f,0f ) ;
  }

  @Test
  public void test282() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1023.0f,-879.0f,0f,245.0f,0f,0f,0f,0f,0f,99.0f,-687.0f,-1367.0f,-548.0f,310.0f,-1891.0f,-1424,0.0014993801f,0.67837375f,0.046834596f,0f,0f,0f ) ;
  }

  @Test
  public void test283() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1041.0f,-1908.0f,0f,457.0f,0f,0f,0f,0f,0f,-434.0f,308.0f,-421.0f,182.0f,433.0f,129.0f,2492,-0.22409528f,-0.34080833f,0.08261709f,0f,0f,0f ) ;
  }

  @Test
  public void test284() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1046.0f,635.0f,0f,877.0f,0f,0f,0f,0f,0f,375.0f,-831.0f,-998.0f,-196.0f,587.0f,-563.0f,-278,0.25010344f,0.7863124f,-0.19605294f,0f,0f,0f ) ;
  }

  @Test
  public void test285() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1070.0f,1652.0f,0f,63.0f,0f,0f,0f,0f,0f,92.0f,442.0f,-2505.0f,359.0f,748.0f,-1807.0f,-924,-0.5738538f,0.75789726f,0.26627067f,0f,0f,0f ) ;
  }

  @Test
  public void test286() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1076.0f,-1434.0f,0f,258.0f,0f,0f,0f,0f,0f,886.0f,453.0f,-955.0f,-91.0f,337.0f,-93.0f,-981,-15.210729f,-4.0473413f,27.278067f,0f,0f,0f ) ;
  }

  @Test
  public void test287() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.08252804E-19f,1.816759E-5f,0f,1.540744E-33f,0f,0f,0f,0f,0f,-100.0f,-100.0f,100.0f,0f,0f,0f,673,0.30152047f,0.8656272f,-0.39972928f,0f,0f,0f ) ;
  }

  @Test
  public void test288() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1084.0f,720.0f,0f,866.0f,0f,0f,0f,0f,0f,116.0f,1074.0f,1361.0f,119.0f,1111.0f,425.0f,-1679,0.5475947f,-0.39637172f,-0.056352057f,0f,0f,0f ) ;
  }

  @Test
  public void test289() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1090.0f,710.0f,0f,1909.0f,0f,0f,0f,0f,0f,1071.0f,1146.0f,-1158.0f,128.0f,1894.0f,-970.0f,-968,-0.8983168f,0.11870962f,-0.26545072f,0f,0f,0f ) ;
  }

  @Test
  public void test290() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-10.921651f,15.420482f,0f,0f,0f,0f,0f,0f,0f,24.579994f,58.918556f,34.520073f,284.0f,-195.0f,-463.0f,-667,-0.39780343f,0.38361496f,-0.5730887f,0f,0f,0f ) ;
  }

  @Test
  public void test291() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1095.0f,480.0f,0f,-1.0f,0f,0f,0f,0f,0f,-1223.0f,-1379.0f,-1761.0f,-599.0f,-679.0f,-1197.0f,418,0.51810646f,0.84845775f,0.055618446f,0f,0f,0f ) ;
  }

  @Test
  public void test292() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1096.0f,390.0f,0f,988.0f,0f,0f,0f,0f,0f,-31.0f,118.0f,-195.0f,-342.0f,-793.0f,-426.0f,-916,75.33384f,73.65282f,96.62092f,0f,0f,0f ) ;
  }

  @Test
  public void test293() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,0.0f,0f,1908.0f,0f,0f,0f,0f,0f,-255.0f,-765.0f,-788.0f,34.0f,1648.0f,36.0f,86,8.589354f,208.59613f,-67.119286f,0f,0f,0f ) ;
  }

  @Test
  public void test294() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,1040.0f,0f,-3.0f,0f,0f,0f,0f,0f,-244.0f,-341.0f,1141.0f,-667.0f,-346.0f,-261.0f,417,-12.417268f,-85.18081f,-28.112755f,0f,0f,0f ) ;
  }

  @Test
  public void test295() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,1290.0f,0f,-996.0f,0f,0f,0f,0f,0f,1774.0f,791.0f,-727.0f,-230.0f,-583.0f,-978.0f,676,-0.5456891f,0.8194116f,-0.08359968f,0f,0f,0f ) ;
  }

  @Test
  public void test296() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,205.0f,0f,976.0f,0f,0f,0f,0f,0f,-539.0f,9.0f,-987.0f,685.0f,-960.0f,676.0f,248,-12.689339f,-96.13092f,49.75748f,0f,0f,0f ) ;
  }

  @Test
  public void test297() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,-225.0f,0f,337.0f,0f,0f,0f,0f,0f,472.0f,-41.0f,-159.0f,643.0f,158.0f,-785.0f,-272,-45.256718f,-18.753725f,-57.753307f,0f,0f,0f ) ;
  }

  @Test
  public void test298() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,344.0f,0f,-2.0f,0f,0f,0f,0f,0f,-2321.0f,-1171.0f,1084.0f,424.0f,-1213.0f,-1729.0f,177,0.081009775f,0.4049058f,0.25346407f,0f,0f,0f ) ;
  }

  @Test
  public void test299() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,438.0f,0f,-1041.0f,0f,0f,0f,0f,0f,-1310.0f,-459.0f,-266.0f,-930.0f,1280.0f,1477.0f,-918,0.369844f,0.6135409f,0.43938044f,0f,0f,0f ) ;
  }

  @Test
  public void test300() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,485.0f,0f,0.0f,0f,0f,0f,0f,0f,635.0f,-1521.0f,-150.0f,-1113.0f,-1528.0f,-395.0f,653,-95.88933f,151.54434f,-82.71838f,0f,0f,0f ) ;
  }

  @Test
  public void test301() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,691.0f,0f,-292.0f,0f,0f,0f,0f,0f,-977.0f,-924.0f,639.0f,1743.0f,1256.0f,-223.0f,1093,36.468975f,-92.46037f,-77.93928f,0f,0f,0f ) ;
  }

  @Test
  public void test302() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1.0f,695.0f,0f,685.0f,0f,0f,0f,0f,0f,-1639.0f,-652.0f,-775.0f,-533.0f,-112.0f,700.0f,-924,24.744339f,-71.00375f,24.267963f,0f,0f,0f ) ;
  }

  @Test
  public void test303() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,843.0f,-49.0f,-430.0f,0f,0f,0f,0f,0f,-1308.0f,924.0f,-794.0f,-540.0f,-415.0f,71.0f,-575,77.42879f,-21.88095f,-96.24444f,59.986958f,0f,0f ) ;
  }

  @Test
  public void test304() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,894.0f,0f,688.0f,0f,0f,0f,0f,0f,1634.0f,-1254.0f,709.0f,310.0f,-2142.0f,462.0f,1292,-0.121988f,-0.008453609f,0.26618838f,0f,0f,0f ) ;
  }

  @Test
  public void test305() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1.0f,9.0f,0f,-1213.0f,0f,0f,0f,0f,0f,-999.0f,1406.0f,-575.0f,993.0f,-748.0f,1005.0f,989,100.0f,-23.533092f,38.02315f,0f,0f,0f ) ;
  }

  @Test
  public void test306() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1100.0f,-96.0f,0f,256.0f,0f,0f,0f,0f,0f,-656.0f,779.0f,1159.0f,51.0f,270.0f,664.0f,784,-35.023224f,-164.65529f,42.14036f,0f,0f,0f ) ;
  }

  @Test
  public void test307() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,110.0f,602.0f,0f,410.0f,0f,0f,0f,0f,0f,780.0f,-442.0f,-739.0f,738.0f,243.0f,-747.0f,-536,-72.95923f,-5.502314f,22.163326f,0f,0f,0f ) ;
  }

  @Test
  public void test308() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1105.0f,453.0f,0f,-1.0f,0f,0f,0f,0f,0f,-960.0f,-143.0f,543.0f,2.0f,790.0f,579.0f,586,108.75237f,-95.24748f,65.34473f,0f,0f,0f ) ;
  }

  @Test
  public void test309() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,11.0f,803.0f,0f,377.0f,0f,0f,0f,0f,0f,-1036.0f,-475.0f,-731.0f,-1034.0f,-1065.0f,83.0f,2499,0.9494515f,-0.16020446f,-0.25062257f,0f,0f,0f ) ;
  }

  @Test
  public void test310() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1115.0f,457.0f,0f,248.0f,0f,0f,0f,0f,0f,924.0f,-603.0f,399.0f,217.0f,-78.0f,485.0f,-940,-25.493269f,-29.74587f,14.082759f,0f,0f,0f ) ;
  }

  @Test
  public void test311() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-11.207857f,0f,0f,0f,0f,0f,0f,0f,0f,-59.77725f,23.73805f,12.744157f,0f,0f,0f,-1036,0.36457112f,-0.09620464f,-0.20044097f,0f,0f,0f ) ;
  }

  @Test
  public void test312() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1135.0f,-321.0f,0f,255.0f,0f,0f,0f,0f,0f,101.0f,567.0f,329.0f,224.0f,849.0f,320.0f,-852,32.43951f,-35.068188f,-1.9475026f,0f,0f,0f ) ;
  }

  @Test
  public void test313() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-11.366091f,-6.0704956f,0f,-24.85666f,0f,0f,0f,0f,0f,83.26421f,28.427088f,1.1929344f,0f,0f,0f,-587,-0.16451138f,-0.8335546f,0.19964302f,0f,0f,0f ) ;
  }

  @Test
  public void test314() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1191.0f,1321.0f,0f,1109.0f,0f,0f,0f,0f,0f,-64.0f,-90.0f,14.0f,644.0f,-403.0f,365.0f,424,-99.14488f,69.80343f,-4.4974165f,0f,0f,0f ) ;
  }

  @Test
  public void test315() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1196.0f,-590.0f,0f,207.0f,0f,0f,0f,0f,0f,-306.0f,181.0f,-607.0f,-1281.0f,1796.0f,74.0f,1696,-0.24200362f,0.009836219f,0.610494f,0f,0f,0f ) ;
  }

  @Test
  public void test316() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-11.969431f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,90.77667f,-100.0f,0f,0f,0f,31,-0.21777627f,-0.47871953f,-0.1205788f,0f,0f,0f ) ;
  }

  @Test
  public void test317() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1200.0f,733.0f,0f,133.0f,0f,0f,0f,0f,0f,-80.0f,-696.0f,212.0f,-1678.0f,-110.0f,-988.0f,-1309,0.101935335f,0.54619914f,-0.08903713f,0f,0f,0f ) ;
  }

  @Test
  public void test318() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-12.0f,-2325.0f,0f,866.0f,0f,0f,0f,0f,0f,-300.0f,240.0f,578.0f,902.0f,-522.0f,669.0f,-677,3.8307478f,1.3384019f,0.10902793f,0f,0f,0f ) ;
  }

  @Test
  public void test319() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-122.0f,392.0f,701.0f,-619.0f,0f,0f,0f,0f,0f,-592.0f,954.0f,-491.0f,450.0f,-693.0f,976.0f,-498,-90.01167f,-85.961334f,50.04215f,3.4105809f,0f,0f ) ;
  }

  @Test
  public void test320() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-122.0f,-677.0f,0f,232.0f,0f,0f,0f,0f,0f,-169.0f,-858.0f,338.0f,970.0f,-862.0f,-35.0f,7,61.35262f,53.087067f,36.41951f,0f,0f,0f ) ;
  }

  @Test
  public void test321() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1265.0f,824.0f,-851.0f,1290.0f,0f,0f,0f,0f,0f,-3.0f,100.0f,-494.0f,162.0f,-419.0f,-455.0f,1496,0.14403412f,0.6697153f,0.3694578f,0f,-7.4490657f,0f ) ;
  }

  @Test
  public void test322() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1275.0f,-1016.0f,0f,960.0f,0f,0f,0f,0f,0f,268.0f,-780.0f,183.0f,923.0f,177.0f,-320.0f,-508,16.926695f,49.343414f,-55.68989f,0f,0f,0f ) ;
  }

  @Test
  public void test323() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1282.0f,864.0f,0f,1410.0f,0f,0f,0f,0f,0f,417.0f,-392.0f,-556.0f,480.0f,11.0f,352.0f,1542,-100.0f,54.670883f,-82.210434f,0f,0f,0f ) ;
  }

  @Test
  public void test324() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1285.0f,1120.0f,-312.0f,1130.0f,0f,0f,0f,0f,0f,472.0f,-36.0f,-192.0f,1867.0f,678.0f,790.0f,-205,0.16542923f,0.5137067f,0.73298216f,-99.90319f,0f,0f ) ;
  }

  @Test
  public void test325() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1289.0f,352.0f,0f,447.0f,0f,0f,0f,0f,0f,-252.0f,155.0f,-345.0f,909.0f,802.0f,-307.0f,-1495,-81.24192f,-97.55216f,36.2948f,0f,0f,0f ) ;
  }

  @Test
  public void test326() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1294.0f,769.0f,0f,106.0f,0f,0f,0f,0f,0f,46.0f,727.0f,806.0f,-295.0f,-80.0f,-199.0f,-96,-100.0f,-100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test327() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1304.0f,-267.0f,0f,1197.0f,0f,0f,0f,0f,0f,475.0f,1888.0f,531.0f,147.0f,-114.0f,970.0f,-708,-0.8904972f,0.10969589f,0.40655428f,0f,0f,0f ) ;
  }

  @Test
  public void test328() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1305.0f,1623.0f,0f,605.0f,0f,0f,0f,0f,0f,-88.0f,313.0f,-199.0f,134.0f,-388.0f,-670.0f,104,-0.15410386f,-0.21824248f,-0.040265545f,0f,0f,0f ) ;
  }

  @Test
  public void test329() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-132.0f,-1189.0f,0f,790.0f,0f,0f,0f,0f,0f,489.0f,14.0f,200.0f,-158.0f,-783.0f,444.0f,-77,-0.23752555f,0.025862612f,-0.13586952f,0f,0f,0f ) ;
  }

  @Test
  public void test330() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-133.0f,39.0f,81.0f,-362.0f,0f,0f,0f,0f,0f,799.0f,-233.0f,238.0f,486.0f,921.0f,197.0f,-811,-54.096912f,10.331787f,-3.287979f,-19.025267f,0f,0f ) ;
  }

  @Test
  public void test331() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1340.0f,365.0f,0f,290.0f,0f,0f,0f,0f,0f,186.0f,-998.0f,1154.0f,570.0f,-739.0f,-805.0f,530,100.0f,43.74783f,-51.83762f,0f,0f,0f ) ;
  }

  @Test
  public void test332() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,134.0f,174.0f,0f,638.0f,0f,0f,0f,0f,0f,-92.0f,979.0f,407.0f,577.0f,763.0f,-55.0f,-191,-9.973383f,-8.572737f,-6.060755f,0f,0f,0f ) ;
  }

  @Test
  public void test333() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1344.0f,1270.0f,0f,615.0f,0f,0f,0f,0f,0f,-1497.0f,-857.0f,-465.0f,-624.0f,1410.0f,-480.0f,2000,-1.5976259f,3.5955133f,-1.4815147f,0f,0f,0f ) ;
  }

  @Test
  public void test334() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1348.0f,480.0f,-1485.0f,1877.0f,0f,0f,0f,0f,0f,-691.0f,-154.0f,139.0f,1241.0f,-467.0f,-323.0f,1166,23.108711f,-13.432083f,99.99696f,55.446754f,2.2129517f,-5.4472f ) ;
  }

  @Test
  public void test335() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-136.0f,683.0f,0f,66.0f,0f,0f,0f,0f,0f,322.0f,219.0f,-272.0f,-1057.0f,-1046.0f,-321.0f,-739,53.95162f,-96.37062f,-13.723329f,0f,0f,0f ) ;
  }

  @Test
  public void test336() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-138.0f,826.0f,0f,363.0f,0f,0f,0f,0f,0f,100.0f,164.0f,6.0f,974.0f,-560.0f,-578.0f,-573,-0.029901138f,-0.62703687f,0.17157716f,0f,0f,0f ) ;
  }

  @Test
  public void test337() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1419.0f,-1475.0f,0f,244.0f,0f,0f,0f,0f,0f,-141.0f,11.0f,-2731.0f,-888.0f,-424.0f,447.0f,471,0.30371416f,-0.28835535f,0.8891341f,0f,0f,0f ) ;
  }

  @Test
  public void test338() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1426.0f,335.0f,0f,-42.0f,0f,0f,0f,0f,0f,-262.0f,984.0f,-2023.0f,-1352.0f,584.0f,1129.0f,-382,0.40129146f,0.62689275f,0.6678103f,0f,0f,0f ) ;
  }

  @Test
  public void test339() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1430.0f,-903.0f,0f,971.0f,0f,0f,0f,0f,0f,227.0f,787.0f,-746.0f,633.0f,-527.0f,-364.0f,1704,-0.8783167f,-0.004561226f,-0.27171028f,0f,0f,0f ) ;
  }

  @Test
  public void test340() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1470.0f,-2280.0f,0f,254.0f,0f,0f,0f,0f,0f,371.0f,510.0f,126.0f,-220.0f,1106.0f,476.0f,850,-0.24582835f,-0.7264183f,-0.08288592f,0f,0f,0f ) ;
  }

  @Test
  public void test341() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1473.0f,156.0f,0f,-960.0f,0f,0f,0f,0f,0f,502.0f,2245.0f,-376.0f,-1159.0f,-518.0f,1339.0f,-2407,-0.2605773f,-0.9414944f,0.21374689f,0f,0f,0f ) ;
  }

  @Test
  public void test342() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,147.39067f,0.0f,0f,98.561775f,0f,0f,0f,0f,0f,-12.596969f,14.403912f,44.238888f,0f,0f,0f,-748,-89.81689f,80.95795f,-73.64529f,0f,0f,0f ) ;
  }

  @Test
  public void test343() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1479.0f,1160.0f,0f,591.0f,0f,0f,0f,0f,0f,1842.0f,-886.0f,934.0f,1793.0f,273.0f,788.0f,556,0.36566362f,0.50446314f,-0.7660869f,0f,0f,0f ) ;
  }

  @Test
  public void test344() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-149.0f,172.0f,0f,348.0f,0f,0f,0f,0f,0f,560.0f,108.0f,-911.0f,1223.0f,529.0f,-131.0f,1188,0.43262228f,0.027893534f,0.90114367f,0f,0f,0f ) ;
  }

  @Test
  public void test345() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1493.0f,2.0f,0f,1781.0f,0f,0f,0f,0f,0f,945.0f,-553.0f,-164.0f,1234.0f,625.0f,227.0f,934,-0.0049727806f,-0.036227506f,0.6621581f,0f,0f,0f ) ;
  }

  @Test
  public void test346() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1526.0f,2.0f,0f,7.0f,0f,0f,0f,0f,0f,461.0f,-269.0f,-590.0f,300.0f,-365.0f,401.0f,-841,1.8535467f,-64.28846f,145.51086f,0f,0f,0f ) ;
  }

  @Test
  public void test347() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1538.0f,855.0f,0f,1828.0f,0f,0f,0f,0f,0f,-121.0f,-44.0f,216.0f,217.0f,-662.0f,-13.0f,46,-0.6573723f,0.15884553f,-0.4195432f,0f,0f,0f ) ;
  }

  @Test
  public void test348() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,156.0f,-781.0f,0f,851.0f,0f,0f,0f,0f,0f,-582.0f,-734.0f,-762.0f,-135.0f,-483.0f,564.0f,811,73.138916f,-0.43419683f,-11.943327f,0f,0f,0f ) ;
  }

  @Test
  public void test349() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1562.0f,-642.0f,0f,283.0f,0f,0f,0f,0f,0f,-783.0f,438.0f,-1870.0f,1178.0f,-887.0f,-1602.0f,-613,0.39619038f,0.11544796f,-0.04896085f,0f,0f,0f ) ;
  }

  @Test
  public void test350() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1573.0f,156.0f,0f,1659.0f,0f,0f,0f,0f,0f,752.0f,176.0f,-692.0f,-634.0f,821.0f,-482.0f,1617,-0.40521786f,1.0245401f,1.0159813f,0f,0f,0f ) ;
  }

  @Test
  public void test351() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1576.0f,773.0f,0f,737.0f,0f,0f,0f,0f,0f,299.0f,540.0f,329.0f,-467.0f,-117.0f,677.0f,-311,-54.73022f,82.97111f,-86.44396f,0f,0f,0f ) ;
  }

  @Test
  public void test352() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1577.0f,-259.0f,0f,1700.0f,0f,0f,0f,0f,0f,-987.0f,507.0f,-1334.0f,372.0f,2066.0f,509.0f,34,64.847885f,33.81325f,-32.42829f,0f,0f,0f ) ;
  }

  @Test
  public void test353() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1579.0f,-436.0f,0f,258.0f,0f,0f,0f,0f,0f,1366.0f,-749.0f,-15.0f,223.0f,-573.0f,-1310.0f,364,-0.3564073f,-0.1031441f,-0.6212974f,0f,0f,0f ) ;
  }

  @Test
  public void test354() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1594.0f,426.0f,0f,2671.0f,0f,0f,0f,0f,0f,638.0f,1485.0f,-112.0f,-713.0f,-821.0f,891.0f,389,-0.032694772f,-0.88798875f,-0.28492466f,0f,0f,0f ) ;
  }

  @Test
  public void test355() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-16.030375f,8.215438f,0f,0f,0f,0f,0f,0f,0f,100.0f,100.0f,-49.28474f,97.0f,67.0f,49.0f,-253,3.852855f,-4.557732f,-1.4302139f,0f,0f,0f ) ;
  }

  @Test
  public void test356() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1645.0f,-362.0f,0f,1112.0f,0f,0f,0f,0f,0f,834.0f,-867.0f,-1950.0f,693.0f,-714.0f,-834.0f,552,-0.79413f,0.20411465f,0.5436024f,0f,0f,0f ) ;
  }

  @Test
  public void test357() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-166.0f,1510.0f,-648.0f,219.0f,0f,0f,0f,0f,0f,-494.0f,-461.0f,384.0f,479.0f,-177.0f,392.0f,-309,-5.5463004f,73.00963f,80.5145f,-16.276125f,-2.6148183f,0f ) ;
  }

  @Test
  public void test358() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,16.698366f,0.4174261f,0f,0f,0f,0f,0f,0f,0f,-13.678195f,-12.748177f,2.2619107f,1130.0f,899.0f,848.0f,-171,19.223621f,-18.475449f,11.98571f,0f,0f,0f ) ;
  }

  @Test
  public void test359() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1680.0f,60.0f,0f,657.0f,0f,0f,0f,0f,0f,1012.0f,235.0f,-341.0f,482.0f,-227.0f,-352.0f,718,-17.381388f,-93.99756f,33.08053f,0f,0f,0f ) ;
  }

  @Test
  public void test360() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1683.0f,891.0f,0f,25.0f,0f,0f,0f,0f,0f,-1791.0f,118.0f,471.0f,-1148.0f,-1380.0f,-912.0f,830,0.057236046f,0.8683797f,-0.009621508f,0f,0f,0f ) ;
  }

  @Test
  public void test361() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-169.0f,618.0f,0f,108.0f,0f,0f,0f,0f,0f,928.0f,-964.0f,875.0f,-238.0f,-582.0f,592.0f,-159,80.04145f,-2.7784007f,-87.950676f,0f,0f,0f ) ;
  }

  @Test
  public void test362() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-171.0f,126.0f,0f,993.0f,0f,0f,0f,0f,0f,-307.0f,-89.0f,202.0f,5.0f,-633.0f,-266.0f,-439,-68.72124f,51.535103f,-81.74702f,0f,0f,0f ) ;
  }

  @Test
  public void test363() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,172.0f,-138.0f,0f,123.0f,0f,0f,0f,0f,0f,1226.0f,314.0f,-378.0f,138.0f,529.0f,781.0f,-641,-36.951836f,3.8435714f,-9.776391f,0f,0f,0f ) ;
  }

  @Test
  public void test364() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1732.0f,-1196.0f,0f,580.0f,0f,0f,0f,0f,0f,-143.0f,-251.0f,-157.0f,-556.0f,54.0f,420.0f,50,-0.6046727f,0.74450403f,0.21074487f,0f,0f,0f ) ;
  }

  @Test
  public void test365() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1774.0f,687.0f,0f,255.0f,0f,0f,0f,0f,0f,279.0f,69.0f,-749.0f,-189.0f,-1310.0f,-534.0f,-991,-79.20027f,100.0f,-20.289398f,0f,0f,0f ) ;
  }

  @Test
  public void test366() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1786.0f,1121.0f,0f,-437.0f,0f,0f,0f,0f,0f,-385.0f,474.0f,222.0f,-831.0f,-2540.0f,-184.0f,-1033,0.053285405f,-4.9696706E-4f,0.02784661f,0f,0f,0f ) ;
  }

  @Test
  public void test367() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1812.0f,2267.0f,0f,1.0f,0f,0f,0f,0f,0f,267.0f,543.0f,-1311.0f,-18.0f,-1075.0f,349.0f,-933,0.09333846f,-0.024937594f,0.046873726f,0f,0f,0f ) ;
  }

  @Test
  public void test368() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1822.0f,588.0f,0f,-44.0f,0f,0f,0f,0f,0f,-689.0f,-1464.0f,722.0f,-1590.0f,703.0f,909.0f,-879,-0.4995213f,0.0054264762f,-0.8662846f,0f,0f,0f ) ;
  }

  @Test
  public void test369() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,18.341f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-100.0f,-94.580605f,0f,0f,0f,-64,0.26983523f,0.96148473f,0.052307855f,0f,0f,0f ) ;
  }

  @Test
  public void test370() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1849.0f,965.0f,0f,744.0f,0f,0f,0f,0f,0f,749.0f,-779.0f,566.0f,-520.0f,-450.0f,142.0f,-1226,69.59758f,6.3780394f,-83.32269f,0f,0f,0f ) ;
  }

  @Test
  public void test371() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-185.0f,266.0f,0f,579.0f,0f,0f,0f,0f,0f,953.0f,880.0f,990.0f,627.0f,1324.0f,-513.0f,652,-23.596016f,-1.3881607f,23.948065f,0f,0f,0f ) ;
  }

  @Test
  public void test372() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-185.0f,-440.0f,0f,960.0f,0f,0f,0f,0f,0f,1373.0f,436.0f,-243.0f,602.0f,416.0f,176.0f,-543,-100.0f,50.50275f,-88.17191f,0f,0f,0f ) ;
  }

  @Test
  public void test373() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-186.0f,-993.0f,0f,912.0f,0f,0f,0f,0f,0f,806.0f,545.0f,912.0f,-896.0f,-551.0f,-458.0f,-228,-16.575714f,-95.87371f,-13.735345f,0f,0f,0f ) ;
  }

  @Test
  public void test374() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,18.921516f,-18.950022f,0f,36.723465f,0f,0f,0f,0f,0f,-16.674984f,-25.114357f,-24.61375f,0f,0f,0f,-636,-5.094194f,-12.834021f,17.983418f,0f,0f,0f ) ;
  }

  @Test
  public void test375() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1896.0f,1.0f,0f,2104.0f,0f,0f,0f,0f,0f,-380.0f,-184.0f,545.0f,459.0f,254.0f,1063.0f,-582,-0.068582386f,-0.015841773f,-0.87169045f,0f,0f,0f ) ;
  }

  @Test
  public void test376() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-190.0f,1444.0f,0f,1251.0f,0f,0f,0f,0f,0f,-680.0f,-1149.0f,231.0f,-26.0f,-1000.0f,-973.0f,-348,-0.072324045f,0.19461577f,-0.5533143f,0f,0f,0f ) ;
  }

  @Test
  public void test377() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,19.25244f,-9.050403f,0f,-4.2587605f,0f,0f,0f,0f,0f,39.862633f,41.96775f,38.100784f,0f,0f,0f,-287,-30.629572f,60.43354f,-97.131165f,0f,0f,0f ) ;
  }

  @Test
  public void test378() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-196.0f,402.0f,0f,7.0f,0f,0f,0f,0f,0f,590.0f,279.0f,414.0f,-392.0f,387.0f,298.0f,-521,-2.4355597f,-15.307999f,13.774231f,0f,0f,0f ) ;
  }

  @Test
  public void test379() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1964.0f,1149.0f,0f,2854.0f,0f,0f,0f,0f,0f,-523.0f,695.0f,853.0f,-1681.0f,431.0f,-1380.0f,5,67.67563f,62.19054f,-9.190996f,0f,0f,0f ) ;
  }

  @Test
  public void test380() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1975.0f,1119.0f,0f,1123.0f,0f,0f,0f,0f,0f,-1021.0f,-664.0f,-268.0f,-927.0f,1351.0f,74.0f,-516,0.34457412f,-1.2589377f,3.8383977f,0f,0f,0f ) ;
  }

  @Test
  public void test381() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,1986.0f,1549.0f,0f,379.0f,0f,0f,0f,0f,0f,122.0f,1010.0f,305.0f,716.0f,-47.0f,-129.0f,1308,-46.78365f,14.784809f,-30.256535f,0f,0f,0f ) ;
  }

  @Test
  public void test382() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1995.0f,1328.0f,0f,524.0f,0f,0f,0f,0f,0f,-146.0f,-651.0f,386.0f,972.0f,-68.0f,254.0f,-543,-100.0f,78.79635f,95.06083f,0f,0f,0f ) ;
  }

  @Test
  public void test383() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1996.0f,1171.0f,0f,1983.0f,0f,0f,0f,0f,0f,527.0f,805.0f,81.0f,401.0f,-195.0f,-674.0f,-517,0.8890527f,-0.49564856f,-0.8852181f,0f,0f,0f ) ;
  }

  @Test
  public void test384() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-200.0f,-805.0f,0f,2036.0f,0f,0f,0f,0f,0f,-552.0f,309.0f,669.0f,-545.0f,-945.0f,-13.0f,156,-0.38123044f,0.24087413f,-0.4486131f,0f,0f,0f ) ;
  }

  @Test
  public void test385() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,201.0f,828.0f,0f,891.0f,0f,0f,0f,0f,0f,483.0f,-510.0f,-900.0f,-917.0f,-404.0f,-646.0f,310,23.49028f,87.62165f,33.49174f,0f,0f,0f ) ;
  }

  @Test
  public void test386() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-203.0f,292.0f,0f,206.0f,0f,0f,0f,0f,0f,1116.0f,-869.0f,768.0f,222.0f,382.0f,110.0f,-699,-0.15180759f,0.8764088f,-0.26487565f,0f,0f,0f ) ;
  }

  @Test
  public void test387() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,20.62372f,100.0f,0f,0f,0f,0f,0f,0f,0f,36.500206f,65.78031f,54.810005f,703.0f,457.0f,822.0f,844,-0.858886f,0.06502644f,0.49391022f,0f,0f,0f ) ;
  }

  @Test
  public void test388() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0869f,-56.080044f,0f,57.14677f,0f,0f,0f,0f,0f,-6.668484f,62.636677f,-52.392197f,0f,0f,0f,-1291,-0.7122543f,-0.31825796f,0.38546443f,0f,0f,0f ) ;
  }

  @Test
  public void test389() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,0.0f,0f,2028.0f,0f,0f,0f,0f,0f,-855.0f,-942.0f,-586.0f,1658.0f,-539.0f,303.0f,2505,0.58230144f,-0.31738663f,-0.20541249f,0f,0f,0f ) ;
  }

  @Test
  public void test390() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,103.0f,0f,5.0f,0f,0f,0f,0f,0f,499.0f,-766.0f,1242.0f,-1800.0f,242.0f,338.0f,1525,10.032148f,188.64949f,-57.254745f,0f,0f,0f ) ;
  }

  @Test
  public void test391() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,1089.0f,0f,205.0f,0f,0f,0f,0f,0f,-3216.0f,-1911.0f,1604.0f,-76.0f,974.0f,226.0f,-149,0.23011181f,0.42469832f,0.79489654f,0f,0f,0f ) ;
  }

  @Test
  public void test392() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,-1589.0f,0f,653.0f,0f,0f,0f,0f,0f,-478.0f,357.0f,-87.0f,1234.0f,819.0f,-870.0f,-187,-0.26204452f,-0.5523722f,0.054713037f,0f,0f,0f ) ;
  }

  @Test
  public void test393() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,1989.0f,0f,1125.0f,0f,0f,0f,0f,0f,282.0f,136.0f,-387.0f,-592.0f,-258.0f,635.0f,-730,-30.136078f,100.0f,13.182497f,0f,0f,0f ) ;
  }

  @Test
  public void test394() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.0f,2609.0f,0f,1591.0f,0f,0f,0f,0f,0f,242.0f,696.0f,-469.0f,11.0f,-270.0f,-395.0f,-803,100.0f,16.200296f,75.79575f,0f,0f,0f ) ;
  }

  @Test
  public void test395() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2.0f,428.0f,0f,1033.0f,0f,0f,0f,0f,0f,184.0f,19.0f,-989.0f,745.0f,-16.0f,424.0f,-1201,67.97286f,43.66091f,13.484905f,0f,0f,0f ) ;
  }

  @Test
  public void test396() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-21.0f,-267.0f,0f,254.0f,0f,0f,0f,0f,0f,97.0f,204.0f,629.0f,-722.0f,394.0f,2078.0f,600,-0.24972732f,-0.93000484f,-0.13141796f,0f,0f,0f ) ;
  }

  @Test
  public void test397() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,21.580713f,-100.0f,0f,-100.0f,0f,0f,0f,0f,0f,38.987396f,-100.0f,78.43143f,0f,0f,0f,626,-0.01492178f,-0.18099439f,-0.63009804f,0f,0f,0f ) ;
  }

  @Test
  public void test398() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2175.0f,1329.0f,0f,0.0f,0f,0f,0f,0f,0f,-759.0f,-102.0f,-80.0f,591.0f,273.0f,-1534.0f,-341,0.6309853f,0.121821925f,-0.76617044f,0f,0f,0f ) ;
  }

  @Test
  public void test399() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-21.801786f,-31.275063f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,-100.0f,0f,0f,0f,2,-0.7146714f,0.56863856f,0.22707838f,0f,0f,0f ) ;
  }

  @Test
  public void test400() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,218.0f,901.0f,0f,2345.0f,0f,0f,0f,0f,0f,1309.0f,30.0f,636.0f,-228.0f,-1668.0f,-61.0f,644,-0.29079375f,0.5652402f,0.5021049f,0f,0f,0f ) ;
  }

  @Test
  public void test401() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-22.0f,67.0f,0f,250.0f,0f,0f,0f,0f,0f,186.0f,94.0f,23.0f,609.0f,-641.0f,-1350.0f,-90,-28.016354f,55.004093f,1.767695f,0f,0f,0f ) ;
  }

  @Test
  public void test402() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,221.0f,70.0f,0f,393.0f,0f,0f,0f,0f,0f,756.0f,446.0f,-121.0f,-128.0f,548.0f,-605.0f,-991,-42.10403f,-20.023981f,32.05949f,0f,0f,0f ) ;
  }

  @Test
  public void test403() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-223.0f,-212.0f,0f,254.0f,0f,0f,0f,0f,0f,1130.0f,1428.0f,494.0f,1585.0f,-1090.0f,689.0f,8,-0.19712855f,-0.37492776f,-0.03158941f,0f,0f,0f ) ;
  }

  @Test
  public void test404() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2233.0f,1377.0f,0f,-1.0f,0f,0f,0f,0f,0f,-1494.0f,1419.0f,583.0f,-880.0f,-1108.0f,864.0f,-174,0.108585306f,-0.06101005f,0.38740984f,0f,0f,0f ) ;
  }

  @Test
  public void test405() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-227.0f,-887.0f,0f,148.0f,0f,0f,0f,0f,0f,575.0f,-98.0f,-84.0f,699.0f,-958.0f,-832.0f,-1890,-0.4974076f,0.1533047f,-0.75371104f,0f,0f,0f ) ;
  }

  @Test
  public void test406() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-22.778955f,0.0f,0f,-46.188858f,0f,0f,0f,0f,0f,-18.295702f,-38.290985f,-58.337753f,0f,0f,0f,363,-13.854928f,-43.040394f,73.911354f,0f,0f,0f ) ;
  }

  @Test
  public void test407() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2297.0f,523.0f,0f,66.0f,0f,0f,0f,0f,0f,-440.0f,-59.0f,842.0f,1300.0f,1041.0f,106.0f,2139,0.5536464f,-0.70578164f,0.23986137f,0f,0f,0f ) ;
  }

  @Test
  public void test408() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-233.0f,344.0f,0f,1.0f,0f,0f,0f,0f,0f,-616.0f,-2037.0f,-1249.0f,-160.0f,-1176.0f,393.0f,-1112,-0.6419935f,0.33416533f,0.6900564f,0f,0f,0f ) ;
  }

  @Test
  public void test409() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2383.0f,975.0f,0f,904.0f,0f,0f,0f,0f,0f,-582.0f,1205.0f,-845.0f,1012.0f,787.0f,-408.0f,1827,3.3718667f,3.3323112f,2.628807f,0f,0f,0f ) ;
  }

  @Test
  public void test410() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-24.0f,-990.0f,0f,356.0f,0f,0f,0f,0f,0f,683.0f,307.0f,-737.0f,-480.0f,2090.0f,-1152.0f,550,-0.48309112f,0.25462475f,-0.10009224f,0f,0f,0f ) ;
  }

  @Test
  public void test411() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,246.0f,5.0f,0f,358.0f,0f,0f,0f,0f,0f,306.0f,122.0f,-360.0f,238.0f,265.0f,292.0f,664,-0.28427044f,0.3336829f,2.511796f,0f,0f,0f ) ;
  }

  @Test
  public void test412() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,2496.0f,-4.0f,0f,2634.0f,0f,0f,0f,0f,0f,368.0f,-469.0f,-226.0f,598.0f,812.0f,-723.0f,-1065,0.09523785f,0.52387875f,0.07905686f,0f,0f,0f ) ;
  }

  @Test
  public void test413() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.5554776f,0.0f,0f,100.0f,0f,0f,0f,0f,0f,-100.0f,100.0f,-20.97655f,0f,0f,0f,308,100.0f,61.71451f,-98.664894f,0f,0f,0f ) ;
  }

  @Test
  public void test414() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2561.0f,-3.0f,0f,1087.0f,0f,0f,0f,0f,0f,-373.0f,-1441.0f,-1042.0f,-840.0f,456.0f,-328.0f,-199,-7.5124764f,0.27472734f,2.3092818f,0f,0f,0f ) ;
  }

  @Test
  public void test415() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,25.937387f,57.301643f,0f,0f,0f,0f,0f,0f,0f,87.29147f,-54.47008f,-95.18952f,767.0f,164.0f,171.0f,-411,-62.762627f,-13.262906f,58.54656f,0f,0f,0f ) ;
  }

  @Test
  public void test416() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-26.0f,1258.0f,0f,119.0f,0f,0f,0f,0f,0f,-906.0f,-953.0f,-5.0f,-79.0f,-1152.0f,698.0f,-1246,-21.501429f,20.875343f,-82.77485f,0f,0f,0f ) ;
  }

  @Test
  public void test417() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2648.0f,-1657.0f,0f,279.0f,0f,0f,0f,0f,0f,-289.0f,13.0f,-659.0f,272.0f,571.0f,-921.0f,875,-0.23238407f,1.051222f,0.14658326f,0f,0f,0f ) ;
  }

  @Test
  public void test418() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,26.48437f,-43.010635f,0f,6.4697013f,0f,0f,0f,0f,0f,-11.380471f,-84.12128f,49.56875f,0f,0f,0f,-568,0.0032387967f,-0.46760777f,-0.79301757f,0f,0f,0f ) ;
  }

  @Test
  public void test419() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,266.0f,672.0f,0f,802.0f,0f,0f,0f,0f,0f,708.0f,-718.0f,-1110.0f,-562.0f,563.0f,-50.0f,523,-0.25914368f,-0.011037205f,0.16105975f,0f,0f,0f ) ;
  }

  @Test
  public void test420() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,26.765041f,0f,0f,0f,0f,0f,0f,0f,0f,-62.03877f,-96.350235f,-100.0f,0f,0f,0f,1,0.22888237f,0.31321812f,0.7542831f,0f,0f,0f ) ;
  }

  @Test
  public void test421() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2704.0f,-456.0f,0f,29.0f,0f,0f,0f,0f,0f,-893.0f,-343.0f,814.0f,130.0f,-1740.0f,-167.0f,1535,-0.29935443f,-0.0089752395f,-0.35379535f,0f,0f,0f ) ;
  }

  @Test
  public void test422() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,271.0f,-280.0f,0f,129.0f,0f,0f,0f,0f,0f,-925.0f,405.0f,724.0f,-338.0f,605.0f,-770.0f,-927,193.0656f,-51.296173f,-39.45086f,0f,0f,0f ) ;
  }

  @Test
  public void test423() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,272.0f,-145.0f,0f,566.0f,0f,0f,0f,0f,0f,-656.0f,854.0f,1889.0f,-314.0f,741.0f,-444.0f,-1027,44.26044f,10.008621f,-8.884804f,0f,0f,0f ) ;
  }

  @Test
  public void test424() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,276.0f,358.0f,122.0f,732.0f,0f,0f,0f,0f,0f,47.0f,479.0f,-82.0f,807.0f,-143.0f,974.0f,-512,-0.60089105f,6.6502447f,25.902344f,37.028065f,0f,0f ) ;
  }

  @Test
  public void test425() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-27.735792f,0f,0f,0f,0f,0f,0f,0f,0f,46.754223f,85.17389f,-47.566475f,0f,0f,0f,-7,-0.5598573f,-5.6290417E-4f,0.72542393f,0f,0f,0f ) ;
  }

  @Test
  public void test426() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,278.0f,-3267.0f,0f,274.0f,0f,0f,0f,0f,0f,483.0f,-727.0f,175.0f,-291.0f,203.0f,1668.0f,18,-0.683158f,-0.41331664f,0.16839135f,0f,0f,0f ) ;
  }

  @Test
  public void test427() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-279.0f,-133.0f,0f,549.0f,0f,0f,0f,0f,0f,-470.0f,348.0f,337.0f,105.0f,-20.0f,168.0f,37,0.99309045f,0.20121145f,0.5332986f,0f,0f,0f ) ;
  }

  @Test
  public void test428() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.8340359f,-8.241536f,0f,0.0f,0f,0f,0f,0f,0f,2.4144416f,-26.707306f,67.83336f,0f,0f,0f,696,18.11073f,72.91797f,-13.328826f,0f,0f,0f ) ;
  }

  @Test
  public void test429() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-292.0f,624.0f,0f,1258.0f,0f,0f,0f,0f,0f,671.0f,876.0f,-210.0f,-425.0f,748.0f,-447.0f,100,99.25482f,-100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test430() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2.924649f,75.47405f,0f,0f,0f,0f,0f,0f,0f,68.442955f,-53.586697f,-16.627066f,447.0f,-344.0f,888.0f,-400,-49.98757f,45.044937f,-77.99458f,0f,0f,0f ) ;
  }

  @Test
  public void test431() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,30.08606f,0.0f,0f,0f,0f,0f,0f,0f,0f,-11.21537f,73.67182f,2.3493931f,0f,0f,0f,231,11.024568f,-19.964622f,70.67774f,0f,0f,0f ) ;
  }

  @Test
  public void test432() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,30.092176f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-44.52284f,-13.504346f,10.601668f,0f,0f,0f,-129,0.70068914f,-0.30754143f,0.35832766f,0f,0f,0f ) ;
  }

  @Test
  public void test433() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-30.275705f,100.0f,0f,0f,0f,0f,0f,0f,0f,100.0f,19.923664f,100.0f,0f,0f,0f,620,-0.14647715f,6.116516E-5f,-0.051907968f,0f,0f,0f ) ;
  }

  @Test
  public void test434() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,304.0f,-268.0f,658.0f,172.0f,0f,0f,0f,0f,0f,-314.0f,-99.0f,63.0f,403.0f,359.0f,396.0f,113,-1.1425438f,-86.80361f,57.870907f,0f,-24.144955f,0f ) ;
  }

  @Test
  public void test435() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,3.0f,-1100.0f,0f,822.0f,0f,0f,0f,0f,0f,-746.0f,87.0f,611.0f,348.0f,520.0f,-204.0f,-893,-0.1694126f,-0.7523396f,-0.5834561f,0f,0f,0f ) ;
  }

  @Test
  public void test436() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-311.0f,123.0f,0f,807.0f,0f,0f,0f,0f,0f,-583.0f,598.0f,831.0f,1960.0f,637.0f,600.0f,612,0.028833184f,-0.30894896f,0.019116089f,0f,0f,0f ) ;
  }

  @Test
  public void test437() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,314.0f,-12.0f,268.0f,876.0f,0f,0f,0f,0f,0f,41.0f,982.0f,896.0f,-975.0f,324.0f,852.0f,-77,0.72791106f,-27.339544f,40.354412f,-46.415924f,0f,0f ) ;
  }

  @Test
  public void test438() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-319.0f,39.0f,0f,233.0f,0f,0f,0f,0f,0f,614.0f,459.0f,11.0f,1430.0f,471.0f,178.0f,42,-16.942423f,23.144634f,-20.067228f,0f,0f,0f ) ;
  }

  @Test
  public void test439() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-32.028507f,21.055613f,0f,0f,0f,0f,0f,0f,0f,-99.52947f,72.95553f,34.10405f,912.0f,-173.0f,-410.0f,841,-2.8443596f,-1.1442869f,-5.853134f,0f,0f,0f ) ;
  }

  @Test
  public void test440() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-324.0f,-1076.0f,0f,1700.0f,0f,0f,0f,0f,0f,-1218.0f,1818.0f,-1478.0f,-291.0f,-404.0f,-1064.0f,-735,-0.023983141f,0.2776995f,0.8100335f,0f,0f,0f ) ;
  }

  @Test
  public void test441() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-325.0f,1510.0f,0f,261.0f,0f,0f,0f,0f,0f,511.0f,1227.0f,273.0f,-851.0f,1254.0f,-1260.0f,-89,82.27246f,-29.414434f,-21.793842f,0f,0f,0f ) ;
  }

  @Test
  public void test442() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-33.292957f,0.0f,0f,-38.58514f,0f,0f,0f,0f,0f,-77.15199f,-93.55072f,78.79696f,0f,0f,0f,-925,0.2248109f,0.08949642f,-0.7011555f,0f,0f,0f ) ;
  }

  @Test
  public void test443() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-346.0f,0.0f,0f,1254.0f,0f,0f,0f,0f,0f,-588.0f,-481.0f,-286.0f,959.0f,240.0f,-354.0f,300,28.343887f,33.853214f,39.982872f,0f,0f,0f ) ;
  }

  @Test
  public void test444() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,3479.0f,823.0f,0f,1334.0f,0f,0f,0f,0f,0f,-876.0f,129.0f,68.0f,-268.0f,-99.0f,2087.0f,-1506,-0.065324955f,0.11300404f,-1.0559516f,0f,0f,0f ) ;
  }

  @Test
  public void test445() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-349.0f,-835.0f,0f,254.0f,0f,0f,0f,0f,0f,-1334.0f,657.0f,111.0f,-227.0f,688.0f,-193.0f,-564,71.98339f,-22.433186f,-94.18309f,0f,0f,0f ) ;
  }

  @Test
  public void test446() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-350.0f,-643.0f,0f,284.0f,0f,0f,0f,0f,0f,-551.0f,615.0f,-725.0f,-605.0f,574.0f,524.0f,551,50.097675f,12.898f,21.67832f,0f,0f,0f ) ;
  }

  @Test
  public void test447() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-35.0f,501.0f,-27.0f,-560.0f,0f,0f,0f,0f,0f,856.0f,364.0f,29.0f,554.0f,-304.0f,-724.0f,-38,-63.025772f,-12.162497f,26.50184f,33.58741f,0f,0f ) ;
  }

  @Test
  public void test448() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-35.0f,894.0f,0f,45.0f,0f,0f,0f,0f,0f,-717.0f,-793.0f,793.0f,294.0f,-451.0f,807.0f,-908,0.15983085f,0.26475382f,-0.7354167f,0f,0f,0f ) ;
  }

  @Test
  public void test449() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-35.381817f,-4.1452384f,0f,0.0f,0f,0f,0f,0f,0f,-97.913704f,1.2712873f,76.75984f,0f,0f,0f,753,0.54144406f,0.28524148f,-0.0846869f,0f,0f,0f ) ;
  }

  @Test
  public void test450() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-35.493546f,66.15402f,0f,0f,0f,0f,0f,0f,0f,57.445564f,-91.22592f,-100.0f,-864.0f,1053.0f,177.0f,-437,-0.29795128f,0.75879943f,-0.5791791f,0f,0f,0f ) ;
  }

  @Test
  public void test451() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-357.0f,81.0f,0f,-3.0f,0f,0f,0f,0f,0f,-887.0f,-209.0f,150.0f,768.0f,548.0f,-15.0f,1370,0.7085739f,0.31396878f,-0.021062758f,0f,0f,0f ) ;
  }

  @Test
  public void test452() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-35.77824f,0.0f,0f,0f,0f,0f,0f,0f,0f,-18.862434f,-4.9153657f,6.19751f,0f,0f,0f,48,0.28665f,0.010195249f,0.44983938f,0f,0f,0f ) ;
  }

  @Test
  public void test453() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,359.0f,1549.0f,0f,3690.0f,0f,0f,0f,0f,0f,363.0f,-253.0f,779.0f,-599.0f,9.0f,282.0f,-11,-10.402235f,56.082035f,3.4176307f,0f,0f,0f ) ;
  }

  @Test
  public void test454() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3706.0f,2791.0f,0f,297.0f,0f,0f,0f,0f,0f,74.0f,73.0f,861.0f,-851.0f,240.0f,53.0f,-943,9.966378f,3.2201192f,-6.366523f,0f,0f,0f ) ;
  }

  @Test
  public void test455() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,378.0f,-118.0f,0f,1138.0f,0f,0f,0f,0f,0f,939.0f,441.0f,-1063.0f,-2395.0f,399.0f,831.0f,810,0.46130642f,-0.043513514f,0.8861732f,0f,0f,0f ) ;
  }

  @Test
  public void test456() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-37.88569f,99.999664f,0f,0f,0f,0f,0f,0f,0f,7.349394f,-46.32647f,76.39615f,738.0f,380.0f,576.0f,834,-0.4551548f,0.84186107f,0.29000688f,0f,0f,0f ) ;
  }

  @Test
  public void test457() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-379.0f,588.0f,-1164.0f,63.0f,0f,0f,0f,0f,0f,805.0f,-38.0f,647.0f,825.0f,422.0f,-37.0f,-270,-0.1775505f,-0.93941873f,0.06924975f,0f,23.594767f,0f ) ;
  }

  @Test
  public void test458() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-38.0f,310.0f,-848.0f,-563.0f,0f,0f,0f,0f,0f,-576.0f,-540.0f,-621.0f,-656.0f,-525.0f,-83.0f,-254,-62.548214f,38.54275f,76.00871f,-15.05244f,34.75141f,0f ) ;
  }

  @Test
  public void test459() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-383.0f,0.0f,0f,968.0f,0f,0f,0f,0f,0f,-489.0f,999.0f,-306.0f,253.0f,-912.0f,964.0f,-326,-0.002129428f,-0.23397185f,0.2734902f,0f,0f,0f ) ;
  }

  @Test
  public void test460() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-38.60478f,0f,0f,0f,0f,0f,0f,0f,0f,-19.738514f,44.140438f,-76.48091f,0f,0f,0f,-979,-2.1596038f,30.962225f,74.68334f,0f,0f,0f ) ;
  }

  @Test
  public void test461() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-388.0f,-855.0f,127.0f,505.0f,0f,0f,0f,0f,0f,998.0f,-959.0f,29.0f,32.0f,-841.0f,-320.0f,718,16.682938f,77.141174f,-1.6875328f,-8.574667f,0f,0f ) ;
  }

  @Test
  public void test462() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-388.0f,-857.0f,0f,551.0f,0f,0f,0f,0f,0f,687.0f,-244.0f,535.0f,531.0f,-976.0f,893.0f,347,-100.0f,100.0f,-54.848778f,0f,0f,0f ) ;
  }

  @Test
  public void test463() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,39.16579f,82.576195f,0f,0f,0f,0f,0f,0f,0f,34.77539f,-1.8430957f,-55.76166f,-74.0f,-967.0f,393.0f,268,-99.178375f,83.25445f,24.231873f,0f,0f,0f ) ;
  }

  @Test
  public void test464() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-392.0f,-1123.0f,0f,45.0f,0f,0f,0f,0f,0f,-499.0f,-637.0f,-128.0f,-339.0f,174.0f,455.0f,519,64.496605f,33.236332f,-0.012540389f,0f,0f,0f ) ;
  }

  @Test
  public void test465() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-393.0f,340.0f,0f,286.0f,0f,0f,0f,0f,0f,255.0f,94.0f,199.0f,826.0f,719.0f,-61.0f,984,-99.76777f,-83.78587f,-95.09227f,0f,0f,0f ) ;
  }

  @Test
  public void test466() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-401.0f,202.0f,0f,339.0f,0f,0f,0f,0f,0f,-373.0f,519.0f,-916.0f,-1651.0f,-800.0f,218.0f,527,-12.562342f,157.98425f,94.81593f,0f,0f,0f ) ;
  }

  @Test
  public void test467() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-40.355007f,-37.178547f,0f,72.336f,0f,0f,0f,0f,0f,88.8846f,-73.54559f,-84.61988f,0f,0f,0f,-864,-57.765926f,96.34782f,22.788612f,0f,0f,0f ) ;
  }

  @Test
  public void test468() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,4.06569f,-79.53474f,0f,0f,0f,0f,0f,0f,0f,35.62417f,-9.41087f,-6.7007246f,0f,0f,0f,-612,-0.010508747f,0.08511087f,-0.0010324566f,0f,0f,0f ) ;
  }

  @Test
  public void test469() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-4.0f,1.0f,0f,238.0f,0f,0f,0f,0f,0f,309.0f,339.0f,-289.0f,-510.0f,-254.0f,-844.0f,1773,-3.1740804f,-30.274832f,22.666565f,0f,0f,0f ) ;
  }

  @Test
  public void test470() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-4.0f,911.0f,-606.0f,-222.0f,0f,0f,0f,0f,0f,-329.0f,1371.0f,-379.0f,-1324.0f,-265.0f,137.0f,-960,-23.544716f,-38.355537f,155.37086f,57.38919f,0f,0f ) ;
  }

  @Test
  public void test471() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,410.0f,815.0f,0f,-1089.0f,0f,0f,0f,0f,0f,1480.0f,-789.0f,295.0f,876.0f,1428.0f,-305.0f,255,0.39591286f,0.8364793f,-0.14779195f,0f,0f,0f ) ;
  }

  @Test
  public void test472() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-411.0f,2468.0f,0f,950.0f,0f,0f,0f,0f,0f,210.0f,-779.0f,471.0f,302.0f,-66.0f,-245.0f,729,0.41767594f,0.28722385f,0.28875363f,0f,0f,0f ) ;
  }

  @Test
  public void test473() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-411.0f,-758.0f,0f,255.0f,0f,0f,0f,0f,0f,-550.0f,-261.0f,982.0f,376.0f,-767.0f,467.0f,89,-68.175575f,72.97081f,-66.809105f,0f,0f,0f ) ;
  }

  @Test
  public void test474() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-412.0f,-881.0f,0f,136.0f,0f,0f,0f,0f,0f,379.0f,459.0f,-737.0f,804.0f,821.0f,798.0f,409,-24.398441f,-58.218735f,41.72369f,0f,0f,0f ) ;
  }

  @Test
  public void test475() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,41.373474f,71.30119f,0f,0f,0f,0f,0f,0f,0f,63.30644f,-20.099396f,35.05245f,982.0f,-444.0f,-332.0f,-1751,0.09926218f,1.0149367f,0.40258488f,0f,0f,0f ) ;
  }

  @Test
  public void test476() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,418.0f,-530.0f,782.0f,155.0f,0f,0f,0f,0f,0f,576.0f,754.0f,-872.0f,565.0f,-617.0f,-804.0f,-502,-0.2362195f,-36.75976f,-8.581397f,-37.090874f,-51.78241f,0f ) ;
  }

  @Test
  public void test477() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-422.0f,-40.0f,0f,478.0f,0f,0f,0f,0f,0f,1422.0f,3.0f,910.0f,-559.0f,463.0f,872.0f,-85,15.283587f,99.92167f,-102.801506f,0f,0f,0f ) ;
  }

  @Test
  public void test478() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,425.0f,761.0f,0f,950.0f,0f,0f,0f,0f,0f,-302.0f,-552.0f,690.0f,-204.0f,428.0f,-619.0f,878,12.957228f,64.56956f,49.65309f,0f,0f,0f ) ;
  }

  @Test
  public void test479() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,426.0f,-727.0f,0f,730.0f,0f,0f,0f,0f,0f,422.0f,-1780.0f,-1221.0f,-97.0f,128.0f,-2022.0f,-1118,0.19089514f,0.64292496f,-0.45718437f,0f,0f,0f ) ;
  }

  @Test
  public void test480() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-42.989403f,-31.981638f,0f,38.591213f,0f,0f,0f,0f,0f,75.45895f,58.964592f,61.997646f,0f,0f,0f,206,-0.8239301f,-0.5376192f,0.17917806f,0f,0f,0f ) ;
  }

  @Test
  public void test481() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,4318.0f,449.0f,0f,-7.0f,0f,0f,0f,0f,0f,-164.0f,1977.0f,-1198.0f,243.0f,-2398.0f,322.0f,1394,-0.5323925f,-0.78864837f,-0.30755815f,0f,0f,0f ) ;
  }

  @Test
  public void test482() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,43.28522f,0.0f,0f,98.242805f,0f,0f,0f,0f,0f,22.428856f,-17.89788f,-13.389792f,0f,0f,0f,-1087,-0.6198848f,0.17199342f,-0.44763097f,0f,0f,0f ) ;
  }

  @Test
  public void test483() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,44.05831f,98.61655f,0f,0f,0f,0f,0f,0f,0f,100.0f,-99.11526f,75.36489f,-613.0f,525.0f,740.0f,-2001,-0.7398845f,-0.19873287f,0.64271003f,0f,0f,0f ) ;
  }

  @Test
  public void test484() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,441.0f,-308.0f,982.0f,515.0f,0f,0f,0f,0f,0f,82.0f,129.0f,-506.0f,977.0f,637.0f,-814.0f,-497,68.0567f,15.702235f,-19.384964f,90.80114f,0f,0f ) ;
  }

  @Test
  public void test485() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,444.0f,888.0f,0f,472.0f,0f,0f,0f,0f,0f,-381.0f,427.0f,-125.0f,91.0f,-295.0f,-1789.0f,1444,-43.61301f,-30.7385f,27.932589f,0f,0f,0f ) ;
  }

  @Test
  public void test486() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,449.0f,893.0f,890.0f,-785.0f,0f,0f,0f,0f,0f,503.0f,898.0f,303.0f,127.0f,-937.0f,641.0f,-451,-57.101124f,5.0021086f,95.42603f,-29.527246f,0f,0f ) ;
  }

  @Test
  public void test487() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,450.0f,1.0f,0f,875.0f,0f,0f,0f,0f,0f,256.0f,-691.0f,204.0f,1315.0f,-715.0f,-286.0f,738,-6.111311f,78.476944f,-40.840984f,0f,0f,0f ) ;
  }

  @Test
  public void test488() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-453.0f,-1179.0f,0f,556.0f,0f,0f,0f,0f,0f,-180.0f,474.0f,-437.0f,1230.0f,-953.0f,-250.0f,-1213,-0.023633054f,0.6298062f,0.77639264f,0f,0f,0f ) ;
  }

  @Test
  public void test489() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,456.0f,1.0f,0f,648.0f,0f,0f,0f,0f,0f,-468.0f,-561.0f,203.0f,404.0f,662.0f,483.0f,-432,-60.368862f,24.844076f,-77.51237f,0f,0f,0f ) ;
  }

  @Test
  public void test490() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,4.5715504f,-100.0f,0f,0.0f,0f,0f,0f,0f,0f,-33.21178f,16.097237f,-4.2137876f,0f,0f,0f,1756,0.7033012f,-0.23315398f,0.045597147f,0f,0f,0f ) ;
  }

  @Test
  public void test491() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,45.891518f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-67.3007f,32.44581f,-55.611523f,0f,0f,0f,-276,59.962097f,-50.73501f,26.697968f,0f,0f,0f ) ;
  }

  @Test
  public void test492() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,45.981674f,83.37661f,0f,0f,0f,0f,0f,0f,0f,-100.0f,57.858704f,-63.571182f,320.0f,565.0f,520.0f,240,-0.3627195f,-0.5243256f,0.6918034f,0f,0f,0f ) ;
  }

  @Test
  public void test493() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-464.0f,-1082.0f,0f,254.0f,0f,0f,0f,0f,0f,-98.0f,991.0f,-186.0f,-1290.0f,1709.0f,1166.0f,1761,0.18238463f,-0.98939216f,0.21028645f,0f,0f,0f ) ;
  }

  @Test
  public void test494() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-47.0f,553.0f,-281.0f,1570.0f,0f,0f,0f,0f,0f,-548.0f,463.0f,-723.0f,-622.0f,-37.0f,-1767.0f,2853,0.7666913f,0.1264311f,-0.2058668f,11.348841f,0f,0f ) ;
  }

  @Test
  public void test495() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-47.56748f,0.0f,0f,32.538082f,0f,0f,0f,0f,0f,100.0f,-100.0f,-100.0f,0f,0f,0f,888,-0.03169878f,-0.22265264f,0.97438234f,0f,0f,0f ) ;
  }

  @Test
  public void test496() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-488.0f,-121.0f,0f,711.0f,0f,0f,0f,0f,0f,819.0f,-506.0f,-631.0f,691.0f,-891.0f,457.0f,-594,24.44566f,45.9869f,46.79615f,0f,0f,0f ) ;
  }

  @Test
  public void test497() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,488.0f,373.0f,0f,231.0f,0f,0f,0f,0f,0f,360.0f,448.0f,-86.0f,-1314.0f,195.0f,-348.0f,176,-21.062672f,31.346973f,75.12654f,0f,0f,0f ) ;
  }

  @Test
  public void test498() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,5.0f,13.0f,0f,1544.0f,0f,0f,0f,0f,0f,358.0f,793.0f,699.0f,734.0f,-124.0f,-235.0f,-212,-2.3593643f,-0.69278944f,-0.7305407f,0f,0f,0f ) ;
  }

  @Test
  public void test499() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-5.0f,211.0f,0f,-718.0f,0f,0f,0f,0f,0f,-790.0f,623.0f,498.0f,273.0f,-600.0f,300.0f,-127,94.06989f,14.794245f,-51.82559f,0f,0f,0f ) ;
  }

  @Test
  public void test500() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,5.0f,-3.0f,0f,726.0f,0f,0f,0f,0f,0f,1409.0f,-528.0f,2530.0f,2292.0f,-488.0f,2037.0f,294,-0.8017221f,0.12166162f,-0.08361687f,0f,0f,0f ) ;
  }

  @Test
  public void test501() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-52.05257f,0.0f,0f,0f,0f,0f,0f,0f,0f,-1.6549149f,-47.052567f,43.50741f,0f,0f,0f,715,-58.511677f,45.28129f,15.039557f,0f,0f,0f ) ;
  }

  @Test
  public void test502() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-524.0f,607.0f,0f,45.0f,0f,0f,0f,0f,0f,224.0f,-545.0f,-96.0f,-195.0f,-139.0f,-193.0f,-683,97.83187f,51.49044f,-64.041145f,0f,0f,0f ) ;
  }

  @Test
  public void test503() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-527.0f,808.0f,0f,482.0f,0f,0f,0f,0f,0f,-1302.0f,-786.0f,2068.0f,1559.0f,-51.0f,-572.0f,-1049,-0.32106602f,-0.4534017f,-0.83147067f,0f,0f,0f ) ;
  }

  @Test
  public void test504() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-528.0f,-656.0f,0f,818.0f,0f,0f,0f,0f,0f,-596.0f,-240.0f,377.0f,748.0f,635.0f,1588.0f,1390,87.35114f,2.4329612f,-44.591602f,0f,0f,0f ) ;
  }

  @Test
  public void test505() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-536.0f,-322.0f,0f,208.0f,0f,0f,0f,0f,0f,228.0f,6.0f,-367.0f,598.0f,-764.0f,359.0f,346,-31.960468f,-11.921661f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test506() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-542.0f,442.0f,802.0f,322.0f,0f,0f,0f,0f,0f,252.0f,-671.0f,-886.0f,509.0f,699.0f,-359.0f,-500,-56.961903f,-90.99509f,49.032707f,-3.6774766f,-74.50671f,0f ) ;
  }

  @Test
  public void test507() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-544.0f,660.0f,0f,-1708.0f,0f,0f,0f,0f,0f,668.0f,63.0f,671.0f,883.0f,430.0f,846.0f,1730,-0.5769452f,-0.05283801f,0.5684446f,0f,0f,0f ) ;
  }

  @Test
  public void test508() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,55.30117f,0.0f,0f,0f,0f,0f,0f,0f,0f,-50.153873f,-89.44427f,56.757816f,0f,0f,0f,4,-0.0336996f,0.0219112f,-0.26162696f,0f,0f,0f ) ;
  }

  @Test
  public void test509() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-559.0f,348.0f,0f,1199.0f,0f,0f,0f,0f,0f,407.0f,893.0f,-199.0f,403.0f,749.0f,272.0f,803,8.174261f,-86.00246f,25.147093f,0f,0f,0f ) ;
  }

  @Test
  public void test510() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,55.96538f,34.33854f,0f,0f,0f,0f,0f,0f,0f,-19.204334f,-23.356798f,33.175797f,0f,0f,0f,890,11.46043f,80.13219f,5.604124f,0f,0f,0f ) ;
  }

  @Test
  public void test511() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,55.98843f,0.0f,0f,0f,0f,0f,0f,0f,0f,93.59518f,100.0f,-4.6902256f,0f,0f,0f,-673,-0.48268095f,0.43741727f,-0.10850861f,0f,0f,0f ) ;
  }

  @Test
  public void test512() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,56.457355f,0.0f,0f,0f,0f,0f,0f,0f,0f,88.697365f,-46.730053f,-100.0f,0f,0f,0f,-1699,0.024570046f,0.92424923f,0.38099337f,0f,0f,0f ) ;
  }

  @Test
  public void test513() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,567.0f,439.0f,0f,715.0f,0f,0f,0f,0f,0f,-556.0f,-779.0f,481.0f,440.0f,-758.0f,-249.0f,-838,24.394087f,-47.730988f,-50.06663f,0f,0f,0f ) ;
  }

  @Test
  public void test514() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,585.0f,940.0f,0f,-409.0f,0f,0f,0f,0f,0f,798.0f,660.0f,434.0f,497.0f,-396.0f,-152.0f,590,44.513176f,-87.63274f,43.73419f,0f,0f,0f ) ;
  }

  @Test
  public void test515() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-589.0f,-953.0f,0f,598.0f,0f,0f,0f,0f,0f,318.0f,-1009.0f,833.0f,-946.0f,-1234.0f,439.0f,-621,0.4119821f,0.137567f,-0.066072f,0f,0f,0f ) ;
  }

  @Test
  public void test516() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-591.0f,323.0f,0f,654.0f,0f,0f,0f,0f,0f,324.0f,36.0f,-42.0f,112.0f,-667.0f,292.0f,-379,-93.61372f,29.661547f,-12.799142f,0f,0f,0f ) ;
  }

  @Test
  public void test517() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-591.0f,-6.0f,0f,2011.0f,0f,0f,0f,0f,0f,-221.0f,1307.0f,-1545.0f,1937.0f,1584.0f,53.0f,353,-0.020950615f,-0.9705795f,-0.23986758f,0f,0f,0f ) ;
  }

  @Test
  public void test518() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,591.0f,-787.0f,0f,114.0f,0f,0f,0f,0f,0f,88.0f,266.0f,172.0f,-1198.0f,467.0f,-109.0f,-882,4.2275596f,-31.57109f,-27.568594f,0f,0f,0f ) ;
  }

  @Test
  public void test519() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-598.0f,-2462.0f,0f,1194.0f,0f,0f,0f,0f,0f,-994.0f,-1712.0f,239.0f,-922.0f,-1906.0f,1002.0f,-188,0.9290311f,-0.33040947f,-0.17120385f,0f,0f,0f ) ;
  }

  @Test
  public void test520() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-602.0f,-1316.0f,0f,524.0f,0f,0f,0f,0f,0f,-1071.0f,882.0f,-521.0f,844.0f,688.0f,-573.0f,-1873,-2.1072268f,-0.1754987f,4.179026f,0f,0f,0f ) ;
  }

  @Test
  public void test521() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,603.0f,428.0f,0f,940.0f,0f,0f,0f,0f,0f,482.0f,861.0f,674.0f,250.0f,415.0f,-709.0f,600,-72.32976f,-73.58152f,96.569984f,0f,0f,0f ) ;
  }

  @Test
  public void test522() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,603.0f,649.0f,0f,855.0f,0f,0f,0f,0f,0f,691.0f,911.0f,-550.0f,507.0f,-824.0f,-731.0f,1060,40.24895f,-13.746323f,75.71607f,0f,0f,0f ) ;
  }

  @Test
  public void test523() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,604.0f,-102.0f,0f,1589.0f,0f,0f,0f,0f,0f,496.0f,53.0f,1673.0f,411.0f,228.0f,123.0f,1076,-0.22406141f,-0.6220169f,-0.14587434f,0f,0f,0f ) ;
  }

  @Test
  public void test524() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-605.0f,728.0f,-69.0f,-772.0f,0f,0f,0f,0f,0f,95.0f,535.0f,-41.0f,313.0f,-103.0f,-877.0f,-197,-2.9822462f,-79.158394f,58.31061f,29.158031f,-23.101736f,0f ) ;
  }

  @Test
  public void test525() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,6.0f,0.0f,0f,179.0f,0f,0f,0f,0f,0f,-142.0f,-1352.0f,743.0f,-639.0f,-153.0f,-398.0f,-747,0.31075075f,0.11643349f,-0.42271087f,0f,0f,0f ) ;
  }

  @Test
  public void test526() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-616.0f,761.0f,-561.0f,604.0f,0f,0f,0f,0f,0f,247.0f,205.0f,-19.0f,626.0f,-682.0f,674.0f,-995,-53.593143f,-0.192795f,47.127388f,96.31635f,0f,0f ) ;
  }

  @Test
  public void test527() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-621.0f,1362.0f,0f,253.0f,0f,0f,0f,0f,0f,-343.0f,-89.0f,142.0f,-542.0f,-132.0f,446.0f,-892,-55.132812f,100.0f,-70.49687f,0f,0f,0f ) ;
  }

  @Test
  public void test528() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-623.0f,282.0f,0f,590.0f,0f,0f,0f,0f,0f,283.0f,237.0f,-224.0f,-289.0f,103.0f,-257.0f,-254,60.43708f,-38.7382f,111.923744f,0f,0f,0f ) ;
  }

  @Test
  public void test529() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,626.0f,550.0f,0f,-1902.0f,0f,0f,0f,0f,0f,-1283.0f,-501.0f,-1368.0f,-209.0f,-750.0f,-1237.0f,-1870,-0.06089033f,0.99322313f,-0.09900028f,0f,0f,0f ) ;
  }

  @Test
  public void test530() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,629.0f,990.0f,0f,1157.0f,0f,0f,0f,0f,0f,434.0f,-397.0f,644.0f,-158.0f,1628.0f,1110.0f,926,35.615032f,-36.00623f,-53.671967f,0f,0f,0f ) ;
  }

  @Test
  public void test531() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-62.948544f,-10.857851f,0f,0f,0f,0f,0f,0f,0f,72.60602f,21.905783f,65.14986f,0f,0f,0f,347,-54.935402f,-8.476204f,-90.10244f,0f,0f,0f ) ;
  }

  @Test
  public void test532() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-63.0f,-357.0f,0f,31.0f,0f,0f,0f,0f,0f,382.0f,-712.0f,-815.0f,-935.0f,289.0f,-691.0f,-970,1.5567526f,3.1181266f,1.9115969f,0f,0f,0f ) ;
  }

  @Test
  public void test533() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-63.0f,640.0f,0f,258.0f,0f,0f,0f,0f,0f,-66.0f,610.0f,-386.0f,215.0f,-181.0f,-1233.0f,-590,-100.0f,11.852771f,35.829536f,0f,0f,0f ) ;
  }

  @Test
  public void test534() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-63.0f,971.0f,0f,-520.0f,0f,0f,0f,0f,0f,166.0f,-256.0f,709.0f,-315.0f,61.0f,307.0f,966,96.49002f,-43.496002f,-53.10948f,0f,0f,0f ) ;
  }

  @Test
  public void test535() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,633.0f,-491.0f,0f,1916.0f,0f,0f,0f,0f,0f,20.0f,-60.0f,921.0f,-467.0f,-556.0f,-26.0f,-1785,0.6261307f,-0.7604261f,-0.06477582f,0f,0f,0f ) ;
  }

  @Test
  public void test536() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-640.0f,631.0f,0f,668.0f,0f,0f,0f,0f,0f,-200.0f,373.0f,384.0f,854.0f,648.0f,888.0f,715,31.830336f,57.837097f,-69.20872f,0f,0f,0f ) ;
  }

  @Test
  public void test537() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,6.4950757f,-74.40448f,0f,0f,0f,0f,0f,0f,0f,-71.77858f,-63.2935f,-44.13497f,0f,0f,0f,-346,99.44058f,-62.80296f,82.45682f,0f,0f,0f ) ;
  }

  @Test
  public void test538() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-65.378204f,100.0f,0f,0f,0f,0f,0f,0f,0f,42.54216f,-71.73153f,0.56641126f,-229.0f,-417.0f,789.0f,-568,-76.34162f,-45.855244f,-74.26157f,0f,0f,0f ) ;
  }

  @Test
  public void test539() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-654.0f,324.0f,95.0f,-66.0f,0f,0f,0f,0f,0f,592.0f,188.0f,383.0f,-205.0f,-527.0f,-540.0f,-224,-86.09476f,53.157997f,37.465725f,28.304039f,0f,0f ) ;
  }

  @Test
  public void test540() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-658.0f,4.0f,0f,2061.0f,0f,0f,0f,0f,0f,2281.0f,-957.0f,-289.0f,-822.0f,-1415.0f,1907.0f,1465,-0.8186407f,-0.30302137f,0.487858f,0f,0f,0f ) ;
  }

  @Test
  public void test541() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-661.0f,794.0f,0f,458.0f,0f,0f,0f,0f,0f,-290.0f,-988.0f,-592.0f,-1117.0f,207.0f,202.0f,1624,-48.790707f,-23.20826f,75.852394f,0f,0f,0f ) ;
  }

  @Test
  public void test542() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-66.34419f,0.0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-45.98717f,-67.204056f,0f,0f,0f,-3,0.008585682f,-0.0020663107f,0.07391704f,0f,0f,0f ) ;
  }

  @Test
  public void test543() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-66.74715f,-62.028973f,0f,-2.9539137f,0f,0f,0f,0f,0f,32.766987f,98.46081f,-100.0f,0f,0f,0f,83,-0.80164075f,-0.37401092f,-0.46635607f,0f,0f,0f ) ;
  }

  @Test
  public void test544() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-670.0f,-130.0f,0f,705.0f,0f,0f,0f,0f,0f,-322.0f,55.0f,-446.0f,891.0f,-150.0f,-662.0f,88,85.72725f,-1.8823977f,94.88814f,0f,0f,0f ) ;
  }

  @Test
  public void test545() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,679.0f,-13.0f,0f,1061.0f,0f,0f,0f,0f,0f,-305.0f,-1317.0f,209.0f,-678.0f,2.0f,-977.0f,122,100.0f,10.240327f,-51.650105f,0f,0f,0f ) ;
  }

  @Test
  public void test546() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,68.0f,20.0f,0f,-1.0f,0f,0f,0f,0f,0f,-1208.0f,1486.0f,18.0f,-2206.0f,1589.0f,-1049.0f,7,0.2034084f,-0.6474224f,0.73448575f,0f,0f,0f ) ;
  }

  @Test
  public void test547() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,688.0f,636.0f,0f,2767.0f,0f,0f,0f,0f,0f,-1695.0f,-1536.0f,145.0f,928.0f,227.0f,173.0f,1000,0.9676727f,-0.09781401f,0.23246929f,0f,0f,0f ) ;
  }

  @Test
  public void test548() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,69.0f,1456.0f,0f,472.0f,0f,0f,0f,0f,0f,-131.0f,824.0f,733.0f,-1168.0f,155.0f,976.0f,-805,100.0f,66.12584f,-56.46343f,0f,0f,0f ) ;
  }

  @Test
  public void test549() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,693.0f,14.0f,0f,1172.0f,0f,0f,0f,0f,0f,547.0f,-401.0f,98.0f,922.0f,-804.0f,-1289.0f,-666,17.766592f,24.916765f,2.7887495f,0f,0f,0f ) ;
  }

  @Test
  public void test550() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-696.0f,-340.0f,0f,248.0f,0f,0f,0f,0f,0f,-969.0f,-502.0f,-730.0f,-1096.0f,451.0f,-29.0f,-407,-0.25940427f,0.06556582f,1.185235f,0f,0f,0f ) ;
  }

  @Test
  public void test551() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,698.0f,-877.0f,0f,791.0f,0f,0f,0f,0f,0f,245.0f,-850.0f,347.0f,-987.0f,-309.0f,753.0f,281,0.29931504f,0.44336873f,-0.048068993f,0f,0f,0f ) ;
  }

  @Test
  public void test552() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,7.016321f,-100.0f,0f,0f,0f,0f,0f,0f,0f,-51.688667f,87.2388f,-100.0f,0f,0f,0f,-1,2.46701f,0.37609258f,-0.77712214f,0f,0f,0f ) ;
  }

  @Test
  public void test553() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,7.0f,-642.0f,0f,1453.0f,0f,0f,0f,0f,0f,-928.0f,720.0f,-152.0f,-631.0f,-794.0f,92.0f,-598,-0.26097453f,-1.5292746f,-0.7881113f,0f,0f,0f ) ;
  }

  @Test
  public void test554() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-71.57373f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-31.759985f,10.644327f,-40.634792f,0f,0f,0f,980,-19.865713f,41.379425f,79.27741f,0f,0f,0f ) ;
  }

  @Test
  public void test555() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-718.0f,-691.0f,0f,981.0f,0f,0f,0f,0f,0f,807.0f,-883.0f,-776.0f,17.0f,-366.0f,433.0f,327,0.079151705f,0.3327957f,0.57158077f,0f,0f,0f ) ;
  }

  @Test
  public void test556() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-724.0f,-390.0f,0f,184.0f,0f,0f,0f,0f,0f,388.0f,-233.0f,197.0f,836.0f,-372.0f,301.0f,445,-100.0f,100.0f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test557() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,728.0f,-288.0f,0f,921.0f,0f,0f,0f,0f,0f,-871.0f,-956.0f,210.0f,920.0f,-744.0f,429.0f,363,93.31116f,35.933903f,60.14763f,0f,0f,0f ) ;
  }

  @Test
  public void test558() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,730.0f,1068.0f,0f,518.0f,0f,0f,0f,0f,0f,820.0f,-746.0f,-461.0f,24.0f,-583.0f,986.0f,1264,0.6685765f,0.6340763f,0.16708861f,0f,0f,0f ) ;
  }

  @Test
  public void test559() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-732.0f,899.0f,0f,691.0f,0f,0f,0f,0f,0f,-362.0f,788.0f,772.0f,908.0f,-189.0f,808.0f,213,-84.018036f,-93.99896f,56.55004f,0f,0f,0f ) ;
  }

  @Test
  public void test560() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-74.02844f,0f,0f,0f,0f,0f,0f,0f,0f,-4.182845f,68.67965f,-100.0f,0f,0f,0f,1465,0.9497724f,0.07790266f,0.30308995f,0f,0f,0f ) ;
  }

  @Test
  public void test561() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-74.0f,786.0f,-1710.0f,1609.0f,0f,0f,0f,0f,0f,-160.0f,306.0f,-240.0f,-1782.0f,-274.0f,874.0f,-635,-31.577291f,-3.0656967f,17.157368f,15.561677f,0f,0f ) ;
  }

  @Test
  public void test562() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-743.0f,7.0f,0f,1563.0f,0f,0f,0f,0f,0f,-417.0f,212.0f,-1650.0f,-677.0f,-459.0f,112.0f,-1793,0.91650724f,-0.016271414f,-0.23371701f,0f,0f,0f ) ;
  }

  @Test
  public void test563() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-745.0f,-228.0f,0f,251.0f,0f,0f,0f,0f,0f,-730.0f,-566.0f,1537.0f,905.0f,-296.0f,497.0f,2721,-0.1422726f,-0.41026163f,-0.27870914f,0f,0f,0f ) ;
  }

  @Test
  public void test564() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-745.0f,588.0f,0f,319.0f,0f,0f,0f,0f,0f,-86.0f,-725.0f,124.0f,340.0f,-371.0f,800.0f,844,81.67015f,76.4303f,51.980152f,0f,0f,0f ) ;
  }

  @Test
  public void test565() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,748.0f,922.0f,0f,1.0f,0f,0f,0f,0f,0f,18.0f,-543.0f,149.0f,559.0f,767.0f,465.0f,-784,50.56598f,94.59915f,-24.328718f,0f,0f,0f ) ;
  }

  @Test
  public void test566() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,7.485116E-16f,-25.59634f,0f,0.0f,0f,0f,0f,0f,0f,-30.568758f,-19.04572f,55.78908f,0f,0f,0f,1083,28.353891f,60.585907f,-100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test567() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,749.0f,318.0f,0f,619.0f,0f,0f,0f,0f,0f,18.0f,905.0f,-999.0f,-1279.0f,340.0f,285.0f,1171,79.21671f,50.597095f,47.27495f,0f,0f,0f ) ;
  }

  @Test
  public void test568() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-76.04394f,35.188282f,0f,0f,0f,0f,0f,0f,0f,-26.501722f,2.8418634f,-59.205048f,0f,0f,0f,-321,31.895035f,92.250465f,16.140615f,0f,0f,0f ) ;
  }

  @Test
  public void test569() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-767.0f,-276.0f,0f,255.0f,0f,0f,0f,0f,0f,606.0f,4.0f,-578.0f,178.0f,-959.0f,-191.0f,782,-153.64896f,-19.624979f,40.00953f,0f,0f,0f ) ;
  }

  @Test
  public void test570() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-7.697732f,15.102878f,0f,0f,0f,0f,0f,0f,0f,-20.804707f,-75.01669f,8.326798f,100.0f,-94.0f,-597.0f,602,-0.7996946f,0.70680547f,-0.061868325f,0f,0f,0f ) ;
  }

  @Test
  public void test571() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-771.0f,519.0f,0f,265.0f,0f,0f,0f,0f,0f,-156.0f,-527.0f,206.0f,185.0f,-1563.0f,-1555.0f,-418,-0.12876669f,0.08410803f,-0.59751505f,0f,0f,0f ) ;
  }

  @Test
  public void test572() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,771.0f,-570.0f,0f,1421.0f,0f,0f,0f,0f,0f,-693.0f,-23.0f,109.0f,-38.0f,-177.0f,-278.0f,-321,9.37543f,49.702507f,48.083183f,0f,0f,0f ) ;
  }

  @Test
  public void test573() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,772.0f,-244.0f,0f,713.0f,0f,0f,0f,0f,0f,-912.0f,-394.0f,730.0f,-886.0f,824.0f,487.0f,735,-31.30791f,45.26622f,-93.495f,0f,0f,0f ) ;
  }

  @Test
  public void test574() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-781.0f,127.0f,0f,254.0f,0f,0f,0f,0f,0f,1488.0f,382.0f,-603.0f,424.0f,1284.0f,-733.0f,300,-1.8588603f,-33.9658f,-26.104345f,0f,0f,0f ) ;
  }

  @Test
  public void test575() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,78.31792f,97.07292f,0f,0f,0f,0f,0f,0f,0f,-44.73037f,89.47173f,9.207645f,0f,0f,0f,-462,0.10260608f,-0.040168185f,0.33795217f,0f,0f,0f ) ;
  }

  @Test
  public void test576() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-78.42341f,26.652739f,0f,0f,0f,0f,0f,0f,0f,-84.579605f,78.41966f,-1.0289111f,481.0f,-700.0f,428.0f,80,81.21608f,23.775955f,98.99648f,0f,0f,0f ) ;
  }

  @Test
  public void test577() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-786.0f,1249.0f,0f,2824.0f,0f,0f,0f,0f,0f,-170.0f,151.0f,427.0f,-551.0f,1294.0f,-681.0f,-887,-0.18801174f,0.32119134f,-0.18843533f,0f,0f,0f ) ;
  }

  @Test
  public void test578() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-788.0f,-303.0f,0f,255.0f,0f,0f,0f,0f,0f,813.0f,-310.0f,-712.0f,-121.0f,-296.0f,-398.0f,-338,-100.0f,178.15324f,107.00746f,0f,0f,0f ) ;
  }

  @Test
  public void test579() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,78.85579f,0f,0f,0f,0f,0f,0f,0f,0f,-3.822616f,97.66792f,20.951189f,0f,0f,0f,80,94.42256f,-17.45999f,-31.968956f,0f,0f,0f ) ;
  }

  @Test
  public void test580() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,7.949514E-21f,0.0f,0f,0f,0f,0f,0f,0f,0f,-42.47661f,71.07211f,-23.550299f,284.0f,64.0f,-319.0f,2767,8.010142f,4.442096f,-1.0417917f,0f,0f,0f ) ;
  }

  @Test
  public void test581() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-795.0f,-322.0f,0f,307.0f,0f,0f,0f,0f,0f,-338.0f,979.0f,-685.0f,-997.0f,-312.0f,-472.0f,-997,-100.0f,-100.0f,-46.244995f,0f,0f,0f ) ;
  }

  @Test
  public void test582() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-799.0f,-1713.0f,0f,628.0f,0f,0f,0f,0f,0f,109.0f,-540.0f,-18.0f,677.0f,-421.0f,-313.0f,-97,-0.034240726f,0.12085336f,-0.9085212f,0f,0f,0f ) ;
  }

  @Test
  public void test583() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,811.0f,-139.0f,0f,586.0f,0f,0f,0f,0f,0f,-180.0f,261.0f,-141.0f,265.0f,371.0f,349.0f,215,0.012920413f,-0.41667256f,-0.78778166f,0f,0f,0f ) ;
  }

  @Test
  public void test584() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-821.0f,-1.0f,0f,135.0f,0f,0f,0f,0f,0f,-793.0f,-782.0f,439.0f,717.0f,-789.0f,969.0f,455,7.956724f,5.318239f,0.05334447f,0f,0f,0f ) ;
  }

  @Test
  public void test585() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,821.0f,-678.0f,0f,1613.0f,0f,0f,0f,0f,0f,-374.0f,-84.0f,-562.0f,1387.0f,-163.0f,-899.0f,-2765,2.0469937f,0.10259444f,-0.16817506f,0f,0f,0f ) ;
  }

  @Test
  public void test586() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,825.0f,-2125.0f,0f,702.0f,0f,0f,0f,0f,0f,-216.0f,-942.0f,1059.0f,1771.0f,-539.0f,-1486.0f,-344,-0.5627188f,0.35561794f,-0.3857358f,0f,0f,0f ) ;
  }

  @Test
  public void test587() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-83.3468f,-67.82071f,0f,-71.98003f,0f,0f,0f,0f,0f,82.8375f,62.886414f,-6.857231f,0f,0f,0f,-23,-74.81665f,36.592476f,62.243744f,0f,0f,0f ) ;
  }

  @Test
  public void test588() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-834.0f,-1079.0f,0f,48.0f,0f,0f,0f,0f,0f,812.0f,-1141.0f,-313.0f,567.0f,331.0f,264.0f,908,-7.682614f,86.094574f,-58.413177f,0f,0f,0f ) ;
  }

  @Test
  public void test589() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-834.0f,-1474.0f,0f,538.0f,0f,0f,0f,0f,0f,-565.0f,-1197.0f,-1974.0f,-66.0f,634.0f,-1427.0f,-879,-0.0022781095f,-0.13980429f,0.5218898f,0f,0f,0f ) ;
  }

  @Test
  public void test590() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-83.46048f,0.0f,0f,0.54564136f,0f,0f,0f,0f,0f,40.78577f,100.0f,17.556393f,0f,0f,0f,-1088,0.4053552f,-0.7313027f,0.005436173f,0f,0f,0f ) ;
  }

  @Test
  public void test591() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-845.0f,33.0f,0f,498.0f,0f,0f,0f,0f,0f,74.0f,594.0f,616.0f,1215.0f,171.0f,689.0f,-990,-24.944914f,-5.5667644f,8.364561f,0f,0f,0f ) ;
  }

  @Test
  public void test592() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,84.97543f,0f,0f,0f,0f,0f,0f,0f,0f,-10.511058f,-0.2049692f,-97.85599f,1115.0f,-552.0f,-676.0f,3,-1.4669929f,0.59506994f,2.8744307f,0f,0f,0f ) ;
  }

  @Test
  public void test593() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,858.0f,76.0f,0f,345.0f,0f,0f,0f,0f,0f,632.0f,-660.0f,584.0f,865.0f,423.0f,307.0f,-104,-66.78673f,-75.78592f,-13.3726f,0f,0f,0f ) ;
  }

  @Test
  public void test594() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,85.883675f,0f,0f,0f,0f,0f,0f,0f,0f,99.14652f,76.41171f,-70.396545f,0f,0f,0f,2,0.35062003f,0.2027926f,0.9065765f,0f,0f,0f ) ;
  }

  @Test
  public void test595() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,859.0f,84.0f,0f,-899.0f,0f,0f,0f,0f,0f,-822.0f,-566.0f,-881.0f,350.0f,-119.0f,1186.0f,-1205,-0.28547636f,0.44896644f,0.63837713f,0f,0f,0f ) ;
  }

  @Test
  public void test596() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-864.0f,393.0f,-253.0f,397.0f,0f,0f,0f,0f,0f,597.0f,-115.0f,-246.0f,-702.0f,655.0f,572.0f,704,14.098858f,88.64451f,-7.223986f,-53.298855f,-100.0f,0f ) ;
  }

  @Test
  public void test597() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-870.0f,607.0f,0f,719.0f,0f,0f,0f,0f,0f,-48.0f,-78.0f,-77.0f,-477.0f,-295.0f,596.0f,-207,29.68568f,-15.958755f,95.051285f,0f,0f,0f ) ;
  }

  @Test
  public void test598() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,879.0f,-2217.0f,0f,1257.0f,0f,0f,0f,0f,0f,-1054.0f,-2006.0f,-844.0f,-650.0f,-419.0f,-1714.0f,-1065,-0.23365831f,0.78590196f,-0.57250535f,0f,0f,0f ) ;
  }

  @Test
  public void test599() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-882.0f,772.0f,-922.0f,-734.0f,0f,0f,0f,0f,0f,-628.0f,305.0f,40.0f,-909.0f,654.0f,738.0f,862,81.75784f,-68.02022f,20.86981f,96.44379f,0f,0f ) ;
  }

  @Test
  public void test600() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-883.0f,-1039.0f,0f,255.0f,0f,0f,0f,0f,0f,-720.0f,-957.0f,232.0f,697.0f,-935.0f,-950.0f,563,41.831406f,-6.6070223f,-8.2683f,0f,0f,0f ) ;
  }

  @Test
  public void test601() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-888.0f,-295.0f,0f,673.0f,0f,0f,0f,0f,0f,238.0f,-496.0f,663.0f,-794.0f,-705.0f,370.0f,-782,47.608734f,24.658955f,-70.672844f,0f,0f,0f ) ;
  }

  @Test
  public void test602() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-900.0f,1057.0f,0f,251.0f,0f,0f,0f,0f,0f,-1749.0f,-4.0f,300.0f,-248.0f,-1422.0f,-1429.0f,237,16.923956f,100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test603() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,908.0f,2100.0f,0f,1238.0f,0f,0f,0f,0f,0f,-684.0f,-1051.0f,99.0f,-652.0f,366.0f,-626.0f,378,-0.22891493f,-0.3195212f,-5.001316f,0f,0f,0f ) ;
  }

  @Test
  public void test604() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-913.0f,-515.0f,0f,254.0f,0f,0f,0f,0f,0f,-951.0f,-771.0f,-605.0f,-221.0f,-5.0f,118.0f,850,-69.6122f,-49.537148f,176.7034f,0f,0f,0f ) ;
  }

  @Test
  public void test605() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,913.0f,-969.0f,0f,963.0f,0f,0f,0f,0f,0f,395.0f,212.0f,-75.0f,108.0f,-161.0f,-8.0f,919,-18.65007f,-51.890816f,-49.30975f,0f,0f,0f ) ;
  }

  @Test
  public void test606() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-918.0f,2165.0f,-875.0f,607.0f,0f,0f,0f,0f,0f,-567.0f,-1028.0f,697.0f,-752.0f,-12.0f,-631.0f,253,-69.39268f,23.87483f,-21.237194f,-62.19526f,0f,0f ) ;
  }

  @Test
  public void test607() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,925.0f,362.0f,0f,946.0f,0f,0f,0f,0f,0f,243.0f,-401.0f,-80.0f,263.0f,243.0f,-423.0f,271,-85.43684f,-51.79556f,0.18372416f,0f,0f,0f ) ;
  }

  @Test
  public void test608() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,925.0f,-440.0f,276.0f,-290.0f,0f,0f,0f,0f,0f,694.0f,56.0f,-319.0f,137.0f,788.0f,145.0f,945,-85.33219f,-21.643969f,77.192955f,66.55828f,0f,0f ) ;
  }

  @Test
  public void test609() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,930.0f,467.0f,0f,0.0f,0f,0f,0f,0f,0f,-921.0f,991.0f,835.0f,-239.0f,511.0f,-723.0f,-996,136.95546f,-91.911674f,88.14088f,0f,0f,0f ) ;
  }

  @Test
  public void test610() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-932.0f,1299.0f,0f,5.0f,0f,0f,0f,0f,0f,-811.0f,251.0f,-809.0f,894.0f,-601.0f,159.0f,-123,9.399906f,-125.76626f,96.10924f,0f,0f,0f ) ;
  }

  @Test
  public void test611() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,934.0f,1135.0f,0f,675.0f,0f,0f,0f,0f,0f,156.0f,726.0f,1870.0f,1874.0f,874.0f,848.0f,-1519,0.8507619f,-0.420746f,-0.09774721f,0f,0f,0f ) ;
  }

  @Test
  public void test612() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-93.61869f,0.0f,0f,-16.22975f,0f,0f,0f,0f,0f,-100.0f,100.0f,-93.061035f,0f,0f,0f,911,0.23209454f,-0.6234691f,0.74660456f,0f,0f,0f ) ;
  }

  @Test
  public void test613() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-94.0f,505.0f,0f,944.0f,0f,0f,0f,0f,0f,-836.0f,-575.0f,-87.0f,550.0f,-563.0f,-246.0f,629,81.83856f,-51.98469f,-21.091185f,0f,0f,0f ) ;
  }

  @Test
  public void test614() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-958.0f,1666.0f,0f,2023.0f,0f,0f,0f,0f,0f,203.0f,872.0f,250.0f,-469.0f,398.0f,-1004.0f,632,-3.40452f,-0.7288423f,-0.89566946f,0f,0f,0f ) ;
  }

  @Test
  public void test615() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,961.0f,-193.0f,0f,511.0f,0f,0f,0f,0f,0f,-404.0f,-799.0f,-642.0f,663.0f,1065.0f,238.0f,841,100.0f,-100.0f,100.0f,0f,0f,0f ) ;
  }

  @Test
  public void test616() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,965.0f,325.0f,0f,785.0f,0f,0f,0f,0f,0f,-453.0f,-711.0f,-257.0f,737.0f,-677.0f,575.0f,1505,100.0f,-28.880936f,-96.36442f,0f,0f,0f ) ;
  }

  @Test
  public void test617() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-968.0f,311.0f,41.0f,1036.0f,0f,0f,0f,0f,0f,709.0f,-259.0f,-243.0f,83.0f,-296.0f,561.0f,1422,-37.396244f,-93.95941f,-8.914876f,-89.61598f,-100.0f,-72.79187f ) ;
  }

  @Test
  public void test618() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,973.0f,1782.0f,0f,1371.0f,0f,0f,0f,0f,0f,589.0f,-274.0f,939.0f,812.0f,271.0f,-430.0f,-1201,-72.949356f,-83.08789f,-52.429817f,0f,0f,0f ) ;
  }

  @Test
  public void test619() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-973.0f,240.0f,0f,169.0f,0f,0f,0f,0f,0f,419.0f,-88.0f,771.0f,-482.0f,392.0f,307.0f,186,-9.523998f,-10.091545f,-38.96939f,0f,0f,0f ) ;
  }

  @Test
  public void test620() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,98.0f,525.0f,0f,1841.0f,0f,0f,0f,0f,0f,1255.0f,472.0f,872.0f,-462.0f,2852.0f,-1587.0f,-508,-0.8856441f,-0.20468341f,-0.41682047f,0f,0f,0f ) ;
  }

  @Test
  public void test621() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,98.607445f,0.0f,0f,-70.01269f,0f,0f,0f,0f,0f,45.88749f,7.386027f,-55.229507f,0f,0f,0f,58,-0.2177739f,0.07311934f,-0.021784257f,0f,0f,0f ) ;
  }

  @Test
  public void test622() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,989.0f,-991.0f,762.0f,-656.0f,0f,0f,0f,0f,0f,-191.0f,907.0f,-593.0f,88.0f,18.0f,580.0f,363,-91.77515f,40.946945f,-0.047391366f,-51.126404f,92.85979f,84.41473f ) ;
  }

  @Test
  public void test623() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-98.923256f,94.22711f,0f,0f,0f,0f,0f,0f,0f,100.0f,100.0f,100.0f,0f,0f,0f,23,5.695167E-4f,-0.044964373f,-0.99898845f,0f,0f,0f ) ;
  }

  @Test
  public void test624() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,98.96841f,92.15351f,0f,0f,0f,0f,0f,0f,0f,-64.45426f,100.0f,64.35202f,360.0f,112.0f,283.0f,-709,0.50797f,-0.6374975f,0.57927835f,0f,0f,0f ) ;
  }

  @Test
  public void test625() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,99.0f,518.0f,0f,-10.0f,0f,0f,0f,0f,0f,-566.0f,-95.0f,-60.0f,15.0f,627.0f,106.0f,695,53.652096f,87.64859f,37.5171f,0f,0f,0f ) ;
  }

  @Test
  public void test626() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,991.0f,960.0f,0f,1165.0f,0f,0f,0f,0f,0f,-1997.0f,1056.0f,1233.0f,-1149.0f,-906.0f,-365.0f,-1676,-0.14002423f,0.4670831f,-0.8730559f,0f,0f,0f ) ;
  }

  @Test
  public void test627() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,99.36824f,-100.0f,0f,-77.34039f,0f,0f,0f,0f,0f,-100.0f,100.0f,-94.66142f,0f,0f,0f,332,0.38115463f,0.6662297f,0.6409829f,0f,0f,0f ) ;
  }

  @Test
  public void test628() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,99.94223f,-100.0f,0f,0.0f,0f,0f,0f,0f,0f,-100.0f,60.46172f,-100.0f,0f,0f,0f,1272,0.84882f,-0.26185036f,0.459281f,0f,0f,0f ) ;
  }

  @Test
  public void test629() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-99.989975f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,60.35464f,74.50737f,-33.705f,0f,0f,0f,1106,0.32554367f,-0.36531848f,0.87210304f,0f,0f,0f ) ;
  }

  @Test
  public void test630() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-99.99984f,0.0f,0f,0f,0f,0f,0f,0f,0f,100.0f,100.0f,18.158432f,0f,0f,0f,-345,-0.8001908f,-0.58526003f,-0.13101648f,0f,0f,0f ) ;
  }

  @Test
  public void test631() {
    TestDrivers.surfaceShade(0f,-147.0f,309.0f,0f,899.0f,600.0f,939.0f,229.0f,0f,0f,0f,0f,0f,-912.0f,836.0f,-602.0f,-811.0f,503.0f,242.0f,-429,-10.398626f,43.545326f,83.298805f,0f,-91.90481f,-13.825612f ) ;
  }

  @Test
  public void test632() {
    TestDrivers.surfaceShade(0f,1951.0f,224.0f,0f,1592.0f,832.0f,-681.0f,1385.0f,0f,0f,0f,0f,0f,-881.0f,-853.0f,881.0f,-14.0f,-866.0f,-788.0f,886,-0.16172124f,-0.540208f,-0.73292893f,0f,47.967785f,99.77942f ) ;
  }

  @Test
  public void test633() {
    TestDrivers.surfaceShade(0f,230.0f,0f,0f,1941.0f,611.0f,-555.0f,800.0f,0f,0f,0f,0f,0f,-634.0f,-826.0f,1368.0f,602.0f,-1790.0f,1107.0f,721,-0.38262996f,0.84306014f,0.28846097f,0f,-100.0f,0f ) ;
  }

  @Test
  public void test634() {
    TestDrivers.surfaceShade(0f,-2519.0f,0f,0f,589.0f,293.0f,-1095.0f,51.0f,0f,0f,0f,0f,0f,-205.0f,977.0f,-276.0f,634.0f,1847.0f,-82.0f,439,0.3788702f,-0.60077274f,-0.42859608f,0f,-98.32965f,0f ) ;
  }

  @Test
  public void test635() {
    TestDrivers.surfaceShade(0f,253.0f,566.0f,0f,-608.0f,866.0f,680.0f,-729.0f,0f,0f,0f,0f,0f,218.0f,-204.0f,-470.0f,-944.0f,796.0f,-296.0f,-312,-74.993805f,19.386307f,-23.696966f,0f,-92.23654f,-69.79337f ) ;
  }

  @Test
  public void test636() {
    TestDrivers.surfaceShade(0f,-3038.0f,175.0f,0f,2374.0f,1189.0f,-1137.0f,523.0f,0f,0f,0f,0f,0f,-433.0f,-310.0f,291.0f,-805.0f,92.0f,-670.0f,1808,-0.37542182f,0.7452294f,-0.43869856f,0f,-94.45866f,-100.0f ) ;
  }

  @Test
  public void test637() {
    TestDrivers.surfaceShade(0f,-326.0f,-119.0f,0f,1128.0f,57.0f,-508.0f,713.0f,0f,0f,0f,0f,0f,-24.0f,1890.0f,522.0f,107.0f,953.0f,-399.0f,74,100.0f,-100.0f,44.334698f,0f,69.42679f,23.550808f ) ;
  }

  @Test
  public void test638() {
    TestDrivers.surfaceShade(0f,517.0f,0f,0f,950.0f,244.0f,-128.0f,382.0f,0f,0f,0f,0f,0f,-544.0f,-866.0f,887.0f,-837.0f,870.0f,672.0f,-102,99.46595f,77.84246f,45.32552f,0f,-4.292884f,0f ) ;
  }

  @Test
  public void test639() {
    TestDrivers.surfaceShade(0f,-521.0f,-79.0f,0f,681.0f,-874.0f,399.0f,-924.0f,0f,0f,0f,0f,0f,100.0f,-760.0f,-457.0f,129.0f,430.0f,-914.0f,714,54.27946f,7.5935807f,18.38789f,0f,-20.36896f,-51.297432f ) ;
  }

  @Test
  public void test640() {
    TestDrivers.surfaceShade(0f,620.0f,0f,0f,-787.0f,72.0f,865.0f,-681.0f,0f,0f,0f,0f,0f,698.0f,-404.0f,-463.0f,-549.0f,-136.0f,788.0f,-577,-58.25857f,-44.34948f,55.210163f,0f,-66.71169f,0f ) ;
  }

  @Test
  public void test641() {
    TestDrivers.surfaceShade(0f,-686.0f,139.0f,0f,537.0f,176.0f,-455.0f,152.0f,0f,0f,0f,0f,0f,-858.0f,432.0f,914.0f,415.0f,-453.0f,745.0f,181,-91.98659f,-44.560295f,-78.435555f,0f,92.29493f,41.03928f ) ;
  }

  @Test
  public void test642() {
    TestDrivers.surfaceShade(0f,-713.0f,563.0f,0f,-424.0f,13.0f,360.0f,853.0f,0f,0f,0f,0f,0f,-645.0f,95.0f,-558.0f,576.0f,-269.0f,958.0f,-450,-44.56573f,-14.330689f,-64.58697f,0f,28.77443f,19.775177f ) ;
  }

  @Test
  public void test643() {
    TestDrivers.surfaceShade(0f,871.0f,0f,0f,398.0f,961.0f,-281.0f,852.0f,0f,0f,0f,0f,0f,-908.0f,785.0f,973.0f,-606.0f,967.0f,-281.0f,-944,26.681068f,-100.0f,69.2467f,0f,-94.302765f,0f ) ;
  }

  @Test
  public void test644() {
    TestDrivers.surfaceShade(0f,874.0f,0f,0f,315.0f,667.0f,-774.0f,-1.0f,0f,0f,0f,0f,0f,303.0f,526.0f,378.0f,1912.0f,664.0f,-323.0f,882,-100.0f,55.199677f,0.98325706f,0f,19.00132f,0f ) ;
  }

  @Test
  public void test645() {
    TestDrivers.surfaceShade(0f,-914.0f,0f,0f,526.0f,1625.0f,-225.0f,-1.0f,0f,0f,0f,0f,0f,-85.0f,-1211.0f,628.0f,16.0f,-622.0f,-466.0f,-211,82.52138f,-11.954956f,-93.303635f,0f,11.495444f,0f ) ;
  }

  @Test
  public void test646() {
    TestDrivers.surfaceShade(0f,93.0f,31.0f,0f,453.0f,960.0f,781.0f,-723.0f,0f,0f,0f,0f,0f,614.0f,625.0f,384.0f,991.0f,265.0f,404.0f,-155,-34.183514f,17.941578f,-36.550217f,0f,15.915661f,-29.503525f ) ;
  }

  @Test
  public void test647() {
    TestDrivers.surfaceShade(0f,-965.0f,0f,0f,695.0f,117.0f,1805.0f,786.0f,0f,0f,0f,0f,0f,-918.0f,2246.0f,1121.0f,995.0f,764.0f,1332.0f,-723,-0.68663794f,-0.68963087f,0.22231644f,0f,-63.997974f,0f ) ;
  }

  @Test
  public void test648() {
    TestDrivers.surfaceShade(0f,966.0f,0f,0f,298.0f,564.0f,880.0f,865.0f,0f,0f,0f,0f,0f,-418.0f,475.0f,-486.0f,661.0f,417.0f,-448.0f,483,-10.492511f,76.508606f,50.42134f,0f,-50.57208f,0f ) ;
  }

  @Test
  public void test649() {
    TestDrivers.surfaceShade(-1000.0f,827.0f,-1227.0f,0f,69.0f,483.0f,0f,418.0f,0f,0f,0f,0f,0f,-494.0f,289.0f,668.0f,-343.0f,753.0f,2010.0f,657,-33.716625f,3.611223f,-26.49649f,85.259766f,60.34185f,69.48573f ) ;
  }

  @Test
  public void test650() {
    TestDrivers.surfaceShade(-100.0f,-798.0f,11.0f,0f,73.0f,416.0f,0f,-459.0f,0f,0f,0f,0f,0f,497.0f,-641.0f,-614.0f,-1543.0f,648.0f,-188.0f,-625,-11.813729f,-80.30984f,74.27879f,-8.365995f,78.22448f,76.05451f ) ;
  }

  @Test
  public void test651() {
    TestDrivers.surfaceShade(101.0f,-172.0f,0f,0f,769.0f,1.0f,0f,0.0f,0f,0f,0f,0f,0f,-995.0f,498.0f,739.0f,0f,0f,0f,290,43.652985f,-4.341908f,61.700935f,86.27728f,-100.0f,0f ) ;
  }

  @Test
  public void test652() {
    TestDrivers.surfaceShade(1012.0f,-533.0f,0f,0f,1089.0f,-988.0f,0f,-629.0f,0f,0f,0f,0f,0f,-633.0f,-941.0f,-268.0f,0f,0f,0f,-1720,0.6497358f,-0.40714648f,0.6419309f,100.0f,100.0f,0f ) ;
  }

  @Test
  public void test653() {
    TestDrivers.surfaceShade(1012.0f,707.0f,0f,0f,743.0f,0.0f,0f,-1297.0f,0f,0f,0f,0f,0f,106.0f,-588.0f,-1051.0f,0f,0f,0f,-82,53.38724f,-5.706272f,8.576913f,68.52745f,13.459188f,0f ) ;
  }

  @Test
  public void test654() {
    TestDrivers.surfaceShade(1016.0f,1368.0f,-659.0f,0f,416.0f,789.0f,0f,326.0f,0f,0f,0f,0f,0f,-883.0f,717.0f,355.0f,436.0f,1668.0f,828.0f,-121,-56.83037f,-49.297794f,-41.787888f,-75.4179f,-100.0f,44.261242f ) ;
  }

  @Test
  public void test655() {
    TestDrivers.surfaceShade(1017.0f,-1738.0f,328.0f,0f,499.0f,-453.0f,0f,1598.0f,0f,0f,0f,0f,0f,925.0f,365.0f,304.0f,-989.0f,-134.0f,92.0f,-606,-2.696411f,-32.78407f,47.566994f,43.06672f,3.021883f,89.82112f ) ;
  }

  @Test
  public void test656() {
    TestDrivers.surfaceShade(-1019.0f,-973.0f,-1050.0f,0f,30.0f,2231.0f,0f,844.0f,0f,0f,0f,0f,0f,-543.0f,-284.0f,875.0f,578.0f,202.0f,-117.0f,-132,-27.005827f,-38.944878f,-29.399439f,-87.36853f,-36.792885f,-34.138596f ) ;
  }

  @Test
  public void test657() {
    TestDrivers.surfaceShade(-1020.0f,466.0f,1597.0f,0f,221.0f,-1394.0f,0f,1.0f,0f,0f,0f,0f,0f,-292.0f,1575.0f,707.0f,0f,0f,0f,-339,-57.678272f,-41.808464f,49.187183f,1.283373f,16.511154f,-25.217014f ) ;
  }

  @Test
  public void test658() {
    TestDrivers.surfaceShade(102.0f,-16.0f,78.0f,-86.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-5.427693f,7.267442E-4f,100.0f ) ;
  }

  @Test
  public void test659() {
    TestDrivers.surfaceShade(102.0f,941.0f,-8.0f,111.0f,0f,0f,0f,-38.36141f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-19.74199f,91.621765f,-28.572372f ) ;
  }

  @Test
  public void test660() {
    TestDrivers.surfaceShade(1028.0f,0f,0f,0f,20.8776f,-71.88036f,0f,-23.638876f,0f,0f,0f,0f,0f,-35.51698f,70.74852f,100.0f,0f,0f,0f,-720,0.5568629f,0.43537557f,-0.7073555f,100.0f,0f,0f ) ;
  }

  @Test
  public void test661() {
    TestDrivers.surfaceShade(1028.0f,647.0f,176.0f,0f,958.0f,-777.0f,0f,33.0f,0f,0f,0f,0f,0f,-601.0f,533.0f,-1065.0f,-356.0f,-33.0f,-884.0f,-870,-46.568066f,-39.49134f,6.5150447f,26.73436f,-58.353325f,81.647995f ) ;
  }

  @Test
  public void test662() {
    TestDrivers.surfaceShade(-103.0f,-826.0f,818.0f,0f,582.0f,2096.0f,0f,1151.0f,0f,0f,0f,0f,0f,-716.0f,-1358.0f,-1259.0f,-763.0f,1464.0f,333.0f,-674,-0.08097337f,-0.25713697f,0.49755138f,86.93594f,87.10836f,13.910856f ) ;
  }

  @Test
  public void test663() {
    TestDrivers.surfaceShade(-1038.0f,1067.0f,-1938.0f,0f,8.0f,-2300.0f,0f,692.0f,0f,0f,0f,0f,0f,1114.0f,-409.0f,629.0f,1180.0f,-746.0f,217.0f,62,-0.33417067f,-0.2864079f,0.4056046f,-64.58235f,-100.0f,7.5198903f ) ;
  }

  @Test
  public void test664() {
    TestDrivers.surfaceShade(-1040.0f,124.0f,-884.0f,818.0f,0f,0f,0f,66.724976f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-100.0f,9.858822E-6f,55.87453f ) ;
  }

  @Test
  public void test665() {
    TestDrivers.surfaceShade(105.0f,-1266.0f,863.0f,0f,58.0f,1386.0f,0f,2068.0f,0f,0f,0f,0f,0f,-129.0f,540.0f,-742.0f,-426.0f,790.0f,736.0f,632,46.43148f,2.9874551f,-5.8981605f,68.62135f,-67.15209f,97.40366f ) ;
  }

  @Test
  public void test666() {
    TestDrivers.surfaceShade(1051.0f,0f,0f,0f,1.5601599f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,-27.38327f,-81.94425f,-88.795616f,0f,0f,0f,-1559,28.57546f,85.3955f,-87.61874f,8.616409f,0f,0f ) ;
  }

  @Test
  public void test667() {
    TestDrivers.surfaceShade(1057.0f,-3085.0f,1465.0f,0f,807.0f,-1107.0f,0f,2072.0f,0f,0f,0f,0f,0f,-834.0f,1.0f,328.0f,-201.0f,275.0f,-966.0f,50,-2.921725f,-0.06391893f,-7.4288254f,68.64375f,-92.237144f,26.28484f ) ;
  }

  @Test
  public void test668() {
    TestDrivers.surfaceShade(-1060.0f,728.0f,-78.0f,0f,3377.0f,-645.0f,0f,194.0f,0f,0f,0f,0f,0f,390.0f,108.0f,117.0f,1546.0f,-1318.0f,-881.0f,-595,0.28590173f,-0.0449662f,-0.91149855f,-98.73713f,8.958352f,11.552322f ) ;
  }

  @Test
  public void test669() {
    TestDrivers.surfaceShade(-1063.0f,261.0f,567.0f,-349.0f,0f,0f,0f,11.327377f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,68.553276f,-167.60011f,-28.782913f ) ;
  }

  @Test
  public void test670() {
    TestDrivers.surfaceShade(1063.0f,858.0f,27.0f,0f,943.0f,96.0f,0f,2232.0f,0f,0f,0f,0f,0f,-1167.0f,125.0f,49.0f,1309.0f,-168.0f,1315.0f,-936,0.028471462f,0.1529991f,0.14001505f,-79.74972f,-39.712147f,5.4244015E-6f ) ;
  }

  @Test
  public void test671() {
    TestDrivers.surfaceShade(1071.0f,352.0f,0f,0f,8.0f,468.0f,-915.0f,-2092.0f,0f,0f,0f,0f,0f,246.0f,-1707.0f,-487.0f,-568.0f,-1229.0f,431.0f,1732,0.4320359f,0.88293934f,0.07972777f,-8.274349f,-33.370037f,0f ) ;
  }

  @Test
  public void test672() {
    TestDrivers.surfaceShade(-108.0f,529.0f,-94.0f,0f,20.0f,-845.0f,0f,575.0f,0f,0f,0f,0f,0f,889.0f,-130.0f,399.0f,-185.0f,-967.0f,-909.0f,-310,18.196136f,93.42182f,-10.10408f,-66.19597f,99.6198f,37.21255f ) ;
  }

  @Test
  public void test673() {
    TestDrivers.surfaceShade(108.0f,-917.0f,0f,0f,660.0f,543.0f,-679.0f,-305.0f,0f,0f,0f,0f,0f,-2760.0f,-584.0f,888.0f,-1215.0f,-95.0f,-205.0f,834,0.06628915f,0.16380583f,-0.1747442f,-46.194042f,-100.0f,0f ) ;
  }

  @Test
  public void test674() {
    TestDrivers.surfaceShade(1084.0f,-50.0f,2018.0f,31.0f,0f,0f,0f,-79.06516f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,25.707573f,-6.451613E-4f,-23.873621f ) ;
  }

  @Test
  public void test675() {
    TestDrivers.surfaceShade(-1086.0f,-271.0f,97.0f,-422.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,4.3963485f,8.744163E-6f,-2.4429573E-5f ) ;
  }

  @Test
  public void test676() {
    TestDrivers.surfaceShade(-1089.0f,2378.0f,-1180.0f,0f,77.0f,-139.0f,0f,-765.0f,0f,0f,0f,0f,0f,349.0f,-707.0f,-1056.0f,0f,0f,0f,666,65.81987f,4.191023f,18.947046f,-102.95844f,9.693262f,-19.600853f ) ;
  }

  @Test
  public void test677() {
    TestDrivers.surfaceShade(-109.0f,-972.0f,0f,0f,4.0f,-982.0f,0f,-1727.0f,0f,0f,0f,0f,0f,932.0f,919.0f,621.0f,0f,0f,0f,1830,-63.14204f,11.129387f,78.293846f,-9.769858f,-23.385687f,0f ) ;
  }

  @Test
  public void test678() {
    TestDrivers.surfaceShade(1092.0f,0f,0f,0f,105.0f,126.0f,0f,545.0f,0f,0f,0f,0f,0f,-945.0f,639.0f,-537.0f,195.0f,-4.0f,630.0f,924,66.00623f,56.80131f,-48.565838f,38.975914f,0f,0f ) ;
  }

  @Test
  public void test679() {
    TestDrivers.surfaceShade(1096.0f,1173.0f,0f,0f,1809.0f,1082.0f,0f,962.0f,0f,0f,0f,0f,0f,-645.0f,251.0f,10.0f,-1335.0f,244.0f,-1488.0f,546,-33.45861f,-89.79387f,95.74564f,-100.0f,-95.72099f,0f ) ;
  }

  @Test
  public void test680() {
    TestDrivers.surfaceShade(1.0f,-2312.0f,-2164.0f,0f,309.0f,-232.0f,0f,389.0f,0f,0f,0f,0f,0f,654.0f,-595.0f,923.0f,-283.0f,802.0f,-2284.0f,1368,0.1928721f,-0.3100579f,-0.6851741f,100.0f,100.0f,-15.80114f ) ;
  }

  @Test
  public void test681() {
    TestDrivers.surfaceShade(-110.0f,38.0f,-1970.0f,0f,101.0f,77.0f,0f,-263.0f,0f,0f,0f,0f,0f,418.0f,-384.0f,-991.0f,471.0f,-184.0f,422.0f,1140,-0.8776528f,-0.071474634f,0.090528585f,-46.245216f,-24.26756f,100.0f ) ;
  }

  @Test
  public void test682() {
    TestDrivers.surfaceShade(1104.0f,0f,0f,0f,346.0f,265.0f,0f,1148.0f,0f,0f,0f,0f,0f,1940.0f,-922.0f,314.0f,-531.0f,369.0f,-985.0f,-740,0.18630773f,0.6605097f,0.72733516f,78.06495f,0f,0f ) ;
  }

  @Test
  public void test683() {
    TestDrivers.surfaceShade(1112.0f,-160.0f,366.0f,0f,844.0f,-281.0f,0f,-519.0f,0f,0f,0f,0f,0f,479.0f,275.0f,971.0f,0f,0f,0f,-1425,-82.9253f,59.80605f,23.969677f,100.0f,-56.833416f,100.0f ) ;
  }

  @Test
  public void test684() {
    TestDrivers.surfaceShade(-1113.0f,-278.0f,-238.0f,0f,1940.0f,-1574.0f,0f,-956.0f,0f,0f,0f,0f,0f,-955.0f,283.0f,-438.0f,0f,0f,0f,-45,0.38165638f,-0.7483406f,-0.4556196f,59.56229f,-80.63852f,-15.616412f ) ;
  }

  @Test
  public void test685() {
    TestDrivers.surfaceShade(1118.0f,545.0f,0f,0f,69.0f,-189.0f,0f,63.0f,0f,0f,0f,0f,0f,-320.0f,-1062.0f,1013.0f,-577.0f,-1066.0f,6.0f,46,0.46085694f,0.37423858f,-0.45935687f,55.722713f,38.994053f,0f ) ;
  }

  @Test
  public void test686() {
    TestDrivers.surfaceShade(-1118.0f,636.0f,0f,-950.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,10.026991f,4.4495325f,0f ) ;
  }

  @Test
  public void test687() {
    TestDrivers.surfaceShade(1119.0f,-1274.0f,0f,0f,615.0f,-479.0f,0f,1354.0f,0f,0f,0f,0f,0f,-960.0f,-37.0f,1368.0f,1086.0f,821.0f,1043.0f,-958,0.15932114f,-0.7419584f,-0.4762619f,59.805656f,99.86036f,0f ) ;
  }

  @Test
  public void test688() {
    TestDrivers.surfaceShade(-1119.0f,-8.0f,754.0f,0f,696.0f,471.0f,0f,250.0f,0f,0f,0f,0f,0f,-111.0f,-981.0f,-553.0f,420.0f,-823.0f,-339.0f,-308,-29.946327f,34.036606f,-54.36866f,-34.77454f,46.220596f,-60.869892f ) ;
  }

  @Test
  public void test689() {
    TestDrivers.surfaceShade(1129.0f,-312.0f,0f,0f,1518.0f,1719.0f,0f,-1138.0f,0f,0f,0f,0f,0f,167.0f,462.0f,-554.0f,478.0f,-294.0f,112.0f,-956,0.49627396f,-0.7412021f,0.4520305f,92.98482f,-100.0f,0f ) ;
  }

  @Test
  public void test690() {
    TestDrivers.surfaceShade(1131.0f,-21.0f,0f,-444.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-1.9913814E-6f,1.0725011E-4f,0f ) ;
  }

  @Test
  public void test691() {
    TestDrivers.surfaceShade(1133.0f,-72.0f,-468.0f,0f,686.0f,-2209.0f,0f,-493.0f,0f,0f,0f,0f,0f,-489.0f,141.0f,452.0f,0f,0f,0f,906,0.4434719f,-0.09275045f,0.508707f,-41.50749f,-100.0f,-100.0f ) ;
  }

  @Test
  public void test692() {
    TestDrivers.surfaceShade(-1135.0f,0f,-463.0f,0f,28.0f,2241.0f,0f,2143.0f,0f,0f,0f,0f,0f,156.0f,-142.0f,-69.0f,-2373.0f,-1134.0f,-1063.0f,-626,0.101703234f,0.95992994f,-0.030262223f,99.99718f,0f,-1.7894796f ) ;
  }

  @Test
  public void test693() {
    TestDrivers.surfaceShade(1140.0f,0f,0f,0f,1271.0f,-1174.0f,0f,40.0f,0f,0f,0f,0f,0f,-394.0f,-303.0f,-592.0f,1847.0f,-881.0f,-18.0f,-231,0.54545254f,0.6332878f,-0.5036631f,26.19425f,0f,0f ) ;
  }

  @Test
  public void test694() {
    TestDrivers.surfaceShade(-1145.0f,0f,0f,0f,569.0f,960.0f,0f,556.0f,0f,0f,0f,0f,0f,1486.0f,-186.0f,-565.0f,-128.0f,-883.0f,909.0f,1086,0.45306486f,1.3982171f,0.7313027f,-32.343975f,0f,0f ) ;
  }

  @Test
  public void test695() {
    TestDrivers.surfaceShade(1146.0f,125.0f,0f,0f,415.0f,0.0f,0f,-2.0f,0f,0f,0f,0f,0f,142.0f,-489.0f,601.0f,0f,0f,0f,384,-98.82402f,-12.785736f,12.946399f,92.70636f,54.71252f,0f ) ;
  }

  @Test
  public void test696() {
    TestDrivers.surfaceShade(-1149.0f,9.0f,299.0f,-464.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-27.137613f,-2.394636E-4f,77.96882f ) ;
  }

  @Test
  public void test697() {
    TestDrivers.surfaceShade(1150.0f,467.0f,0f,0f,1617.0f,-68.0f,0f,9.0f,0f,0f,0f,0f,0f,-13.0f,1243.0f,-35.0f,0f,0f,0f,-704,19.612602f,-85.180374f,3.3507392f,42.648342f,1.2031265E-11f,0f ) ;
  }

  @Test
  public void test698() {
    TestDrivers.surfaceShade(-1155.0f,-1778.0f,-31.0f,0f,30.0f,963.0f,0f,218.0f,0f,0f,0f,0f,0f,694.0f,946.0f,202.0f,-66.0f,-50.0f,506.0f,1097,78.64453f,-49.925255f,-36.3862f,19.895329f,-65.24077f,-57.35367f ) ;
  }

  @Test
  public void test699() {
    TestDrivers.surfaceShade(-116.0f,0f,0f,0f,622.0f,763.0f,0f,367.0f,0f,0f,0f,0f,0f,-830.0f,-322.0f,650.0f,294.0f,778.0f,-113.0f,-446,14.956766f,90.654106f,17.867949f,65.64294f,0f,0f ) ;
  }

  @Test
  public void test700() {
    TestDrivers.surfaceShade(-1161.0f,-1599.0f,0f,0f,9.0f,-491.0f,0f,-1.0f,0f,0f,0f,0f,0f,585.0f,-777.0f,153.0f,0f,0f,0f,750,-0.34434348f,-0.22450922f,-0.9122297f,-9.430477f,13.498739f,0f ) ;
  }

  @Test
  public void test701() {
    TestDrivers.surfaceShade(-1162.0f,-180.0f,0f,0f,1086.0f,1.0f,0f,-1.0f,0f,0f,0f,0f,0f,468.0f,985.0f,-96.0f,0f,0f,0f,1040,-1.3998514f,-42.83196f,66.32843f,-2.1199276f,74.814926f,0f ) ;
  }

  @Test
  public void test702() {
    TestDrivers.surfaceShade(-1162.0f,-97.0f,1126.0f,-257.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,89.64073f,4.0113922E-5f,-11.159501f ) ;
  }

  @Test
  public void test703() {
    TestDrivers.surfaceShade(-1166.0f,986.0f,0f,0f,390.0f,-314.0f,0f,584.0f,0f,0f,0f,0f,0f,-26.0f,160.0f,3.0f,106.0f,-210.0f,-323.0f,82,27.653631f,-47.574265f,15.053535f,-61.78895f,-74.3746f,0f ) ;
  }

  @Test
  public void test704() {
    TestDrivers.surfaceShade(-1169.0f,1233.0f,833.0f,0f,440.0f,-1743.0f,0f,307.0f,0f,0f,0f,0f,0f,1054.0f,463.0f,-299.0f,642.0f,-453.0f,-462.0f,-470,0.37944975f,-0.74219996f,0.1882992f,15.2895155f,-75.980804f,-0.30257085f ) ;
  }

  @Test
  public void test705() {
    TestDrivers.surfaceShade(-1173.0f,-1971.0f,1492.0f,0f,59.0f,1389.0f,0f,-1694.0f,0f,0f,0f,0f,0f,-993.0f,34.0f,185.0f,-143.0f,-1166.0f,149.0f,-807,20.378302f,76.064545f,95.40248f,-57.8527f,-88.09934f,100.0f ) ;
  }

  @Test
  public void test706() {
    TestDrivers.surfaceShade(1173.0f,-737.0f,0f,0f,501.0f,965.0f,0f,333.0f,0f,0f,0f,0f,0f,-176.0f,1867.0f,86.0f,278.0f,-1347.0f,-275.0f,29,8.897865E-4f,-0.10653626f,0.99431777f,-22.157486f,7.713591f,0f ) ;
  }

  @Test
  public void test707() {
    TestDrivers.surfaceShade(-1175.0f,-74.0f,335.0f,0f,144.0f,-1206.0f,0f,-164.0f,0f,0f,0f,0f,0f,554.0f,92.0f,-578.0f,0f,0f,0f,281,-81.32333f,67.04871f,-19.232958f,-60.96851f,-3.3795686E-9f,99.30378f ) ;
  }

  @Test
  public void test708() {
    TestDrivers.surfaceShade(-1178.0f,18.0f,0f,0f,8.0f,-458.0f,0f,338.0f,0f,0f,0f,0f,0f,438.0f,860.0f,977.0f,-216.0f,1900.0f,-555.0f,-287,-0.26886144f,-0.433147f,0.5018092f,100.0f,-12.020185f,0f ) ;
  }

  @Test
  public void test709() {
    TestDrivers.surfaceShade(1197.0f,-2116.0f,0f,0f,939.0f,-880.0f,0f,-856.0f,0f,0f,0f,0f,0f,1869.0f,-1323.0f,-517.0f,0f,0f,0f,212,-0.8899005f,0.4179223f,0.18280609f,3.2938626f,-84.15546f,0f ) ;
  }

  @Test
  public void test710() {
    TestDrivers.surfaceShade(1197.0f,915.0f,0f,0f,225.0f,1346.0f,0f,-217.0f,0f,0f,0f,0f,0f,-112.0f,107.0f,140.0f,2315.0f,-807.0f,-1004.0f,419,-0.541136f,0.27454007f,-0.6427359f,38.689255f,1.2548149f,0f ) ;
  }

  @Test
  public void test711() {
    TestDrivers.surfaceShade(-1203.0f,1155.0f,810.0f,0f,64.0f,-1844.0f,0f,30.0f,0f,0f,0f,0f,0f,-978.0f,-449.0f,1118.0f,-366.0f,271.0f,-960.0f,-857,-53.11633f,32.87263f,-33.26293f,-100.0f,14.16518f,-24.000532f ) ;
  }

  @Test
  public void test712() {
    TestDrivers.surfaceShade(-1204.0f,-205.0f,-1195.0f,0f,500.0f,495.0f,0f,-663.0f,0f,0f,0f,0f,0f,-833.0f,-295.0f,-971.0f,-905.0f,1187.0f,718.0f,2640,-0.20914786f,0.2984338f,0.59783113f,-21.064047f,-47.526623f,-31.984491f ) ;
  }

  @Test
  public void test713() {
    TestDrivers.surfaceShade(12.0f,-116.0f,-365.0f,0f,670.0f,405.0f,0f,828.0f,0f,0f,0f,0f,0f,105.0f,-32.0f,-452.0f,-897.0f,237.0f,933.0f,-950,-74.32776f,-44.53038f,44.942554f,-17.511847f,30.0482f,92.88067f ) ;
  }

  @Test
  public void test714() {
    TestDrivers.surfaceShade(-12.0f,-142.0f,673.0f,0f,322.0f,-125.0f,0f,249.0f,0f,0f,0f,0f,0f,2014.0f,-364.0f,-814.0f,-1497.0f,-452.0f,-760.0f,118,0.080908224f,-0.66131437f,0.4959061f,100.0f,80.50218f,9.913365f ) ;
  }

  @Test
  public void test715() {
    TestDrivers.surfaceShade(12.0f,873.0f,1341.0f,0f,693.0f,2.0f,0f,-932.0f,0f,0f,0f,0f,0f,-1052.0f,-185.0f,-322.0f,0f,0f,0f,1147,1.097638f,-0.76416975f,-3.1470304f,100.0f,-90.05302f,100.0f ) ;
  }

  @Test
  public void test716() {
    TestDrivers.surfaceShade(1210.0f,-459.0f,-131.0f,-627.0f,0f,0f,0f,50.638885f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-98.08042f,-65.1342f,1.2174781E-5f ) ;
  }

  @Test
  public void test717() {
    TestDrivers.surfaceShade(-121.0f,-694.0f,0f,0f,912.0f,-171.0f,0f,1950.0f,0f,0f,0f,0f,0f,-782.0f,-793.0f,-1595.0f,-552.0f,624.0f,-608.0f,-654,-59.620964f,64.29055f,29.88271f,48.240974f,-22.04793f,0f ) ;
  }

  @Test
  public void test718() {
    TestDrivers.surfaceShade(122.0f,66.0f,0f,-61.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-1.2930475f,-2.483855E-4f,0f ) ;
  }

  @Test
  public void test719() {
    TestDrivers.surfaceShade(-1221.0f,801.0f,0f,0f,856.0f,379.0f,0f,2626.0f,0f,0f,0f,0f,0f,-352.0f,634.0f,15.0f,-524.0f,-772.0f,-89.0f,751,49.532574f,27.125895f,15.843304f,-46.06213f,70.214554f,0f ) ;
  }

  @Test
  public void test720() {
    TestDrivers.surfaceShade(1226.0f,-106.0f,0f,0f,147.0f,371.0f,0f,-2601.0f,0f,0f,0f,0f,0f,-1363.0f,793.0f,433.0f,-645.0f,-773.0f,-240.0f,-345,0.5334781f,0.75893337f,0.2893683f,99.75698f,-37.415455f,0f ) ;
  }

  @Test
  public void test721() {
    TestDrivers.surfaceShade(1238.0f,-685.0f,-1253.0f,0f,54.0f,-68.0f,0f,382.0f,0f,0f,0f,0f,0f,582.0f,-85.0f,1573.0f,-939.0f,165.0f,-996.0f,348,-23.76612f,-100.0f,3.3896265f,100.0f,-91.77053f,-46.10628f ) ;
  }

  @Test
  public void test722() {
    TestDrivers.surfaceShade(124.0f,1142.0f,-379.0f,0f,236.0f,-209.0f,0f,722.0f,0f,0f,0f,0f,0f,-381.0f,-72.0f,717.0f,-1753.0f,102.0f,-186.0f,1203,-100.0f,95.278435f,-43.570366f,100.0f,-100.0f,93.18786f ) ;
  }

  @Test
  public void test723() {
    TestDrivers.surfaceShade(124.0f,-1483.0f,-83.0f,0f,223.0f,510.0f,0f,373.0f,0f,0f,0f,0f,0f,-371.0f,1157.0f,-281.0f,858.0f,758.0f,610.0f,1074,-13.454042f,-17.09341f,-52.61788f,-60.09437f,-92.84698f,-94.56832f ) ;
  }

  @Test
  public void test724() {
    TestDrivers.surfaceShade(1241.0f,845.0f,126.0f,0f,604.0f,-581.0f,0f,514.0f,0f,0f,0f,0f,0f,-576.0f,535.0f,389.0f,-224.0f,813.0f,146.0f,-2462,28.275995f,31.013664f,-0.7849268f,-99.99968f,-10.933068f,-73.57706f ) ;
  }

  @Test
  public void test725() {
    TestDrivers.surfaceShade(1246.0f,-1466.0f,1099.0f,0f,1293.0f,1103.0f,0f,-1611.0f,0f,0f,0f,0f,0f,-746.0f,-933.0f,-243.0f,931.0f,1793.0f,1610.0f,-716,0.038127135f,0.69800264f,-0.52365834f,70.575836f,-100.0f,-100.0f ) ;
  }

  @Test
  public void test726() {
    TestDrivers.surfaceShade(1247.0f,-3322.0f,241.0f,0f,200.0f,-581.0f,0f,1843.0f,0f,0f,0f,0f,0f,-238.0f,-833.0f,-947.0f,-521.0f,92.0f,672.0f,78,-100.0f,-74.251595f,90.445175f,-39.744392f,-8.417217f,0.5492181f ) ;
  }

  @Test
  public void test727() {
    TestDrivers.surfaceShade(1254.0f,-2058.0f,0f,0f,884.0f,769.0f,0f,232.0f,0f,0f,0f,0f,0f,-2183.0f,539.0f,347.0f,1383.0f,-667.0f,-1229.0f,867,0.3095151f,0.04902591f,0.08411717f,-30.09913f,-97.03752f,0f ) ;
  }

  @Test
  public void test728() {
    TestDrivers.surfaceShade(-126.0f,900.0f,-35.0f,0f,113.0f,301.0f,0f,183.0f,0f,0f,0f,0f,0f,53.0f,572.0f,-317.0f,-1012.0f,-130.0f,-344.0f,-535,65.709564f,41.462532f,85.80182f,-25.619503f,99.72936f,-92.23018f ) ;
  }

  @Test
  public void test729() {
    TestDrivers.surfaceShade(-1281.0f,293.0f,0f,0f,770.0f,-1610.0f,0f,-1010.0f,0f,0f,0f,0f,0f,161.0f,-1238.0f,-1447.0f,0f,0f,0f,-1244,-0.28632885f,0.15062645f,-0.16072874f,41.539936f,55.871326f,0f ) ;
  }

  @Test
  public void test730() {
    TestDrivers.surfaceShade(1282.0f,-902.0f,1475.0f,0f,1150.0f,-2263.0f,0f,1428.0f,0f,0f,0f,0f,0f,160.0f,-499.0f,292.0f,966.0f,792.0f,366.0f,625,0.8880433f,0.31977266f,0.059861735f,100.0f,-0.56463385f,38.225277f ) ;
  }

  @Test
  public void test731() {
    TestDrivers.surfaceShade(-1288.0f,-198.0f,-621.0f,0f,468.0f,904.0f,-343.0f,-514.0f,0f,0f,0f,0f,0f,-751.0f,-763.0f,605.0f,-991.0f,-397.0f,1781.0f,-822,-0.31738716f,0.16733934f,-0.7962436f,-31.813019f,98.0688f,1.7225853f ) ;
  }

  @Test
  public void test732() {
    TestDrivers.surfaceShade(-1292.0f,-465.0f,0f,0f,521.0f,-260.0f,0f,3.0f,0f,0f,0f,0f,0f,-249.0f,-1186.0f,922.0f,0f,0f,0f,-879,0.44228205f,-0.11887895f,-0.2474188f,100.0f,-59.52768f,0f ) ;
  }

  @Test
  public void test733() {
    TestDrivers.surfaceShade(1299.0f,0f,0f,0f,94.0f,-2568.0f,0f,8.0f,0f,0f,0f,0f,0f,-11.0f,211.0f,-491.0f,-298.0f,-1691.0f,-232.0f,-1542,0.29414693f,-0.44011578f,-0.19572312f,-66.83158f,0f,0f ) ;
  }

  @Test
  public void test734() {
    TestDrivers.surfaceShade(1299.0f,-16.0f,0f,0f,818.0f,-422.0f,0f,1997.0f,0f,0f,0f,0f,0f,-867.0f,-211.0f,-659.0f,18.0f,992.0f,-637.0f,-59,-0.53958935f,-0.08290645f,0.73647285f,66.887794f,0.028382035f,0f ) ;
  }

  @Test
  public void test735() {
    TestDrivers.surfaceShade(130.0f,-263.0f,0f,-373.0f,0f,0f,0f,74.974106f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-2.0622809E-5f,36.449406f,0f ) ;
  }

  @Test
  public void test736() {
    TestDrivers.surfaceShade(1302.0f,-738.0f,850.0f,0f,1019.0f,-786.0f,0f,252.0f,0f,0f,0f,0f,0f,-817.0f,-567.0f,550.0f,1619.0f,-604.0f,-241.0f,-221,-12.298529f,86.71577f,71.12717f,96.56569f,-100.0f,37.57471f ) ;
  }

  @Test
  public void test737() {
    TestDrivers.surfaceShade(1304.0f,0f,0f,0f,470.0f,1799.0f,0f,304.0f,0f,0f,0f,0f,0f,1137.0f,-531.0f,580.0f,-1189.0f,-565.0f,466.0f,-1470,0.103856504f,0.28658694f,0.04533619f,-86.32773f,0f,0f ) ;
  }

  @Test
  public void test738() {
    TestDrivers.surfaceShade(1308.0f,678.0f,813.0f,0f,33.0f,900.0f,0f,258.0f,0f,0f,0f,0f,0f,363.0f,-258.0f,103.0f,-1017.0f,-17.0f,89.0f,-1944,-0.67174774f,0.34372514f,-0.23620506f,-15.286804f,11.49556f,3.22137f ) ;
  }

  @Test
  public void test739() {
    TestDrivers.surfaceShade(-1310.0f,730.0f,480.0f,0f,288.0f,-803.0f,0f,-360.0f,0f,0f,0f,0f,0f,-310.0f,985.0f,-272.0f,0f,0f,0f,-590,16.776701f,16.269405f,39.796272f,-57.601074f,27.582903f,24.079912f ) ;
  }

  @Test
  public void test740() {
    TestDrivers.surfaceShade(-1310.0f,-758.0f,0f,0f,77.0f,-605.0f,0f,-897.0f,0f,0f,0f,0f,0f,-639.0f,354.0f,1021.0f,0f,0f,0f,132,0.3820077f,0.9501707f,-0.09035996f,-18.957876f,-72.505875f,0f ) ;
  }

  @Test
  public void test741() {
    TestDrivers.surfaceShade(132.0f,629.0f,-603.0f,-552.0f,0f,0f,0f,10.31467f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0f,0f,0f,87.708534f,23.641766f,54.574203f ) ;
  }

  @Test
  public void test742() {
    TestDrivers.surfaceShade(-1332.0f,-652.0f,762.0f,502.0f,0f,0f,0f,2.4651903E-32f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,2.1010513f,-29.399641f,2.614215E-6f ) ;
  }

  @Test
  public void test743() {
    TestDrivers.surfaceShade(1338.0f,84.0f,0f,0f,57.0f,-542.0f,0f,251.0f,0f,0f,0f,0f,0f,568.0f,-345.0f,-108.0f,632.0f,-201.0f,436.0f,-838,-23.06693f,-22.727701f,-48.712585f,65.96006f,34.68174f,0f ) ;
  }

  @Test
  public void test744() {
    TestDrivers.surfaceShade(-1341.0f,-371.0f,-661.0f,0f,1.0f,-502.0f,0f,-937.0f,0f,0f,0f,0f,0f,-491.0f,-1525.0f,-1255.0f,0f,0f,0f,1512,100.0f,-100.0f,100.0f,100.0f,-84.45201f,-6.845517E-8f ) ;
  }

  @Test
  public void test745() {
    TestDrivers.surfaceShade(-1350.0f,225.0f,832.0f,0f,726.0f,213.0f,0f,-53.0f,0f,0f,0f,0f,0f,-430.0f,-286.0f,-743.0f,-695.0f,-511.0f,-488.0f,501,-47.85492f,100.0f,-10.797289f,-16.13244f,48.001205f,-80.08705f ) ;
  }

  @Test
  public void test746() {
    TestDrivers.surfaceShade(-136.0f,-222.0f,-229.0f,0f,363.0f,-92.0f,0f,1241.0f,0f,0f,0f,0f,0f,495.0f,-107.0f,-70.0f,-21.0f,823.0f,744.0f,-852,-0.22133543f,-0.5637986f,-0.70335114f,-6.1399503f,-22.890078f,-8.482312f ) ;
  }

  @Test
  public void test747() {
    TestDrivers.surfaceShade(-1363.0f,0f,0f,0f,9.834729E-8f,-50.392483f,0f,-98.57636f,0f,0f,0f,0f,0f,-100.0f,-61.225742f,6.834491f,0f,0f,0f,380,0.21533105f,0.8570478f,-0.08691258f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test748() {
    TestDrivers.surfaceShade(1370.0f,0f,0f,0f,1725.0f,726.0f,0f,-1099.0f,0f,0f,0f,0f,0f,918.0f,-1028.0f,-76.0f,-582.0f,1042.0f,-291.0f,-217,-0.21656226f,0.5827002f,-0.78330153f,6.101488E-10f,0f,0f ) ;
  }

  @Test
  public void test749() {
    TestDrivers.surfaceShade(1370.0f,1730.0f,722.0f,0f,381.0f,1127.0f,0f,859.0f,0f,0f,0f,0f,0f,565.0f,-412.0f,335.0f,-843.0f,254.0f,435.0f,1040,-32.874428f,-86.766335f,-51.26471f,35.914635f,26.86537f,68.150536f ) ;
  }

  @Test
  public void test750() {
    TestDrivers.surfaceShade(137.0f,-364.0f,0f,0f,606.0f,-538.0f,0f,423.0f,0f,0f,0f,0f,0f,-180.0f,-71.0f,-59.0f,412.0f,57.0f,-149.0f,-899,-55.2086f,81.79959f,69.996216f,31.444105f,-86.35f,0f ) ;
  }

  @Test
  public void test751() {
    TestDrivers.surfaceShade(-1375.0f,-659.0f,0f,0f,783.0f,1.0f,0f,-1375.0f,0f,0f,0f,0f,0f,831.0f,-387.0f,-1298.0f,0f,0f,0f,19,5.7719893f,-0.4974956f,3.843647f,-5.22006f,-10.891621f,0f ) ;
  }

  @Test
  public void test752() {
    TestDrivers.surfaceShade(1377.0f,0f,0f,0f,1217.0f,-2084.0f,0f,1134.0f,0f,0f,0f,0f,0f,-26.0f,-184.0f,-15.0f,-848.0f,2385.0f,206.0f,11,1.265286f,-0.250178f,0.875688f,100.0f,0f,0f ) ;
  }

  @Test
  public void test753() {
    TestDrivers.surfaceShade(1390.0f,-1506.0f,-413.0f,226.0f,0f,0f,0f,157.3893f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,4,0f,0f,0f,-53.05112f,84.55194f,17.397219f ) ;
  }

  @Test
  public void test754() {
    TestDrivers.surfaceShade(139.0f,0f,0f,231.0f,0f,0f,0f,-27.823112f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,43.743797f,0f,0f ) ;
  }

  @Test
  public void test755() {
    TestDrivers.surfaceShade(1393.0f,0f,0f,0f,100.0f,-11.092808f,0f,0.0f,0f,0f,0f,0f,0f,-39.180954f,-62.262375f,-40.8037f,0f,0f,0f,1479,-0.28107646f,0.15021199f,0.7306952f,54.24736f,0f,0f ) ;
  }

  @Test
  public void test756() {
    TestDrivers.surfaceShade(1396.0f,-19.0f,54.0f,0f,31.0f,-1149.0f,0f,-495.0f,0f,0f,0f,0f,0f,-917.0f,490.0f,-146.0f,0f,0f,0f,203,0.24014467f,0.45782557f,0.028234875f,-3.1445453f,-3.161438f,1.4058717f ) ;
  }

  @Test
  public void test757() {
    TestDrivers.surfaceShade(-1402.0f,1555.0f,0f,0f,1951.0f,0.0f,0f,-800.0f,0f,0f,0f,0f,0f,-191.0f,-434.0f,63.0f,0f,0f,0f,-278,-25.893984f,16.026165f,31.89849f,-74.71808f,132.78397f,0f ) ;
  }

  @Test
  public void test758() {
    TestDrivers.surfaceShade(1409.0f,-469.0f,0f,0f,445.0f,49.0f,0f,1219.0f,0f,0f,0f,0f,0f,88.0f,-276.0f,-119.0f,-579.0f,-922.0f,-733.0f,-147,38.30333f,-26.483534f,89.749146f,20.083797f,22.229689f,0f ) ;
  }

  @Test
  public void test759() {
    TestDrivers.surfaceShade(-141.0f,0f,0f,0f,897.0f,772.0f,918.0f,-877.0f,0f,0f,0f,0f,0f,399.0f,849.0f,1654.0f,134.0f,-302.0f,769.0f,921,0.19367838f,-0.5279495f,0.19995531f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test760() {
    TestDrivers.surfaceShade(141.0f,118.0f,0f,0f,1167.0f,-245.0f,0f,535.0f,0f,0f,0f,0f,0f,578.0f,-620.0f,-828.0f,-1861.0f,-50.0f,-373.0f,446,-28.380854f,12.168472f,-28.923414f,76.65356f,89.71635f,0f ) ;
  }

  @Test
  public void test761() {
    TestDrivers.surfaceShade(-1414.0f,-521.0f,370.0f,-6.0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-79.959274f,3.1989763E-4f,-4.5045046E-4f ) ;
  }

  @Test
  public void test762() {
    TestDrivers.surfaceShade(-1426.0f,-542.0f,0f,0f,362.0f,415.0f,-328.0f,-161.0f,0f,0f,0f,0f,0f,46.0f,703.0f,-662.0f,-401.0f,488.0f,490.0f,921,-45.44017f,-80.14725f,-83.53384f,56.05937f,-100.0f,0f ) ;
  }

  @Test
  public void test763() {
    TestDrivers.surfaceShade(-1438.0f,-1312.0f,-703.0f,0f,681.0f,-1148.0f,0f,-302.0f,0f,0f,0f,0f,0f,-1503.0f,2076.0f,330.0f,0f,0f,0f,-870,0.34984377f,-0.65808564f,0.07918655f,54.459305f,-35.38881f,19.583776f ) ;
  }

  @Test
  public void test764() {
    TestDrivers.surfaceShade(-144.0f,0f,0f,0f,1105.0f,350.0f,237.0f,249.0f,0f,0f,0f,0f,0f,832.0f,-861.0f,-1926.0f,66.0f,564.0f,-454.0f,-967,-0.25963265f,0.024300043f,-0.09294161f,0.9303158f,0f,0f ) ;
  }

  @Test
  public void test765() {
    TestDrivers.surfaceShade(1445.0f,-210.0f,0f,0f,1291.0f,69.0f,0f,478.0f,0f,0f,0f,0f,0f,-399.0f,608.0f,-571.0f,419.0f,-243.0f,-575.0f,435,-96.75097f,22.713078f,91.79194f,89.79843f,51.05658f,0f ) ;
  }

  @Test
  public void test766() {
    TestDrivers.surfaceShade(1448.0f,-1395.0f,-509.0f,0f,773.0f,1035.0f,-2066.0f,-951.0f,0f,0f,0f,0f,0f,842.0f,-1264.0f,-344.0f,1183.0f,611.0f,-251.0f,537,0.025118869f,0.7811232f,0.3835642f,-88.54725f,92.62203f,99.59442f ) ;
  }

  @Test
  public void test767() {
    TestDrivers.surfaceShade(-1449.0f,54.0f,-646.0f,0f,1195.0f,-672.0f,0f,591.0f,0f,0f,0f,0f,0f,454.0f,639.0f,-542.0f,618.0f,675.0f,-1702.0f,334,-0.72405744f,0.24729002f,0.59130436f,-74.30398f,56.374336f,56.534336f ) ;
  }

  @Test
  public void test768() {
    TestDrivers.surfaceShade(145.0f,-1495.0f,0f,332.0f,0f,0f,0f,61.583557f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-43.49091f,-31.11322f,0f ) ;
  }

  @Test
  public void test769() {
    TestDrivers.surfaceShade(1457.0f,-748.0f,0f,0f,71.0f,2588.0f,0f,-341.0f,0f,0f,0f,0f,0f,-28.0f,-17.0f,-1101.0f,247.0f,-1911.0f,2480.0f,-950,0.9969696f,-0.07410205f,-0.023676554f,-28.807114f,0.0010964314f,0f ) ;
  }

  @Test
  public void test770() {
    TestDrivers.surfaceShade(-1465.0f,-158.0f,449.0f,0f,1075.0f,-1162.0f,0f,1770.0f,0f,0f,0f,0f,0f,-1914.0f,1290.0f,2052.0f,-295.0f,-283.0f,528.0f,-1308,0.508774f,-0.09251615f,-0.78048635f,100.0f,-100.0f,-23.118015f ) ;
  }

  @Test
  public void test771() {
    TestDrivers.surfaceShade(-147.0f,262.0f,0f,0f,531.0f,-692.0f,0f,-205.0f,0f,0f,0f,0f,0f,-795.0f,-287.0f,888.0f,0f,0f,0f,810,-57.343067f,-85.99124f,-79.12976f,-100.0f,33.89263f,0f ) ;
  }

  @Test
  public void test772() {
    TestDrivers.surfaceShade(-1473.0f,710.0f,0f,0f,854.0f,-1082.0f,0f,-1.0f,0f,0f,0f,0f,0f,1207.0f,-610.0f,-593.0f,0f,0f,0f,521,-0.18132065f,-0.46928662f,0.54904646f,-100.0f,-100.0f,0f ) ;
  }

  @Test
  public void test773() {
    TestDrivers.surfaceShade(149.0f,0f,0f,0f,740.0f,1229.0f,0f,432.0f,0f,0f,0f,0f,0f,-326.0f,-270.0f,822.0f,802.0f,393.0f,-664.0f,121,0.5373387f,-0.7277359f,-0.42622492f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test774() {
    TestDrivers.surfaceShade(-1495.0f,38.0f,2014.0f,0f,2279.0f,-267.0f,0f,-2120.0f,0f,0f,0f,0f,0f,-868.0f,-846.0f,270.0f,0f,0f,0f,309,0.78941524f,0.01688611f,0.5711894f,-100.0f,73.62182f,-40.13048f ) ;
  }

  @Test
  public void test775() {
    TestDrivers.surfaceShade(150.0f,13.0f,541.0f,36.0f,0f,0f,0f,-43.38543f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,1.8518518E-4f,0.0021367522f,81.40427f ) ;
  }

  @Test
  public void test776() {
    TestDrivers.surfaceShade(1503.0f,-1291.0f,0f,0f,78.0f,-1099.0f,0f,-373.0f,0f,0f,0f,0f,0f,758.0f,-92.0f,-438.0f,0f,0f,0f,-650,0.6317937f,-0.69842833f,1.24008f,79.47651f,-61.15982f,0f ) ;
  }

  @Test
  public void test777() {
    TestDrivers.surfaceShade(15.0f,547.0f,0f,42.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0.0015873016f,-35.50701f,0f ) ;
  }

  @Test
  public void test778() {
    TestDrivers.surfaceShade(151.0f,164.0f,0f,0f,624.0f,825.0f,0f,-1047.0f,0f,0f,0f,0f,0f,-142.0f,-433.0f,840.0f,220.0f,-400.0f,-107.0f,916,12.689403f,71.322174f,38.909992f,-21.485397f,5.9470778f,0f ) ;
  }

  @Test
  public void test779() {
    TestDrivers.surfaceShade(-153.0f,612.0f,0f,610.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,77.19548f,2.678667E-6f,0f ) ;
  }

  @Test
  public void test780() {
    TestDrivers.surfaceShade(-153.0f,746.0f,1186.0f,0f,159.0f,0.0f,0f,-483.0f,0f,0f,0f,0f,0f,-309.0f,-506.0f,1005.0f,0f,0f,0f,-804,-100.0f,136.84663f,-83.03385f,-50.29663f,-37.319363f,-60.17894f ) ;
  }

  @Test
  public void test781() {
    TestDrivers.surfaceShade(-1549.0f,1676.0f,-628.0f,0f,195.0f,23.0f,0f,954.0f,0f,0f,0f,0f,0f,24.0f,-29.0f,164.0f,-914.0f,25.0f,64.0f,-1812,79.84322f,91.53559f,4.501797f,-40.22809f,37.179817f,39.86294f ) ;
  }

  @Test
  public void test782() {
    TestDrivers.surfaceShade(-1554.0f,0f,0f,0f,60.131115f,0.0f,0f,-40.133183f,0f,0f,0f,0f,0f,25.579214f,-30.044117f,-64.95846f,0f,0f,0f,1554,0.35028145f,0.43254456f,-0.06212425f,99.164085f,0f,0f ) ;
  }

  @Test
  public void test783() {
    TestDrivers.surfaceShade(-1566.0f,534.0f,0f,0f,36.0f,-417.0f,0f,-1.0f,0f,0f,0f,0f,0f,158.0f,-1188.0f,-812.0f,0f,0f,0f,848,-4.307014f,-42.273354f,61.010143f,-1.089761f,0.81919265f,0f ) ;
  }

  @Test
  public void test784() {
    TestDrivers.surfaceShade(-157.0f,1204.0f,0f,0f,72.0f,-162.0f,0f,-1515.0f,0f,0f,0f,0f,0f,-81.0f,-33.0f,-742.0f,0f,0f,0f,-331,160.28809f,-41.42794f,-8.53743f,-68.85686f,-3.4192898f,0f ) ;
  }

  @Test
  public void test785() {
    TestDrivers.surfaceShade(157.0f,14.0f,829.0f,0f,1599.0f,516.0f,-410.0f,-39.0f,0f,0f,0f,0f,0f,646.0f,-310.0f,-317.0f,-180.0f,-755.0f,109.0f,-809,-0.35883683f,-0.14111753f,-0.5172238f,56.472652f,77.85767f,73.508865f ) ;
  }

  @Test
  public void test786() {
    TestDrivers.surfaceShade(1578.0f,117.0f,0f,0f,370.0f,-2.0f,0f,-350.0f,0f,0f,0f,0f,0f,37.0f,241.0f,1197.0f,0f,0f,0f,-1258,0.6847569f,0.14607038f,-0.25960907f,-4.184668f,31.603247f,0f ) ;
  }

  @Test
  public void test787() {
    TestDrivers.surfaceShade(1579.0f,-104.0f,0f,0f,187.0f,-212.0f,0f,239.0f,0f,0f,0f,0f,0f,497.0f,1391.0f,-167.0f,673.0f,-405.0f,-382.0f,896,-36.305336f,-20.155361f,-88.1713f,8.240467f,-85.11051f,0f ) ;
  }

  @Test
  public void test788() {
    TestDrivers.surfaceShade(-158.0f,-744.0f,-656.0f,0f,642.0f,955.0f,0f,-1388.0f,0f,0f,0f,0f,0f,-699.0f,597.0f,782.0f,-1108.0f,653.0f,-684.0f,968,21.068466f,-49.61962f,56.713264f,-53.564148f,77.76721f,-100.0f ) ;
  }

  @Test
  public void test789() {
    TestDrivers.surfaceShade(1589.0f,0f,0f,0f,1.1566104f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,3.8915555f,-4.407715f,-39.38517f,0f,0f,0f,-523,-0.24979362f,0.18816285f,0.12979864f,47.499653f,0f,0f ) ;
  }

  @Test
  public void test790() {
    TestDrivers.surfaceShade(1601.0f,-1011.0f,-220.0f,0f,497.0f,-1478.0f,0f,-1301.0f,0f,0f,0f,0f,0f,151.0f,-63.0f,-1150.0f,0f,0f,0f,764,-0.7694407f,-0.3228776f,0.1334063f,100.0f,71.924614f,-11.986964f ) ;
  }

  @Test
  public void test791() {
    TestDrivers.surfaceShade(1604.0f,1117.0f,0f,0f,1946.0f,-651.0f,0f,-423.0f,0f,0f,0f,0f,0f,16.0f,-182.0f,-485.0f,0f,0f,0f,577,-0.2934367f,0.61968124f,-0.24222057f,24.71861f,14.317142f,0f ) ;
  }

  @Test
  public void test792() {
    TestDrivers.surfaceShade(1607.0f,206.0f,0f,0f,50.0f,-129.0f,0f,-3.0f,0f,0f,0f,0f,0f,195.0f,366.0f,439.0f,0f,0f,0f,-211,0.7996548f,-0.4348379f,0.0073302775f,86.80436f,66.99509f,0f ) ;
  }

  @Test
  public void test793() {
    TestDrivers.surfaceShade(16.0f,0f,0f,0f,100.0f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,34.151615f,-51.03214f,68.82084f,0f,0f,0f,450,-100.0f,24.90192f,6.3917685f,21.652733f,0f,0f ) ;
  }

  @Test
  public void test794() {
    TestDrivers.surfaceShade(16.0f,679.0f,-869.0f,0f,1065.0f,585.0f,0f,988.0f,0f,0f,0f,0f,0f,-194.0f,884.0f,-743.0f,827.0f,-670.0f,-56.0f,-129,-26.518213f,65.76728f,85.17202f,81.39844f,-100.0f,-46.339603f ) ;
  }

  @Test
  public void test795() {
    TestDrivers.surfaceShade(-1618.0f,0f,0f,0f,92.0f,257.0f,0f,-906.0f,0f,0f,0f,0f,0f,693.0f,-1476.0f,782.0f,-609.0f,321.0f,-833.0f,-133,0.51926845f,0.63520473f,0.24904098f,100.0f,0f,0f ) ;
  }

  @Test
  public void test796() {
    TestDrivers.surfaceShade(-164.0f,615.0f,0f,632.0f,0f,0f,0f,-27.063934f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,57.09123f,2.5728104E-6f,0f ) ;
  }

  @Test
  public void test797() {
    TestDrivers.surfaceShade(-1665.0f,0f,-442.0f,0f,2983.0f,-467.0f,0f,0.0f,0f,0f,0f,0f,0f,-1306.0f,1044.0f,81.0f,0f,0f,0f,107,0.06160971f,0.017565252f,-0.9053248f,-60.43893f,0f,-3.8937821f ) ;
  }

  @Test
  public void test798() {
    TestDrivers.surfaceShade(-168.0f,0f,0f,0f,7.3327146E-6f,0.0f,0f,-3.801647E-21f,0f,0f,0f,0f,0f,38.56615f,20.815163f,-100.0f,0f,0f,0f,-691,-0.17690527f,0.48329574f,0.3889473f,-22.765446f,0f,0f ) ;
  }

  @Test
  public void test799() {
    TestDrivers.surfaceShade(1688.0f,585.0f,520.0f,0f,3.0f,-1470.0f,0f,-123.0f,0f,0f,0f,0f,0f,-336.0f,-228.0f,-618.0f,0f,0f,0f,-403,-0.6473168f,-0.27233502f,0.45241237f,66.54137f,79.68556f,67.2501f ) ;
  }

  @Test
  public void test800() {
    TestDrivers.surfaceShade(-169.0f,0f,0f,0f,134.0f,-152.0f,399.0f,-928.0f,0f,0f,0f,0f,0f,672.0f,694.0f,-470.0f,167.0f,-127.0f,-521.0f,-796,-46.59166f,86.01191f,-81.486755f,51.551693f,0f,0f ) ;
  }

  @Test
  public void test801() {
    TestDrivers.surfaceShade(1692.0f,-1340.0f,1717.0f,0f,539.0f,-1841.0f,0f,897.0f,0f,0f,0f,0f,0f,-1293.0f,-610.0f,-187.0f,1364.0f,-932.0f,-434.0f,1371,-0.11548749f,0.105673f,0.45382243f,138.3135f,-100.0f,100.0f ) ;
  }

  @Test
  public void test802() {
    TestDrivers.surfaceShade(-1692.0f,1751.0f,0f,0f,1119.0f,1151.0f,0f,-659.0f,0f,0f,0f,0f,0f,-239.0f,337.0f,-1036.0f,362.0f,-913.0f,36.0f,-1065,-0.095829785f,0.38902304f,0.41118813f,15.991997f,-100.0f,0f ) ;
  }

  @Test
  public void test803() {
    TestDrivers.surfaceShade(-1693.0f,1593.0f,0f,762.0f,0f,0f,0f,-80.28202f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,9.646623f,-33.943604f,0f ) ;
  }

  @Test
  public void test804() {
    TestDrivers.surfaceShade(-1696.0f,632.0f,-230.0f,0f,314.0f,1738.0f,0f,-266.0f,0f,0f,0f,0f,0f,-52.0f,-186.0f,-354.0f,551.0f,-590.0f,-156.0f,-131,-70.92378f,-4.7367616f,12.90699f,-100.0f,21.163788f,-58.15441f ) ;
  }

  @Test
  public void test805() {
    TestDrivers.surfaceShade(170.0f,458.0f,1751.0f,0f,256.0f,1311.0f,0f,617.0f,0f,0f,0f,0f,0f,-560.0f,-574.0f,342.0f,-1371.0f,-905.0f,194.0f,611,89.26963f,-100.0f,-21.663769f,-99.38777f,2.5108943f,-95.30608f ) ;
  }

  @Test
  public void test806() {
    TestDrivers.surfaceShade(1705.0f,-602.0f,0f,0f,457.0f,-1480.0f,0f,-690.0f,0f,0f,0f,0f,0f,-433.0f,1164.0f,-303.0f,0f,0f,0f,-1574,-0.07833662f,-0.92987233f,0.14590959f,-100.0f,5.7416053f,0f ) ;
  }

  @Test
  public void test807() {
    TestDrivers.surfaceShade(-17.0f,-5.0f,0f,0f,409.0f,-432.0f,0f,508.0f,0f,0f,0f,0f,0f,-222.0f,-736.0f,50.0f,-325.0f,99.0f,1014.0f,-1175,32.18494f,-7.094519f,38.469822f,100.0f,27.134521f,0f ) ;
  }

  @Test
  public void test808() {
    TestDrivers.surfaceShade(-175.0f,1870.0f,-378.0f,15.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-3.8095238E-4f,66.38831f,-5.848663f ) ;
  }

  @Test
  public void test809() {
    TestDrivers.surfaceShade(175.0f,205.0f,-2036.0f,1006.0f,0f,0f,0f,-48.81485f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,19.675268f,4.848955E-6f,-78.45595f ) ;
  }

  @Test
  public void test810() {
    TestDrivers.surfaceShade(-1753.0f,697.0f,-910.0f,124.0f,0f,0f,0f,67.12674f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,-99.51184f,-24.102476f,-15.702595f ) ;
  }

  @Test
  public void test811() {
    TestDrivers.surfaceShade(1780.0f,280.0f,-552.0f,0f,182.0f,1093.0f,0f,281.0f,0f,0f,0f,0f,0f,-134.0f,911.0f,180.0f,2093.0f,1031.0f,-549.0f,-748,-53.90532f,0.92407024f,-44.80634f,41.608444f,83.03722f,12.612508f ) ;
  }

  @Test
  public void test812() {
    TestDrivers.surfaceShade(178.0f,0f,0f,0f,928.0f,-225.0f,345.0f,-938.0f,0f,0f,0f,0f,0f,977.0f,-829.0f,-755.0f,191.0f,974.0f,-268.0f,495,-74.16571f,82.3157f,85.15743f,27.940695f,0f,0f ) ;
  }

  @Test
  public void test813() {
    TestDrivers.surfaceShade(1788.0f,1033.0f,-238.0f,0f,808.0f,-733.0f,0f,-446.0f,0f,0f,0f,0f,0f,-1662.0f,-273.0f,-1402.0f,0f,0f,0f,-1539,0.065758064f,-1.6691924f,0.24707535f,29.559727f,-100.0f,-100.0f ) ;
  }

  @Test
  public void test814() {
    TestDrivers.surfaceShade(-18.0f,748.0f,0f,0f,231.0f,-1001.0f,0f,-681.0f,0f,0f,0f,0f,0f,-1409.0f,1553.0f,-764.0f,0f,0f,0f,759,0.37931406f,-0.4748063f,-0.60228235f,-39.52324f,4.2947135f,0f ) ;
  }

  @Test
  public void test815() {
    TestDrivers.surfaceShade(-1821.0f,-2094.0f,0f,0f,1398.0f,2.0f,0f,3.0f,0f,0f,0f,0f,0f,693.0f,-1001.0f,-244.0f,0f,0f,0f,292,-203.18445f,100.0f,-247.78438f,55.55643f,174.88438f,0f ) ;
  }

  @Test
  public void test816() {
    TestDrivers.surfaceShade(-1829.0f,884.0f,-543.0f,0f,400.0f,1314.0f,0f,673.0f,0f,0f,0f,0f,0f,-1327.0f,265.0f,1391.0f,-182.0f,841.0f,865.0f,-247,-99.81675f,8.614729f,-96.86537f,50.40986f,100.0f,16.662182f ) ;
  }

  @Test
  public void test817() {
    TestDrivers.surfaceShade(-183.0f,-622.0f,0f,0f,694.0f,691.0f,0f,-852.0f,0f,0f,0f,0f,0f,-2.0f,-745.0f,-197.0f,-784.0f,941.0f,-157.0f,-72,100.0f,100.0f,-100.0f,100.0f,-77.27102f,0f ) ;
  }

  @Test
  public void test818() {
    TestDrivers.surfaceShade(-1835.0f,770.0f,-1544.0f,0f,1530.0f,508.0f,0f,229.0f,0f,0f,0f,0f,0f,694.0f,-66.0f,30.0f,1586.0f,-1105.0f,-1355.0f,-408,-9.481601f,-60.724087f,85.74804f,-44.814457f,-88.11729f,-43.498882f ) ;
  }

  @Test
  public void test819() {
    TestDrivers.surfaceShade(1857.0f,-521.0f,0f,0f,184.0f,1.0f,0f,5.0f,0f,0f,0f,0f,0f,-1115.0f,-774.0f,954.0f,0f,0f,0f,607,0.51346374f,-0.083719686f,0.53219396f,20.020037f,-37.996544f,0f ) ;
  }

  @Test
  public void test820() {
    TestDrivers.surfaceShade(-1919.0f,0f,0f,0f,4.31021f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,10.114838f,0.40850237f,86.33264f,0f,0f,0f,-456,-0.5664436f,0.014927335f,0.06375056f,2.2531576f,0f,0f ) ;
  }

  @Test
  public void test821() {
    TestDrivers.surfaceShade(-193.0f,0f,0f,1468.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-3.529528E-6f,0f,0f ) ;
  }

  @Test
  public void test822() {
    TestDrivers.surfaceShade(193.0f,773.0f,0f,0f,43.0f,935.0f,790.0f,122.0f,0f,0f,0f,0f,0f,579.0f,-148.0f,296.0f,-872.0f,471.0f,330.0f,-47,-50.555496f,-82.94845f,-49.178234f,-29.01707f,2.0826921f,0f ) ;
  }

  @Test
  public void test823() {
    TestDrivers.surfaceShade(194.0f,597.0f,-80.0f,0f,45.0f,37.0f,0f,-294.0f,0f,0f,0f,0f,0f,597.0f,-116.0f,-621.0f,654.0f,-791.0f,-706.0f,-710,55.267166f,80.181046f,38.153778f,35.24426f,100.0f,-85.467354f ) ;
  }

  @Test
  public void test824() {
    TestDrivers.surfaceShade(-194.0f,68.0f,1106.0f,0f,943.0f,-901.0f,0f,195.0f,0f,0f,0f,0f,0f,-808.0f,1290.0f,599.0f,1670.0f,375.0f,557.0f,-141,38.35361f,65.94112f,-90.27432f,58.407394f,16.6048f,-76.29512f ) ;
  }

  @Test
  public void test825() {
    TestDrivers.surfaceShade(197.0f,0f,0f,0f,585.0f,-2288.0f,0f,489.0f,0f,0f,0f,0f,0f,-52.0f,1108.0f,1151.0f,841.0f,-997.0f,111.0f,1789,-0.16831097f,0.51140004f,-0.8426989f,-13.302853f,0f,0f ) ;
  }

  @Test
  public void test826() {
    TestDrivers.surfaceShade(198.0f,-43.0f,-570.0f,0f,998.0f,-2087.0f,0f,1319.0f,0f,0f,0f,0f,0f,-1937.0f,-2427.0f,776.0f,1414.0f,251.0f,1508.0f,-745,0.07753659f,0.52090967f,1.822727f,100.0f,100.0f,-14.02612f ) ;
  }

  @Test
  public void test827() {
    TestDrivers.surfaceShade(-200.0f,-310.0f,81.0f,0f,31.0f,447.0f,0f,-616.0f,0f,0f,0f,0f,0f,738.0f,-283.0f,-944.0f,261.0f,824.0f,735.0f,-775,20.428448f,-44.45148f,29.296572f,-4.689877f,-27.661263f,-39.39289f ) ;
  }

  @Test
  public void test828() {
    TestDrivers.surfaceShade(-200.0f,371.0f,706.0f,-75.0f,0f,0f,0f,51.67467f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-6.8821383f,-3.5938905E-5f,51.512497f ) ;
  }

  @Test
  public void test829() {
    TestDrivers.surfaceShade(201.0f,0f,0f,0f,-921.0f,-758.0f,383.0f,-391.0f,0f,0f,0f,0f,0f,-338.0f,303.0f,-754.0f,105.0f,-435.0f,-847.0f,-361,-25.568287f,64.801994f,-97.64795f,57.67737f,0f,0f ) ;
  }

  @Test
  public void test830() {
    TestDrivers.surfaceShade(-2015.0f,17.0f,0f,0f,2007.0f,1047.0f,0f,-1079.0f,0f,0f,0f,0f,0f,744.0f,-775.0f,3627.0f,1050.0f,-856.0f,-1961.0f,1047,0.05435299f,-0.3793686f,-0.92364776f,-6.7915635f,-100.0f,0f ) ;
  }

  @Test
  public void test831() {
    TestDrivers.surfaceShade(-2052.0f,672.0f,-1188.0f,0f,24.0f,276.0f,0f,-123.0f,0f,0f,0f,0f,0f,-404.0f,-556.0f,-600.0f,-275.0f,954.0f,-859.0f,934,28.402737f,-10.195377f,-9.676792f,-30.155123f,75.188805f,-81.73908f ) ;
  }

  @Test
  public void test832() {
    TestDrivers.surfaceShade(-207.0f,-114.0f,-1031.0f,0f,104.0f,503.0f,0f,-404.0f,0f,0f,0f,0f,0f,-529.0f,896.0f,557.0f,-783.0f,-247.0f,964.0f,305,39.53903f,5.9435415f,27.990541f,54.37187f,-38.42639f,-0.6295313f ) ;
  }

  @Test
  public void test833() {
    TestDrivers.surfaceShade(-207.0f,2140.0f,-13.0f,56.0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,-10.504538f,2.55833E-5f,-0.0013736264f ) ;
  }

  @Test
  public void test834() {
    TestDrivers.surfaceShade(-207.0f,-92.0f,0f,0f,816.0f,149.0f,0f,568.0f,0f,0f,0f,0f,0f,-282.0f,-779.0f,416.0f,-1756.0f,743.0f,928.0f,278,34.27939f,2.0363858f,27.050798f,38.713043f,-10.722594f,0f ) ;
  }

  @Test
  public void test835() {
    TestDrivers.surfaceShade(-2076.0f,2019.0f,-1089.0f,0f,870.0f,942.0f,0f,783.0f,0f,0f,0f,0f,0f,-904.0f,735.0f,176.0f,1062.0f,-711.0f,552.0f,-623,43.872295f,57.921577f,-16.544338f,-24.789518f,13.347331f,-15.003609f ) ;
  }

  @Test
  public void test836() {
    TestDrivers.surfaceShade(208.0f,-309.0f,-1453.0f,-145.0f,0f,0f,0f,-24.287374f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-3,0f,0f,0f,53.460243f,-100.0f,4.7464223E-6f ) ;
  }

  @Test
  public void test837() {
    TestDrivers.surfaceShade(-208.0f,-898.0f,-183.0f,20.0f,0f,0f,0f,17.360931f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-2.4038462E-4f,27.477201f,110.031166f ) ;
  }

  @Test
  public void test838() {
    TestDrivers.surfaceShade(-2.0f,0f,0f,0f,45.0f,-999.0f,0f,1595.0f,0f,0f,0f,0f,0f,-280.0f,513.0f,768.0f,1866.0f,1240.0f,-3215.0f,-36,-1.2902025f,-8.575026f,5.2441235f,-0.0010845859f,0f,0f ) ;
  }

  @Test
  public void test839() {
    TestDrivers.surfaceShade(2.0f,1443.0f,0f,0f,35.0f,0.0f,0f,-2.0f,0f,0f,0f,0f,0f,959.0f,-254.0f,-987.0f,0f,0f,0f,666,100.0f,-10.704167f,100.0f,1.760592E-4f,-100.0f,0f ) ;
  }

  @Test
  public void test840() {
    TestDrivers.surfaceShade(2116.0f,-2614.0f,0f,0f,420.0f,0.0f,0f,-335.0f,0f,0f,0f,0f,0f,191.0f,140.0f,699.0f,0f,0f,0f,795,-0.552914f,-0.9339083f,0.33813122f,47.759922f,-20.075546f,0f ) ;
  }

  @Test
  public void test841() {
    TestDrivers.surfaceShade(-212.0f,-534.0f,755.0f,517.0f,0f,0f,0f,-1.5056231E-14f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-9.123754E-6f,32.039383f,41.9083f ) ;
  }

  @Test
  public void test842() {
    TestDrivers.surfaceShade(216.0f,508.0f,0f,0f,616.0f,648.0f,0f,-798.0f,0f,0f,0f,0f,0f,46.0f,1152.0f,500.0f,226.0f,-282.0f,-159.0f,-1579,-83.930855f,16.461098f,-88.36123f,95.5106f,58.18656f,0f ) ;
  }

  @Test
  public void test843() {
    TestDrivers.surfaceShade(2185.0f,1063.0f,35.0f,105.0f,0f,0f,0f,-49.675182f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,-168.40373f,38.835056f,2.7210885E-4f ) ;
  }

  @Test
  public void test844() {
    TestDrivers.surfaceShade(-219.0f,-358.0f,225.0f,0f,48.0f,-546.0f,0f,1331.0f,0f,0f,0f,0f,0f,4.0f,-999.0f,396.0f,31.0f,-7.0f,412.0f,-727,-69.45196f,13.20816f,34.02212f,96.27432f,75.752426f,67.92051f ) ;
  }

  @Test
  public void test845() {
    TestDrivers.surfaceShade(22.0f,727.0f,1230.0f,0f,1399.0f,-976.0f,0f,613.0f,0f,0f,0f,0f,0f,-185.0f,427.0f,-405.0f,695.0f,-394.0f,-678.0f,-812,49.909634f,-1.7991095f,-24.695066f,13.353826f,37.99574f,60.37055f ) ;
  }

  @Test
  public void test846() {
    TestDrivers.surfaceShade(-224.0f,0f,107.0f,0f,2562.0f,-1024.0f,0f,0.0f,0f,0f,0f,0f,0f,-76.0f,22.0f,-179.0f,0f,0f,0f,-2700,0.3863277f,-0.15315853f,-0.18285136f,-100.0f,0f,45.721767f ) ;
  }

  @Test
  public void test847() {
    TestDrivers.surfaceShade(-2241.0f,2307.0f,68.0f,0f,69.0f,-70.0f,0f,39.0f,0f,0f,0f,0f,0f,-572.0f,-906.0f,225.0f,-522.0f,-948.0f,1141.0f,17,2.0448256f,-0.39470983f,1.9955345f,100.0f,10.247032f,-2.3766556E-6f ) ;
  }

  @Test
  public void test848() {
    TestDrivers.surfaceShade(2253.0f,-193.0f,0f,0f,1558.0f,1262.0f,0f,365.0f,0f,0f,0f,0f,0f,-162.0f,-233.0f,-890.0f,-670.0f,-1376.0f,-443.0f,1367,-28.76784f,15.797708f,1.1005892f,-100.0f,32.334526f,0f ) ;
  }

  @Test
  public void test849() {
    TestDrivers.surfaceShade(226.0f,1057.0f,-223.0f,0f,68.0f,-1024.0f,0f,280.0f,0f,0f,0f,0f,0f,-401.0f,711.0f,536.0f,-315.0f,-577.0f,1000.0f,-509,-2.7059f,65.308495f,-184.33455f,42.54504f,-28.196178f,22.183298f ) ;
  }

  @Test
  public void test850() {
    TestDrivers.surfaceShade(2300.0f,0f,0f,0f,2242.0f,-1235.0f,0f,639.0f,0f,0f,0f,0f,0f,638.0f,-2034.0f,-1994.0f,75.0f,916.0f,1413.0f,2435,-0.12859741f,0.4983731f,0.85737216f,100.0f,0f,0f ) ;
  }

  @Test
  public void test851() {
    TestDrivers.surfaceShade(230.0f,-252.0f,0f,0f,516.0f,583.0f,0f,77.0f,0f,0f,0f,0f,0f,-1140.0f,967.0f,250.0f,1754.0f,426.0f,324.0f,-321,-0.006037166f,-0.15256594f,-0.9882749f,-100.0f,-100.0f,0f ) ;
  }

  @Test
  public void test852() {
    TestDrivers.surfaceShade(230.0f,-350.0f,876.0f,0f,770.0f,-2605.0f,0f,496.0f,0f,0f,0f,0f,0f,762.0f,1834.0f,-1160.0f,-281.0f,-1387.0f,-629.0f,-1197,-0.2947021f,0.40051523f,0.4772742f,-2.3542457f,3.9065402f,100.0f ) ;
  }

  @Test
  public void test853() {
    TestDrivers.surfaceShade(23.0f,618.0f,227.0f,0f,785.0f,-398.0f,0f,441.0f,0f,0f,0f,0f,0f,185.0f,242.0f,-911.0f,219.0f,922.0f,-822.0f,-4,81.921906f,18.371984f,42.59944f,-2.1033912E-9f,8.728177f,74.44748f ) ;
  }

  @Test
  public void test854() {
    TestDrivers.surfaceShade(-231.0f,888.0f,793.0f,0f,342.0f,-342.0f,0f,207.0f,0f,0f,0f,0f,0f,1694.0f,974.0f,-1634.0f,724.0f,736.0f,-509.0f,1245,-0.3917753f,-0.5689915f,-0.05078457f,-38.477703f,73.79776f,39.798874f ) ;
  }

  @Test
  public void test855() {
    TestDrivers.surfaceShade(-232.0f,0f,-1052.0f,0f,574.0f,-19.0f,0f,3.0f,0f,0f,0f,0f,0f,-405.0f,1737.0f,427.0f,0f,0f,0f,-184,0.42796823f,-0.37093228f,-0.70041656f,-47.865383f,0f,60.36792f ) ;
  }

  @Test
  public void test856() {
    TestDrivers.surfaceShade(-2329.0f,-383.0f,-26.0f,3.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,79.14346f,-8.70322E-4f,-0.012820513f ) ;
  }

  @Test
  public void test857() {
    TestDrivers.surfaceShade(-2341.0f,121.0f,0f,0f,3.0f,1729.0f,0f,2728.0f,0f,0f,0f,0f,0f,-38.0f,-51.0f,173.0f,258.0f,616.0f,-1245.0f,1220,0.29653552f,-0.051908966f,0.04983184f,-68.826904f,32.14724f,0f ) ;
  }

  @Test
  public void test858() {
    TestDrivers.surfaceShade(-2354.0f,2280.0f,409.0f,0f,306.0f,1603.0f,0f,1630.0f,0f,0f,0f,0f,0f,-351.0f,-89.0f,159.0f,244.0f,709.0f,-981.0f,847,30.350418f,58.89351f,99.96553f,-40.878754f,56.335464f,99.99783f ) ;
  }

  @Test
  public void test859() {
    TestDrivers.surfaceShade(-2385.0f,271.0f,18.0f,-479.0f,0f,0f,0f,47.029945f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,8.753386E-7f,-49.255146f,-1.1598237E-4f ) ;
  }

  @Test
  public void test860() {
    TestDrivers.surfaceShade(-239.0f,334.0f,545.0f,0f,456.0f,1008.0f,0f,-406.0f,0f,0f,0f,0f,0f,-440.0f,881.0f,202.0f,-1193.0f,-1013.0f,1173.0f,-782,0.37827346f,0.22326107f,-0.14976577f,91.15733f,47.1773f,49.210033f ) ;
  }

  @Test
  public void test861() {
    TestDrivers.surfaceShade(24.0f,-441.0f,0f,107.0f,0f,0f,0f,-51.4897f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,3.894081E-4f,92.61692f,0f ) ;
  }

  @Test
  public void test862() {
    TestDrivers.surfaceShade(-24.0f,838.0f,0f,77.0f,0f,0f,0f,62.317806f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,97.756485f,-30.01169f,0f ) ;
  }

  @Test
  public void test863() {
    TestDrivers.surfaceShade(-2428.0f,1471.0f,2314.0f,0f,2121.0f,447.0f,0f,317.0f,0f,0f,0f,0f,0f,-912.0f,-357.0f,110.0f,16.0f,1549.0f,-575.0f,2400,3.7871966f,18.857971f,92.60199f,-90.38146f,100.0f,88.795265f ) ;
  }

  @Test
  public void test864() {
    TestDrivers.surfaceShade(-2437.0f,-1146.0f,984.0f,0f,116.0f,-811.0f,0f,521.0f,0f,0f,0f,0f,0f,-15.0f,779.0f,-368.0f,-764.0f,-84.0f,471.0f,773,-0.2763728f,-0.064269535f,0.08772601f,6.0702333f,-47.852135f,54.080795f ) ;
  }

  @Test
  public void test865() {
    TestDrivers.surfaceShade(-246.0f,271.0f,-687.0f,0f,788.0f,725.0f,0f,-316.0f,0f,0f,0f,0f,0f,508.0f,-139.0f,-971.0f,-506.0f,-709.0f,-1069.0f,577,100.0f,58.088654f,44.001728f,-5.386562f,132.43181f,-52.72479f ) ;
  }

  @Test
  public void test866() {
    TestDrivers.surfaceShade(-2494.0f,511.0f,-941.0f,0f,587.0f,-648.0f,0f,50.0f,0f,0f,0f,0f,0f,-1186.0f,1537.0f,-745.0f,322.0f,-1055.0f,-31.0f,-1415,0.29750228f,-0.53158396f,0.63538307f,-2.4660292f,59.936928f,-51.552555f ) ;
  }

  @Test
  public void test867() {
    TestDrivers.surfaceShade(-25.0f,-337.0f,0f,0f,915.0f,254.0f,0f,298.0f,0f,0f,0f,0f,0f,280.0f,945.0f,-636.0f,-119.0f,-251.0f,-234.0f,337,-13.3149805f,-73.18037f,-19.503376f,46.882523f,-5.259231f,0f ) ;
  }

  @Test
  public void test868() {
    TestDrivers.surfaceShade(-251.0f,0f,0f,0f,53.04637f,0.0f,0f,-57.60084f,0f,0f,0f,0f,0f,3.636344f,-72.10315f,63.14334f,0f,0f,0f,-499,-0.077285096f,0.32607493f,0.19594228f,-18.52127f,0f,0f ) ;
  }

  @Test
  public void test869() {
    TestDrivers.surfaceShade(-251.0f,-181.0f,-1808.0f,0f,600.0f,-1128.0f,0f,265.0f,0f,0f,0f,0f,0f,61.0f,429.0f,-155.0f,-661.0f,697.0f,-741.0f,955,-0.13029225f,-0.2155198f,-0.3857597f,43.178017f,30.520485f,-61.663483f ) ;
  }

  @Test
  public void test870() {
    TestDrivers.surfaceShade(-251.0f,643.0f,614.0f,-1010.0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,3.9446177E-6f,-1.5398118E-6f,13.197134f ) ;
  }

  @Test
  public void test871() {
    TestDrivers.surfaceShade(253.0f,-741.0f,729.0f,0f,108.0f,-563.0f,0f,-400.0f,0f,0f,0f,0f,0f,288.0f,-124.0f,-115.0f,0f,0f,0f,-713,35.421803f,55.875713f,28.45992f,100.0f,-24.949722f,-100.0f ) ;
  }

  @Test
  public void test872() {
    TestDrivers.surfaceShade(254.0f,-531.0f,0f,0f,18.0f,-875.0f,0f,515.0f,0f,0f,0f,0f,0f,-443.0f,1134.0f,-920.0f,-273.0f,-709.0f,298.0f,110,-0.4113491f,-0.7371111f,-0.25774515f,100.0f,22.735598f,0f ) ;
  }

  @Test
  public void test873() {
    TestDrivers.surfaceShade(255.0f,-1485.0f,878.0f,0f,812.0f,338.0f,0f,-1085.0f,0f,0f,0f,0f,0f,-320.0f,-235.0f,683.0f,810.0f,-476.0f,901.0f,-1914,-42.59045f,11.444724f,-16.01674f,-77.57217f,-100.0f,100.0f ) ;
  }

  @Test
  public void test874() {
    TestDrivers.surfaceShade(2559.0f,1488.0f,-213.0f,0f,186.0f,-1976.0f,0f,133.0f,0f,0f,0f,0f,0f,-1170.0f,-877.0f,272.0f,407.0f,906.0f,864.0f,-987,0.7696451f,-0.32140446f,-0.06669085f,-100.0f,-99.99161f,10.594373f ) ;
  }

  @Test
  public void test875() {
    TestDrivers.surfaceShade(-256.0f,-2431.0f,0f,0f,341.0f,-2.0f,0f,-745.0f,0f,0f,0f,0f,0f,85.0f,961.0f,-895.0f,0f,0f,0f,1571,-86.75622f,-25.896515f,-19.698317f,46.379574f,91.85584f,0f ) ;
  }

  @Test
  public void test876() {
    TestDrivers.surfaceShade(259.0f,0f,0f,0f,668.0f,668.0f,-937.0f,1522.0f,0f,0f,0f,0f,0f,-749.0f,-952.0f,-331.0f,-704.0f,528.0f,869.0f,-1160,0.14923155f,-0.46517873f,1.0002288f,74.2732f,0f,0f ) ;
  }

  @Test
  public void test877() {
    TestDrivers.surfaceShade(259.0f,1773.0f,-120.0f,0f,423.0f,584.0f,0f,-1055.0f,0f,0f,0f,0f,0f,-92.0f,-533.0f,-170.0f,-535.0f,744.0f,182.0f,-806,58.174816f,12.114664f,-60.493748f,5.9843295E-9f,-79.582855f,-58.888157f ) ;
  }

  @Test
  public void test878() {
    TestDrivers.surfaceShade(-2618.0f,775.0f,751.0f,0f,1734.0f,710.0f,0f,-1226.0f,0f,0f,0f,0f,0f,-277.0f,-587.0f,1295.0f,-398.0f,-935.0f,-798.0f,-799,-1.5003498f,13.160948f,5.6446943f,-83.54939f,100.0f,92.22172f ) ;
  }

  @Test
  public void test879() {
    TestDrivers.surfaceShade(2640.0f,627.0f,-162.0f,-14.0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,-11.960933f,-1.1392117E-4f,4.409171E-4f ) ;
  }

  @Test
  public void test880() {
    TestDrivers.surfaceShade(265.0f,0f,0f,-22.0f,0f,0f,0f,-17.750858f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-1.7152658E-4f,0f,0f ) ;
  }

  @Test
  public void test881() {
    TestDrivers.surfaceShade(266.0f,-645.0f,784.0f,0f,105.0f,21.0f,0f,550.0f,0f,0f,0f,0f,0f,-1391.0f,476.0f,-1125.0f,970.0f,-780.0f,-143.0f,-1551,0.47783744f,-0.7568941f,-0.29770467f,-96.39675f,-100.0f,-11.627534f ) ;
  }

  @Test
  public void test882() {
    TestDrivers.surfaceShade(2672.0f,390.0f,0f,0f,143.0f,-1415.0f,0f,-1.0f,0f,0f,0f,0f,0f,446.0f,1082.0f,782.0f,0f,0f,0f,-683,-100.0f,-31.053604f,100.0f,-52.520947f,16.540182f,0f ) ;
  }

  @Test
  public void test883() {
    TestDrivers.surfaceShade(-269.0f,172.0f,-554.0f,0f,217.0f,30.0f,0f,856.0f,0f,0f,0f,0f,0f,-812.0f,-1512.0f,624.0f,286.0f,726.0f,69.0f,-169,51.19319f,-43.180206f,-56.806015f,-76.09094f,53.8455f,38.228027f ) ;
  }

  @Test
  public void test884() {
    TestDrivers.surfaceShade(-2696.0f,-54.0f,-1345.0f,0f,281.0f,-517.0f,0f,182.0f,0f,0f,0f,0f,0f,-237.0f,-795.0f,-481.0f,-1455.0f,-561.0f,823.0f,695,-0.19600062f,-0.2982273f,0.8654448f,86.95698f,97.3687f,26.478798f ) ;
  }

  @Test
  public void test885() {
    TestDrivers.surfaceShade(2699.0f,-309.0f,-461.0f,0f,1107.0f,-678.0f,0f,819.0f,0f,0f,0f,0f,0f,-42.0f,94.0f,-114.0f,183.0f,1105.0f,-1467.0f,234,-30.678709f,11.315253f,20.632803f,-10.517417f,8.157952f,-11.978161f ) ;
  }

  @Test
  public void test886() {
    TestDrivers.surfaceShade(270.0f,-614.0f,-18.0f,0f,127.0f,-778.0f,0f,225.0f,0f,0f,0f,0f,0f,843.0f,-457.0f,-197.0f,52.0f,-964.0f,-442.0f,1508,8.082973f,-8.015428f,53.18272f,-94.629005f,-83.53731f,55.070854f ) ;
  }

  @Test
  public void test887() {
    TestDrivers.surfaceShade(-272.0f,995.0f,0f,0f,504.0f,-1728.0f,0f,306.0f,0f,0f,0f,0f,0f,4.0f,-395.0f,748.0f,-189.0f,-451.0f,910.0f,737,-55.793457f,-85.49958f,-60.115078f,1.2779822E-10f,-60.042217f,0f ) ;
  }

  @Test
  public void test888() {
    TestDrivers.surfaceShade(-2724.0f,-480.0f,0f,0f,846.0f,-6.0f,0f,5.0f,0f,0f,0f,0f,0f,-314.0f,565.0f,-48.0f,0f,0f,0f,-723,0.40544707f,-0.660656f,0.3883382f,-98.60615f,-16.32771f,0f ) ;
  }

  @Test
  public void test889() {
    TestDrivers.surfaceShade(273.0f,-687.0f,-1043.0f,0f,25.0f,-454.0f,0f,297.0f,0f,0f,0f,0f,0f,86.0f,56.0f,-11.0f,329.0f,42.0f,442.0f,-193,0.008661129f,-0.0029315138f,0.05279023f,-48.70028f,38.882275f,27.339495f ) ;
  }

  @Test
  public void test890() {
    TestDrivers.surfaceShade(-2735.0f,-2.0f,1.0f,0f,915.0f,3608.0f,0f,427.0f,0f,0f,0f,0f,0f,-251.0f,719.0f,-1360.0f,957.0f,94.0f,-22.0f,-555,-1.6149406f,-1.7954476f,-0.65115935f,-100.0f,135.45227f,47.279327f ) ;
  }

  @Test
  public void test891() {
    TestDrivers.surfaceShade(-276.0f,598.0f,1289.0f,-1.0f,0f,0f,0f,86.48664f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-81.34319f,-4.8704443f,-25.827723f ) ;
  }

  @Test
  public void test892() {
    TestDrivers.surfaceShade(278.0f,-643.0f,0f,0f,49.0f,107.0f,-924.0f,18.0f,0f,0f,0f,0f,0f,-15.0f,20.0f,16.0f,814.0f,810.0f,-578.0f,838,94.712524f,52.59535f,22.532759f,63.49896f,-8.179627f,0f ) ;
  }

  @Test
  public void test893() {
    TestDrivers.surfaceShade(28.0f,-835.0f,-772.0f,0f,687.0f,8.0f,0f,975.0f,0f,0f,0f,0f,0f,-853.0f,370.0f,-681.0f,1571.0f,-833.0f,-311.0f,-923,-30.556435f,-92.408226f,-11.932991f,36.07367f,-70.5689f,-88.379906f ) ;
  }

  @Test
  public void test894() {
    TestDrivers.surfaceShade(282.0f,331.0f,-988.0f,856.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,14.085014f,-30.896372f,-2.4098708E-5f ) ;
  }

  @Test
  public void test895() {
    TestDrivers.surfaceShade(-283.0f,581.0f,-1145.0f,-11.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,3.2123353E-4f,37.27587f,97.917786f ) ;
  }

  @Test
  public void test896() {
    TestDrivers.surfaceShade(2837.0f,-1591.0f,-486.0f,0f,38.0f,-319.0f,0f,196.0f,0f,0f,0f,0f,0f,222.0f,498.0f,134.0f,-1801.0f,-375.0f,-756.0f,548,26.263477f,-29.426888f,65.85148f,-45.604004f,78.24636f,-100.0f ) ;
  }

  @Test
  public void test897() {
    TestDrivers.surfaceShade(-2903.0f,0f,-294.0f,0f,258.0f,2188.0f,0f,-2440.0f,0f,0f,0f,0f,0f,107.0f,2312.0f,573.0f,-760.0f,-3100.0f,649.0f,1844,0.4432393f,0.0998991f,-0.8908193f,-100.0f,0f,-100.0f ) ;
  }

  @Test
  public void test898() {
    TestDrivers.surfaceShade(-29.0f,-191.0f,0f,0f,614.0f,504.0f,575.0f,818.0f,0f,0f,0f,0f,0f,-968.0f,142.0f,-212.0f,-123.0f,-626.0f,687.0f,556,39.14662f,82.08469f,2.3749173f,96.031166f,7.190372f,0f ) ;
  }

  @Test
  public void test899() {
    TestDrivers.surfaceShade(291.0f,-758.0f,695.0f,0f,20.0f,-1056.0f,0f,26.0f,0f,0f,0f,0f,0f,-836.0f,415.0f,858.0f,-730.0f,723.0f,-178.0f,718,-91.25149f,13.72721f,-95.55132f,48.35579f,79.56064f,20.590307f ) ;
  }

  @Test
  public void test900() {
    TestDrivers.surfaceShade(-293.0f,863.0f,51.0f,-206.0f,0f,0f,0f,-100.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,1.6567812E-5f,-5.624993E-6f,-9.518371E-5f ) ;
  }

  @Test
  public void test901() {
    TestDrivers.surfaceShade(296.0f,274.0f,0f,0f,810.0f,-957.0f,0f,-438.0f,0f,0f,0f,0f,0f,-337.0f,539.0f,-399.0f,0f,0f,0f,361,-62.73459f,-15.005425f,32.71587f,70.78948f,100.0f,0f ) ;
  }

  @Test
  public void test902() {
    TestDrivers.surfaceShade(-300.0f,0f,0f,0f,1.046801E-7f,-93.73015f,0f,-17.251207f,0f,0f,0f,0f,0f,-76.29644f,80.2975f,-51.58434f,0f,0f,0f,-469,34.783348f,13.087835f,-14.833862f,-38.011105f,0f,0f ) ;
  }

  @Test
  public void test903() {
    TestDrivers.surfaceShade(300.0f,-1247.0f,0f,0f,819.0f,-8.0f,0f,-2.0f,0f,0f,0f,0f,0f,-1306.0f,-382.0f,-1063.0f,0f,0f,0f,151,-0.39393058f,1.0336536f,0.11348947f,-100.0f,-9.758141E-6f,0f ) ;
  }

  @Test
  public void test904() {
    TestDrivers.surfaceShade(-3095.0f,118.0f,597.0f,0f,449.0f,2215.0f,0f,-1449.0f,0f,0f,0f,0f,0f,-97.0f,506.0f,467.0f,156.0f,-1208.0f,-560.0f,31,2.4658654f,1.0773561f,-0.6551461f,-100.0f,18.56018f,100.0f ) ;
  }

  @Test
  public void test905() {
    TestDrivers.surfaceShade(-313.0f,0f,0f,0f,68.0f,1595.0f,0f,-401.0f,0f,0f,0f,0f,0f,-422.0f,-4.0f,-354.0f,-297.0f,-275.0f,746.0f,-513,0.21761242f,0.33083063f,0.013396187f,-9.838401f,0f,0f ) ;
  }

  @Test
  public void test906() {
    TestDrivers.surfaceShade(-316.0f,64.0f,-915.0f,0f,8.0f,-500.0f,0f,-1578.0f,0f,0f,0f,0f,0f,-321.0f,2087.0f,-312.0f,0f,0f,0f,46,-0.64114016f,-0.58037055f,0.49332464f,88.30777f,-3.587241f,-99.99291f ) ;
  }

  @Test
  public void test907() {
    TestDrivers.surfaceShade(-318.0f,251.0f,0f,-132.0f,0f,0f,0f,27.827301f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,92.64101f,-3.0182302E-5f,0f ) ;
  }

  @Test
  public void test908() {
    TestDrivers.surfaceShade(319.0f,534.0f,0f,0f,1115.0f,358.0f,0f,-49.0f,0f,0f,0f,0f,0f,-767.0f,-614.0f,-486.0f,446.0f,357.0f,665.0f,-976,0.69783545f,-0.009578788f,-0.23299816f,36.14499f,60.14877f,0f ) ;
  }

  @Test
  public void test909() {
    TestDrivers.surfaceShade(320.0f,-269.0f,-737.0f,0f,987.0f,-374.0f,0f,996.0f,0f,0f,0f,0f,0f,-408.0f,-89.0f,-904.0f,-667.0f,83.0f,-209.0f,-79,-86.4523f,-79.36345f,66.38082f,-86.35454f,20.476017f,-19.253115f ) ;
  }

  @Test
  public void test910() {
    TestDrivers.surfaceShade(320.0f,463.0f,557.0f,0f,359.0f,949.0f,0f,151.0f,0f,0f,0f,0f,0f,-528.0f,-615.0f,-150.0f,-422.0f,523.0f,297.0f,216,65.812546f,-39.68446f,-23.97953f,74.68593f,-82.29429f,-70.61444f ) ;
  }

  @Test
  public void test911() {
    TestDrivers.surfaceShade(-32.0f,243.0f,0f,0f,645.0f,0.0f,0f,-922.0f,0f,0f,0f,0f,0f,-509.0f,741.0f,-309.0f,0f,0f,0f,387,-29.501625f,-93.23135f,91.263306f,-64.174194f,-33.76663f,0f ) ;
  }

  @Test
  public void test912() {
    TestDrivers.surfaceShade(321.0f,983.0f,-1261.0f,0f,911.0f,344.0f,0f,865.0f,0f,0f,0f,0f,0f,506.0f,593.0f,3.0f,70.0f,-729.0f,-1837.0f,927,38.760197f,-33.17995f,21.01716f,83.30564f,77.40068f,-100.0f ) ;
  }

  @Test
  public void test913() {
    TestDrivers.surfaceShade(-322.0f,0f,0f,0f,77.0f,1208.0f,0f,-731.0f,0f,0f,0f,0f,0f,321.0f,-179.0f,169.0f,-967.0f,2267.0f,677.0f,-1738,-0.19103615f,-0.8329292f,-0.51935935f,7.6992235f,0f,0f ) ;
  }

  @Test
  public void test914() {
    TestDrivers.surfaceShade(3280.0f,485.0f,969.0f,0f,1236.0f,782.0f,0f,-149.0f,0f,0f,0f,0f,0f,-290.0f,-720.0f,927.0f,-2345.0f,1477.0f,481.0f,838,65.35722f,-34.41437f,-6.283443f,-100.0f,18.095066f,100.0f ) ;
  }

  @Test
  public void test915() {
    TestDrivers.surfaceShade(330.0f,-1624.0f,-1401.0f,0f,83.0f,1.0f,0f,-1053.0f,0f,0f,0f,0f,0f,-712.0f,807.0f,-966.0f,0f,0f,0f,-1309,-0.15865865f,-0.6552932f,0.024798881f,-100.0f,87.76748f,100.0f ) ;
  }

  @Test
  public void test916() {
    TestDrivers.surfaceShade(-331.0f,798.0f,1213.0f,0f,11.0f,-269.0f,0f,312.0f,0f,0f,0f,0f,0f,-124.0f,1377.0f,306.0f,-1823.0f,1162.0f,-911.0f,972,32.970436f,-1.9553573f,22.159678f,100.0f,-34.42227f,-26.702034f ) ;
  }

  @Test
  public void test917() {
    TestDrivers.surfaceShade(332.0f,157.0f,0f,-248.0f,0f,0f,0f,1.2789769E-13f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-100.0f,126.500565f,0f ) ;
  }

  @Test
  public void test918() {
    TestDrivers.surfaceShade(336.0f,41.0f,10.0f,-7.0f,0f,0f,0f,92.03471f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,4.6296295E-4f,-8.130081E-4f,-0.0033333334f ) ;
  }

  @Test
  public void test919() {
    TestDrivers.surfaceShade(337.0f,0f,0f,0f,1531.0f,-335.0f,0f,256.0f,0f,0f,0f,0f,0f,-38.0f,607.0f,213.0f,108.0f,640.0f,573.0f,-222,-0.02810256f,-0.6938054f,-0.6854418f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test920() {
    TestDrivers.surfaceShade(338.0f,470.0f,1023.0f,670.0f,0f,0f,0f,-53.471573f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,4.415791E-6f,-9.326575f,-84.739494f ) ;
  }

  @Test
  public void test921() {
    TestDrivers.surfaceShade(339.0f,0f,0f,0f,100.0f,-26.46001f,0f,-71.322586f,0f,0f,0f,0f,0f,-17.691372f,16.181236f,-10.377718f,0f,0f,0f,-2753,0.17905976f,-0.7082232f,-0.48356238f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test922() {
    TestDrivers.surfaceShade(-339.0f,0f,0f,0f,863.0f,-223.0f,474.0f,-158.0f,0f,0f,0f,0f,0f,-124.0f,-162.0f,-712.0f,648.0f,28.0f,-636.0f,-708,58.3226f,-25.499893f,72.26675f,84.62434f,0f,0f ) ;
  }

  @Test
  public void test923() {
    TestDrivers.surfaceShade(339.0f,947.0f,-945.0f,20.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,4,0f,0f,0f,-90.709946f,63.31975f,-5.0016365f ) ;
  }

  @Test
  public void test924() {
    TestDrivers.surfaceShade(-342.0f,-1213.0f,-232.0f,-24.0f,0f,0f,0f,9.024214f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,1.2183236E-4f,-61.76298f,69.51453f ) ;
  }

  @Test
  public void test925() {
    TestDrivers.surfaceShade(-343.0f,0f,0f,0f,251.0f,-1371.0f,0f,117.0f,0f,0f,0f,0f,0f,-702.0f,-748.0f,-118.0f,-1569.0f,-530.0f,-765.0f,-36,0.4051169f,-0.42914417f,0.3102354f,-79.94605f,0f,0f ) ;
  }

  @Test
  public void test926() {
    TestDrivers.surfaceShade(343.0f,-459.0f,505.0f,0f,1007.0f,-700.0f,0f,-645.0f,0f,0f,0f,0f,0f,236.0f,-39.0f,-440.0f,0f,0f,0f,-1133,34.740276f,23.500042f,16.550463f,100.0f,-38.71187f,27.151804f ) ;
  }

  @Test
  public void test927() {
    TestDrivers.surfaceShade(-344.0f,0f,0f,0f,509.0f,-558.0f,0f,578.0f,0f,0f,0f,0f,0f,106.0f,-260.0f,-492.0f,94.0f,380.0f,988.0f,-821,92.671875f,38.047142f,25.552042f,-98.68193f,0f,0f ) ;
  }

  @Test
  public void test928() {
    TestDrivers.surfaceShade(344.0f,-28.0f,-614.0f,0f,979.0f,766.0f,-856.0f,872.0f,0f,0f,0f,0f,0f,536.0f,-100.0f,-288.0f,-501.0f,1195.0f,256.0f,486,46.067913f,10.991783f,81.92091f,-34.945816f,-57.31505f,28.220135f ) ;
  }

  @Test
  public void test929() {
    TestDrivers.surfaceShade(-344.0f,-896.0f,-1919.0f,0f,213.0f,345.0f,0f,1608.0f,0f,0f,0f,0f,0f,-749.0f,-374.0f,620.0f,1283.0f,868.0f,-60.0f,-937,0.8685778f,0.25573853f,-0.030581644f,-100.0f,79.703316f,15.326919f ) ;
  }

  @Test
  public void test930() {
    TestDrivers.surfaceShade(346.0f,-16.0f,0f,0f,-115.0f,-81.0f,651.0f,26.0f,0f,0f,0f,0f,0f,-556.0f,927.0f,-280.0f,-722.0f,-18.0f,-666.0f,-990,-58.379257f,-35.85645f,88.68709f,57.830887f,39.894566f,0f ) ;
  }

  @Test
  public void test931() {
    TestDrivers.surfaceShade(346.0f,-1649.0f,618.0f,0f,524.0f,-596.0f,0f,136.0f,0f,0f,0f,0f,0f,511.0f,156.0f,-581.0f,-62.0f,-510.0f,451.0f,-474,-100.0f,-56.46076f,-82.319786f,-6.117562f,-57.09635f,100.0f ) ;
  }

  @Test
  public void test932() {
    TestDrivers.surfaceShade(-350.0f,-1263.0f,0f,0f,658.0f,1.0f,0f,-556.0f,0f,0f,0f,0f,0f,-199.0f,487.0f,-166.0f,0f,0f,0f,-571,0.59662855f,0.399706f,0.45739606f,-2.1771297f,40.785385f,0f ) ;
  }

  @Test
  public void test933() {
    TestDrivers.surfaceShade(350.0f,225.0f,-648.0f,0f,315.0f,338.0f,0f,616.0f,0f,0f,0f,0f,0f,24.0f,-542.0f,560.0f,468.0f,-685.0f,715.0f,-621,-100.0f,-2.9823768f,1.3991997f,-62.872025f,-90.00288f,35.65502f ) ;
  }

  @Test
  public void test934() {
    TestDrivers.surfaceShade(350.0f,826.0f,0f,0f,776.0f,-271.0f,0f,765.0f,0f,0f,0f,0f,0f,-168.0f,847.0f,-904.0f,-364.0f,296.0f,-801.0f,757,-52.764576f,-67.17289f,-53.131626f,-63.03248f,-67.98417f,0f ) ;
  }

  @Test
  public void test935() {
    TestDrivers.surfaceShade(-353.0f,1.0f,-2187.0f,0f,782.0f,-213.0f,0f,-2003.0f,0f,0f,0f,0f,0f,654.0f,-477.0f,729.0f,0f,0f,0f,-1420,-0.59331846f,-0.6237013f,0.12417645f,20.915907f,9.905176f,22.453487f ) ;
  }

  @Test
  public void test936() {
    TestDrivers.surfaceShade(-355.0f,-888.0f,-319.0f,0f,841.0f,1133.0f,0f,458.0f,0f,0f,0f,0f,0f,828.0f,1415.0f,-1828.0f,636.0f,-825.0f,625.0f,-1902,100.0f,-60.59866f,66.87822f,-2.6752822E-11f,8.532926f,21.860703f ) ;
  }

  @Test
  public void test937() {
    TestDrivers.surfaceShade(357.0f,0f,0f,0f,0.064449765f,0.0f,0f,-77.01418f,0f,0f,0f,0f,0f,-60.513275f,15.448468f,-22.039682f,0f,0f,0f,1278,26.597763f,68.08774f,-25.302717f,16.420593f,0f,0f ) ;
  }

  @Test
  public void test938() {
    TestDrivers.surfaceShade(357.0f,-828.0f,-184.0f,0f,807.0f,14.0f,0f,-83.0f,0f,0f,0f,0f,0f,-257.0f,-398.0f,-120.0f,671.0f,264.0f,670.0f,971,-62.795692f,76.58187f,-100.0f,-78.36475f,26.809914f,-23.489836f ) ;
  }

  @Test
  public void test939() {
    TestDrivers.surfaceShade(-360.0f,84.0f,-579.0f,0f,188.0f,-403.0f,0f,1310.0f,0f,0f,0f,0f,0f,855.0f,660.0f,-188.0f,34.0f,-452.0f,27.0f,-635,-33.78252f,-25.308811f,59.359207f,-63.10236f,5.029669f,75.46422f ) ;
  }

  @Test
  public void test940() {
    TestDrivers.surfaceShade(-36.0f,-1233.0f,0f,0f,167.0f,345.0f,0f,616.0f,0f,0f,0f,0f,0f,408.0f,-238.0f,-711.0f,315.0f,349.0f,452.0f,-663,-32.605957f,-0.1200886f,-18.670393f,-63.506905f,-12.149075f,0f ) ;
  }

  @Test
  public void test941() {
    TestDrivers.surfaceShade(36.0f,2143.0f,1685.0f,410.0f,0f,0f,0f,77.38249f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,6.7750676E-5f,100.0f,-100.0f ) ;
  }

  @Test
  public void test942() {
    TestDrivers.surfaceShade(361.0f,-569.0f,-411.0f,0f,515.0f,-692.0f,0f,-827.0f,0f,0f,0f,0f,0f,-767.0f,-811.0f,65.0f,0f,0f,0f,-478,-1.9305671f,35.369762f,95.02433f,-80.80521f,-20.92412f,100.0f ) ;
  }

  @Test
  public void test943() {
    TestDrivers.surfaceShade(-364.0f,-271.0f,92.0f,-70.0f,0f,0f,0f,94.06996f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,8.957146f,5.271481E-5f,-1.552795E-4f ) ;
  }

  @Test
  public void test944() {
    TestDrivers.surfaceShade(37.0f,34.0f,160.0f,0f,394.0f,70.0f,0f,1282.0f,0f,0f,0f,0f,0f,-760.0f,372.0f,-926.0f,-263.0f,-513.0f,1274.0f,-580,81.26047f,100.0f,-18.342619f,-14.210705f,-33.49003f,41.401783f ) ;
  }

  @Test
  public void test945() {
    TestDrivers.surfaceShade(-377.0f,0f,0f,0f,287.0f,-916.0f,0f,735.0f,0f,0f,0f,0f,0f,734.0f,-238.0f,938.0f,506.0f,753.0f,130.0f,-7,-40.89015f,93.918785f,37.638058f,50.660393f,0f,0f ) ;
  }

  @Test
  public void test946() {
    TestDrivers.surfaceShade(-38.0f,-109.0f,892.0f,0f,19.0f,-1559.0f,0f,2126.0f,0f,0f,0f,0f,0f,918.0f,-405.0f,419.0f,-2537.0f,218.0f,-614.0f,-798,-0.0117374305f,0.5838442f,0.5900521f,-85.867065f,-29.26794f,-100.0f ) ;
  }

  @Test
  public void test947() {
    TestDrivers.surfaceShade(381.0f,-33.0f,0f,0f,1669.0f,-717.0f,0f,0.0f,0f,0f,0f,0f,0f,314.0f,299.0f,890.0f,0f,0f,0f,369,0.5132437f,0.2008173f,-0.5567182f,98.512146f,-100.0f,0f ) ;
  }

  @Test
  public void test948() {
    TestDrivers.surfaceShade(-381.0f,994.0f,0.0f,-26.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,1.0094892E-4f,-0.13691899f,100.0f ) ;
  }

  @Test
  public void test949() {
    TestDrivers.surfaceShade(-384.0f,0f,0f,0f,712.0f,557.0f,0f,251.0f,0f,0f,0f,0f,0f,-96.0f,-112.0f,-115.0f,774.0f,-543.0f,-639.0f,-339,-82.85569f,-8.534757f,77.4786f,-49.085476f,0f,0f ) ;
  }

  @Test
  public void test950() {
    TestDrivers.surfaceShade(388.0f,118.0f,-850.0f,0f,284.0f,466.0f,0f,224.0f,0f,0f,0f,0f,0f,-590.0f,-646.0f,-59.0f,-994.0f,-862.0f,-157.0f,179,87.98865f,-82.522835f,23.668686f,100.0f,-96.60706f,-51.63313f ) ;
  }

  @Test
  public void test951() {
    TestDrivers.surfaceShade(388.0f,-911.0f,1720.0f,0f,3.0f,-1076.0f,0f,820.0f,0f,0f,0f,0f,0f,601.0f,-954.0f,-468.0f,-1408.0f,842.0f,134.0f,1203,43.8435f,74.529915f,-95.62306f,84.81434f,-86.92445f,28.952482f ) ;
  }

  @Test
  public void test952() {
    TestDrivers.surfaceShade(-396.0f,-716.0f,133.0f,0f,1413.0f,-856.0f,0f,859.0f,0f,0f,0f,0f,0f,-1558.0f,37.0f,488.0f,969.0f,1321.0f,-9.0f,156,0.03774953f,-0.2736134f,-0.89692736f,-87.76621f,-76.46119f,-41.529953f ) ;
  }

  @Test
  public void test953() {
    TestDrivers.surfaceShade(399.0f,623.0f,442.0f,0f,291.0f,-5.0f,0f,-604.0f,0f,0f,0f,0f,0f,62.0f,845.0f,-1136.0f,0f,0f,0f,324,-0.04533505f,-0.64515907f,-0.27217737f,-63.529404f,-8.159575f,-4.4438105f ) ;
  }

  @Test
  public void test954() {
    TestDrivers.surfaceShade(400.0f,0f,0f,0f,19.555622f,-53.583584f,0f,-60.42936f,0f,0f,0f,0f,0f,83.57077f,99.90802f,98.70034f,0f,0f,0f,871,-56.684513f,34.70093f,-89.87312f,78.92217f,0f,0f ) ;
  }

  @Test
  public void test955() {
    TestDrivers.surfaceShade(-402.0f,-1096.0f,-472.0f,0f,335.0f,-469.0f,0f,-1715.0f,0f,0f,0f,0f,0f,51.0f,65.0f,-622.0f,0f,0f,0f,157,18.468441f,12.327116f,2.802497f,-94.15694f,88.128876f,82.84012f ) ;
  }

  @Test
  public void test956() {
    TestDrivers.surfaceShade(409.0f,-29.0f,-507.0f,85.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,2.8764562E-5f,-4.0567952E-4f,-2.3623907E-5f ) ;
  }

  @Test
  public void test957() {
    TestDrivers.surfaceShade(-4.0f,-1117.0f,-84.0f,0f,568.0f,102.0f,0f,509.0f,0f,0f,0f,0f,0f,-294.0f,-603.0f,-631.0f,-1682.0f,206.0f,846.0f,322,7.7522297f,-49.359474f,74.231415f,38.790775f,-68.3784f,-74.9885f ) ;
  }

  @Test
  public void test958() {
    TestDrivers.surfaceShade(-413.0f,-599.0f,0f,-96.0f,0f,0f,0f,67.47639f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-6.679602f,1.7390095E-5f,0f ) ;
  }

  @Test
  public void test959() {
    TestDrivers.surfaceShade(413.0f,62.0f,213.0f,791.0f,0f,0f,0f,97.29188f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-97.45471f,15.788841f,-24.421202f ) ;
  }

  @Test
  public void test960() {
    TestDrivers.surfaceShade(414.0f,-367.0f,0f,0f,-800.0f,-58.0f,520.0f,617.0f,0f,0f,0f,0f,0f,379.0f,-4.0f,775.0f,-623.0f,-471.0f,-162.0f,-714,-54.006886f,-22.776588f,96.180504f,-76.951775f,-63.44021f,0f ) ;
  }

  @Test
  public void test961() {
    TestDrivers.surfaceShade(418.0f,0f,0f,0f,65.0f,916.0f,0f,-967.0f,0f,0f,0f,0f,0f,-844.0f,591.0f,767.0f,-4.0f,-450.0f,130.0f,-396,-100.0f,-100.0f,-100.0f,98.45896f,0f,0f ) ;
  }

  @Test
  public void test962() {
    TestDrivers.surfaceShade(-419.0f,-77.0f,561.0f,-2.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-3,0f,0f,0f,0.0011933175f,0.0064935065f,-8.912656E-4f ) ;
  }

  @Test
  public void test963() {
    TestDrivers.surfaceShade(-421.0f,789.0f,158.0f,0f,170.0f,949.0f,0f,-228.0f,0f,0f,0f,0f,0f,18.0f,-1136.0f,-236.0f,829.0f,180.0f,-479.0f,324,28.443283f,56.81366f,43.527946f,-13.965428f,-3.5732284f,-26.348917f ) ;
  }

  @Test
  public void test964() {
    TestDrivers.surfaceShade(-422.0f,851.0f,-833.0f,-37.0f,0f,0f,0f,83.5571f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,7.1123755E-4f,36.345753f,3.2445412E-5f ) ;
  }

  @Test
  public void test965() {
    TestDrivers.surfaceShade(-427.0f,0f,0f,0f,16.0f,-2.0f,0f,327.0f,0f,0f,0f,0f,0f,1833.0f,-225.0f,-447.0f,1101.0f,62.0f,692.0f,-446,0.00668865f,0.21201842f,-0.012953545f,-52.33796f,0f,0f ) ;
  }

  @Test
  public void test966() {
    TestDrivers.surfaceShade(429.0f,0f,0f,0f,348.0f,55.0f,-471.0f,0.0f,0f,0f,0f,0f,0f,1147.0f,-547.0f,-57.0f,623.0f,458.0f,-637.0f,732,-30.294283f,-11.007584f,-35.54227f,40.48794f,0f,0f ) ;
  }

  @Test
  public void test967() {
    TestDrivers.surfaceShade(429.0f,-162.0f,0f,0f,187.0f,935.0f,0f,-1200.0f,0f,0f,0f,0f,0f,32.0f,-711.0f,-525.0f,-822.0f,113.0f,611.0f,426,0.082976714f,0.8387748f,0.52471f,53.541435f,2.8625102f,0f ) ;
  }

  @Test
  public void test968() {
    TestDrivers.surfaceShade(-430.0f,-587.0f,0f,0f,1123.0f,1.0f,0f,6.0f,0f,0f,0f,0f,0f,630.0f,1363.0f,-99.0f,0f,0f,0f,-1479,-0.26385397f,-0.052794926f,-0.176947f,75.735275f,33.7483f,0f ) ;
  }

  @Test
  public void test969() {
    TestDrivers.surfaceShade(430.0f,869.0f,0f,-42.0f,0f,0f,0f,-47.787296f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-5.5370987E-5f,-2.739876E-5f,0f ) ;
  }

  @Test
  public void test970() {
    TestDrivers.surfaceShade(-43.0f,672.0f,-883.0f,0f,191.0f,-331.0f,0f,1413.0f,0f,0f,0f,0f,0f,-110.0f,-246.0f,-216.0f,-722.0f,848.0f,-2213.0f,370,74.69522f,-18.910107f,-16.50272f,-100.0f,-4.9665604f,6.17031f ) ;
  }

  @Test
  public void test971() {
    TestDrivers.surfaceShade(-431.0f,-547.0f,288.0f,0f,4.0f,-253.0f,0f,711.0f,0f,0f,0f,0f,0f,-620.0f,-489.0f,-34.0f,-225.0f,1208.0f,1080.0f,1436,0.016674872f,8.6646184E-4f,-0.3165326f,-46.484196f,60.067818f,-96.132126f ) ;
  }

  @Test
  public void test972() {
    TestDrivers.surfaceShade(-434.0f,570.0f,-2044.0f,0f,810.0f,230.0f,0f,1139.0f,0f,0f,0f,0f,0f,860.0f,840.0f,26.0f,467.0f,-972.0f,978.0f,353,-100.0f,99.28571f,100.0f,99.99909f,99.99965f,47.998577f ) ;
  }

  @Test
  public void test973() {
    TestDrivers.surfaceShade(-436.0f,-792.0f,0f,0f,871.0f,849.0f,0f,-905.0f,0f,0f,0f,0f,0f,1090.0f,-138.0f,-81.0f,-53.0f,220.0f,-650.0f,-679,-3.0341682f,15.1792965f,-57.18674f,44.84778f,3.3669305f,0f ) ;
  }

  @Test
  public void test974() {
    TestDrivers.surfaceShade(-44.0f,-827.0f,-497.0f,-19.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0.0011961722f,79.350204f,-68.61351f ) ;
  }

  @Test
  public void test975() {
    TestDrivers.surfaceShade(443.0f,-163.0f,74.0f,-867.0f,0f,0f,0f,-83.66567f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0f,0f,0f,8.321586f,7.0760893E-6f,-66.20845f ) ;
  }

  @Test
  public void test976() {
    TestDrivers.surfaceShade(444.0f,-2370.0f,347.0f,0f,147.0f,-1165.0f,0f,851.0f,0f,0f,0f,0f,0f,279.0f,-36.0f,-565.0f,-610.0f,-587.0f,1229.0f,-268,-21.114964f,-13.903188f,-9.540814f,30.969954f,55.888935f,66.60269f ) ;
  }

  @Test
  public void test977() {
    TestDrivers.surfaceShade(446.0f,0f,0f,0f,100.0f,-33.234226f,0f,0.0f,0f,0f,0f,0f,0f,-98.24729f,47.260784f,-17.04963f,0f,0f,0f,468,67.28199f,-54.74476f,-37.646595f,91.16117f,0f,0f ) ;
  }

  @Test
  public void test978() {
    TestDrivers.surfaceShade(449.0f,0f,0f,0f,384.0f,1024.0f,0f,-314.0f,0f,0f,0f,0f,0f,794.0f,746.0f,52.0f,-1282.0f,-1764.0f,-206.0f,2601,-0.88887334f,-0.44884947f,-0.09186015f,45.31266f,0f,0f ) ;
  }

  @Test
  public void test979() {
    TestDrivers.surfaceShade(-454.0f,158.0f,1194.0f,0f,463.0f,2397.0f,0f,249.0f,0f,0f,0f,0f,0f,50.0f,210.0f,-15.0f,-763.0f,946.0f,-1865.0f,-1408,-53.58407f,16.236538f,48.69797f,-92.81063f,-100.0f,100.0f ) ;
  }

  @Test
  public void test980() {
    TestDrivers.surfaceShade(-455.0f,-753.0f,-580.0f,0f,54.0f,-317.0f,0f,-92.0f,0f,0f,0f,0f,0f,3.0f,50.0f,533.0f,0f,0f,0f,-451,52.37344f,67.22965f,-6.6015067f,-36.866608f,-41.032608f,-87.47879f ) ;
  }

  @Test
  public void test981() {
    TestDrivers.surfaceShade(455.0f,826.0f,-615.0f,-13.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,100.0f,-9.3127215E-5f,11.616643f ) ;
  }

  @Test
  public void test982() {
    TestDrivers.surfaceShade(456.0f,0f,0f,0f,0.9643308f,0.0f,0f,0.0f,0f,0f,0f,0f,0f,45.099957f,59.23454f,33.568775f,0f,0f,0f,-803,54.37723f,-61.869453f,36.11683f,80.629196f,0f,0f ) ;
  }

  @Test
  public void test983() {
    TestDrivers.surfaceShade(-457.0f,1123.0f,-40.0f,-93.0f,0f,0f,0f,30.530787f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,7.6656065f,-46.999546f,5.681818E-4f ) ;
  }

  @Test
  public void test984() {
    TestDrivers.surfaceShade(-457.0f,-992.0f,803.0f,-50.0f,0f,0f,0f,31.360142f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,4.3763677E-5f,37.481087f,-6.6148424f ) ;
  }

  @Test
  public void test985() {
    TestDrivers.surfaceShade(-459.0f,752.0f,0f,0f,536.0f,0.0f,0f,1.0f,0f,0f,0f,0f,0f,-621.0f,-866.0f,282.0f,0f,0f,0f,8,-94.04187f,100.0f,100.0f,-77.134705f,78.21023f,0f ) ;
  }

  @Test
  public void test986() {
    TestDrivers.surfaceShade(-460.0f,-1643.0f,-95.0f,251.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,100.0f,84.045006f,-4.1937514E-5f ) ;
  }

  @Test
  public void test987() {
    TestDrivers.surfaceShade(-46.0f,307.0f,0f,0f,223.0f,720.0f,186.0f,-349.0f,0f,0f,0f,0f,0f,660.0f,690.0f,-206.0f,34.0f,38.0f,-632.0f,-829,-2.3946064f,-80.6348f,-78.92427f,-34.22202f,-69.928276f,0f ) ;
  }

  @Test
  public void test988() {
    TestDrivers.surfaceShade(46.0f,598.0f,1106.0f,0f,885.0f,1921.0f,-66.0f,868.0f,0f,0f,0f,0f,0f,-263.0f,450.0f,238.0f,-279.0f,-400.0f,-293.0f,1637,-54.135868f,-78.123665f,87.8904f,65.72372f,17.575552f,-28.601109f ) ;
  }

  @Test
  public void test989() {
    TestDrivers.surfaceShade(461.0f,281.0f,0f,25.0f,0f,0f,0f,13.313329f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,9.689693f,5.589655f,0f ) ;
  }

  @Test
  public void test990() {
    TestDrivers.surfaceShade(464.0f,-63.0f,0f,0f,61.0f,-951.0f,0f,-582.0f,0f,0f,0f,0f,0f,607.0f,636.0f,-1367.0f,0f,0f,0f,-1148,-0.3307279f,-0.29109824f,0.89770865f,-54.454437f,23.02511f,0f ) ;
  }

  @Test
  public void test991() {
    TestDrivers.surfaceShade(-465.0f,705.0f,-711.0f,0f,1604.0f,-95.0f,0f,673.0f,0f,0f,0f,0f,0f,235.0f,-145.0f,118.0f,-209.0f,-118.0f,-342.0f,-845,-33.107178f,-29.446747f,-37.336567f,-81.49019f,61.388126f,-41.782753f ) ;
  }

  @Test
  public void test992() {
    TestDrivers.surfaceShade(470.0f,-759.0f,0f,0f,739.0f,-469.0f,0f,-936.0f,0f,0f,0f,0f,0f,-248.0f,250.0f,51.0f,0f,0f,0f,568,69.37768f,65.46542f,-66.58463f,70.21424f,-47.443745f,0f ) ;
  }

  @Test
  public void test993() {
    TestDrivers.surfaceShade(-47.0f,1071.0f,701.0f,0f,154.0f,-77.0f,0f,734.0f,0f,0f,0f,0f,0f,83.0f,101.0f,821.0f,913.0f,511.0f,-176.0f,-4,-12.305924f,-73.21032f,9.862379f,-4.34818E-7f,-8.637294f,2.9072798E-8f ) ;
  }

  @Test
  public void test994() {
    TestDrivers.surfaceShade(-474.0f,67.0f,0f,64.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,-66.00913f,16.177965f,0f ) ;
  }

  @Test
  public void test995() {
    TestDrivers.surfaceShade(-476.0f,1607.0f,-515.0f,0f,462.0f,-126.0f,0f,1458.0f,0f,0f,0f,0f,0f,23.0f,-728.0f,1026.0f,462.0f,-747.0f,-199.0f,-1650,-2.3269424f,7.1466484f,5.12308f,23.933632f,-76.83077f,95.69914f ) ;
  }

  @Test
  public void test996() {
    TestDrivers.surfaceShade(-477.0f,0f,0f,0f,2.0155979E-4f,-57.172176f,0f,0.0f,0f,0f,0f,0f,0f,-41.122517f,45.42972f,-25.576656f,0f,0f,0f,802,0.14299096f,0.48869035f,0.66465855f,-15.322147f,0f,0f ) ;
  }

  @Test
  public void test997() {
    TestDrivers.surfaceShade(477.0f,0f,0f,0f,279.0f,644.0f,0f,-1501.0f,0f,0f,0f,0f,0f,-802.0f,-1043.0f,-781.0f,-461.0f,-983.0f,-1.0f,662,-42.863308f,73.67145f,-54.369976f,-54.633724f,0f,0f ) ;
  }

  @Test
  public void test998() {
    TestDrivers.surfaceShade(479.0f,-958.0f,0f,0f,106.0f,-141.0f,0f,672.0f,0f,0f,0f,0f,0f,-499.0f,-330.0f,612.0f,588.0f,-106.0f,-378.0f,447,69.59959f,-99.93962f,2.8596694f,67.18785f,67.42163f,0f ) ;
  }

  @Test
  public void test999() {
    TestDrivers.surfaceShade(-483.0f,0f,0f,0f,82.93208f,0.0f,0f,-63.03442f,0f,0f,0f,0f,0f,-46.15122f,-64.73188f,-12.947444f,0f,0f,0f,-668,0.021857599f,-0.16261192f,0.735081f,-68.22054f,0f,0f ) ;
  }

  @Test
  public void test1000() {
    TestDrivers.surfaceShade(487.0f,136.0f,1273.0f,0f,1014.0f,521.0f,0f,803.0f,0f,0f,0f,0f,0f,-714.0f,-151.0f,-489.0f,-341.0f,109.0f,-1568.0f,882,-11.965789f,-40.094166f,29.852335f,-70.789085f,-46.62841f,27.833115f ) ;
  }

  @Test
  public void test1001() {
    TestDrivers.surfaceShade(-488.0f,-43.0f,0f,0f,544.0f,848.0f,0f,-205.0f,0f,0f,0f,0f,0f,-61.0f,-608.0f,750.0f,-939.0f,-339.0f,-398.0f,266,-72.97741f,53.55007f,-52.57518f,-12.2005415f,38.408943f,0f ) ;
  }

  @Test
  public void test1002() {
    TestDrivers.surfaceShade(-488.0f,76.0f,-906.0f,0f,1306.0f,-1.0f,0f,-28.0f,0f,0f,0f,0f,0f,-638.0f,855.0f,185.0f,0f,0f,0f,-801,26.091866f,22.87169f,-100.0f,-28.519009f,-1.0838629f,-100.0f ) ;
  }

  @Test
  public void test1003() {
    TestDrivers.surfaceShade(-489.0f,234.0f,746.0f,0f,700.0f,817.0f,0f,-112.0f,0f,0f,0f,0f,0f,-739.0f,-289.0f,-8.0f,987.0f,968.0f,728.0f,159,64.58594f,-44.979156f,89.22757f,62.399277f,0.05344767f,27.154465f ) ;
  }

  @Test
  public void test1004() {
    TestDrivers.surfaceShade(49.0f,-755.0f,0f,0f,569.0f,1658.0f,0f,-465.0f,0f,0f,0f,0f,0f,208.0f,-773.0f,529.0f,373.0f,357.0f,352.0f,-388,-78.1625f,-7.959271f,19.102613f,66.77957f,39.71866f,0f ) ;
  }

  @Test
  public void test1005() {
    TestDrivers.surfaceShade(-49.0f,77.0f,0f,0f,450.0f,136.0f,0f,-199.0f,0f,0f,0f,0f,0f,127.0f,120.0f,-256.0f,817.0f,-699.0f,998.0f,-282,-86.188934f,83.22623f,-3.7454977f,-55.3023f,46.05836f,0f ) ;
  }

  @Test
  public void test1006() {
    TestDrivers.surfaceShade(-493.0f,-21.0f,0f,0f,136.0f,-2321.0f,0f,1000.0f,0f,0f,0f,0f,0f,320.0f,-711.0f,1420.0f,584.0f,-650.0f,-1184.0f,590,0.6923474f,-0.534239f,-0.45224518f,-100.0f,-8.58332E-6f,0f ) ;
  }

  @Test
  public void test1007() {
    TestDrivers.surfaceShade(-494.0f,-2703.0f,390.0f,0f,1753.0f,-503.0f,0f,2.0f,0f,0f,0f,0f,0f,-1584.0f,182.0f,613.0f,0f,0f,0f,394,30.921286f,-67.69606f,100.0f,100.0f,-100.0f,29.587175f ) ;
  }

  @Test
  public void test1008() {
    TestDrivers.surfaceShade(496.0f,347.0f,0f,0f,75.0f,-1341.0f,0f,0.0f,0f,0f,0f,0f,0f,328.0f,-770.0f,1268.0f,0f,0f,0f,-1272,-0.5591768f,0.2635027f,0.30465856f,-19.137262f,2.420194f,0f ) ;
  }

  @Test
  public void test1009() {
    TestDrivers.surfaceShade(496.0f,-928.0f,0f,0f,408.0f,199.0f,0f,194.0f,0f,0f,0f,0f,0f,848.0f,659.0f,-892.0f,-986.0f,436.0f,-418.0f,-754,-55.753056f,0.8485861f,96.36555f,-42.13069f,85.3522f,0f ) ;
  }

  @Test
  public void test1010() {
    TestDrivers.surfaceShade(497.0f,-133.0f,-32.0f,0f,1266.0f,-353.0f,0f,657.0f,0f,0f,0f,0f,0f,126.0f,-48.0f,87.0f,420.0f,1132.0f,-568.0f,872,37.907753f,-80.64435f,-99.39432f,83.53422f,-11.141288f,-90.10841f ) ;
  }

  @Test
  public void test1011() {
    TestDrivers.surfaceShade(-497.0f,-639.0f,0f,0f,350.0f,-17.0f,0f,-261.0f,0f,0f,0f,0f,0f,-635.0f,781.0f,-863.0f,0f,0f,0f,-187,15.533231f,73.28275f,85.31463f,17.16205f,95.26803f,0f ) ;
  }

  @Test
  public void test1012() {
    TestDrivers.surfaceShade(503.0f,1944.0f,-465.0f,0f,212.0f,618.0f,0f,139.0f,0f,0f,0f,0f,0f,980.0f,659.0f,-354.0f,651.0f,853.0f,57.0f,1989,99.99963f,-99.90883f,90.84667f,100.0f,138.64632f,-100.0f ) ;
  }

  @Test
  public void test1013() {
    TestDrivers.surfaceShade(-507.0f,0f,0f,0f,622.0f,625.0f,-1340.0f,1377.0f,0f,0f,0f,0f,0f,-285.0f,-138.0f,-147.0f,451.0f,255.0f,773.0f,-1457,-0.44441518f,0.60407054f,0.29453465f,81.14831f,0f,0f ) ;
  }

  @Test
  public void test1014() {
    TestDrivers.surfaceShade(-509.0f,-512.0f,691.0f,0f,621.0f,180.0f,0f,637.0f,0f,0f,0f,0f,0f,859.0f,74.0f,-187.0f,-1247.0f,419.0f,-941.0f,-1254,0.7048228f,0.25360322f,3.3380182f,-28.242413f,-92.85795f,30.58574f ) ;
  }

  @Test
  public void test1015() {
    TestDrivers.surfaceShade(-509.0f,-881.0f,0f,0f,68.0f,961.0f,0f,1422.0f,0f,0f,0f,0f,0f,461.0f,-773.0f,811.0f,514.0f,-105.0f,-1311.0f,-962,-0.22242221f,0.27726752f,0.026769597f,-48.086098f,30.500944f,0f ) ;
  }

  @Test
  public void test1016() {
    TestDrivers.surfaceShade(-512.0f,0f,218.0f,0f,2186.0f,2631.0f,0f,1430.0f,0f,0f,0f,0f,0f,-959.0f,126.0f,-56.0f,2545.0f,-1042.0f,-450.0f,-89,0.13352278f,-0.45754403f,0.8711832f,100.0f,0f,1.081304f ) ;
  }

  @Test
  public void test1017() {
    TestDrivers.surfaceShade(-512.0f,-349.0f,-212.0f,-798.0f,0f,0f,0f,94.10609f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-0.15849166f,63.13432f,5.911004E-6f ) ;
  }

  @Test
  public void test1018() {
    TestDrivers.surfaceShade(-515.0f,68.0f,-446.0f,31.0f,0f,0f,0f,46.71584f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-6.263702E-5f,4.743833E-4f,-99.99999f ) ;
  }

  @Test
  public void test1019() {
    TestDrivers.surfaceShade(516.0f,1404.0f,127.0f,0f,10.0f,-66.0f,0f,920.0f,0f,0f,0f,0f,0f,19.0f,221.0f,-1062.0f,498.0f,-330.0f,837.0f,-1164,6.235541f,69.70705f,17.161024f,45.9063f,-100.0f,2.9149265E-7f ) ;
  }

  @Test
  public void test1020() {
    TestDrivers.surfaceShade(-518.0f,387.0f,-794.0f,0f,170.0f,213.0f,0f,-1377.0f,0f,0f,0f,0f,0f,1201.0f,-62.0f,-834.0f,-1177.0f,1002.0f,-1267.0f,643,0.13171484f,-0.073951036f,0.9579653f,100.0f,56.450893f,23.288954f ) ;
  }

  @Test
  public void test1021() {
    TestDrivers.surfaceShade(519.0f,-478.0f,-925.0f,0f,385.0f,-842.0f,0f,578.0f,0f,0f,0f,0f,0f,710.0f,256.0f,-279.0f,447.0f,569.0f,188.0f,484,-45.413765f,100.0f,-5.53431f,-9.638718f,-100.0f,-15.018106f ) ;
  }

  @Test
  public void test1022() {
    TestDrivers.surfaceShade(-52.0f,-819.0f,415.0f,0f,1808.0f,35.0f,0f,-660.0f,0f,0f,0f,0f,0f,449.0f,132.0f,-984.0f,-967.0f,-801.0f,880.0f,765,8.81567f,8.375404f,14.175246f,-91.99966f,-34.54851f,49.82381f ) ;
  }

  @Test
  public void test1023() {
    TestDrivers.surfaceShade(523.0f,617.0f,938.0f,0f,1304.0f,-2182.0f,0f,1480.0f,0f,0f,0f,0f,0f,203.0f,231.0f,1562.0f,554.0f,-938.0f,453.0f,532,-9.840947f,-2.322324f,1.6223874f,-87.510864f,-39.45273f,-97.57937f ) ;
  }

  @Test
  public void test1024() {
    TestDrivers.surfaceShade(524.0f,-252.0f,0f,0f,629.0f,-1.0f,0f,-805.0f,0f,0f,0f,0f,0f,-354.0f,824.0f,-1413.0f,0f,0f,0f,-366,-67.5391f,-0.22603855f,16.788807f,92.28811f,-36.319897f,0f ) ;
  }

  @Test
  public void test1025() {
    TestDrivers.surfaceShade(-531.0f,-680.0f,-23.0f,81.0f,0f,0f,0f,-51.71135f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,-17.476076f,-74.1269f,62.925556f ) ;
  }

  @Test
  public void test1026() {
    TestDrivers.surfaceShade(-532.0f,0f,0f,-132.0f,0f,0f,0f,-51.74408f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-43.937046f,0f,0f ) ;
  }

  @Test
  public void test1027() {
    TestDrivers.surfaceShade(-535.0f,-754.0f,0f,0f,354.0f,1189.0f,0f,-1379.0f,0f,0f,0f,0f,0f,-133.0f,411.0f,-564.0f,807.0f,1785.0f,1355.0f,-38,-89.72417f,-41.94049f,-9.404657f,-68.11698f,-48.66499f,0f ) ;
  }

  @Test
  public void test1028() {
    TestDrivers.surfaceShade(545.0f,641.0f,992.0f,0f,573.0f,739.0f,0f,-16.0f,0f,0f,0f,0f,0f,-899.0f,-557.0f,953.0f,-466.0f,334.0f,322.0f,-254,82.48584f,-9.67312f,72.15828f,85.35573f,-72.808235f,91.55094f ) ;
  }

  @Test
  public void test1029() {
    TestDrivers.surfaceShade(551.0f,-1281.0f,0f,0f,36.0f,-822.0f,0f,764.0f,0f,0f,0f,0f,0f,-556.0f,48.0f,-969.0f,-795.0f,2026.0f,313.0f,438,16.224794f,-78.95574f,-13.220703f,-53.4936f,23.00936f,0f ) ;
  }

  @Test
  public void test1030() {
    TestDrivers.surfaceShade(-559.0f,-999.0f,-638.0f,0f,-58.0f,232.0f,315.0f,638.0f,0f,0f,0f,0f,0f,-952.0f,952.0f,-265.0f,-79.0f,-916.0f,961.0f,-493,29.175797f,36.802197f,15.340855f,45.93724f,-0.83271486f,72.48103f ) ;
  }

  @Test
  public void test1031() {
    TestDrivers.surfaceShade(-565.0f,-239.0f,-26.0f,-26.0f,0f,0f,0f,14.744794f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-99.32626f,1.6092694E-4f,0.00147929f ) ;
  }

  @Test
  public void test1032() {
    TestDrivers.surfaceShade(569.0f,-612.0f,0f,0f,208.0f,-4.0f,0f,-1.0f,0f,0f,0f,0f,0f,625.0f,-440.0f,857.0f,0f,0f,0f,-113,-12.864271f,55.95582f,17.824986f,72.80854f,-7.5164423f,0f ) ;
  }

  @Test
  public void test1033() {
    TestDrivers.surfaceShade(570.0f,0f,0f,0f,62.79094f,-97.11497f,0f,-74.02138f,0f,0f,0f,0f,0f,87.242386f,68.70166f,69.23326f,0f,0f,0f,326,-59.60399f,23.030787f,-79.05747f,-57.51659f,0f,0f ) ;
  }

  @Test
  public void test1034() {
    TestDrivers.surfaceShade(57.0f,463.0f,0f,0f,146.0f,86.0f,0f,846.0f,0f,0f,0f,0f,0f,619.0f,981.0f,-285.0f,-392.0f,-1294.0f,-205.0f,-425,98.69807f,-82.09086f,-66.65292f,2.725143E-7f,-59.27947f,0f ) ;
  }

  @Test
  public void test1035() {
    TestDrivers.surfaceShade(-571.0f,-694.0f,765.0f,0f,622.0f,354.0f,0f,-311.0f,0f,0f,0f,0f,0f,193.0f,146.0f,-85.0f,-546.0f,-460.0f,-563.0f,-928,-70.25927f,-96.52766f,-47.498455f,-34.552082f,55.431683f,33.14643f ) ;
  }

  @Test
  public void test1036() {
    TestDrivers.surfaceShade(-572.0f,-1775.0f,0f,0f,469.0f,-1.0f,0f,1.0f,0f,0f,0f,0f,0f,-879.0f,-1020.0f,113.0f,0f,0f,0f,-98,-31.109024f,26.517214f,-2.6307461f,-21.22473f,-37.28503f,0f ) ;
  }

  @Test
  public void test1037() {
    TestDrivers.surfaceShade(575.0f,1642.0f,0f,0f,73.0f,111.0f,0f,813.0f,0f,0f,0f,0f,0f,631.0f,-214.0f,954.0f,2460.0f,-639.0f,-1143.0f,752,-81.36993f,-92.9499f,32.969753f,-43.964024f,-23.987165f,0f ) ;
  }

  @Test
  public void test1038() {
    TestDrivers.surfaceShade(-576.0f,-396.0f,-822.0f,0f,774.0f,-447.0f,0f,-417.0f,0f,0f,0f,0f,0f,-872.0f,315.0f,997.0f,0f,0f,0f,656,100.0f,-100.0f,100.0f,-100.0f,-100.0f,100.0f ) ;
  }

  @Test
  public void test1039() {
    TestDrivers.surfaceShade(-578.0f,-22.0f,739.0f,143.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-1.2098628E-5f,-3.1786395E-4f,-60.14419f ) ;
  }

  @Test
  public void test1040() {
    TestDrivers.surfaceShade(580.0f,-339.0f,0f,0f,989.0f,408.0f,0f,237.0f,0f,0f,0f,0f,0f,-773.0f,995.0f,-682.0f,0.0f,-57.0f,632.0f,489,-3.2312462f,-56.204506f,73.51141f,94.836784f,35.301792f,0f ) ;
  }

  @Test
  public void test1041() {
    TestDrivers.surfaceShade(582.0f,1312.0f,0f,0f,373.0f,-2592.0f,0f,1384.0f,0f,0f,0f,0f,0f,-722.0f,760.0f,342.0f,-462.0f,-1492.0f,-682.0f,-860,1.8986373f,15.381353f,-30.17255f,44.459072f,24.590227f,0f ) ;
  }

  @Test
  public void test1042() {
    TestDrivers.surfaceShade(586.0f,-175.0f,0f,0f,765.0f,646.0f,0f,393.0f,0f,0f,0f,0f,0f,-989.0f,62.0f,-1647.0f,-188.0f,1761.0f,-1096.0f,1004,90.47881f,-31.540237f,-55.51854f,-26.003674f,29.017237f,0f ) ;
  }

  @Test
  public void test1043() {
    TestDrivers.surfaceShade(-588.0f,781.0f,674.0f,0f,924.0f,-672.0f,0f,0.0f,0f,0f,0f,0f,0f,607.0f,84.0f,949.0f,0f,0f,0f,-1502,26.817316f,32.328495f,-20.014442f,2.7135239f,-3.8711736f,11.824818f ) ;
  }

  @Test
  public void test1044() {
    TestDrivers.surfaceShade(588.0f,-931.0f,-660.0f,0f,258.0f,326.0f,0f,237.0f,0f,0f,0f,0f,0f,-808.0f,405.0f,-460.0f,552.0f,1372.0f,-847.0f,-865,8.637219f,-96.021866f,-99.712456f,29.679844f,58.71217f,-7.2259326f ) ;
  }

  @Test
  public void test1045() {
    TestDrivers.surfaceShade(-589.0f,386.0f,0f,0f,146.0f,4.0f,0f,-2089.0f,0f,0f,0f,0f,0f,-724.0f,-90.0f,-514.0f,0f,0f,0f,-437,44.424774f,9.997143f,-64.32545f,-25.621426f,39.095848f,0f ) ;
  }

  @Test
  public void test1046() {
    TestDrivers.surfaceShade(590.0f,-426.0f,0f,309.0f,0f,0f,0f,-54.495884f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-65.52394f,-78.14008f,0f ) ;
  }

  @Test
  public void test1047() {
    TestDrivers.surfaceShade(591.0f,0f,0f,0f,994.0f,76.0f,-144.0f,-611.0f,0f,0f,0f,0f,0f,983.0f,-702.0f,509.0f,-368.0f,756.0f,-401.0f,-102,76.44372f,68.756744f,-52.803425f,31.816204f,0f,0f ) ;
  }

  @Test
  public void test1048() {
    TestDrivers.surfaceShade(591.0f,-339.0f,-821.0f,-380.0f,0f,0f,0f,-98.54597f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,84.04286f,13.105213f,-58.336052f ) ;
  }

  @Test
  public void test1049() {
    TestDrivers.surfaceShade(-592.0f,1859.0f,0f,0f,577.0f,-144.0f,0f,-7.0f,0f,0f,0f,0f,0f,-1232.0f,505.0f,94.0f,0f,0f,0f,788,0.36208603f,0.34651706f,-0.8275009f,4.4669194f,-80.975815f,0f ) ;
  }

  @Test
  public void test1050() {
    TestDrivers.surfaceShade(593.0f,-290.0f,954.0f,0f,466.0f,-469.0f,0f,495.0f,0f,0f,0f,0f,0f,319.0f,484.0f,-184.0f,-365.0f,-232.0f,-263.0f,731,-63.536137f,55.052666f,35.892746f,-64.17707f,-34.583214f,-12.529806f ) ;
  }

  @Test
  public void test1051() {
    TestDrivers.surfaceShade(595.0f,0f,0f,0f,6.289949f,-85.878105f,0f,-24.843864f,0f,0f,0f,0f,0f,-78.266426f,-88.00862f,99.95963f,0f,0f,0f,117,0.47844636f,0.8508545f,0.21710755f,-22.497667f,0f,0f ) ;
  }

  @Test
  public void test1052() {
    TestDrivers.surfaceShade(595.0f,0f,-659.0f,0f,386.0f,133.0f,0f,2023.0f,0f,0f,0f,0f,0f,-634.0f,-626.0f,-1123.0f,514.0f,-130.0f,1247.0f,-735,0.8618494f,-0.48779276f,-0.13894954f,-51.263756f,0f,67.9413f ) ;
  }

  @Test
  public void test1053() {
    TestDrivers.surfaceShade(596.0f,0f,0f,0f,1674.0f,351.0f,-127.0f,0.0f,0f,0f,0f,0f,0f,-797.0f,587.0f,1374.0f,12.0f,619.0f,-128.0f,-497,82.30658f,-100.0f,17.129128f,60.605762f,0f,0f ) ;
  }

  @Test
  public void test1054() {
    TestDrivers.surfaceShade(596.0f,-1720.0f,960.0f,0f,293.0f,2179.0f,0f,-619.0f,0f,0f,0f,0f,0f,-841.0f,-406.0f,-248.0f,20.0f,3032.0f,-720.0f,186,0.3869817f,-0.8206871f,0.03123938f,-100.0f,1.978337f,10.21989f ) ;
  }

  @Test
  public void test1055() {
    TestDrivers.surfaceShade(597.0f,0f,0f,0f,1150.0f,-711.0f,0f,815.0f,0f,0f,0f,0f,0f,139.0f,30.0f,-392.0f,-882.0f,-455.0f,758.0f,33,41.314285f,-77.53684f,60.874275f,-10.63267f,0f,0f ) ;
  }

  @Test
  public void test1056() {
    TestDrivers.surfaceShade(60.0f,0f,0f,0f,523.0f,628.0f,-393.0f,0.0f,0f,0f,0f,0f,0f,-861.0f,-1255.0f,-793.0f,2041.0f,-2019.0f,450.0f,-982,34.5524f,6.203342f,-37.642662f,-80.16851f,0f,0f ) ;
  }

  @Test
  public void test1057() {
    TestDrivers.surfaceShade(60.0f,-845.0f,964.0f,-690.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,86.55615f,-114.20872f,-83.26164f ) ;
  }

  @Test
  public void test1058() {
    TestDrivers.surfaceShade(-601.0f,-657.0f,0f,0f,-463.0f,-663.0f,747.0f,-674.0f,0f,0f,0f,0f,0f,29.0f,81.0f,-422.0f,832.0f,-654.0f,351.0f,59,-98.60947f,48.900585f,-57.819134f,-16.880913f,80.163376f,0f ) ;
  }

  @Test
  public void test1059() {
    TestDrivers.surfaceShade(-603.0f,0f,0f,0f,-490.0f,-704.0f,774.0f,326.0f,0f,0f,0f,0f,0f,808.0f,899.0f,313.0f,198.0f,-447.0f,598.0f,-140,80.884346f,-93.609436f,-33.188313f,9.822625f,0f,0f ) ;
  }

  @Test
  public void test1060() {
    TestDrivers.surfaceShade(-605.0f,827.0f,-130.0f,2.0f,0f,0f,0f,89.963356f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,-76.2216f,88.77623f,41.695507f ) ;
  }

  @Test
  public void test1061() {
    TestDrivers.surfaceShade(-608.0f,0f,0f,0f,2.2711046f,-32.57463f,0f,-64.41458f,0f,0f,0f,0f,0f,-64.31627f,-99.41853f,6.180579f,0f,0f,0f,1654,-0.1975627f,0.06701883f,-0.9779289f,-1.2367136f,0f,0f ) ;
  }

  @Test
  public void test1062() {
    TestDrivers.surfaceShade(608.0f,0f,0f,0f,695.0f,-128.0f,0f,273.0f,0f,0f,0f,0f,0f,-581.0f,-131.0f,-423.0f,-545.0f,-463.0f,63.0f,632,42.582832f,61.039375f,21.6581f,43.77755f,0f,0f ) ;
  }

  @Test
  public void test1063() {
    TestDrivers.surfaceShade(609.0f,352.0f,-383.0f,735.0f,0f,0f,0f,-46.132305f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,-176.49088f,-44.912727f,14.675205f ) ;
  }

  @Test
  public void test1064() {
    TestDrivers.surfaceShade(61.0f,-11.0f,-615.0f,0f,68.0f,-2674.0f,0f,-397.0f,0f,0f,0f,0f,0f,140.0f,-716.0f,123.0f,0f,0f,0f,-163,-7.078865f,9.40055f,62.779144f,53.50525f,83.414024f,-5.3215938f ) ;
  }

  @Test
  public void test1065() {
    TestDrivers.surfaceShade(61.0f,426.0f,0f,0f,6.0f,89.0f,-236.0f,895.0f,0f,0f,0f,0f,0f,-893.0f,597.0f,324.0f,993.0f,694.0f,-316.0f,-559,34.245975f,17.517971f,62.10935f,-50.57637f,37.586266f,0f ) ;
  }

  @Test
  public void test1066() {
    TestDrivers.surfaceShade(612.0f,-861.0f,0f,0f,965.0f,-1604.0f,0f,0.0f,0f,0f,0f,0f,0f,-70.0f,-1126.0f,-417.0f,0f,0f,0f,394,64.91527f,98.78362f,67.1006f,-40.822357f,-45.48876f,0f ) ;
  }

  @Test
  public void test1067() {
    TestDrivers.surfaceShade(617.0f,122.0f,-299.0f,0f,1639.0f,-650.0f,0f,-968.0f,0f,0f,0f,0f,0f,502.0f,621.0f,-920.0f,0f,0f,0f,-93,-53.62165f,-23.164543f,-44.894836f,-67.21201f,89.34605f,-36.455578f ) ;
  }

  @Test
  public void test1068() {
    TestDrivers.surfaceShade(617.0f,-972.0f,-267.0f,0f,974.0f,685.0f,0f,142.0f,0f,0f,0f,0f,0f,-78.0f,534.0f,565.0f,-955.0f,61.0f,273.0f,886,53.649338f,38.64358f,-29.116858f,88.093346f,-15.513739f,100.0f ) ;
  }

  @Test
  public void test1069() {
    TestDrivers.surfaceShade(-619.0f,206.0f,54.0f,0f,281.0f,-1418.0f,0f,-1420.0f,0f,0f,0f,0f,0f,-863.0f,-447.0f,-209.0f,0f,0f,0f,72,65.20915f,-93.3044f,-69.70544f,9.047289f,32.822815f,92.82198f ) ;
  }

  @Test
  public void test1070() {
    TestDrivers.surfaceShade(-621.0f,-327.0f,-499.0f,0f,867.0f,-442.0f,0f,-767.0f,0f,0f,0f,0f,0f,1640.0f,738.0f,-910.0f,0f,0f,0f,-505,-0.41464612f,-0.21339308f,-0.6330951f,-4.5062284f,36.945206f,4.7108197f ) ;
  }

  @Test
  public void test1071() {
    TestDrivers.surfaceShade(-627.0f,392.0f,14.0f,0f,200.0f,-841.0f,0f,784.0f,0f,0f,0f,0f,0f,999.0f,953.0f,361.0f,452.0f,1474.0f,540.0f,-1517,-0.14668313f,-0.5255342f,0.6418193f,-58.242687f,-92.986984f,-73.2276f ) ;
  }

  @Test
  public void test1072() {
    TestDrivers.surfaceShade(-628.0f,480.0f,0f,0f,226.0f,-120.0f,0f,137.0f,0f,0f,0f,0f,0f,-838.0f,963.0f,-398.0f,-25.0f,196.0f,1093.0f,-836,-35.973682f,-67.396774f,-87.329506f,27.269348f,5.048221f,0f ) ;
  }

  @Test
  public void test1073() {
    TestDrivers.surfaceShade(631.0f,-1238.0f,1061.0f,0f,762.0f,-495.0f,0f,122.0f,0f,0f,0f,0f,0f,1537.0f,334.0f,-242.0f,1161.0f,859.0f,16.0f,-728,-0.19409904f,0.96929157f,0.10501305f,92.01385f,1.9688925f,58.282734f ) ;
  }

  @Test
  public void test1074() {
    TestDrivers.surfaceShade(631.0f,459.0f,0f,0f,1285.0f,-1693.0f,0f,-1265.0f,0f,0f,0f,0f,0f,1069.0f,-986.0f,1620.0f,0f,0f,0f,284,-0.42116302f,0.51051795f,0.36719784f,-100.0f,88.50228f,0f ) ;
  }

  @Test
  public void test1075() {
    TestDrivers.surfaceShade(633.0f,0f,0f,-546.0f,0f,0f,0f,50.42562f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,45.96482f,0f,0f ) ;
  }

  @Test
  public void test1076() {
    TestDrivers.surfaceShade(636.0f,161.0f,0f,903.0f,0f,0f,0f,-79.747406f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,57.726604f,64.99475f,0f ) ;
  }

  @Test
  public void test1077() {
    TestDrivers.surfaceShade(-639.0f,994.0f,2490.0f,0f,643.0f,1443.0f,0f,-75.0f,0f,0f,0f,0f,0f,1088.0f,-818.0f,-43.0f,-1203.0f,955.0f,743.0f,-28,-0.5268858f,0.4636339f,0.3173941f,11.090148f,-53.071754f,-99.838615f ) ;
  }

  @Test
  public void test1078() {
    TestDrivers.surfaceShade(640.0f,574.0f,367.0f,684.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-2,0f,0f,0f,-8.486501f,-60.79305f,-24.14199f ) ;
  }

  @Test
  public void test1079() {
    TestDrivers.surfaceShade(64.0f,-542.0f,0f,0f,153.0f,-3.0f,0f,-255.0f,0f,0f,0f,0f,0f,-498.0f,148.0f,-633.0f,0f,0f,0f,740,5.685362f,13.316467f,66.093765f,-62.603542f,-72.91997f,0f ) ;
  }

  @Test
  public void test1080() {
    TestDrivers.surfaceShade(641.0f,1996.0f,0f,0f,1272.0f,-2990.0f,0f,-84.0f,0f,0f,0f,0f,0f,28.0f,-986.0f,117.0f,0f,0f,0f,-419,-0.8405783f,-0.2602946f,-1.9924297f,124.04677f,-162.94826f,0f ) ;
  }

  @Test
  public void test1081() {
    TestDrivers.surfaceShade(645.0f,0f,371.0f,0f,3683.0f,2655.0f,0f,-2582.0f,0f,0f,0f,0f,0f,105.0f,1472.0f,-676.0f,229.0f,-1639.0f,1369.0f,1399,0.04024747f,0.15469514f,0.98714215f,14.591346f,0f,-100.0f ) ;
  }

  @Test
  public void test1082() {
    TestDrivers.surfaceShade(65.0f,59.0f,714.0f,-361.0f,0f,0f,0f,-41.953537f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-4,0f,0f,0f,83.98839f,197.0676f,-36.057716f ) ;
  }

  @Test
  public void test1083() {
    TestDrivers.surfaceShade(-651.0f,0f,0f,0f,87.0f,917.0f,-979.0f,56.0f,0f,0f,0f,0f,0f,-135.0f,719.0f,-924.0f,642.0f,-752.0f,-685.0f,-222,-97.658844f,1.245432f,90.881775f,-84.37725f,0f,0f ) ;
  }

  @Test
  public void test1084() {
    TestDrivers.surfaceShade(659.0f,379.0f,0f,0f,1740.0f,359.0f,394.0f,-320.0f,0f,0f,0f,0f,0f,-824.0f,1049.0f,946.0f,-17.0f,1169.0f,-242.0f,328,0.90935886f,0.05285486f,0.14340068f,-100.0f,-39.03614f,0f ) ;
  }

  @Test
  public void test1085() {
    TestDrivers.surfaceShade(659.0f,-489.0f,-322.0f,531.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-17.673756f,-61.034466f,24.451403f ) ;
  }

  @Test
  public void test1086() {
    TestDrivers.surfaceShade(-660.0f,1241.0f,-2114.0f,0f,4.0f,733.0f,0f,150.0f,0f,0f,0f,0f,0f,-846.0f,694.0f,318.0f,2152.0f,1737.0f,276.0f,585,-38.172386f,-7.1879573f,-85.86603f,-100.0f,32.519257f,63.39321f ) ;
  }

  @Test
  public void test1087() {
    TestDrivers.surfaceShade(661.0f,-1185.0f,-1329.0f,0f,506.0f,178.0f,0f,-437.0f,0f,0f,0f,0f,0f,819.0f,901.0f,672.0f,634.0f,-1569.0f,-99.0f,-239,-34.27525f,-8.504546f,16.194384f,21.866379f,-76.25906f,38.048622f ) ;
  }

  @Test
  public void test1088() {
    TestDrivers.surfaceShade(668.0f,91.0f,736.0f,0f,1334.0f,434.0f,0f,213.0f,0f,0f,0f,0f,0f,-810.0f,996.0f,-418.0f,-466.0f,-58.0f,290.0f,922,86.41526f,88.85239f,44.259846f,-48.46306f,3.88007f,28.581303f ) ;
  }

  @Test
  public void test1089() {
    TestDrivers.surfaceShade(-671.0f,704.0f,77.0f,0f,884.0f,-61.0f,0f,-443.0f,0f,0f,0f,0f,0f,-659.0f,248.0f,-14.0f,0f,0f,0f,874,19.439007f,43.522415f,94.14606f,6.4160156f,4.818439E-10f,95.85957f ) ;
  }

  @Test
  public void test1090() {
    TestDrivers.surfaceShade(-676.0f,613.0f,0f,0f,1083.0f,-505.0f,0f,-2.0f,0f,0f,0f,0f,0f,1779.0f,140.0f,1107.0f,0f,0f,0f,130,-0.79306775f,1.1104261f,1.1340631f,-25.411f,-91.41684f,0f ) ;
  }

  @Test
  public void test1091() {
    TestDrivers.surfaceShade(677.0f,797.0f,0f,0f,1706.0f,407.0f,0f,-1329.0f,0f,0f,0f,0f,0f,1941.0f,456.0f,1714.0f,-1166.0f,-920.0f,-3168.0f,640,-0.70903486f,0.41725227f,-0.56848055f,-100.0f,98.89554f,0f ) ;
  }

  @Test
  public void test1092() {
    TestDrivers.surfaceShade(-678.0f,0f,0f,0f,39.81457f,-50.41784f,0f,0.0f,0f,0f,0f,0f,0f,-43.81974f,-20.732779f,74.048386f,0f,0f,0f,-948,99.657555f,-9.881523f,-54.550613f,56.387753f,0f,0f ) ;
  }

  @Test
  public void test1093() {
    TestDrivers.surfaceShade(678.0f,400.0f,0f,0f,24.0f,80.0f,0f,2623.0f,0f,0f,0f,0f,0f,403.0f,-1401.0f,172.0f,-1845.0f,72.0f,-829.0f,614,0.34331518f,0.08443001f,-0.11668508f,-14.288814f,0.41445193f,0f ) ;
  }

  @Test
  public void test1094() {
    TestDrivers.surfaceShade(679.0f,169.0f,0f,0f,26.0f,139.0f,0f,905.0f,0f,0f,0f,0f,0f,349.0f,-1814.0f,908.0f,-831.0f,1057.0f,-1391.0f,532,-93.04914f,32.153168f,100.0f,8.427731f,23.935179f,0f ) ;
  }

  @Test
  public void test1095() {
    TestDrivers.surfaceShade(679.0f,-218.0f,0f,0f,935.0f,2794.0f,0f,1210.0f,0f,0f,0f,0f,0f,433.0f,756.0f,1606.0f,-1283.0f,1625.0f,-852.0f,-1915,0.9331503f,-0.38412344f,-0.07100759f,-26.060968f,0.7291388f,0f ) ;
  }

  @Test
  public void test1096() {
    TestDrivers.surfaceShade(-68.0f,0f,0f,0f,961.0f,1643.0f,-879.0f,1156.0f,0f,0f,0f,0f,0f,-1033.0f,547.0f,721.0f,-180.0f,-70.0f,-142.0f,-274,-0.24236463f,0.11513349f,-0.85823053f,100.0f,0f,0f ) ;
  }

  @Test
  public void test1097() {
    TestDrivers.surfaceShade(681.0f,-728.0f,0f,0f,276.0f,-319.0f,0f,-511.0f,0f,0f,0f,0f,0f,-172.0f,727.0f,-282.0f,0f,0f,0f,-411,29.280735f,-83.61254f,55.020428f,-4.377691f,-61.110603f,0f ) ;
  }

  @Test
  public void test1098() {
    TestDrivers.surfaceShade(687.0f,0f,0f,747.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,88.94216f,0f,0f ) ;
  }

  @Test
  public void test1099() {
    TestDrivers.surfaceShade(-690.0f,-454.0f,0f,0f,2953.0f,177.0f,0f,-481.0f,0f,0f,0f,0f,0f,-633.0f,-1122.0f,71.0f,-1106.0f,760.0f,1163.0f,-1169,0.54721916f,0.23696351f,-0.98873913f,0.5471428f,69.75026f,0f ) ;
  }

  @Test
  public void test1100() {
    TestDrivers.surfaceShade(692.0f,0f,0f,0f,40.0f,460.0f,0f,-1070.0f,0f,0f,0f,0f,0f,4.0f,-1171.0f,-1541.0f,-623.0f,122.0f,-261.0f,498,-0.05885016f,-0.31440726f,0.23876412f,99.99999f,0f,0f ) ;
  }

  @Test
  public void test1101() {
    TestDrivers.surfaceShade(697.0f,-191.0f,0f,0f,622.0f,-250.0f,0f,2729.0f,0f,0f,0f,0f,0f,791.0f,-2650.0f,815.0f,166.0f,-772.0f,752.0f,1508,-0.24935162f,0.5266884f,0.37075755f,-100.0f,-100.0f,0f ) ;
  }

  @Test
  public void test1102() {
    TestDrivers.surfaceShade(698.0f,-512.0f,-538.0f,0f,872.0f,1839.0f,0f,-323.0f,0f,0f,0f,0f,0f,362.0f,206.0f,-473.0f,-842.0f,-838.0f,-1000.0f,-571,86.38606f,-1.8633442f,65.302124f,20.782042f,84.58654f,22.248114f ) ;
  }

  @Test
  public void test1103() {
    TestDrivers.surfaceShade(70.0f,94.0f,181.0f,-494.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-109.29593f,77.46584f,-70.72705f ) ;
  }

  @Test
  public void test1104() {
    TestDrivers.surfaceShade(-705.0f,759.0f,249.0f,0f,172.0f,-1008.0f,0f,507.0f,0f,0f,0f,0f,0f,895.0f,-518.0f,-920.0f,132.0f,-412.0f,-237.0f,151,-0.24524543f,0.106501296f,0.81573683f,97.92491f,60.81467f,25.419323f ) ;
  }

  @Test
  public void test1105() {
    TestDrivers.surfaceShade(706.0f,90.0f,0f,0f,1550.0f,154.0f,0f,-879.0f,0f,0f,0f,0f,0f,-189.0f,-469.0f,-433.0f,68.0f,26.0f,1665.0f,773,-59.49965f,33.113f,-9.895064f,68.36985f,56.860706f,0f ) ;
  }

  @Test
  public void test1106() {
    TestDrivers.surfaceShade(-707.0f,110.0f,0f,0f,851.0f,771.0f,0f,965.0f,0f,0f,0f,0f,0f,291.0f,712.0f,358.0f,-411.0f,1562.0f,219.0f,-670,64.87296f,-26.6672f,0.3044193f,72.69856f,-18.401037f,0f ) ;
  }

  @Test
  public void test1107() {
    TestDrivers.surfaceShade(-708.0f,-909.0f,-489.0f,0f,179.0f,566.0f,0f,-319.0f,0f,0f,0f,0f,0f,-469.0f,-1042.0f,952.0f,265.0f,95.0f,-884.0f,349,-0.2467659f,0.63785106f,-0.7165048f,1.059774f,-50.17425f,-100.0f ) ;
  }

  @Test
  public void test1108() {
    TestDrivers.surfaceShade(-7.0f,-605.0f,0f,0f,747.0f,-228.0f,0f,-69.0f,0f,0f,0f,0f,0f,-314.0f,895.0f,948.0f,0f,0f,0f,254,84.22575f,98.01134f,-64.63424f,-22.929892f,95.63165f,0f ) ;
  }

  @Test
  public void test1109() {
    TestDrivers.surfaceShade(711.0f,1154.0f,0f,0f,590.0f,-478.0f,0f,-139.0f,0f,0f,0f,0f,0f,673.0f,-1194.0f,-89.0f,0f,0f,0f,-961,-0.7454235f,0.013136876f,-0.4876224f,9.918736f,-9.296576f,0f ) ;
  }

  @Test
  public void test1110() {
    TestDrivers.surfaceShade(-711.0f,632.0f,659.0f,0f,891.0f,-1368.0f,0f,-256.0f,0f,0f,0f,0f,0f,525.0f,-9.0f,369.0f,0f,0f,0f,495,-0.099858455f,-0.23486511f,0.13634662f,23.385548f,100.0f,91.25428f ) ;
  }

  @Test
  public void test1111() {
    TestDrivers.surfaceShade(-713.0f,0f,0f,0f,702.0f,936.0f,773.0f,-619.0f,0f,0f,0f,0f,0f,-473.0f,888.0f,558.0f,-275.0f,763.0f,-307.0f,751,-0.34405115f,42.566017f,-77.22865f,-28.987017f,0f,0f ) ;
  }

  @Test
  public void test1112() {
    TestDrivers.surfaceShade(713.0f,-69.0f,85.0f,0f,786.0f,-219.0f,0f,-346.0f,0f,0f,0f,0f,0f,535.0f,323.0f,150.0f,0f,0f,0f,-937,-58.883663f,81.98746f,-64.61735f,28.991697f,-76.79546f,89.224655f ) ;
  }

  @Test
  public void test1113() {
    TestDrivers.surfaceShade(714.0f,-202.0f,0f,0f,937.0f,-584.0f,0f,0.0f,0f,0f,0f,0f,0f,-773.0f,-1731.0f,-1743.0f,0f,0f,0f,-1784,46.960445f,100.0f,-19.653385f,-38.208755f,95.5996f,0f ) ;
  }

  @Test
  public void test1114() {
    TestDrivers.surfaceShade(-715.0f,1181.0f,0f,0f,586.0f,-151.0f,0f,1247.0f,0f,0f,0f,0f,0f,-580.0f,-603.0f,336.0f,747.0f,-326.0f,-1911.0f,457,1.5256745f,-1.941871f,-0.8513602f,44.252388f,57.455585f,0f ) ;
  }

  @Test
  public void test1115() {
    TestDrivers.surfaceShade(716.0f,1682.0f,1063.0f,0f,972.0f,1073.0f,0f,1183.0f,0f,0f,0f,0f,0f,-179.0f,-1955.0f,-2018.0f,2376.0f,-785.0f,818.0f,-1524,0.020370366f,-0.015293767f,0.24258718f,98.903076f,11.532157f,60.72668f ) ;
  }

  @Test
  public void test1116() {
    TestDrivers.surfaceShade(718.0f,-1186.0f,-388.0f,0f,612.0f,354.0f,0f,478.0f,0f,0f,0f,0f,0f,-190.0f,667.0f,-442.0f,-531.0f,170.0f,-419.0f,476,-18.08772f,33.743374f,58.695694f,-53.843014f,13.87471f,20.790255f ) ;
  }

  @Test
  public void test1117() {
    TestDrivers.surfaceShade(-718.0f,1200.0f,220.0f,0f,1158.0f,204.0f,-13.0f,-25.0f,0f,0f,0f,0f,0f,675.0f,-841.0f,370.0f,183.0f,-615.0f,536.0f,312,-0.85130745f,0.29664773f,-0.41059676f,-100.0f,39.59929f,-86.67951f ) ;
  }

  @Test
  public void test1118() {
    TestDrivers.surfaceShade(-723.0f,-767.0f,0f,0f,298.0f,997.0f,0f,50.0f,0f,0f,0f,0f,0f,702.0f,-847.0f,1330.0f,206.0f,-1211.0f,-513.0f,365,-27.20463f,86.96754f,69.74363f,-45.31069f,-39.871956f,0f ) ;
  }

  @Test
  public void test1119() {
    TestDrivers.surfaceShade(726.0f,-103.0f,0f,64.0f,0f,0f,0f,97.27962f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,2.1522039E-5f,-1.5169903E-4f,0f ) ;
  }

  @Test
  public void test1120() {
    TestDrivers.surfaceShade(-726.0f,441.0f,0f,-159.0f,0f,0f,0f,-52.212765f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,3.584724f,-1.426147E-5f,0f ) ;
  }

  @Test
  public void test1121() {
    TestDrivers.surfaceShade(728.0f,0f,0f,0f,721.0f,-382.0f,0f,148.0f,0f,0f,0f,0f,0f,117.0f,-137.0f,117.0f,2215.0f,182.0f,-597.0f,451,-0.82518727f,100.0f,100.0f,3.8130604E-10f,0f,0f ) ;
  }

  @Test
  public void test1122() {
    TestDrivers.surfaceShade(728.0f,-709.0f,0f,0f,874.0f,-1181.0f,0f,867.0f,0f,0f,0f,0f,0f,132.0f,1830.0f,758.0f,1425.0f,-919.0f,241.0f,-149,-0.46579087f,0.050046545f,-0.8320622f,-4.4889474f,-10.465577f,0f ) ;
  }

  @Test
  public void test1123() {
    TestDrivers.surfaceShade(-73.0f,465.0f,0f,0f,1000.0f,-4.0f,0f,-684.0f,0f,0f,0f,0f,0f,-1397.0f,-1006.0f,-177.0f,0f,0f,0f,687,69.06159f,32.238327f,-75.64205f,-28.385798f,166.41176f,0f ) ;
  }

  @Test
  public void test1124() {
    TestDrivers.surfaceShade(732.0f,1858.0f,0f,0f,1497.0f,-1.0f,0f,-2325.0f,0f,0f,0f,0f,0f,1067.0f,-84.0f,-261.0f,0f,0f,0f,-502,0.06301165f,0.101490185f,0.22493584f,1.8626481f,36.70799f,0f ) ;
  }

  @Test
  public void test1125() {
    TestDrivers.surfaceShade(732.0f,907.0f,-1034.0f,0f,265.0f,956.0f,0f,906.0f,0f,0f,0f,0f,0f,744.0f,502.0f,-681.0f,-393.0f,-759.0f,349.0f,298,-43.669273f,85.127014f,26.526821f,-24.544306f,5.3197063E-10f,-48.06385f ) ;
  }

  @Test
  public void test1126() {
    TestDrivers.surfaceShade(-738.0f,-1261.0f,0f,0f,1569.0f,0.0f,0f,-2004.0f,0f,0f,0f,0f,0f,220.0f,-1584.0f,690.0f,0f,0f,0f,981,-3.122542E-4f,0.73454237f,0.02930931f,87.13681f,100.0f,0f ) ;
  }

  @Test
  public void test1127() {
    TestDrivers.surfaceShade(-738.0f,382.0f,0f,0f,331.0f,787.0f,-227.0f,706.0f,0f,0f,0f,0f,0f,511.0f,-511.0f,81.0f,-947.0f,527.0f,658.0f,-964,31.56958f,42.98091f,71.98999f,-83.29448f,-14.339328f,0f ) ;
  }

  @Test
  public void test1128() {
    TestDrivers.surfaceShade(740.0f,0f,0f,0f,387.0f,464.0f,0f,429.0f,0f,0f,0f,0f,0f,-188.0f,879.0f,-778.0f,-37.0f,-638.0f,766.0f,-419,37.96951f,5.60234f,31.19044f,30.386591f,0f,0f ) ;
  }

  @Test
  public void test1129() {
    TestDrivers.surfaceShade(741.0f,-643.0f,0f,0f,431.0f,910.0f,0f,136.0f,0f,0f,0f,0f,0f,-50.0f,169.0f,-11.0f,1263.0f,100.0f,314.0f,747,0.6361458f,-0.06933783f,0.059571262f,50.497036f,-78.23963f,0f ) ;
  }

  @Test
  public void test1130() {
    TestDrivers.surfaceShade(743.0f,533.0f,0f,0f,364.0f,-1441.0f,0f,291.0f,0f,0f,0f,0f,0f,-400.0f,906.0f,599.0f,-220.0f,622.0f,912.0f,561,-94.00133f,14.531383f,-84.75119f,-100.0f,-87.26912f,0f ) ;
  }

  @Test
  public void test1131() {
    TestDrivers.surfaceShade(-748.0f,-134.0f,0f,0f,1455.0f,1149.0f,-73.0f,-732.0f,0f,0f,0f,0f,0f,734.0f,-362.0f,878.0f,1731.0f,-1837.0f,-353.0f,-186,-0.22329593f,-0.83937806f,-0.3537659f,-15.28009f,-8.321435f,0f ) ;
  }

  @Test
  public void test1132() {
    TestDrivers.surfaceShade(-754.0f,0f,0f,0f,28.683191f,-82.29696f,0f,0.0f,0f,0f,0f,0f,0f,-24.011868f,42.38081f,-88.26399f,0f,0f,0f,226,-0.0030757927f,-0.04798657f,0.39703852f,19.54875f,0f,0f ) ;
  }

  @Test
  public void test1133() {
    TestDrivers.surfaceShade(759.0f,-2481.0f,0f,-70.0f,0f,0f,0f,-91.740295f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,-1.8821758E-5f,6.494368f,0f ) ;
  }

  @Test
  public void test1134() {
    TestDrivers.surfaceShade(-76.0f,177.0f,811.0f,-486.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,56.461338f,36.79763f,100.0f ) ;
  }

  @Test
  public void test1135() {
    TestDrivers.surfaceShade(-761.0f,-86.0f,-845.0f,111.0f,0f,0f,0f,44.642754f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-81.34331f,75.12712f,39.277985f ) ;
  }

  @Test
  public void test1136() {
    TestDrivers.surfaceShade(-763.0f,-1664.0f,0f,911.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,90.85723f,-5.8844795f,0f ) ;
  }

  @Test
  public void test1137() {
    TestDrivers.surfaceShade(-764.0f,0f,0f,0f,-478.0f,-782.0f,964.0f,530.0f,0f,0f,0f,0f,0f,-989.0f,-434.0f,-655.0f,-493.0f,932.0f,886.0f,437,-90.50012f,-44.952065f,45.69116f,-15.980889f,0f,0f ) ;
  }

  @Test
  public void test1138() {
    TestDrivers.surfaceShade(-77.0f,-1414.0f,0f,0f,1479.0f,1.0f,0f,13.0f,0f,0f,0f,0f,0f,471.0f,-1787.0f,94.0f,0f,0f,0f,-26,-0.068163894f,0.025447195f,-0.21015932f,-43.27195f,22.99153f,0f ) ;
  }

  @Test
  public void test1139() {
    TestDrivers.surfaceShade(774.0f,0f,0f,558.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,2.3153937E-6f,0f,0f ) ;
  }

  @Test
  public void test1140() {
    TestDrivers.surfaceShade(-776.0f,-1827.0f,290.0f,-576.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,2.2372567E-6f,-16.933949f,55.46362f ) ;
  }

  @Test
  public void test1141() {
    TestDrivers.surfaceShade(776.0f,261.0f,598.0f,0f,301.0f,-823.0f,0f,1015.0f,0f,0f,0f,0f,0f,206.0f,-173.0f,-49.0f,723.0f,-1362.0f,-410.0f,465,-101.32787f,24.321732f,92.98591f,71.89935f,81.88841f,-8.016089f ) ;
  }

  @Test
  public void test1142() {
    TestDrivers.surfaceShade(780.0f,-568.0f,0f,0f,22.0f,-2334.0f,0f,1680.0f,0f,0f,0f,0f,0f,904.0f,-156.0f,-946.0f,-1368.0f,-2060.0f,155.0f,1971,30.65583f,-97.067375f,45.301674f,92.7674f,-35.565056f,0f ) ;
  }

  @Test
  public void test1143() {
    TestDrivers.surfaceShade(79.0f,2293.0f,-52.0f,0f,1437.0f,-568.0f,0f,0.0f,0f,0f,0f,0f,0f,527.0f,-355.0f,490.0f,0f,0f,0f,-1775,77.13937f,30.596077f,-77.944626f,-100.0f,-33.962337f,43.296444f ) ;
  }

  @Test
  public void test1144() {
    TestDrivers.surfaceShade(-79.0f,942.0f,0f,0f,192.0f,1080.0f,0f,-1348.0f,0f,0f,0f,0f,0f,562.0f,-1776.0f,-241.0f,-143.0f,1757.0f,464.0f,-107,-0.28498742f,-0.082797624f,-0.054416377f,100.0f,2.9049795f,0f ) ;
  }

  @Test
  public void test1145() {
    TestDrivers.surfaceShade(-792.0f,0f,0f,0f,169.0f,830.0f,0f,439.0f,0f,0f,0f,0f,0f,-298.0f,355.0f,375.0f,-467.0f,294.0f,-257.0f,-739,75.1531f,43.94228f,18.12297f,84.40806f,0f,0f ) ;
  }

  @Test
  public void test1146() {
    TestDrivers.surfaceShade(792.0f,-622.0f,-243.0f,0f,455.0f,-4.0f,0f,-290.0f,0f,0f,0f,0f,0f,-1063.0f,-736.0f,-445.0f,0f,0f,0f,-709,0.7208934f,0.04344551f,0.5381401f,-37.737324f,65.84327f,-28.55413f ) ;
  }

  @Test
  public void test1147() {
    TestDrivers.surfaceShade(794.0f,452.0f,0f,535.0f,0f,0f,0f,-109.13536f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-3,0f,0f,0f,25.61033f,-83.41387f,0f ) ;
  }

  @Test
  public void test1148() {
    TestDrivers.surfaceShade(795.0f,0f,0f,0f,20.176481f,0.0f,0f,-80.023834f,0f,0f,0f,0f,0f,15.665579f,-12.887579f,38.606655f,0f,0f,0f,776,-51.396362f,-60.19659f,-34.91671f,-25.151901f,0f,0f ) ;
  }

  @Test
  public void test1149() {
    TestDrivers.surfaceShade(795.0f,216.0f,-211.0f,0f,108.0f,-60.0f,0f,1.0f,0f,0f,0f,0f,0f,-981.0f,144.0f,-960.0f,0f,0f,0f,365,27.761456f,-69.0972f,23.760952f,-51.11842f,-39.47998f,-33.72923f ) ;
  }

  @Test
  public void test1150() {
    TestDrivers.surfaceShade(-801.0f,-742.0f,289.0f,0f,1346.0f,-371.0f,0f,-3.0f,0f,0f,0f,0f,0f,720.0f,-216.0f,-105.0f,0f,0f,0f,-249,-58.177963f,72.21324f,71.639114f,50.62228f,-55.85645f,80.06046f ) ;
  }

  @Test
  public void test1151() {
    TestDrivers.surfaceShade(-805.0f,-932.0f,0f,0f,738.0f,-1236.0f,0f,-366.0f,0f,0f,0f,0f,0f,1603.0f,224.0f,-1680.0f,0f,0f,0f,-1217,-1.0932276f,-1.9628798f,-1.3048387f,-40.528835f,-100.0f,0f ) ;
  }

  @Test
  public void test1152() {
    TestDrivers.surfaceShade(-807.0f,-637.0f,0f,0f,960.0f,-1.0f,0f,-853.0f,0f,0f,0f,0f,0f,715.0f,688.0f,1473.0f,0f,0f,0f,-96,-0.24827921f,-0.29657477f,-0.057378706f,-20.596663f,11.380765f,0f ) ;
  }

  @Test
  public void test1153() {
    TestDrivers.surfaceShade(8.0f,0f,0f,0f,19.0f,-1779.0f,0f,1247.0f,0f,0f,0f,0f,0f,-130.0f,821.0f,1309.0f,411.0f,-959.0f,-606.0f,264,0.49702543f,-0.8660742f,0.05367671f,1.0547235E-5f,0f,0f ) ;
  }

  @Test
  public void test1154() {
    TestDrivers.surfaceShade(-815.0f,-282.0f,0f,0f,352.0f,23.0f,-572.0f,-755.0f,0f,0f,0f,0f,0f,7.0f,232.0f,242.0f,703.0f,56.0f,31.0f,942,-46.3574f,9.655231f,-35.22006f,-30.517252f,22.208778f,0f ) ;
  }

  @Test
  public void test1155() {
    TestDrivers.surfaceShade(-818.0f,1181.0f,536.0f,0f,246.0f,-602.0f,0f,664.0f,0f,0f,0f,0f,0f,-195.0f,742.0f,70.0f,-338.0f,782.0f,404.0f,-288,-26.733944f,-25.465221f,-22.564236f,69.95926f,-62.9644f,-7.970442E-10f ) ;
  }

  @Test
  public void test1156() {
    TestDrivers.surfaceShade(82.0f,-16.0f,0f,48.0f,0f,0f,0f,73.337135f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,2.5406503E-4f,22.803543f,0f ) ;
  }

  @Test
  public void test1157() {
    TestDrivers.surfaceShade(-824.0f,-614.0f,953.0f,0f,680.0f,819.0f,818.0f,456.0f,0f,0f,0f,0f,0f,-352.0f,180.0f,400.0f,722.0f,794.0f,40.0f,157,-43.752254f,56.581505f,-4.193194f,-39.52625f,49.99319f,-36.00515f ) ;
  }

  @Test
  public void test1158() {
    TestDrivers.surfaceShade(826.0f,-2350.0f,1181.0f,0f,874.0f,-20.0f,0f,-107.0f,0f,0f,0f,0f,0f,-257.0f,68.0f,-513.0f,0f,0f,0f,-199,43.18856f,63.979633f,-13.155643f,3.4453473f,24.951057f,100.0f ) ;
  }

  @Test
  public void test1159() {
    TestDrivers.surfaceShade(827.0f,0f,0f,0f,1144.0f,1648.0f,0f,644.0f,0f,0f,0f,0f,0f,861.0f,-824.0f,-102.0f,1099.0f,855.0f,968.0f,-775,-35.556934f,-47.025352f,79.7488f,-39.84438f,0f,0f ) ;
  }

  @Test
  public void test1160() {
    TestDrivers.surfaceShade(827.0f,0f,0f,0f,23.0f,987.0f,0f,1.0f,0f,0f,0f,0f,0f,843.0f,-177.0f,-777.0f,-775.0f,257.0f,-592.0f,683,0.44670394f,-0.60707873f,0.62294f,100.0f,0f,0f ) ;
  }

  @Test
  public void test1161() {
    TestDrivers.surfaceShade(830.0f,-274.0f,-376.0f,0f,853.0f,653.0f,0f,-1511.0f,0f,0f,0f,0f,0f,134.0f,-486.0f,461.0f,247.0f,675.0f,-1795.0f,1395,-19.688025f,29.864061f,37.206352f,61.931046f,7.3703365f,-68.598404f ) ;
  }

  @Test
  public void test1162() {
    TestDrivers.surfaceShade(-832.0f,-195.0f,255.0f,0f,1060.0f,1521.0f,-425.0f,-576.0f,0f,0f,0f,0f,0f,761.0f,-1557.0f,207.0f,480.0f,-350.0f,-233.0f,-48,0.23880512f,0.6722308f,0.2933518f,9.936844f,53.063343f,-77.07821f ) ;
  }

  @Test
  public void test1163() {
    TestDrivers.surfaceShade(-833.0f,525.0f,-708.0f,0f,369.0f,-283.0f,0f,167.0f,0f,0f,0f,0f,0f,-692.0f,199.0f,58.0f,360.0f,96.0f,-574.0f,-816,-24.422604f,-66.4307f,-63.460896f,75.64011f,-95.3581f,70.2684f ) ;
  }

  @Test
  public void test1164() {
    TestDrivers.surfaceShade(-833.0f,627.0f,0f,205.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,23.13717f,-6.244587f,0f ) ;
  }

  @Test
  public void test1165() {
    TestDrivers.surfaceShade(-835.0f,0f,0f,0f,671.0f,645.0f,-261.0f,-265.0f,0f,0f,0f,0f,0f,625.0f,-2301.0f,581.0f,963.0f,-641.0f,-590.0f,992,0.29078737f,0.49958593f,-0.33999f,53.263668f,0f,0f ) ;
  }

  @Test
  public void test1166() {
    TestDrivers.surfaceShade(-840.0f,489.0f,210.0f,0f,997.0f,-712.0f,0f,237.0f,0f,0f,0f,0f,0f,-994.0f,-405.0f,-131.0f,511.0f,-708.0f,-543.0f,-231,-6.6260853f,15.140996f,3.4673703f,-47.285587f,73.30764f,96.72115f ) ;
  }

  @Test
  public void test1167() {
    TestDrivers.surfaceShade(843.0f,0f,0f,0f,760.0f,680.0f,-1346.0f,579.0f,0f,0f,0f,0f,0f,-372.0f,709.0f,-144.0f,-654.0f,-523.0f,-784.0f,941,92.20898f,28.070154f,-100.0f,94.070175f,0f,0f ) ;
  }

  @Test
  public void test1168() {
    TestDrivers.surfaceShade(844.0f,26.0f,-77.0f,0f,995.0f,-350.0f,0f,-1551.0f,0f,0f,0f,0f,0f,-602.0f,1652.0f,-61.0f,0f,0f,0f,54,0.8292881f,-0.40792328f,0.21936436f,88.7136f,19.024008f,-94.56635f ) ;
  }

  @Test
  public void test1169() {
    TestDrivers.surfaceShade(851.0f,817.0f,0f,0f,2154.0f,-994.0f,0f,1.0f,0f,0f,0f,0f,0f,790.0f,96.0f,-72.0f,0f,0f,0f,26,-1.739586f,24.115421f,16.988249f,49.175255f,72.05689f,0f ) ;
  }

  @Test
  public void test1170() {
    TestDrivers.surfaceShade(-852.0f,0f,0f,-403.0f,0f,0f,0f,7.5236745f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,19.23689f,0f,0f ) ;
  }

  @Test
  public void test1171() {
    TestDrivers.surfaceShade(852.0f,993.0f,0f,0f,555.0f,-112.0f,0f,768.0f,0f,0f,0f,0f,0f,-857.0f,219.0f,649.0f,155.0f,495.0f,-127.0f,345,-87.47128f,-66.68317f,-96.18096f,-79.82723f,-38.154995f,0f ) ;
  }

  @Test
  public void test1172() {
    TestDrivers.surfaceShade(86.0f,-750.0f,0f,0f,-579.0f,-756.0f,647.0f,741.0f,0f,0f,0f,0f,0f,-145.0f,940.0f,-996.0f,-56.0f,-761.0f,343.0f,125,-22.58779f,-43.045002f,-8.482349f,65.34002f,-34.797028f,0f ) ;
  }

  @Test
  public void test1173() {
    TestDrivers.surfaceShade(-863.0f,139.0f,0f,0f,1929.0f,457.0f,0f,1113.0f,0f,0f,0f,0f,0f,-967.0f,726.0f,-925.0f,1084.0f,663.0f,75.0f,-518,4.013397f,-68.37806f,-57.863167f,100.0f,83.53673f,0f ) ;
  }

  @Test
  public void test1174() {
    TestDrivers.surfaceShade(-865.0f,1465.0f,0f,0f,174.0f,-2495.0f,0f,4.0f,0f,0f,0f,0f,0f,654.0f,-1101.0f,-1337.0f,0f,0f,0f,865,-0.099235125f,-0.2508658f,0.15804298f,-100.0f,100.0f,0f ) ;
  }

  @Test
  public void test1175() {
    TestDrivers.surfaceShade(-866.0f,520.0f,-1072.0f,-667.0f,0f,0f,0f,-87.09603f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,28.864866f,-77.05471f,43.21991f ) ;
  }

  @Test
  public void test1176() {
    TestDrivers.surfaceShade(-866.0f,-930.0f,0f,0f,511.0f,860.0f,887.0f,-566.0f,0f,0f,0f,0f,0f,742.0f,989.0f,374.0f,511.0f,98.0f,-614.0f,201,-94.140236f,-71.95163f,-53.686325f,69.22684f,29.732286f,0f ) ;
  }

  @Test
  public void test1177() {
    TestDrivers.surfaceShade(-868.0f,-834.0f,-267.0f,0f,857.0f,-145.0f,0f,-125.0f,0f,0f,0f,0f,0f,-672.0f,772.0f,165.0f,0f,0f,0f,-266,-3.239072f,2.0951338f,-22.994543f,138.26126f,20.714418f,-50.238f ) ;
  }

  @Test
  public void test1178() {
    TestDrivers.surfaceShade(873.0f,0f,0f,0f,645.0f,1032.0f,-337.0f,-1194.0f,0f,0f,0f,0f,0f,-834.0f,969.0f,321.0f,-1178.0f,-164.0f,692.0f,-689,-0.0019131022f,0.0057422733f,-0.13601977f,72.41773f,0f,0f ) ;
  }

  @Test
  public void test1179() {
    TestDrivers.surfaceShade(-874.0f,638.0f,0f,0f,653.0f,1.0f,0f,-45.0f,0f,0f,0f,0f,0f,-1509.0f,909.0f,93.0f,0f,0f,0f,614,0.74722797f,-0.29104564f,-0.5948188f,-64.01242f,87.66837f,0f ) ;
  }

  @Test
  public void test1180() {
    TestDrivers.surfaceShade(877.0f,-528.0f,0.0f,0f,48.0f,431.0f,0f,-476.0f,0f,0f,0f,0f,0f,699.0f,596.0f,-732.0f,422.0f,-145.0f,927.0f,-4,-83.49325f,-98.182335f,-112.349434f,81.00943f,-46.186394f,-8.847608f ) ;
  }

  @Test
  public void test1181() {
    TestDrivers.surfaceShade(880.0f,-441.0f,800.0f,0f,388.0f,-313.0f,0f,256.0f,0f,0f,0f,0f,0f,705.0f,-419.0f,-559.0f,745.0f,461.0f,64.0f,19,60.72683f,35.256824f,50.717117f,-53.55126f,92.95817f,-18.41434f ) ;
  }

  @Test
  public void test1182() {
    TestDrivers.surfaceShade(-881.0f,536.0f,0f,0f,676.0f,-2770.0f,0f,-774.0f,0f,0f,0f,0f,0f,-241.0f,-461.0f,-912.0f,0f,0f,0f,-739,-35.038673f,-4.5125775f,11.540153f,-27.041739f,44.419556f,0f ) ;
  }

  @Test
  public void test1183() {
    TestDrivers.surfaceShade(883.0f,-1034.0f,0f,7.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,1.6178611E-4f,-5.451393f,0f ) ;
  }

  @Test
  public void test1184() {
    TestDrivers.surfaceShade(890.0f,-18.0f,-54.0f,-55.0f,0f,0f,0f,16.390718f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-2.042901E-5f,0.001010101f,-61.80893f ) ;
  }

  @Test
  public void test1185() {
    TestDrivers.surfaceShade(-890.0f,-594.0f,-1095.0f,0f,4.0f,1722.0f,0f,-767.0f,0f,0f,0f,0f,0f,248.0f,212.0f,-16.0f,-472.0f,-50.0f,-726.0f,136,0.08144637f,-0.08689344f,0.11108163f,69.69463f,-45.01906f,-15.634604f ) ;
  }

  @Test
  public void test1186() {
    TestDrivers.surfaceShade(-892.0f,390.0f,-1759.0f,0f,1787.0f,1071.0f,0f,434.0f,0f,0f,0f,0f,0f,160.0f,1773.0f,1135.0f,639.0f,-2340.0f,-142.0f,87,-0.07895176f,0.5527556f,-1.2714263f,100.0f,-99.29483f,100.0f ) ;
  }

  @Test
  public void test1187() {
    TestDrivers.surfaceShade(-900.0f,539.0f,0f,0f,1732.0f,-6.0f,0f,-371.0f,0f,0f,0f,0f,0f,-282.0f,1210.0f,-736.0f,0f,0f,0f,1815,3.353966f,0.20016691f,-0.9560006f,43.987625f,31.203339f,0f ) ;
  }

  @Test
  public void test1188() {
    TestDrivers.surfaceShade(-90.0f,292.0f,347.0f,-1044.0f,0f,0f,0f,-19.51176f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,1.0642827E-5f,81.759865f,-2.7603874E-6f ) ;
  }

  @Test
  public void test1189() {
    TestDrivers.surfaceShade(-904.0f,-597.0f,0f,0f,412.0f,713.0f,0f,767.0f,0f,0f,0f,0f,0f,975.0f,-1189.0f,758.0f,-324.0f,518.0f,-233.0f,-1221,0.30987036f,-0.13200074f,-0.6557222f,100.0f,26.443233f,0f ) ;
  }

  @Test
  public void test1190() {
    TestDrivers.surfaceShade(-904.0f,650.0f,-4.0f,0f,185.0f,1.0f,0f,-912.0f,0f,0f,0f,0f,0f,468.0f,-295.0f,-796.0f,0f,0f,0f,-1492,11.305394f,-100.0f,43.70719f,-100.0f,-65.166214f,-78.27597f ) ;
  }

  @Test
  public void test1191() {
    TestDrivers.surfaceShade(908.0f,-918.0f,0f,0f,929.0f,5.0f,0f,180.0f,0f,0f,0f,0f,0f,-115.0f,-56.0f,-932.0f,-894.0f,-956.0f,271.0f,-137,-76.21972f,74.549324f,90.03322f,83.33398f,-41.207684f,0f ) ;
  }

  @Test
  public void test1192() {
    TestDrivers.surfaceShade(-91.0f,228.0f,-1009.0f,0f,813.0f,580.0f,0f,674.0f,0f,0f,0f,0f,0f,444.0f,355.0f,-118.0f,-2322.0f,104.0f,1441.0f,-682,-54.07371f,36.339104f,-94.13853f,-27.259832f,10.880021f,-44.241978f ) ;
  }

  @Test
  public void test1193() {
    TestDrivers.surfaceShade(91.0f,-467.0f,0f,0f,461.0f,-9.0f,0f,-4.0f,0f,0f,0f,0f,0f,-676.0f,-134.0f,-1547.0f,0f,0f,0f,-467,0.25443852f,0.64468944f,0.2543659f,-47.966602f,-65.60765f,0f ) ;
  }

  @Test
  public void test1194() {
    TestDrivers.surfaceShade(91.0f,855.0f,410.0f,0f,203.0f,-1376.0f,0f,194.0f,0f,0f,0f,0f,0f,32.0f,552.0f,55.0f,746.0f,-1055.0f,538.0f,-783,-40.853115f,10.180506f,-78.40617f,154.91469f,21.796625f,33.456806f ) ;
  }

  @Test
  public void test1195() {
    TestDrivers.surfaceShade(-912.0f,436.0f,212.0f,0f,339.0f,2686.0f,0f,-1902.0f,0f,0f,0f,0f,0f,-1654.0f,-406.0f,-492.0f,1103.0f,-658.0f,-1213.0f,-1979,0.56858695f,-0.62399423f,-0.08239577f,-39.60899f,-17.11212f,69.31645f ) ;
  }

  @Test
  public void test1196() {
    TestDrivers.surfaceShade(917.0f,4.0f,-886.0f,6.0f,0f,0f,0f,-92.396385f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1,0f,0f,0f,-61.336384f,0.041666668f,43.2096f ) ;
  }

  @Test
  public void test1197() {
    TestDrivers.surfaceShade(-918.0f,-901.0f,3421.0f,0f,193.0f,-2664.0f,0f,1062.0f,0f,0f,0f,0f,0f,210.0f,653.0f,-480.0f,-899.0f,-1100.0f,1671.0f,-1006,100.0f,-17.299767f,20.215109f,35.37352f,-100.0f,26.336998f ) ;
  }

  @Test
  public void test1198() {
    TestDrivers.surfaceShade(92.0f,0.0f,1438.0f,900.0f,0f,0f,0f,5.684342E-14f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-96.382416f,87.84293f,94.709015f ) ;
  }

  @Test
  public void test1199() {
    TestDrivers.surfaceShade(-92.0f,0f,0f,17.0f,0f,0f,0f,65.57997f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-6.393862E-4f,0f,0f ) ;
  }

  @Test
  public void test1200() {
    TestDrivers.surfaceShade(-92.0f,-2116.0f,1042.0f,0f,326.0f,503.0f,0f,494.0f,0f,0f,0f,0f,0f,-711.0f,-2306.0f,2393.0f,951.0f,1234.0f,-892.0f,455,0.63704103f,0.3262969f,0.28565678f,-100.0f,-28.167812f,-31.868534f ) ;
  }

  @Test
  public void test1201() {
    TestDrivers.surfaceShade(-921.0f,-663.0f,0f,0f,1578.0f,-823.0f,0f,433.0f,0f,0f,0f,0f,0f,804.0f,-327.0f,-444.0f,-876.0f,252.0f,-422.0f,-1119,-0.45501456f,-0.4985885f,-0.34026533f,-71.80196f,-1.709012f,0f ) ;
  }

  @Test
  public void test1202() {
    TestDrivers.surfaceShade(922.0f,-2026.0f,0f,0f,1127.0f,-244.0f,0f,1912.0f,0f,0f,0f,0f,0f,1886.0f,-828.0f,-337.0f,-94.0f,1025.0f,-1321.0f,-966,-0.18609469f,-0.29919714f,0.19699545f,-93.30065f,63.380383f,0f ) ;
  }

  @Test
  public void test1203() {
    TestDrivers.surfaceShade(-922.0f,-822.0f,0f,0f,226.0f,-2947.0f,0f,-1080.0f,0f,0f,0f,0f,0f,984.0f,-58.0f,79.0f,0f,0f,0f,606,0.07419238f,0.66201943f,-0.43807822f,-28.76038f,-32.25921f,0f ) ;
  }

  @Test
  public void test1204() {
    TestDrivers.surfaceShade(923.0f,607.0f,247.0f,0f,770.0f,-682.0f,0f,-793.0f,0f,0f,0f,0f,0f,22.0f,-191.0f,602.0f,0f,0f,0f,-414,-95.402695f,-85.29416f,-70.37221f,83.63192f,-48.16279f,39.080887f ) ;
  }

  @Test
  public void test1205() {
    TestDrivers.surfaceShade(-924.0f,255.0f,0f,0f,656.0f,711.0f,0f,-3.0f,0f,0f,0f,0f,0f,-1315.0f,-817.0f,-355.0f,979.0f,-809.0f,-1093.0f,-180,0.53277427f,-0.13735865f,0.5113151f,72.0492f,58.776157f,0f ) ;
  }

  @Test
  public void test1206() {
    TestDrivers.surfaceShade(924.0f,593.0f,-874.0f,0f,851.0f,846.0f,0f,2055.0f,0f,0f,0f,0f,0f,549.0f,-272.0f,304.0f,-369.0f,2789.0f,889.0f,-2,1.8693618f,0.6262119f,-2.815625f,50.70198f,100.0f,-24.143599f ) ;
  }

  @Test
  public void test1207() {
    TestDrivers.surfaceShade(-927.0f,491.0f,148.0f,402.0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,-2.6834543E-6f,-78.90123f,1.6807853E-5f ) ;
  }

  @Test
  public void test1208() {
    TestDrivers.surfaceShade(-927.0f,-667.0f,550.0f,0f,1382.0f,1984.0f,0f,1428.0f,0f,0f,0f,0f,0f,-879.0f,-472.0f,1827.0f,534.0f,800.0f,-182.0f,2040,0.81703854f,-0.19836397f,-0.30951568f,-56.940365f,76.52982f,58.281746f ) ;
  }

  @Test
  public void test1209() {
    TestDrivers.surfaceShade(930.0f,117.0f,39.0f,0f,15.0f,-648.0f,0f,-45.0f,0f,0f,0f,0f,0f,107.0f,-111.0f,-21.0f,0f,0f,0f,-178,0.09803074f,0.2047927f,-0.5829584f,-40.844578f,-48.83507f,2.9793618f ) ;
  }

  @Test
  public void test1210() {
    TestDrivers.surfaceShade(-930.0f,30.0f,53.0f,0f,588.0f,532.0f,0f,-194.0f,0f,0f,0f,0f,0f,-892.0f,-449.0f,688.0f,208.0f,-517.0f,-216.0f,-36,10.812994f,34.700535f,36.665306f,15.892038f,100.0f,15.065791f ) ;
  }

  @Test
  public void test1211() {
    TestDrivers.surfaceShade(932.0f,-418.0f,0f,0f,2.0f,1.0f,0f,-1036.0f,0f,0f,0f,0f,0f,-103.0f,998.0f,163.0f,0f,0f,0f,635,-100.0f,-23.910069f,83.191574f,-93.98255f,-5.915261E-4f,0f ) ;
  }

  @Test
  public void test1212() {
    TestDrivers.surfaceShade(933.0f,0f,0f,0f,16.430676f,-2.9089513f,0f,0.0f,0f,0f,0f,0f,0f,22.842451f,42.007954f,57.00221f,0f,0f,0f,-2129,-56.71551f,52.07527f,-15.649467f,68.53912f,0f,0f ) ;
  }

  @Test
  public void test1213() {
    TestDrivers.surfaceShade(-933.0f,0f,0f,0f,88.52738f,0.0f,0f,-76.12376f,0f,0f,0f,0f,0f,8.614929f,14.969947f,-7.436282f,0f,0f,0f,28,-42.533173f,-37.627808f,35.34544f,-35.998898f,0f,0f ) ;
  }

  @Test
  public void test1214() {
    TestDrivers.surfaceShade(-933.0f,-486.0f,-94.0f,0f,586.0f,-166.0f,0f,315.0f,0f,0f,0f,0f,0f,-711.0f,144.0f,-915.0f,892.0f,-718.0f,489.0f,-245,96.352875f,39.415257f,31.878458f,-15.030145f,94.344826f,-32.6348f ) ;
  }

  @Test
  public void test1215() {
    TestDrivers.surfaceShade(948.0f,146.0f,-785.0f,0f,859.0f,345.0f,0f,796.0f,0f,0f,0f,0f,0f,964.0f,-75.0f,351.0f,-539.0f,377.0f,350.0f,-647,-26.55549f,99.688705f,61.021187f,-99.144806f,59.45588f,99.58144f ) ;
  }

  @Test
  public void test1216() {
    TestDrivers.surfaceShade(949.0f,-40.0f,10.0f,0f,17.0f,522.0f,0f,908.0f,0f,0f,0f,0f,0f,-51.0f,578.0f,-138.0f,-1106.0f,-729.0f,-516.0f,104,-13.702684f,18.222393f,81.386826f,-72.11419f,89.27456f,4.6454396f ) ;
  }

  @Test
  public void test1217() {
    TestDrivers.surfaceShade(950.0f,-536.0f,0f,0f,328.0f,-241.0f,0f,816.0f,0f,0f,0f,0f,0f,242.0f,1320.0f,271.0f,714.0f,234.0f,-682.0f,669,-96.009f,-79.07953f,-83.79945f,61.79705f,-23.290653f,0f ) ;
  }

  @Test
  public void test1218() {
    TestDrivers.surfaceShade(950.0f,566.0f,140.0f,0f,296.0f,-508.0f,0f,209.0f,0f,0f,0f,0f,0f,-893.0f,-317.0f,-827.0f,-420.0f,-870.0f,774.0f,93,-43.61427f,-69.82275f,75.69005f,-41.19f,90.55288f,-48.332428f ) ;
  }

  @Test
  public void test1219() {
    TestDrivers.surfaceShade(952.0f,-104.0f,0f,0f,-454.0f,62.0f,580.0f,-371.0f,0f,0f,0f,0f,0f,-404.0f,-904.0f,-910.0f,147.0f,-173.0f,-664.0f,-599,-78.99631f,36.838806f,-89.10393f,91.65922f,-53.61337f,0f ) ;
  }

  @Test
  public void test1220() {
    TestDrivers.surfaceShade(-957.0f,0f,0f,0f,160.0f,99.0f,0f,-253.0f,0f,0f,0f,0f,0f,514.0f,-600.0f,-574.0f,-673.0f,1038.0f,-838.0f,958,-54.637047f,-79.2473f,33.91104f,-0.35447386f,0f,0f ) ;
  }

  @Test
  public void test1221() {
    TestDrivers.surfaceShade(-959.0f,1303.0f,-1024.0f,0f,233.0f,-60.0f,0f,-775.0f,0f,0f,0f,0f,0f,-138.0f,-183.0f,-611.0f,0f,0f,0f,38,4.103293f,23.682003f,-8.01974f,27.551617f,57.421864f,-95.80935f ) ;
  }

  @Test
  public void test1222() {
    TestDrivers.surfaceShade(963.0f,-990.0f,962.0f,0f,916.0f,-787.0f,0f,-892.0f,0f,0f,0f,0f,0f,489.0f,425.0f,-423.0f,0f,0f,0f,618,64.90885f,-100.0f,65.811905f,-100.0f,-100.0f,100.0f ) ;
  }

  @Test
  public void test1223() {
    TestDrivers.surfaceShade(97.0f,0f,0f,0f,95.42946f,-100.0f,0f,-36.8588f,0f,0f,0f,0f,0f,99.53421f,-76.00625f,-58.760796f,0f,0f,0f,811,-0.12519322f,-0.356156f,0.68245995f,6.680377f,0f,0f ) ;
  }

  @Test
  public void test1224() {
    TestDrivers.surfaceShade(973.0f,5.0f,0f,0f,407.0f,-4.0f,0f,-4.0f,0f,0f,0f,0f,0f,-1168.0f,-208.0f,-136.0f,0f,0f,0f,-911,100.0f,-48.556095f,-60.32541f,-18.204227f,4.9890363E-9f,0f ) ;
  }

  @Test
  public void test1225() {
    TestDrivers.surfaceShade(-975.0f,0f,0f,0f,133.0f,84.0f,-120.0f,5.0f,0f,0f,0f,0f,0f,687.0f,175.0f,577.0f,-900.0f,824.0f,363.0f,296,-86.944084f,100.0f,73.18992f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test1226() {
    TestDrivers.surfaceShade(-978.0f,0f,114.0f,0f,467.0f,2083.0f,0f,-269.0f,0f,0f,0f,0f,0f,110.0f,-530.0f,-194.0f,0.0f,262.0f,933.0f,1132,-0.4392636f,1.464198f,-4.2491956f,-66.51131f,0f,80.46614f ) ;
  }

  @Test
  public void test1227() {
    TestDrivers.surfaceShade(-978.0f,-162.0f,757.0f,0f,415.0f,-1079.0f,0f,248.0f,0f,0f,0f,0f,0f,-92.0f,150.0f,-69.0f,280.0f,225.0f,922.0f,547,-60.8564f,-33.349304f,71.448524f,5.64377E-10f,38.112686f,35.190063f ) ;
  }

  @Test
  public void test1228() {
    TestDrivers.surfaceShade(-979.0f,-850.0f,-440.0f,-42.0f,0f,0f,0f,64.56777f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,-26.044336f,-99.99999f,5.4112556E-5f ) ;
  }

  @Test
  public void test1229() {
    TestDrivers.surfaceShade(-980.0f,512.0f,0f,0f,49.0f,-1192.0f,0f,197.0f,0f,0f,0f,0f,0f,-250.0f,-780.0f,-32.0f,1641.0f,-636.0f,-1172.0f,875,0.06594536f,-0.01999794f,0.8465298f,0.6463448f,-100.0f,0f ) ;
  }

  @Test
  public void test1230() {
    TestDrivers.surfaceShade(98.0f,-556.0f,718.0f,0f,465.0f,72.0f,0f,806.0f,0f,0f,0f,0f,0f,-360.0f,211.0f,497.0f,-60.0f,-950.0f,321.0f,556,-0.7586218f,-39.250942f,4.768904f,49.09195f,10.820301f,37.02485f ) ;
  }

  @Test
  public void test1231() {
    TestDrivers.surfaceShade(-986.0f,-1071.0f,46.0f,0f,107.0f,923.0f,0f,1076.0f,0f,0f,0f,0f,0f,493.0f,-854.0f,371.0f,67.0f,512.0f,-9.0f,-783,86.03529f,89.56973f,67.30088f,-85.36522f,53.549736f,2.2305418E-8f ) ;
  }

  @Test
  public void test1232() {
    TestDrivers.surfaceShade(-986.0f,-1682.0f,90.0f,0f,77.0f,623.0f,0f,1021.0f,0f,0f,0f,0f,0f,113.0f,684.0f,540.0f,-757.0f,147.0f,-2868.0f,884,-37.073425f,-16.213896f,28.295551f,100.0f,-24.942999f,0.032449983f ) ;
  }

  @Test
  public void test1233() {
    TestDrivers.surfaceShade(990.0f,-938.0f,-799.0f,0f,415.0f,-519.0f,0f,580.0f,0f,0f,0f,0f,0f,137.0f,-547.0f,-946.0f,-22.0f,-501.0f,-52.0f,815,35.16213f,-5.9906363f,64.65855f,23.160683f,95.30106f,-25.524796f ) ;
  }

  @Test
  public void test1234() {
    TestDrivers.surfaceShade(99.0f,308.0f,0f,0f,21.0f,-516.0f,0f,924.0f,0f,0f,0f,0f,0f,-924.0f,800.0f,-856.0f,325.0f,40.0f,-563.0f,208,-34.88484f,-64.026054f,-22.18137f,-17.86048f,-12.500465f,0f ) ;
  }

  @Test
  public void test1235() {
    TestDrivers.surfaceShade(-99.0f,-683.0f,-1411.0f,-620.0f,0f,0f,0f,29.667393f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,47.920082f,2.3614982E-6f,86.43239f ) ;
  }

  @Test
  public void test1236() {
    TestDrivers.surfaceShade(-992.0f,-660.0f,-1662.0f,0f,201.0f,327.0f,0f,897.0f,0f,0f,0f,0f,0f,-80.0f,771.0f,334.0f,-453.0f,-1493.0f,986.0f,3,94.625244f,43.636974f,-78.06613f,-47.578487f,-69.937836f,-28.629301f ) ;
  }

  @Test
  public void test1237() {
    TestDrivers.surfaceShade(995.0f,0f,0f,0f,1311.0f,1023.0f,0f,2468.0f,0f,0f,0f,0f,0f,1025.0f,-2271.0f,1141.0f,1489.0f,513.0f,-2134.0f,-351,-0.28687856f,0.31695518f,0.8403937f,13.160815f,0f,0f ) ;
  }

  @Test
  public void test1238() {
    TestDrivers.surfaceShade(-996.0f,230.0f,1973.0f,0f,1283.0f,-254.0f,0f,262.0f,0f,0f,0f,0f,0f,-671.0f,-599.0f,722.0f,-235.0f,-510.0f,-1059.0f,-513,0.20359175f,0.8671771f,0.3513559f,27.160543f,8.814897f,-11.75834f ) ;
  }

  @Test
  public void test1239() {
    TestDrivers.surfaceShade(996.0f,-655.0f,0f,0f,312.0f,-60.0f,0f,-111.0f,0f,0f,0f,0f,0f,1116.0f,215.0f,-17.0f,0f,0f,0f,-778,-0.57500297f,0.087921835f,0.8137307f,-100.0f,-4.586024f,0f ) ;
  }
}
