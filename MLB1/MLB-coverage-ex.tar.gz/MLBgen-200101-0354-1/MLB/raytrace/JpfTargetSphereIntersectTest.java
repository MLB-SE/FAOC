import org.junit.Test;

public class JpfTargetSphereIntersectTest {

  @Test
  public void test0() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.19979191f,-0.9593691f,-0.13927792f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.87265253f,0.48832515f,0.004020174f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.95469886f,0.07447507f,0.28810343f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.9915933f,-0.0750282f,0.07844244f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1.2889005E-4f,2.6796278E-4f,-2.2284775E-4f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-2.1298561E-4f,-1.9090509E-4f,2.570233E-4f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-31.92203f,-53.08175f,97.67056f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,4.1168957E-10f,-1.0082137E-9f,4.945266E-10f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-51.75381f,0.8514013f,14.588732f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-61.07066f,48.58002f,15.298464f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,26.934893f,-59.665997f,-74.15926f,100.0f,100.0f,-0.086633556f,0.9824811f,0.16500144f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-100.0f,98.99524f,-87.62407f,-100.0f,-100.0f,11.105748f,7.1710045E-4f,-0.05266838f,-0.9986118f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-18.670576f,-73.383446f,-65.613846f,-47.085514f,24.29643f,20.88516f,-0.26080364f,-0.48967293f,0.39496887f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-69.83094f,-3.2738297f,100.0f,-56.2802f,-92.989174f,19.949118f,-0.05547644f,-0.005540339f,-0.039176572f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,79.01418f,100.0f,-100.0f,33.447098f,79.61169f,-100.0f,0.5037524f,0.122667104f,-0.8550943f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,99.99633f,-9.98532f,-100.0f,-99.920006f,33.007866f,-67.51892f,-0.65502554f,-0.6907417f,-0.30629632f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-99.99999f,-81.18977f,-99.99992f,2.793337f,-40.79494f,-42.579266f,-0.40626937f,0.54248357f,0.7352937f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,10.676516f,1.7844528f,-91.608246f,71.75247f,39.157486f,-36.76736f,-37.999886f,-74.30246f,-63.61316f,2.4528549f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,11.130786f,2.3175476f,-42.299343f,35.574574f,-2.5845318f,-30.391747f,-39.560844f,-191.44135f,91.19483f,72.59369f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-14.084862f,-43.221527f,-29.629467f,89.15701f,61.042534f,-99.97102f,-19.366621f,-4.6444173f,-3.1515472f,-1.5618926f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1.9680603f,-26.615131f,39.657898f,24.091988f,9.428291f,-6.346717f,33.35406f,-0.2643757f,-0.8601368f,0.43619964f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-22.292364f,56.059685f,-6.85983f,59.57949f,-18.544996f,5.673504f,-38.43364f,10.639455f,2.2170725f,27.978308f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-23.852066f,42.582207f,97.42123f,99.33148f,15.752241f,57.117718f,20.825573f,-0.7776133f,-0.5039579f,-0.26046738f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2.4088275f,-2.5973282f,-69.54016f,83.645424f,72.66627f,94.7637f,32.283688f,-81.008804f,92.471085f,-88.41577f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-26.228157f,99.32938f,42.79315f,-77.957466f,50.2088f,-8.250061f,21.121202f,97.73024f,-33.106808f,66.824066f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,26.664944f,-99.88793f,99.99998f,73.472145f,99.99999f,-95.653114f,99.18017f,-0.8888911f,-0.4383345f,0.13318264f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-27.80582f,100.0f,31.617393f,20.897667f,-72.719955f,85.396835f,-100.0f,0.33502805f,0.74847525f,-0.4352908f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2.9434907f,-51.795708f,6.4743004f,36.79333f,8.559619f,-18.587128f,-17.584059f,0.14597064f,-0.8755555f,-0.1521301f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-3.0927722f,-51.42282f,-14.690852f,-54.70976f,-38.890923f,-18.801903f,23.177755f,-77.588264f,95.862465f,26.23674f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,3.1113038f,-14.185793f,-5.789146f,72.383736f,42.76585f,-14.08002f,43.666565f,-64.33221f,7.797649f,93.02624f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-3.4729383f,-100.0f,100.0f,100.0f,30.495535f,-5.945473f,42.962574f,0.05048818f,-0.98633194f,0.15684482f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-35.780045f,22.4287f,58.65491f,70.75267f,-69.78605f,80.59254f,37.05631f,-0.75076425f,-0.64368856f,-0.06982294f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-35.818436f,65.88931f,34.641487f,95.70435f,39.636734f,11.813396f,11.368407f,-1.2168585f,0.15837924f,-0.35949272f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,36.264854f,-51.803345f,-53.46093f,-91.42754f,39.430473f,2.9638386f,68.79553f,59.13312f,-1.950907f,77.42381f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-37.877895f,84.50696f,-99.43855f,-51.441067f,-49.328365f,11.946492f,-100.0f,-0.7469574f,-0.6096204f,0.26536313f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-42.160446f,81.20755f,25.477148f,87.997345f,-29.882236f,-13.624124f,-53.924545f,-30.060333f,30.565792f,6.838093f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-42.52562f,100.0f,97.097015f,81.62109f,-100.0f,42.055763f,98.17624f,80.052925f,40.767757f,53.610146f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-42.678146f,-99.88211f,-43.603638f,-100.0f,-67.98216f,32.44751f,97.73086f,-0.5237715f,0.32716432f,0.7865284f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,45.18713f,-36.83306f,-28.444736f,74.01489f,17.469883f,-41.728535f,41.942852f,35.677353f,61.002396f,1.8371023f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,52.416843f,64.041275f,-17.917257f,93.436615f,82.77574f,-24.32459f,-18.377567f,-34.15048f,49.498577f,-10.149327f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,5.8398223f,-22.159428f,-68.97384f,-62.141644f,-66.05585f,5.912057f,-26.947996f,-65.75667f,99.878f,-2.3547168f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,61.66359f,-79.32012f,92.19182f,2.4812095f,-65.06608f,-92.08329f,44.143986f,-22.332914f,1.4320426f,-4.2562943f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-62.619377f,-34.468445f,22.372992f,46.152424f,-75.025116f,-68.00572f,-6.8056755f,20.863426f,55.642952f,49.69667f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,65.469666f,34.640842f,-26.634798f,45.911053f,30.082f,21.37159f,-0.56825376f,24.903059f,13.744666f,40.749237f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,67.548874f,-19.709057f,54.138596f,19.556757f,49.344112f,-13.307672f,50.964375f,-34.632496f,-100.0f,-2.08521f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-7.3416786f,6.478718f,22.133453f,85.664276f,-96.223816f,61.111134f,27.396511f,0.99639845f,0.060337365f,0.05957843f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,75.21276f,19.712576f,58.31926f,26.880272f,80.617035f,20.102543f,84.64777f,-0.2179757f,0.45841494f,-0.8358589f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-78.11146f,-90.44101f,66.065094f,52.879055f,31.871048f,-0.9465954f,-77.98343f,15.4534645f,-30.920534f,44.397076f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-78.56627f,82.314285f,-33.741295f,92.917404f,-5.940635f,28.929394f,-11.175534f,-78.35365f,56.819233f,-25.762402f ) ;
  }

  @Test
  public void test49() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,78.99004f,69.99724f,-100.0f,22.99459f,95.21209f,86.29228f,-99.73945f,-99.549164f,-99.99984f,-1.6493595f ) ;
  }

  @Test
  public void test50() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-79.86471f,-79.012344f,0.056976613f,43.4935f,69.10062f,100.0f,-76.585266f,6.683127f,-8.632641f,-0.9544836f ) ;
  }

  @Test
  public void test51() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,84.15453f,37.062805f,-27.470581f,56.815136f,98.26559f,12.569149f,-81.013725f,-16.279272f,5.7964416f,20.511324f ) ;
  }

  @Test
  public void test52() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-85.96291f,-100.0f,34.377743f,100.0f,51.78738f,83.17621f,100.0f,-0.2253504f,-0.97014105f,0.0896857f ) ;
  }

  @Test
  public void test53() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-86.87191f,89.44008f,-25.66223f,66.57285f,-48.426617f,63.16004f,-1.8053701f,0.40062156f,-0.17921636f,-0.54566765f ) ;
  }

  @Test
  public void test54() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,90.13512f,-7.756912f,-67.96433f,-70.10312f,95.99557f,57.850517f,-31.721409f,17.663973f,95.15304f,14.05511f ) ;
  }

  @Test
  public void test55() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,9.049497f,28.077253f,-1.4560755f,55.107586f,-19.51935f,88.54201f,35.96361f,95.55095f,-20.95856f,-72.4863f ) ;
  }

  @Test
  public void test56() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-91.12542f,-90.2684f,-79.80249f,-27.307325f,24.747578f,-75.969795f,42.22822f,-34.591568f,-73.41199f,64.668655f ) ;
  }

  @Test
  public void test57() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,92.20941f,-7.6732516f,-17.949442f,71.75264f,56.209396f,14.067699f,62.42789f,87.982834f,-68.69012f,-33.691944f ) ;
  }

  @Test
  public void test58() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,9.270237f,-93.518f,-22.292463f,96.63534f,66.02451f,-20.684763f,6.2147374f,-68.041565f,-93.70803f,-49.872917f ) ;
  }

  @Test
  public void test59() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,94.30294f,-11.812342f,87.02942f,76.7612f,71.2978f,36.824184f,6.179795f,-36.551903f,-56.751316f,65.686005f ) ;
  }

  @Test
  public void test60() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-9.566349f,9.505154f,-58.904564f,61.397026f,12.786503f,-18.305767f,-8.939603f,100.0f,43.968925f,-34.774097f ) ;
  }

  @Test
  public void test61() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,96.32189f,100.0f,-46.89216f,-87.11194f,-8.3530855f,10.202637f,99.368645f,-0.10214751f,0.40820634f,0.3320642f ) ;
  }

  @Test
  public void test62() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-98.598114f,21.31466f,58.307053f,74.405876f,-37.592804f,23.197298f,22.475876f,-90.45806f,16.90588f,-45.0637f ) ;
  }

  @Test
  public void test63() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.25526f,84.141815f,100.0f,-95.68234f,75.43891f,100.0f,99.99998f,0.93552154f,-0.35267186f,-0.020541465f ) ;
  }

  @Test
  public void test64() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.58541f,41.11381f,-100.0f,20.137978f,-78.58731f,24.14299f,-98.17337f,-0.31474632f,0.8439414f,0.43439347f ) ;
  }

  @Test
  public void test65() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,99.93869f,-17.793274f,55.818897f,46.087082f,66.75992f,8.750669f,37.969334f,128.63231f,-53.214424f,96.392075f ) ;
  }

  @Test
  public void test66() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.99999f,-99.99978f,-100.0f,100.0f,100.0f,49.82107f,100.0f,0.8928241f,-0.12116587f,-0.43380168f ) ;
  }
}
