import org.junit.Test;

public class JpfTargetRayTraceTest {

  @Test
  public void test0() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,0.001620612f,-5.5727677E-4f,-7.41247E-4f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,0.10416201f,0.47672352f,-0.49042785f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-0.25858176f,-0.8560309f,-0.13519442f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-0.35765713f,0.018166792f,0.93367624f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,0.57518107f,-0.81488854f,0.07157816f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,1.7153613E-7f,8.433231E-7f,2.648039E-7f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-37.657074f,-44.93508f,93.60206f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,44.955124f,95.72031f,8.150014f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,5.58072E-6f,4.7850885E-5f,2.2130291E-6f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,70.80538f,-95.89812f,26.444056f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.rayTrace(-100.0f,100.0f,100.0f,-100.0f,-100.0f,100.0f,-34.85667f,0.16725723f,0.89293754f,0.4179564f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.rayTrace(-100.0f,100.0f,100.0f,-100.0f,36.741833f,100.0f,-8.168562f,0.84786844f,0.48469973f,-0.21490756f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.rayTrace(-100.0f,100.0f,100.0f,100.0f,-88.99601f,38.93136f,-100.0f,-0.0055174925f,0.9991927f,-0.03979243f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.rayTrace(-100.0f,100.0f,-3.307865f,45.103233f,58.85172f,-42.625526f,-100.0f,0.08221575f,-0.81728196f,0.24311471f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.rayTrace(100.0f,-100.0f,99.999756f,80.4231f,100.0f,-47.63413f,100.0f,0.13317841f,-0.97828996f,0.15878372f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.rayTrace(100.0f,-17.798903f,-100.0f,-99.98469f,100.0f,100.0f,-100.0f,-0.32808903f,-0.84360677f,0.42507082f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.rayTrace(1.0211467f,75.255936f,-82.5333f,94.703766f,50.637768f,-44.63951f,5.3126483f,-28.182835f,-72.725136f,0.40766177f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.rayTrace(-11.311606f,100.0f,-45.995235f,32.491505f,-5.767704f,-100.0f,-53.536224f,0.5749843f,-0.4537825f,-0.12267809f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.rayTrace(13.69222f,-16.94552f,1.1415988f,100.0f,27.07716f,74.62332f,15.909702f,-0.34040302f,-0.33711204f,-0.110215746f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.rayTrace(-13.734426f,-40.805187f,-8.656048f,80.43137f,-1.0789601f,-59.616776f,48.278103f,-3.1126587f,32.531982f,-45.192867f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.rayTrace(23.433674f,5.4712477f,29.713446f,75.852165f,-14.074769f,24.445217f,-16.239397f,0.41458485f,0.24437478f,0.062837236f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.rayTrace(30.95638f,-3.899023f,100.0f,99.999794f,100.0f,-65.85408f,-21.933922f,0.88604164f,-0.32408133f,-0.33151397f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.rayTrace(33.721653f,100.0f,57.306587f,-79.32708f,-100.0f,-100.0f,100.0f,-0.6646001f,-0.09576075f,0.7410375f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.rayTrace(37.371933f,-56.39145f,-100.0f,-100.0f,-100.0f,-81.10222f,-42.847317f,0.48658454f,-0.14608033f,0.12668851f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.rayTrace(46.495316f,-93.76051f,-53.512253f,97.17532f,98.176765f,-100.0f,-4.456522f,0.5052725f,0.18715665f,0.5154732f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.rayTrace(49.816395f,30.898478f,-18.052109f,37.4921f,13.408896f,5.2368593f,25.395075f,22.5878f,66.65703f,-58.64848f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.rayTrace(57.72695f,-100.0f,80.50415f,100.0f,40.26554f,-100.0f,66.84129f,0.47127292f,-0.87087494f,0.1395659f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.rayTrace(-62.240067f,-17.333658f,-42.192715f,-49.7571f,-45.691933f,-46.432587f,-5.3799415f,-0.50334954f,0.06229013f,0.023154058f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.rayTrace(-6.35753f,-50.750996f,-63.376354f,50.179092f,39.120262f,-29.693773f,-60.865334f,-85.929756f,-69.18562f,-70.67408f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.rayTrace(6.5288167f,-50.66874f,-4.2857103f,26.987122f,-12.453866f,85.85626f,83.84856f,44.896877f,-10.011657f,42.352215f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.rayTrace(-66.072044f,21.03441f,-34.92332f,-42.352688f,-84.760315f,6.5438805f,-43.29263f,-34.835773f,65.15954f,-12.140601f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.rayTrace(66.4849f,11.663776f,-42.3259f,-100.0f,-33.2402f,-100.0f,-65.984215f,-0.46225795f,-0.71758217f,0.5209543f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.rayTrace(68.38155f,-69.40117f,23.237728f,88.45508f,32.49099f,-11.975462f,-7.0468993f,0.203954f,-0.54921335f,-0.53197855f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.rayTrace(-68.653694f,-64.07327f,-25.482718f,-91.56351f,-27.989265f,-13.954446f,39.19773f,30.808739f,7.7407603f,96.33583f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.rayTrace(69.57582f,-4.6231513f,-82.24699f,-37.2252f,-57.771713f,-42.435932f,30.036554f,0.37951082f,0.15591006f,-0.11893327f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.rayTrace(72.51913f,25.575747f,100.0f,100.0f,100.0f,100.0f,-35.946186f,-0.011453097f,-0.08783858f,0.0962288f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.rayTrace(-73.31258f,98.075615f,-50.630997f,-2.260197f,-44.924057f,-91.18511f,55.864964f,-13.3284645f,-69.7755f,40.796192f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.rayTrace(-75.718216f,-6.5037875f,-31.183504f,45.104626f,-71.710686f,16.322323f,7.5119185f,0.8859671f,-0.43628046f,-0.15723118f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.rayTrace(81.22044f,-49.048603f,-83.59139f,51.701393f,52.09374f,-9.098954f,-99.99993f,0.31677887f,-1.7847618f,-3.4092147f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.rayTrace(81.56713f,9.261767f,45.823048f,-62.998253f,56.480766f,26.179583f,38.667404f,-0.6740378f,-0.09604466f,0.69724655f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.rayTrace(-82.05405f,-76.65862f,-2.2276077f,72.99169f,-83.113f,-21.930195f,-68.63355f,21.169928f,59.790005f,-93.22952f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.rayTrace(91.3113f,16.859146f,30.755573f,82.889175f,47.830307f,-12.014944f,-20.382402f,36.74159f,-85.6112f,-71.87835f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.rayTrace(-91.45541f,45.06194f,96.48008f,38.034866f,-100.0f,27.758942f,100.0f,0.39590898f,0.9099133f,-0.12374931f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.rayTrace(-93.62101f,-83.0465f,17.677916f,-60.436493f,19.841698f,39.47349f,23.776052f,33.412315f,28.6146f,-22.812378f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.rayTrace(-9.46678f,-50.510284f,-31.709076f,24.77191f,-45.69998f,-45.685993f,-42.05113f,92.50924f,64.07846f,56.722824f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.rayTrace(99.97653f,-100.0f,67.773094f,100.0f,100.0f,-90.33192f,-100.0f,-0.063877344f,0.08761122f,-1.0234336f ) ;
  }
}
