import org.junit.Test;

public class TestStatCalcTest {

  @Test
  public void test0() {
    concolic.TestStatCalc.run(11 ) ;
  }

  @Test
  public void test1() {
    concolic.TestStatCalc.run(180 ) ;
  }

  @Test
  public void test2() {
    concolic.TestStatCalc.run(-252 ) ;
  }

  @Test
  public void test3() {
    concolic.TestStatCalc.run(269 ) ;
  }

  @Test
  public void test4() {
    concolic.TestStatCalc.run(270 ) ;
  }

  @Test
  public void test5() {
    concolic.TestStatCalc.run(-279 ) ;
  }

  @Test
  public void test6() {
    concolic.TestStatCalc.run(-299 ) ;
  }

  @Test
  public void test7() {
    concolic.TestStatCalc.run(3 ) ;
  }

  @Test
  public void test8() {
    concolic.TestStatCalc.run(-332 ) ;
  }

  @Test
  public void test9() {
    concolic.TestStatCalc.run(-415 ) ;
  }

  @Test
  public void test10() {
    concolic.TestStatCalc.run(540 ) ;
  }

  @Test
  public void test11() {
    concolic.TestStatCalc.run(546 ) ;
  }

  @Test
  public void test12() {
    concolic.TestStatCalc.run(621 ) ;
  }

  @Test
  public void test13() {
    concolic.TestStatCalc.run(-638 ) ;
  }

  @Test
  public void test14() {
    concolic.TestStatCalc.run(-726 ) ;
  }

  @Test
  public void test15() {
    concolic.TestStatCalc.run(918 ) ;
  }

  @Test
  public void test16() {
    concolic.TestStatCalc.run(947 ) ;
  }
}
