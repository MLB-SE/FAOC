import org.junit.Test;

public class JpfTargetsendmoremoneyTest {

  @Test
  public void test0() {
    color.sendmoremoney.solve(1,1,6,1,9,0,0,0 ) ;
  }

  @Test
  public void test1() {
    color.sendmoremoney.solve(1,1,6,390,0,0,0,0 ) ;
  }

  @Test
  public void test2() {
    color.sendmoremoney.solve(160,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    color.sendmoremoney.solve(1,7,0,9,974,0,0,0 ) ;
  }

  @Test
  public void test4() {
    color.sendmoremoney.solve(2,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    color.sendmoremoney.solve(2,10,1,8,5,163,0,0 ) ;
  }

  @Test
  public void test6() {
    color.sendmoremoney.solve(2,4,4,5,-8,-117,0,0 ) ;
  }

  @Test
  public void test7() {
    color.sendmoremoney.solve(2,5,600,0,0,0,0,0 ) ;
  }

  @Test
  public void test8() {
    color.sendmoremoney.solve(2,8,0,4,9,866,0,0 ) ;
  }

  @Test
  public void test9() {
    color.sendmoremoney.solve(3,8,1,4,0,0,0,0 ) ;
  }

  @Test
  public void test10() {
    color.sendmoremoney.solve(3,9,0,5,0,-535,2624,0 ) ;
  }

  @Test
  public void test11() {
    color.sendmoremoney.solve(4,7,1,0,0,0,0,0 ) ;
  }

  @Test
  public void test12() {
    color.sendmoremoney.solve(5,1,1,0,-112,0,0,0 ) ;
  }

  @Test
  public void test13() {
    color.sendmoremoney.solve(-540,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test14() {
    color.sendmoremoney.solve(5,5,6,1758,0,0,0,0 ) ;
  }

  @Test
  public void test15() {
    color.sendmoremoney.solve(5,8,8,-454,0,0,0,0 ) ;
  }

  @Test
  public void test16() {
    color.sendmoremoney.solve(5,-942,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test17() {
    color.sendmoremoney.solve(6,214,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test18() {
    color.sendmoremoney.solve(6,2,9,3,415,0,0,0 ) ;
  }

  @Test
  public void test19() {
    color.sendmoremoney.solve(6,9,672,0,0,0,0,0 ) ;
  }

  @Test
  public void test20() {
    color.sendmoremoney.solve(7,0,6,6,7,-764,0,0 ) ;
  }

  @Test
  public void test21() {
    color.sendmoremoney.solve(720,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test22() {
    color.sendmoremoney.solve(8,0,1,1,5,-442,-2742,0 ) ;
  }

  @Test
  public void test23() {
    color.sendmoremoney.solve(8,7,-338,0,0,0,0,0 ) ;
  }

  @Test
  public void test24() {
    color.sendmoremoney.solve(9,233,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test25() {
    color.sendmoremoney.solve(9,8,0,0,0,0,0,0 ) ;
  }
}
