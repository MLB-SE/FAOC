import org.junit.Test;

public class JpfTargetmagicseries2Test {

  @Test
  public void test0() {
    color.magicseries.solve2(0,1,0,3 ) ;
  }

  @Test
  public void test1() {
    color.magicseries.solve2(0,1,3,0 ) ;
  }

  @Test
  public void test2() {
    color.magicseries.solve2(0,1,3,-1 ) ;
  }

  @Test
  public void test3() {
    color.magicseries.solve2(0,3,1,0 ) ;
  }

  @Test
  public void test4() {
    color.magicseries.solve2(0,3,1,-1357 ) ;
  }

  @Test
  public void test5() {
    color.magicseries.solve2(0,4,0,0 ) ;
  }

  @Test
  public void test6() {
    color.magicseries.solve2(1,0,0,1 ) ;
  }

  @Test
  public void test7() {
    color.magicseries.solve2(1,1,1,1 ) ;
  }

  @Test
  public void test8() {
    color.magicseries.solve2(1,2,0,1 ) ;
  }

  @Test
  public void test9() {
    color.magicseries.solve2(1,2,2,1 ) ;
  }

  @Test
  public void test10() {
    color.magicseries.solve2(1,2,-304,0 ) ;
  }

  @Test
  public void test11() {
    color.magicseries.solve2(1,3,0,0 ) ;
  }

  @Test
  public void test12() {
    color.magicseries.solve2(1,3,754,0 ) ;
  }

  @Test
  public void test13() {
    color.magicseries.solve2(1,855,0,0 ) ;
  }

  @Test
  public void test14() {
    color.magicseries.solve2(2,0,0,0 ) ;
  }

  @Test
  public void test15() {
    color.magicseries.solve2(2,0,2,0 ) ;
  }

  @Test
  public void test16() {
    color.magicseries.solve2(2,1,1,0 ) ;
  }

  @Test
  public void test17() {
    color.magicseries.solve2(2,187,0,0 ) ;
  }

  @Test
  public void test18() {
    color.magicseries.solve2(3,0,1,3 ) ;
  }

  @Test
  public void test19() {
    color.magicseries.solve2(3,0,303,0 ) ;
  }

  @Test
  public void test20() {
    color.magicseries.solve2(3,1,0,2 ) ;
  }

  @Test
  public void test21() {
    color.magicseries.solve2(3,3,0,305 ) ;
  }

  @Test
  public void test22() {
    color.magicseries.solve2(4,0,0,0 ) ;
  }

  @Test
  public void test23() {
    color.magicseries.solve2(4,2,1,23 ) ;
  }

  @Test
  public void test24() {
    color.magicseries.solve2(4,3,1,0 ) ;
  }

  @Test
  public void test25() {
    color.magicseries.solve2(4,-380,0,0 ) ;
  }

  @Test
  public void test26() {
    color.magicseries.solve2(933,0,0,0 ) ;
  }

  @Test
  public void test27() {
    color.magicseries.solve2(-96,0,0,0 ) ;
  }

  @Test
  public void test28() {
    color.magicseries.solve2(993,0,0,0 ) ;
  }
}
