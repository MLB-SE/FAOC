import org.junit.Test;

public class JpfTargetlaplaceTest {

  @Test
  public void test0() {
    color.laplace.solve(0.396039f,-100.0f,-0.6879928f,1.584156f,78.43054f,18.375126f,-72.48996f,-3.7794755f,0f ) ;
  }

  @Test
  public void test1() {
    color.laplace.solve(0.44610086f,-70.8244f,-48.47924f,-29.564524f,-18.704193f,51.038727f,-100.0f,-25.466574f,-24.91545f ) ;
  }

  @Test
  public void test2() {
    color.laplace.solve(-0.61664075f,-1.9725497f,-98.526955f,-0.4734075f,-1.0513341f,-1.3301667f,-0.22565511f,-0.42921293f,-0.4398449f ) ;
  }

  @Test
  public void test3() {
    color.laplace.solve(0.69100785f,1.0904729f,0.47870228f,-98.32644f,10.856665f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test4() {
    color.laplace.solve(-0.92300457f,-91.730316f,87.29802f,-11.961703f,83.8564f,0f,31.031675f,23.506514f,0f ) ;
  }

  @Test
  public void test5() {
    color.laplace.solve(-100.0f,-100.0f,0f,-49.25771f,-80.911766f,-74.684715f,-16.119072f,-15.21858f,39.147717f ) ;
  }

  @Test
  public void test6() {
    color.laplace.solve(-100.0f,25.587822f,0f,34.040684f,5.2475867f,64.30486f,11.38622f,11.504198f,29.382986f ) ;
  }

  @Test
  public void test7() {
    color.laplace.solve(-100.0f,33.186424f,-99.99777f,-29.439148f,-5.436244f,-5.6500072f,-12.320349f,-19.842245f,-61.61239f ) ;
  }

  @Test
  public void test8() {
    color.laplace.solve(-100.0f,-57.1217f,0f,-34.414665f,-26.907272f,0f,-25.628922f,-68.10102f,0f ) ;
  }

  @Test
  public void test9() {
    color.laplace.solve(100.0f,-73.052376f,0f,37.290337f,37.045692f,-29.06106f,12.115657f,11.172289f,-4.472193f ) ;
  }

  @Test
  public void test10() {
    color.laplace.solve(100.0f,-96.33375f,0f,71.704834f,4.426014f,-90.92491f,14.304292f,-14.487666f,-76.68097f ) ;
  }

  @Test
  public void test11() {
    color.laplace.solve(10.05168f,-26.75176f,57.347137f,-33.041523f,-8.506306f,0f,3.538728f,47.196434f,57.871307f ) ;
  }

  @Test
  public void test12() {
    color.laplace.solve(10.214146f,-83.55952f,96.014725f,24.416098f,84.13248f,46.81726f,8.652269f,10.192979f,-52.012825f ) ;
  }

  @Test
  public void test13() {
    color.laplace.solve(-10.35724f,-170.57637f,-20.353348f,29.226654f,10.121303f,0f,-1.9073397f,-36.8204f,69.925644f ) ;
  }

  @Test
  public void test14() {
    color.laplace.solve(10.593081f,-86.48346f,-5.4960203f,28.855782f,9.998705f,78.44708f,13.685669f,25.886894f,79.8632f ) ;
  }

  @Test
  public void test15() {
    color.laplace.solve(1.0659559f,-17.000898f,0f,5.0693355f,56.56841f,4.927074f,-37.35702f,-60.55166f,0f ) ;
  }

  @Test
  public void test16() {
    color.laplace.solve(1.1738936f,100.0f,0f,-28.694206f,-31.939833f,77.82552f,-84.01089f,-4.2244515f,0f ) ;
  }

  @Test
  public void test17() {
    color.laplace.solve(11.979879f,-37.02776f,11.798874f,21.68979f,-9.703561f,5.081838f,84.48284f,-28.558111f,100.0f ) ;
  }

  @Test
  public void test18() {
    color.laplace.solve(12.024587f,31.330215f,34.62156f,-83.231865f,-21.325283f,7.1560235f,-62.790977f,83.905846f,0f ) ;
  }

  @Test
  public void test19() {
    color.laplace.solve(-12.026279f,-128.62216f,-58.623352f,-21.915844f,-66.517006f,-100.0f,-9.256984f,-15.112092f,15.914159f ) ;
  }

  @Test
  public void test20() {
    color.laplace.solve(12.219998f,-21.224184f,30.284006f,-29.895823f,-32.03916f,-18.434952f,-99.76413f,-58.601685f,-71.98465f ) ;
  }

  @Test
  public void test21() {
    color.laplace.solve(-12.737907f,94.839134f,0f,14.784023f,61.176918f,-15.02113f,10.697082f,28.004303f,40.143215f ) ;
  }

  @Test
  public void test22() {
    color.laplace.solve(1.2930868f,76.26801f,0f,-98.03513f,-4.2595983f,-49.289406f,-26.250898f,-6.968465f,2.6366382f ) ;
  }

  @Test
  public void test23() {
    color.laplace.solve(13.298328f,-96.094f,0f,-2.1415677f,-20.135483f,10.622396f,-1.7291172f,-4.774901f,2.764995f ) ;
  }

  @Test
  public void test24() {
    color.laplace.solve(-13.572576f,15.928679f,0f,-1.5289514f,82.28634f,59.84971f,-74.82957f,17.192278f,0f ) ;
  }

  @Test
  public void test25() {
    color.laplace.solve(13.788841f,29.133545f,0f,-83.16178f,100.0f,-79.16429f,-19.753082f,4.149455f,-63.649097f ) ;
  }

  @Test
  public void test26() {
    color.laplace.solve(-14.681168f,24.75987f,63.639545f,5.42399f,-7.7853694f,26.729403f,44.162495f,-88.05474f,8.808147f ) ;
  }

  @Test
  public void test27() {
    color.laplace.solve(14.698047f,-30.6117f,56.047825f,13.294609f,17.332817f,15.352672f,21.147573f,71.295685f,-11.969954f ) ;
  }

  @Test
  public void test28() {
    color.laplace.solve(15.084126f,-20.953012f,13.650044f,-18.699411f,-212.03967f,-24.44258f,-13.876498f,-60.002228f,0f ) ;
  }

  @Test
  public void test29() {
    color.laplace.solve(15.510761f,-82.8167f,72.079544f,44.97168f,34.323143f,129.55067f,131.15343f,44.433975f,-10.584848f ) ;
  }

  @Test
  public void test30() {
    color.laplace.solve(16.099125f,-12.424728f,-10.713168f,-23.32899f,-155.0702f,-159.38242f,-16.045763f,-41.22761f,68.84003f ) ;
  }

  @Test
  public void test31() {
    color.laplace.solve(16.305058f,51.714592f,0f,-5.0474486f,-20.294931f,0f,-10.138756f,88.3887f,0f ) ;
  }

  @Test
  public void test32() {
    color.laplace.solve(16.417982f,-24.613787f,-31.426605f,0.19088078f,-13.123472f,-17.756151f,-2.5309875f,-10.314831f,-26.474525f ) ;
  }

  @Test
  public void test33() {
    color.laplace.solve(16.67332f,8.2870655f,16.474941f,-41.593773f,-100.0f,-42.38729f,-83.048416f,0f,0f ) ;
  }

  @Test
  public void test34() {
    color.laplace.solve(16.754482f,33.288754f,53.205994f,-66.27083f,-36.805458f,-12.858106f,-4.267623f,49.200336f,0f ) ;
  }

  @Test
  public void test35() {
    color.laplace.solve(17.352634f,18.09079f,35.115627f,-48.68025f,-80.1051f,22.371712f,0f,0f,0f ) ;
  }

  @Test
  public void test36() {
    color.laplace.solve(17.373573f,-89.71703f,-16.825388f,59.21133f,30.338017f,0f,15.190844f,1.5520452f,0f ) ;
  }

  @Test
  public void test37() {
    color.laplace.solve(17.869759f,48.359543f,93.20044f,-76.88051f,-17.632032f,-21.503553f,-20.09959f,-3.517851f,44.739746f ) ;
  }

  @Test
  public void test38() {
    color.laplace.solve(18.021896f,10.124833f,-18.808054f,-38.037247f,-58.714516f,-99.99962f,-16.109045f,-26.398926f,-30.772146f ) ;
  }

  @Test
  public void test39() {
    color.laplace.solve(18.125523f,10.824423f,121.44585f,-38.444553f,-30.525463f,-42.945766f,-142.34587f,-51.539257f,59.56421f ) ;
  }

  @Test
  public void test40() {
    color.laplace.solve(18.863317f,39.084232f,40.737427f,-63.63096f,-3.787019f,0f,-71.49733f,0f,0f ) ;
  }

  @Test
  public void test41() {
    color.laplace.solve(19.037498f,-43.219933f,-3.9689116f,19.369925f,68.95917f,-15.917958f,-10.516967f,2.196283f,0f ) ;
  }

  @Test
  public void test42() {
    color.laplace.solve(19.139103f,6.2955093f,0f,-39.344078f,51.48988f,-65.49526f,-2.1298401f,30.824717f,73.93883f ) ;
  }

  @Test
  public void test43() {
    color.laplace.solve(19.289635f,52.357708f,50.497147f,-75.199165f,39.644054f,49.63088f,-18.55873f,0.9642528f,-17.228313f ) ;
  }

  @Test
  public void test44() {
    color.laplace.solve(19.350712f,72.73432f,83.980286f,-95.331474f,-43.04449f,0f,-46.412407f,-90.31815f,0f ) ;
  }

  @Test
  public void test45() {
    color.laplace.solve(19.487743f,-29.281782f,0f,7.0670533f,5.370459f,74.24925f,3.4100108f,6.57299f,17.51149f ) ;
  }

  @Test
  public void test46() {
    color.laplace.solve(19.997303f,28.614626f,-100.0f,-48.625412f,-100.0f,0f,-26.30011f,-56.575027f,-100.0f ) ;
  }

  @Test
  public void test47() {
    color.laplace.solve(20.395872f,73.68605f,25.009491f,-92.10256f,-46.270428f,0f,-19.708265f,13.903071f,0f ) ;
  }

  @Test
  public void test48() {
    color.laplace.solve(20.441568f,-41.515385f,89.19845f,5.392598f,-14.415935f,-78.327385f,15.544758f,56.786434f,11.134348f ) ;
  }

  @Test
  public void test49() {
    color.laplace.solve(20.830116f,24.40095f,60.235672f,-41.080482f,-83.46199f,-44.51784f,-8.05482f,8.861199f,0f ) ;
  }

  @Test
  public void test50() {
    color.laplace.solve(20.87352f,-57.426956f,-38.477467f,6.685782f,-2.7904243f,-4.5564575f,8.660032f,44.135937f,23.04206f ) ;
  }

  @Test
  public void test51() {
    color.laplace.solve(-21.200155f,-100.0f,0f,23.186985f,99.99507f,100.0f,13.953023f,32.625107f,16.55233f ) ;
  }

  @Test
  public void test52() {
    color.laplace.solve(21.23279f,-6.8369565f,-90.82763f,-8.231885f,-57.75299f,1.0842997f,13.496398f,62.217476f,0f ) ;
  }

  @Test
  public void test53() {
    color.laplace.solve(21.310366f,62.078762f,0f,3.6222086f,-3.8710287f,0f,-8.987668f,-39.572884f,-42.765682f ) ;
  }

  @Test
  public void test54() {
    color.laplace.solve(21.473885f,19.925026f,0f,-56.154373f,86.851006f,0f,96.13302f,-38.69714f,0f ) ;
  }

  @Test
  public void test55() {
    color.laplace.solve(22.026655f,5.471121f,-24.131021f,-17.3645f,-62.64811f,0f,-28.836548f,0f,0f ) ;
  }

  @Test
  public void test56() {
    color.laplace.solve(22.076696f,11.283095f,7.5415154f,-22.976309f,-84.48583f,-73.96279f,-29.4961f,-95.008095f,0f ) ;
  }

  @Test
  public void test57() {
    color.laplace.solve(-22.208536f,85.28794f,-32.024883f,-4.1489058f,11.234631f,-17.86255f,-5.6217165f,-18.33796f,-78.96475f ) ;
  }

  @Test
  public void test58() {
    color.laplace.solve(22.260742f,11.117808f,-18.328562f,-22.07484f,-59.460945f,50.478626f,-51.09916f,100.0f,0f ) ;
  }

  @Test
  public void test59() {
    color.laplace.solve(22.37005f,40.03604f,-42.140503f,-50.55584f,79.91462f,-99.97241f,-10.58462f,8.21736f,-36.460564f ) ;
  }

  @Test
  public void test60() {
    color.laplace.solve(22.512604f,5.3732967f,76.23969f,-15.322885f,31.698175f,0f,-13.210727f,-37.52002f,-60.31507f ) ;
  }

  @Test
  public void test61() {
    color.laplace.solve(22.553467f,42.890507f,-3.701082f,-52.67664f,-15.597159f,16.515747f,-14.928973f,-7.0392523f,2.3691237f ) ;
  }

  @Test
  public void test62() {
    color.laplace.solve(22.673014f,-3.5659592f,-96.04681f,-5.7419844f,-40.890045f,-27.775787f,-4.9274864f,-13.96796f,-10.054311f ) ;
  }

  @Test
  public void test63() {
    color.laplace.solve(23.260086f,72.39076f,88.11272f,-79.35041f,51.444435f,0f,-23.467157f,-18.582138f,0f ) ;
  }

  @Test
  public void test64() {
    color.laplace.solve(23.777866f,100.0f,0f,-5.8727865f,27.635534f,-3.933089f,0.3306652f,7.1954474f,0.8155896f ) ;
  }

  @Test
  public void test65() {
    color.laplace.solve(23.845455f,7.675633f,-83.088066f,-12.293809f,-16.668228f,15.626183f,-56.352463f,-77.68092f,-54.711403f ) ;
  }

  @Test
  public void test66() {
    color.laplace.solve(-24.033108f,-67.99842f,0f,-13.905629f,-25.35154f,91.579346f,-6.237869f,-11.045846f,-12.593975f ) ;
  }

  @Test
  public void test67() {
    color.laplace.solve(24.181387f,-53.408157f,-5.6573267f,28.513323f,26.120737f,29.377779f,63.75117f,100.0f,97.04771f ) ;
  }

  @Test
  public void test68() {
    color.laplace.solve(24.332584f,36.27607f,41.487408f,-38.945732f,-20.715712f,30.517553f,-11.36663f,-6.5207877f,5.9991913f ) ;
  }

  @Test
  public void test69() {
    color.laplace.solve(24.619814f,5.3048224f,-38.706234f,-6.8255677f,-64.69429f,-100.0f,64.06134f,0f,0f ) ;
  }

  @Test
  public void test70() {
    color.laplace.solve(24.63013f,59.974464f,0f,0.42911038f,-17.097855f,-77.3483f,-5.8158345f,-23.69245f,-96.3804f ) ;
  }

  @Test
  public void test71() {
    color.laplace.solve(25.297209f,4.782232f,-75.1054f,-3.593394f,-31.062883f,99.99995f,-7.468427f,-26.280313f,-66.58994f ) ;
  }

  @Test
  public void test72() {
    color.laplace.solve(25.312597f,-69.71761f,13.168865f,1.3157455f,-19.008482f,-2.1503088f,-1.0416192f,-5.482222f,-1.9081328f ) ;
  }

  @Test
  public void test73() {
    color.laplace.solve(25.37497f,-63.14517f,11.172871f,64.64505f,71.21777f,23.800558f,17.432816f,5.0862145f,-68.305725f ) ;
  }

  @Test
  public void test74() {
    color.laplace.solve(25.678488f,-97.065285f,0f,5.9954615f,-6.6826563f,59.683754f,4.9860144f,13.948597f,84.76922f ) ;
  }

  @Test
  public void test75() {
    color.laplace.solve(25.687849f,10.054888f,14.229345f,-7.3034906f,-99.69765f,-63.64101f,-2.06768f,-0.96722883f,97.89641f ) ;
  }

  @Test
  public void test76() {
    color.laplace.solve(25.822521f,52.046f,-9.538686f,11.256212f,10.3336525f,-46.1861f,8.868677f,24.218496f,77.67165f ) ;
  }

  @Test
  public void test77() {
    color.laplace.solve(26.097275f,66.27114f,15.152285f,-61.882042f,24.680367f,-100.0f,-14.977517f,1.9719714f,-1.8149638f ) ;
  }

  @Test
  public void test78() {
    color.laplace.solve(26.133408f,33.42732f,-69.82417f,7.098036f,4.34384f,-7.7115364f,-2.0851057f,-15.438458f,17.326048f ) ;
  }

  @Test
  public void test79() {
    color.laplace.solve(26.822649f,16.339155f,31.411642f,-9.048559f,-92.87767f,-50.202003f,26.392849f,0f,0f ) ;
  }

  @Test
  public void test80() {
    color.laplace.solve(26.946533f,17.38732f,4.905044f,-9.601187f,-62.302296f,-98.046394f,-3.0489848f,-2.5947516f,-2.4123313f ) ;
  }

  @Test
  public void test81() {
    color.laplace.solve(27.13458f,-1.7515069f,-26.710201f,10.289833f,25.086073f,10.162947f,-11.061323f,81.64302f,0f ) ;
  }

  @Test
  public void test82() {
    color.laplace.solve(27.27851f,-1.0391008f,0f,2.9152436f,-29.018227f,57.423786f,13.400692f,-53.154842f,0f ) ;
  }

  @Test
  public void test83() {
    color.laplace.solve(27.374277f,43.435474f,50.363663f,-33.938366f,-3.9960432f,43.834248f,-98.04411f,64.323395f,0f ) ;
  }

  @Test
  public void test84() {
    color.laplace.solve(-27.418743f,-11.622303f,0f,-40.387505f,-38.436996f,0f,-23.341808f,-52.979725f,50.22273f ) ;
  }

  @Test
  public void test85() {
    color.laplace.solve(-27.448849f,-47.87098f,0f,-47.25561f,-53.34925f,0f,-8.799899f,-46.09621f,0f ) ;
  }

  @Test
  public void test86() {
    color.laplace.solve(27.578161f,5.992643f,100.0f,-12.648118f,-13.680555f,-21.806864f,-64.490074f,-26.259882f,-34.0525f ) ;
  }

  @Test
  public void test87() {
    color.laplace.solve(28.018288f,41.009632f,58.434517f,-28.936481f,-22.414274f,92.72843f,15.677584f,91.64681f,-78.855286f ) ;
  }

  @Test
  public void test88() {
    color.laplace.solve(28.55543f,23.229391f,-42.0443f,-9.007674f,-60.675514f,-63.725098f,-3.9106119f,-6.6347737f,50.447716f ) ;
  }

  @Test
  public void test89() {
    color.laplace.solve(29.007906f,8.484047f,-78.38578f,7.5475802f,-20.550877f,-11.433267f,21.733292f,-86.80187f,48.919903f ) ;
  }

  @Test
  public void test90() {
    color.laplace.solve(29.143269f,1.9930058f,0f,-1.2913646f,-11.081317f,52.02934f,-23.22741f,-27.74877f,0f ) ;
  }

  @Test
  public void test91() {
    color.laplace.solve(29.339832f,0.75318885f,0f,5.446551f,-7.623762f,-76.47832f,0.07013305f,-5.166019f,-13.110446f ) ;
  }

  @Test
  public void test92() {
    color.laplace.solve(29.468885f,8.377623f,-99.74999f,9.497922f,3.4429057f,-100.0f,5.0799f,10.821677f,34.763905f ) ;
  }

  @Test
  public void test93() {
    color.laplace.solve(-2.955278f,21.912628f,59.284603f,24.369762f,17.737204f,85.204056f,82.69712f,-60.537636f,-2.6551185f ) ;
  }

  @Test
  public void test94() {
    color.laplace.solve(29.7864f,9.861558f,-99.9996f,9.2840395f,6.332541f,-31.956964f,1.0172182f,-5.215167f,-28.210426f ) ;
  }

  @Test
  public void test95() {
    color.laplace.solve(29.918821f,33.502277f,-40.357944f,-13.826992f,1.3850584f,0f,4.0915036f,30.193007f,-27.736986f ) ;
  }

  @Test
  public void test96() {
    color.laplace.solve(29.96221f,43.8841f,61.73759f,-24.035261f,-16.163391f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test97() {
    color.laplace.solve(30.02494f,1.2294884f,0f,10.302878f,19.1562f,-55.13922f,-7.9696293f,-42.181396f,0f ) ;
  }

  @Test
  public void test98() {
    color.laplace.solve(30.45924f,36.836395f,7.343334f,-14.999438f,9.543013f,-18.997871f,-100.0f,35.332966f,-99.03598f ) ;
  }

  @Test
  public void test99() {
    color.laplace.solve(30.465845f,35.557167f,-42.710175f,-13.693784f,-12.394913f,-27.289986f,-72.84607f,-44.153046f,-54.054855f ) ;
  }

  @Test
  public void test100() {
    color.laplace.solve(30.569448f,24.6741f,-9.9250765f,-2.3963072f,-21.94797f,-90.71928f,-18.206707f,-70.43052f,96.39249f ) ;
  }

  @Test
  public void test101() {
    color.laplace.solve(30.86999f,32.29565f,22.676567f,-8.815696f,-24.36395f,-41.589382f,27.670458f,0f,0f ) ;
  }

  @Test
  public void test102() {
    color.laplace.solve(31.016941f,42.798744f,60.67185f,-18.730984f,-20.493813f,99.88866f,-11.333088f,-26.601368f,64.75367f ) ;
  }

  @Test
  public void test103() {
    color.laplace.solve(31.132074f,28.270157f,3.6586652f,-3.7418568f,-44.866287f,0f,-38.255886f,-43.5215f,0f ) ;
  }

  @Test
  public void test104() {
    color.laplace.solve(31.149876f,23.44977f,-34.14692f,1.1497339f,-12.479736f,0f,-11.330508f,-46.471767f,-18.992598f ) ;
  }

  @Test
  public void test105() {
    color.laplace.solve(31.310886f,20.066933f,-43.586853f,5.1766086f,-7.4563f,14.447581f,-3.1481516f,-17.769215f,-60.47241f ) ;
  }

  @Test
  public void test106() {
    color.laplace.solve(31.318615f,-47.35265f,-9.234871f,72.62711f,16.04235f,0f,29.245014f,44.352947f,-20.687675f ) ;
  }

  @Test
  public void test107() {
    color.laplace.solve(31.338598f,64.1003f,25.06261f,-38.745907f,100.0f,69.36697f,0f,0f,0f ) ;
  }

  @Test
  public void test108() {
    color.laplace.solve(31.397123f,17.285673f,17.587986f,8.302818f,-79.842415f,-46.933727f,3.7780452f,6.8093624f,37.042934f ) ;
  }

  @Test
  public void test109() {
    color.laplace.solve(31.61361f,37.596294f,20.125599f,-11.141861f,-1.354024f,-55.410347f,-74.82703f,23.539816f,-99.76016f ) ;
  }

  @Test
  public void test110() {
    color.laplace.solve(31.922338f,34.544895f,34.041172f,-6.8555446f,-27.783924f,-58.720287f,-31.560593f,-91.077736f,0f ) ;
  }

  @Test
  public void test111() {
    color.laplace.solve(3.2006905f,-75.24982f,53.235092f,-11.947424f,77.95058f,30.663807f,4.7255135f,30.849478f,40.72182f ) ;
  }

  @Test
  public void test112() {
    color.laplace.solve(32.23551f,29.856386f,37.149376f,-0.91434634f,-49.959343f,18.741133f,-6.5853467f,-25.427046f,-45.163498f ) ;
  }

  @Test
  public void test113() {
    color.laplace.solve(32.350418f,48.885746f,0f,79.904305f,-57.26776f,-49.798042f,16.423134f,-14.211771f,-16.002453f ) ;
  }

  @Test
  public void test114() {
    color.laplace.solve(-32.43564f,-9.228864f,0f,-1.2281994f,-44.854565f,0f,8.776202f,36.333008f,21.509638f ) ;
  }

  @Test
  public void test115() {
    color.laplace.solve(32.461174f,28.16701f,-12.961246f,0.120560445f,6.61933f,5.63749f,-38.598263f,-7.447739f,28.891876f ) ;
  }

  @Test
  public void test116() {
    color.laplace.solve(32.577496f,33.770386f,31.64934f,-3.4604082f,-29.145298f,-17.026632f,-17.273829f,-65.6349f,49.22273f ) ;
  }

  @Test
  public void test117() {
    color.laplace.solve(32.784496f,-27.036234f,0f,24.248323f,-65.938126f,-46.96323f,0.9465915f,-20.461956f,-16.856297f ) ;
  }

  @Test
  public void test118() {
    color.laplace.solve(32.87264f,34.360405f,45.20562f,-2.8698463f,-40.636635f,-100.0f,-3.7153912f,-27.760891f,0f ) ;
  }

  @Test
  public void test119() {
    color.laplace.solve(3.318822f,-60.790768f,1.613399f,-25.933947f,18.058481f,0f,-37.87637f,-48.612915f,0f ) ;
  }

  @Test
  public void test120() {
    color.laplace.solve(3.352225f,-228.53435f,2.1891658f,-60.920776f,-88.333725f,26.745173f,-158.62743f,-90.6398f,76.13577f ) ;
  }

  @Test
  public void test121() {
    color.laplace.solve(33.68207f,47.67792f,-49.0595f,-12.949633f,-34.190388f,89.128586f,-4.73454f,-5.988527f,14.97082f ) ;
  }

  @Test
  public void test122() {
    color.laplace.solve(33.72568f,20.650625f,-94.156235f,14.252103f,43.033054f,-74.04771f,-19.750326f,63.285206f,0f ) ;
  }

  @Test
  public void test123() {
    color.laplace.solve(34.15154f,31.488527f,11.171897f,5.117694f,-19.36938f,-100.0f,5.6886163f,17.636711f,84.22761f ) ;
  }

  @Test
  public void test124() {
    color.laplace.solve(34.282646f,35.397755f,58.849438f,1.7328266f,-51.541065f,100.0f,-28.857838f,87.62979f,0f ) ;
  }

  @Test
  public void test125() {
    color.laplace.solve(34.32681f,29.775448f,-16.601063f,7.531788f,-11.107075f,-23.972145f,6.9074183f,-64.28803f,0f ) ;
  }

  @Test
  public void test126() {
    color.laplace.solve(34.403324f,-13.769696f,53.728825f,51.382988f,-66.88598f,38.761227f,9.677896f,-12.671406f,6.5224547f ) ;
  }

  @Test
  public void test127() {
    color.laplace.solve(-34.600796f,87.165504f,99.997215f,0.33098426f,33.21281f,34.838036f,2.7119238f,10.516711f,6.142111f ) ;
  }

  @Test
  public void test128() {
    color.laplace.solve(34.657562f,28.670261f,27.413132f,9.959986f,-47.38965f,-34.084908f,100.0f,0f,0f ) ;
  }

  @Test
  public void test129() {
    color.laplace.solve(34.68632f,19.77962f,-100.0f,18.96567f,33.436756f,19.996712f,7.7395983f,11.992723f,-26.680237f ) ;
  }

  @Test
  public void test130() {
    color.laplace.solve(35.0027f,36.906643f,33.45549f,3.1041622f,-20.831621f,-11.143233f,-1.7544317f,-12.131534f,0f ) ;
  }

  @Test
  public void test131() {
    color.laplace.solve(35.03828f,55.601322f,76.26373f,-15.448198f,-64.528404f,0f,-32.302673f,0f,0f ) ;
  }

  @Test
  public void test132() {
    color.laplace.solve(35.45382f,60.283615f,-99.59475f,-18.46834f,-25.432648f,-44.099648f,-83.89453f,-99.44622f,55.918037f ) ;
  }

  @Test
  public void test133() {
    color.laplace.solve(35.55562f,-99.126144f,0f,24.936417f,60.19407f,-69.82246f,3.9959824f,-8.952487f,-100.0f ) ;
  }

  @Test
  public void test134() {
    color.laplace.solve(35.68033f,22.373177f,-65.32106f,20.348139f,19.133438f,-3.3329036f,26.578787f,37.14534f,32.85601f ) ;
  }

  @Test
  public void test135() {
    color.laplace.solve(35.87191f,55.559128f,21.647747f,-12.071487f,64.71685f,-68.96814f,14.868849f,15.135168f,0f ) ;
  }

  @Test
  public void test136() {
    color.laplace.solve(-35.917873f,100.0f,-46.61463f,0.8876428f,41.990906f,78.05347f,-2.522461f,-10.977487f,-4.0549865f ) ;
  }

  @Test
  public void test137() {
    color.laplace.solve(35.962326f,30.952745f,13.080738f,12.896555f,-25.23208f,2.1112366f,40.855976f,-44.67802f,0f ) ;
  }

  @Test
  public void test138() {
    color.laplace.solve(36.22633f,28.105375f,-6.213816f,16.79995f,-17.591017f,-9.008418f,52.271122f,-13.63124f,0f ) ;
  }

  @Test
  public void test139() {
    color.laplace.solve(36.308064f,37.72591f,22.757607f,7.506344f,-8.162035f,-49.18675f,1.8793479f,0.011047821f,0f ) ;
  }

  @Test
  public void test140() {
    color.laplace.solve(36.38617f,67.59125f,100.0f,20.984217f,35.985275f,30.08818f,11.565418f,25.277456f,31.51506f ) ;
  }

  @Test
  public void test141() {
    color.laplace.solve(36.44603f,34.712723f,27.183304f,11.07139f,-24.77844f,-99.999985f,32.617973f,-44.897896f,0f ) ;
  }

  @Test
  public void test142() {
    color.laplace.solve(36.59296f,49.51521f,76.55453f,-3.1433606f,-12.444606f,0f,-37.462303f,-21.502748f,0f ) ;
  }

  @Test
  public void test143() {
    color.laplace.solve(36.78024f,54.741333f,95.18477f,-7.620378f,-12.999679f,99.97108f,-54.26207f,-100.0f,0f ) ;
  }

  @Test
  public void test144() {
    color.laplace.solve(36.904213f,48.65468f,-72.52624f,-1.037831f,-8.601025f,-73.641716f,-32.454514f,-8.379232f,0f ) ;
  }

  @Test
  public void test145() {
    color.laplace.solve(36.92554f,48.112827f,77.29708f,-0.41066745f,-23.155302f,-3.242147f,-15.412907f,-61.24096f,0f ) ;
  }

  @Test
  public void test146() {
    color.laplace.solve(36.95151f,31.343674f,-17.152327f,16.462378f,-29.694424f,-25.367609f,58.592422f,-32.117184f,0f ) ;
  }

  @Test
  public void test147() {
    color.laplace.solve(37.113087f,38.37129f,-48.589474f,10.081056f,5.9275846f,-65.2f,-2.7164469f,-20.946844f,-86.99851f ) ;
  }

  @Test
  public void test148() {
    color.laplace.solve(-37.23073f,-56.096058f,0f,-29.743774f,-39.88645f,-100.0f,-41.857918f,26.29403f,0f ) ;
  }

  @Test
  public void test149() {
    color.laplace.solve(37.237907f,27.212133f,40.23781f,21.739492f,-68.62718f,35.490112f,1.5548887f,-15.519939f,4.992543f ) ;
  }

  @Test
  public void test150() {
    color.laplace.solve(37.258198f,43.81701f,40.438026f,5.215782f,-2.4281826f,-79.1764f,-13.966887f,-61.083332f,-37.741158f ) ;
  }

  @Test
  public void test151() {
    color.laplace.solve(37.57773f,41.741306f,26.780594f,8.5696125f,2.6069045f,-34.618935f,-22.81038f,-99.811134f,0f ) ;
  }

  @Test
  public void test152() {
    color.laplace.solve(37.696045f,36.889896f,14.918325f,13.894278f,-5.0547867f,-18.187462f,22.935852f,-52.815857f,0f ) ;
  }

  @Test
  public void test153() {
    color.laplace.solve(37.764732f,63.441006f,88.85265f,-12.382084f,27.78311f,0f,-3.2718382f,-0.70526904f,-27.332348f ) ;
  }

  @Test
  public void test154() {
    color.laplace.solve(37.768383f,37.060097f,-100.0f,10.595139f,3.0431585f,-31.163511f,1.5690124f,-4.319089f,-27.697206f ) ;
  }

  @Test
  public void test155() {
    color.laplace.solve(38.091858f,38.95044f,0f,18.062328f,28.043882f,-85.935074f,6.113573f,6.3919635f,-0.8791296f ) ;
  }

  @Test
  public void test156() {
    color.laplace.solve(38.68868f,37.35982f,-16.026705f,17.394894f,26.777306f,-28.995745f,7.4493084f,12.402341f,74.91723f ) ;
  }

  @Test
  public void test157() {
    color.laplace.solve(38.817238f,2.6958063f,-81.04387f,52.57315f,-46.990143f,49.29384f,48.796356f,46.174355f,0f ) ;
  }

  @Test
  public void test158() {
    color.laplace.solve(39.25484f,22.753233f,-100.0f,34.266136f,-51.184f,18.365887f,5.7592373f,-11.229187f,0.5080131f ) ;
  }

  @Test
  public void test159() {
    color.laplace.solve(39.42638f,35.487946f,-17.488146f,22.217579f,20.013546f,89.614525f,29.430391f,87.19324f,0f ) ;
  }

  @Test
  public void test160() {
    color.laplace.solve(39.520702f,57.28523f,36.43064f,0.79758203f,53.189564f,54.412884f,25.195593f,99.98479f,-97.920395f ) ;
  }

  @Test
  public void test161() {
    color.laplace.solve(3.9571395f,-51.769997f,-215.2721f,-33.748905f,-94.9833f,-21.518257f,-44.207897f,-147.24564f,-85.48041f ) ;
  }

  @Test
  public void test162() {
    color.laplace.solve(39.713478f,-67.15048f,0f,42.430347f,0.09180738f,-6.7467775f,14.597443f,15.959424f,49.148445f ) ;
  }

  @Test
  public void test163() {
    color.laplace.solve(39.986584f,44.28732f,-38.335934f,15.659016f,21.068619f,96.913086f,1.58086f,-85.165245f,0f ) ;
  }

  @Test
  public void test164() {
    color.laplace.solve(40.02397f,32.90101f,-26.673653f,27.194881f,18.253717f,51.78745f,50.501835f,0f,0f ) ;
  }

  @Test
  public void test165() {
    color.laplace.solve(40.24059f,40.881046f,-10.758447f,20.081308f,34.042038f,99.894554f,6.042607f,0f,0f ) ;
  }

  @Test
  public void test166() {
    color.laplace.solve(40.575138f,45.20935f,40.09153f,17.091202f,-2.48246f,0f,11.022689f,26.999556f,99.49626f ) ;
  }

  @Test
  public void test167() {
    color.laplace.solve(40.627167f,29.967886f,56.534542f,32.540775f,-77.29016f,72.675125f,-10.581364f,-35.241623f,0f ) ;
  }

  @Test
  public void test168() {
    color.laplace.solve(40.934017f,46.16901f,14.263723f,17.567055f,-8.20126f,-16.364681f,37.535465f,-80.17642f,-71.52119f ) ;
  }

  @Test
  public void test169() {
    color.laplace.solve(41.051025f,48.6703f,33.256752f,15.533807f,4.306301f,8.677264f,16.777899f,51.57779f,-2.1250074f ) ;
  }

  @Test
  public void test170() {
    color.laplace.solve(41.140007f,51.88318f,55.025986f,12.676856f,11.366713f,100.0f,-1.7992984f,-19.87405f,-96.006424f ) ;
  }

  @Test
  public void test171() {
    color.laplace.solve(41.551136f,83.928955f,100.0f,-17.724401f,-20.418707f,-73.74398f,-92.03004f,100.0f,0f ) ;
  }

  @Test
  public void test172() {
    color.laplace.solve(-41.57779f,5.7591844f,0f,-0.14618824f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test173() {
    color.laplace.solve(41.60068f,-69.823204f,0f,20.48488f,42.565456f,52.03302f,-2.226615f,-29.39134f,21.940468f ) ;
  }

  @Test
  public void test174() {
    color.laplace.solve(41.853848f,57.367558f,21.382534f,14.661636f,18.899693f,26.659176f,-2.1069918f,-23.089603f,100.0f ) ;
  }

  @Test
  public void test175() {
    color.laplace.solve(-42.088577f,57.500034f,0f,1.493358f,49.453682f,70.43686f,-1.3916752f,-7.060059f,-81.57658f ) ;
  }

  @Test
  public void test176() {
    color.laplace.solve(-42.465714f,-61.682884f,34.253666f,-8.885954f,-30.169834f,18.327784f,37.091732f,-68.43828f,69.2273f ) ;
  }

  @Test
  public void test177() {
    color.laplace.solve(42.60588f,-66.53731f,0f,-18.526722f,-100.0f,0f,-18.607151f,-55.901882f,-6.294585f ) ;
  }

  @Test
  public void test178() {
    color.laplace.solve(-4.268103f,-34.92001f,0f,-6.885395f,-24.136358f,43.34673f,0.86288065f,10.336918f,64.62115f ) ;
  }

  @Test
  public void test179() {
    color.laplace.solve(42.701126f,64.99812f,0f,11.735982f,2.1105173f,-46.558357f,2.132281f,-3.2068577f,-17.070229f ) ;
  }

  @Test
  public void test180() {
    color.laplace.solve(43.035904f,46.562428f,-47.66372f,25.581182f,62.288338f,-27.484818f,-2.9995112f,-3.0612352f,0f ) ;
  }

  @Test
  public void test181() {
    color.laplace.solve(43.598083f,44.9683f,-30.380348f,29.424026f,66.65547f,-43.259827f,7.4425516f,-41.60522f,0f ) ;
  }

  @Test
  public void test182() {
    color.laplace.solve(43.6501f,40.69344f,0f,32.666424f,54.610474f,7.9018064f,32.405117f,43.733425f,0f ) ;
  }

  @Test
  public void test183() {
    color.laplace.solve(43.656677f,52.595333f,-78.7221f,22.03137f,23.062006f,-45.974503f,21.4068f,63.595825f,74.755005f ) ;
  }

  @Test
  public void test184() {
    color.laplace.solve(43.712776f,45.43825f,-22.128937f,29.412853f,51.11258f,67.707825f,22.82606f,61.891384f,92.208275f ) ;
  }

  @Test
  public void test185() {
    color.laplace.solve(44.022907f,54.03192f,67.232796f,22.059713f,4.871974f,34.16637f,23.435373f,-59.016846f,0f ) ;
  }

  @Test
  public void test186() {
    color.laplace.solve(44.31175f,63.86909f,85.16339f,13.377899f,52.426285f,0f,-43.9362f,0f,0f ) ;
  }

  @Test
  public void test187() {
    color.laplace.solve(44.31519f,59.10218f,65.35716f,18.158573f,26.736374f,-14.436049f,1.8156316f,-10.896046f,-72.13619f ) ;
  }

  @Test
  public void test188() {
    color.laplace.solve(-44.390293f,-35.662193f,0f,97.416115f,77.44581f,0f,92.87644f,0f,0f ) ;
  }

  @Test
  public void test189() {
    color.laplace.solve(44.54016f,80.52932f,-43.976006f,-2.3686705f,27.54661f,27.03476f,-81.561455f,4.9910307f,-52.1018f ) ;
  }

  @Test
  public void test190() {
    color.laplace.solve(44.6074f,54.65446f,20.444483f,23.775135f,53.565964f,-80.665f,-3.0728247f,-36.066433f,0f ) ;
  }

  @Test
  public void test191() {
    color.laplace.solve(44.716045f,63.283806f,99.94514f,15.580367f,8.474047f,86.64383f,9.656184f,23.044369f,-60.84712f ) ;
  }

  @Test
  public void test192() {
    color.laplace.solve(45.109394f,15.525538f,-36.318966f,64.91204f,-46.688274f,27.150051f,15.811482f,-1.6661127f,7.2413735f ) ;
  }

  @Test
  public void test193() {
    color.laplace.solve(45.344086f,58.250942f,34.906204f,23.125397f,52.753483f,-18.626127f,-15.151712f,-83.73225f,26.878925f ) ;
  }

  @Test
  public void test194() {
    color.laplace.solve(45.39029f,53.469284f,-100.0f,28.091873f,63.040176f,-54.65425f,3.937028f,-12.343761f,-32.600533f ) ;
  }

  @Test
  public void test195() {
    color.laplace.solve(-4.556331f,-77.91117f,0f,-11.608597f,-48.831093f,23.99823f,6.9530396f,39.420753f,0f ) ;
  }

  @Test
  public void test196() {
    color.laplace.solve(45.563465f,77.39068f,90.454575f,4.8631787f,73.54467f,100.0f,-99.65542f,99.89849f,0f ) ;
  }

  @Test
  public void test197() {
    color.laplace.solve(45.600494f,30.294798f,7.3211584f,52.10718f,-31.742464f,32.589428f,6.4417605f,-26.340141f,-80.05986f ) ;
  }

  @Test
  public void test198() {
    color.laplace.solve(45.60433f,43.71263f,28.761106f,38.70469f,0.48508534f,-32.46491f,8.026188f,-6.599936f,0f ) ;
  }

  @Test
  public void test199() {
    color.laplace.solve(-45.611f,3.7970686f,0f,1.0573008f,68.173454f,39.854027f,-18.33325f,-74.390305f,0f ) ;
  }

  @Test
  public void test200() {
    color.laplace.solve(-45.61682f,30.402044f,0f,-14.923215f,-8.699853f,-42.418606f,-5.3761826f,-6.5815163f,-12.2500305f ) ;
  }

  @Test
  public void test201() {
    color.laplace.solve(45.680634f,38.122345f,35.602352f,44.60018f,-70.01603f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test202() {
    color.laplace.solve(-45.82176f,-50.044506f,0f,-21.301563f,95.49285f,0f,12.263221f,70.35445f,-58.235176f ) ;
  }

  @Test
  public void test203() {
    color.laplace.solve(-45.856712f,-269.30756f,114.68328f,-14.125576f,26.302168f,-84.5313f,-37.280872f,-134.90273f,0f ) ;
  }

  @Test
  public void test204() {
    color.laplace.solve(46.98069f,49.48383f,1.4678595f,38.43894f,18.83939f,-8.849387f,87.93567f,-3.71582f,-55.7048f ) ;
  }

  @Test
  public void test205() {
    color.laplace.solve(47.107845f,69.689445f,-80.99906f,16.075865f,14.181263f,-25.021805f,3.0143528f,-4.0184517f,-33.269424f ) ;
  }

  @Test
  public void test206() {
    color.laplace.solve(47.165657f,54.46809f,41.223183f,34.194542f,29.48352f,10.424635f,28.25141f,0f,0f ) ;
  }

  @Test
  public void test207() {
    color.laplace.solve(47.27983f,60.796055f,4.973511f,28.323267f,2.3756528f,-17.209124f,63.63758f,-62.407585f,-23.302427f ) ;
  }

  @Test
  public void test208() {
    color.laplace.solve(47.334393f,38.36559f,-0.95580465f,50.971977f,7.083768f,2.0120456f,-1.2154996f,-55.833977f,0f ) ;
  }

  @Test
  public void test209() {
    color.laplace.solve(47.465397f,48.892147f,-49.520546f,40.96944f,97.62373f,-95.9024f,18.788628f,34.18507f,-42.71555f ) ;
  }

  @Test
  public void test210() {
    color.laplace.solve(47.60134f,43.91053f,56.59736f,46.494835f,-28.556574f,45.009907f,7.4735966f,-16.600447f,-45.318813f ) ;
  }

  @Test
  public void test211() {
    color.laplace.solve(47.92914f,35.752007f,-14.419953f,55.964546f,77.822464f,25.74779f,98.106575f,76.17503f,0f ) ;
  }

  @Test
  public void test212() {
    color.laplace.solve(48.27014f,35.373302f,0f,9.120468f,-37.301857f,0f,25.513586f,0f,0f ) ;
  }

  @Test
  public void test213() {
    color.laplace.solve(48.31966f,61.617165f,-100.0f,31.661478f,44.953835f,-6.4844017f,11.575949f,14.642315f,2.0394783f ) ;
  }

  @Test
  public void test214() {
    color.laplace.solve(48.781944f,24.140718f,0f,24.494223f,-23.317383f,0f,31.123556f,100.0f,30.087946f ) ;
  }

  @Test
  public void test215() {
    color.laplace.solve(48.81185f,74.02392f,-39.803276f,21.223492f,28.703333f,-19.953703f,7.3787856f,8.291652f,-2.9155128f ) ;
  }

  @Test
  public void test216() {
    color.laplace.solve(48.81208f,98.53911f,-71.90836f,-3.2907917f,-55.347153f,0f,-7.3098307f,-25.948532f,-41.13714f ) ;
  }

  @Test
  public void test217() {
    color.laplace.solve(48.946083f,55.629f,-7.2847857f,40.155334f,80.85471f,94.08959f,30.820534f,83.1268f,0f ) ;
  }

  @Test
  public void test218() {
    color.laplace.solve(48.959595f,90.06196f,-100.0f,5.7764273f,-8.499824f,-55.81027f,-17.354063f,15.138655f,0f ) ;
  }

  @Test
  public void test219() {
    color.laplace.solve(49.363243f,85.59001f,-19.264214f,11.862955f,7.336899f,-76.1814f,-9.248319f,8.076027f,31.678822f ) ;
  }

  @Test
  public void test220() {
    color.laplace.solve(49.403145f,65.9185f,47.8277f,31.69407f,66.44316f,-41.088425f,10.929979f,12.025846f,-88.22981f ) ;
  }

  @Test
  public void test221() {
    color.laplace.solve(49.51577f,20.857187f,-62.913013f,77.20589f,-13.899504f,0f,30.816212f,44.991787f,0f ) ;
  }

  @Test
  public void test222() {
    color.laplace.solve(49.567406f,21.94343f,-66.32632f,76.3262f,4.532631f,-61.757645f,18.448557f,61.28574f,0f ) ;
  }

  @Test
  public void test223() {
    color.laplace.solve(49.674244f,64.94511f,60.513134f,33.75212f,49.59305f,-52.679165f,11.642419f,12.817555f,-9.965371f ) ;
  }

  @Test
  public void test224() {
    color.laplace.solve(49.78154f,76.192566f,88.58325f,22.933592f,66.405464f,74.18601f,-24.452635f,0f,0f ) ;
  }

  @Test
  public void test225() {
    color.laplace.solve(49.846764f,57.134136f,-21.31022f,42.253082f,100.0f,-99.38952f,19.16557f,34.408604f,18.46766f ) ;
  }

  @Test
  public void test226() {
    color.laplace.solve(4.994877f,-28.330334f,28.2728f,-51.69016f,-36.33376f,0f,-81.05348f,0f,0f ) ;
  }

  @Test
  public void test227() {
    color.laplace.solve(50.23187f,63.499752f,52.408195f,37.427723f,51.35894f,43.596313f,48.12008f,14.05825f,0f ) ;
  }

  @Test
  public void test228() {
    color.laplace.solve(50.516026f,41.94062f,3.1036751f,19.504782f,22.702518f,29.667124f,4.8005815f,-0.3024549f,-28.71292f ) ;
  }

  @Test
  public void test229() {
    color.laplace.solve(50.626457f,99.99679f,100.0f,2.5090377f,-34.26761f,-100.0f,-6.322697f,-27.799826f,-70.60899f ) ;
  }

  @Test
  public void test230() {
    color.laplace.solve(51.00632f,68.41379f,22.747889f,35.611492f,99.90094f,-77.32506f,-8.461297f,39.222553f,0f ) ;
  }

  @Test
  public void test231() {
    color.laplace.solve(51.81776f,68.81053f,99.999985f,38.46051f,23.42438f,19.405357f,32.01525f,89.60049f,-100.0f ) ;
  }

  @Test
  public void test232() {
    color.laplace.solve(52.006203f,-100.0f,0f,-5.6620045f,-68.02386f,-14.275056f,-6.630367f,-20.859463f,-8.783629f ) ;
  }

  @Test
  public void test233() {
    color.laplace.solve(52.116364f,-25.040503f,0f,16.308386f,1.9867982f,21.263536f,11.13038f,28.213133f,0f ) ;
  }

  @Test
  public void test234() {
    color.laplace.solve(52.132435f,61.65971f,5.4690228f,17.342031f,19.537455f,25.697176f,-2.3017664f,-26.549097f,0.87657213f ) ;
  }

  @Test
  public void test235() {
    color.laplace.solve(52.16669f,-71.5464f,0f,12.516889f,3.8812633f,76.9013f,-5.9804015f,11.572438f,0f ) ;
  }

  @Test
  public void test236() {
    color.laplace.solve(52.176018f,75.47225f,-76.899956f,33.23182f,56.93887f,-50.874744f,23.812395f,62.01776f,0f ) ;
  }

  @Test
  public void test237() {
    color.laplace.solve(52.179424f,-48.105316f,0f,24.383142f,-81.53616f,0f,25.085533f,0f,0f ) ;
  }

  @Test
  public void test238() {
    color.laplace.solve(52.39871f,69.44269f,52.56346f,33.280533f,73.38154f,-62.20138f,2.7757578f,-27.200352f,-184.35432f ) ;
  }

  @Test
  public void test239() {
    color.laplace.solve(-52.4265f,-31.068743f,35.349327f,10.665589f,8.411532f,11.547808f,86.67732f,42.501476f,2.4303696f ) ;
  }

  @Test
  public void test240() {
    color.laplace.solve(-52.80208f,100.0f,100.0f,-24.131348f,-18.584497f,-73.78272f,-25.138817f,-76.42391f,-100.0f ) ;
  }

  @Test
  public void test241() {
    color.laplace.solve(-5.2868f,-76.761826f,-38.523563f,-10.07214f,-9.825302f,36.488033f,-25.176456f,11.0447235f,-37.505417f ) ;
  }

  @Test
  public void test242() {
    color.laplace.solve(53.330616f,14.286174f,0f,-5.345514f,-71.14132f,64.93297f,-3.5713508f,-8.93989f,-10.8889065f ) ;
  }

  @Test
  public void test243() {
    color.laplace.solve(53.941803f,71.86607f,59.50119f,43.90113f,78.71979f,0f,39.320095f,-31.44469f,0f ) ;
  }

  @Test
  public void test244() {
    color.laplace.solve(54.490726f,85.08246f,-75.5874f,31.807673f,58.795013f,94.3178f,13.944948f,23.97212f,-5.8404126f ) ;
  }

  @Test
  public void test245() {
    color.laplace.solve(54.66579f,57.083508f,64.60438f,61.579655f,9.063861f,-58.33742f,13.259267f,-8.54259f,-56.493484f ) ;
  }

  @Test
  public void test246() {
    color.laplace.solve(-5.4700236f,-99.889626f,-0.6926625f,-21.99047f,99.92921f,100.0f,3.03321f,34.12331f,33.530827f ) ;
  }

  @Test
  public void test247() {
    color.laplace.solve(55.272797f,32.36828f,-53.393715f,88.722916f,27.594034f,-66.28771f,9.36073f,-51.27999f,-23.449493f ) ;
  }

  @Test
  public void test248() {
    color.laplace.solve(55.377865f,44.908234f,26.102734f,76.60323f,-1.8476686f,-55.026707f,0f,0f,0f ) ;
  }

  @Test
  public void test249() {
    color.laplace.solve(55.993053f,22.638577f,-34.615105f,7.140503f,-9.118003f,14.141562f,-18.313038f,-80.392654f,-100.0f ) ;
  }

  @Test
  public void test250() {
    color.laplace.solve(-56.523647f,78.84656f,0f,-16.964756f,-74.858315f,0f,63.522938f,0f,0f ) ;
  }

  @Test
  public void test251() {
    color.laplace.solve(57.87335f,64.11415f,0f,-36.8087f,-25.078714f,0f,15.23658f,97.75502f,13.795842f ) ;
  }

  @Test
  public void test252() {
    color.laplace.solve(57.969276f,45.150223f,-60.00978f,86.72688f,-20.844524f,0f,31.901983f,40.88105f,-100.0f ) ;
  }

  @Test
  public void test253() {
    color.laplace.solve(-59.390224f,54.16675f,0f,-27.81681f,-54.683666f,-54.643604f,2.8066509f,13.298911f,0f ) ;
  }

  @Test
  public void test254() {
    color.laplace.solve(59.42374f,52.023365f,29.658747f,85.6716f,19.01097f,96.136215f,26.716127f,21.19291f,39.044537f ) ;
  }

  @Test
  public void test255() {
    color.laplace.solve(-59.54338f,51.19468f,-66.53486f,-8.483907f,20.325289f,8.97661f,5.2824664f,29.613773f,2.6707542f ) ;
  }

  @Test
  public void test256() {
    color.laplace.solve(60.60312f,-11.133381f,0f,21.67607f,73.66805f,0f,-7.5696707f,3.8086088f,0f ) ;
  }

  @Test
  public void test257() {
    color.laplace.solve(62.8843f,62.18543f,-75.028435f,7.1678424f,-15.2203665f,-47.096626f,-18.992567f,-83.13811f,-98.13771f ) ;
  }

  @Test
  public void test258() {
    color.laplace.solve(63.886295f,96.12156f,-61.012016f,59.42362f,-76.072845f,0f,-36.366035f,0f,0f ) ;
  }

  @Test
  public void test259() {
    color.laplace.solve(64.09144f,95.685005f,0f,60.680737f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test260() {
    color.laplace.solve(-6.5927324f,69.05462f,0f,-98.88226f,62.294075f,-64.57715f,-27.18473f,-9.856659f,-74.53598f ) ;
  }

  @Test
  public void test261() {
    color.laplace.solve(65.98012f,68.63294f,100.0f,95.287544f,100.0f,0f,25.558128f,6.944964f,-97.778275f ) ;
  }

  @Test
  public void test262() {
    color.laplace.solve(66.41582f,8.051064f,0f,20.084637f,3.625011f,1.9132503f,10.297721f,21.106249f,70.50226f ) ;
  }

  @Test
  public void test263() {
    color.laplace.solve(66.682556f,20.431332f,0f,80.8766f,-56.40978f,0f,21.577904f,5.4350104f,0f ) ;
  }

  @Test
  public void test264() {
    color.laplace.solve(67.328156f,50.936512f,0f,3.914513f,31.04105f,56.96958f,-82.71115f,12.343593f,0f ) ;
  }

  @Test
  public void test265() {
    color.laplace.solve(-67.93732f,-87.993805f,0f,25.628443f,-70.8736f,64.397896f,2.8195496f,-14.3502445f,10.653066f ) ;
  }

  @Test
  public void test266() {
    color.laplace.solve(68.07226f,73.388725f,-38.5991f,98.9003f,-71.36916f,0f,11.008727f,-54.865387f,0f ) ;
  }

  @Test
  public void test267() {
    color.laplace.solve(-6.875984f,-21.64031f,0f,10.004951f,75.04933f,0f,6.8100343f,17.235188f,-12.918617f ) ;
  }

  @Test
  public void test268() {
    color.laplace.solve(69.36843f,-26.09878f,99.749435f,21.56396f,15.036937f,78.84467f,1.850463f,-14.1621065f,26.39918f ) ;
  }

  @Test
  public void test269() {
    color.laplace.solve(69.82654f,43.317574f,0f,35.90953f,53.113434f,-81.98502f,20.698145f,46.883053f,-67.65248f ) ;
  }

  @Test
  public void test270() {
    color.laplace.solve(70.27226f,99.26814f,-22.09247f,81.82091f,78.157394f,-42.43539f,26.822395f,25.468674f,-3.105094f ) ;
  }

  @Test
  public void test271() {
    color.laplace.solve(71.36657f,146.40825f,-37.963116f,30.82009f,40.42363f,-11.24508f,7.5961175f,-0.087769724f,-47.338688f ) ;
  }

  @Test
  public void test272() {
    color.laplace.solve(7.164927f,23.144403f,0f,-77.661606f,3.6964264f,0f,-29.885004f,-41.878414f,0f ) ;
  }

  @Test
  public void test273() {
    color.laplace.solve(-7.172659f,-2.5363157f,-69.88089f,-10.365996f,-22.754713f,-41.0068f,-11.536614f,-37.109737f,32.431137f ) ;
  }

  @Test
  public void test274() {
    color.laplace.solve(73.55142f,83.731445f,94.680595f,10.269535f,29.331072f,-16.255232f,-61.80435f,39.578537f,-65.140144f ) ;
  }

  @Test
  public void test275() {
    color.laplace.solve(-73.65344f,14.417749f,0f,-19.483025f,-45.806866f,0f,18.53776f,44.62668f,0f ) ;
  }

  @Test
  public void test276() {
    color.laplace.solve(73.76234f,-12.6729355f,0f,41.783257f,96.330894f,45.68042f,-2.96021f,-29.497168f,0f ) ;
  }

  @Test
  public void test277() {
    color.laplace.solve(-75.68097f,19.065952f,0f,-21.574532f,-4.2443643f,-56.9455f,-6.3727927f,-3.9166381f,-5.0493956f ) ;
  }

  @Test
  public void test278() {
    color.laplace.solve(75.687935f,88.57133f,0f,-69.6449f,97.78636f,0f,-8.24846f,36.651054f,57.066315f ) ;
  }

  @Test
  public void test279() {
    color.laplace.solve(75.82493f,-9.495565f,0f,-7.208896f,-96.78167f,-5.051667f,-7.8788414f,-24.30647f,7.434632f ) ;
  }

  @Test
  public void test280() {
    color.laplace.solve(76.8326f,-8.427344f,0f,12.28297f,6.708209f,11.881874f,-34.408936f,-60.39104f,0f ) ;
  }

  @Test
  public void test281() {
    color.laplace.solve(77.036415f,9.556166f,0f,-58.609756f,61.741516f,0f,-16.58625f,-7.735247f,7.768479f ) ;
  }

  @Test
  public void test282() {
    color.laplace.solve(-77.32637f,-100.0f,0f,-16.174267f,17.205862f,-82.49681f,-4.57656f,-2.1319737f,-21.157196f ) ;
  }

  @Test
  public void test283() {
    color.laplace.solve(77.8452f,13.862114f,0f,59.84817f,44.084827f,0f,79.57293f,-22.33597f,0f ) ;
  }

  @Test
  public void test284() {
    color.laplace.solve(7.8179603f,-71.97157f,16.412045f,-6.3267827f,-26.461344f,-7.218814f,-6.6637473f,-20.328207f,-18.825956f ) ;
  }

  @Test
  public void test285() {
    color.laplace.solve(-79.0479f,18.215864f,0f,-4.6909904f,-10.533454f,-83.61247f,70.81739f,56.93281f,0f ) ;
  }

  @Test
  public void test286() {
    color.laplace.solve(7.936123f,31.637678f,0f,-89.42777f,-54.237347f,0f,4.464873f,0f,0f ) ;
  }

  @Test
  public void test287() {
    color.laplace.solve(80.39332f,61.69941f,0f,-29.746325f,26.80991f,0f,-15.66535f,-32.915077f,0f ) ;
  }

  @Test
  public void test288() {
    color.laplace.solve(80.65667f,12.696714f,25.120584f,28.913927f,19.771566f,5.479674f,15.2274685f,31.995949f,92.98476f ) ;
  }

  @Test
  public void test289() {
    color.laplace.solve(-8.144756f,-136.15178f,-187.45932f,3.5800803f,-76.34707f,-18.197443f,98.89958f,-21.072983f,0f ) ;
  }

  @Test
  public void test290() {
    color.laplace.solve(-81.8891f,49.79627f,0f,-15.250393f,19.332613f,0f,0.4514901f,17.056353f,48.44131f ) ;
  }

  @Test
  public void test291() {
    color.laplace.solve(82.1894f,100.0f,0f,24.128618f,-99.30674f,0f,6.480516f,1.7934442f,100.0f ) ;
  }

  @Test
  public void test292() {
    color.laplace.solve(82.426216f,24.239702f,0f,-85.46386f,28.726883f,9.225091f,-20.675451f,2.7620547f,2.9967864f ) ;
  }

  @Test
  public void test293() {
    color.laplace.solve(-83.34779f,-99.884224f,0f,-3.911542f,34.52473f,42.345387f,33.1769f,52.149403f,0f ) ;
  }

  @Test
  public void test294() {
    color.laplace.solve(86.53413f,67.53075f,-48.50881f,36.7113f,27.629555f,-87.73858f,32.681515f,94.01476f,87.50415f ) ;
  }

  @Test
  public void test295() {
    color.laplace.solve(8.665938f,-44.37086f,47.775875f,-18.62926f,-14.009932f,-58.97836f,-69.17304f,65.93875f,-43.07672f ) ;
  }

  @Test
  public void test296() {
    color.laplace.solve(-86.98185f,-81.61567f,35.35421f,-50.720413f,-20.839304f,26.15749f,-95.06049f,22.821383f,90.11505f ) ;
  }

  @Test
  public void test297() {
    color.laplace.solve(8.853285f,-25.958246f,-134.86711f,-38.634205f,-77.84323f,81.65026f,-77.507645f,-109.33061f,0f ) ;
  }

  @Test
  public void test298() {
    color.laplace.solve(91.55382f,5.964392f,0f,26.54127f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test299() {
    color.laplace.solve(9.158109f,-19.184986f,37.450542f,-44.18258f,-9.408943f,0f,0.3298341f,45.501915f,0f ) ;
  }

  @Test
  public void test300() {
    color.laplace.solve(9.26337f,21.774649f,24.491423f,-84.72117f,-46.656197f,-23.80896f,-10.91401f,41.06513f,0f ) ;
  }

  @Test
  public void test301() {
    color.laplace.solve(96.39259f,8.29087f,-78.8799f,37.061935f,-10.64655f,-85.54832f,62.501694f,-2.3906868f,17.183285f ) ;
  }

  @Test
  public void test302() {
    color.laplace.solve(-9.760179f,48.12772f,0f,30.483778f,-45.371822f,0f,17.511267f,44.600365f,0f ) ;
  }

  @Test
  public void test303() {
    color.laplace.solve(97.83246f,-90.62023f,0f,-95.29631f,80.17625f,0f,-40.70417f,0f,0f ) ;
  }

  @Test
  public void test304() {
    color.laplace.solve(98.78246f,56.580563f,0f,22.581573f,-59.255283f,0f,-77.616585f,-58.199455f,0f ) ;
  }

  @Test
  public void test305() {
    color.laplace.solve(9.939089f,-52.774956f,78.98056f,-5.878831f,-20.373747f,23.602627f,-13.080666f,-46.44383f,35.803696f ) ;
  }

  @Test
  public void test306() {
    color.laplace.solve(99.96838f,-43.44432f,-24.947052f,21.882341f,-16.003626f,-34.82861f,3.5646074f,-7.6239114f,-18.056627f ) ;
  }

  @Test
  public void test307() {
    color.laplace.solve(99.99891f,97.70109f,8.511704f,31.033937f,20.560486f,-29.764551f,3.5763521f,-16.728527f,-66.181656f ) ;
  }

  @Test
  public void test308() {
    color.laplace.solve(-99.99999f,18.759594f,-84.07664f,-29.740608f,-10.155138f,-24.150995f,-8.807299f,-5.4885287f,-2.9916792f ) ;
  }
}
