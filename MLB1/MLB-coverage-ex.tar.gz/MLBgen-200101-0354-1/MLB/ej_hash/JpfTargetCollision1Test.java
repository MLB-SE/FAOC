import org.junit.Test;

public class JpfTargetCollision1Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision1(198,-246,75,147,-1801,881 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision1(886,226,-299,369,-503,873 ) ;
  }
}
