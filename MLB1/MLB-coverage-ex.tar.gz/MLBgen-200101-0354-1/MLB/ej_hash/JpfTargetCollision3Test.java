import org.junit.Test;

public class JpfTargetCollision3Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision3(247,846 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision3(-25875,-89 ) ;
  }
}
