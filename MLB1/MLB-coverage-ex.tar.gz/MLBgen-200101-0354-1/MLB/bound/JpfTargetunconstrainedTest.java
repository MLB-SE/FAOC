import org.junit.Test;

public class JpfTargetunconstrainedTest {

  @Test
  public void test0() {
    bound.unconstrained.solve(10,0,0,0 ) ;
  }

  @Test
  public void test1() {
    bound.unconstrained.solve(1,3,340,0 ) ;
  }

  @Test
  public void test2() {
    bound.unconstrained.solve(171,0,0,0 ) ;
  }

  @Test
  public void test3() {
    bound.unconstrained.solve(3,3,3,723 ) ;
  }

  @Test
  public void test4() {
    bound.unconstrained.solve(3,-45,0,0 ) ;
  }

  @Test
  public void test5() {
    bound.unconstrained.solve(3,7,0,0 ) ;
  }

  @Test
  public void test6() {
    bound.unconstrained.solve(3,9,-46,0 ) ;
  }

  @Test
  public void test7() {
    bound.unconstrained.solve(3,967,0,0 ) ;
  }

  @Test
  public void test8() {
    bound.unconstrained.solve(4,3,984,0 ) ;
  }

  @Test
  public void test9() {
    bound.unconstrained.solve(5,9,5,5 ) ;
  }

  @Test
  public void test10() {
    bound.unconstrained.solve(7,305,0,0 ) ;
  }

  @Test
  public void test11() {
    bound.unconstrained.solve(7,6,9,-153 ) ;
  }

  @Test
  public void test12() {
    bound.unconstrained.solve(7,8,2,3 ) ;
  }

  @Test
  public void test13() {
    bound.unconstrained.solve(7,9,8,1272 ) ;
  }

  @Test
  public void test14() {
    bound.unconstrained.solve(873,0,0,0 ) ;
  }

  @Test
  public void test15() {
    bound.unconstrained.solve(-913,0,0,0 ) ;
  }

  @Test
  public void test16() {
    bound.unconstrained.solve(9,1,4,9 ) ;
  }

  @Test
  public void test17() {
    bound.unconstrained.solve(9,2,9,0 ) ;
  }
}
