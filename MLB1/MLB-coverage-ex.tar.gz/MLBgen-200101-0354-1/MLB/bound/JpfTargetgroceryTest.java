import org.junit.Test;

public class JpfTargetgroceryTest {

  @Test
  public void test0() {
    bound.grocery.solve(114,576,0,0 ) ;
  }

  @Test
  public void test1() {
    bound.grocery.solve(1,362,303,45 ) ;
  }

  @Test
  public void test2() {
    bound.grocery.solve(153,733,0,0 ) ;
  }

  @Test
  public void test3() {
    bound.grocery.solve(166,27,382,247 ) ;
  }

  @Test
  public void test4() {
    bound.grocery.solve(172,68,371,100 ) ;
  }

  @Test
  public void test5() {
    bound.grocery.solve(263,-321,0,0 ) ;
  }

  @Test
  public void test6() {
    bound.grocery.solve(270,662,515,0 ) ;
  }

  @Test
  public void test7() {
    bound.grocery.solve(305,610,267,0 ) ;
  }

  @Test
  public void test8() {
    bound.grocery.solve(311,0,0,0 ) ;
  }

  @Test
  public void test9() {
    bound.grocery.solve(313,91,318,177 ) ;
  }

  @Test
  public void test10() {
    bound.grocery.solve(322,168,431,485 ) ;
  }

  @Test
  public void test11() {
    bound.grocery.solve(-384,0,0,0 ) ;
  }

  @Test
  public void test12() {
    bound.grocery.solve(386,283,-607,0 ) ;
  }

  @Test
  public void test13() {
    bound.grocery.solve(491,25,154,41 ) ;
  }

  @Test
  public void test14() {
    bound.grocery.solve(499,61,412,809 ) ;
  }

  @Test
  public void test15() {
    bound.grocery.solve(527,0,0,0 ) ;
  }

  @Test
  public void test16() {
    bound.grocery.solve(616,413,219,-504 ) ;
  }

  @Test
  public void test17() {
    bound.grocery.solve(631,237,786,0 ) ;
  }

  @Test
  public void test18() {
    bound.grocery.solve(90,160,299,162 ) ;
  }

  @Test
  public void test19() {
    bound.grocery.solve(908,0,0,0 ) ;
  }

  @Test
  public void test20() {
    bound.grocery.solve(96,966,0,0 ) ;
  }
}
