import org.junit.Test;

public class JpfTargetgolombTest {

  @Test
  public void test0() {
    bound.golomb.solve(0,0,0 ) ;
  }

  @Test
  public void test1() {
    bound.golomb.solve(0,0,2 ) ;
  }

  @Test
  public void test2() {
    bound.golomb.solve(0,0,-27 ) ;
  }

  @Test
  public void test3() {
    bound.golomb.solve(0,0,4 ) ;
  }

  @Test
  public void test4() {
    bound.golomb.solve(0,0,5 ) ;
  }

  @Test
  public void test5() {
    bound.golomb.solve(0,1,0 ) ;
  }

  @Test
  public void test6() {
    bound.golomb.solve(0,3,6 ) ;
  }

  @Test
  public void test7() {
    bound.golomb.solve(0,6,1 ) ;
  }

  @Test
  public void test8() {
    bound.golomb.solve(1,0,1 ) ;
  }

  @Test
  public void test9() {
    bound.golomb.solve(1,2,4 ) ;
  }

  @Test
  public void test10() {
    bound.golomb.solve(1,5,6 ) ;
  }

  @Test
  public void test11() {
    bound.golomb.solve(2,1,495 ) ;
  }

  @Test
  public void test12() {
    bound.golomb.solve(2,-90,0 ) ;
  }

  @Test
  public void test13() {
    bound.golomb.solve(3,0,0 ) ;
  }

  @Test
  public void test14() {
    bound.golomb.solve(3,3,0 ) ;
  }

  @Test
  public void test15() {
    bound.golomb.solve(3,4,6 ) ;
  }

  @Test
  public void test16() {
    bound.golomb.solve(389,0,0 ) ;
  }

  @Test
  public void test17() {
    bound.golomb.solve(4,4,0 ) ;
  }

  @Test
  public void test18() {
    bound.golomb.solve(4,5,6 ) ;
  }

  @Test
  public void test19() {
    bound.golomb.solve(4,5,780 ) ;
  }

  @Test
  public void test20() {
    bound.golomb.solve(4,6,2 ) ;
  }

  @Test
  public void test21() {
    bound.golomb.solve(524,0,0 ) ;
  }

  @Test
  public void test22() {
    bound.golomb.solve(5,397,0 ) ;
  }

  @Test
  public void test23() {
    bound.golomb.solve(5,5,6 ) ;
  }

  @Test
  public void test24() {
    bound.golomb.solve(6,51,0 ) ;
  }

  @Test
  public void test25() {
    bound.golomb.solve(6,5,5 ) ;
  }

  @Test
  public void test26() {
    bound.golomb.solve(-924,0,0 ) ;
  }
}
