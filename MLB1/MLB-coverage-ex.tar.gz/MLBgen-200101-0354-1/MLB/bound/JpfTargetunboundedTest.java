import org.junit.Test;

public class JpfTargetunboundedTest {

  @Test
  public void test0() {
    bound.unbounded.solve(-235,298 ) ;
  }

  @Test
  public void test1() {
    bound.unbounded.solve(-619,56 ) ;
  }

  @Test
  public void test2() {
    bound.unbounded.solve(827,852 ) ;
  }

  @Test
  public void test3() {
    bound.unbounded.solve(-880,-557 ) ;
  }
}
