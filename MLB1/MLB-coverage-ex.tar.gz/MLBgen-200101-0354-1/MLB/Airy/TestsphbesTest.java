import org.junit.Test;

public class TestsphbesTest {

  @Test
  public void test0() {
    airy.sphbes(0,10.81270328896457 ) ;
  }

  @Test
  public void test1() {
    airy.sphbes(0,-1999.270682237333 ) ;
  }

  @Test
  public void test2() {
    airy.sphbes(0,2.0 ) ;
  }

  @Test
  public void test3() {
    airy.sphbes(0,-2025.5761168320587 ) ;
  }

  @Test
  public void test4() {
    airy.sphbes(0,-2156.6948798599533 ) ;
  }

  @Test
  public void test5() {
    airy.sphbes(0,-2221.9381463132518 ) ;
  }

  @Test
  public void test6() {
    airy.sphbes(0,-2507.2042560846776 ) ;
  }

  @Test
  public void test7() {
    airy.sphbes(0,45.405994824081034 ) ;
  }

  @Test
  public void test8() {
    airy.sphbes(0,54.77373222728377 ) ;
  }

  @Test
  public void test9() {
    airy.sphbes(-1089,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test10() {
    airy.sphbes(114,0.0 ) ;
  }

  @Test
  public void test11() {
    airy.sphbes(-1,-166.3826351588667 ) ;
  }

  @Test
  public void test12() {
    airy.sphbes(-1,1.999999999999997 ) ;
  }

  @Test
  public void test13() {
    airy.sphbes(-1,1.9999999999999996 ) ;
  }

  @Test
  public void test14() {
    airy.sphbes(-1,2.045784616002913 ) ;
  }

  @Test
  public void test15() {
    airy.sphbes(-1,-2113.885106615625 ) ;
  }

  @Test
  public void test16() {
    airy.sphbes(-1,-2297.3686970883828 ) ;
  }

  @Test
  public void test17() {
    airy.sphbes(-1,2.3160072562297955 ) ;
  }

  @Test
  public void test18() {
    airy.sphbes(1,-2316.397630427452 ) ;
  }

  @Test
  public void test19() {
    airy.sphbes(-134,0.0 ) ;
  }

  @Test
  public void test20() {
    airy.sphbes(-14,-5.4E-323 ) ;
  }

  @Test
  public void test21() {
    airy.sphbes(-153,-8.4E-323 ) ;
  }

  @Test
  public void test22() {
    airy.sphbes(15,4.9E-324 ) ;
  }

  @Test
  public void test23() {
    airy.sphbes(174,-1.0E-323 ) ;
  }

  @Test
  public void test24() {
    airy.sphbes(-1,83.76109101315748 ) ;
  }

  @Test
  public void test25() {
    airy.sphbes(-1,-84.33668900889145 ) ;
  }

  @Test
  public void test26() {
    airy.sphbes(192,50.54123401820789 ) ;
  }

  @Test
  public void test27() {
    airy.sphbes(-198,25.81625807873668 ) ;
  }

  @Test
  public void test28() {
    airy.sphbes(-22,99.45179664552671 ) ;
  }

  @Test
  public void test29() {
    airy.sphbes(259,0.0 ) ;
  }

  @Test
  public void test30() {
    airy.sphbes(269,-43.646279147455004 ) ;
  }

  @Test
  public void test31() {
    airy.sphbes(271,55.56606335078018 ) ;
  }

  @Test
  public void test32() {
    airy.sphbes(283,-8.220041430894497 ) ;
  }

  @Test
  public void test33() {
    airy.sphbes(2852,2.000000000000098 ) ;
  }

  @Test
  public void test34() {
    airy.sphbes(-287,2.0000000000000004 ) ;
  }

  @Test
  public void test35() {
    airy.sphbes(317,-2.1175823681357508E-22 ) ;
  }

  @Test
  public void test36() {
    airy.sphbes(-318,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test37() {
    airy.sphbes(32,73.04238896607575 ) ;
  }

  @Test
  public void test38() {
    airy.sphbes(-35,0 ) ;
  }

  @Test
  public void test39() {
    airy.sphbes(351,-37.43866198188495 ) ;
  }

  @Test
  public void test40() {
    airy.sphbes(363,2.0 ) ;
  }

  @Test
  public void test41() {
    airy.sphbes(367,-61.0336750777386 ) ;
  }

  @Test
  public void test42() {
    airy.sphbes(-450,1.9999999999999998 ) ;
  }

  @Test
  public void test43() {
    airy.sphbes(46,0.0 ) ;
  }

  @Test
  public void test44() {
    airy.sphbes(469,-61.229247403119615 ) ;
  }

  @Test
  public void test45() {
    airy.sphbes(485,0.0 ) ;
  }

  @Test
  public void test46() {
    airy.sphbes(486,5.4E-323 ) ;
  }

  @Test
  public void test47() {
    airy.sphbes(488,-1.14E-322 ) ;
  }

  @Test
  public void test48() {
    airy.sphbes(530,2.662276496693636 ) ;
  }

  @Test
  public void test49() {
    airy.sphbes(531,2.0 ) ;
  }

  @Test
  public void test50() {
    airy.sphbes(537,14.122266962432903 ) ;
  }

  @Test
  public void test51() {
    airy.sphbes(564,-4.4E-323 ) ;
  }

  @Test
  public void test52() {
    airy.sphbes(-579,2.0 ) ;
  }

  @Test
  public void test53() {
    airy.sphbes(-584,76.48815577170694 ) ;
  }

  @Test
  public void test54() {
    airy.sphbes(586,-78.20248014219388 ) ;
  }

  @Test
  public void test55() {
    airy.sphbes(598,0.0 ) ;
  }

  @Test
  public void test56() {
    airy.sphbes(-603,-3.320157594904643 ) ;
  }

  @Test
  public void test57() {
    airy.sphbes(62,-29.47862571142079 ) ;
  }

  @Test
  public void test58() {
    airy.sphbes(626,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test59() {
    airy.sphbes(628,25.369500930609988 ) ;
  }

  @Test
  public void test60() {
    airy.sphbes(-630,0.0 ) ;
  }

  @Test
  public void test61() {
    airy.sphbes(-649,-45.23116778372906 ) ;
  }

  @Test
  public void test62() {
    airy.sphbes(-664,50.58587457341548 ) ;
  }

  @Test
  public void test63() {
    airy.sphbes(721,0 ) ;
  }

  @Test
  public void test64() {
    airy.sphbes(736,58.71695017079969 ) ;
  }

  @Test
  public void test65() {
    airy.sphbes(739,-32.69854017901308 ) ;
  }

  @Test
  public void test66() {
    airy.sphbes(746,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test67() {
    airy.sphbes(-756,0.0 ) ;
  }

  @Test
  public void test68() {
    airy.sphbes(769,0.020476048763124144 ) ;
  }

  @Test
  public void test69() {
    airy.sphbes(-784,2.0 ) ;
  }

  @Test
  public void test70() {
    airy.sphbes(818,2.8480945388892178E-306 ) ;
  }

  @Test
  public void test71() {
    airy.sphbes(-846,0.0 ) ;
  }

  @Test
  public void test72() {
    airy.sphbes(-847,-66.56464786666658 ) ;
  }

  @Test
  public void test73() {
    airy.sphbes(-84,-77.72659793302063 ) ;
  }

  @Test
  public void test74() {
    airy.sphbes(885,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test75() {
    airy.sphbes(-895,-58.84086853124955 ) ;
  }

  @Test
  public void test76() {
    airy.sphbes(901,58.076740898773636 ) ;
  }

  @Test
  public void test77() {
    airy.sphbes(91,92.32474185866533 ) ;
  }

  @Test
  public void test78() {
    airy.sphbes(926,12.10145179708455 ) ;
  }

  @Test
  public void test79() {
    airy.sphbes(948,17.474042715389174 ) ;
  }

  @Test
  public void test80() {
    airy.sphbes(996,-81.60964135246003 ) ;
  }
}
