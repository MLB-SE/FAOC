import org.junit.Test;

public class TestAiryTest {

  @Test
  public void test0() {
    airy.main_airy(-10.32666049157855 ) ;
  }

  @Test
  public void test1() {
    airy.main_airy(-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2() {
    airy.main_airy(-12.384107464721765 ) ;
  }

  @Test
  public void test3() {
    airy.main_airy(1.4143349381297696 ) ;
  }

  @Test
  public void test4() {
    airy.main_airy(16.945004850786788 ) ;
  }

  @Test
  public void test5() {
    airy.main_airy(-1.7290327071306454E-223 ) ;
  }

  @Test
  public void test6() {
    airy.main_airy(-1.9078827039819686 ) ;
  }

  @Test
  public void test7() {
    airy.main_airy(-2.0800838230519036 ) ;
  }

  @Test
  public void test8() {
    airy.main_airy(-2.080083823051904 ) ;
  }

  @Test
  public void test9() {
    airy.main_airy(-2.0800838230519045 ) ;
  }

  @Test
  public void test10() {
    airy.main_airy(-2.130625194496118 ) ;
  }

  @Test
  public void test11() {
    airy.main_airy(2.1612908839133068E-224 ) ;
  }

  @Test
  public void test12() {
    airy.main_airy(-2.1788055250797242 ) ;
  }

  @Test
  public void test13() {
    airy.main_airy(21.982886461040493 ) ;
  }

  @Test
  public void test14() {
    airy.main_airy(-2.465190328815662E-32 ) ;
  }

  @Test
  public void test15() {
    airy.main_airy(2635.55460314108 ) ;
  }

  @Test
  public void test16() {
    airy.main_airy(2653.6439192207567 ) ;
  }

  @Test
  public void test17() {
    airy.main_airy(-26.77120847852099 ) ;
  }

  @Test
  public void test18() {
    airy.main_airy(-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test19() {
    airy.main_airy(2.7755575615628914E-17 ) ;
  }

  @Test
  public void test20() {
    airy.main_airy(39.364036754140216 ) ;
  }

  @Test
  public void test21() {
    airy.main_airy(-42.17544483628197 ) ;
  }

  @Test
  public void test22() {
    airy.main_airy(-46.379482937615315 ) ;
  }

  @Test
  public void test23() {
    airy.main_airy(-5.403227209783267E-225 ) ;
  }

  @Test
  public void test24() {
    airy.main_airy(-5.551115123125783E-17 ) ;
  }

  @Test
  public void test25() {
    airy.main_airy(-5.852095443365248E-98 ) ;
  }

  @Test
  public void test26() {
    airy.main_airy(6.3174603311753045E-176 ) ;
  }

  @Test
  public void test27() {
    airy.main_airy(6.549995632268306 ) ;
  }

  @Test
  public void test28() {
    airy.main_airy(-70.07664356205237 ) ;
  }

  @Test
  public void test29() {
    airy.main_airy(-7.01378991682689E-192 ) ;
  }

  @Test
  public void test30() {
    airy.main_airy(7.490682167507517E-96 ) ;
  }

  @Test
  public void test31() {
    airy.main_airy(78.44772218245026 ) ;
  }

  @Test
  public void test32() {
    airy.main_airy(8.597307459135763 ) ;
  }

  @Test
  public void test33() {
    airy.main_airy(8.89103499794031E-162 ) ;
  }

  @Test
  public void test34() {
    airy.main_airy(-90.73620564975302 ) ;
  }

  @Test
  public void test35() {
    airy.main_airy(9.860761315262648E-32 ) ;
  }
}
