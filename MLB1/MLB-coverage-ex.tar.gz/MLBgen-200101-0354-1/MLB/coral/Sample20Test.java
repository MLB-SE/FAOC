import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(35.76735073241758,55.74215281842504 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(-4.42713712986918,54.2296080133612 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(-46.46483176802049,13.145876541272486 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(69.75220421777672,-64.22976496821991 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(82.28984389116209,98.49580550252867 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(-94.700190927088,75.00661741258162 ) ;
  }
}
