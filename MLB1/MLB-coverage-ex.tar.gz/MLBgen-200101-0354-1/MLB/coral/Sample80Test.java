import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(-28.587001243936896,-53.031516435320356 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(-2.9627385228286016,1.5062883506060842 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(55.99108303814748,-70.40989946564846 ) ;
  }
}
