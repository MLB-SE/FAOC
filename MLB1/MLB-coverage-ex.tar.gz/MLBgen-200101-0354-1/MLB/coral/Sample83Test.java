import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(0.9443710155255761,0.8915415416861523 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(1.6130146783308827,2.6045359216294166 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(51.39112586762053,-26.034234878229356 ) ;
  }
}
