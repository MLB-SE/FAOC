import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(11.410735614515374,98.35218321461073 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(-37.64979975728505,24.406925324940374 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(45.70348512635306,-75.33032845158765 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(49.483063136744505,-4.497488003234025 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(57.63873420325669,43.35262738440284 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(57.993123963840134,2.8595661349890094 ) ;
  }
}
