import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(25.958006140581347,29.023631518912282,-72.0299363349142 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(29.963791246474955,-64.0375932899505,54.88426941189201 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(62.46274449244014,34.47117432951869,-90.16683873276521 ) ;
  }
}
