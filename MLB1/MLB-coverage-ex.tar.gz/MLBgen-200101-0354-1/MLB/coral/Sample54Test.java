import org.junit.Test;

public class Sample54Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark54(22.297550772246762,74.45194328529726,-34.39019399781917 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark54(34.49865589108404,53.2225595637922,76.61909381726397 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark54(94.54417625897804,56.96963537969151,-54.56806600586641 ) ;
  }
}
