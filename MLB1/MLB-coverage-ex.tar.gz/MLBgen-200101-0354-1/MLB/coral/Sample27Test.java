import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(-27.14369661546189,-36.16003183865455,76.66394854492063 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(47.18408694715626,3.8966960882870723,93.04611050373691 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(65.89037113093387,21.084669240971138,-12.333585522638844 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(-67.90095219045668,-44.334260324739496,69.64080349543495 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(68.95807704976352,10.285030692911334,21.02464780380319 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(89.60474306034835,-94.88443565469528,-11.186527191529322 ) ;
  }
}
