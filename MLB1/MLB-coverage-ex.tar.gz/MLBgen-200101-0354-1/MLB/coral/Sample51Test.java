import org.junit.Test;

public class Sample51Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark51(1.2220675301845403,18.95490263515779 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark51(1.2368951380822892,45.58934792782367 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark51(17.560681893293122,18.291320143213923 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark51(17.58324623263428,80.54708008706774 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark51(20.030404687423072,29.969595312576928 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark51(20.74089974988695,28.653144812126804 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark51(39.61734085759454,83.40047136295485 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark51(5.264565909948726E-14,5.402926563914121E-8 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark51(5.512972907159579,41.099047769802496 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark51(-70.36012014512721,57.20374790454318 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark51(7.791591402876307,92.18560943175132 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark51(8.346025422310107E-11,9.13573718449064E-6 ) ;
  }
}
