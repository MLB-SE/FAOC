import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(11.948138749011576,-16.28034618733649,37.18077520894519 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(88.08641329851719,48.41508474921906,-56.48551404637288 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(9.759412642338276,-58.386535945335694,13.713515636432334 ) ;
  }
}
