import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(-29.47631067348007,-57.97831293508293,-87.454623608563 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(-83.41850719391451,92.16228507854544,-46.95045700041902 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(-99.71422331329904,-24.514766920631658,-25.986191123259175 ) ;
  }
}
