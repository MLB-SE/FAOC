import org.junit.Test;

public class Sample04Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark04(14.092788329844623 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark04(-45.92607477184887 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark04(-663.2535587097062 ) ;
  }
}
