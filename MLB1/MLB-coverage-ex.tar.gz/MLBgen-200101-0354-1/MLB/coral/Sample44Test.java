import org.junit.Test;

public class Sample44Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark44(12.070742302058363,12.070742302058363 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark44(20.187148465523364,56.42944052614146 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark44(34.53149038272038,1.1219619327929113 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark44(4.362670707982403,1.2412700253555897 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark44(63.597497818037056,77.91877799896804 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark44(66.59705806169117,30.394190168475546 ) ;
  }
}
