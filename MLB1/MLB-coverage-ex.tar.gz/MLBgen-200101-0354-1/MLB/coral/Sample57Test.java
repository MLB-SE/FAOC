import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0,19.295908604276036,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(0,2.990676272845789,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(16.918217309964703,-8.658592480111224,96.89878822885927,65.80245226871637,-38.77868856329976 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(26.82194454788977,87.46839630089943,-51.873102048476994,9.880939563946598,74.8535347304283 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(35.34685311601602,52.65543308840957,73.37248679885428,83.50738252175674,-27.265447743899813 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(54.12612536931795,40.37870586826341,-31.59397414725555,23.126146863884586,45.45488615335432 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(59.12213619396752,52.217401338333644,-58.47364070773211,59.597336309508705,-94.39483101153347 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(98.45903147658032,-1.5737362386159646,-94.2046779652059,-90.76479350872759,-50.12973010983948 ) ;
  }
}
