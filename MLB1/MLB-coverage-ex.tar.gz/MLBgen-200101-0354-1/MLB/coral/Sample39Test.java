import org.junit.Test;

public class Sample39Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark39(1.5178638901221575,2.1697589233203512E-16 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark39(40.856221929401784,-27.619211215545818 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark39(63.67671843794119,34.62070517214565 ) ;
  }
}
