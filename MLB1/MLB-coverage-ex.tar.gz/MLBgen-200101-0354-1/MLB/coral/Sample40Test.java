import org.junit.Test;

public class Sample40Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark40(1.8097208173732815,1.4653686194609366 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark40(-35.70309718605036,42.87137060108904 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark40(6.052663214808348,60.561736579779705 ) ;
  }
}
