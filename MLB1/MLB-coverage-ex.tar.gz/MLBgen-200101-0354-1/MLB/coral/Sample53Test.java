import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark53(14.209012665199964,-2.2765106159355213,97.64808861313824 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(18.539702119690627,-48.42589164464446,28.471163933559875 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(25.848174583717665,49.52222418322188,39.806706904964386 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark53(30.460809693802588,2.7613218346805004,46.63988205812923 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark53(6.005650485803017,-8.791585891244068,29.103905660609627 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark53(61.429837774885215,-38.22528321306602,56.73571353637519 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark53(61.679253290795,96.89794479014898,90.74318262242988 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark53(66.61146934023799,72.6960826815162,90.44910330594732 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark53(89.19825004417531,-66.01859696258096,90.1972769471269 ) ;
  }
}
