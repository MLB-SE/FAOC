import org.junit.Test;

public class Sample35Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark35(12.566690337351718,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark35(-136.65928042561015,-25.90370383667036 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark35(7.853981641348244,-78.67644479281351 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark35(-85.2490539016091,-40.26652935597976 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark35(8.538608036732143,0 ) ;
  }
}
