import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(-0.08288969307145633 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(3.1201206037059848 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(35.005556809725135 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark31(-35.30970686657844 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark31(4.049369642614437 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark31(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark31(4.778773919121491 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark31(-66.39108171426764 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark31(87.42534084591313 ) ;
  }
}
