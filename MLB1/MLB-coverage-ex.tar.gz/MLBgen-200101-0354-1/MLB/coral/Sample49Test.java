import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(0.016107078851926585,0.055108861182058974 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(0.6193264359989924,36.04691681118289 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(0.7580658868205781,17.143940437855843 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(-12.448898320223293,67.6058945752377 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(1.589172755556961,48.41082724444304 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(19.790482209007394,93.11986528272246 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(32.56827498272011,37.340165414241284 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(5.303645977255966E-15,7.282578608972928E-8 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(86.95006763032154,99.08043189362652 ) ;
  }
}
