import org.junit.Test;

public class Sample43Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark43(0.06115553453895473,0.061155534538954726 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark43(12.825846402358508,0.43732881578748106 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark43(19.82994930911542,36.24956788011394 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark43(34.56603149041902,54.45494735384682 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark43(5.354091097109844,28.666291476150896 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark43(55.793052390868326,99.06648879688706 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark43(68.84343104688278,64.17336207184871 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark43(9.42682052202954,9.42682052202954 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark43(9.524712739899883,91.93632266604848 ) ;
  }
}
