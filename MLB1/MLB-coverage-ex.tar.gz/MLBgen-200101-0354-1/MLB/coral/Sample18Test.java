import org.junit.Test;

public class Sample18Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark18(0.5718311563501146 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark18(0.9778108202134099 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark18(0.9916773388131637 ) ;
  }
}
