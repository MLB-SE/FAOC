import org.junit.Test;

public class Sample82Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark82(-0.4681335675404483,-2.1361424801343617E-4 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark82(-1.9209890331784503E-5,-5.205651790449889 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark82(-26.51787074598204,-3.771041836575506E-6 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark82(-5.074242358142172,90.61103240056966 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark82(72.73673799420575,30.385640443868567 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark82(9.909584724669E-6,10.091240226349669 ) ;
  }
}
