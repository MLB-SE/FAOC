import org.junit.Test;

public class Sample01Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark01(0.5891081927620831,-49.73501233062838 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark01(39.95707064414251,-42.640446565678495 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark01(-77.50909100199554,-21.91826301596238 ) ;
  }
}
