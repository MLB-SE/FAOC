import org.junit.Test;

public class Sample17Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark17(0.07316855098700614 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark17(-0.2815110920591337 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark17(0.7091520165996087 ) ;
  }
}
