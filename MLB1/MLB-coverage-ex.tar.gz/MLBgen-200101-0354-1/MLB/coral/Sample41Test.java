import org.junit.Test;

public class Sample41Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,1.9999999999999998 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0000000000000004 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark41(1.777824832673923,1.3828363029981392 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark41(-2.762081653886252,10.391176716621265 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark41(-4.504639723185306,24.7964187588843 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark41(5.238208266030829,22.200617572282873 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark41(-7.254165879106884,130.68916495693435 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark41(8.151472722445675,58.29503482233022 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark41(-88.66236230145562,-96.08741358198141 ) ;
  }
}
