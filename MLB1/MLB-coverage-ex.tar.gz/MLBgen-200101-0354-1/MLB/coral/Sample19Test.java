import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(0.5588729373611159,47.73583905771803,0.9825038221859188 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(0.70949556242536,79.89240649747472,0.9326296942480781 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(-0.9000839638471518,-14.21452080949119,-0.09780549597944344 ) ;
  }
}
