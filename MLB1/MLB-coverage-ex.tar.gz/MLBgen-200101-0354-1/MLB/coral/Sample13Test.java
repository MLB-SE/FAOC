import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(-0.8251559656569327,38.64093678352086,11.369656129119335,73.84332529808466 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(-0.93708323415968,51.182871234899174,94.62705332408188,23.78275062208826 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(-0.9616866174261247,-24.941666610214796,78.72406891604766,-69.4368681484614 ) ;
  }
}
