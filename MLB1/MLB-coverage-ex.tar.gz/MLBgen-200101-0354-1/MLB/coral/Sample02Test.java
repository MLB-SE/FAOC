import org.junit.Test;

public class Sample02Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark02(-31.564040852272964,45.70120779352814 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark02(87.73557245107969,49.4455515342579 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark02(88.6546572483214,49.20219305687323 ) ;
  }
}
