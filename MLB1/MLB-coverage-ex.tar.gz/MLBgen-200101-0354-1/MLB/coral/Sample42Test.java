import org.junit.Test;

public class Sample42Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark42(0.37535548472990854,0.37535548472990854 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark42(0.9566827888415668,0.8683981920571417 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark42(1.0,-82.87628343330391 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark42(32.75511005825172,33.89816473197436 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark42(32.96254801678617,51.905667507138844 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark42(46.12638838462411,88.98799402782197 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark42(48.34203905823264,9.340374014625581 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark42(49.073921696515136,0.6637621982290653 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark42(5.001804841954353,10.0 ) ;
  }
}
