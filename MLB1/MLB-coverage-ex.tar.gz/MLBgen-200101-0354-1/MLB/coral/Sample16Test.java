import org.junit.Test;

public class Sample16Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,33.967003648154844 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,-5.893288818267408 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark16(-2.00700813812929,14.180091182074037,-40.98776290142951,-21.447180757727708,93.39162320225222 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark16(-41.97971688942166,14.932164112063944,71.29299068366183,-56.441992347417205,-41.95396524418686 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark16(-90.35654830442172,14.601393154655455,71.73202136651531,39.40701253069284,-76.88263446128276 ) ;
  }
}
