import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(100.0,39.98165442304848,0,-47.47976292567064 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(-26.67717590958773,-86.90601053406569,-19.899524226656013,11.466241357531644 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(30.10933969639231,-85.9984720807863,0,-70.84849842310553 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(-34.030007590512696,-78.80357214390203,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(38.55500593216635,14.3426538928842,-46.48765023715728,-33.333231857049455 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(56.59077603652375,14.334066729944666,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(96.40743433781677,-3.8843038233738127,-4.887709091578785,84.10162935235394 ) ;
  }
}
