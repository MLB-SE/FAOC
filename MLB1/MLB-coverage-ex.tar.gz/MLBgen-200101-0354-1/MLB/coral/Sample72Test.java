import org.junit.Test;

public class Sample72Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark72(-100.0,-21.32510502469205,-14.691080598727197,5.120996757746423,-64.8049462109376,80.01084096951561,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark72(100.0,99.76159595741063,-52.48267270734232,4.065995057273962,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark72(1.0877784058396713,-11.044053113675204,0,0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark72(32.644367074607004,-86.04220007333656,-100.0,55.82757082454637,-57.96483771074543,25.95927764524187,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark72(-41.992798921614536,-9.332090556469687,100.0,49.23859114299992,29.345578935108904,29.489176897405343,54.689985097093796 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark72(-44.34743763277822,78.91217183441054,-91.40998831092423,0,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark72(52.32623537882066,-73.33747076477107,0,0,0,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark72(-56.23718874694987,-57.59748641750542,41.88952314955645,0,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark72(57.435222374166244,-41.566922323327624,43.6517049740564,-38.203255196522726,-44.68862590130438,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark72(-68.21187165206737,15.036148818986646,69.74422830679453,-59.402865510778454,100.0,100.0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark72(-69.14597163019019,22.378938101380257,-26.48902429585914,88.85008996050252,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark72(69.73468137947823,62.799047543178425,-40.376345357956154,-64.70725520793884,-14.441772750502151,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark72(-74.37110784954373,63.479113283779924,2.5071563147050853,60.045140798437444,0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark72(77.59735334168634,13.439855326401668,77.71258265723101,-47.950959894510696,-99.97156073529794,86.1742360611693,-39.489470082422436 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark72(-92.75456167942534,87.59641340383507,-38.391424997334546,16.903473238812467,16.65274488398407,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark72(-92.89371737462342,46.423276653598094,6.733786381987358,0,0,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark72(-93.26253037936407,-73.1024748136222,-100.0,198.17899343539426,66.41118878450618,-90.64082686649641,-36.3787622497008 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark72(-98.82715056511859,37.552387322343606,0,0,0,0,0 ) ;
  }
}
