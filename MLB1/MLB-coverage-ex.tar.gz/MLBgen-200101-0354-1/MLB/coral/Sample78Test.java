import org.junit.Test;

public class Sample78Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,0.0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0.0,-100.0,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-18.33662459647205,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-4.797080356308086,0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-90.0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-38.18251620275102,90.0,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,38.5333158268177,-2.54672E-318,0,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-48.10151942925267,-47.313742367264396,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,66.51631656223023,-13.954740031040444,0,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-88.35570988744345,-0.1439754938411113,0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark78(-100.0,-100.0,-100.0,-100.0,100.0,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark78(11.819126176255622,0,0,-72.5156129425338,-6.3334825786349285,0,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark78(-29.06797488150268,64.22481638171323,30.131822809366838,-36.6507689779503,75.0119412863472,0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark78(31.34437979782181,0,0,12.043475184322673,-90.0,0,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark78(-32.31302178960382,0,0,-63.63264736417904,77.07611723143094,0,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark78(-38.52953167861248,0,0,-6.373845913369119,-90.0,0,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark78(44.431681950122055,0,0,-37.13241894232762,67.78842986042292,0,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark78(-55.52773247286562,0,0,4.7272850523062967E-125,90.308768346107,0,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark78(6.15174847438443E-25,0,0,-52.09795639409994,90.0,0,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark78(69.93406290126256,0,0,-12.47205402548066,45.89138617461481,0,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark78(73.22165783391401,0,0,28.249178493551938,18.190329246525465,0,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark78(-77.98364386782141,0,0,-73.80934040128238,84.34470659669014,0,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark78(8.143732062222443E-28,0,0,97.72455822281066,-90.0,0,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark78(-86.91963433704309,-100.0,-100.0,-86.91963433704379,89.99999649603126,0,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark78(92.67405277011756,0,0,-16.9091782680096,-6.20260064581006E-266,0,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark78(-93.11649744921557,0,0,-92.7958083813466,11.144495396375248,0,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark78(99.99999999999882,0,0,99.96689935207804,1.5290591125556738E-297,0,0,0 ) ;
  }
}
