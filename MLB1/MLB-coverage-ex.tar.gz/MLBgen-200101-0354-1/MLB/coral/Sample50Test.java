import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(11.502317800501679,24.50231780050168 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(14.288133966770033,26.554341017193764 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(21.518995118523648,41.078985227012595 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(24.67532046272993,25.32467953727007 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(27.119131963258695,83.01514279288477 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(3.2292990786980056,6.573477754358876 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(5.093574216921692E-13,7.134986271874649E-7 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(5.281464041749937E-10,9.692348953244691E-11 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(53.35630303012155,26.717172003121277 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(5.370071460625354,6.830075065641847 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(6.4252301934487335,33.42831418615628 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(77.05341103376423,96.97380121372615 ) ;
  }
}
