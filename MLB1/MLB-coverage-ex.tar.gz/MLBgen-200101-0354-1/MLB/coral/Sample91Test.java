import org.junit.Test;

public class Sample91Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark91(2.73482565812175,-74.95662448155036 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark91(62.4247179206358,72.76543523784724 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark91(-92.99580251745589,-96.13739517104568 ) ;
  }
}
