import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(-0.44111990201061246,-84.79695396868667,-82.39152698368935,87.10442328865241 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(-0.8676044851308973,-7.258194627106349,9.41828910176395,141.93486789032283 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(0.9540209480075106,-80.53666422187536,-97.88702641273616,92.42202551575375 ) ;
  }
}
