import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(-38.87630328262828,93.49294684290342,68.15934186339928 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(55.214423297600604,57.81511773814535,-28.78711068780995 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(-72.48610379834872,-44.14303733687503,-45.48631727875434 ) ;
  }
}
