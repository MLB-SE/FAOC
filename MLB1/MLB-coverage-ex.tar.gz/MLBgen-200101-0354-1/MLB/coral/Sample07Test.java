import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark07(0,1.391220151299347,0,-6.193397223737871 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(0,38.540092022111224,0,-1.9997498273242655 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(0,51.31268000527468,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(0,-52.66784347107845,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(-44.1271741827685,21.704327122101418,34.66612105430866,-7.260926818195458 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(-84.50390085384278,-22.155495119541897,-34.44847244502634,-26.481001220555882 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(-88.28230454803307,17.300840989717713,-49.18363795621008,89.11244657442523 ) ;
  }
}
