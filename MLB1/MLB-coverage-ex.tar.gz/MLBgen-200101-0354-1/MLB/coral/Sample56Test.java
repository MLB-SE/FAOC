import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,1.2649929206759936,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0.8178733079353904,80.74643439513953,67.82585152234162,3.453830094288925,49.65725082398484 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.61521995083238,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(-50.335087079578344,-36.9749459923389,42.75950093993961,1.9405579055458588,41.566825762011916 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(-55.99179708291848,77.80628061107626,76.24730948906807,48.0910654216803,-25.18158906905181 ) ;
  }
}
