import org.junit.Test;

public class Sample45Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark45(0.0,-19.062041212821754,41.55091603615858 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark45(-0.1774916410562497,-2.372081052069703,26.831734964281907 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark45(1.3877787807814457E-17,1.0000000000000002,1.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark45(-187.2119613844823,-455.62839005105207,61.539537328352225 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark45(22.046187123147895,24.046187123147895,61.45230580953105 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark45(31.999918892803237,99.98730025642533,85.48912237141528 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark45(32.28480577608127,-22.555657752051417,51.52762827895364 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark45(32.58815843481892,45.545313460647776,19.384623328952856 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark45(41.269970331257326,9.546546118727576,88.9353043019035 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark45(50.07733786342382,96.79247502355776,57.726482795328735 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark45(5.551115123125783E-17,1.0000000000010583,0.9997935871922867 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark45(59.500796797008405,1.0,41.360196998772636 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark45(65.10071237042169,92.09176988437906,45.909533848786026 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark45(-7.372729821821778,42.813439331555685,35.49288358842574 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark45(75.88277265475017,8.412016856114306,95.87106392002283 ) ;
  }
}
