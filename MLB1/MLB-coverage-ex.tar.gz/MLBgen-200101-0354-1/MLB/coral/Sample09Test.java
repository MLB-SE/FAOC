import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(-48.89367315640643,40.236897797114786 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(50.079196222692275,-29.305377355054432 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(94.75565663416506,-16.43740630318355 ) ;
  }
}
