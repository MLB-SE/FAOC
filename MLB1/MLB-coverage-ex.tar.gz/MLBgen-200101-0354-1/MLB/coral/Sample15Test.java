import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(0.7032678082414776,-1.8130840128824985,-53.409882542410855,73.76180586498583 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(0.9619392356095631,-35.05761060975325,49.27158393254223,-17.584316666318063 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(0.9998462505071046,35.13863000564231,-92.02971197328186,75.23682188044523 ) ;
  }
}
