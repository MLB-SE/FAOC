import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark05(10.804488477297824,-81.46389289693894,-0.2632434636996095 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(2.480189944203957,63.47911324966887,-11.686055569453856 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(-51.86382945488531,78.06241704798022,34.08751134094663 ) ;
  }
}
