import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(0.6901174142103437,82.40158698710005,40.695536683139984,-15.277330130734839 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(-0.9112265400314641,-64.00189417799018,78.98260315292413,0.8343871048954128 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(-0.925383875714175,-86.8870493973744,-47.457199294004894,60.853007403490324 ) ;
  }
}
