import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(13.539643882747953,-12.918957227374662,82.10751362610407 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(22.11703721153332,-61.938822110972225,46.83021550021237 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(22.663020572750497,70.51843780878946,92.01323114571372 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark55(26.54988671387757,-34.05649012830753,33.40107430448748 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark55(27.635344441859715,-37.15101409247884,35.03512390478119 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark55(30.474219380894993,-100.0,29.035928477540445 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark55(35.510884219619555,-94.91900591351465,54.52411645126091 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark55(3.6121419667121666,2.4895614838483815,4.5636071146513935 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark55(44.44120767547651,36.818768383766994,66.1168804842218 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark55(50.47045984936068,-56.8360345298623,22.30912662149632 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark55(60.75673312409299,-38.45877352223135,65.01404865359072 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark55(63.97623328461068,-12.553928674339971,63.665962697562406 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark55(73.87719544607648,18.219595298330738,74.38731210086605 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark55(81.78537156697959,-21.32688746791682,91.82337598899872 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark55(89.54258986798192,83.58486510060493,43.63943054955729 ) ;
  }
}
