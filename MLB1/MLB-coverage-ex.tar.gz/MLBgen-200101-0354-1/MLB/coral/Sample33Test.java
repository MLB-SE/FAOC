import org.junit.Test;

public class Sample33Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark33(-18.43866613161218 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark33(88.74999246391165 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark33(-92.78917605803454 ) ;
  }
}
