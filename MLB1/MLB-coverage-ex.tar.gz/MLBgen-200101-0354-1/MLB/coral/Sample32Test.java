import org.junit.Test;

public class Sample32Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark32(10.853624990030951 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark32(25.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark32(93.65492134058962 ) ;
  }
}
