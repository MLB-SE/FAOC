import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(-387.3869590347433,-214.52001547798426,-566.4459808811108 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(-70.24243584045374,-91.03374700097196,77.47873868335427 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(88.35952385263332,34.36658140970704,91.65287321275693 ) ;
  }
}
