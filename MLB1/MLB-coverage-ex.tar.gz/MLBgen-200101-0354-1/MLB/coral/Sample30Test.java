import org.junit.Test;

public class Sample30Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark30(100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark30(167.11087859066947 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark30(33.82635041381096 ) ;
  }
}
