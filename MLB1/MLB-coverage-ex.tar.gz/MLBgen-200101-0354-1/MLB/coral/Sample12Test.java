import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(0.33913654026758877,0.30069692770366885,-99.63115374575848,-14.817336976607649 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(-0.4253313853482439,0.9203731593744493,38.43944527626746,-17.46240934844994 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(0.8876350020138091,0.21872432751055726,-37.06930220719404,13.98435931172611 ) ;
  }
}
