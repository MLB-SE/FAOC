import org.junit.Test;

public class Sample26Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark26(-100.0,-100.0,-80.8797967874828,63.6028562061982,-12.537580374233942 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark26(-100.0,-44.97862005338537,-100.0,0,36.550164974921394 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark26(12.514783353574984,-36.761039762909945,86.72507410853765,0,56.46027428866742 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark26(13.416416504242505,82.9250770656989,-13.02760297984571,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark26(25.33466054936011,1.0711919535163474,86.52307225796156,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark26(43.67382886801923,77.93028804975668,-39.701632536222455,50.78206203917702,14.795706038102722 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark26(53.771093256447415,-92.0453069621288,-21.26951352614219,23.297555610589995,44.71413553938717 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark26(71.12040811129194,-44.198224284924905,13.09046298268403,-81.15115234797537,99.41151243614826 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark26(-91.20492431868993,48.22939871553563,-46.88884428149491,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark26(99.99999999999932,99.9999999999999,99.99999999999987,-41.10040177061409,100.0 ) ;
  }
}
