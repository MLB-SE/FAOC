import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,2.611323064650307 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-73.91253771394605 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(0.2949024176446642,76.60581914310252,41.60072767417239,40.037719371973935 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(0.7333547005086386,-12.053078956918487,-10.321790536056957,3.5657107487476093E-4 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(100.0,-3.138287717089222,48.15998731512985,53.005634078672074 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(1.1992144831942544,13.266202343141178,14.527450777072477,-0.0551328609113876 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(12.00508321103564,-15.74302374944141,-89.52595473296516,23.950609650721717 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(17.96009035498858,77.58109416953249,-64.62619758834644,14.748196515078817 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(35.848048142896175,92.52284199516416,92.04142686189033,-29.210199581982877 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(36.67438956057359,2.5823299503797728,-95.28123666353669,100.0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(-41.35326238680268,3.105421176553264,-79.48966196498822,-60.49823809432273 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(46.253972569356364,-7.628982216261491,81.79290005127763,46.088747282142265 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(48.135234987742415,9.081815706328948,52.81353598576163,5.300177469379594 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(51.58723800524788,-56.87095623323331,46.26827855842677,-8.598694600781386 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(53.60524975245701,-34.59840844753808,-4.1595859419386585,34.43171619761213 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(57.42489761022125,-42.035061281245945,52.86873917705191,-35.09333757773136 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(6.328343568379211,13.896676040391881,38.03556061864106,-86.43800741500804 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(63.4429927949698,-28.219427879506583,53.538644636344685,89.39011816976895 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(69.62040277383329,38.27238503909672,27.446810121894714,-53.60328432788253 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(7.9652240632750875,43.05019874490546,26.317234984300214,24.698187823880332 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(8.301738670302285,-2.3906711923079174,89.45879944728387,-17.24859926459773 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(83.45916157870056,-18.57551153506141,58.50122640702605,17.637588527785113 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(89.70216166774227,0.0,47.87921963611586,-82.44865267326202 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(92.49258228161997,61.9972666108992,34.180319006766126,-27.58056627399941 ) ;
  }
}
