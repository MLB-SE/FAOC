import org.junit.Test;

public class Sample36Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark36(14.492126384578725,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark36(-41.73326578962284,-54.05270091430767,7.628325341615138 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark36(-55.32378502144957,-40.005610809514344,5.760322088991089 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark36(72.25660781217033,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark36(-93.66062861690693,-71.63316188646003,28.548993878264127 ) ;
  }
}
