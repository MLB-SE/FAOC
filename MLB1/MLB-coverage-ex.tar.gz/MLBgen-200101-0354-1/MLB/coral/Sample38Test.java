import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(34.20574375360016,-31.217106397675522 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(91.08351034494302,58.48404942586613 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(-95.05388351000876,79.2260728780532 ) ;
  }
}
