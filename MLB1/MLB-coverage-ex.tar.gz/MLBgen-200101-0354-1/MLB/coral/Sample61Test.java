import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,0.0031629902513401476 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,61.07899139807273 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(12.91866547537579,51.79649371258472,56.6527468391493,40.068603157352385 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(13.249538501841988,-32.937090009758506,40.72204233237691,-0.4022680357589712 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(-15.236019334091353,14.369340266644429,-61.868811366584794,3.5770046843754955 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(17.408557405723116,49.470046278518964,18.87417489150414,-71.76291472819295 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(19.235855017303102,0.0,100.0,-100.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(19.31657581174464,-14.457357662454811,-63.54099286797103,45.58836278925389 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(1.9378973904440926,38.81594918038664,45.17916655155577,-4.425319980725035 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(22.259695674581636,-6.3547761917030385,94.62877017094266,-9.813946122643372 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(24.979710602030323,-1.691430787546011,16.451162558041375,-61.44787190269574 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(25.826328410971588,2.5167979158529366,11.931197341557782,16.501094308038518 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(35.342581523253756,0.8262135518074971,-60.07718913318192,42.38492668178381 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(-3.7647045521388804,-61.87071630104444,-78.25159431833393,37.76043317374294 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(39.069617172270014,-37.837943239830985,-68.83411607032724,-55.886638709660815 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(54.50549064079729,10.413847334332175,32.769730770272304,60.55932661150456 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(61.386319441075244,57.49461260979783,6.420225015055323,95.8936225397359 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(67.74157015550912,95.09284036606522,93.2396832926064,85.63423083243947 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(68.76479639740677,22.489282271320207,85.47692415295211,-82.28487822653855 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(76.32520660453528,-39.53376320657842,102.67825240744008,-62.64833299235295 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(99.32855016703525,3.3027873738711975,79.43556109477285,82.87268809366114 ) ;
  }
}
