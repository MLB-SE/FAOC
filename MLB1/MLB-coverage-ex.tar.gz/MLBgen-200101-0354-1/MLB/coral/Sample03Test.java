import org.junit.Test;

public class Sample03Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark03(38.88955038750527,65.31343835512445 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark03(52.60214365043594,36.933246976873164 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark03(-95.75107311864825,-92.58466444060211 ) ;
  }
}
