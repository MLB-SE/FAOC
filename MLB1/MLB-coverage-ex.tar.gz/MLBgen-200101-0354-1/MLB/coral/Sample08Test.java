import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(10.725806851483616,48.80411901233839,-17.871177648788233 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(-19.03907625066377,21.901429432059814,92.57323374072305 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(-47.07966561130574,89.04616931936118,98.45617897263463 ) ;
  }
}
