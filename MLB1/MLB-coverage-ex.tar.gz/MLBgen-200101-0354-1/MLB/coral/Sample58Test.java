import org.junit.Test;

public class Sample58Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark58(0,4.15185892428957,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark58(0,54.308377264567355,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark58(100.0,5.951303388674535,2.386143568821369,94.55199523590005,-40.428069538387376 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark58(-14.42806444391347,-11.081117174061816,-55.18305372298293,52.11543717570993,93.38339270832859 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark58(15.228852576326881,67.37708989544473,-82.82376231828556,9.86180456463208,77.66236616592643 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark58(1.5347755105892986,12.213626027102592,0.4165466986700608,39.17875673466034,52.551780554108376 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark58(-1.8489203160496777,-7.829005963117992,13.481516363181115,-89.37955970214975,-88.7461253399156 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark58(25.09882251944417,39.3276803173342,4.438015142609615,81.24211511346815,77.11146946906695 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark58(4.260001197357639,4.533777796914478,-8.828761762559248,18.34228963895272,-5.196313556811488 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark58(54.02663532155339,17.682843300790665,-72.62533627664949,72.24171491656858,57.50235042939402 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark58(-56.644601951397135,3.666516475334646,44.03094573000487,-84.12833874684786,12.23052743899106 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark58(6.813003874879399,81.94223323910529,-88.70093163382711,90.02023621130817,18.24237636959056 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark58(87.45498741632942,0.6345166017707129,-87.97188312698502,70.0982935033525,52.8798361138677 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark58(9.473468753238464,6.263402620710039,-15.329921429901844,-43.05196714511945,68.58851072470486 ) ;
  }
}
