import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(16.889921419716103,98.368188606128,-67.00005775560922,43.38275751628075,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(5.8117875438187956E-9,-100.0,-100.0,100.0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(9.019139332643514E-9,-100.0,-100.0,100.0,0 ) ;
  }
}
