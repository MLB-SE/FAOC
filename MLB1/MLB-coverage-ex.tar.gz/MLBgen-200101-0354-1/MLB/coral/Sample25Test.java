import org.junit.Test;

public class Sample25Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark25(-0.2385551195373239,7.734787458183945,1.1487903402881017,0,5.388478748668916 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark25(100.0,-100.0,-99.98032701124792,-66.07640348458042,-35.92240048724781 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark25(-100.0,61.676303121069644,-54.00861335658561,0,-44.81278989904155 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark25(-11.667220830795273,16.979719193515038,82.14761657622077,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark25(-31.69347895678753,-71.59896174965925,98.50443286540667,-15.036951926126662,5.106935354061065 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark25(-40.52986875531186,39.237454273234334,-79.55015727674785,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark25(48.76075492072873,44.412378929629035,22.653377257898597,2.7024243407050648,-38.255979249087346 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark25(59.63375926882159,49.17407773659207,-2.212692631269846,18.01585520984989,-28.187316961070536 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark25(-6.1959833146493395,72.8832913512885,21.963257659216367,24.994260733665612,-46.608355681165236 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark25(-91.41291017250033,-59.116098888339785,-38.31132376198264,0,0 ) ;
  }
}
