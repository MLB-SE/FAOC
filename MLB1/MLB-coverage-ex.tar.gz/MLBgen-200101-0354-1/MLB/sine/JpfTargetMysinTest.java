import org.junit.Test;

public class JpfTargetMysinTest {

  @Test
  public void test0() {
    JpfTargetMysin.static_mysin(0.4818119798918056 ) ;
  }

  @Test
  public void test1() {
    JpfTargetMysin.static_mysin(-0.7699266145048371 ) ;
  }

  @Test
  public void test2() {
    JpfTargetMysin.static_mysin(-0.867990925176704 ) ;
  }

  @Test
  public void test3() {
    JpfTargetMysin.static_mysin(10.522524712895674 ) ;
  }

  @Test
  public void test4() {
    JpfTargetMysin.static_mysin(-13.35176877775662 ) ;
  }

  @Test
  public void test5() {
    JpfTargetMysin.static_mysin(-2.033141171932979E-38 ) ;
  }

  @Test
  public void test6() {
    JpfTargetMysin.static_mysin(-2.4414063886926533E-4 ) ;
  }

  @Test
  public void test7() {
    JpfTargetMysin.static_mysin(2.4462365181215516E-4 ) ;
  }

  @Test
  public void test8() {
    JpfTargetMysin.static_mysin(2.611006682723426E-4 ) ;
  }

  @Test
  public void test9() {
    JpfTargetMysin.static_mysin(-268.4366700724253 ) ;
  }

  @Test
  public void test10() {
    JpfTargetMysin.static_mysin(-2.699859428011893E-4 ) ;
  }

  @Test
  public void test11() {
    JpfTargetMysin.static_mysin(271.56739491636927 ) ;
  }

  @Test
  public void test12() {
    JpfTargetMysin.static_mysin(-271.82343334781945 ) ;
  }

  @Test
  public void test13() {
    JpfTargetMysin.static_mysin(3.5189745495323166E-4 ) ;
  }

  @Test
  public void test14() {
    JpfTargetMysin.static_mysin(3.6248849879447533 ) ;
  }

  @Test
  public void test15() {
    JpfTargetMysin.static_mysin(-37.74806496720875 ) ;
  }

  @Test
  public void test16() {
    JpfTargetMysin.static_mysin(46.76133794012523 ) ;
  }

  @Test
  public void test17() {
    JpfTargetMysin.static_mysin(56.93478975897597 ) ;
  }

  @Test
  public void test18() {
    JpfTargetMysin.static_mysin(57.08091464174208 ) ;
  }

  @Test
  public void test19() {
    JpfTargetMysin.static_mysin(-58.90486225480862 ) ;
  }

  @Test
  public void test20() {
    JpfTargetMysin.static_mysin(6.381742783643715E-5 ) ;
  }

  @Test
  public void test21() {
    JpfTargetMysin.static_mysin(65.18804756198821 ) ;
  }

  @Test
  public void test22() {
    JpfTargetMysin.static_mysin(66.43533830263257 ) ;
  }

  @Test
  public void test23() {
    JpfTargetMysin.static_mysin(68.329640215578 ) ;
  }

  @Test
  public void test24() {
    JpfTargetMysin.static_mysin(-7.293407295096993E-17 ) ;
  }

  @Test
  public void test25() {
    JpfTargetMysin.static_mysin(76.35927430392448 ) ;
  }

  @Test
  public void test26() {
    JpfTargetMysin.static_mysin(-78.53167014291502 ) ;
  }

  @Test
  public void test27() {
    JpfTargetMysin.static_mysin(-78.67554652576504 ) ;
  }

  @Test
  public void test28() {
    JpfTargetMysin.static_mysin(-89.97257703113517 ) ;
  }

  @Test
  public void test29() {
    JpfTargetMysin.static_mysin(-94.94124567711451 ) ;
  }
}
