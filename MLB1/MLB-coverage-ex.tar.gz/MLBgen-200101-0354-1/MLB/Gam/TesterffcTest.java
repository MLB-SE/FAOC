import org.junit.Test;

public class TesterffcTest {

  @Test
  public void test0() {
    gam.erffc(0.028768037505997768 ) ;
  }

  @Test
  public void test1() {
    gam.erffc(-0.30021005765940334 ) ;
  }

  @Test
  public void test2() {
    gam.erffc(0.5629795851092023 ) ;
  }

  @Test
  public void test3() {
    gam.erffc(0.9196300367313646 ) ;
  }

  @Test
  public void test4() {
    gam.erffc(1.0190827496356687 ) ;
  }

  @Test
  public void test5() {
    gam.erffc(-1.04725565739436 ) ;
  }

  @Test
  public void test6() {
    gam.erffc(-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test7() {
    gam.erffc(1.0842021724855044E-19 ) ;
  }

  @Test
  public void test8() {
    gam.erffc(-1.1214028995285918 ) ;
  }

  @Test
  public void test9() {
    gam.erffc(-1.224744871391589 ) ;
  }

  @Test
  public void test10() {
    gam.erffc(1.224744871391589 ) ;
  }

  @Test
  public void test11() {
    gam.erffc(-1.2247448713915892 ) ;
  }

  @Test
  public void test12() {
    gam.erffc(1.2247448713915892 ) ;
  }

  @Test
  public void test13() {
    gam.erffc(-1.224744871391595E-7 ) ;
  }

  @Test
  public void test14() {
    gam.erffc(1.224744871391595E-7 ) ;
  }

  @Test
  public void test15() {
    gam.erffc(-1.232595164407831E-32 ) ;
  }

  @Test
  public void test16() {
    gam.erffc(1.232595164407831E-32 ) ;
  }

  @Test
  public void test17() {
    gam.erffc(-12.627714603983904 ) ;
  }

  @Test
  public void test18() {
    gam.erffc(1.3877787807814457E-17 ) ;
  }

  @Test
  public void test19() {
    gam.erffc(1.7763568394002505E-15 ) ;
  }

  @Test
  public void test20() {
    gam.erffc(-18.464444106708726 ) ;
  }

  @Test
  public void test21() {
    gam.erffc(19.929990740820585 ) ;
  }

  @Test
  public void test22() {
    gam.erffc(-2.220446049250313E-16 ) ;
  }

  @Test
  public void test23() {
    gam.erffc(-2.2761049594727193E-159 ) ;
  }

  @Test
  public void test24() {
    gam.erffc(2.2761049594727193E-159 ) ;
  }

  @Test
  public void test25() {
    gam.erffc(-2.5269841324701218E-175 ) ;
  }

  @Test
  public void test26() {
    gam.erffc(2.5269841324701218E-175 ) ;
  }

  @Test
  public void test27() {
    gam.erffc(39.619696184133886 ) ;
  }

  @Test
  public void test28() {
    gam.erffc(-42.918997322076265 ) ;
  }

  @Test
  public void test29() {
    gam.erffc(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test30() {
    gam.erffc(4.440892098500626E-16 ) ;
  }

  @Test
  public void test31() {
    gam.erffc(5.0539682649402436E-175 ) ;
  }

  @Test
  public void test32() {
    gam.erffc(51.17660010126818 ) ;
  }

  @Test
  public void test33() {
    gam.erffc(51.33060814181255 ) ;
  }

  @Test
  public void test34() {
    gam.erffc(-5.4484815861659825 ) ;
  }

  @Test
  public void test35() {
    gam.erffc(65.98993334914857 ) ;
  }

  @Test
  public void test36() {
    gam.erffc(72.17637281490462 ) ;
  }

  @Test
  public void test37() {
    gam.erffc(72.4961197323421 ) ;
  }

  @Test
  public void test38() {
    gam.erffc(-74.18392000070762 ) ;
  }

  @Test
  public void test39() {
    gam.erffc(-77.43618848509661 ) ;
  }

  @Test
  public void test40() {
    gam.erffc(-7.820637090558988E-149 ) ;
  }

  @Test
  public void test41() {
    gam.erffc(-7.950614359978033 ) ;
  }

  @Test
  public void test42() {
    gam.erffc(-81.6765315259783 ) ;
  }

  @Test
  public void test43() {
    gam.erffc(-85.41718150178596 ) ;
  }

  @Test
  public void test44() {
    gam.erffc(-8.673617379884035E-19 ) ;
  }

  @Test
  public void test45() {
    gam.erffc(-8.881784197001252E-16 ) ;
  }

  @Test
  public void test46() {
    gam.erffc(8.881784197001252E-16 ) ;
  }

  @Test
  public void test47() {
    gam.erffc(96.29021465839463 ) ;
  }
}
