import org.junit.Test;

public class TestbicoTest {

  @Test
  public void test0() {
    gam.bico(0,0 ) ;
  }

  @Test
  public void test1() {
    gam.bico(0,-1 ) ;
  }

  @Test
  public void test2() {
    gam.bico(0,1 ) ;
  }

  @Test
  public void test3() {
    gam.bico(0,2 ) ;
  }

  @Test
  public void test4() {
    gam.bico(0,987 ) ;
  }

  @Test
  public void test5() {
    gam.bico(-1,0 ) ;
  }

  @Test
  public void test6() {
    gam.bico(1,-120 ) ;
  }

  @Test
  public void test7() {
    gam.bico(-117,-543 ) ;
  }

  @Test
  public void test8() {
    gam.bico(1,259 ) ;
  }

  @Test
  public void test9() {
    gam.bico(1,-277 ) ;
  }

  @Test
  public void test10() {
    gam.bico(1,-769 ) ;
  }

  @Test
  public void test11() {
    gam.bico(1,-940 ) ;
  }

  @Test
  public void test12() {
    gam.bico(2,0 ) ;
  }

  @Test
  public void test13() {
    gam.bico(20,0 ) ;
  }

  @Test
  public void test14() {
    gam.bico(-284,-645 ) ;
  }

  @Test
  public void test15() {
    gam.bico(-320,322 ) ;
  }

  @Test
  public void test16() {
    gam.bico(345,0 ) ;
  }

  @Test
  public void test17() {
    gam.bico(-349,1 ) ;
  }

  @Test
  public void test18() {
    gam.bico(-382,2 ) ;
  }

  @Test
  public void test19() {
    gam.bico(-403,-803 ) ;
  }

  @Test
  public void test20() {
    gam.bico(-486,0 ) ;
  }

  @Test
  public void test21() {
    gam.bico(-496,2 ) ;
  }

  @Test
  public void test22() {
    gam.bico(-505,-80 ) ;
  }

  @Test
  public void test23() {
    gam.bico(-52,-459 ) ;
  }

  @Test
  public void test24() {
    gam.bico(555,0 ) ;
  }

  @Test
  public void test25() {
    gam.bico(-569,111 ) ;
  }

  @Test
  public void test26() {
    gam.bico(-756,0 ) ;
  }

  @Test
  public void test27() {
    gam.bico(-791,0 ) ;
  }

  @Test
  public void test28() {
    gam.bico(-811,-811 ) ;
  }

  @Test
  public void test29() {
    gam.bico(-92,-91 ) ;
  }

  @Test
  public void test30() {
    gam.bico(-948,214 ) ;
  }

  @Test
  public void test31() {
    gam.bico(974,0 ) ;
  }

  @Test
  public void test32() {
    gam.bico(-979,0 ) ;
  }

  @Test
  public void test33() {
    gam.bico(-997,-991 ) ;
  }
}
