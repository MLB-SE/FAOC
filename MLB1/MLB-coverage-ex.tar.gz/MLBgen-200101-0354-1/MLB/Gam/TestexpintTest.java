import org.junit.Test;

public class TestexpintTest {

  @Test
  public void test0() {
    expint.expint(0,0.0 ) ;
  }

  @Test
  public void test1() {
    expint.expint(0,11.077874820598964 ) ;
  }

  @Test
  public void test2() {
    expint.expint(1,0.0 ) ;
  }

  @Test
  public void test3() {
    expint.expint(141,0 ) ;
  }

  @Test
  public void test4() {
    expint.expint(144,0.9999999999999982 ) ;
  }

  @Test
  public void test5() {
    expint.expint(173,48.26729339210354 ) ;
  }

  @Test
  public void test6() {
    expint.expint(179,3.0E-323 ) ;
  }

  @Test
  public void test7() {
    expint.expint(-19,0 ) ;
  }

  @Test
  public void test8() {
    expint.expint(194,0.0 ) ;
  }

  @Test
  public void test9() {
    expint.expint(195,0.0 ) ;
  }

  @Test
  public void test10() {
    expint.expint(207,-2.53E-321 ) ;
  }

  @Test
  public void test11() {
    expint.expint(21,24.16499415789484 ) ;
  }

  @Test
  public void test12() {
    expint.expint(285,1.0 ) ;
  }

  @Test
  public void test13() {
    expint.expint(357,28.59452427191485 ) ;
  }

  @Test
  public void test14() {
    expint.expint(413,6.4E-323 ) ;
  }

  @Test
  public void test15() {
    expint.expint(471,1.4788152327084684E-272 ) ;
  }

  @Test
  public void test16() {
    expint.expint(506,85.32830646098427 ) ;
  }

  @Test
  public void test17() {
    expint.expint(51,0.0 ) ;
  }

  @Test
  public void test18() {
    expint.expint(644,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test19() {
    expint.expint(824,14.157786929062283 ) ;
  }

  @Test
  public void test20() {
    expint.expint(910,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test21() {
    expint.expint(960,0.0 ) ;
  }

  @Test
  public void test22() {
    expint.expint(99,-17.857754610118448 ) ;
  }
}
