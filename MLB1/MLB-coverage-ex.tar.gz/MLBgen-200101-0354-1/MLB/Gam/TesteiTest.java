import org.junit.Test;

public class TesteiTest {

  @Test
  public void test0() {
    expint.ei(0.0015652377189554864 ) ;
  }

  @Test
  public void test1() {
    expint.ei(0.008458251006125591 ) ;
  }

  @Test
  public void test2() {
    expint.ei(0.061362327321052304 ) ;
  }

  @Test
  public void test3() {
    expint.ei(0.19355198123718914 ) ;
  }

  @Test
  public void test4() {
    expint.ei(0.4156956373819731 ) ;
  }

  @Test
  public void test5() {
    expint.ei(0.7232656054321196 ) ;
  }

  @Test
  public void test6() {
    expint.ei(0.7724187664444742 ) ;
  }

  @Test
  public void test7() {
    expint.ei(0.9999999999999998 ) ;
  }

  @Test
  public void test8() {
    expint.ei(1.0 ) ;
  }

  @Test
  public void test9() {
    expint.ei(1.0118E-320 ) ;
  }

  @Test
  public void test10() {
    expint.ei(1.0235761163406E-310 ) ;
  }

  @Test
  public void test11() {
    expint.ei(-10.815039143437005 ) ;
  }

  @Test
  public void test12() {
    expint.ei(1.106421579651463 ) ;
  }

  @Test
  public void test13() {
    expint.ei(1.1102230246251565E-16 ) ;
  }

  @Test
  public void test14() {
    expint.ei(1.1665795231290236E-302 ) ;
  }

  @Test
  public void test15() {
    expint.ei(-11.915823671199092 ) ;
  }

  @Test
  public void test16() {
    expint.ei(1.2085667661490307E-5 ) ;
  }

  @Test
  public void test17() {
    expint.ei(1.265E-321 ) ;
  }

  @Test
  public void test18() {
    expint.ei(1.4582244039112795E-303 ) ;
  }

  @Test
  public void test19() {
    expint.ei(14.889799438160239 ) ;
  }

  @Test
  public void test20() {
    expint.ei(1.58E-322 ) ;
  }

  @Test
  public void test21() {
    expint.ei(1.700917035529373E-309 ) ;
  }

  @Test
  public void test22() {
    expint.ei(17.217529798356978 ) ;
  }

  @Test
  public void test23() {
    expint.ei(1.734723475976807E-18 ) ;
  }

  @Test
  public void test24() {
    expint.ei(1.7763568394002505E-15 ) ;
  }

  @Test
  public void test25() {
    expint.ei(17.917698054210064 ) ;
  }

  @Test
  public void test26() {
    expint.ei(1.9721522630525295E-31 ) ;
  }

  @Test
  public void test27() {
    expint.ei(2.17753057752505E-310 ) ;
  }

  @Test
  public void test28() {
    expint.ei(2.2250738585072014E-308 ) ;
  }

  @Test
  public void test29() {
    expint.ei(2.558940307041E-311 ) ;
  }

  @Test
  public void test30() {
    expint.ei(2.663368250502059E-305 ) ;
  }

  @Test
  public void test31() {
    expint.ei(2733.5053220945915 ) ;
  }

  @Test
  public void test32() {
    expint.ei(2.763215441414654E-307 ) ;
  }

  @Test
  public void test33() {
    expint.ei(2.916448807822559E-303 ) ;
  }

  @Test
  public void test34() {
    expint.ei(31.367820182359367 ) ;
  }

  @Test
  public void test35() {
    expint.ei(3.16E-322 ) ;
  }

  @Test
  public void test36() {
    expint.ei(32.23619130191664 ) ;
  }

  @Test
  public void test37() {
    expint.ei(3.2379E-319 ) ;
  }

  @Test
  public void test38() {
    expint.ei(32.59021706509141 ) ;
  }

  @Test
  public void test39() {
    expint.ei(33.93909624499102 ) ;
  }

  @Test
  public void test40() {
    expint.ei(3.73351824943653E-310 ) ;
  }

  @Test
  public void test41() {
    expint.ei(-3.9686101840156454 ) ;
  }

  @Test
  public void test42() {
    expint.ei(4.242640912119312E-7 ) ;
  }

  @Test
  public void test43() {
    expint.ei(4.242640912119313E-7 ) ;
  }

  @Test
  public void test44() {
    expint.ei(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test45() {
    expint.ei(4.440892098500626E-16 ) ;
  }

  @Test
  public void test46() {
    expint.ei(4.72230006954155E-310 ) ;
  }

  @Test
  public void test47() {
    expint.ei(4.8633294792639E-310 ) ;
  }

  @Test
  public void test48() {
    expint.ei(4.897265328852459E-307 ) ;
  }

  @Test
  public void test49() {
    expint.ei(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test50() {
    expint.ei(5.06E-321 ) ;
  }

  @Test
  public void test51() {
    expint.ei(5.117880614082E-311 ) ;
  }

  @Test
  public void test52() {
    expint.ei(5.551115123125783E-17 ) ;
  }

  @Test
  public void test53() {
    expint.ei(56.33305795828244 ) ;
  }

  @Test
  public void test54() {
    expint.ei(-56.854726485645955 ) ;
  }

  @Test
  public void test55() {
    expint.ei(5.832897615645118E-303 ) ;
  }

  @Test
  public void test56() {
    expint.ei(63.62758805437002 ) ;
  }

  @Test
  public void test57() {
    expint.ei(6.4658935872292E-310 ) ;
  }

  @Test
  public void test58() {
    expint.ei(6.4E-323 ) ;
  }

  @Test
  public void test59() {
    expint.ei(70.19213032331268 ) ;
  }

  @Test
  public void test60() {
    expint.ei(8.0948E-320 ) ;
  }

  @Test
  public void test61() {
    expint.ei(-8.881784197001252E-16 ) ;
  }

  @Test
  public void test62() {
    expint.ei(88.8922498206926 ) ;
  }

  @Test
  public void test63() {
    expint.ei(9.23639754082914E-310 ) ;
  }

  @Test
  public void test64() {
    expint.ei(97.12839513076653 ) ;
  }

  @Test
  public void test65() {
    expint.ei(9.864929395126312E-5 ) ;
  }
}
