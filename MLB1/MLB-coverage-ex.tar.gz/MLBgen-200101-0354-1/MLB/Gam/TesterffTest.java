import org.junit.Test;

public class TesterffTest {

  @Test
  public void test0() {
    gam.erff(-0.10940953766041056 ) ;
  }

  @Test
  public void test1() {
    gam.erff(0.17026661240656055 ) ;
  }

  @Test
  public void test2() {
    gam.erff(0.35379635574203494 ) ;
  }

  @Test
  public void test3() {
    gam.erff(-0.6198270978082916 ) ;
  }

  @Test
  public void test4() {
    gam.erff(0.9761700690635877 ) ;
  }

  @Test
  public void test5() {
    gam.erff(-1.048315203383666 ) ;
  }

  @Test
  public void test6() {
    gam.erff(1.0796094707838506 ) ;
  }

  @Test
  public void test7() {
    gam.erff(1.1102230246251565E-16 ) ;
  }

  @Test
  public void test8() {
    gam.erff(1.1113793747425387E-162 ) ;
  }

  @Test
  public void test9() {
    gam.erff(1.1579018769336074 ) ;
  }

  @Test
  public void test10() {
    gam.erff(-1.18066465255407 ) ;
  }

  @Test
  public void test11() {
    gam.erff(-1.224744871391589 ) ;
  }

  @Test
  public void test12() {
    gam.erff(-1.2247448713915892 ) ;
  }

  @Test
  public void test13() {
    gam.erff(1.2247448713915892 ) ;
  }

  @Test
  public void test14() {
    gam.erff(1.2247448713915894 ) ;
  }

  @Test
  public void test15() {
    gam.erff(1.2247448713915953E-7 ) ;
  }

  @Test
  public void test16() {
    gam.erff(-1.224744871391595E-7 ) ;
  }

  @Test
  public void test17() {
    gam.erff(1.224744871391595E-7 ) ;
  }

  @Test
  public void test18() {
    gam.erff(1.232595164407831E-32 ) ;
  }

  @Test
  public void test19() {
    gam.erff(17.505267926659542 ) ;
  }

  @Test
  public void test20() {
    gam.erff(1.751275838118581E-14 ) ;
  }

  @Test
  public void test21() {
    gam.erff(-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test22() {
    gam.erff(-18.043012160943547 ) ;
  }

  @Test
  public void test23() {
    gam.erff(2.0035339527624245 ) ;
  }

  @Test
  public void test24() {
    gam.erff(2.220446049250313E-16 ) ;
  }

  @Test
  public void test25() {
    gam.erff(2.2227587494850775E-162 ) ;
  }

  @Test
  public void test26() {
    gam.erff(-22.510303988958967 ) ;
  }

  @Test
  public void test27() {
    gam.erff(24.885215959496023 ) ;
  }

  @Test
  public void test28() {
    gam.erff(2.7755575615628914E-17 ) ;
  }

  @Test
  public void test29() {
    gam.erff(2.778448436856347E-163 ) ;
  }

  @Test
  public void test30() {
    gam.erff(-3.1587301655876523E-176 ) ;
  }

  @Test
  public void test31() {
    gam.erff(33.248837156706514 ) ;
  }

  @Test
  public void test32() {
    gam.erff(3.552713678800501E-15 ) ;
  }

  @Test
  public void test33() {
    gam.erff(4.3368086899420177E-19 ) ;
  }

  @Test
  public void test34() {
    gam.erff(-4.682946067332281 ) ;
  }

  @Test
  public void test35() {
    gam.erff(-5.0539682649402436E-175 ) ;
  }

  @Test
  public void test36() {
    gam.erff(51.61766489146876 ) ;
  }

  @Test
  public void test37() {
    gam.erff(-52.79474584719361 ) ;
  }

  @Test
  public void test38() {
    gam.erff(55.270568417404775 ) ;
  }

  @Test
  public void test39() {
    gam.erff(-5.551115123125783E-17 ) ;
  }

  @Test
  public void test40() {
    gam.erff(5.551115123125783E-17 ) ;
  }

  @Test
  public void test41() {
    gam.erff(-5.872643821210417 ) ;
  }

  @Test
  public void test42() {
    gam.erff(61.900825613971534 ) ;
  }

  @Test
  public void test43() {
    gam.erff(-6.2565096724471904E-148 ) ;
  }

  @Test
  public void test44() {
    gam.erff(66.31352029001118 ) ;
  }

  @Test
  public void test45() {
    gam.erff(6.946121092140867E-164 ) ;
  }

  @Test
  public void test46() {
    gam.erff(-70.51303706863735 ) ;
  }

  @Test
  public void test47() {
    gam.erff(-74.87034047968561 ) ;
  }

  @Test
  public void test48() {
    gam.erff(-7.703719777548943E-34 ) ;
  }

  @Test
  public void test49() {
    gam.erff(-77.60041109831597 ) ;
  }

  @Test
  public void test50() {
    gam.erff(-8.673617379884035E-19 ) ;
  }

  @Test
  public void test51() {
    gam.erff(8.673617379884035E-19 ) ;
  }

  @Test
  public void test52() {
    gam.erff(-8.881784197001252E-16 ) ;
  }

  @Test
  public void test53() {
    gam.erff(-8.89103499794031E-162 ) ;
  }

  @Test
  public void test54() {
    gam.erff(93.76013407194742 ) ;
  }
}
