import org.junit.Test;

public class TestbetacfTest {

  @Test
  public void test0() {
    beta.betacf(12.862173572075648,-26.64276184459642,-2.257935717514073 ) ;
  }

  @Test
  public void test1() {
    beta.betacf(13.098583017368014,-53.304473895183804,92.09730033940721 ) ;
  }

  @Test
  public void test2() {
    beta.betacf(-2.113289025089439,-24.7855772486623,0.04138795344604545 ) ;
  }

  @Test
  public void test3() {
    beta.betacf(24.306008671923635,-38.37935164728334,-1.798151918576178 ) ;
  }

  @Test
  public void test4() {
    beta.betacf(-32.09851897878144,31.588211014567996,60.94068907334139 ) ;
  }

  @Test
  public void test5() {
    beta.betacf(-38.17106215656241,-52.97247895156249,0.4078299098832011 ) ;
  }

  @Test
  public void test6() {
    beta.betacf(48.72266870046701,39.23978013129203,0.5652715375804149 ) ;
  }

  @Test
  public void test7() {
    beta.betacf(50.354135863681904,51.18557610271736,-52.40233311105229 ) ;
  }

  @Test
  public void test8() {
    beta.betacf(5.643546790033113,58.41547228440115,-34.01429366313434 ) ;
  }

  @Test
  public void test9() {
    beta.betacf(5.773467592702147,15.033082280855353,-90.30023551035191 ) ;
  }

  @Test
  public void test10() {
    beta.betacf(61.36688133683407,0,0 ) ;
  }

  @Test
  public void test11() {
    beta.betacf(-6.41035384596627,-14.370395347592961,62.70701372589059 ) ;
  }

  @Test
  public void test12() {
    beta.betacf(-64.78092260914244,80.71699514577136,-4.0022987133462475 ) ;
  }

  @Test
  public void test13() {
    beta.betacf(-67.97385012544603,66.86404128695642,60.34719476247246 ) ;
  }

  @Test
  public void test14() {
    beta.betacf(69.11789942818444,-88.91687464622247,20.224703124373463 ) ;
  }

  @Test
  public void test15() {
    beta.betacf(-69.16616530514072,-88.61081930400539,15.664156664803343 ) ;
  }

  @Test
  public void test16() {
    beta.betacf(80.39661101282391,1.7824107429502192,21.736267453710127 ) ;
  }

  @Test
  public void test17() {
    beta.betacf(-8.303651633059062,0,0 ) ;
  }

  @Test
  public void test18() {
    beta.betacf(-88.36056133153905,91.52351107937511,-27.619964999857118 ) ;
  }

  @Test
  public void test19() {
    beta.betacf(89.64967470765988,-86.20906263727566,26.346961776930844 ) ;
  }

  @Test
  public void test20() {
    beta.betacf(-91.95259072271683,93.3046529525259,-67.26952999460757 ) ;
  }

  @Test
  public void test21() {
    beta.betacf(-97.1344947106016,63.37003618065958,2.8472097257342477 ) ;
  }

  @Test
  public void test22() {
    beta.betacf(97.52996476441987,71.99887794166463,0.5811988284214457 ) ;
  }
}
