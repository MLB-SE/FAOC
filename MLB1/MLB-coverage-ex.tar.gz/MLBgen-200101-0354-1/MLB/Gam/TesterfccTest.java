import org.junit.Test;

public class TesterfccTest {

  @Test
  public void test0() {
    erf.erfcc(-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1() {
    erf.erfcc(-14.447113994375144 ) ;
  }

  @Test
  public void test2() {
    erf.erfcc(2.0E-323 ) ;
  }

  @Test
  public void test3() {
    erf.erfcc(-2.465190328815662E-32 ) ;
  }

  @Test
  public void test4() {
    erf.erfcc(-26.75276059823804 ) ;
  }

  @Test
  public void test5() {
    erf.erfcc(-31.38798641352298 ) ;
  }

  @Test
  public void test6() {
    erf.erfcc(-4.524850233078141 ) ;
  }

  @Test
  public void test7() {
    erf.erfcc(4.930380657631324E-32 ) ;
  }

  @Test
  public void test8() {
    erf.erfcc(56.47441725912583 ) ;
  }

  @Test
  public void test9() {
    erf.erfcc(71.98526124059151 ) ;
  }

  @Test
  public void test10() {
    erf.erfcc(72.9886962413355 ) ;
  }

  @Test
  public void test11() {
    erf.erfcc(-7.4E-323 ) ;
  }

  @Test
  public void test12() {
    erf.erfcc(9.860761315262648E-32 ) ;
  }
}
