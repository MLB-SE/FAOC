import org.junit.Test;

public class TestbetaiTest {

  @Test
  public void test0() {
    beta.betai(0,0,0.9588713583080652 ) ;
  }

  @Test
  public void test1() {
    beta.betai(0,0,0.9999999999999996 ) ;
  }

  @Test
  public void test2() {
    beta.betai(0,0,0.9999999999999998 ) ;
  }

  @Test
  public void test3() {
    beta.betai(0,0,0.9999999999999999 ) ;
  }

  @Test
  public void test4() {
    beta.betai(0,0,1.0000000000000004 ) ;
  }

  @Test
  public void test5() {
    beta.betai(0,0,1.000043471240269 ) ;
  }

  @Test
  public void test6() {
    beta.betai(0,0,1.0001680636450876 ) ;
  }

  @Test
  public void test7() {
    beta.betai(0,0,1.0570410691338878 ) ;
  }

  @Test
  public void test8() {
    beta.betai(0,0,18.918973533932544 ) ;
  }

  @Test
  public void test9() {
    beta.betai(0,0,1.9721522630525295E-31 ) ;
  }

  @Test
  public void test10() {
    beta.betai(0,0,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test11() {
    beta.betai(0,0,-23.630714918599466 ) ;
  }

  @Test
  public void test12() {
    beta.betai(0,0,-26.94612017701587 ) ;
  }

  @Test
  public void test13() {
    beta.betai(0,0,-3.0814879110195774E-33 ) ;
  }

  @Test
  public void test14() {
    beta.betai(0,0,-33.46564317814338 ) ;
  }

  @Test
  public void test15() {
    beta.betai(0,0,36.39289629606586 ) ;
  }

  @Test
  public void test16() {
    beta.betai(0,0,39.473125742681475 ) ;
  }

  @Test
  public void test17() {
    beta.betai(0,0,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test18() {
    beta.betai(0,0,5.551115123125783E-17 ) ;
  }

  @Test
  public void test19() {
    beta.betai(0,0,64.21033777426234 ) ;
  }

  @Test
  public void test20() {
    beta.betai(0,0,7.659969856812964 ) ;
  }

  @Test
  public void test21() {
    beta.betai(0,0,9.332077013386012 ) ;
  }

  @Test
  public void test22() {
    beta.betai(12.472909790998115,-13.472909790998115,33.759734932696404 ) ;
  }

  @Test
  public void test23() {
    beta.betai(-29.756059889964376,28.756059889964376,-5.973535637956999 ) ;
  }

  @Test
  public void test24() {
    beta.betai(-3.7045142444232226,23.26705504931961,-91.27969099320711 ) ;
  }

  @Test
  public void test25() {
    beta.betai(37.46047481406046,-14.07452036708996,-29.04995420781522 ) ;
  }

  @Test
  public void test26() {
    beta.betai(-40.709911683642005,39.709911683642005,0.2686017798997066 ) ;
  }

  @Test
  public void test27() {
    beta.betai(54.43390082205036,-56.43390082205036,-25.453674183050623 ) ;
  }

  @Test
  public void test28() {
    beta.betai(-73.14077731343727,93.29822144384727,16.492928836140948 ) ;
  }

  @Test
  public void test29() {
    beta.betai(-78.0441769813306,-49.71090575704338,0.8205639551743786 ) ;
  }
}
