import org.junit.Test;

public class TestbetaTest {

  @Test
  public void test0() {
    beta.beta(-1.0,0 ) ;
  }

  @Test
  public void test1() {
    beta.beta(-2.0,0 ) ;
  }

  @Test
  public void test2() {
    beta.beta(-3.0,0 ) ;
  }

  @Test
  public void test3() {
    beta.beta(66.58237418562376,0 ) ;
  }

  @Test
  public void test4() {
    beta.beta(-67.24506510212453,0 ) ;
  }

  @Test
  public void test5() {
    beta.beta(-91.1968529682271,0 ) ;
  }
}
