import org.junit.Test;

public class TestfactrlTest {

  @Test
  public void test0() {
    gam.factrl(0 ) ;
  }

  @Test
  public void test1() {
    gam.factrl(-1 ) ;
  }

  @Test
  public void test2() {
    gam.factrl(-134 ) ;
  }

  @Test
  public void test3() {
    gam.factrl(15 ) ;
  }

  @Test
  public void test4() {
    gam.factrl(-452 ) ;
  }

  @Test
  public void test5() {
    gam.factrl(560 ) ;
  }

  @Test
  public void test6() {
    gam.factrl(6 ) ;
  }

  @Test
  public void test7() {
    gam.factrl(-60 ) ;
  }

  @Test
  public void test8() {
    gam.factrl(617 ) ;
  }

  @Test
  public void test9() {
    gam.factrl(898 ) ;
  }
}
