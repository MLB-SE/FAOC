import org.junit.Test;

public class JpfTargetTcasTest {

  @Test
  public void test0() {
    Tcas.start_symbolic(0,1,0,0,0,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    Tcas.start_symbolic(0,1,0,0,1015,0,0,0,0,0,1,0 ) ;
  }

  @Test
  public void test2() {
    Tcas.start_symbolic(0,1,0,0,-604,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    Tcas.start_symbolic(0,1,0,0,635,0,0,0,0,0,697,0 ) ;
  }

  @Test
  public void test4() {
    Tcas.start_symbolic(0,1,0,0,775,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    Tcas.start_symbolic(0,1,1,0,1062,0,0,0,0,0,346,0 ) ;
  }

  @Test
  public void test6() {
    Tcas.start_symbolic(0,1,1,0,2217,0,0,0,0,29,423,0 ) ;
  }

  @Test
  public void test7() {
    Tcas.start_symbolic(0,1,1,0,2404,0,0,0,0,174,2,0 ) ;
  }

  @Test
  public void test8() {
    Tcas.start_symbolic(0,1,1,0,3118,0,0,0,0,0,455,0 ) ;
  }

  @Test
  public void test9() {
    Tcas.start_symbolic(0,1,1,0,770,0,0,0,0,0,1,0 ) ;
  }

  @Test
  public void test10() {
    Tcas.start_symbolic(0,1,1,0,821,0,0,0,0,0,1,0 ) ;
  }

  @Test
  public void test11() {
    Tcas.start_symbolic(0,1,559,0,902,0,0,0,0,0,-670,0 ) ;
  }

  @Test
  public void test12() {
    Tcas.start_symbolic(0,187,1,0,0,0,0,0,0,0,468,0 ) ;
  }

  @Test
  public void test13() {
    Tcas.start_symbolic(0,1,898,0,954,0,0,0,0,0,1,0 ) ;
  }

  @Test
  public void test14() {
    Tcas.start_symbolic(0,-440,-802,0,0,0,0,0,0,0,-130,0 ) ;
  }

  @Test
  public void test15() {
    Tcas.start_symbolic(0,-522,1,0,0,0,0,0,0,0,1,0 ) ;
  }

  @Test
  public void test16() {
    Tcas.start_symbolic(0,-575,1,0,0,0,0,0,0,1204,1,0 ) ;
  }

  @Test
  public void test17() {
    Tcas.start_symbolic(0,588,1,0,0,0,0,0,0,-558,-291,0 ) ;
  }

  @Test
  public void test18() {
    Tcas.start_symbolic(0,-589,0,0,0,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test19() {
    Tcas.start_symbolic(0,615,1,0,0,0,0,0,0,0,1,0 ) ;
  }

  @Test
  public void test20() {
    Tcas.start_symbolic(0,-617,0,0,0,0,0,0,0,0,1,0 ) ;
  }

  @Test
  public void test21() {
    Tcas.start_symbolic(0,845,0,0,0,0,0,0,0,0,-596,0 ) ;
  }

  @Test
  public void test22() {
    Tcas.start_symbolic(0,-924,1,0,0,0,0,0,0,0,-863,0 ) ;
  }

  @Test
  public void test23() {
    Tcas.start_symbolic(0,967,-714,0,0,0,0,0,0,0,1,0 ) ;
  }

  @Test
  public void test24() {
    Tcas.start_symbolic(1012,2,-7,1607,-47,131,0,-742,-729,0,478,0 ) ;
  }

  @Test
  public void test25() {
    Tcas.start_symbolic(1025,1,326,578,-441,1178,0,-1935,-944,0,74,0 ) ;
  }

  @Test
  public void test26() {
    Tcas.start_symbolic(1025,1,-773,-381,-125,-380,0,151,-993,0,-341,0 ) ;
  }

  @Test
  public void test27() {
    Tcas.start_symbolic(1026,1,1,-953,-1273,-833,0,0,0,0,19,0 ) ;
  }

  @Test
  public void test28() {
    Tcas.start_symbolic(1057,1,0,0,-1387,0,0,0,0,2,0,0 ) ;
  }

  @Test
  public void test29() {
    Tcas.start_symbolic(1072,1,146,0,150,0,0,625,-1759,0,-674,0 ) ;
  }

  @Test
  public void test30() {
    Tcas.start_symbolic(1105,1,1,0,-574,0,0,0,0,0,-1847,1 ) ;
  }

  @Test
  public void test31() {
    Tcas.start_symbolic(1141,1,1,0,-511,0,0,-977,41,0,796,0 ) ;
  }

  @Test
  public void test32() {
    Tcas.start_symbolic(1183,0,1186,945,-799,566,0,508,515,0,185,0 ) ;
  }

  @Test
  public void test33() {
    Tcas.start_symbolic(1193,1,-1093,-208,-20,-208,0,-1485,-587,0,122,0 ) ;
  }

  @Test
  public void test34() {
    Tcas.start_symbolic(1209,2,-1237,758,-549,-307,0,561,895,0,104,0 ) ;
  }

  @Test
  public void test35() {
    Tcas.start_symbolic(122,1,238,0,-888,0,0,0,0,0,1,0 ) ;
  }

  @Test
  public void test36() {
    Tcas.start_symbolic(1282,1,778,261,229,810,0,672,-322,0,752,0 ) ;
  }

  @Test
  public void test37() {
    Tcas.start_symbolic(1398,1,654,-906,-845,460,0,990,-476,0,-130,0 ) ;
  }

  @Test
  public void test38() {
    Tcas.start_symbolic(1428,3,-584,635,235,-1303,0,295,2456,0,854,0 ) ;
  }

  @Test
  public void test39() {
    Tcas.start_symbolic(1434,1,1,0,-686,0,0,0,0,0,1,0 ) ;
  }

  @Test
  public void test40() {
    Tcas.start_symbolic(1461,1,273,-637,-80,1105,0,-94,49,0,1079,0 ) ;
  }

  @Test
  public void test41() {
    Tcas.start_symbolic(1473,0,-874,-754,71,326,0,1732,628,0,-1063,0 ) ;
  }

  @Test
  public void test42() {
    Tcas.start_symbolic(-1495,1,1,0,110,0,0,0,0,0,1265,0 ) ;
  }

  @Test
  public void test43() {
    Tcas.start_symbolic(1530,0,-855,-923,-36,851,0,219,-363,0,490,0 ) ;
  }

  @Test
  public void test44() {
    Tcas.start_symbolic(1584,1,-308,0,-475,0,0,-614,-484,0,459,0 ) ;
  }

  @Test
  public void test45() {
    Tcas.start_symbolic(1666,2,-518,244,-381,729,0,-289,6,0,-1141,0 ) ;
  }

  @Test
  public void test46() {
    Tcas.start_symbolic(1679,1,1,0,-216,0,0,0,0,545,-933,0 ) ;
  }

  @Test
  public void test47() {
    Tcas.start_symbolic(168,1,-1,0,-699,0,0,0,0,722,513,0 ) ;
  }

  @Test
  public void test48() {
    Tcas.start_symbolic(1752,1,-912,0,-449,0,0,0,0,0,4,0 ) ;
  }

  @Test
  public void test49() {
    Tcas.start_symbolic(1754,1,0,1626,-1591,618,0,644,0,0,-154,0 ) ;
  }

  @Test
  public void test50() {
    Tcas.start_symbolic(1870,2,1413,240,-845,240,0,-454,-381,0,3194,0 ) ;
  }

  @Test
  public void test51() {
    Tcas.start_symbolic(2080,1,1,-367,499,-367,0,0,0,0,-1406,0 ) ;
  }

  @Test
  public void test52() {
    Tcas.start_symbolic(2108,-2,-1680,0,-848,0,0,-104,1411,0,1065,1 ) ;
  }

  @Test
  public void test53() {
    Tcas.start_symbolic(2193,0,18,-643,559,-588,0,-977,-700,0,569,0 ) ;
  }

  @Test
  public void test54() {
    Tcas.start_symbolic(2249,1,-524,207,513,72,0,-910,-899,0,-647,0 ) ;
  }

  @Test
  public void test55() {
    Tcas.start_symbolic(2289,1,470,0,212,0,0,801,-220,0,829,-8 ) ;
  }

  @Test
  public void test56() {
    Tcas.start_symbolic(238,1,1,0,25,0,0,0,0,0,1,0 ) ;
  }

  @Test
  public void test57() {
    Tcas.start_symbolic(2406,1,1,0,349,0,0,0,0,1,124,0 ) ;
  }

  @Test
  public void test58() {
    Tcas.start_symbolic(2477,2,1,1228,532,-944,0,0,0,0,-272,0 ) ;
  }

  @Test
  public void test59() {
    Tcas.start_symbolic(2943,1,-384,0,-348,0,0,-436,-437,0,802,0 ) ;
  }

  @Test
  public void test60() {
    Tcas.start_symbolic(299,1,-1152,-583,-473,682,0,2183,374,0,-836,0 ) ;
  }

  @Test
  public void test61() {
    Tcas.start_symbolic(299,1,173,0,-63,0,0,0,0,0,516,0 ) ;
  }

  @Test
  public void test62() {
    Tcas.start_symbolic(-301,1,0,0,-477,0,0,0,0,0,1,0 ) ;
  }

  @Test
  public void test63() {
    Tcas.start_symbolic(-313,1,1,0,501,0,0,0,0,0,857,0 ) ;
  }

  @Test
  public void test64() {
    Tcas.start_symbolic(-364,1,0,0,-113,0,0,0,0,0,984,0 ) ;
  }

  @Test
  public void test65() {
    Tcas.start_symbolic(463,1,0,0,-269,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test66() {
    Tcas.start_symbolic(509,0,5,0,138,0,0,0,0,737,0,0 ) ;
  }

  @Test
  public void test67() {
    Tcas.start_symbolic(604,2,1,0,-1526,0,0,293,-759,0,531,0 ) ;
  }

  @Test
  public void test68() {
    Tcas.start_symbolic(646,1,1,-46,-688,-46,0,0,0,0,-109,0 ) ;
  }

  @Test
  public void test69() {
    Tcas.start_symbolic(665,1,1,1294,-770,-2646,0,-766,0,0,313,0 ) ;
  }

  @Test
  public void test70() {
    Tcas.start_symbolic(674,1,-472,0,-12,0,0,1326,428,0,-138,-1065 ) ;
  }

  @Test
  public void test71() {
    Tcas.start_symbolic(677,1,658,932,-218,-470,0,979,-787,0,-649,0 ) ;
  }

  @Test
  public void test72() {
    Tcas.start_symbolic(691,1,0,-270,-507,686,0,0,0,0,659,0 ) ;
  }

  @Test
  public void test73() {
    Tcas.start_symbolic(691,1,260,-783,-2065,-782,0,-704,1488,0,1229,0 ) ;
  }

  @Test
  public void test74() {
    Tcas.start_symbolic(713,1,1,0,302,0,0,0,0,0,1462,-3 ) ;
  }

  @Test
  public void test75() {
    Tcas.start_symbolic(714,1,1,90,-1491,-655,0,0,0,0,904,0 ) ;
  }

  @Test
  public void test76() {
    Tcas.start_symbolic(718,1,-343,0,523,0,0,153,872,0,-349,0 ) ;
  }

  @Test
  public void test77() {
    Tcas.start_symbolic(718,1,-826,0,308,0,0,0,0,0,-1312,1 ) ;
  }

  @Test
  public void test78() {
    Tcas.start_symbolic(724,1,1,13,-468,309,0,0,0,0,-470,0 ) ;
  }

  @Test
  public void test79() {
    Tcas.start_symbolic(755,1,-513,-748,138,-1837,0,312,325,0,-630,0 ) ;
  }

  @Test
  public void test80() {
    Tcas.start_symbolic(781,1,340,603,441,-473,0,786,903,0,76,0 ) ;
  }

  @Test
  public void test81() {
    Tcas.start_symbolic(791,1,1,0,-467,0,0,-514,452,0,-103,0 ) ;
  }

  @Test
  public void test82() {
    Tcas.start_symbolic(792,0,129,526,-563,-1450,0,-874,631,0,-413,0 ) ;
  }

  @Test
  public void test83() {
    Tcas.start_symbolic(807,1,-971,0,-901,0,0,-29,-1274,0,340,0 ) ;
  }

  @Test
  public void test84() {
    Tcas.start_symbolic(820,1,-933,191,-1245,183,0,-489,-207,0,-922,0 ) ;
  }

  @Test
  public void test85() {
    Tcas.start_symbolic(823,1,0,0,328,0,0,0,0,0,1,0 ) ;
  }

  @Test
  public void test86() {
    Tcas.start_symbolic(825,1,0,0,-505,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test87() {
    Tcas.start_symbolic(835,1,0,0,95,0,0,0,0,0,-465,0 ) ;
  }

  @Test
  public void test88() {
    Tcas.start_symbolic(838,0,904,0,-288,0,0,0,0,0,-639,-656 ) ;
  }

  @Test
  public void test89() {
    Tcas.start_symbolic(844,1,1,0,14,0,0,0,0,0,-799,0 ) ;
  }

  @Test
  public void test90() {
    Tcas.start_symbolic(857,1,-320,0,-749,0,0,-564,-25,0,-79,886 ) ;
  }

  @Test
  public void test91() {
    Tcas.start_symbolic(860,1,-713,-224,459,1961,0,-561,946,0,-920,0 ) ;
  }

  @Test
  public void test92() {
    Tcas.start_symbolic(872,1,-577,0,279,0,0,-416,403,0,-173,0 ) ;
  }

  @Test
  public void test93() {
    Tcas.start_symbolic(874,0,-409,-228,161,836,0,-597,-1472,0,-22,0 ) ;
  }

  @Test
  public void test94() {
    Tcas.start_symbolic(876,0,1,0,-450,0,0,0,0,0,229,-790 ) ;
  }

  @Test
  public void test95() {
    Tcas.start_symbolic(876,1,0,0,-191,0,0,0,0,-915,1,0 ) ;
  }

  @Test
  public void test96() {
    Tcas.start_symbolic(877,1,394,726,3,477,0,-963,283,0,-972,0 ) ;
  }

  @Test
  public void test97() {
    Tcas.start_symbolic(889,1,365,-677,-439,-677,0,704,1615,0,-647,0 ) ;
  }

  @Test
  public void test98() {
    Tcas.start_symbolic(904,1,1,0,19,0,0,0,0,0,-539,-1308 ) ;
  }

  @Test
  public void test99() {
    Tcas.start_symbolic(-909,1,2,0,57,0,0,0,0,1,2,0 ) ;
  }

  @Test
  public void test100() {
    Tcas.start_symbolic(909,2,31,1091,-14,-1027,0,-484,-1047,0,-727,0 ) ;
  }

  @Test
  public void test101() {
    Tcas.start_symbolic(929,1,-1,0,-771,0,0,-243,-278,0,-1218,0 ) ;
  }

  @Test
  public void test102() {
    Tcas.start_symbolic(934,1,1,-127,-66,-426,0,0,0,0,434,0 ) ;
  }

  @Test
  public void test103() {
    Tcas.start_symbolic(944,1,-628,-990,300,-971,0,24,724,0,-893,0 ) ;
  }

  @Test
  public void test104() {
    Tcas.start_symbolic(961,1,1030,352,7,462,0,2263,536,0,805,0 ) ;
  }

  @Test
  public void test105() {
    Tcas.start_symbolic(971,0,-1184,861,-665,-855,0,-971,-630,0,846,0 ) ;
  }

  @Test
  public void test106() {
    Tcas.start_symbolic(990,1,901,-617,-2215,-851,0,-647,-51,0,-353,0 ) ;
  }

  @Test
  public void test107() {
    Tcas.start_symbolic(997,1,-686,0,160,0,0,0,0,0,893,0 ) ;
  }
}
