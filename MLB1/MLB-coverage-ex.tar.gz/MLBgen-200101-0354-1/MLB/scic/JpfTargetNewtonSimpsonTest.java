import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(0.05767109662807002,-58.79556693992269 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(0.31021220164851115,0 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(-0.7459379599575229,0 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(-1.0171631753792383,0.9700452673765625 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(-10.251368717790484,99.65073729824974 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(-1.1531802773870936,7.397070473781573 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonSimpson.newton(-12.514492187281135,-87.92906473914009 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonSimpson.newton(1.3752960683127213,-2.691995345049264 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonSimpson.newton(1.6448969054204847,1.4965029215829873E-9 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonSimpson.newton(-1.6493292487337357,0 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonSimpson.newton(2.0043917844196244,82.77987671262846 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonSimpson.newton(2.08160552863734,-11.747246454253172 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonSimpson.newton(24.75585415540948,0 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonSimpson.newton(24.96992615990179,0 ) ;
  }

  @Test
  public void test14() {
    scic.NewtonSimpson.newton(2.6671842589775423,59.44771063226278 ) ;
  }

  @Test
  public void test15() {
    scic.NewtonSimpson.newton(2.821732199005808,0 ) ;
  }

  @Test
  public void test16() {
    scic.NewtonSimpson.newton(-30.807563835444313,99.11998844974437 ) ;
  }

  @Test
  public void test17() {
    scic.NewtonSimpson.newton(3.135771320495138,-34.07389557273106 ) ;
  }

  @Test
  public void test18() {
    scic.NewtonSimpson.newton(-3.3165595840882958,0 ) ;
  }

  @Test
  public void test19() {
    scic.NewtonSimpson.newton(33.20543269541375,0 ) ;
  }

  @Test
  public void test20() {
    scic.NewtonSimpson.newton(-33.25396416162971,0 ) ;
  }

  @Test
  public void test21() {
    scic.NewtonSimpson.newton(-43.67742022688543,0 ) ;
  }
}
