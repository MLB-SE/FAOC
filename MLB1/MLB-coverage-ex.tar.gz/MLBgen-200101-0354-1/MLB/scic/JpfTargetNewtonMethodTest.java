import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(30.192095095242934,-25.772916540157723 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(-42.128251321022205,60.53653346002227 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(-42.75,-100.0 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(-43.230464629176325,0.02002729077638321 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(-45.75,0 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(-47.89605740611995,16.05354942657371 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonMethod.newton(-50.25484933409115,-99.37231225508572 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonMethod.newton(-60.14973269088926,0 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonMethod.newton(665.649354872653,0 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonMethod.newton(-80.75,4.181144878546872 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonMethod.newton(87.84279458137019,0 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonMethod.newton(-89.25000000000001,1.4210854715202004E-14 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonMethod.newton(89.54445780911536,0 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonMethod.newton(-98.4038175795464,0.18731378387623465 ) ;
  }
}
