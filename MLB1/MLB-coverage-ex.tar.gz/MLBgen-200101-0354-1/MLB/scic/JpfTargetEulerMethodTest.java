import org.junit.Test;

public class JpfTargetEulerMethodTest {

  @Test
  public void test0() {
    scic.EulerMethod.euler(-16.839684181997143 ) ;
  }

  @Test
  public void test1() {
    scic.EulerMethod.euler(-1.9946221946070202 ) ;
  }

  @Test
  public void test2() {
    scic.EulerMethod.euler(-47.78627588705808 ) ;
  }
}
