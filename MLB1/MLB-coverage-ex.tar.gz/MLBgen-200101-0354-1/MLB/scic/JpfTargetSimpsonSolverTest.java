import org.junit.Test;

public class JpfTargetSimpsonSolverTest {

  @Test
  public void test0() {
    scic.SimpsonSolver.simpson(-39.79847417533544,10.917068668929565 ) ;
  }

  @Test
  public void test1() {
    scic.SimpsonSolver.simpson(-44.03155752077258,100.0 ) ;
  }

  @Test
  public void test2() {
    scic.SimpsonSolver.simpson(-69.03236119495114,-76.99721225748766 ) ;
  }
}
