import org.junit.Test;

public class JpfTargetCubedRootTest {

  @Test
  public void test0() {
    scic.CubedRoot.check(24.99854013611914 ) ;
  }

  @Test
  public void test1() {
    scic.CubedRoot.check(6.231990563615113 ) ;
  }

  @Test
  public void test2() {
    scic.CubedRoot.check(65.05871584019087 ) ;
  }
}
