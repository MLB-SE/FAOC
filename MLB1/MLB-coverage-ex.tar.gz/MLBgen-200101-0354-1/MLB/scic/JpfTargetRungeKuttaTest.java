import org.junit.Test;

public class JpfTargetRungeKuttaTest {

  @Test
  public void test0() {
    scic.RungeKutta.rungeKutta(2719.618133630542 ) ;
  }

  @Test
  public void test1() {
    scic.RungeKutta.rungeKutta(2727.334079172901 ) ;
  }

  @Test
  public void test2() {
    scic.RungeKutta.rungeKutta(2733.3284124639827 ) ;
  }

  @Test
  public void test3() {
    scic.RungeKutta.rungeKutta(2735.13553185614 ) ;
  }

  @Test
  public void test4() {
    scic.RungeKutta.rungeKutta(2741.002618419497 ) ;
  }

  @Test
  public void test5() {
    scic.RungeKutta.rungeKutta(2741.7281390815233 ) ;
  }

  @Test
  public void test6() {
    scic.RungeKutta.rungeKutta(2744.4779819131018 ) ;
  }

  @Test
  public void test7() {
    scic.RungeKutta.rungeKutta(40.60773658054782 ) ;
  }

  @Test
  public void test8() {
    scic.RungeKutta.rungeKutta(-43.27428151823558 ) ;
  }

  @Test
  public void test9() {
    scic.RungeKutta.rungeKutta(-57.05804284536173 ) ;
  }

  @Test
  public void test10() {
    scic.RungeKutta.rungeKutta(71.39184020305552 ) ;
  }

  @Test
  public void test11() {
    scic.RungeKutta.rungeKutta(-87.31274124951616 ) ;
  }

  @Test
  public void test12() {
    scic.RungeKutta.rungeKutta(90.45757962174542 ) ;
  }

  @Test
  public void test13() {
    scic.RungeKutta.rungeKutta(92.09149766923846 ) ;
  }

  @Test
  public void test14() {
    scic.RungeKutta.rungeKutta(-92.56903787333965 ) ;
  }

  @Test
  public void test15() {
    scic.RungeKutta.rungeKutta(92.63618519642691 ) ;
  }

  @Test
  public void test16() {
    scic.RungeKutta.rungeKutta(94.86520785063786 ) ;
  }

  @Test
  public void test17() {
    scic.RungeKutta.rungeKutta(95.90643761474169 ) ;
  }
}
