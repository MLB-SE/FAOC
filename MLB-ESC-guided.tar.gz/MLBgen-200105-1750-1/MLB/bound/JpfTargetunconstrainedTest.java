import org.junit.Test;

public class JpfTargetunconstrainedTest {

  @Test
  public void test0() {
    bound.unconstrained.solve(10,5,6,1 ) ;
  }

  @Test
  public void test1() {
    bound.unconstrained.solve(1,1,7,1 ) ;
  }

  @Test
  public void test2() {
    bound.unconstrained.solve(2,7,2,0 ) ;
  }

  @Test
  public void test3() {
    bound.unconstrained.solve(3,0,0,0 ) ;
  }

  @Test
  public void test4() {
    bound.unconstrained.solve(3,2,-230,0 ) ;
  }

  @Test
  public void test5() {
    bound.unconstrained.solve(3,2,8,863 ) ;
  }

  @Test
  public void test6() {
    bound.unconstrained.solve(3,4,6,-479 ) ;
  }

  @Test
  public void test7() {
    bound.unconstrained.solve(3,-935,0,0 ) ;
  }

  @Test
  public void test8() {
    bound.unconstrained.solve(4,10,125,0 ) ;
  }

  @Test
  public void test9() {
    bound.unconstrained.solve(4,1,7,3 ) ;
  }

  @Test
  public void test10() {
    bound.unconstrained.solve(4,2,4,7 ) ;
  }

  @Test
  public void test11() {
    bound.unconstrained.solve(4,730,0,0 ) ;
  }

  @Test
  public void test12() {
    bound.unconstrained.solve(4,8,5,6 ) ;
  }

  @Test
  public void test13() {
    bound.unconstrained.solve(531,0,0,0 ) ;
  }

  @Test
  public void test14() {
    bound.unconstrained.solve(620,0,0,0 ) ;
  }

  @Test
  public void test15() {
    bound.unconstrained.solve(6,291,0,0 ) ;
  }

  @Test
  public void test16() {
    bound.unconstrained.solve(-641,0,0,0 ) ;
  }

  @Test
  public void test17() {
    bound.unconstrained.solve(8,9,9,9 ) ;
  }

  @Test
  public void test18() {
    bound.unconstrained.solve(9,4,0,0 ) ;
  }

  @Test
  public void test19() {
    bound.unconstrained.solve(9,4,330,0 ) ;
  }

  @Test
  public void test20() {
    bound.unconstrained.solve(9,7,4,742 ) ;
  }
}
