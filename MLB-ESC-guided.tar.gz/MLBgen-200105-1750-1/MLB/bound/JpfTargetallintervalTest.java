import org.junit.Test;

public class JpfTargetallintervalTest {

  @Test
  public void test0() {
    bound.allinterval.solve(1,1,4,0 ) ;
  }

  @Test
  public void test1() {
    bound.allinterval.solve(2,0,0,0 ) ;
  }

  @Test
  public void test2() {
    bound.allinterval.solve(2,1,2,4 ) ;
  }

  @Test
  public void test3() {
    bound.allinterval.solve(2,2,777,0 ) ;
  }

  @Test
  public void test4() {
    bound.allinterval.solve(2,4,0,0 ) ;
  }

  @Test
  public void test5() {
    bound.allinterval.solve(2,4,3,884 ) ;
  }

  @Test
  public void test6() {
    bound.allinterval.solve(3,2,3,4 ) ;
  }

  @Test
  public void test7() {
    bound.allinterval.solve(3,3,4,4 ) ;
  }

  @Test
  public void test8() {
    bound.allinterval.solve(3,543,0,0 ) ;
  }

  @Test
  public void test9() {
    bound.allinterval.solve(4,1,1,-482 ) ;
  }

  @Test
  public void test10() {
    bound.allinterval.solve(4,1,2,372 ) ;
  }

  @Test
  public void test11() {
    bound.allinterval.solve(4,1,4,2 ) ;
  }

  @Test
  public void test12() {
    bound.allinterval.solve(4,-158,0,0 ) ;
  }

  @Test
  public void test13() {
    bound.allinterval.solve(4,290,0,0 ) ;
  }

  @Test
  public void test14() {
    bound.allinterval.solve(4,3,4,1 ) ;
  }

  @Test
  public void test15() {
    bound.allinterval.solve(4,4,-245,0 ) ;
  }

  @Test
  public void test16() {
    bound.allinterval.solve(4,4,957,0 ) ;
  }

  @Test
  public void test17() {
    bound.allinterval.solve(-484,0,0,0 ) ;
  }

  @Test
  public void test18() {
    bound.allinterval.solve(693,0,0,0 ) ;
  }

  @Test
  public void test19() {
    bound.allinterval.solve(805,0,0,0 ) ;
  }
}
