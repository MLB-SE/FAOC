import org.junit.Test;

public class JpfTargetgroceryTest {

  @Test
  public void test0() {
    bound.grocery.solve(119,191,94,307 ) ;
  }

  @Test
  public void test1() {
    bound.grocery.solve(119,59,532,1 ) ;
  }

  @Test
  public void test2() {
    bound.grocery.solve(176,513,904,0 ) ;
  }

  @Test
  public void test3() {
    bound.grocery.solve(204,233,120,154 ) ;
  }

  @Test
  public void test4() {
    bound.grocery.solve(211,0,0,0 ) ;
  }

  @Test
  public void test5() {
    bound.grocery.solve(245,692,446,307 ) ;
  }

  @Test
  public void test6() {
    bound.grocery.solve(-249,0,0,0 ) ;
  }

  @Test
  public void test7() {
    bound.grocery.solve(249,542,701,0 ) ;
  }

  @Test
  public void test8() {
    bound.grocery.solve(307,372,4,28 ) ;
  }

  @Test
  public void test9() {
    bound.grocery.solve(317,390,986,0 ) ;
  }

  @Test
  public void test10() {
    bound.grocery.solve(318,53,621,400 ) ;
  }

  @Test
  public void test11() {
    bound.grocery.solve(326,51,326,8 ) ;
  }

  @Test
  public void test12() {
    bound.grocery.solve(333,8,520,376 ) ;
  }

  @Test
  public void test13() {
    bound.grocery.solve(345,0,0,0 ) ;
  }

  @Test
  public void test14() {
    bound.grocery.solve(379,254,684,-319 ) ;
  }

  @Test
  public void test15() {
    bound.grocery.solve(38,117,358,198 ) ;
  }

  @Test
  public void test16() {
    bound.grocery.solve(48,10,193,460 ) ;
  }

  @Test
  public void test17() {
    bound.grocery.solve(498,743,0,0 ) ;
  }

  @Test
  public void test18() {
    bound.grocery.solve(54,40,608,9 ) ;
  }

  @Test
  public void test19() {
    bound.grocery.solve(578,106,7,20 ) ;
  }

  @Test
  public void test20() {
    bound.grocery.solve(610,1510,0,0 ) ;
  }

  @Test
  public void test21() {
    bound.grocery.solve(612,28,0,0 ) ;
  }

  @Test
  public void test22() {
    bound.grocery.solve(6,196,-477,0 ) ;
  }

  @Test
  public void test23() {
    bound.grocery.solve(666,579,437,725 ) ;
  }

  @Test
  public void test24() {
    bound.grocery.solve(683,-576,0,0 ) ;
  }

  @Test
  public void test25() {
    bound.grocery.solve(785,0,0,0 ) ;
  }
}
