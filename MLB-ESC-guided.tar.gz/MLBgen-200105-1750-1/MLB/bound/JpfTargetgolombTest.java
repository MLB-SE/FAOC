import org.junit.Test;

public class JpfTargetgolombTest {

  @Test
  public void test0() {
    bound.golomb.solve(0,0,0 ) ;
  }

  @Test
  public void test1() {
    bound.golomb.solve(0,0,2 ) ;
  }

  @Test
  public void test2() {
    bound.golomb.solve(0,0,3 ) ;
  }

  @Test
  public void test3() {
    bound.golomb.solve(0,0,481 ) ;
  }

  @Test
  public void test4() {
    bound.golomb.solve(0,1,2 ) ;
  }

  @Test
  public void test5() {
    bound.golomb.solve(0,3,3 ) ;
  }

  @Test
  public void test6() {
    bound.golomb.solve(0,6,0 ) ;
  }

  @Test
  public void test7() {
    bound.golomb.solve(0,6,3 ) ;
  }

  @Test
  public void test8() {
    bound.golomb.solve(1,2,0 ) ;
  }

  @Test
  public void test9() {
    bound.golomb.solve(1,2,3 ) ;
  }

  @Test
  public void test10() {
    bound.golomb.solve(-133,0,0 ) ;
  }

  @Test
  public void test11() {
    bound.golomb.solve(1,3,6 ) ;
  }

  @Test
  public void test12() {
    bound.golomb.solve(1,4,5 ) ;
  }

  @Test
  public void test13() {
    bound.golomb.solve(1,5,4 ) ;
  }

  @Test
  public void test14() {
    bound.golomb.solve(1,5,6 ) ;
  }

  @Test
  public void test15() {
    bound.golomb.solve(2,2,2 ) ;
  }

  @Test
  public void test16() {
    bound.golomb.solve(2,3,3 ) ;
  }

  @Test
  public void test17() {
    bound.golomb.solve(2,3,-423 ) ;
  }

  @Test
  public void test18() {
    bound.golomb.solve(280,0,0 ) ;
  }

  @Test
  public void test19() {
    bound.golomb.solve(3,1,1 ) ;
  }

  @Test
  public void test20() {
    bound.golomb.solve(3,145,0 ) ;
  }

  @Test
  public void test21() {
    bound.golomb.solve(3,1,5 ) ;
  }

  @Test
  public void test22() {
    bound.golomb.solve(3,-748,0 ) ;
  }

  @Test
  public void test23() {
    bound.golomb.solve(4,0,0 ) ;
  }

  @Test
  public void test24() {
    bound.golomb.solve(4,2,517 ) ;
  }

  @Test
  public void test25() {
    bound.golomb.solve(4,5,6 ) ;
  }

  @Test
  public void test26() {
    bound.golomb.solve(6,106,0 ) ;
  }

  @Test
  public void test27() {
    bound.golomb.solve(769,0,0 ) ;
  }
}
