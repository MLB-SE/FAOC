import org.junit.Test;

public class JpfTargetCollision3Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision3(-25981,-117 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision3(37385,261 ) ;
  }

  @Test
  public void test2() {
    EffectiveJavaHashCode.testCollision3(521,196 ) ;
  }
}
