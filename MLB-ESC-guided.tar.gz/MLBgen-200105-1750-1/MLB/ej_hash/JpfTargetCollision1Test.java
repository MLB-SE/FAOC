import org.junit.Test;

public class JpfTargetCollision1Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision1(-108,662,535,-112,834,-953 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision1(834,-789,-276,-515,-240,400 ) ;
  }
}
