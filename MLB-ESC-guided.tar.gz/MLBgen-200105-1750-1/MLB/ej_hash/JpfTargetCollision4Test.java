import org.junit.Test;

public class JpfTargetCollision4Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision4(-26024,705,46 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision4(-36890,624,641 ) ;
  }

  @Test
  public void test2() {
    EffectiveJavaHashCode.testCollision4(-52288,312,-1034 ) ;
  }

  @Test
  public void test3() {
    EffectiveJavaHashCode.testCollision4(-836,180,123 ) ;
  }
}
