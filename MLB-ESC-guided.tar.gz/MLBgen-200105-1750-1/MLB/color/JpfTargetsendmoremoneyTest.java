import org.junit.Test;

public class JpfTargetsendmoremoneyTest {

  @Test
  public void test0() {
    color.sendmoremoney.solve(1,10,2,-1,-10,8,35,1229 ) ;
  }

  @Test
  public void test1() {
    color.sendmoremoney.solve(-1,16,4,8,2,1345,0,0 ) ;
  }

  @Test
  public void test2() {
    color.sendmoremoney.solve(13,2,9,3,5,6,1190,0 ) ;
  }

  @Test
  public void test3() {
    color.sendmoremoney.solve(1,3,3,1,2,3,0,0 ) ;
  }

  @Test
  public void test4() {
    color.sendmoremoney.solve(1,5,468,0,0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    color.sendmoremoney.solve(1,5,-890,0,0,0,0,0 ) ;
  }

  @Test
  public void test6() {
    color.sendmoremoney.solve(16,-1,5,22,18,-20,-4,2 ) ;
  }

  @Test
  public void test7() {
    color.sendmoremoney.solve(1,9,1,9,1,1,7,2 ) ;
  }

  @Test
  public void test8() {
    color.sendmoremoney.solve(2,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test9() {
    color.sendmoremoney.solve(23,-42,8,8,5,-13,5,16 ) ;
  }

  @Test
  public void test10() {
    color.sendmoremoney.solve(2,5,4,-520,0,0,0,0 ) ;
  }

  @Test
  public void test11() {
    color.sendmoremoney.solve(-25,5,-7,-11,1,9,4,-48 ) ;
  }

  @Test
  public void test12() {
    color.sendmoremoney.solve(2,5,6,1,-4,11,55,-8 ) ;
  }

  @Test
  public void test13() {
    color.sendmoremoney.solve(2,7,0,4,73,0,0,0 ) ;
  }

  @Test
  public void test14() {
    color.sendmoremoney.solve(2,7,3,0,8,6,820,0 ) ;
  }

  @Test
  public void test15() {
    color.sendmoremoney.solve(2,-756,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test16() {
    color.sendmoremoney.solve(2,9,8,0,9,11,2,0 ) ;
  }

  @Test
  public void test17() {
    color.sendmoremoney.solve(3,1,3,0,4,-847,0,0 ) ;
  }

  @Test
  public void test18() {
    color.sendmoremoney.solve(3,1,9,8,3,4,7,0 ) ;
  }

  @Test
  public void test19() {
    color.sendmoremoney.solve(3,3,4,4,-229,0,0,0 ) ;
  }

  @Test
  public void test20() {
    color.sendmoremoney.solve(3,507,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test21() {
    color.sendmoremoney.solve(4,0,8,1,0,0,0,0 ) ;
  }

  @Test
  public void test22() {
    color.sendmoremoney.solve(4,2,0,4,4,615,0,0 ) ;
  }

  @Test
  public void test23() {
    color.sendmoremoney.solve(4,4,1,6,8,-1,7,0 ) ;
  }

  @Test
  public void test24() {
    color.sendmoremoney.solve(459,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test25() {
    color.sendmoremoney.solve(4,6,6,185,0,0,0,0 ) ;
  }

  @Test
  public void test26() {
    color.sendmoremoney.solve(4,9,5,9,6,0,0,0 ) ;
  }

  @Test
  public void test27() {
    color.sendmoremoney.solve(5,0,71,0,0,0,0,0 ) ;
  }

  @Test
  public void test28() {
    color.sendmoremoney.solve(5,1,3,9,9,1,9,3388 ) ;
  }

  @Test
  public void test29() {
    color.sendmoremoney.solve(5,1,7,3,6,14,-596,0 ) ;
  }

  @Test
  public void test30() {
    color.sendmoremoney.solve(5,2,8,17,9,0,6,1834 ) ;
  }

  @Test
  public void test31() {
    color.sendmoremoney.solve(5,3,3,12,1,3,18,2 ) ;
  }

  @Test
  public void test32() {
    color.sendmoremoney.solve(5,4,6,1,8,4,8,6 ) ;
  }

  @Test
  public void test33() {
    color.sendmoremoney.solve(5,5,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test34() {
    color.sendmoremoney.solve(6,1,2,1,9,6,0,-2088 ) ;
  }

  @Test
  public void test35() {
    color.sendmoremoney.solve(6,26,21,5,-1,12,3,-6 ) ;
  }

  @Test
  public void test36() {
    color.sendmoremoney.solve(6,9,6,9,1,0,9,0 ) ;
  }

  @Test
  public void test37() {
    color.sendmoremoney.solve(7,0,-3,4,21,0,-17,-586 ) ;
  }

  @Test
  public void test38() {
    color.sendmoremoney.solve(7,2,7,66,0,0,0,0 ) ;
  }

  @Test
  public void test39() {
    color.sendmoremoney.solve(7,3,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test40() {
    color.sendmoremoney.solve(7,347,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test41() {
    color.sendmoremoney.solve(7,7,0,9,1,0,9,0 ) ;
  }

  @Test
  public void test42() {
    color.sendmoremoney.solve(7,7,15,-1,14,3,15,12 ) ;
  }

  @Test
  public void test43() {
    color.sendmoremoney.solve(7,9,-1,-1,3,-4,8,1 ) ;
  }

  @Test
  public void test44() {
    color.sendmoremoney.solve(8,1,8,4,189,0,0,0 ) ;
  }

  @Test
  public void test45() {
    color.sendmoremoney.solve(8,-2,10,0,11,-14,9,18 ) ;
  }

  @Test
  public void test46() {
    color.sendmoremoney.solve(8,2,5,6,5,7,6,1 ) ;
  }

  @Test
  public void test47() {
    color.sendmoremoney.solve(8,2,6,6,5,9,2,1044 ) ;
  }

  @Test
  public void test48() {
    color.sendmoremoney.solve(8,5,3,15,1,6,0,8 ) ;
  }

  @Test
  public void test49() {
    color.sendmoremoney.solve(8,5,6,1,8,9,813,0 ) ;
  }

  @Test
  public void test50() {
    color.sendmoremoney.solve(8,7,0,5,6,3,1,8 ) ;
  }

  @Test
  public void test51() {
    color.sendmoremoney.solve(88,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test52() {
    color.sendmoremoney.solve(8,8,0,9,1,0,9,0 ) ;
  }

  @Test
  public void test53() {
    color.sendmoremoney.solve(8,9,0,9,1,0,9,0 ) ;
  }

  @Test
  public void test54() {
    color.sendmoremoney.solve(8,9,0,9,1,1,5,0 ) ;
  }

  @Test
  public void test55() {
    color.sendmoremoney.solve(8,9,1,5,1,0,9,2 ) ;
  }

  @Test
  public void test56() {
    color.sendmoremoney.solve(8,9,3,9,3,2,-797,0 ) ;
  }

  @Test
  public void test57() {
    color.sendmoremoney.solve(8,9,6,6,9,2552,0,0 ) ;
  }

  @Test
  public void test58() {
    color.sendmoremoney.solve(8,9,8,9,1,0,9,0 ) ;
  }

  @Test
  public void test59() {
    color.sendmoremoney.solve(9,0,9,9,1,10,7,-3 ) ;
  }

  @Test
  public void test60() {
    color.sendmoremoney.solve(9,-2,1,3,9,1,166,0 ) ;
  }

  @Test
  public void test61() {
    color.sendmoremoney.solve(-93,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test62() {
    color.sendmoremoney.solve(9,3,4,9,1,0,8,2 ) ;
  }

  @Test
  public void test63() {
    color.sendmoremoney.solve(9,7,7,9,3,-5,8,6 ) ;
  }

  @Test
  public void test64() {
    color.sendmoremoney.solve(9,8,1,5,1,1,2,2 ) ;
  }

  @Test
  public void test65() {
    color.sendmoremoney.solve(9,8,3,1,2,-5,4,4 ) ;
  }

  @Test
  public void test66() {
    color.sendmoremoney.solve(9,9,0,3,1,1,8,2 ) ;
  }

  @Test
  public void test67() {
    color.sendmoremoney.solve(9,9,0,8,1,2,7,2 ) ;
  }

  @Test
  public void test68() {
    color.sendmoremoney.solve(9,9,0,9,1,1,7,0 ) ;
  }
}
