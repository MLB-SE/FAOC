import org.junit.Test;

public class JpfTargetlaplaceTest {

  @Test
  public void test0() {
    color.laplace.solve(0.14353733f,-0.48528242f,9.004249f,0.035343f,-0.016846566f,0.3591881f,0.014677344f,0.023366379f,0.09563829f ) ;
  }

  @Test
  public void test1() {
    color.laplace.solve(0.190564f,-99.99997f,87.823875f,0.7622289f,-13.556789f,35.48319f,16.41514f,9.5274f,67.66566f ) ;
  }

  @Test
  public void test2() {
    color.laplace.solve(-0.46158946f,-86.13452f,-81.7889f,-15.711835f,65.40698f,0f,20.018383f,95.78536f,-64.66271f ) ;
  }

  @Test
  public void test3() {
    color.laplace.solve(0.7160738f,80.01604f,-5.777572f,11.89322f,37.919296f,35.911118f,8.93751f,23.85682f,53.93187f ) ;
  }

  @Test
  public void test4() {
    color.laplace.solve(-100.0f,50.891804f,0f,82.514084f,66.36239f,-18.28834f,30.21232f,38.335194f,56.766068f ) ;
  }

  @Test
  public void test5() {
    color.laplace.solve(-100.0f,-82.58707f,0f,-25.246527f,6.4818873f,37.6522f,-7.4679947f,-4.625452f,-17.515701f ) ;
  }

  @Test
  public void test6() {
    color.laplace.solve(-100.0f,92.68138f,100.0f,-2.4519672f,24.061382f,-77.328735f,66.13075f,83.34485f,-77.95498f ) ;
  }

  @Test
  public void test7() {
    color.laplace.solve(10.446292f,-48.260216f,58.93115f,-9.954616f,99.80833f,0f,54.450413f,0f,0f ) ;
  }

  @Test
  public void test8() {
    color.laplace.solve(10.97213f,-47.890556f,-99.98397f,-8.237107f,-37.64268f,-77.56989f,-6.27788f,-16.889359f,-23.646269f ) ;
  }

  @Test
  public void test9() {
    color.laplace.solve(-1.1045891f,-31.71632f,-28.505701f,-73.455055f,-197.99683f,-523.94257f,-24.407194f,-24.195732f,26.632751f ) ;
  }

  @Test
  public void test10() {
    color.laplace.solve(11.059991f,19.863476f,100.0f,-1.2270572f,-15.847461f,-82.77028f,-0.12075904f,0.74402106f,18.944304f ) ;
  }

  @Test
  public void test11() {
    color.laplace.solve(11.14898f,63.34133f,-61.86994f,6.535943f,28.83797f,-0.75368106f,-13.843179f,46.22829f,30.017244f ) ;
  }

  @Test
  public void test12() {
    color.laplace.solve(11.568426f,-45.20626f,-45.83317f,-8.520035f,-33.26374f,-38.30939f,-12.384826f,-41.019268f,-74.14065f ) ;
  }

  @Test
  public void test13() {
    color.laplace.solve(-11.569144f,-33.97955f,0f,43.369137f,58.8877f,0f,38.259613f,64.68505f,0f ) ;
  }

  @Test
  public void test14() {
    color.laplace.solve(11.680599f,19.309053f,44.699623f,-72.586655f,-79.14401f,59.489445f,-23.076784f,-19.720482f,23.338865f ) ;
  }

  @Test
  public void test15() {
    color.laplace.solve(11.732198f,-52.904556f,43.70324f,-0.16665491f,-11.7312155f,8.650385f,-0.6676017f,-2.5040362f,2.3826725f ) ;
  }

  @Test
  public void test16() {
    color.laplace.solve(11.884403f,-44.20931f,-49.18065f,-8.253081f,-31.774567f,30.267763f,-13.122161f,-44.23556f,0f ) ;
  }

  @Test
  public void test17() {
    color.laplace.solve(-11.950476f,-20.591753f,0f,14.054796f,67.885284f,0f,11.6290045f,32.46122f,0f ) ;
  }

  @Test
  public void test18() {
    color.laplace.solve(11.962077f,-26.577522f,27.244652f,5.6186357f,4.7733293f,22.71429f,5.739137f,17.337912f,58.839184f ) ;
  }

  @Test
  public void test19() {
    color.laplace.solve(11.975866f,-57.613216f,-100.0f,5.5166802f,-9.575853f,18.566046f,19.666708f,-4.7729216f,-100.0f ) ;
  }

  @Test
  public void test20() {
    color.laplace.solve(12.000771f,-47.488895f,100.0f,-4.5080223f,-19.649086f,10.427639f,-10.383772f,-37.027065f,-99.99955f ) ;
  }

  @Test
  public void test21() {
    color.laplace.solve(-1.2105255f,-23.388372f,0f,7.495421f,27.598495f,-21.577307f,3.5937142f,6.8794355f,-3.6744678f ) ;
  }

  @Test
  public void test22() {
    color.laplace.solve(12.243519f,-53.343815f,-5.7269344f,2.3178928f,-2.1127787f,-8.548335f,-0.859169f,-5.754569f,41.71559f ) ;
  }

  @Test
  public void test23() {
    color.laplace.solve(-1.2370404f,-99.38684f,-8.17352f,-5.5613174f,-22.284021f,5.1475945f,1.2757914f,10.664483f,51.047916f ) ;
  }

  @Test
  public void test24() {
    color.laplace.solve(-12.392976f,29.85125f,0f,-23.90528f,-8.116425f,75.53933f,-75.11172f,17.945866f,0f ) ;
  }

  @Test
  public void test25() {
    color.laplace.solve(12.445904f,-80.90411f,-67.37558f,30.687729f,94.20624f,100.0f,16.098772f,33.70736f,-50.860134f ) ;
  }

  @Test
  public void test26() {
    color.laplace.solve(12.557498f,-36.96719f,100.0f,-12.802816f,-59.710526f,100.0f,-4.0582356f,-3.4301267f,47.090057f ) ;
  }

  @Test
  public void test27() {
    color.laplace.solve(12.584559f,-63.251095f,23.499664f,13.589335f,-5.19861f,0f,-7.7388635f,-44.54479f,0.71577096f ) ;
  }

  @Test
  public void test28() {
    color.laplace.solve(12.6511755f,-47.83633f,-15.4090805f,-1.1608094f,-15.7071905f,-8.643544f,-1.5872222f,-5.18808f,-3.457906f ) ;
  }

  @Test
  public void test29() {
    color.laplace.solve(12.75421f,40.96559f,100.0f,-89.94875f,-48.891846f,6.3943915f,-27.247084f,-19.039587f,0f ) ;
  }

  @Test
  public void test30() {
    color.laplace.solve(12.758512f,0.910426f,17.349344f,6.479213f,10.194455f,28.011835f,2.9638903f,5.3763475f,8.347046f ) ;
  }

  @Test
  public void test31() {
    color.laplace.solve(-132.4862f,-37.04973f,166.46707f,-28.282288f,14.611831f,82.89405f,3.0279446f,40.866135f,93.94366f ) ;
  }

  @Test
  public void test32() {
    color.laplace.solve(13.267935f,-48.181652f,-11.199432f,1.2533932f,-10.476871f,-2.6158648f,2.2225084f,7.6366405f,38.800926f ) ;
  }

  @Test
  public void test33() {
    color.laplace.solve(13.312457f,-55.888626f,-59.73315f,9.138457f,18.69481f,27.133963f,4.5465603f,9.047785f,12.949768f ) ;
  }

  @Test
  public void test34() {
    color.laplace.solve(13.326369f,-40.58015f,74.94323f,-6.1143723f,-36.464428f,-99.999825f,-1.3194325f,0.8366422f,41.13043f ) ;
  }

  @Test
  public void test35() {
    color.laplace.solve(13.555632f,-35.951313f,5.4434676f,-9.826161f,-32.895054f,-15.769332f,-19.964891f,-70.03341f,-35.62534f ) ;
  }

  @Test
  public void test36() {
    color.laplace.solve(13.624693f,-37.488922f,-100.0f,-8.012304f,-38.44102f,-87.3436f,-7.2328897f,-20.919254f,-38.00311f ) ;
  }

  @Test
  public void test37() {
    color.laplace.solve(-136.62468f,16.16717f,13.994341f,-33.08365f,4.0784574f,-2.1106646f,0.25429383f,35.02876f,-82.40154f ) ;
  }

  @Test
  public void test38() {
    color.laplace.solve(13.717286f,7.136405f,1.7869477f,-52.26726f,-86.95861f,-99.98862f,-30.828299f,68.25847f,0f ) ;
  }

  @Test
  public void test39() {
    color.laplace.solve(-1.3991218f,-99.664696f,-99.99282f,-5.931785f,-21.765566f,10.619693f,-0.56245244f,3.6819773f,37.055927f ) ;
  }

  @Test
  public void test40() {
    color.laplace.solve(14.200234f,22.716211f,13.8050995f,-65.915276f,-37.140488f,5.422581f,40.03625f,0f,0f ) ;
  }

  @Test
  public void test41() {
    color.laplace.solve(14.314127f,9.0153885f,-62.926838f,-51.75888f,100.0f,0f,100.0f,-69.5856f,0f ) ;
  }

  @Test
  public void test42() {
    color.laplace.solve(1.4330492f,-82.48216f,-25.887506f,-11.785643f,-38.606762f,-32.069454f,-9.968859f,-28.08979f,-63.783543f ) ;
  }

  @Test
  public void test43() {
    color.laplace.solve(14.345731f,43.496044f,0f,83.3744f,-14.473593f,100.0f,22.675262f,7.32665f,21.104933f ) ;
  }

  @Test
  public void test44() {
    color.laplace.solve(14.637078f,-43.033936f,45.325996f,1.582249f,-8.312538f,9.765961f,0.004456158f,-1.5644244f,2.050384f ) ;
  }

  @Test
  public void test45() {
    color.laplace.solve(1.4646833f,5.858733f,2.85985f,-100.0f,-80.8896f,-94.419334f,-1.2291017f,95.083595f,100.0f ) ;
  }

  @Test
  public void test46() {
    color.laplace.solve(14.9786825f,-34.12643f,89.45249f,-5.95884f,-35.605576f,-95.462006f,-3.208466f,-6.8750243f,-13.500053f ) ;
  }

  @Test
  public void test47() {
    color.laplace.solve(15.015119f,14.844556f,-10.206015f,2.1214483f,-3.4409082f,-16.254519f,-3.0884175f,-14.475119f,-51.371147f ) ;
  }

  @Test
  public void test48() {
    color.laplace.solve(15.181361f,81.39489f,-99.99979f,10.947158f,23.722807f,-6.0415106f,4.884462f,8.59069f,5.7554903f ) ;
  }

  @Test
  public void test49() {
    color.laplace.solve(15.751233f,-41.526695f,-213.35661f,4.2993503f,-68.07836f,-112.67083f,-5.6436787f,-27.052282f,-34.93132f ) ;
  }

  @Test
  public void test50() {
    color.laplace.solve(15.771691f,-58.682564f,-59.887077f,21.769327f,65.8896f,-100.0f,5.4160175f,-0.10525745f,-71.72665f ) ;
  }

  @Test
  public void test51() {
    color.laplace.solve(15.954909f,-38.583603f,99.97523f,2.4032428f,-0.6057756f,59.105145f,-5.7361617f,-25.34789f,-99.9748f ) ;
  }

  @Test
  public void test52() {
    color.laplace.solve(16.017899f,-98.46513f,28.415585f,62.536728f,61.38979f,0f,-9.776203f,18.790535f,0f ) ;
  }

  @Test
  public void test53() {
    color.laplace.solve(16.208925f,-30.288778f,-172.58553f,-4.8754725f,-64.7631f,-182.38756f,29.049572f,-41.50154f,32.380836f ) ;
  }

  @Test
  public void test54() {
    color.laplace.solve(16.334639f,-47.47296f,-66.19089f,12.811514f,-26.321854f,-20.239395f,61.23327f,-50.38657f,-49.370556f ) ;
  }

  @Test
  public void test55() {
    color.laplace.solve(16.342627f,22.344156f,66.00105f,-56.973648f,-92.6362f,42.434326f,-22.019873f,-31.105846f,-9.767315f ) ;
  }

  @Test
  public void test56() {
    color.laplace.solve(16.444141f,-15.243825f,-99.99838f,-18.979609f,-77.42106f,99.29959f,-14.941518f,-40.78646f,-70.783264f ) ;
  }

  @Test
  public void test57() {
    color.laplace.solve(16.53603f,-41.886436f,-32.199444f,8.030568f,5.836353f,26.232296f,9.749888f,30.968985f,100.0f ) ;
  }

  @Test
  public void test58() {
    color.laplace.solve(16.596264f,-85.997826f,0.17077385f,52.382885f,-76.47036f,0f,19.673306f,24.5626f,0f ) ;
  }

  @Test
  public void test59() {
    color.laplace.solve(16.777855f,-30.170952f,-81.70895f,-2.717625f,-25.067892f,-3.4699793f,-2.580463f,-7.6042266f,-2.7685516f ) ;
  }

  @Test
  public void test60() {
    color.laplace.solve(17.027725f,-32.91251f,-15.254452f,1.0234134f,-12.097033f,-12.12746f,-0.83704007f,-4.371574f,-4.5522223f ) ;
  }

  @Test
  public void test61() {
    color.laplace.solve(1.7117276f,-85.01476f,12.800219f,-8.138329f,-27.899664f,-1.1223767f,-6.3653793f,-17.323189f,10.609939f ) ;
  }

  @Test
  public void test62() {
    color.laplace.solve(17.233793f,22.676678f,13.672187f,-53.741505f,-40.199272f,-67.98793f,-16.998583f,-14.25283f,0.18653934f ) ;
  }

  @Test
  public void test63() {
    color.laplace.solve(17.32568f,33.903275f,10.534495f,-64.600555f,7.752925f,-91.76529f,-19.252583f,-12.409779f,-38.139458f ) ;
  }

  @Test
  public void test64() {
    color.laplace.solve(17.332567f,-29.129128f,22.794016f,-1.5406033f,-17.35967f,-15.768309f,-6.135311f,-23.00064f,-68.50758f ) ;
  }

  @Test
  public void test65() {
    color.laplace.solve(17.36779f,-34.262806f,-2.5507555f,3.7339656f,-3.40829f,16.465084f,1.0455233f,0.4481276f,4.2275357f ) ;
  }

  @Test
  public void test66() {
    color.laplace.solve(17.449215f,-31.230402f,-42.765274f,1.0272615f,-12.453048f,-15.030077f,-0.8879468f,-4.5790486f,-4.9022627f ) ;
  }

  @Test
  public void test67() {
    color.laplace.solve(17.77375f,-31.675379f,-100.0f,2.770376f,-13.212078f,-47.252266f,6.5198326f,23.308954f,99.92806f ) ;
  }

  @Test
  public void test68() {
    color.laplace.solve(17.95755f,-27.504208f,8.585999f,-0.6655905f,-20.21102f,67.929955f,-0.4088926f,-0.96997994f,16.739992f ) ;
  }

  @Test
  public void test69() {
    color.laplace.solve(17.960743f,11.898069f,-45.063408f,-40.0551f,-34.358166f,0f,-1.5271798f,33.94638f,-55.704124f ) ;
  }

  @Test
  public void test70() {
    color.laplace.solve(18.02246f,-36.70637f,97.88346f,8.792446f,12.649799f,69.309975f,4.497525f,9.199058f,19.627258f ) ;
  }

  @Test
  public void test71() {
    color.laplace.solve(18.03473f,-53.63499f,99.99762f,25.773912f,76.15288f,99.99996f,8.908038f,9.858241f,-45.627953f ) ;
  }

  @Test
  public void test72() {
    color.laplace.solve(18.169382f,-8.132846f,35.33673f,-19.138468f,-185.40395f,-53.970158f,-18.500233f,-54.862465f,208.17212f ) ;
  }

  @Test
  public void test73() {
    color.laplace.solve(18.323416f,24.74149f,46.951412f,-51.44783f,-76.23942f,0f,-21.656301f,-35.17738f,0f ) ;
  }

  @Test
  public void test74() {
    color.laplace.solve(18.379023f,-5.150264f,-86.38225f,-21.333647f,-52.59783f,99.60005f,-7.6927853f,-9.437494f,22.54064f ) ;
  }

  @Test
  public void test75() {
    color.laplace.solve(18.484596f,-30.1345f,96.700066f,4.0728855f,-9.306244f,-35.543797f,7.118605f,24.380432f,99.709366f ) ;
  }

  @Test
  public void test76() {
    color.laplace.solve(1.863139f,-84.16534f,-69.28914f,-8.382108f,-34.06395f,-83.30788f,-1.3276236f,39.59953f,29.739359f ) ;
  }

  @Test
  public void test77() {
    color.laplace.solve(18.64447f,-39.92658f,-70.99311f,14.504455f,60.741703f,66.54923f,-21.368355f,-99.977875f,0f ) ;
  }

  @Test
  public void test78() {
    color.laplace.solve(-18.860914f,8.039609f,0f,-8.364419f,-9.674573f,-1.6506366f,-4.9221873f,-11.324331f,71.021324f ) ;
  }

  @Test
  public void test79() {
    color.laplace.solve(18.861294f,51.013912f,-55.21802f,-75.56873f,63.12584f,0f,-15.7856f,0f,0f ) ;
  }

  @Test
  public void test80() {
    color.laplace.solve(-18.908981f,15.868421f,0f,-9.818037f,-25.868395f,-53.692024f,5.5052276f,31.838947f,0f ) ;
  }

  @Test
  public void test81() {
    color.laplace.solve(18.95675f,-29.778368f,-82.68185f,5.6053686f,1.3827134f,26.981182f,2.08201f,2.7226717f,7.4259634f ) ;
  }

  @Test
  public void test82() {
    color.laplace.solve(18.970549f,5.8928413f,-2.43329f,-30.010723f,-93.04304f,-189.00957f,-47.104515f,-158.47202f,-12.739574f ) ;
  }

  @Test
  public void test83() {
    color.laplace.solve(19.030666f,-28.47381f,58.186382f,4.5963373f,-2.0021527f,15.037875f,1.3568351f,0.83094263f,3.9672048f ) ;
  }

  @Test
  public void test84() {
    color.laplace.solve(19.312767f,-24.75278f,-27.9738f,2.0038488f,-10.323825f,-12.648224f,-0.97357947f,-5.898168f,-12.295267f ) ;
  }

  @Test
  public void test85() {
    color.laplace.solve(19.398094f,-26.077448f,13.602966f,3.6698227f,-4.115594f,12.02791f,-0.6032092f,-6.0826592f,-3.0948067f ) ;
  }

  @Test
  public void test86() {
    color.laplace.solve(19.429913f,27.940899f,63.254723f,-50.22125f,-70.92104f,74.224945f,-20.055485f,-30.000692f,-29.026241f ) ;
  }

  @Test
  public void test87() {
    color.laplace.solve(19.433083f,-24.453897f,92.589455f,2.1862254f,-7.6702604f,5.8445363f,-3.0179203f,-14.257906f,-39.033894f ) ;
  }

  @Test
  public void test88() {
    color.laplace.solve(19.512878f,-46.507095f,65.00379f,24.55861f,71.77792f,10.660501f,6.9436364f,-70.88207f,0f ) ;
  }

  @Test
  public void test89() {
    color.laplace.solve(-19.529737f,-100.0f,24.80549f,-78.11895f,100.0f,26.389492f,-13.310621f,24.876467f,12.81649f ) ;
  }

  @Test
  public void test90() {
    color.laplace.solve(19.693188f,4.6017327f,17.317125f,-25.981243f,-118.646904f,-35.261364f,-4.8446445f,6.5961475f,59.743668f ) ;
  }

  @Test
  public void test91() {
    color.laplace.solve(19.70955f,36.860523f,47.955734f,-58.022316f,-20.223198f,45.513626f,-16.173462f,-6.6715345f,9.710523f ) ;
  }

  @Test
  public void test92() {
    color.laplace.solve(-19.74106f,-89.847115f,0f,-89.11712f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test93() {
    color.laplace.solve(-19.987661f,41.21394f,-58.06581f,-3.7072763f,5.9755363f,-14.043874f,-0.8169799f,0.43935674f,-3.4011292f ) ;
  }

  @Test
  public void test94() {
    color.laplace.solve(20.00956f,65.14389f,66.28597f,-85.10565f,74.280014f,100.0f,-12.66488f,34.446133f,84.82065f ) ;
  }

  @Test
  public void test95() {
    color.laplace.solve(20.039871f,-7.3492904f,-87.933174f,-12.491226f,-61.50386f,-42.66741f,-8.500915f,-21.512434f,-16.044962f ) ;
  }

  @Test
  public void test96() {
    color.laplace.solve(20.042917f,-24.15948f,37.808445f,4.331145f,-3.4132388f,7.7268887f,0.6949103f,-1.5515037f,-3.487648f ) ;
  }

  @Test
  public void test97() {
    color.laplace.solve(20.10803f,-27.795904f,96.93954f,8.228022f,7.512472f,36.67945f,5.2915854f,12.938319f,-26.161018f ) ;
  }

  @Test
  public void test98() {
    color.laplace.solve(20.285479f,-30.072453f,-201.13445f,13.84394f,-38.94441f,-80.12455f,75.01177f,-59.44028f,98.39383f ) ;
  }

  @Test
  public void test99() {
    color.laplace.solve(20.320858f,-25.493347f,8.326131f,6.776769f,1.1665797f,7.681121f,5.6196365f,15.7017765f,21.231764f ) ;
  }

  @Test
  public void test100() {
    color.laplace.solve(-2.0322409f,-96.52359f,-79.878105f,-11.6053705f,-38.04578f,-30.285694f,-6.34346f,-13.76847f,-10.684637f ) ;
  }

  @Test
  public void test101() {
    color.laplace.solve(20.447285f,22.90702f,12.540254f,-41.11788f,-41.359455f,-72.74601f,-15.267001f,-19.950123f,-23.174032f ) ;
  }

  @Test
  public void test102() {
    color.laplace.solve(-2.0511396f,83.15717f,0f,5.0081134f,16.129557f,11.302616f,5.9540377f,-34.94968f,0f ) ;
  }

  @Test
  public void test103() {
    color.laplace.solve(20.525135f,95.96552f,21.649155f,18.05528f,32.33061f,-44.104618f,19.365381f,59.406246f,-32.84702f ) ;
  }

  @Test
  public void test104() {
    color.laplace.solve(20.788713f,-85.66179f,-31.846758f,68.81664f,-58.60941f,0f,27.025679f,39.28607f,66.90044f ) ;
  }

  @Test
  public void test105() {
    color.laplace.solve(20.957829f,-16.511326f,-27.62001f,0.34263605f,-8.4719925f,27.08452f,-11.115292f,-44.803802f,40.15705f ) ;
  }

  @Test
  public void test106() {
    color.laplace.solve(20.97522f,-5.369035f,-100.0f,-10.73006f,-42.45136f,-78.66f,-21.444098f,-75.046326f,-99.999466f ) ;
  }

  @Test
  public void test107() {
    color.laplace.solve(20.975971f,5.530629f,-17.155499f,-21.15341f,-85.739296f,-291.61218f,-15.507845f,-35.424698f,-41.83455f ) ;
  }

  @Test
  public void test108() {
    color.laplace.solve(21.081467f,5.9493713f,-5.1360254f,-0.97087777f,-21.780348f,-80.332245f,-3.1846304f,-11.767644f,-22.105598f ) ;
  }

  @Test
  public void test109() {
    color.laplace.solve(21.227125f,5.386851f,-23.592966f,-16.208897f,-76.107025f,-262.857f,-11.38656f,-30.754671f,-35.688812f ) ;
  }

  @Test
  public void test110() {
    color.laplace.solve(21.39871f,-19.130114f,90.274155f,4.724952f,-1.7577031f,15.064094f,-0.7411981f,-7.6897445f,-28.260077f ) ;
  }

  @Test
  public void test111() {
    color.laplace.solve(21.549086f,38.871265f,-100.0f,5.39246f,2.2760694f,-20.745722f,-2.2553165f,-14.413726f,-57.67566f ) ;
  }

  @Test
  public void test112() {
    color.laplace.solve(21.788136f,33.64291f,52.1757f,-46.490364f,-39.392204f,67.82015f,-10.379235f,4.973423f,69.66513f ) ;
  }

  @Test
  public void test113() {
    color.laplace.solve(21.874754f,-2.561207f,-31.299068f,-9.939775f,8.477497f,-18.991644f,-70.11135f,65.40261f,-53.145f ) ;
  }

  @Test
  public void test114() {
    color.laplace.solve(21.91412f,8.054103f,5.444805f,-20.397625f,-95.14251f,-86.27488f,-8.362107f,-13.050806f,51.301395f ) ;
  }

  @Test
  public void test115() {
    color.laplace.solve(22.019392f,10.533852f,18.265633f,-22.45628f,-98.14962f,-37.471317f,-13.694893f,-32.32329f,-17.448652f ) ;
  }

  @Test
  public void test116() {
    color.laplace.solve(22.08659f,30.521482f,99.99934f,-42.175125f,-100.0f,-46.736744f,-16.843855f,-25.200293f,16.042685f ) ;
  }

  @Test
  public void test117() {
    color.laplace.solve(22.23786f,-16.913956f,88.04119f,5.865393f,-5.5401134f,-32.301807f,6.7638273f,21.189915f,-15.534971f ) ;
  }

  @Test
  public void test118() {
    color.laplace.solve(22.254868f,9.300507f,14.520032f,-20.281036f,-99.572876f,-37.055614f,-3.8061368f,5.056488f,0f ) ;
  }

  @Test
  public void test119() {
    color.laplace.solve(22.41999f,-24.833992f,-100.0f,14.513958f,26.843447f,97.0382f,8.792395f,20.65562f,46.986645f ) ;
  }

  @Test
  public void test120() {
    color.laplace.solve(22.478863f,-21.597591f,-19.137066f,11.51304f,17.942715f,70.84612f,5.630582f,11.009288f,20.463852f ) ;
  }

  @Test
  public void test121() {
    color.laplace.solve(22.483429f,55.36566f,36.671333f,-65.431946f,62.307888f,51.67333f,47.09421f,86.152374f,0f ) ;
  }

  @Test
  public void test122() {
    color.laplace.solve(22.713438f,13.365882f,30.731834f,-22.51213f,-99.98174f,21.916632f,-12.78022f,-28.608747f,-1.6730288f ) ;
  }

  @Test
  public void test123() {
    color.laplace.solve(22.748493f,23.742016f,0f,25.490389f,55.272446f,-51.43816f,23.940617f,100.0f,0f ) ;
  }

  @Test
  public void test124() {
    color.laplace.solve(22.78327f,9.990127f,-81.609825f,-18.857046f,-1.2129369f,-22.29323f,-5.7836094f,-4.277391f,-30.26931f ) ;
  }

  @Test
  public void test125() {
    color.laplace.solve(22.943712f,5.591695f,-34.019485f,-13.816844f,-66.55745f,49.838387f,-11.653645f,-32.797733f,-52.97984f ) ;
  }

  @Test
  public void test126() {
    color.laplace.solve(22.972923f,-15.662381f,7.5523715f,7.554071f,18.983875f,0f,10.432006f,97.913055f,0f ) ;
  }

  @Test
  public void test127() {
    color.laplace.solve(23.051506f,-2.9201539f,-61.832413f,-4.873824f,-39.825775f,80.03353f,-2.7210174f,-6.010245f,18.505823f ) ;
  }

  @Test
  public void test128() {
    color.laplace.solve(23.092192f,25.865988f,23.992891f,-33.497223f,-43.621128f,-29.894426f,-9.789681f,-5.6615043f,30.764791f ) ;
  }

  @Test
  public void test129() {
    color.laplace.solve(23.163174f,23.75153f,24.913858f,-30.269478f,-40.367252f,-23.098408f,-103.59139f,-133.31236f,-76.7214f ) ;
  }

  @Test
  public void test130() {
    color.laplace.solve(23.238873f,14.394657f,28.284761f,-21.439167f,-93.94501f,-1.2556101f,-15.05053f,-38.762955f,5.296857f ) ;
  }

  @Test
  public void test131() {
    color.laplace.solve(23.28127f,34.893997f,-112.25239f,-42.09573f,111.51208f,35.85536f,-4.0501876f,26.059755f,-3.021039f ) ;
  }

  @Test
  public void test132() {
    color.laplace.solve(23.310652f,-17.018654f,55.516605f,10.26126f,100.0f,-54.783894f,12.121222f,38.22363f,40.77329f ) ;
  }

  @Test
  public void test133() {
    color.laplace.solve(23.334724f,4.316985f,-60.920364f,-11.110301f,-45.442554f,-22.39888f,-22.328299f,-152.57515f,16.804365f ) ;
  }

  @Test
  public void test134() {
    color.laplace.solve(23.486235f,10.132045f,6.8221803f,-16.187103f,-89.780235f,-82.84332f,1.5455878f,16.594196f,0f ) ;
  }

  @Test
  public void test135() {
    color.laplace.solve(-23.585735f,8.503593f,0f,-14.368726f,-17.99812f,0f,-6.5982447f,-12.024253f,-23.500648f ) ;
  }

  @Test
  public void test136() {
    color.laplace.solve(23.590944f,11.606104f,22.833488f,-17.242323f,-100.0f,-20.272133f,7.439781f,47.001446f,99.54921f ) ;
  }

  @Test
  public void test137() {
    color.laplace.solve(23.642157f,-3.9496033f,-126.6551f,-1.4810791f,-12.445375f,-21.652632f,-6.9057565f,-7.753945f,-6.9678106f ) ;
  }

  @Test
  public void test138() {
    color.laplace.solve(23.651768f,-37.85043f,-100.0f,32.457504f,12.364648f,-32.32684f,93.8136f,87.17836f,-27.502823f ) ;
  }

  @Test
  public void test139() {
    color.laplace.solve(23.658684f,41.396263f,99.97395f,-46.76153f,-58.047577f,82.19032f,2.645637f,57.344078f,13.616114f ) ;
  }

  @Test
  public void test140() {
    color.laplace.solve(23.756485f,-6.4753304f,-139.01749f,1.410624f,-10.693957f,-82.84162f,-3.8672392f,-18.80518f,-59.45652f ) ;
  }

  @Test
  public void test141() {
    color.laplace.solve(23.764978f,15.049734f,35.05625f,-19.989819f,-98.62229f,-92.5342f,-5.1019545f,-0.41799974f,0f ) ;
  }

  @Test
  public void test142() {
    color.laplace.solve(23.801842f,-6.5007615f,58.154625f,1.7081283f,-14.696374f,-94.12192f,-2.2729547f,-10.799949f,-26.230467f ) ;
  }

  @Test
  public void test143() {
    color.laplace.solve(24.274109f,3.7339163f,-99.999466f,-6.637483f,-28.680414f,-29.881071f,-22.143625f,-81.93702f,26.010504f ) ;
  }

  @Test
  public void test144() {
    color.laplace.solve(24.369253f,-4.1382046f,-130.55058f,1.3269613f,-8.615383f,-15.460724f,-6.7928643f,-16.070377f,192.7922f ) ;
  }

  @Test
  public void test145() {
    color.laplace.solve(24.4538f,-5.5669785f,-161.40437f,3.382178f,14.316998f,-28.336777f,-25.391165f,88.23054f,63.316055f ) ;
  }

  @Test
  public void test146() {
    color.laplace.solve(24.49466f,7.934898f,-142.82565f,-9.983169f,-47.169262f,-127.82182f,-17.258076f,-58.803185f,-170.71762f ) ;
  }

  @Test
  public void test147() {
    color.laplace.solve(24.562725f,-25.179296f,1.9308225f,23.430197f,-25.165417f,-70.957085f,94.32348f,-27.955482f,0f ) ;
  }

  @Test
  public void test148() {
    color.laplace.solve(24.563776f,17.488142f,24.262215f,-19.145884f,-78.79434f,-20.257973f,-22.246965f,-69.1997f,-175.82097f ) ;
  }

  @Test
  public void test149() {
    color.laplace.solve(24.589405f,14.730194f,14.008151f,-16.372576f,-79.67678f,-58.69759f,-7.6082234f,-14.060317f,31.043736f ) ;
  }

  @Test
  public void test150() {
    color.laplace.solve(24.638231f,-3.6852496f,99.97297f,2.2381783f,-12.425423f,-32.97605f,-3.2600968f,-15.278565f,-45.42874f ) ;
  }

  @Test
  public void test151() {
    color.laplace.solve(-2.4638624f,-80.27991f,48.933216f,-29.575544f,-97.59156f,38.89676f,-18.850319f,-45.825733f,-66.861046f ) ;
  }

  @Test
  public void test152() {
    color.laplace.solve(24.652275f,-8.980131f,99.9979f,7.5892344f,4.480105f,22.002327f,1.2245562f,-2.6910093f,-16.468699f ) ;
  }

  @Test
  public void test153() {
    color.laplace.solve(2.489058f,-92.748215f,-99.99989f,2.7044573f,-17.343063f,-79.31144f,25.671835f,99.98293f,-91.84045f ) ;
  }

  @Test
  public void test154() {
    color.laplace.solve(24.938778f,17.369095f,12.626614f,-17.613983f,-68.08901f,-66.86264f,61.824028f,30.745216f,0f ) ;
  }

  @Test
  public void test155() {
    color.laplace.solve(2.4990895f,-87.2569f,80.14148f,-2.746741f,-39.29483f,-44.00333f,25.808777f,-99.84809f,0f ) ;
  }

  @Test
  public void test156() {
    color.laplace.solve(25.034273f,17.951237f,21.831509f,-17.814146f,-75.06084f,-30.625202f,-10.680014f,-24.905907f,-13.882777f ) ;
  }

  @Test
  public void test157() {
    color.laplace.solve(25.122675f,13.108894f,-9.377548f,-12.618197f,-19.017973f,0f,-15.090334f,-47.74314f,0f ) ;
  }

  @Test
  public void test158() {
    color.laplace.solve(-25.321465f,-8.649054f,-38.839714f,-11.248536f,-13.580642f,-21.305944f,-6.0918517f,-13.118871f,-32.802837f ) ;
  }

  @Test
  public void test159() {
    color.laplace.solve(25.408535f,18.562368f,17.510063f,-17.01291f,-68.952675f,-48.777393f,-24.510727f,-228.6885f,-143.56297f ) ;
  }

  @Test
  public void test160() {
    color.laplace.solve(25.416962f,16.64522f,18.340765f,-14.977376f,-77.17685f,19.882082f,-8.149615f,-17.621086f,14.842128f ) ;
  }

  @Test
  public void test161() {
    color.laplace.solve(25.432827f,7.746009f,-50.073936f,-5.992962f,-44.36737f,-165.12798f,-5.033414f,-14.0726595f,-6.931352f ) ;
  }

  @Test
  public void test162() {
    color.laplace.solve(25.491474f,18.579939f,28.506702f,-16.614046f,-79.67842f,-4.55313f,-12.269239f,-32.462914f,-37.90399f ) ;
  }

  @Test
  public void test163() {
    color.laplace.solve(25.549685f,-7.4580812f,-39.344074f,9.65675f,6.3316236f,5.80246f,6.7456894f,17.325293f,56.22229f ) ;
  }

  @Test
  public void test164() {
    color.laplace.solve(25.553589f,7.7354875f,-51.956528f,-5.5211334f,-42.65511f,-28.264944f,-4.983012f,-14.410916f,-10.005544f ) ;
  }

  @Test
  public void test165() {
    color.laplace.solve(25.602407f,2.4336343f,-97.92248f,-0.024004852f,-17.945395f,-43.203083f,-7.7530327f,-30.988125f,-98.254074f ) ;
  }

  @Test
  public void test166() {
    color.laplace.solve(25.713215f,55.653397f,-6.8416057f,-52.800533f,55.05101f,0f,-31.1216f,81.16564f,0f ) ;
  }

  @Test
  public void test167() {
    color.laplace.solve(25.862453f,60.078438f,21.756416f,-56.628628f,92.694885f,-73.05277f,-12.6894455f,5.870846f,0f ) ;
  }

  @Test
  public void test168() {
    color.laplace.solve(25.878824f,-16.386635f,-53.37186f,19.90193f,39.145355f,87.627426f,14.583538f,38.432224f,100.0f ) ;
  }

  @Test
  public void test169() {
    color.laplace.solve(25.911842f,17.142775f,7.730435f,-13.495408f,-65.071175f,-86.22104f,-14.298457f,-43.69842f,-28.443571f ) ;
  }

  @Test
  public void test170() {
    color.laplace.solve(25.922873f,18.847141f,27.875652f,-15.155647f,-78.409966f,-24.829605f,-8.135502f,-17.386358f,17.00003f ) ;
  }

  @Test
  public void test171() {
    color.laplace.solve(26.0189f,22.77897f,9.468981f,-18.703371f,-44.371998f,-84.903046f,-56.46039f,-96.66054f,-100.0f ) ;
  }

  @Test
  public void test172() {
    color.laplace.solve(26.090132f,1.415281f,100.0f,2.9452465f,-13.019846f,-48.337463f,-1.2893003f,-8.1024475f,-18.100645f ) ;
  }

  @Test
  public void test173() {
    color.laplace.solve(26.131453f,30.174082f,26.345587f,-25.6473f,-30.06648f,-24.791733f,-98.65411f,-100.0f,-95.44599f ) ;
  }

  @Test
  public void test174() {
    color.laplace.solve(26.244265f,3.1396556f,-99.99989f,2.0669074f,-13.535569f,-40.956055f,-3.7378726f,-16.89055f,-50.288757f ) ;
  }

  @Test
  public void test175() {
    color.laplace.solve(26.278639f,37.886883f,36.9578f,-32.83152f,-11.162921f,10.050343f,-146.33755f,-59.960953f,-177.98383f ) ;
  }

  @Test
  public void test176() {
    color.laplace.solve(26.295582f,-0.8873014f,-59.598095f,6.0696254f,-3.1905377f,-16.568682f,1.173458f,-1.3757935f,-3.486094f ) ;
  }

  @Test
  public void test177() {
    color.laplace.solve(26.30363f,37.554153f,81.703545f,-32.33963f,-57.79056f,43.49675f,-97.87159f,35.184723f,0f ) ;
  }

  @Test
  public void test178() {
    color.laplace.solve(26.33012f,17.161465f,-4.8591623f,-9.721204f,-53.108574f,-191.96712f,-9.864189f,-27.088644f,-45.010593f ) ;
  }

  @Test
  public void test179() {
    color.laplace.solve(26.39088f,67.99491f,88.88832f,-62.431393f,56.700455f,77.903336f,-11.281531f,17.30527f,23.80215f ) ;
  }

  @Test
  public void test180() {
    color.laplace.solve(26.481129f,4.4043937f,-99.83753f,1.5201238f,-9.026022f,-3.3061814f,-11.374612f,-38.722424f,82.75724f ) ;
  }

  @Test
  public void test181() {
    color.laplace.solve(26.580387f,7.088401f,-4.80909f,-0.7668496f,-93.417694f,50.794632f,63.76991f,5.235886f,0f ) ;
  }

  @Test
  public void test182() {
    color.laplace.solve(26.751823f,75.33418f,-95.54289f,12.215916f,17.920637f,-20.396082f,4.1912036f,4.537648f,-3.9612477f ) ;
  }

  @Test
  public void test183() {
    color.laplace.solve(26.812563f,42.46843f,10.464518f,-35.218178f,-16.50854f,0f,76.717384f,-66.8124f,0f ) ;
  }

  @Test
  public void test184() {
    color.laplace.solve(26.87183f,6.8295183f,-57.562904f,0.65779996f,-41.990852f,-100.0f,17.748814f,50.219822f,0f ) ;
  }

  @Test
  public void test185() {
    color.laplace.solve(26.912437f,-0.8126683f,99.9873f,8.462415f,9.172273f,46.44196f,-2.23505f,-17.402605f,-3.2087648f ) ;
  }

  @Test
  public void test186() {
    color.laplace.solve(27.276686f,21.213339f,5.303316f,-12.100708f,-47.723686f,-100.0f,-27.955833f,-100.0f,-6.9401116f ) ;
  }

  @Test
  public void test187() {
    color.laplace.solve(27.300665f,24.487251f,35.244663f,-15.28459f,-64.59632f,99.56646f,-23.842707f,0f,0f ) ;
  }

  @Test
  public void test188() {
    color.laplace.solve(27.332766f,14.57624f,-51.176296f,-5.2451797f,-17.851513f,17.925007f,-3.4906497f,-8.717419f,-13.5275135f ) ;
  }

  @Test
  public void test189() {
    color.laplace.solve(-27.395094f,87.150116f,0f,-14.371051f,-24.761381f,-4.0845127f,-5.327729f,-6.939866f,2.3296452f ) ;
  }

  @Test
  public void test190() {
    color.laplace.solve(27.447304f,8.186173f,91.64444f,1.6030452f,-7.4319315f,16.49887f,-13.603192f,-56.015816f,-18.217026f ) ;
  }

  @Test
  public void test191() {
    color.laplace.solve(27.522108f,9.514312f,-86.01142f,0.57412124f,-17.70734f,-50.27054f,-7.5182834f,-30.647255f,-97.363396f ) ;
  }

  @Test
  public void test192() {
    color.laplace.solve(27.585693f,22.148968f,33.67722f,-11.8062f,-72.66704f,12.55991f,-2.1434531f,3.2323875f,87.74004f ) ;
  }

  @Test
  public void test193() {
    color.laplace.solve(27.633743f,24.190487f,100.0f,-13.655511f,-66.02493f,-76.25804f,-16.230858f,-51.26792f,100.0f ) ;
  }

  @Test
  public void test194() {
    color.laplace.solve(27.765108f,20.215603f,43.777798f,-9.155168f,-90.6805f,54.89559f,-7.949177f,-22.64154f,8.063513f ) ;
  }

  @Test
  public void test195() {
    color.laplace.solve(27.781254f,24.556974f,40.428265f,-13.431961f,-69.98162f,37.156082f,-11.527478f,-32.67795f,72.4683f ) ;
  }

  @Test
  public void test196() {
    color.laplace.solve(-27.817717f,-82.14503f,-12.526082f,-13.879594f,-21.230986f,23.099768f,-6.469671f,-11.999089f,-20.295702f ) ;
  }

  @Test
  public void test197() {
    color.laplace.solve(27.982964f,4.545975f,-95.6007f,7.4423704f,-14.155867f,-124.61507f,15.946812f,56.070786f,-129.39037f ) ;
  }

  @Test
  public void test198() {
    color.laplace.solve(28.003162f,22.629158f,7.3598022f,-10.616512f,-44.844383f,-99.51874f,-25.622925f,-91.867805f,-27.051044f ) ;
  }

  @Test
  public void test199() {
    color.laplace.solve(28.014095f,8.454022f,-17.476599f,3.6023622f,-17.79504f,-96.39575f,4.1903925f,13.159207f,66.24148f ) ;
  }

  @Test
  public void test200() {
    color.laplace.solve(28.128595f,5.9561405f,-30.585388f,6.558199f,-1.9689758f,-14.027f,0.048729468f,-6.363281f,-23.557323f ) ;
  }

  @Test
  public void test201() {
    color.laplace.solve(28.198126f,16.134886f,-41.524666f,-3.3440142f,-22.133917f,-26.905712f,-19.44102f,-74.42083f,-43.960186f ) ;
  }

  @Test
  public void test202() {
    color.laplace.solve(28.218256f,18.9245f,-31.138826f,-6.06208f,-21.208342f,13.189087f,-30.964243f,-320.33356f,0f ) ;
  }

  @Test
  public void test203() {
    color.laplace.solve(28.235533f,23.48933f,9.139597f,-10.547183f,-43.417812f,-89.134766f,-27.006456f,-97.47863f,-99.99933f ) ;
  }

  @Test
  public void test204() {
    color.laplace.solve(28.245811f,15.7729225f,35.399895f,-2.7896757f,-57.024303f,40.32738f,17.61979f,-11.950602f,0f ) ;
  }

  @Test
  public void test205() {
    color.laplace.solve(28.260471f,6.6430907f,-28.650156f,6.398798f,-13.876331f,-90.767685f,-0.8980543f,-9.991015f,-25.189676f ) ;
  }

  @Test
  public void test206() {
    color.laplace.solve(28.28657f,49.935116f,27.399f,-36.788834f,44.05489f,33.520664f,-19.907816f,-42.842434f,-17.719189f ) ;
  }

  @Test
  public void test207() {
    color.laplace.solve(28.433018f,8.121702f,19.109957f,5.610373f,-1.9795796f,0.0077683805f,-4.0119467f,-21.658161f,-80.64111f ) ;
  }

  @Test
  public void test208() {
    color.laplace.solve(28.492203f,34.522987f,29.305185f,-20.553988f,-19.705442f,-17.30188f,-7.2219725f,-8.334089f,-6.4089923f ) ;
  }

  @Test
  public void test209() {
    color.laplace.solve(28.518198f,37.978195f,49.24161f,-23.905401f,-25.847034f,-39.790195f,-13.245465f,-29.07646f,-70.79621f ) ;
  }

  @Test
  public void test210() {
    color.laplace.solve(28.576492f,12.303233f,-61.432125f,2.0027332f,-17.93143f,-76.32435f,-2.6341274f,-12.539243f,-43.328636f ) ;
  }

  @Test
  public void test211() {
    color.laplace.solve(28.60267f,23.307196f,22.89961f,-8.896551f,-58.28602f,-31.708754f,-5.9028554f,-14.713338f,5.335525f ) ;
  }

  @Test
  public void test212() {
    color.laplace.solve(28.621313f,-16.760412f,-13.369589f,31.24566f,86.67668f,-90.73231f,9.684654f,7.4929543f,-66.38952f ) ;
  }

  @Test
  public void test213() {
    color.laplace.solve(28.626461f,20.956425f,2.7651346f,-6.013643f,-47.59121f,-142.78665f,-4.97908f,-13.581899f,-1.7522751f ) ;
  }

  @Test
  public void test214() {
    color.laplace.solve(28.662283f,14.423982f,44.692192f,0.22514671f,-18.309317f,-49.851738f,-9.452378f,-38.03466f,100.0f ) ;
  }

  @Test
  public void test215() {
    color.laplace.solve(28.749552f,4.119898f,20.56743f,10.878305f,9.928937f,48.500526f,4.834734f,8.46063f,19.07885f ) ;
  }

  @Test
  public void test216() {
    color.laplace.solve(-28.75234f,21.955347f,0f,3.4724772f,36.01349f,-18.080053f,6.6287603f,23.042564f,0f ) ;
  }

  @Test
  public void test217() {
    color.laplace.solve(28.756361f,19.512966f,-6.8793244f,-4.481621f,-43.84999f,-183.89117f,-2.8132987f,-6.694301f,76.93576f ) ;
  }

  @Test
  public void test218() {
    color.laplace.solve(28.762888f,-6.5492496f,-3.6403532f,21.600801f,-92.83999f,0f,99.896454f,0f,0f ) ;
  }

  @Test
  public void test219() {
    color.laplace.solve(28.790865f,14.92261f,-58.77831f,0.24084881f,-10.322117f,-33.861168f,-34.41655f,-57.860977f,0f ) ;
  }

  @Test
  public void test220() {
    color.laplace.solve(28.830294f,20.26492f,-3.5811987f,-4.943742f,-44.189423f,-100.0f,-4.415839f,-12.719616f,-2.2732022f ) ;
  }

  @Test
  public void test221() {
    color.laplace.solve(28.845701f,25.953415f,42.86743f,-10.570607f,-67.899475f,-31.753502f,-3.2286577f,25.989496f,0f ) ;
  }

  @Test
  public void test222() {
    color.laplace.solve(28.908401f,11.866337f,-71.88772f,3.7674088f,-9.713607f,-35.743683f,-3.7450433f,-18.744488f,-61.373405f ) ;
  }

  @Test
  public void test223() {
    color.laplace.solve(28.948751f,7.899408f,-97.64451f,7.895601f,0.29338396f,-16.086943f,2.340268f,1.4654702f,33.00335f ) ;
  }

  @Test
  public void test224() {
    color.laplace.solve(29.013992f,40.208958f,16.596855f,-24.152992f,15.224986f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test225() {
    color.laplace.solve(29.043633f,12.45209f,-62.621185f,14.302508f,21.88086f,49.929188f,6.28554f,10.839652f,15.19221f ) ;
  }

  @Test
  public void test226() {
    color.laplace.solve(29.044546f,2.2468984f,-140.93628f,13.681269f,20.78932f,56.584335f,5.5205026f,11.071572f,18.268633f ) ;
  }

  @Test
  public void test227() {
    color.laplace.solve(29.060642f,9.0387745f,-91.23279f,7.203786f,-1.672765f,-21.438906f,1.4272658f,-1.4947256f,-5.733408f ) ;
  }

  @Test
  public void test228() {
    color.laplace.solve(29.107756f,10.499645f,-72.689354f,5.931378f,-14.419825f,-81.746796f,9.0375805f,30.218943f,-23.698006f ) ;
  }

  @Test
  public void test229() {
    color.laplace.solve(29.155012f,28.507536f,70.723366f,12.2818775f,16.059008f,20.074545f,3.9134884f,3.3720763f,-6.4841914f ) ;
  }

  @Test
  public void test230() {
    color.laplace.solve(29.166765f,30.149647f,-13.038582f,-13.482586f,4.470405f,33.5885f,-87.56751f,90.99798f,0f ) ;
  }

  @Test
  public void test231() {
    color.laplace.solve(29.181053f,24.362226f,28.589333f,-7.638012f,-60.321476f,-10.004898f,0.58837557f,9.991514f,99.69916f ) ;
  }

  @Test
  public void test232() {
    color.laplace.solve(29.190994f,28.447676f,8.996101f,-11.6837f,-24.39639f,-92.46327f,-51.5294f,-21.886272f,0f ) ;
  }

  @Test
  public void test233() {
    color.laplace.solve(29.20667f,-1.6445053f,-97.40827f,19.797329f,-38.34376f,-45.57852f,88.2382f,-125.664566f,-137.9131f ) ;
  }

  @Test
  public void test234() {
    color.laplace.solve(29.20885f,23.370014f,20.845499f,-6.534609f,-56.57429f,-39.988014f,-6.505434f,-19.487127f,-14.868785f ) ;
  }

  @Test
  public void test235() {
    color.laplace.solve(29.276318f,9.005226f,-98.30576f,8.100044f,5.05035f,18.90214f,-1.9264914f,-15.806009f,73.46652f ) ;
  }

  @Test
  public void test236() {
    color.laplace.solve(29.594763f,12.167565f,-76.974014f,6.2114873f,-3.9504874f,-24.776209f,-0.7983264f,-9.404793f,-32.870358f ) ;
  }

  @Test
  public void test237() {
    color.laplace.solve(29.718454f,14.916373f,-57.070915f,3.9574463f,-12.982044f,50.9213f,-0.9066255f,-7.5839486f,-16.447124f ) ;
  }

  @Test
  public void test238() {
    color.laplace.solve(29.75637f,27.113533f,14.834728f,-8.088055f,-36.1369f,-67.774635f,-25.97161f,-95.7984f,99.99966f ) ;
  }

  @Test
  public void test239() {
    color.laplace.solve(29.796288f,17.05597f,-53.99253f,2.129184f,-7.5798817f,56.38613f,-13.699671f,-56.927868f,-37.92597f ) ;
  }

  @Test
  public void test240() {
    color.laplace.solve(29.806221f,20.381899f,-10.887137f,-1.1570177f,-37.39149f,100.0f,2.9571998f,12.985817f,86.377556f ) ;
  }

  @Test
  public void test241() {
    color.laplace.solve(29.886322f,13.930023f,-70.47221f,5.6134553f,-3.694715f,-13.721252f,-3.7469077f,-20.601086f,19.281918f ) ;
  }

  @Test
  public void test242() {
    color.laplace.solve(29.89438f,11.902754f,-80.569984f,7.6747713f,-0.8435762f,-21.790257f,1.6429454f,-1.2332795f,-5.755884f ) ;
  }

  @Test
  public void test243() {
    color.laplace.solve(29.91823f,24.998043f,44.748104f,-5.3251224f,-74.67416f,53.994366f,-62.29147f,0f,0f ) ;
  }

  @Test
  public void test244() {
    color.laplace.solve(30.016212f,10.760796f,-98.32f,9.304051f,11.346974f,51.215015f,-4.146979f,-25.891968f,-16.372662f ) ;
  }

  @Test
  public void test245() {
    color.laplace.solve(30.080101f,39.82013f,37.940704f,-19.499723f,-8.740291f,11.942685f,-99.33871f,-67.22425f,18.570328f ) ;
  }

  @Test
  public void test246() {
    color.laplace.solve(30.10068f,13.915545f,16.865736f,6.4871936f,-4.8902674f,-36.427933f,0.7378231f,-3.5358646f,-9.99095f ) ;
  }

  @Test
  public void test247() {
    color.laplace.solve(30.10376f,28.33954f,41.44638f,-7.9245033f,-58.19198f,14.913781f,-3.6097937f,-6.514672f,35.743088f ) ;
  }

  @Test
  public void test248() {
    color.laplace.solve(30.111713f,10.311982f,-12.744583f,10.134872f,4.8694797f,-13.06725f,5.5582967f,12.098313f,-44.393898f ) ;
  }

  @Test
  public void test249() {
    color.laplace.solve(30.149038f,15.993834f,-51.960506f,4.60232f,-14.2132f,-82.7404f,2.4734423f,5.2914486f,32.905552f ) ;
  }

  @Test
  public void test250() {
    color.laplace.solve(30.158936f,14.843922f,-41.14028f,5.7918196f,-29.642967f,-33.83991f,22.65131f,86.491295f,0f ) ;
  }

  @Test
  public void test251() {
    color.laplace.solve(30.161001f,10.160877f,-96.15041f,10.483124f,6.632928f,-4.1834273f,5.138565f,10.071137f,61.69626f ) ;
  }

  @Test
  public void test252() {
    color.laplace.solve(30.19566f,9.239679f,-99.66003f,11.542958f,6.4230886f,-21.759665f,9.553084f,26.66938f,5.108317f ) ;
  }

  @Test
  public void test253() {
    color.laplace.solve(30.200773f,15.050852f,-41.04335f,5.75224f,-28.954016f,-0.49382263f,21.762201f,81.29657f,-0.08836627f ) ;
  }

  @Test
  public void test254() {
    color.laplace.solve(30.304852f,14.172766f,-70.39944f,7.0466385f,-3.2143073f,-31.417448f,1.0967939f,-2.6591861f,-8.519164f ) ;
  }

  @Test
  public void test255() {
    color.laplace.solve(-3.0351255f,-100.0f,-99.54401f,-12.140502f,-39.623734f,-34.88232f,-5.903152f,-11.472106f,-0.36154124f ) ;
  }

  @Test
  public void test256() {
    color.laplace.solve(30.533182f,22.360487f,-31.438736f,-0.22775915f,-19.61247f,0f,-0.07143474f,-0.057979804f,39.5656f ) ;
  }

  @Test
  public void test257() {
    color.laplace.solve(30.583218f,13.265925f,-84.89863f,9.066948f,7.3791127f,23.02869f,-1.6945413f,-15.845114f,-69.065025f ) ;
  }

  @Test
  public void test258() {
    color.laplace.solve(30.678764f,41.09741f,22.485102f,-18.382353f,11.225765f,-51.157005f,2.5569396f,0f,0f ) ;
  }

  @Test
  public void test259() {
    color.laplace.solve(30.773373f,39.525738f,55.126865f,-16.432251f,-27.797277f,-58.243473f,-68.7051f,-76.03913f,-57.7676f ) ;
  }

  @Test
  public void test260() {
    color.laplace.solve(30.84314f,22.408897f,-42.13482f,0.9636608f,0.9272645f,-9.182557f,-27.91576f,-10.480942f,4.4773235f ) ;
  }

  @Test
  public void test261() {
    color.laplace.solve(30.878588f,11.985655f,-93.042915f,11.528764f,10.1069565f,-99.99984f,5.129513f,8.989299f,20.720716f ) ;
  }

  @Test
  public void test262() {
    color.laplace.solve(30.889082f,-4.4139633f,-11.111026f,27.97029f,14.938659f,0f,-15.531671f,-90.09697f,0f ) ;
  }

  @Test
  public void test263() {
    color.laplace.solve(31.107166f,18.32478f,25.849182f,10.802317f,9.172428f,6.6462464f,2.9296713f,0.91636896f,-8.436624f ) ;
  }

  @Test
  public void test264() {
    color.laplace.solve(31.12077f,30.17707f,35.62055f,-5.69399f,-46.033047f,12.3051195f,-7.8636856f,-25.76074f,-49.14623f ) ;
  }

  @Test
  public void test265() {
    color.laplace.solve(31.136381f,29.151262f,41.9375f,-4.605735f,-56.46883f,38.598732f,5.52983f,26.725056f,48.066933f ) ;
  }

  @Test
  public void test266() {
    color.laplace.solve(31.178303f,25.920479f,5.159183f,-1.2074848f,-32.65557f,15.438835f,-3.3526752f,-12.203217f,-12.804621f ) ;
  }

  @Test
  public void test267() {
    color.laplace.solve(31.18141f,32.815136f,29.927372f,-7.8082104f,-29.339577f,-12.515096f,-32.933895f,-129.38777f,-200.6562f ) ;
  }

  @Test
  public void test268() {
    color.laplace.solve(31.234747f,49.10137f,46.52053f,-24.162388f,18.650217f,24.992796f,-4.612674f,0f,0f ) ;
  }

  @Test
  public void test269() {
    color.laplace.solve(31.308525f,18.732077f,-52.905994f,6.5020275f,-3.4742246f,-25.324207f,-1.8261917f,-13.806794f,-49.92676f ) ;
  }

  @Test
  public void test270() {
    color.laplace.solve(31.310379f,17.820225f,-57.98568f,7.4212894f,-2.0438023f,-27.669765f,0.41858312f,-5.7469563f,-21.362606f ) ;
  }

  @Test
  public void test271() {
    color.laplace.solve(31.34105f,23.409687f,-77.190796f,1.952457f,-29.203703f,-162.8962f,5.671734f,20.71945f,106.41059f ) ;
  }

  @Test
  public void test272() {
    color.laplace.solve(31.362595f,-41.819767f,14.213883f,67.27014f,-34.69002f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test273() {
    color.laplace.solve(31.397713f,42.351414f,36.856033f,-16.72501f,1.7143145f,5.0434594f,-99.99451f,-23.766043f,-18.396511f ) ;
  }

  @Test
  public void test274() {
    color.laplace.solve(31.462254f,16.880394f,-66.76069f,8.968698f,2.1633246f,-17.224077f,2.2492604f,0.028403383f,-4.2989182f ) ;
  }

  @Test
  public void test275() {
    color.laplace.solve(31.489931f,16.987152f,83.17107f,8.972561f,-4.3678474f,-69.53115f,8.76816f,26.10006f,99.999916f ) ;
  }

  @Test
  public void test276() {
    color.laplace.solve(31.495384f,27.275469f,-4.466919f,-1.2939334f,-17.926594f,-24.003744f,-18.744524f,-73.684166f,99.99942f ) ;
  }

  @Test
  public void test277() {
    color.laplace.solve(31.520334f,19.516588f,55.554264f,6.5647473f,0.96234274f,9.227533f,-6.2236876f,-31.4595f,-19.606472f ) ;
  }

  @Test
  public void test278() {
    color.laplace.solve(31.520456f,3.190775f,-19.476965f,22.891047f,11.362183f,0f,13.165789f,29.772108f,94.56046f ) ;
  }

  @Test
  public void test279() {
    color.laplace.solve(31.53648f,26.937094f,6.735262f,-0.7911741f,-30.52337f,-99.99605f,-4.177806f,-15.92005f,-28.979023f ) ;
  }

  @Test
  public void test280() {
    color.laplace.solve(31.577105f,40.566383f,19.793154f,-14.257966f,10.895272f,-61.393764f,-99.50424f,100.0f,0f ) ;
  }

  @Test
  public void test281() {
    color.laplace.solve(31.588467f,35.884125f,28.715868f,-9.530257f,-16.767836f,-21.020653f,-52.941658f,-72.40456f,-96.03065f ) ;
  }

  @Test
  public void test282() {
    color.laplace.solve(31.609118f,46.299095f,62.383873f,-19.800608f,-8.561121f,17.65272f,-102.24584f,-78.386215f,16.695698f ) ;
  }

  @Test
  public void test283() {
    color.laplace.solve(31.664038f,17.588884f,19.828182f,9.067264f,4.609646f,0.86821204f,-0.0046279766f,-9.085775f,-40.94812f ) ;
  }

  @Test
  public void test284() {
    color.laplace.solve(31.696215f,32.362778f,25.371637f,-5.577756f,-27.616167f,-37.263176f,-26.39107f,-99.98652f,-99.98641f ) ;
  }

  @Test
  public void test285() {
    color.laplace.solve(31.76984f,27.964033f,8.956297f,-0.43925545f,-28.868126f,-264.72675f,-4.7625017f,-18.610752f,69.53618f ) ;
  }

  @Test
  public void test286() {
    color.laplace.solve(31.774593f,15.942939f,-75.474785f,11.155396f,7.4719405f,-7.555383f,5.375052f,10.344809f,28.532242f ) ;
  }

  @Test
  public void test287() {
    color.laplace.solve(31.859201f,20.161766f,-48.83825f,7.2750583f,-2.3738863f,-28.116943f,-0.38508192f,-8.815405f,-20.435532f ) ;
  }

  @Test
  public void test288() {
    color.laplace.solve(31.984657f,39.93733f,12.103562f,-11.998699f,15.661099f,-91.52308f,-95.64056f,-100.0f,0f ) ;
  }

  @Test
  public void test289() {
    color.laplace.solve(31.988361f,28.39774f,7.4343467f,-0.4442918f,-25.83175f,-99.98963f,-7.9337783f,-31.290821f,-100.0f ) ;
  }

  @Test
  public void test290() {
    color.laplace.solve(32.10825f,8.309099f,-64.293144f,20.123894f,-34.578705f,-100.0f,0.79388446f,-16.948355f,-34.008602f ) ;
  }

  @Test
  public void test291() {
    color.laplace.solve(32.222218f,22.802551f,-34.156044f,6.0863194f,-6.8559704f,-46.142555f,-1.0209694f,-10.1701975f,-32.80385f ) ;
  }

  @Test
  public void test292() {
    color.laplace.solve(32.22423f,17.270596f,49.079887f,11.70479f,10.549287f,8.746083f,4.0449967f,4.4751973f,3.3053203f ) ;
  }

  @Test
  public void test293() {
    color.laplace.solve(-32.237713f,51.203598f,89.877754f,-10.896333f,2.3598924f,13.066026f,-13.707513f,-43.93372f,8.619929f ) ;
  }

  @Test
  public void test294() {
    color.laplace.solve(32.32956f,29.538525f,6.9450574f,1.5380012f,-21.120522f,-100.0f,-3.0655787f,-13.157596f,-28.450079f ) ;
  }

  @Test
  public void test295() {
    color.laplace.solve(32.335022f,23.834053f,-27.569048f,5.506029f,-9.429761f,-58.028522f,-0.88114333f,-9.030602f,-32.587276f ) ;
  }

  @Test
  public void test296() {
    color.laplace.solve(32.34229f,22.432135f,-59.75303f,6.937015f,17.139282f,-88.58042f,-21.733511f,-93.871056f,-50.275196f ) ;
  }

  @Test
  public void test297() {
    color.laplace.solve(32.436035f,19.149279f,-65.05779f,10.594857f,5.902238f,-11.704961f,4.0411587f,5.569777f,12.335712f ) ;
  }

  @Test
  public void test298() {
    color.laplace.solve(3.2484512f,-72.48238f,-64.072945f,-14.523812f,18.752008f,69.654755f,-80.09571f,92.35948f,55.162693f ) ;
  }

  @Test
  public void test299() {
    color.laplace.solve(32.510765f,18.412424f,-67.378174f,11.69171f,8.531918f,-7.00865f,5.724157f,11.265905f,30.811659f ) ;
  }

  @Test
  public void test300() {
    color.laplace.solve(32.526257f,17.63865f,-72.01718f,12.4663725f,10.045526f,-6.631387f,7.2937098f,16.708467f,35.446106f ) ;
  }

  @Test
  public void test301() {
    color.laplace.solve(32.539646f,21.467459f,-46.849396f,8.672068f,0.1789859f,-28.120941f,1.8401464f,-1.3352532f,-7.360145f ) ;
  }

  @Test
  public void test302() {
    color.laplace.solve(32.552094f,17.776278f,-70.93168f,12.432096f,9.484696f,-10.603853f,7.691591f,18.334269f,19.03157f ) ;
  }

  @Test
  public void test303() {
    color.laplace.solve(32.5862f,27.817553f,-20.206848f,2.5272486f,-1.109142f,31.361237f,-21.368065f,-66.14261f,49.404877f ) ;
  }

  @Test
  public void test304() {
    color.laplace.solve(32.601913f,29.649971f,15.587977f,0.76553506f,-29.600197f,-149.20122f,0.19837862f,0.29176906f,30.668875f ) ;
  }

  @Test
  public void test305() {
    color.laplace.solve(32.63651f,32.001083f,18.064116f,-1.4550445f,-22.696285f,-59.74462f,-15.760402f,-61.586563f,15.1932745f ) ;
  }

  @Test
  public void test306() {
    color.laplace.solve(32.752865f,12.462857f,6.873289f,18.5486f,-47.278652f,57.861774f,88.720184f,0.56447047f,0f ) ;
  }

  @Test
  public void test307() {
    color.laplace.solve(32.767582f,30.849234f,11.810614f,0.7610279f,-21.098799f,-83.743706f,-7.9115787f,-32.261753f,-100.0f ) ;
  }

  @Test
  public void test308() {
    color.laplace.solve(32.807545f,21.041668f,-50.50593f,10.188502f,5.0735583f,-12.2390585f,2.872906f,1.30312f,-2.7339845f ) ;
  }

  @Test
  public void test309() {
    color.laplace.solve(32.829548f,-30.233858f,17.25311f,61.552055f,100.0f,7.2621837f,25.61178f,40.895065f,37.968487f ) ;
  }

  @Test
  public void test310() {
    color.laplace.solve(32.9063f,15.15868f,-89.14228f,16.466518f,16.870697f,-12.0322075f,16.089079f,47.889797f,24.14275f ) ;
  }

  @Test
  public void test311() {
    color.laplace.solve(32.941525f,45.01869f,41.898827f,-13.293519f,5.2344f,22.543304f,-91.35337f,-33.354633f,43.038742f ) ;
  }

  @Test
  public void test312() {
    color.laplace.solve(32.95742f,22.379204f,-42.86975f,9.450483f,-0.57085866f,-46.32412f,5.4153705f,12.210999f,43.999485f ) ;
  }

  @Test
  public void test313() {
    color.laplace.solve(32.99808f,38.43162f,30.231525f,-6.4393086f,-9.502972f,-17.505518f,-49.252342f,-52.49867f,-90.7506f ) ;
  }

  @Test
  public void test314() {
    color.laplace.solve(33.004375f,16.07634f,-60.81613f,15.941169f,14.7274475f,-21.297955f,16.03285f,48.190235f,-39.103138f ) ;
  }

  @Test
  public void test315() {
    color.laplace.solve(-3.3098736f,6.327316f,0f,-19.052755f,-26.886919f,-63.038124f,-4.938101f,-0.6996475f,29.02643f ) ;
  }

  @Test
  public void test316() {
    color.laplace.solve(33.11929f,25.6469f,-32.605804f,6.830257f,2.0741167f,74.64106f,3.3105605f,6.411985f,20.263262f ) ;
  }

  @Test
  public void test317() {
    color.laplace.solve(33.147972f,28.52351f,-10.238359f,4.068384f,-8.815575f,18.998991f,-8.058863f,-86.85319f,95.049904f ) ;
  }

  @Test
  public void test318() {
    color.laplace.solve(33.192024f,35.941254f,30.664341f,-3.1731532f,-20.09135f,-13.283887f,-25.79329f,-100.0f,0f ) ;
  }

  @Test
  public void test319() {
    color.laplace.solve(33.218166f,22.689974f,-61.879547f,10.168599f,4.664328f,-15.200273f,2.7919028f,0.98067844f,-3.5474987f ) ;
  }

  @Test
  public void test320() {
    color.laplace.solve(33.27294f,19.191843f,72.96888f,13.899915f,16.728727f,25.332994f,5.597543f,8.490161f,11.634346f ) ;
  }

  @Test
  public void test321() {
    color.laplace.solve(33.360374f,29.990187f,6.8346496f,3.4958112f,-20.206423f,-114.17942f,0.83744186f,-0.11679283f,18.942379f ) ;
  }

  @Test
  public void test322() {
    color.laplace.solve(33.420357f,33.052563f,28.505272f,0.62886125f,-29.715382f,-19.031473f,-2.29393f,-9.804582f,-7.2090135f ) ;
  }

  @Test
  public void test323() {
    color.laplace.solve(33.44325f,21.652132f,-68.908295f,12.120869f,22.073568f,51.833202f,-7.033343f,-40.25424f,0f ) ;
  }

  @Test
  public void test324() {
    color.laplace.solve(33.472588f,34.645756f,23.804167f,-0.75540674f,-18.693724f,-39.429092f,-17.800491f,-70.446556f,-14.952409f ) ;
  }

  @Test
  public void test325() {
    color.laplace.solve(33.483532f,31.093504f,20.659517f,2.8406503f,-29.76902f,-48.455437f,7.6480913f,27.751753f,56.544117f ) ;
  }

  @Test
  public void test326() {
    color.laplace.solve(33.5145f,16.079397f,-99.827736f,17.977337f,30.6268f,74.69108f,7.929838f,13.75939f,16.48093f ) ;
  }

  @Test
  public void test327() {
    color.laplace.solve(33.533035f,40.074505f,30.441439f,-5.9423647f,-3.676452f,-18.308754f,-53.62604f,-30.529196f,-100.0f ) ;
  }

  @Test
  public void test328() {
    color.laplace.solve(33.5785f,29.767923f,1.1070818f,4.5460486f,-15.613914f,6.5615005f,0.2195836f,-3.6677144f,0.72344625f ) ;
  }

  @Test
  public void test329() {
    color.laplace.solve(33.579994f,31.428999f,12.626364f,2.6850271f,-19.660885f,-100.0f,-2.4939544f,-12.660845f,-28.234571f ) ;
  }

  @Test
  public void test330() {
    color.laplace.solve(33.754482f,35.328026f,-100.0f,-0.31009734f,3.6357534f,0f,2.2559824f,9.334027f,31.444374f ) ;
  }

  @Test
  public void test331() {
    color.laplace.solve(33.77683f,24.152489f,-43.969566f,10.95483f,6.802694f,-9.900895f,3.2397954f,2.0043516f,-2.0250826f ) ;
  }

  @Test
  public void test332() {
    color.laplace.solve(33.81203f,44.078194f,40.26276f,-8.830068f,2.2379882f,16.972849f,-71.37029f,-61.07119f,0f ) ;
  }

  @Test
  public void test333() {
    color.laplace.solve(33.826744f,19.379467f,-53.324467f,15.927504f,-2.9844098f,-34.394123f,4.450358f,1.8739285f,6.029766f ) ;
  }

  @Test
  public void test334() {
    color.laplace.solve(33.839878f,44.271618f,-98.203316f,-8.912104f,-36.594563f,-98.93644f,-32.89373f,-82.80132f,-72.54398f ) ;
  }

  @Test
  public void test335() {
    color.laplace.solve(3.3845713f,8.242233f,-3.847482f,-1.3071085f,-4.95007f,-13.39077f,-3.6629355f,-13.344634f,-44.76553f ) ;
  }

  @Test
  public void test336() {
    color.laplace.solve(33.89049f,35.902893f,29.94486f,-0.3198154f,-20.14417f,-16.123453f,-15.02558f,-100.0f,-74.2945f ) ;
  }

  @Test
  public void test337() {
    color.laplace.solve(33.946815f,33.90959f,23.139091f,1.8776709f,-21.447544f,-99.74537f,-4.9885983f,-21.832066f,-60.946964f ) ;
  }

  @Test
  public void test338() {
    color.laplace.solve(33.94825f,32.474174f,12.523279f,3.31883f,-16.574825f,-82.38106f,-4.0981054f,-19.711252f,5.830044f ) ;
  }

  @Test
  public void test339() {
    color.laplace.solve(33.95091f,37.543266f,54.437458f,-1.7396293f,-38.215305f,28.084827f,-2.6941218f,-9.036859f,4.7619925f ) ;
  }

  @Test
  public void test340() {
    color.laplace.solve(33.97823f,23.297388f,-52.876766f,12.617225f,12.088091f,7.444615f,4.4025803f,4.994368f,70.56714f ) ;
  }

  @Test
  public void test341() {
    color.laplace.solve(33.98866f,37.05208f,31.660244f,-1.0973319f,-17.439873f,-10.411171f,-20.938173f,-95.302765f,-55.865055f ) ;
  }

  @Test
  public void test342() {
    color.laplace.solve(34.047646f,20.231249f,-74.11119f,15.959328f,20.988539f,28.518394f,8.801127f,19.245182f,47.191063f ) ;
  }

  @Test
  public void test343() {
    color.laplace.solve(34.047897f,35.340126f,9.961738f,0.8514604f,-2.6491249f,-86.775116f,-27.992931f,39.98703f,26.273125f ) ;
  }

  @Test
  public void test344() {
    color.laplace.solve(34.10576f,32.5488f,12.202747f,3.9225075f,-14.388633f,-83.73781f,-1.6208807f,-10.4438f,-23.536715f ) ;
  }

  @Test
  public void test345() {
    color.laplace.solve(34.141033f,61.170467f,41.299294f,-24.606327f,-78.71617f,0f,-53.850174f,0f,0f ) ;
  }

  @Test
  public void test346() {
    color.laplace.solve(34.166424f,31.737526f,8.402978f,4.92817f,-15.619302f,-98.87696f,1.1655583f,-0.26593694f,13.389996f ) ;
  }

  @Test
  public void test347() {
    color.laplace.solve(34.186916f,31.720882f,8.00229f,5.0267763f,-15.3056755f,-99.71172f,1.2258661f,-0.123311974f,10.319283f ) ;
  }

  @Test
  public void test348() {
    color.laplace.solve(34.18879f,23.491457f,-51.369404f,13.263708f,11.14644f,-9.784105f,7.7196016f,17.614698f,51.592754f ) ;
  }

  @Test
  public void test349() {
    color.laplace.solve(34.214046f,27.777016f,-23.529259f,9.083421f,0.42327586f,-32.882458f,1.7009519f,-2.2796004f,-11.242578f ) ;
  }

  @Test
  public void test350() {
    color.laplace.solve(34.243362f,32.23479f,10.75939f,4.738654f,-16.063581f,-99.588455f,0.7748353f,-1.6393129f,100.0f ) ;
  }

  @Test
  public void test351() {
    color.laplace.solve(34.273506f,23.925598f,-49.736477f,13.172192f,11.146787f,-8.517635f,7.294795f,16.00605f,4.5191507f ) ;
  }

  @Test
  public void test352() {
    color.laplace.solve(34.317444f,29.320358f,8.949606f,7.9494195f,-25.98562f,-41.246155f,23.465853f,-99.9661f,55.621998f ) ;
  }

  @Test
  public void test353() {
    color.laplace.solve(34.36383f,38.861084f,35.715977f,-1.40577f,-14.635466f,4.002821f,-25.351442f,-100.0f,-54.980915f ) ;
  }

  @Test
  public void test354() {
    color.laplace.solve(34.373543f,44.498302f,40.517334f,-7.0041285f,3.1023314f,17.57104f,-65.492386f,-42.655888f,2.3721173f ) ;
  }

  @Test
  public void test355() {
    color.laplace.solve(34.402245f,29.966213f,-3.655857f,7.6427855f,-10.881538f,25.73444f,7.05044f,20.558973f,86.06699f ) ;
  }

  @Test
  public void test356() {
    color.laplace.solve(-3.4469807f,-20.190321f,68.37184f,6.195912f,18.71524f,56.98973f,9.515388f,31.865639f,99.231926f ) ;
  }

  @Test
  public void test357() {
    color.laplace.solve(34.48112f,27.710476f,-27.564772f,10.214014f,3.923891f,-21.819086f,2.4510436f,-0.40984005f,-8.014295f ) ;
  }

  @Test
  public void test358() {
    color.laplace.solve(34.520985f,34.33005f,21.26257f,3.7538898f,-18.463343f,-40.811676f,-1.042084f,-7.9222255f,-12.1834755f ) ;
  }

  @Test
  public void test359() {
    color.laplace.solve(34.56542f,19.379196f,-88.74158f,18.883116f,31.692947f,53.225994f,9.277064f,18.229052f,31.946196f ) ;
  }

  @Test
  public void test360() {
    color.laplace.solve(-3.464299f,-100.0f,-87.75357f,20.880194f,-13.01493f,65.36864f,100.0f,-38.308548f,10.385708f ) ;
  }

  @Test
  public void test361() {
    color.laplace.solve(34.730694f,38.223812f,49.05122f,0.69974387f,-30.88667f,56.72552f,-1.0444872f,-4.8772273f,12.422247f ) ;
  }

  @Test
  public void test362() {
    color.laplace.solve(34.738888f,32.509872f,-88.59745f,6.4456763f,32.972824f,-7.0642433f,-41.92901f,100.0f,28.187893f ) ;
  }

  @Test
  public void test363() {
    color.laplace.solve(34.773533f,39.396694f,35.55649f,-0.30256632f,-12.743255f,2.5924573f,-23.240541f,-92.6596f,-12.443409f ) ;
  }

  @Test
  public void test364() {
    color.laplace.solve(34.785202f,40.907547f,69.85725f,-1.7667581f,-41.012268f,99.99996f,-0.8399724f,-1.5931339f,35.4797f ) ;
  }

  @Test
  public void test365() {
    color.laplace.solve(34.79209f,27.751688f,-34.836117f,11.416676f,11.050779f,17.15609f,-0.17616521f,-12.121337f,-66.176605f ) ;
  }

  @Test
  public void test366() {
    color.laplace.solve(34.815556f,34.991493f,26.448202f,4.2707314f,-21.297787f,-29.198687f,3.5651557f,9.989891f,57.692196f ) ;
  }

  @Test
  public void test367() {
    color.laplace.solve(34.837967f,31.500036f,-1.1051261f,7.8518357f,-7.7448106f,-79.716644f,4.304988f,9.368117f,40.90148f ) ;
  }

  @Test
  public void test368() {
    color.laplace.solve(34.893806f,41.10563f,47.0999f,-1.5304028f,-17.571194f,-17.613516f,-23.444223f,-92.24649f,-99.982765f ) ;
  }

  @Test
  public void test369() {
    color.laplace.solve(34.902237f,36.674313f,16.657095f,2.9346306f,-4.8620815f,17.083887f,-18.301632f,-76.14116f,119.957085f ) ;
  }

  @Test
  public void test370() {
    color.laplace.solve(34.922413f,20.923807f,-70.142105f,18.765844f,18.914925f,-30.16825f,21.226036f,66.1383f,-69.445816f ) ;
  }

  @Test
  public void test371() {
    color.laplace.solve(3.4923058f,-68.176315f,-53.716038f,-17.854464f,-27.96831f,-12.958819f,-46.94185f,-61.699528f,0f ) ;
  }

  @Test
  public void test372() {
    color.laplace.solve(35.01531f,38.273376f,33.145184f,1.7878636f,-15.066988f,-6.035419f,-12.796867f,-94.29378f,-99.998856f ) ;
  }

  @Test
  public void test373() {
    color.laplace.solve(35.076942f,38.669636f,34.585354f,1.6381316f,-14.979218f,-0.33428717f,-13.540655f,-99.86755f,-20.937237f ) ;
  }

  @Test
  public void test374() {
    color.laplace.solve(35.079247f,34.40467f,14.735557f,5.912322f,-12.196121f,-86.2538f,0.7661606f,-2.8476796f,99.993645f ) ;
  }

  @Test
  public void test375() {
    color.laplace.solve(35.089252f,46.052902f,96.37842f,-5.6958976f,-47.25606f,-99.99167f,-10.665467f,-36.965973f,-100.0f ) ;
  }

  @Test
  public void test376() {
    color.laplace.solve(35.133663f,39.854507f,37.209473f,0.68013966f,-12.925106f,1.7199721f,-19.487997f,-93.95504f,-17.404478f ) ;
  }

  @Test
  public void test377() {
    color.laplace.solve(35.17843f,51.7968f,51.519547f,-11.083088f,20.489222f,54.281395f,-100.0f,-13.038218f,-64.52331f ) ;
  }

  @Test
  public void test378() {
    color.laplace.solve(35.183598f,27.765865f,-0.08776196f,12.968533f,12.275002f,3.670269f,4.4159684f,4.695341f,2.0914025f ) ;
  }

  @Test
  public void test379() {
    color.laplace.solve(35.274776f,35.673237f,28.119967f,5.425867f,-20.691261f,-23.161768f,7.220142f,-100.0f,-100.0f ) ;
  }

  @Test
  public void test380() {
    color.laplace.solve(35.310295f,39.19923f,35.47381f,2.0419545f,-13.9871855f,2.6960077f,-13.155293f,-99.88593f,-100.0f ) ;
  }

  @Test
  public void test381() {
    color.laplace.solve(-35.43211f,43.62196f,0f,-87.11751f,41.002666f,0f,-7.5568476f,-8.131418f,0f ) ;
  }

  @Test
  public void test382() {
    color.laplace.solve(35.449203f,41.984737f,59.571136f,-0.18793167f,-27.081383f,-32.127613f,-9.119545f,-36.29025f,-0.7075404f ) ;
  }

  @Test
  public void test383() {
    color.laplace.solve(35.455265f,28.099628f,-30.5416f,13.721425f,7.484847f,8.901911f,11.945589f,-20.783575f,0f ) ;
  }

  @Test
  public void test384() {
    color.laplace.solve(35.48621f,41.814247f,62.717373f,0.13059607f,-30.946821f,56.227474f,-4.0185437f,-16.204771f,-29.854212f ) ;
  }

  @Test
  public void test385() {
    color.laplace.solve(35.50292f,33.648903f,8.412423f,8.362775f,-9.319699f,-99.999214f,7.26788f,20.708744f,-100.0f ) ;
  }

  @Test
  public void test386() {
    color.laplace.solve(35.537148f,34.646976f,-33.32265f,7.501613f,-2.0807168f,-29.169933f,-3.449978f,-21.301525f,-81.27636f ) ;
  }

  @Test
  public void test387() {
    color.laplace.solve(35.56658f,35.309647f,14.693911f,6.9571877f,-9.021908f,-76.533936f,1.2840775f,-1.8206259f,-33.39295f ) ;
  }

  @Test
  public void test388() {
    color.laplace.solve(35.59117f,28.527622f,-35.501705f,13.835629f,14.021022f,4.6351657f,5.7303247f,9.08403f,16.58312f ) ;
  }

  @Test
  public void test389() {
    color.laplace.solve(35.596344f,36.661644f,19.727713f,5.7237277f,-8.677498f,-55.2739f,-4.023936f,-21.82146f,-100.0f ) ;
  }

  @Test
  public void test390() {
    color.laplace.solve(35.608265f,35.095413f,13.602025f,7.337653f,-8.828538f,-80.68731f,2.5692568f,2.9393735f,-3.3781161f ) ;
  }

  @Test
  public void test391() {
    color.laplace.solve(35.63148f,38.5721f,57.701496f,3.953819f,-39.04458f,43.61363f,19.228374f,72.95968f,-99.86764f ) ;
  }

  @Test
  public void test392() {
    color.laplace.solve(35.73662f,34.67024f,13.19935f,8.38922f,-6.981028f,-81.87284f,4.722467f,10.71716f,45.1272f ) ;
  }

  @Test
  public void test393() {
    color.laplace.solve(35.751106f,38.39588f,35.179653f,4.6085668f,-17.34724f,1.9641477f,0.030398944f,-4.4868813f,-0.6306834f ) ;
  }

  @Test
  public void test394() {
    color.laplace.solve(35.79268f,47.2264f,41.48728f,-4.055686f,11.625639f,18.722729f,-63.64106f,-15.390888f,9.307038f ) ;
  }

  @Test
  public void test395() {
    color.laplace.solve(35.819885f,41.237904f,49.3284f,2.0416348f,-20.196676f,-17.27187f,-7.456669f,-31.86831f,-99.8199f ) ;
  }

  @Test
  public void test396() {
    color.laplace.solve(35.83744f,16.781086f,-125.14989f,26.59113f,56.4746f,147.83589f,14.021602f,29.596935f,44.44864f ) ;
  }

  @Test
  public void test397() {
    color.laplace.solve(35.8542f,39.55237f,30.035679f,3.864428f,-7.680404f,-19.409655f,-12.716083f,-54.728756f,-100.0f ) ;
  }

  @Test
  public void test398() {
    color.laplace.solve(35.86208f,40.114895f,32.24114f,3.333417f,-7.6436353f,-11.150335f,-14.884775f,-62.872517f,-75.60656f ) ;
  }

  @Test
  public void test399() {
    color.laplace.solve(35.932903f,36.474693f,21.356949f,7.2569203f,-11.391076f,-99.982414f,4.485853f,10.686494f,49.651196f ) ;
  }

  @Test
  public void test400() {
    color.laplace.solve(35.9363f,37.58782f,27.976646f,6.1623716f,-13.443233f,-99.9988f,2.1564205f,2.4738135f,21.173721f ) ;
  }

  @Test
  public void test401() {
    color.laplace.solve(35.936657f,42.593697f,42.320538f,1.1532414f,-7.0015783f,26.688457f,-24.322113f,-98.44171f,71.43487f ) ;
  }

  @Test
  public void test402() {
    color.laplace.solve(35.944416f,37.9776f,-30.374487f,5.8000636f,-10.689887f,-72.52005f,-2.0542743f,-14.017161f,72.59378f ) ;
  }

  @Test
  public void test403() {
    color.laplace.solve(35.958694f,36.57197f,18.068186f,7.263272f,-7.738989f,-70.86656f,0.8344835f,-3.9241173f,-8.791965f ) ;
  }

  @Test
  public void test404() {
    color.laplace.solve(35.99761f,39.352703f,25.182178f,4.6377316f,-3.7689683f,0.28228065f,-13.677714f,-59.34859f,-20.284088f ) ;
  }

  @Test
  public void test405() {
    color.laplace.solve(36.002464f,37.477577f,29.537298f,6.5322747f,-15.629458f,-19.328382f,5.756095f,-87.1993f,66.82408f ) ;
  }

  @Test
  public void test406() {
    color.laplace.solve(36.012066f,28.073236f,-47.172806f,15.974724f,23.698774f,49.96894f,4.1880574f,0.7775052f,-24.77681f ) ;
  }

  @Test
  public void test407() {
    color.laplace.solve(36.03733f,37.647602f,31.828426f,6.501723f,-17.275356f,-22.226961f,7.2449164f,22.477943f,99.942215f ) ;
  }

  @Test
  public void test408() {
    color.laplace.solve(36.056026f,36.99859f,18.546894f,7.3393426f,-6.089498f,-62.993988f,0.34941697f,-5.7363048f,-17.205137f ) ;
  }

  @Test
  public void test409() {
    color.laplace.solve(36.079037f,31.623268f,-20.452703f,12.692886f,10.866735f,-3.4594154f,3.8257725f,2.6102035f,-4.2516937f ) ;
  }

  @Test
  public void test410() {
    color.laplace.solve(36.093945f,36.80959f,17.706015f,7.565926f,-6.561051f,-65.98679f,0.7328457f,-4.634543f,-12.709968f ) ;
  }

  @Test
  public void test411() {
    color.laplace.solve(36.098034f,39.81943f,29.278282f,4.5727024f,-6.0985885f,-85.08016f,-11.708635f,-13.687883f,0f ) ;
  }

  @Test
  public void test412() {
    color.laplace.solve(-36.112465f,-12.014142f,86.88776f,-3.5977008f,19.786633f,83.40519f,1.9388226f,11.35375f,23.689547f ) ;
  }

  @Test
  public void test413() {
    color.laplace.solve(36.16504f,36.372963f,15.55646f,8.2872925f,-6.2297783f,-74.14741f,3.2138329f,4.568039f,38.29107f ) ;
  }

  @Test
  public void test414() {
    color.laplace.solve(36.24064f,38.138607f,17.297161f,6.823946f,-0.9833755f,-68.94996f,-7.961479f,-38.669865f,0f ) ;
  }

  @Test
  public void test415() {
    color.laplace.solve(36.24688f,28.319267f,-46.917103f,16.668247f,23.947294f,-21.10044f,6.4788175f,9.247023f,8.644434f ) ;
  }

  @Test
  public void test416() {
    color.laplace.solve(36.343285f,21.511965f,-94.296364f,23.861177f,44.000935f,94.0898f,15.1004925f,36.54079f,87.06174f ) ;
  }

  @Test
  public void test417() {
    color.laplace.solve(36.348972f,42.01105f,54.653282f,3.3848448f,-22.958048f,76.60207f,0.54830897f,-1.1916089f,17.643303f ) ;
  }

  @Test
  public void test418() {
    color.laplace.solve(36.351814f,41.33536f,37.276085f,4.071892f,-3.4177012f,7.768983f,-15.476596f,-65.97827f,-2.7824528f ) ;
  }

  @Test
  public void test419() {
    color.laplace.solve(36.37156f,42.60977f,39.34346f,2.8764842f,-5.275931f,14.645267f,-19.589691f,-81.235245f,24.11589f ) ;
  }

  @Test
  public void test420() {
    color.laplace.solve(36.378693f,31.568335f,2.991409f,13.946437f,-13.096765f,-26.925089f,32.503822f,-70.97674f,-97.595f ) ;
  }

  @Test
  public void test421() {
    color.laplace.solve(-3.6379774f,-100.0f,-53.1656f,-14.551912f,-46.471233f,-53.582104f,-8.0757065f,-17.750277f,-16.454168f ) ;
  }

  @Test
  public void test422() {
    color.laplace.solve(36.384087f,55.295273f,72.609474f,-9.758938f,12.187522f,22.822725f,-87.607376f,-19.609135f,6.493895f ) ;
  }

  @Test
  public void test423() {
    color.laplace.solve(36.431988f,34.6842f,-11.135669f,11.0437565f,6.5277996f,-13.433946f,1.2152361f,-6.1828117f,49.441826f ) ;
  }

  @Test
  public void test424() {
    color.laplace.solve(36.436024f,40.10076f,42.7737f,5.6433296f,-18.806671f,-18.395895f,4.943967f,14.132538f,70.39286f ) ;
  }

  @Test
  public void test425() {
    color.laplace.solve(36.47319f,37.29879f,16.634192f,8.593972f,-3.9122279f,23.385088f,1.8149248f,-1.3342725f,-3.239787f ) ;
  }

  @Test
  public void test426() {
    color.laplace.solve(36.486023f,39.979515f,30.457191f,5.9645777f,-5.094843f,-18.64879f,-5.5214157f,-28.05024f,-100.0f ) ;
  }

  @Test
  public void test427() {
    color.laplace.solve(36.51802f,36.285233f,14.854587f,9.786847f,-6.231679f,-76.86688f,8.861048f,25.657343f,100.0f ) ;
  }

  @Test
  public void test428() {
    color.laplace.solve(36.53968f,37.92205f,17.382252f,8.236697f,-2.2337239f,-41.42029f,-1.3591676f,-13.673359f,-99.794174f ) ;
  }

  @Test
  public void test429() {
    color.laplace.solve(36.582485f,38.03957f,19.862806f,8.290376f,-4.287228f,-58.711586f,0.8662504f,-4.825374f,-15.88424f ) ;
  }

  @Test
  public void test430() {
    color.laplace.solve(36.635273f,29.108698f,-42.60763f,17.432394f,19.704033f,-3.8536582f,13.390273f,36.128696f,7.488968f ) ;
  }

  @Test
  public void test431() {
    color.laplace.solve(36.642982f,38.13093f,19.4781f,8.440998f,-3.5973508f,-70.01343f,0.71835357f,-5.567584f,-19.391338f ) ;
  }

  @Test
  public void test432() {
    color.laplace.solve(36.689835f,28.449821f,-55.737858f,18.309519f,32.84731f,48.44102f,3.700931f,-3.5057948f,-50.57142f ) ;
  }

  @Test
  public void test433() {
    color.laplace.solve(36.69979f,37.6028f,17.445704f,9.196372f,-3.7343f,-67.819984f,3.819997f,6.083616f,-100.0f ) ;
  }

  @Test
  public void test434() {
    color.laplace.solve(36.708817f,33.106827f,-17.584713f,13.728431f,13.303209f,0.4992106f,4.9017f,5.878369f,5.3085666f ) ;
  }

  @Test
  public void test435() {
    color.laplace.solve(36.756367f,30.566305f,-43.08429f,16.459158f,19.464523f,8.828811f,9.615745f,22.003819f,58.935005f ) ;
  }

  @Test
  public void test436() {
    color.laplace.solve(36.766953f,40.516804f,29.063728f,6.54947f,-3.208854f,-24.307589f,-7.265819f,-35.59215f,-131.88155f ) ;
  }

  @Test
  public void test437() {
    color.laplace.solve(36.79501f,34.221607f,-18.682602f,12.958431f,10.835364f,-7.693542f,4.2033486f,3.8549638f,5.997263f ) ;
  }

  @Test
  public void test438() {
    color.laplace.solve(36.84147f,36.70643f,-26.708118f,10.659455f,35.699894f,22.797644f,-29.903547f,72.636055f,82.1988f ) ;
  }

  @Test
  public void test439() {
    color.laplace.solve(36.854305f,33.869316f,-15.114472f,13.547907f,12.945157f,-0.0627569f,4.392165f,4.7974763f,1.9693804f ) ;
  }

  @Test
  public void test440() {
    color.laplace.solve(36.860813f,37.264942f,19.99844f,10.178312f,-7.7994823f,-57.271183f,11.6519165f,-21.370003f,17.48692f ) ;
  }

  @Test
  public void test441() {
    color.laplace.solve(36.91611f,45.460293f,72.00273f,2.2041492f,-27.077665f,100.0f,-1.0218489f,-6.291545f,2.9333334f ) ;
  }

  @Test
  public void test442() {
    color.laplace.solve(36.947933f,29.861954f,-44.655483f,17.929775f,27.155363f,48.91712f,7.615807f,12.533454f,15.362644f ) ;
  }

  @Test
  public void test443() {
    color.laplace.solve(36.96853f,39.152195f,22.975397f,8.721909f,-3.3351412f,-47.250572f,1.254247f,-3.704946f,-12.738883f ) ;
  }

  @Test
  public void test444() {
    color.laplace.solve(-36.975624f,13.212926f,70.95426f,-3.6752403f,9.0943165f,-29.557041f,13.180346f,56.39662f,60.865646f ) ;
  }

  @Test
  public void test445() {
    color.laplace.solve(36.9776f,40.03512f,28.13306f,7.8752866f,-4.970186f,-61.530323f,-0.5062692f,-9.900363f,-34.124996f ) ;
  }

  @Test
  public void test446() {
    color.laplace.solve(37.014343f,40.266125f,29.425756f,7.791246f,-5.375603f,-22.563097f,-0.4737546f,-9.686265f,-32.895702f ) ;
  }

  @Test
  public void test447() {
    color.laplace.solve(37.03396f,31.109682f,15.912134f,17.026154f,18.6222f,100.0f,12.448454f,32.767662f,100.0f ) ;
  }

  @Test
  public void test448() {
    color.laplace.solve(37.04962f,31.544867f,99.14083f,16.653624f,22.876955f,33.21128f,6.687919f,10.098052f,10.8273325f ) ;
  }

  @Test
  public void test449() {
    color.laplace.solve(37.063553f,39.303032f,27.299719f,8.951176f,-7.1511703f,-30.10416f,5.892321f,-46.754726f,-72.93952f ) ;
  }

  @Test
  public void test450() {
    color.laplace.solve(37.13351f,31.625906f,-34.313255f,16.90812f,20.638844f,11.488992f,9.860125f,22.532358f,59.63038f ) ;
  }

  @Test
  public void test451() {
    color.laplace.solve(37.137165f,37.88008f,13.555471f,10.668574f,0.8276884f,-83.658195f,4.7094436f,8.169201f,-2.5872252f ) ;
  }

  @Test
  public void test452() {
    color.laplace.solve(3.7195282f,67.73377f,23.569784f,-5.3616323f,-3.0290136f,8.698353f,-22.137045f,-83.18655f,14.252643f ) ;
  }

  @Test
  public void test453() {
    color.laplace.solve(37.23969f,50.367813f,41.22212f,-1.40906f,23.009441f,-11.618772f,-65.88537f,54.697784f,0f ) ;
  }

  @Test
  public void test454() {
    color.laplace.solve(37.317993f,44.265697f,39.94167f,5.0062814f,-0.1968776f,23.330757f,-17.095991f,-73.39024f,53.578236f ) ;
  }

  @Test
  public void test455() {
    color.laplace.solve(37.328667f,43.590874f,31.928349f,5.7237926f,5.1064825f,-15.877481f,-19.539978f,-13.011255f,100.0f ) ;
  }

  @Test
  public void test456() {
    color.laplace.solve(37.37223f,42.413734f,32.57478f,7.075195f,-0.2920768f,-8.46454f,-8.779375f,-42.192696f,5.248077f ) ;
  }

  @Test
  public void test457() {
    color.laplace.solve(37.419594f,31.186037f,-41.70898f,18.492332f,29.033535f,54.88329f,7.516204f,11.572483f,52.902992f ) ;
  }

  @Test
  public void test458() {
    color.laplace.solve(37.490067f,39.98765f,23.709576f,9.972619f,-1.2496895f,-71.21816f,3.6485925f,4.622593f,16.090612f ) ;
  }

  @Test
  public void test459() {
    color.laplace.solve(37.499855f,35.37844f,12.4343605f,14.620982f,-8.420451f,-85.641f,0f,0f,0f ) ;
  }

  @Test
  public void test460() {
    color.laplace.solve(37.52603f,55.012707f,41.204704f,-4.9085755f,41.320095f,-27.4062f,-0.10815146f,4.47597f,-23.308064f ) ;
  }

  @Test
  public void test461() {
    color.laplace.solve(37.595455f,34.83445f,47.356884f,15.547372f,-45.614544f,54.59309f,70.20857f,-99.985954f,0f ) ;
  }

  @Test
  public void test462() {
    color.laplace.solve(37.600094f,40.016983f,22.314507f,10.383387f,0.81567067f,-50.75896f,3.500616f,3.6209934f,10.167686f ) ;
  }

  @Test
  public void test463() {
    color.laplace.solve(37.627285f,45.390453f,43.677082f,5.1187086f,0.2574394f,25.278864f,-17.40989f,-74.75826f,5.2684054f ) ;
  }

  @Test
  public void test464() {
    color.laplace.solve(37.635517f,36.525227f,12.045506f,14.016841f,-3.5801203f,-88.3432f,-1.6726851f,-20.70758f,0f ) ;
  }

  @Test
  public void test465() {
    color.laplace.solve(37.665997f,48.418274f,45.96745f,2.245713f,10.039655f,-27.511967f,-31.389915f,80.75443f,0f ) ;
  }

  @Test
  public void test466() {
    color.laplace.solve(37.68983f,21.087643f,-78.083595f,29.671675f,24.311499f,-100.0f,56.68537f,100.0f,0f ) ;
  }

  @Test
  public void test467() {
    color.laplace.solve(37.712215f,38.580482f,4.4941373f,12.268381f,12.115571f,-19.587915f,-0.7542618f,-15.285428f,-72.50302f ) ;
  }

  @Test
  public void test468() {
    color.laplace.solve(37.747246f,41.069508f,26.411419f,9.919477f,0.1193695f,-47.837204f,1.8112934f,-2.6743035f,-12.627877f ) ;
  }

  @Test
  public void test469() {
    color.laplace.solve(37.757153f,40.12473f,21.536625f,10.908467f,1.2061787f,-53.978226f,4.670846f,7.7742662f,-15.764522f ) ;
  }

  @Test
  public void test470() {
    color.laplace.solve(37.758068f,39.370914f,31.48916f,11.551979f,-11.757277f,-165.24377f,19.854723f,67.36378f,-134.24055f ) ;
  }

  @Test
  public void test471() {
    color.laplace.solve(37.7807f,42.082928f,29.175016f,9.039778f,1.3759948f,-25.38286f,-2.9975832f,-21.030088f,-82.498764f ) ;
  }

  @Test
  public void test472() {
    color.laplace.solve(37.807755f,33.229298f,27.805738f,18.00172f,-32.6963f,-35.22677f,2.3466313f,-8.615196f,0f ) ;
  }

  @Test
  public void test473() {
    color.laplace.solve(37.87848f,34.339638f,99.99997f,17.174278f,23.909464f,33.66153f,6.9091706f,10.462404f,11.030984f ) ;
  }

  @Test
  public void test474() {
    color.laplace.solve(37.88036f,27.47325f,-70.47516f,24.048183f,42.487797f,82.41359f,15.824582f,36.016155f,-14.373228f ) ;
  }

  @Test
  public void test475() {
    color.laplace.solve(37.92417f,31.19577f,-21.519308f,20.500916f,8.378216f,50.669525f,35.701275f,-68.85335f,-99.851166f ) ;
  }

  @Test
  public void test476() {
    color.laplace.solve(37.94713f,45.601505f,-100.0f,6.1870127f,-12.103839f,-88.29136f,-1.0952394f,-10.56797f,-12.816335f ) ;
  }

  @Test
  public void test477() {
    color.laplace.solve(37.948696f,44.88102f,-44.139496f,6.9137654f,-6.4842086f,15.78902f,1.626643f,-0.40719354f,3.2287915f ) ;
  }

  @Test
  public void test478() {
    color.laplace.solve(37.972687f,40.93958f,23.579725f,10.951179f,2.205905f,-46.62069f,3.6261876f,3.553572f,8.382218f ) ;
  }

  @Test
  public void test479() {
    color.laplace.solve(37.998146f,41.95051f,27.479198f,10.042078f,2.3246818f,-32.03372f,-0.15451576f,-10.660141f,-44.81073f ) ;
  }

  @Test
  public void test480() {
    color.laplace.solve(38.00486f,39.047337f,14.632497f,12.972102f,3.551985f,-80.51735f,10.331565f,28.354156f,99.53307f ) ;
  }

  @Test
  public void test481() {
    color.laplace.solve(38.033607f,42.581028f,29.701777f,9.546843f,2.5909703f,-22.469366f,-2.437209f,-19.295897f,-77.34839f ) ;
  }

  @Test
  public void test482() {
    color.laplace.solve(38.037254f,13.33448f,-10.385263f,38.81453f,-74.31407f,-44.408375f,3.279403f,-25.696918f,0.039598536f ) ;
  }

  @Test
  public void test483() {
    color.laplace.solve(38.038876f,41.153248f,19.1166f,11.001158f,7.460032f,-64.68685f,-1.4942737f,-16.98351f,-73.90365f ) ;
  }

  @Test
  public void test484() {
    color.laplace.solve(38.057632f,37.926376f,-24.56713f,14.30416f,14.124488f,-1.5664976f,5.0345187f,5.8339143f,4.1766505f ) ;
  }

  @Test
  public void test485() {
    color.laplace.solve(38.058464f,41.67503f,26.709412f,10.558832f,2.0253923f,-42.37623f,2.1987178f,-1.7334958f,-11.034571f ) ;
  }

  @Test
  public void test486() {
    color.laplace.solve(38.064087f,34.75379f,20.325037f,17.502552f,-12.708437f,-14.603969f,44.65456f,-88.48612f,-66.03248f ) ;
  }

  @Test
  public void test487() {
    color.laplace.solve(38.1169f,37.19572f,-5.9127417f,15.271889f,16.578718f,3.5514162f,6.391935f,10.295851f,53.75846f ) ;
  }

  @Test
  public void test488() {
    color.laplace.solve(38.121395f,39.87629f,13.717972f,12.609297f,7.6671987f,-27.809399f,4.6501083f,5.992609f,11.654436f ) ;
  }

  @Test
  public void test489() {
    color.laplace.solve(38.131817f,33.427357f,-38.48318f,19.099916f,34.060787f,85.987526f,4.207065f,-2.2716575f,-47.35448f ) ;
  }

  @Test
  public void test490() {
    color.laplace.solve(38.136166f,41.53579f,33.932293f,11.008897f,-5.9425426f,-5.806514f,11.827415f,-70.50834f,-51.215805f ) ;
  }

  @Test
  public void test491() {
    color.laplace.solve(38.13713f,51.15193f,42.71067f,1.3965902f,23.759918f,19.690756f,-56.310688f,22.800396f,0f ) ;
  }

  @Test
  public void test492() {
    color.laplace.solve(38.15093f,34.79816f,-21.479649f,17.805548f,22.521358f,13.087656f,10.549905f,24.394073f,39.740047f ) ;
  }

  @Test
  public void test493() {
    color.laplace.solve(38.153435f,45.14078f,39.069275f,7.472963f,3.3404193f,11.136315f,2.4391506f,2.2836397f,3.3549888f ) ;
  }

  @Test
  public void test494() {
    color.laplace.solve(38.1614f,37.794434f,-2.5736883f,14.851164f,15.61477f,3.7667074f,5.496286f,5.9757543f,2.1797953f ) ;
  }

  @Test
  public void test495() {
    color.laplace.solve(38.209717f,40.614563f,30.366627f,12.333516f,-3.3750796f,-19.103937f,14.670302f,-47.24965f,-164.17169f ) ;
  }

  @Test
  public void test496() {
    color.laplace.solve(38.22423f,43.975807f,58.128445f,8.921124f,-0.51554275f,-37.941216f,-2.024191f,-17.017889f,100.0f ) ;
  }

  @Test
  public void test497() {
    color.laplace.solve(38.284496f,32.08017f,25.905504f,21.057821f,30.45236f,28.636076f,15.494427f,45.10529f,0f ) ;
  }

  @Test
  public void test498() {
    color.laplace.solve(38.312172f,43.487946f,31.84946f,9.76075f,3.7901437f,-16.0901f,-3.0593178f,-21.99802f,-100.0f ) ;
  }

  @Test
  public void test499() {
    color.laplace.solve(38.31364f,48.4477f,7.8871207f,4.8068657f,47.590034f,44.459827f,-66.67621f,-27.19561f,0f ) ;
  }

  @Test
  public void test500() {
    color.laplace.solve(38.321747f,43.953568f,34.442875f,9.33345f,3.0496461f,-15.626735f,-4.037486f,-25.246817f,-99.99944f ) ;
  }

  @Test
  public void test501() {
    color.laplace.solve(38.36081f,43.670906f,32.30569f,9.772338f,4.017116f,-14.448138f,-3.2885756f,-22.926641f,-14.13543f ) ;
  }

  @Test
  public void test502() {
    color.laplace.solve(38.39105f,42.269142f,26.541973f,11.295046f,4.1435513f,-37.847157f,2.6455846f,-0.71270764f,-9.639967f ) ;
  }

  @Test
  public void test503() {
    color.laplace.solve(38.402496f,49.8367f,62.163506f,3.7732775f,-1.2249832f,33.64656f,-22.096842f,-92.15945f,73.64772f ) ;
  }

  @Test
  public void test504() {
    color.laplace.solve(38.415375f,38.620335f,-0.111155786f,15.041161f,16.179146f,4.750946f,5.4698944f,6.3041434f,2.984986f ) ;
  }

  @Test
  public void test505() {
    color.laplace.solve(38.441097f,42.10148f,39.651974f,11.662915f,-9.687165f,-30.481577f,17.89773f,-69.67222f,0f ) ;
  }

  @Test
  public void test506() {
    color.laplace.solve(38.539642f,44.048107f,37.55881f,10.110422f,0.09362535f,-50.898273f,1.8061813f,-2.8865485f,-13.446001f ) ;
  }

  @Test
  public void test507() {
    color.laplace.solve(38.555695f,31.104063f,32.32527f,23.118711f,38.51953f,61.375553f,15.399625f,38.47979f,100.0f ) ;
  }

  @Test
  public void test508() {
    color.laplace.solve(38.567493f,38.946278f,-6.9553638f,15.3236885f,18.361305f,17.035118f,4.365957f,2.1401384f,56.734528f ) ;
  }

  @Test
  public void test509() {
    color.laplace.solve(38.59037f,47.822815f,49.053516f,6.538669f,3.6473374f,31.06766f,-16.077442f,-70.8398f,-92.78602f ) ;
  }

  @Test
  public void test510() {
    color.laplace.solve(38.612484f,35.59622f,-24.32905f,18.853193f,28.101435f,42.01414f,8.698352f,15.941654f,26.96683f ) ;
  }

  @Test
  public void test511() {
    color.laplace.solve(38.616714f,34.78296f,-25.871346f,19.683903f,26.386463f,15.833158f,13.732433f,35.24583f,99.999535f ) ;
  }

  @Test
  public void test512() {
    color.laplace.solve(38.626522f,44.475773f,33.863056f,10.029979f,5.413513f,-7.142221f,-3.919957f,-25.709806f,-67.84545f ) ;
  }

  @Test
  public void test513() {
    color.laplace.solve(38.661057f,36.73485f,-18.849792f,17.909374f,27.128147f,-49.64858f,5.8482966f,5.4838133f,-11.041191f ) ;
  }

  @Test
  public void test514() {
    color.laplace.solve(38.68681f,51.365692f,43.38742f,3.3815413f,23.389362f,22.184029f,-48.549786f,16.62619f,-37.742363f ) ;
  }

  @Test
  public void test515() {
    color.laplace.solve(38.68813f,47.37176f,47.148262f,7.380752f,3.6506531f,41.221283f,-12.815773f,-99.98673f,0f ) ;
  }

  @Test
  public void test516() {
    color.laplace.solve(38.75657f,56.841434f,161.03697f,-1.8151581f,-72.42786f,185.80168f,4.206762f,0f,0f ) ;
  }

  @Test
  public void test517() {
    color.laplace.solve(38.780457f,40.597527f,-100.0f,14.524299f,9.816854f,100.0f,9.4998865f,23.475246f,74.58424f ) ;
  }

  @Test
  public void test518() {
    color.laplace.solve(38.828346f,51.323845f,32.88473f,3.9895391f,33.58231f,-19.784922f,-56.4525f,98.800766f,-86.48266f ) ;
  }

  @Test
  public void test519() {
    color.laplace.solve(38.848347f,48.37661f,48.36535f,7.0172133f,6.292928f,45.084793f,-17.072422f,-75.30645f,95.86395f ) ;
  }

  @Test
  public void test520() {
    color.laplace.solve(38.868958f,43.391556f,25.250639f,12.084271f,9.446632f,-5.6910076f,0.021494513f,-11.998294f,-57.461304f ) ;
  }

  @Test
  public void test521() {
    color.laplace.solve(38.903008f,31.425674f,-44.80903f,24.186352f,31.608717f,-9.925531f,26.233683f,80.748375f,-26.501816f ) ;
  }

  @Test
  public void test522() {
    color.laplace.solve(38.91572f,46.772915f,51.84653f,8.889966f,-3.6705904f,-100.0f,0.3147352f,-7.6310253f,-27.168247f ) ;
  }

  @Test
  public void test523() {
    color.laplace.solve(38.917427f,42.769257f,32.738693f,12.902631f,-0.5790899f,-11.513329f,13.271878f,-46.47492f,-78.21294f ) ;
  }

  @Test
  public void test524() {
    color.laplace.solve(38.932f,61.384594f,-100.0f,-5.6566043f,-44.035805f,-85.28894f,-6.1835933f,-19.077768f,-26.091677f ) ;
  }

  @Test
  public void test525() {
    color.laplace.solve(39.009136f,45.001015f,4.835281f,11.035528f,6.3791394f,-14.499813f,-1.2461613f,-16.020174f,-69.21368f ) ;
  }

  @Test
  public void test526() {
    color.laplace.solve(39.01828f,51.244125f,41.497692f,4.829004f,24.46052f,14.746649f,-44.162785f,27.022303f,17.663235f ) ;
  }

  @Test
  public void test527() {
    color.laplace.solve(39.01928f,43.342495f,23.926838f,12.734625f,10.423804f,-47.635143f,2.1467998f,-4.147426f,-29.160309f ) ;
  }

  @Test
  public void test528() {
    color.laplace.solve(39.02589f,36.878277f,-21.232748f,19.225279f,29.720228f,49.385174f,8.154721f,13.392419f,15.694399f ) ;
  }

  @Test
  public void test529() {
    color.laplace.solve(39.028316f,42.976192f,22.657055f,13.137075f,10.219401f,-52.347977f,3.3005836f,0.06525851f,-13.25895f ) ;
  }

  @Test
  public void test530() {
    color.laplace.solve(39.044334f,36.019222f,-26.553236f,20.158113f,31.585785f,-100.0f,10.002336f,19.851229f,37.81679f ) ;
  }

  @Test
  public void test531() {
    color.laplace.solve(39.085377f,46.512447f,39.62869f,9.829054f,7.424861f,12.059814f,-7.194019f,-38.663284f,1.1857088f ) ;
  }

  @Test
  public void test532() {
    color.laplace.solve(39.111416f,43.740887f,28.33218f,12.704783f,7.5199485f,-30.412165f,4.187768f,4.046289f,-100.0f ) ;
  }

  @Test
  public void test533() {
    color.laplace.solve(39.183125f,44.475945f,26.52951f,12.256561f,12.19114f,31.10982f,-2.3480234f,-21.648655f,-8.622262f ) ;
  }

  @Test
  public void test534() {
    color.laplace.solve(39.20812f,45.6855f,35.47595f,11.392842f,8.057942f,-6.6508427f,-1.6082846f,-17.825981f,-77.73951f ) ;
  }

  @Test
  public void test535() {
    color.laplace.solve(39.212578f,45.7011f,28.003868f,11.149213f,15.587947f,57.465385f,-10.203674f,-51.96391f,100.0f ) ;
  }

  @Test
  public void test536() {
    color.laplace.solve(39.257168f,70.463806f,-100.0f,-13.435131f,3.7812753f,-26.254995f,-96.77897f,-15.648576f,0f ) ;
  }

  @Test
  public void test537() {
    color.laplace.solve(39.265312f,44.567265f,35.20681f,12.49398f,3.7969422f,-3.7400193f,6.9136677f,-38.133457f,-53.963833f ) ;
  }

  @Test
  public void test538() {
    color.laplace.solve(39.26727f,44.47415f,41.437035f,12.594919f,-2.8076942f,21.273985f,13.920103f,43.085495f,0f ) ;
  }

  @Test
  public void test539() {
    color.laplace.solve(39.32462f,42.468586f,89.511795f,14.831367f,17.430689f,17.079079f,2.5437727f,-4.6562757f,-38.626167f ) ;
  }

  @Test
  public void test540() {
    color.laplace.solve(39.347622f,42.67804f,22.74479f,14.710443f,8.619744f,-51.698696f,10.874358f,28.789192f,95.663246f ) ;
  }

  @Test
  public void test541() {
    color.laplace.solve(39.409126f,44.951454f,65.205215f,12.685058f,8.218248f,10.006318f,3.1128552f,-0.23363753f,-12.265654f ) ;
  }

  @Test
  public void test542() {
    color.laplace.solve(39.41031f,54.43402f,52.597733f,3.2072208f,25.728037f,39.490578f,-52.309464f,5.780326f,79.63655f ) ;
  }

  @Test
  public void test543() {
    color.laplace.solve(39.456974f,41.016926f,-59.908173f,16.810968f,19.113037f,0.7397832f,8.67386f,17.884472f,43.754265f ) ;
  }

  @Test
  public void test544() {
    color.laplace.solve(39.477722f,48.46247f,45.644398f,9.448417f,8.727772f,28.095922f,-10.411827f,-51.095726f,28.771555f ) ;
  }

  @Test
  public void test545() {
    color.laplace.solve(39.482883f,46.446648f,44.43248f,11.484883f,1.8712225f,31.073818f,3.7648563f,3.5745423f,8.66209f ) ;
  }

  @Test
  public void test546() {
    color.laplace.solve(39.550392f,37.48245f,-24.021355f,20.719124f,34.400764f,51.42898f,8.925337f,14.982225f,16.602802f ) ;
  }

  @Test
  public void test547() {
    color.laplace.solve(39.567074f,49.93128f,50.855553f,8.336759f,9.302482f,49.372784f,-15.523534f,-70.43089f,62.612534f ) ;
  }

  @Test
  public void test548() {
    color.laplace.solve(39.574703f,46.216774f,35.692394f,12.082044f,9.599998f,-4.4306684f,-0.84652835f,-15.468157f,-70.6261f ) ;
  }

  @Test
  public void test549() {
    color.laplace.solve(39.63559f,44.054234f,26.813494f,14.486124f,9.767761f,-36.801697f,8.541145f,19.678255f,60.404114f ) ;
  }

  @Test
  public void test550() {
    color.laplace.solve(39.639782f,43.63158f,-79.76677f,14.927543f,13.869722f,-12.955359f,6.200667f,9.875126f,19.430115f ) ;
  }

  @Test
  public void test551() {
    color.laplace.solve(39.642666f,47.220303f,39.239437f,11.350363f,9.999111f,9.737439f,-4.240325f,-28.311663f,-51.322784f ) ;
  }

  @Test
  public void test552() {
    color.laplace.solve(39.65226f,46.551136f,36.92186f,12.057904f,9.630426f,-3.825161f,-1.0510676f,-16.262175f,-73.62806f ) ;
  }

  @Test
  public void test553() {
    color.laplace.solve(39.686775f,56.079243f,-69.51153f,2.667855f,-11.641022f,-33.145996f,-17.374332f,-72.165184f,-51.431435f ) ;
  }

  @Test
  public void test554() {
    color.laplace.solve(39.72199f,39.18897f,-10.033189f,19.698978f,27.066952f,21.052053f,12.006777f,28.327806f,69.40515f ) ;
  }

  @Test
  public void test555() {
    color.laplace.solve(3.9780183f,-87.09317f,-58.079006f,3.0052402f,3.727833f,84.74406f,4.3151097f,14.255199f,48.977856f ) ;
  }

  @Test
  public void test556() {
    color.laplace.solve(39.821247f,35.107662f,-50.39694f,24.177317f,51.006332f,41.26326f,5.881693f,-0.6503694f,-59.489483f ) ;
  }

  @Test
  public void test557() {
    color.laplace.solve(-39.821426f,25.972342f,-11.439655f,-38.642353f,-26.10391f,-75.70184f,-88.64408f,-16.043785f,-38.826485f ) ;
  }

  @Test
  public void test558() {
    color.laplace.solve(39.836315f,41.19357f,-0.5789f,18.1517f,25.516863f,31.859426f,7.2536135f,10.862755f,10.680545f ) ;
  }

  @Test
  public void test559() {
    color.laplace.solve(39.851696f,57.58129f,49.33255f,1.8254977f,41.14091f,25.89459f,-73.69062f,79.262276f,9.2744465f ) ;
  }

  @Test
  public void test560() {
    color.laplace.solve(39.87334f,56.622902f,90.77403f,2.870452f,-4.1557603f,23.69714f,-24.235771f,-99.81354f,8.170288f ) ;
  }

  @Test
  public void test561() {
    color.laplace.solve(-39.97899f,90.04494f,0f,27.819912f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test562() {
    color.laplace.solve(40.111824f,48.09762f,27.41822f,12.349674f,24.860432f,-38.424736f,-15.573558f,-74.643906f,0f ) ;
  }

  @Test
  public void test563() {
    color.laplace.solve(40.14813f,49.05519f,54.645885f,11.448574f,1.4267538f,58.991364f,4.222142f,5.4399934f,16.111074f ) ;
  }

  @Test
  public void test564() {
    color.laplace.solve(40.24245f,33.865463f,-14.764756f,27.104336f,6.199483f,0f,-11.614083f,0f,0f ) ;
  }

  @Test
  public void test565() {
    color.laplace.solve(40.27346f,46.976788f,34.155746f,14.413584f,13.47794f,-10.998798f,4.4741063f,3.5916543f,-91.77182f ) ;
  }

  @Test
  public void test566() {
    color.laplace.solve(40.27989f,52.300156f,36.952175f,8.819402f,31.968555f,-4.49146f,-36.970837f,71.246124f,-48.250053f ) ;
  }

  @Test
  public void test567() {
    color.laplace.solve(40.35412f,48.61327f,40.788883f,12.80174f,13.31689f,14.475304f,-2.4552536f,-22.622755f,3.7945986f ) ;
  }

  @Test
  public void test568() {
    color.laplace.solve(40.419888f,44.497437f,-70.582825f,17.182117f,19.49456f,-1.775261f,8.814016f,18.07395f,43.98722f ) ;
  }

  @Test
  public void test569() {
    color.laplace.solve(40.43873f,42.645252f,34.510937f,19.109667f,-4.368662f,-4.601507f,40.368603f,-74.62806f,-48.5483f ) ;
  }

  @Test
  public void test570() {
    color.laplace.solve(40.452187f,27.260807f,-100.0f,34.54793f,82.43525f,55.951782f,15.304301f,26.669273f,8.937543f ) ;
  }

  @Test
  public void test571() {
    color.laplace.solve(-40.493546f,71.70481f,82.996414f,-3.426227f,26.65727f,34.398804f,0.1313668f,3.9516945f,27.941528f ) ;
  }

  @Test
  public void test572() {
    color.laplace.solve(40.523525f,42.97211f,5.49297f,19.123394f,25.871836f,20.120062f,10.098216f,21.271776f,49.11705f ) ;
  }

  @Test
  public void test573() {
    color.laplace.solve(40.528843f,48.027725f,37.460873f,14.087652f,14.121189f,1.6547264f,1.7005763f,-7.2853475f,-44.963158f ) ;
  }

  @Test
  public void test574() {
    color.laplace.solve(40.534084f,51.60061f,20.313835f,10.535726f,45.554516f,-70.34527f,-57.036232f,100.0f,0f ) ;
  }

  @Test
  public void test575() {
    color.laplace.solve(40.548145f,50.59292f,47.60312f,11.59967f,14.226743f,39.819553f,-8.376841f,-45.107044f,-100.0f ) ;
  }

  @Test
  public void test576() {
    color.laplace.solve(40.581215f,47.81918f,36.3165f,14.505678f,14.379001f,-2.553171f,3.0624988f,-2.2556832f,-99.88842f ) ;
  }

  @Test
  public void test577() {
    color.laplace.solve(40.616814f,57.861942f,44.847385f,4.6053047f,45.983578f,21.527597f,-68.17917f,99.93946f,-68.29221f ) ;
  }

  @Test
  public void test578() {
    color.laplace.solve(40.63727f,45.7024f,21.613941f,16.846687f,20.558393f,11.766832f,6.1910844f,7.9176497f,4.9211206f ) ;
  }

  @Test
  public void test579() {
    color.laplace.solve(40.701214f,47.50836f,29.045233f,15.298147f,20.287844f,-31.327427f,0.2035332f,-14.483434f,21.974436f ) ;
  }

  @Test
  public void test580() {
    color.laplace.solve(40.70634f,45.58062f,23.3583f,17.24474f,18.25784f,-12.608378f,10.01478f,22.814379f,-92.04965f ) ;
  }

  @Test
  public void test581() {
    color.laplace.solve(40.748734f,47.93539f,36.378437f,15.059548f,14.614393f,-8.814669f,4.875066f,4.440714f,-1.7266034f ) ;
  }

  @Test
  public void test582() {
    color.laplace.solve(40.749752f,48.103916f,37.571144f,14.895094f,14.092066f,-10.668566f,4.7332277f,4.037816f,-2.675465f ) ;
  }

  @Test
  public void test583() {
    color.laplace.solve(40.780323f,44.311203f,34.55896f,18.810091f,1.9055228f,25.059464f,32.55452f,-80.55866f,-19.621258f ) ;
  }

  @Test
  public void test584() {
    color.laplace.solve(40.78055f,45.691902f,25.513561f,17.430294f,16.473505f,-43.63766f,11.865981f,30.03363f,91.79504f ) ;
  }

  @Test
  public void test585() {
    color.laplace.solve(40.781284f,48.53251f,38.03611f,14.592626f,15.312651f,3.6119256f,2.276542f,-5.486459f,-39.535027f ) ;
  }

  @Test
  public void test586() {
    color.laplace.solve(40.80018f,47.273827f,33.14123f,15.922842f,15.153901f,-17.599758f,7.734996f,15.017141f,12.178922f ) ;
  }

  @Test
  public void test587() {
    color.laplace.solve(40.862347f,45.054512f,15.711512f,18.394869f,23.644194f,-100.0f,9.072934f,17.89687f,38.870346f ) ;
  }

  @Test
  public void test588() {
    color.laplace.solve(40.908894f,45.516434f,39.98505f,18.119146f,1.1717864f,-65.550354f,30.395864f,6.601946f,-18.130941f ) ;
  }

  @Test
  public void test589() {
    color.laplace.solve(40.927086f,53.215656f,40.775276f,10.492691f,31.160269f,8.790777f,-30.11659f,52.14195f,-63.98373f ) ;
  }

  @Test
  public void test590() {
    color.laplace.solve(40.93365f,46.669594f,24.68959f,17.065002f,21.05495f,12.464726f,6.2713714f,8.020478f,4.7555947f ) ;
  }

  @Test
  public void test591() {
    color.laplace.solve(40.983665f,44.05127f,19.118486f,19.8834f,16.102917f,-67.577324f,22.447014f,68.05432f,30.622335f ) ;
  }

  @Test
  public void test592() {
    color.laplace.solve(41.043537f,46.97868f,25.498444f,17.195465f,21.372736f,13.049921f,6.3655863f,8.266881f,5.3292003f ) ;
  }

  @Test
  public void test593() {
    color.laplace.solve(41.090115f,51.040806f,43.94503f,13.31978f,19.128094f,24.739317f,-6.9391074f,-12.58753f,0f ) ;
  }

  @Test
  public void test594() {
    color.laplace.solve(41.1616f,45.672462f,-46.016182f,18.973938f,87.544426f,-99.9092f,5.380331f,2.5473864f,0f ) ;
  }

  @Test
  public void test595() {
    color.laplace.solve(41.19356f,52.995453f,67.30601f,11.7788f,3.4822433f,-48.824078f,2.439399f,-2.021204f,-14.006456f ) ;
  }

  @Test
  public void test596() {
    color.laplace.solve(41.23612f,41.97993f,-12.696741f,22.96456f,39.380337f,70.57424f,11.241779f,22.002625f,37.38838f ) ;
  }

  @Test
  public void test597() {
    color.laplace.solve(41.367626f,51.380966f,77.43502f,14.089538f,9.674228f,-33.949238f,5.316296f,7.1756473f,-100.0f ) ;
  }

  @Test
  public void test598() {
    color.laplace.solve(41.374905f,64.68616f,99.98312f,0.81345755f,17.386604f,54.34243f,-55.50768f,-50.295628f,99.999985f ) ;
  }

  @Test
  public void test599() {
    color.laplace.solve(41.392826f,46.637623f,21.842505f,18.933678f,23.315155f,-59.267605f,11.026731f,25.173244f,66.3511f ) ;
  }

  @Test
  public void test600() {
    color.laplace.solve(41.405544f,48.67126f,35.053608f,16.950924f,18.225882f,-8.456822f,8.172272f,15.738162f,-80.845085f ) ;
  }

  @Test
  public void test601() {
    color.laplace.solve(41.411167f,47.290943f,18.998789f,18.358599f,28.752584f,-71.2625f,-4.978219f,-38.26138f,-176.84381f ) ;
  }

  @Test
  public void test602() {
    color.laplace.solve(4.142854f,-82.36776f,5.578286f,-1.0608257f,-7.2090445f,58.240032f,-1.1771128f,-3.6476257f,-6.2043457f ) ;
  }

  @Test
  public void test603() {
    color.laplace.solve(41.429573f,50.458477f,42.049797f,15.259824f,18.359829f,17.745445f,1.3103513f,-10.019703f,-99.45219f ) ;
  }

  @Test
  public void test604() {
    color.laplace.solve(41.429913f,48.11693f,-22.69242f,17.602724f,21.34067f,73.02079f,7.640311f,-53.377766f,-34.084213f ) ;
  }

  @Test
  public void test605() {
    color.laplace.solve(41.49933f,43.46738f,69.81621f,22.529928f,33.67876f,31.562693f,14.941626f,37.155037f,100.0f ) ;
  }

  @Test
  public void test606() {
    color.laplace.solve(41.568054f,49.993668f,39.422363f,16.278547f,18.984251f,7.6957874f,4.5618877f,1.969002f,-100.0f ) ;
  }

  @Test
  public void test607() {
    color.laplace.solve(41.657326f,52.95425f,51.149303f,13.67505f,19.010235f,46.999714f,-5.9674015f,-37.588043f,7.566217f ) ;
  }

  @Test
  public void test608() {
    color.laplace.solve(41.669754f,54.77204f,57.95956f,11.906972f,19.458847f,77.0662f,-13.500713f,-65.90983f,9.972144f ) ;
  }

  @Test
  public void test609() {
    color.laplace.solve(41.685093f,51.96217f,45.89339f,14.77821f,20.270187f,31.611395f,-2.842441f,-17.271027f,55.377342f ) ;
  }

  @Test
  public void test610() {
    color.laplace.solve(41.724533f,43.76289f,-4.965181f,23.13524f,38.292213f,27.459772f,12.524215f,58.810947f,76.512054f ) ;
  }

  @Test
  public void test611() {
    color.laplace.solve(41.733246f,54.068405f,67.721886f,12.864571f,6.8184924f,-38.420616f,2.9065452f,-1.2383901f,-14.678598f ) ;
  }

  @Test
  public void test612() {
    color.laplace.solve(41.754616f,54.354282f,66.662415f,12.664184f,9.000095f,-17.961994f,-0.09797627f,-13.056088f,-61.126476f ) ;
  }

  @Test
  public void test613() {
    color.laplace.solve(41.756844f,52.412975f,42.07145f,14.614404f,25.8236f,15.872826f,-9.122829f,-52.397026f,0f ) ;
  }

  @Test
  public void test614() {
    color.laplace.solve(41.81156f,40.239895f,36.878185f,27.00636f,-17.730167f,7.2728043f,9.803557f,12.207871f,56.758083f ) ;
  }

  @Test
  public void test615() {
    color.laplace.solve(41.83283f,49.42931f,34.315083f,17.902f,21.569332f,4.0246363f,8.205845f,14.921378f,29.910337f ) ;
  }

  @Test
  public void test616() {
    color.laplace.solve(41.865414f,51.21595f,42.626453f,16.245708f,20.371937f,19.28987f,2.7454817f,-5.2637825f,-80.43883f ) ;
  }

  @Test
  public void test617() {
    color.laplace.solve(41.887074f,50.2718f,39.386017f,17.276495f,20.802464f,7.2722735f,6.416445f,8.389285f,-31.099386f ) ;
  }

  @Test
  public void test618() {
    color.laplace.solve(41.91386f,51.612995f,43.940113f,16.042442f,20.598013f,24.147459f,1.6578988f,-9.410849f,-59.899303f ) ;
  }

  @Test
  public void test619() {
    color.laplace.solve(41.93688f,55.831326f,79.39192f,11.888713f,1.9779825f,-62.53077f,3.6371715f,2.7226605f,5.2754884f ) ;
  }

  @Test
  public void test620() {
    color.laplace.solve(41.944454f,51.367966f,45.473324f,16.403479f,18.056997f,-1.6055051f,5.615377f,6.061991f,0.5755909f ) ;
  }

  @Test
  public void test621() {
    color.laplace.solve(41.972416f,49.74372f,44.10413f,18.145945f,12.898341f,19.153101f,17.713022f,-35.4494f,11.287269f ) ;
  }

  @Test
  public void test622() {
    color.laplace.solve(41.977013f,52.007824f,84.6106f,15.900229f,22.419521f,40.85259f,-0.7955964f,-19.082615f,-97.9548f ) ;
  }

  @Test
  public void test623() {
    color.laplace.solve(41.982063f,54.614067f,58.913845f,13.314185f,17.560356f,40.770073f,-6.285678f,-38.456898f,86.606094f ) ;
  }

  @Test
  public void test624() {
    color.laplace.solve(41.992657f,52.14079f,45.522667f,15.829834f,21.047838f,30.93519f,0.27884284f,-14.714463f,57.170258f ) ;
  }

  @Test
  public void test625() {
    color.laplace.solve(42.04255f,35.613876f,-56.404808f,32.556316f,56.81777f,66.19742f,31.364944f,92.903465f,55.466187f ) ;
  }

  @Test
  public void test626() {
    color.laplace.solve(42.113613f,54.79046f,55.518017f,13.664f,21.530201f,67.28161f,-8.987816f,-49.615265f,-10.287226f ) ;
  }

  @Test
  public void test627() {
    color.laplace.solve(42.119114f,48.841835f,31.692375f,19.634615f,21.555868f,-22.072338f,14.863493f,39.819355f,11.883856f ) ;
  }

  @Test
  public void test628() {
    color.laplace.solve(42.13199f,61.01432f,75.15687f,7.513637f,-13.279524f,2.2072248f,1.2020825f,-2.7053072f,1.2562126f ) ;
  }

  @Test
  public void test629() {
    color.laplace.solve(42.158257f,51.020466f,40.280952f,17.61256f,21.64265f,8.952806f,6.6493335f,8.984774f,-26.11238f ) ;
  }

  @Test
  public void test630() {
    color.laplace.solve(42.16534f,53.057858f,48.294582f,15.603498f,21.77162f,40.12047f,-1.5229608f,-21.695343f,90.41567f ) ;
  }

  @Test
  public void test631() {
    color.laplace.solve(42.19914f,50.347183f,37.26028f,18.449371f,21.929314f,-1.3060648f,9.669034f,20.226765f,59.88064f ) ;
  }

  @Test
  public void test632() {
    color.laplace.solve(42.247444f,51.257496f,40.634007f,17.732285f,22.148533f,11.278537f,6.5331593f,8.400353f,4.9197226f ) ;
  }

  @Test
  public void test633() {
    color.laplace.solve(42.251938f,26.86777f,-13.727234f,42.13998f,-21.053625f,-25.376457f,3.1672702f,-29.4709f,-99.99724f ) ;
  }

  @Test
  public void test634() {
    color.laplace.solve(42.25868f,45.12781f,18.69362f,23.906902f,19.558945f,25.78436f,33.80999f,-16.583294f,64.88488f ) ;
  }

  @Test
  public void test635() {
    color.laplace.solve(42.2963f,48.52531f,18.043726f,20.659882f,33.761215f,-76.35041f,6.5820117f,5.6681666f,-17.67056f ) ;
  }

  @Test
  public void test636() {
    color.laplace.solve(42.337025f,51.31189f,41.044773f,18.036207f,21.865765f,4.3830104f,7.942039f,13.731949f,-53.82193f ) ;
  }

  @Test
  public void test637() {
    color.laplace.solve(42.352234f,56.083763f,59.94679f,13.325179f,22.03602f,76.41048f,-11.087539f,-57.675335f,100.0f ) ;
  }

  @Test
  public void test638() {
    color.laplace.solve(42.388523f,54.27139f,41.447468f,15.282708f,33.24957f,11.052086f,-14.507258f,52.392082f,-99.8619f ) ;
  }

  @Test
  public void test639() {
    color.laplace.solve(42.426823f,52.027386f,43.01552f,17.681643f,22.687288f,13.787538f,6.2332277f,7.2512693f,0.08686259f ) ;
  }

  @Test
  public void test640() {
    color.laplace.solve(-42.49005f,-36.67891f,0f,-16.06476f,-16.416311f,12.181532f,-5.352679f,-5.345954f,-62.51259f ) ;
  }

  @Test
  public void test641() {
    color.laplace.solve(42.507607f,57.514294f,78.15099f,12.516135f,9.398572f,-33.81845f,-1.8416388f,-19.88269f,-87.08769f ) ;
  }

  @Test
  public void test642() {
    color.laplace.solve(42.566624f,48.99649f,46.624344f,21.281536f,6.794998f,37.510887f,35.76452f,-80.603645f,-100.0f ) ;
  }

  @Test
  public void test643() {
    color.laplace.solve(42.606533f,44.60554f,55.08682f,25.820593f,-19.271194f,-79.18792f,62.63199f,0f,0f ) ;
  }

  @Test
  public void test644() {
    color.laplace.solve(-42.636307f,-76.71869f,0f,-48.384388f,-2.738524f,0f,-29.477417f,-69.52528f,-51.786106f ) ;
  }

  @Test
  public void test645() {
    color.laplace.solve(42.750927f,53.755333f,38.020195f,17.248377f,34.25021f,-1.6745526f,-8.007631f,67.67168f,-78.96861f ) ;
  }

  @Test
  public void test646() {
    color.laplace.solve(42.794537f,53.917965f,49.44711f,17.260178f,23.430212f,43.87048f,2.8159645f,-21.327772f,-100.0f ) ;
  }

  @Test
  public void test647() {
    color.laplace.solve(42.84501f,53.90464f,47.500103f,17.475393f,25.27345f,29.207268f,1.7831126f,0.50650424f,44.055515f ) ;
  }

  @Test
  public void test648() {
    color.laplace.solve(42.855186f,57.69517f,78.824036f,13.725577f,9.101462f,-125.909744f,2.9456606f,-1.9429351f,-19.818863f ) ;
  }

  @Test
  public void test649() {
    color.laplace.solve(42.899612f,51.3188f,38.98323f,20.27965f,23.392366f,4.614122f,14.82662f,17.35689f,-43.91911f ) ;
  }

  @Test
  public void test650() {
    color.laplace.solve(42.96494f,40.43228f,-52.536976f,31.427483f,71.301155f,68.519806f,11.443835f,14.347858f,-25.353558f ) ;
  }

  @Test
  public void test651() {
    color.laplace.solve(42.977882f,48.01743f,33.75114f,23.894106f,15.340688f,7.5351887f,37.257854f,-18.083973f,63.88129f ) ;
  }

  @Test
  public void test652() {
    color.laplace.solve(42.98216f,53.889317f,50.025635f,18.039316f,22.54617f,46.215374f,6.6284914f,8.472748f,4.7115846f ) ;
  }

  @Test
  public void test653() {
    color.laplace.solve(42.998615f,43.69548f,38.300243f,28.298985f,-6.51694f,-14.757882f,6.834405f,-0.96136415f,-4.1629214f ) ;
  }

  @Test
  public void test654() {
    color.laplace.solve(43.01063f,54.36645f,-6.413366f,17.676067f,33.751675f,-12.586447f,-6.058032f,75.55062f,-77.6841f ) ;
  }

  @Test
  public void test655() {
    color.laplace.solve(43.09174f,43.927402f,21.120754f,28.439558f,11.497122f,-59.675907f,10.0138445f,11.615821f,24.952316f ) ;
  }

  @Test
  public void test656() {
    color.laplace.solve(43.12536f,45.539963f,-3.0339882f,26.956177f,42.068336f,23.587137f,22.631016f,72.195435f,55.3142f ) ;
  }

  @Test
  public void test657() {
    color.laplace.solve(-43.16038f,26.95476f,-58.226555f,-11.852909f,-0.7401026f,-15.870555f,-3.5111537f,-2.1917055f,-4.5155654f ) ;
  }

  @Test
  public void test658() {
    color.laplace.solve(43.213413f,42.71828f,27.245337f,30.135372f,100.0f,0f,-9.831027f,-69.45948f,-2.5298605f ) ;
  }

  @Test
  public void test659() {
    color.laplace.solve(43.254555f,62.427105f,100.0f,10.591122f,6.4538636f,100.0f,-15.289099f,-71.74752f,-71.17713f ) ;
  }

  @Test
  public void test660() {
    color.laplace.solve(43.295677f,55.799744f,44.673355f,17.382963f,35.22994f,-99.710434f,-8.993761f,22.408405f,0f ) ;
  }

  @Test
  public void test661() {
    color.laplace.solve(43.34227f,57.833324f,56.124207f,15.53576f,15.805837f,-6.5897055f,2.9949322f,-3.5560315f,-96.30168f ) ;
  }

  @Test
  public void test662() {
    color.laplace.solve(43.38247f,54.368874f,48.134106f,19.160992f,25.958746f,20.255936f,7.302253f,10.04802f,6.930894f ) ;
  }

  @Test
  public void test663() {
    color.laplace.solve(43.41595f,52.121693f,28.951092f,21.542107f,36.11973f,-36.31732f,6.632744f,4.9888697f,-22.796997f ) ;
  }

  @Test
  public void test664() {
    color.laplace.solve(43.43373f,58.382008f,61.37871f,15.352922f,28.714415f,99.43363f,-10.739385f,-58.310905f,93.08528f ) ;
  }

  @Test
  public void test665() {
    color.laplace.solve(-43.434963f,-99.99984f,0f,-30.201488f,-65.9962f,80.018684f,-11.374794f,-15.297687f,16.180248f ) ;
  }

  @Test
  public void test666() {
    color.laplace.solve(43.451706f,29.567667f,-98.36534f,44.23916f,73.1843f,5.904125f,60.320625f,-57.108463f,0f ) ;
  }

  @Test
  public void test667() {
    color.laplace.solve(43.46223f,53.89174f,44.287376f,19.957376f,27.817327f,23.177359f,8.550077f,14.243061f,20.604841f ) ;
  }

  @Test
  public void test668() {
    color.laplace.solve(43.465137f,53.775272f,42.73806f,20.085285f,28.897884f,29.903797f,7.9781184f,11.827188f,10.432746f ) ;
  }

  @Test
  public void test669() {
    color.laplace.solve(43.471554f,52.225098f,37.561646f,21.66112f,27.867287f,-1.9785224f,15.305641f,39.561447f,-75.951836f ) ;
  }

  @Test
  public void test670() {
    color.laplace.solve(43.47295f,53.59912f,42.10786f,20.292673f,28.594973f,24.369684f,9.102771f,16.118412f,26.775906f ) ;
  }

  @Test
  public void test671() {
    color.laplace.solve(43.481617f,99.97995f,0f,19.054789f,25.490107f,19.198784f,7.2474256f,9.934915f,7.002125f ) ;
  }

  @Test
  public void test672() {
    color.laplace.solve(43.501682f,51.6205f,18.915348f,22.386227f,44.06496f,-75.95911f,1.9782646f,-14.665533f,0f ) ;
  }

  @Test
  public void test673() {
    color.laplace.solve(43.559246f,54.102417f,44.629326f,20.134565f,28.2211f,23.750322f,8.757915f,14.897092f,22.15086f ) ;
  }

  @Test
  public void test674() {
    color.laplace.solve(43.597622f,58.858612f,-99.63546f,15.5318775f,13.789318f,-22.66361f,4.740568f,3.4303956f,-4.808304f ) ;
  }

  @Test
  public void test675() {
    color.laplace.solve(43.678455f,57.391624f,68.35291f,17.322203f,17.535124f,15.163038f,8.075228f,14.978709f,60.225864f ) ;
  }

  @Test
  public void test676() {
    color.laplace.solve(43.681747f,94.61326f,0f,-1.5252694f,-3.2320933f,55.202435f,-46.55073f,-107.34242f,0f ) ;
  }

  @Test
  public void test677() {
    color.laplace.solve(43.70723f,61.959103f,47.666943f,12.869245f,10.316586f,-10.50363f,-2.546838f,-23.05717f,-99.99768f ) ;
  }

  @Test
  public void test678() {
    color.laplace.solve(43.79044f,54.250572f,67.98576f,20.911188f,30.570787f,30.898476f,9.283525f,16.222914f,25.037344f ) ;
  }

  @Test
  public void test679() {
    color.laplace.solve(43.79916f,16.804724f,22.879845f,58.391922f,-99.46011f,-25.285343f,9.626891f,-19.884354f,75.06712f ) ;
  }

  @Test
  public void test680() {
    color.laplace.solve(43.8213f,57.476166f,56.443207f,17.815613f,29.653572f,68.29667f,-1.7894357f,-24.974157f,7.106448f ) ;
  }

  @Test
  public void test681() {
    color.laplace.solve(43.993275f,56.12676f,53.369892f,19.848112f,27.120134f,57.358707f,8.278238f,13.264839f,17.659128f ) ;
  }

  @Test
  public void test682() {
    color.laplace.solve(44.00387f,60.92397f,82.929886f,15.091499f,15.87832f,0.6536503f,0.48391435f,-13.155842f,-68.9856f ) ;
  }

  @Test
  public void test683() {
    color.laplace.solve(44.02249f,63.479218f,17.671522f,12.610746f,92.22286f,67.607185f,11.172497f,32.07924f,24.921608f ) ;
  }

  @Test
  public void test684() {
    color.laplace.solve(44.205196f,52.126034f,18.941267f,24.694761f,45.357662f,-76.36096f,9.216182f,12.169966f,-5.893981f ) ;
  }

  @Test
  public void test685() {
    color.laplace.solve(44.249798f,57.309795f,58.341232f,19.690208f,26.648146f,19.01148f,7.5678267f,10.54523f,7.395484f ) ;
  }

  @Test
  public void test686() {
    color.laplace.solve(44.36253f,71.35605f,18.071558f,6.094065f,-1.2067596f,3.266482f,-18.779509f,-85.54364f,-3.7988694f ) ;
  }

  @Test
  public void test687() {
    color.laplace.solve(44.400837f,54.501057f,41.399487f,23.102293f,32.20391f,11.096886f,15.804423f,40.1154f,-29.21585f ) ;
  }

  @Test
  public void test688() {
    color.laplace.solve(44.448498f,56.46134f,35.787678f,21.332653f,45.609196f,-13.310629f,7.2799673f,7.787216f,-21.7403f ) ;
  }

  @Test
  public void test689() {
    color.laplace.solve(44.50151f,41.240482f,74.91126f,36.765564f,-54.450848f,39.844875f,0f,0f,0f ) ;
  }

  @Test
  public void test690() {
    color.laplace.solve(44.635536f,53.62061f,36.538845f,24.927277f,33.30805f,-7.4593287f,21.76689f,62.14028f,-99.774376f ) ;
  }

  @Test
  public void test691() {
    color.laplace.solve(44.742767f,54.6039f,38.37489f,24.367167f,35.297092f,-1.1050279f,17.428635f,63.322323f,-75.60353f ) ;
  }

  @Test
  public void test692() {
    color.laplace.solve(44.784733f,56.566517f,48.02958f,22.574928f,33.528294f,35.6685f,12.212585f,26.576504f,60.565132f ) ;
  }

  @Test
  public void test693() {
    color.laplace.solve(44.87589f,61.463486f,87.80863f,18.040068f,13.169424f,-65.245636f,14.114961f,38.419773f,4.340752f ) ;
  }

  @Test
  public void test694() {
    color.laplace.solve(44.919304f,49.34121f,40.730255f,30.336002f,11.715273f,20.879614f,64.70943f,-53.69577f,31.072933f ) ;
  }

  @Test
  public void test695() {
    color.laplace.solve(44.954514f,57.57158f,50.54066f,22.24647f,34.79114f,44.59107f,9.240227f,14.714436f,14.826377f ) ;
  }

  @Test
  public void test696() {
    color.laplace.solve(44.97641f,33.404716f,22.961246f,46.500923f,-34.318794f,-41.55973f,9.262124f,-9.452428f,-12.75304f ) ;
  }

  @Test
  public void test697() {
    color.laplace.solve(44.986572f,57.908447f,59.51784f,22.037842f,27.129375f,-48.40269f,16.035421f,42.103844f,100.0f ) ;
  }

  @Test
  public void test698() {
    color.laplace.solve(45.05955f,56.459366f,39.266895f,23.77653f,41.51094f,75.44425f,8.534994f,10.363446f,-8.592352f ) ;
  }

  @Test
  public void test699() {
    color.laplace.solve(45.115475f,42.270943f,-52.157013f,38.19096f,76.12531f,-100.0f,31.523054f,87.90125f,48.09061f ) ;
  }

  @Test
  public void test700() {
    color.laplace.solve(-45.11692f,37.687054f,22.071003f,-10.68385f,6.0828657f,1.4497864f,-3.7013445f,-4.1215286f,-22.354723f ) ;
  }

  @Test
  public void test701() {
    color.laplace.solve(45.175674f,49.28519f,100.0f,31.417503f,47.918873f,12.088423f,32.57547f,98.88437f,-100.0f ) ;
  }

  @Test
  public void test702() {
    color.laplace.solve(4.520263f,-37.38501f,-5.1367035f,1.6069709f,-1.8645161f,14.838397f,3.7721367f,13.481576f,-17.199507f ) ;
  }

  @Test
  public void test703() {
    color.laplace.solve(45.21488f,54.994343f,38.749413f,25.865196f,36.01428f,0.029449493f,22.258331f,63.168133f,-74.63229f ) ;
  }

  @Test
  public void test704() {
    color.laplace.solve(45.224663f,57.796f,50.24438f,23.102636f,35.714962f,43.181522f,11.470922f,22.781034f,100.0f ) ;
  }

  @Test
  public void test705() {
    color.laplace.solve(45.322826f,97.80555f,-93.40985f,-16.51425f,-99.27482f,-1.7706753f,-12.105f,-31.90575f,-60.993362f ) ;
  }

  @Test
  public void test706() {
    color.laplace.solve(45.46253f,64.85024f,95.534935f,16.999872f,18.403503f,1.3718336f,4.133455f,-0.46605173f,-27.719208f ) ;
  }

  @Test
  public void test707() {
    color.laplace.solve(45.526234f,62.334927f,76.44434f,19.770012f,27.350384f,22.376177f,6.167459f,4.819896f,-14.320312f ) ;
  }

  @Test
  public void test708() {
    color.laplace.solve(45.615734f,58.96849f,56.21775f,23.456852f,34.04047f,20.46366f,14.171214f,33.220325f,-8.4022255f ) ;
  }

  @Test
  public void test709() {
    color.laplace.solve(45.648277f,42.331112f,-72.29044f,40.26199f,95.966606f,-20.365356f,19.432692f,37.468773f,34.47544f ) ;
  }

  @Test
  public void test710() {
    color.laplace.solve(45.69999f,59.86911f,55.509815f,22.930851f,38.266644f,62.170143f,7.7568293f,8.096462f,-13.637625f ) ;
  }

  @Test
  public void test711() {
    color.laplace.solve(45.717613f,55.667904f,41.014626f,27.202549f,35.939377f,15.263935f,27.153208f,45.62312f,-15.898264f ) ;
  }

  @Test
  public void test712() {
    color.laplace.solve(45.730915f,51.296185f,22.503754f,31.627481f,36.95007f,1.2614316f,43.828945f,63.615173f,-31.65905f ) ;
  }

  @Test
  public void test713() {
    color.laplace.solve(45.759445f,64.89643f,87.29819f,17.965036f,26.528809f,42.949493f,-0.4531091f,-19.747536f,-347.23654f ) ;
  }

  @Test
  public void test714() {
    color.laplace.solve(45.76576f,73.04565f,100.0f,10.017385f,46.416813f,75.852974f,-52.113033f,0f,0f ) ;
  }

  @Test
  public void test715() {
    color.laplace.solve(45.7822f,50.696743f,0f,111.346664f,-14.199338f,-85.32078f,27.284052f,-2.1956036f,-21.867128f ) ;
  }

  @Test
  public void test716() {
    color.laplace.solve(45.802177f,67.9876f,-21.057335f,15.22111f,13.990612f,-16.391754f,1.0916505f,-10.854508f,-58.500294f ) ;
  }

  @Test
  public void test717() {
    color.laplace.solve(45.84616f,49.247925f,35.17099f,34.136715f,25.036274f,0f,65.66443f,0f,0f ) ;
  }

  @Test
  public void test718() {
    color.laplace.solve(45.858067f,62.997055f,85.73197f,20.435211f,20.398178f,-100.0f,15.484599f,98.160446f,43.3332f ) ;
  }

  @Test
  public void test719() {
    color.laplace.solve(45.975777f,60.737324f,63.23862f,23.165787f,33.7349f,22.392418f,12.952467f,28.644081f,-6.0600815f ) ;
  }

  @Test
  public void test720() {
    color.laplace.solve(46.01316f,53.856525f,38.922848f,30.196114f,30.490097f,1.8348612f,44.281197f,36.072887f,13.212579f ) ;
  }

  @Test
  public void test721() {
    color.laplace.solve(46.033466f,28.551018f,33.15262f,55.76602f,-62.483356f,-1.0361769f,24.760391f,42.90812f,208.61137f ) ;
  }

  @Test
  public void test722() {
    color.laplace.solve(46.03495f,56.499466f,52.197586f,27.640331f,27.765331f,-24.74192f,36.761047f,51.66345f,85.11459f ) ;
  }

  @Test
  public void test723() {
    color.laplace.solve(46.046314f,67.86254f,-5.355517f,32.5875f,53.54116f,23.25199f,30.762526f,90.4626f,44.82232f ) ;
  }

  @Test
  public void test724() {
    color.laplace.solve(46.1258f,63.100685f,75.02019f,21.419125f,31.233438f,28.557888f,8.317265f,11.882327f,7.978607f ) ;
  }

  @Test
  public void test725() {
    color.laplace.solve(46.39212f,59.736702f,51.034992f,25.83178f,41.5197f,44.680897f,15.4153f,35.82942f,86.38268f ) ;
  }

  @Test
  public void test726() {
    color.laplace.solve(46.541733f,67.168076f,-34.914177f,18.997412f,22.779507f,-2.7236829f,6.668409f,7.673614f,1.2377746f ) ;
  }

  @Test
  public void test727() {
    color.laplace.solve(46.54913f,50.055714f,23.32042f,36.1408f,29.713081f,22.907307f,68.30099f,9.748508f,38.595722f ) ;
  }

  @Test
  public void test728() {
    color.laplace.solve(46.676167f,39.39365f,32.88258f,47.311024f,-21.984142f,-39.38028f,10.399081f,-5.7147007f,-11.273746f ) ;
  }

  @Test
  public void test729() {
    color.laplace.solve(46.77278f,91.31469f,6.28899f,-4.2235603f,-88.3224f,94.36539f,24.655376f,74.64698f,0f ) ;
  }

  @Test
  public void test730() {
    color.laplace.solve(46.91949f,22.6331f,42.955315f,65.04486f,-99.33817f,49.193123f,11.204764f,-20.222635f,7.241831f ) ;
  }

  @Test
  public void test731() {
    color.laplace.solve(47.04116f,62.37347f,57.916424f,25.791172f,44.536297f,69.29222f,11.587228f,20.55774f,26.107435f ) ;
  }

  @Test
  public void test732() {
    color.laplace.solve(47.045757f,62.658653f,33.80746f,25.524376f,69.7814f,-53.336052f,-14.729652f,-84.442986f,51.110252f ) ;
  }

  @Test
  public void test733() {
    color.laplace.solve(47.057114f,49.12167f,8.507628f,39.228428f,40.74161f,-115.46568f,68.9651f,119.30953f,0f ) ;
  }

  @Test
  public void test734() {
    color.laplace.solve(47.115963f,24.059107f,-41.416466f,64.40475f,-9.463071f,-59.05237f,15.520831f,-2.3214219f,-15.343448f ) ;
  }

  @Test
  public void test735() {
    color.laplace.solve(47.18099f,62.213524f,56.49516f,26.510433f,45.17795f,63.767113f,13.682793f,28.220736f,54.022198f ) ;
  }

  @Test
  public void test736() {
    color.laplace.solve(47.33673f,60.968323f,52.140305f,28.378597f,44.396244f,29.49118f,21.781366f,58.746872f,14.002144f ) ;
  }

  @Test
  public void test737() {
    color.laplace.solve(-47.37574f,-30.097227f,10.559359f,-18.866327f,-21.031145f,-25.79364f,-7.0584273f,-9.367382f,-9.379957f ) ;
  }

  @Test
  public void test738() {
    color.laplace.solve(47.404263f,55.558125f,59.280037f,34.05893f,15.548196f,8.767064f,73.28326f,-36.191338f,-39.75997f ) ;
  }

  @Test
  public void test739() {
    color.laplace.solve(47.46136f,59.016247f,49.222588f,30.829195f,39.38104f,37.874107f,36.474384f,0f,0f ) ;
  }

  @Test
  public void test740() {
    color.laplace.solve(47.516743f,51.386414f,40.243073f,38.68055f,17.785841f,9.585878f,89.41962f,-28.509481f,-19.685398f ) ;
  }

  @Test
  public void test741() {
    color.laplace.solve(47.840958f,54.13664f,-17.358223f,37.227314f,86.06491f,-62.56451f,15.00159f,22.78006f,-9.946261f ) ;
  }

  @Test
  public void test742() {
    color.laplace.solve(48.054535f,59.749172f,49.878067f,32.46897f,41.064083f,39.7631f,40.757275f,32.27508f,-42.424023f ) ;
  }

  @Test
  public void test743() {
    color.laplace.solve(48.192398f,22.55074f,6.5340896f,70.21885f,-64.52354f,-96.41438f,13.595675f,-15.836148f,-12.416736f ) ;
  }

  @Test
  public void test744() {
    color.laplace.solve(48.24761f,64.16677f,65.97893f,28.82367f,42.440536f,99.74895f,24.606533f,69.60246f,-35.03325f ) ;
  }

  @Test
  public void test745() {
    color.laplace.solve(48.404865f,66.466f,66.610596f,27.108057f,50.831017f,99.99473f,9.196121f,9.674777f,-21.32803f ) ;
  }

  @Test
  public void test746() {
    color.laplace.solve(48.48746f,67.42816f,-30.394201f,27.342197f,43.698925f,38.637913f,17.182405f,41.387424f,-7.252276f ) ;
  }

  @Test
  public void test747() {
    color.laplace.solve(48.501232f,61.521698f,27.618277f,32.48324f,69.96735f,-51.04859f,11.464368f,13.374236f,-45.199764f ) ;
  }

  @Test
  public void test748() {
    color.laplace.solve(48.501553f,68.43979f,81.21479f,25.566422f,44.042797f,68.84627f,9.721286f,13.318722f,-0.4892211f ) ;
  }

  @Test
  public void test749() {
    color.laplace.solve(48.52961f,65.717384f,58.130756f,28.401054f,56.209164f,39.00683f,8.86544f,7.060709f,-21.926338f ) ;
  }

  @Test
  public void test750() {
    color.laplace.solve(48.537273f,67.143364f,80.356445f,27.00574f,39.67973f,12.351733f,19.805954f,52.218075f,-93.35231f ) ;
  }

  @Test
  public void test751() {
    color.laplace.solve(48.717503f,74.6196f,-37.07604f,20.250412f,24.78527f,-5.4740076f,7.498872f,9.745076f,-9.605261f ) ;
  }

  @Test
  public void test752() {
    color.laplace.solve(48.74686f,69.955505f,99.04108f,25.031939f,37.761105f,37.65632f,11.31215f,18.323921f,13.823094f ) ;
  }

  @Test
  public void test753() {
    color.laplace.solve(48.9083f,82.41584f,58.46794f,13.217274f,12.257674f,-0.19814879f,-8.296749f,-46.40427f,-71.51804f ) ;
  }

  @Test
  public void test754() {
    color.laplace.solve(4.891927f,-75.90904f,51.537395f,-4.5232477f,-19.514143f,8.054931f,-2.51149f,-5.528554f,0.6315942f ) ;
  }

  @Test
  public void test755() {
    color.laplace.solve(-4.895698f,-98.68857f,53.720406f,-9.538034f,-28.379372f,4.679239f,-4.877047f,-9.970124f,-6.6240797f ) ;
  }

  @Test
  public void test756() {
    color.laplace.solve(49.212082f,64.18016f,47.165348f,32.668167f,60.3432f,0.7970474f,21.11739f,51.80139f,99.99999f ) ;
  }

  @Test
  public void test757() {
    color.laplace.solve(49.308735f,71.80199f,99.99848f,25.432957f,37.900715f,21.711418f,14.522373f,32.656536f,-51.05353f ) ;
  }

  @Test
  public void test758() {
    color.laplace.solve(49.3204f,46.571846f,16.949965f,50.70975f,20.017023f,-78.431786f,-25.715483f,0f,0f ) ;
  }

  @Test
  public void test759() {
    color.laplace.solve(49.36184f,72.758675f,99.87895f,24.68868f,41.7939f,64.020996f,7.5989842f,5.707256f,87.71336f ) ;
  }

  @Test
  public void test760() {
    color.laplace.solve(49.383923f,62.750492f,1.6180487f,34.7852f,100.0f,89.57018f,20.814545f,48.482487f,0f ) ;
  }

  @Test
  public void test761() {
    color.laplace.solve(49.51584f,91.345085f,100.0f,6.7182636f,-12.2762165f,-98.98369f,-10.366567f,-48.18453f,100.0f ) ;
  }

  @Test
  public void test762() {
    color.laplace.solve(49.522305f,64.052864f,6.6893206f,34.036358f,99.99983f,-1.1085755f,-13.376711f,-87.5432f,0f ) ;
  }

  @Test
  public void test763() {
    color.laplace.solve(-49.540348f,24.832102f,34.920788f,-9.90046f,10.254145f,17.447021f,-0.31563595f,8.637917f,24.613155f ) ;
  }

  @Test
  public void test764() {
    color.laplace.solve(49.59308f,72.531685f,97.895f,25.840633f,42.638676f,65.15918f,11.1307745f,18.682465f,20.960411f ) ;
  }

  @Test
  public void test765() {
    color.laplace.solve(49.941204f,61.1011f,26.472849f,38.66372f,67.99035f,-34.182766f,36.723324f,39.39215f,0f ) ;
  }

  @Test
  public void test766() {
    color.laplace.solve(50.00451f,62.937485f,21.988575f,37.080555f,79.75685f,-100.0f,18.560863f,37.162903f,50.333893f ) ;
  }

  @Test
  public void test767() {
    color.laplace.solve(50.06216f,76.91861f,49.868595f,23.330025f,34.153595f,23.278406f,9.104342f,13.087344f,9.091437f ) ;
  }

  @Test
  public void test768() {
    color.laplace.solve(50.07759f,97.61801f,-67.23684f,2.692355f,-38.028305f,40.05528f,-1.2798681f,-7.811827f,8.060863f ) ;
  }

  @Test
  public void test769() {
    color.laplace.solve(50.298416f,72.05306f,95.975395f,29.1406f,49.400185f,58.092487f,16.863796f,38.31459f,86.99437f ) ;
  }

  @Test
  public void test770() {
    color.laplace.solve(50.337643f,67.203735f,53.783188f,34.212013f,64.34538f,112.39994f,19.570555f,43.27769f,-20.936588f ) ;
  }

  @Test
  public void test771() {
    color.laplace.solve(50.417004f,66.72038f,41.793705f,34.947636f,74.670815f,0.45443884f,14.702718f,23.863237f,6.079419f ) ;
  }

  @Test
  public void test772() {
    color.laplace.solve(50.48444f,70.030075f,67.3327f,31.907686f,62.30315f,99.30073f,14.767342f,27.161678f,31.576223f ) ;
  }

  @Test
  public void test773() {
    color.laplace.solve(50.538567f,81.096115f,-88.38778f,21.058157f,31.69624f,90.644745f,1.9978224f,-49.26136f,0f ) ;
  }

  @Test
  public void test774() {
    color.laplace.solve(-5.0894523f,-19.897203f,0f,-100.0f,72.2293f,0f,-14.954186f,40.183254f,94.183365f ) ;
  }

  @Test
  public void test775() {
    color.laplace.solve(50.894928f,79.47956f,3.974523f,24.100155f,35.664898f,46.922573f,9.840795f,15.263022f,15.546399f ) ;
  }

  @Test
  public void test776() {
    color.laplace.solve(50.926014f,84.31324f,-3.0026395f,19.390816f,27.017635f,25.278845f,-0.38038576f,-20.91236f,77.10039f ) ;
  }

  @Test
  public void test777() {
    color.laplace.solve(51.068577f,21.938448f,36.56669f,82.335846f,-99.88148f,24.32833f,11.512819f,-36.284584f,-56.76968f ) ;
  }

  @Test
  public void test778() {
    color.laplace.solve(51.438812f,66.87938f,84.62246f,38.875877f,31.456242f,53.009865f,72.60845f,63.67665f,0f ) ;
  }

  @Test
  public void test779() {
    color.laplace.solve(51.52913f,83.51299f,95.824936f,22.603523f,31.092558f,9.687618f,7.792406f,8.566103f,-88.16702f ) ;
  }

  @Test
  public void test780() {
    color.laplace.solve(51.549183f,63.322834f,81.79571f,42.873905f,19.946426f,-16.12536f,100.0f,-10.285671f,57.27299f ) ;
  }

  @Test
  public void test781() {
    color.laplace.solve(51.69421f,69.99946f,62.479946f,36.087254f,64.65958f,80.16739f,27.280727f,72.37628f,196.60092f ) ;
  }

  @Test
  public void test782() {
    color.laplace.solve(51.726303f,96.272026f,-36.31006f,10.633182f,-7.6565537f,-100.0f,-1.5370204f,-16.781263f,-57.93148f ) ;
  }

  @Test
  public void test783() {
    color.laplace.solve(51.817284f,72.4283f,54.604424f,34.840828f,83.291504f,1.295131f,4.2545214f,-17.822742f,0f ) ;
  }

  @Test
  public void test784() {
    color.laplace.solve(51.85126f,87.03804f,173.61595f,20.306261f,22.6528f,-24.082321f,6.700543f,6.2521405f,-4.4759474f ) ;
  }

  @Test
  public void test785() {
    color.laplace.solve(51.980827f,71.67652f,67.20488f,36.2468f,67.52037f,99.536476f,25.485994f,65.69718f,0f ) ;
  }

  @Test
  public void test786() {
    color.laplace.solve(52.1187f,90.46933f,-97.79344f,18.00547f,20.518894f,-5.930913f,-0.6157096f,-20.46831f,53.55089f ) ;
  }

  @Test
  public void test787() {
    color.laplace.solve(52.25249f,93.967964f,-78.12715f,20.77602f,24.915743f,-18.048382f,5.9358473f,2.9673686f,-18.982115f ) ;
  }

  @Test
  public void test788() {
    color.laplace.solve(52.94382f,49.820225f,23.449736f,61.955055f,22.887348f,-56.021282f,18.475384f,11.946477f,-75.824585f ) ;
  }

  @Test
  public void test789() {
    color.laplace.solve(53.005917f,20.521381f,-99.30109f,91.50229f,28.3807f,96.189926f,28.254412f,21.515358f,29.426321f ) ;
  }

  @Test
  public void test790() {
    color.laplace.solve(53.02907f,40.09998f,13.350484f,72.01631f,-5.979644f,-72.23002f,0f,0f,0f ) ;
  }

  @Test
  public void test791() {
    color.laplace.solve(53.050564f,80.230354f,99.5232f,31.9719f,68.34765f,-84.29815f,6.4897137f,-6.013047f,-98.88955f ) ;
  }

  @Test
  public void test792() {
    color.laplace.solve(53.086674f,67.13121f,28.962132f,45.215485f,86.476036f,-51.58909f,11.76734f,1.8538725f,-90.82789f ) ;
  }

  @Test
  public void test793() {
    color.laplace.solve(53.10657f,79.33311f,78.82304f,33.093185f,85.40281f,-12.427695f,92.384674f,-15.393375f,0f ) ;
  }

  @Test
  public void test794() {
    color.laplace.solve(53.146885f,99.92519f,100.0f,12.662342f,-4.9975204f,-66.013245f,2.8044667f,-1.444475f,-3.5848463f ) ;
  }

  @Test
  public void test795() {
    color.laplace.solve(53.258575f,94.869705f,-99.99999f,18.164598f,12.952001f,100.0f,6.447819f,7.6266785f,11.1068945f ) ;
  }

  @Test
  public void test796() {
    color.laplace.solve(53.395493f,89.43271f,0.40518945f,24.149204f,34.03202f,10.018445f,9.169231f,12.52772f,5.6365185f ) ;
  }

  @Test
  public void test797() {
    color.laplace.solve(53.62406f,39.0009f,-22.868784f,75.49534f,25.24832f,73.52204f,26.902004f,32.112675f,0f ) ;
  }

  @Test
  public void test798() {
    color.laplace.solve(53.65318f,99.921875f,96.071884f,14.690847f,7.3334193f,40.701756f,-2.2232113f,-23.583693f,-99.44498f ) ;
  }

  @Test
  public void test799() {
    color.laplace.solve(5.3986783f,-32.687046f,3.7049706f,-45.71824f,61.247795f,72.31046f,-6.5798564f,19.398813f,22.92732f ) ;
  }

  @Test
  public void test800() {
    color.laplace.solve(54.530033f,32.84061f,20.79358f,85.27952f,-43.961178f,-49.66629f,16.694527f,-18.501415f,-46.73901f ) ;
  }

  @Test
  public void test801() {
    color.laplace.solve(54.584114f,64.36952f,66.01681f,53.966927f,36.877182f,-42.94879f,60.23056f,70.50828f,0f ) ;
  }

  @Test
  public void test802() {
    color.laplace.solve(-5.47643f,-21.146112f,-30.66311f,0.9155497f,-9.60966f,24.94427f,18.74829f,-43.15235f,74.29387f ) ;
  }

  @Test
  public void test803() {
    color.laplace.solve(55.166576f,98.98091f,0f,24.093506f,4.6426954f,85.57389f,36.56475f,41.614227f,0f ) ;
  }

  @Test
  public void test804() {
    color.laplace.solve(-55.877804f,-11.753664f,0f,15.5789585f,33.57494f,0f,19.429976f,62.14094f,0f ) ;
  }

  @Test
  public void test805() {
    color.laplace.solve(56.362183f,100.0f,66.502914f,25.448732f,23.419676f,-28.189552f,22.013067f,62.603535f,0f ) ;
  }

  @Test
  public void test806() {
    color.laplace.solve(56.625435f,100.0f,49.901764f,29.627308f,47.845936f,35.3516f,14.007995f,26.378159f,43.658703f ) ;
  }

  @Test
  public void test807() {
    color.laplace.solve(56.70058f,100.0f,-73.42215f,30.583801f,47.636513f,18.55359f,17.998116f,41.408657f,100.0f ) ;
  }

  @Test
  public void test808() {
    color.laplace.solve(5.876018f,72.405396f,100.0f,11.295337f,33.252632f,36.395668f,6.0526977f,12.9117155f,12.326846f ) ;
  }

  @Test
  public void test809() {
    color.laplace.solve(59.168026f,100.0f,100.0f,36.67211f,55.083603f,100.0f,32.436813f,94.248405f,0f ) ;
  }

  @Test
  public void test810() {
    color.laplace.solve(5.956009f,-93.101074f,23.734278f,16.925112f,53.591537f,-11.680355f,8.152902f,15.686494f,1.0015346f ) ;
  }

  @Test
  public void test811() {
    color.laplace.solve(60.07655f,54.799904f,31.238125f,85.506294f,27.884949f,-29.847406f,24.535288f,12.634856f,-1.8808104f ) ;
  }

  @Test
  public void test812() {
    color.laplace.solve(60.344124f,100.0f,25.504345f,41.3765f,5.161878f,-33.084045f,100.0f,-87.64494f,67.7005f ) ;
  }

  @Test
  public void test813() {
    color.laplace.solve(6.062489f,20.259455f,0f,-12.127381f,51.345936f,0f,-32.509556f,-35.52801f,0f ) ;
  }

  @Test
  public void test814() {
    color.laplace.solve(60.657852f,50.320614f,-54.456303f,92.31079f,95.08091f,9.470878f,43.79128f,82.854324f,100.0f ) ;
  }

  @Test
  public void test815() {
    color.laplace.solve(61.529648f,51.17087f,24.420187f,94.947716f,18.733654f,-53.490124f,10.159747f,-71.09596f,0f ) ;
  }

  @Test
  public void test816() {
    color.laplace.solve(62.16103f,61.320312f,48.41627f,87.32381f,34.703957f,-100.0f,-3.1399143f,-18.385612f,0f ) ;
  }

  @Test
  public void test817() {
    color.laplace.solve(62.487022f,53.772476f,41.770325f,96.175606f,10.8325615f,13.308828f,26.387018f,9.372461f,0.27026737f ) ;
  }

  @Test
  public void test818() {
    color.laplace.solve(-62.75314f,-55.712955f,0f,-6.4162464f,-17.885618f,-66.9892f,54.97377f,-39.813927f,0f ) ;
  }

  @Test
  public void test819() {
    color.laplace.solve(-64.183365f,-91.62293f,-22.286905f,-28.086636f,-37.648735f,-16.914246f,-10.5144415f,-13.97113f,-7.721344f ) ;
  }

  @Test
  public void test820() {
    color.laplace.solve(64.51628f,65.64863f,56.904568f,92.416504f,41.173664f,9.379635f,28.883436f,23.11724f,22.411867f ) ;
  }

  @Test
  public void test821() {
    color.laplace.solve(6.5257006f,-71.68678f,70.319595f,-2.2104144f,-16.830875f,-1.490792f,1.4635179f,8.0644865f,-59.451885f ) ;
  }

  @Test
  public void test822() {
    color.laplace.solve(6.560397f,66.432365f,-45.254845f,0.4783268f,25.70702f,17.517302f,-30.35411f,18.40009f,89.61703f ) ;
  }

  @Test
  public void test823() {
    color.laplace.solve(-66.37716f,-47.701866f,0f,10.516134f,87.04964f,-59.66138f,21.392057f,75.0521f,-23.817713f ) ;
  }

  @Test
  public void test824() {
    color.laplace.solve(67.32138f,69.285515f,45.486088f,100.0f,64.3346f,54.811512f,29.942732f,19.77093f,-15.193614f ) ;
  }

  @Test
  public void test825() {
    color.laplace.solve(68.04716f,76.09207f,51.47517f,96.096565f,84.84597f,29.808601f,36.831856f,51.23086f,83.24563f ) ;
  }

  @Test
  public void test826() {
    color.laplace.solve(6.811719f,14.885791f,-27.851294f,-87.638916f,-19.417261f,-99.98385f,-23.365128f,-5.8215966f,19.496002f ) ;
  }

  @Test
  public void test827() {
    color.laplace.solve(-69.03725f,-94.175316f,0f,-35.88629f,-81.658035f,0f,-18.180357f,-36.835136f,-47.502155f ) ;
  }

  @Test
  public void test828() {
    color.laplace.solve(-6.905385f,-99.139854f,0f,46.54032f,-76.42018f,0f,3.9680452f,0f,0f ) ;
  }

  @Test
  public void test829() {
    color.laplace.solve(6.9510818f,96.93812f,11.65296f,2.3125114f,2.9439456f,-82.58241f,-0.6449814f,-4.892437f,-21.868713f ) ;
  }

  @Test
  public void test830() {
    color.laplace.solve(6.974232f,-8.924506f,-192.15916f,-65.107f,48.910286f,-117.277725f,-16.255423f,0.15287063f,-31.557533f ) ;
  }

  @Test
  public void test831() {
    color.laplace.solve(6.9920754f,-2.9533904f,-33.93161f,-69.07831f,26.446835f,0f,-18.037628f,-3.0722086f,-20.69804f ) ;
  }

  @Test
  public void test832() {
    color.laplace.solve(-7.040447f,-48.96783f,0f,-3.1388226f,-4.265905f,-5.7945757f,-1.2489381f,-1.8569298f,-1.9128764f ) ;
  }

  @Test
  public void test833() {
    color.laplace.solve(7.1188736f,-92.24726f,22.712189f,20.722754f,-14.806169f,0.33318698f,90.57831f,11.966645f,47.700752f ) ;
  }

  @Test
  public void test834() {
    color.laplace.solve(7.1515474f,-68.434814f,-33.451622f,-2.9589922f,-17.107367f,7.525953f,-1.88015f,-4.5616074f,0.7410863f ) ;
  }

  @Test
  public void test835() {
    color.laplace.solve(-71.63991f,-28.67598f,-77.76572f,-29.124386f,-30.15989f,-33.172592f,-14.697746f,-29.6666f,-73.80876f ) ;
  }

  @Test
  public void test836() {
    color.laplace.solve(-71.90939f,-33.528084f,0f,93.21343f,63.81086f,0f,-47.944122f,-18.40627f,0f ) ;
  }

  @Test
  public void test837() {
    color.laplace.solve(-72.74373f,63.89892f,0f,-44.57782f,73.571236f,84.60591f,-12.864373f,-6.8796725f,-88.22555f ) ;
  }

  @Test
  public void test838() {
    color.laplace.solve(73.4371f,98.69995f,-44.338238f,95.04845f,11.609855f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test839() {
    color.laplace.solve(-73.71222f,100.0f,0f,57.289364f,-54.33722f,0.4552383f,11.472265f,-11.400306f,-2.7362669f ) ;
  }

  @Test
  public void test840() {
    color.laplace.solve(-7.394229f,-34.888996f,84.19577f,1.5099236f,-6.847932f,-49.719482f,20.281855f,55.70683f,-41.993282f ) ;
  }

  @Test
  public void test841() {
    color.laplace.solve(7.5733476f,-70.5526f,100.0f,0.84598875f,-6.14877f,38.12001f,1.9593775f,6.9915214f,32.15548f ) ;
  }

  @Test
  public void test842() {
    color.laplace.solve(7.5949492f,-65.34489f,0f,16.010113f,70.86579f,66.9858f,-14.420295f,-73.69129f,-99.28599f ) ;
  }

  @Test
  public void test843() {
    color.laplace.solve(-82.353645f,-34.696228f,0f,69.418495f,76.10036f,0f,4.366977f,-51.95059f,-2.1316476f ) ;
  }

  @Test
  public void test844() {
    color.laplace.solve(82.924065f,201.605f,175.42432f,28.856813f,42.228306f,2.1716688f,-8.503458f,-63.667618f,-43.732334f ) ;
  }

  @Test
  public void test845() {
    color.laplace.solve(-83.10866f,2.9884598f,0f,9.394618f,21.049192f,0f,99.63794f,0f,0f ) ;
  }

  @Test
  public void test846() {
    color.laplace.solve(-83.72322f,-13.833453f,-98.96515f,-32.164124f,-35.017372f,-86.57245f,-9.9158945f,-7.4994574f,14.935436f ) ;
  }

  @Test
  public void test847() {
    color.laplace.solve(8.383876f,6.1888742f,0f,-7.0943913f,-33.97173f,-100.0f,-2.7897108f,-4.064452f,20.503632f ) ;
  }

  @Test
  public void test848() {
    color.laplace.solve(-84.87628f,6.3779383f,0f,-2.2590318f,79.29601f,31.152103f,-3.4558578f,69.34044f,0f ) ;
  }

  @Test
  public void test849() {
    color.laplace.solve(8.665381f,-38.769615f,-20.089935f,-26.56886f,-31.376175f,-16.305277f,-83.564644f,-43.860947f,-13.754998f ) ;
  }

  @Test
  public void test850() {
    color.laplace.solve(-86.84708f,-20.020384f,-71.59152f,-3.65249f,-22.388931f,-32.369125f,94.62605f,-33.513725f,-35.496048f ) ;
  }

  @Test
  public void test851() {
    color.laplace.solve(8.826473f,-70.72333f,-100.0f,6.029223f,10.438202f,100.0f,4.8522162f,13.3796425f,38.22815f ) ;
  }

  @Test
  public void test852() {
    color.laplace.solve(9.024254f,12.075969f,-70.09742f,-75.97896f,9.377041f,-93.154045f,-22.516748f,-14.08804f,-43.212452f ) ;
  }

  @Test
  public void test853() {
    color.laplace.solve(-90.490265f,130.81613f,0f,-12.452175f,4.561881f,0f,9.581058f,50.776405f,-90.486465f ) ;
  }

  @Test
  public void test854() {
    color.laplace.solve(-91.184525f,-84.55137f,-24.912874f,-48.15004f,-26.599747f,48.882957f,-74.81589f,-22.580536f,14.191833f ) ;
  }

  @Test
  public void test855() {
    color.laplace.solve(95.40971f,-81.44421f,0f,-95.19696f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test856() {
    color.laplace.solve(-96.04702f,-89.11726f,0f,-28.478197f,-6.891452f,-100.0f,-10.974313f,-15.419055f,-43.81045f ) ;
  }

  @Test
  public void test857() {
    color.laplace.solve(-96.313614f,66.78017f,-10.632427f,-19.91899f,20.056238f,27.119131f,-3.4185848f,6.24465f,8.340945f ) ;
  }

  @Test
  public void test858() {
    color.laplace.solve(-9.744377f,6.6252737f,-15.441431f,-145.54356f,11.515307f,20.051104f,-37.917027f,-5.703718f,3.586846f ) ;
  }

  @Test
  public void test859() {
    color.laplace.solve(-99.21466f,73.196144f,0f,-9.436227f,52.687172f,0f,47.027016f,0f,0f ) ;
  }

  @Test
  public void test860() {
    color.laplace.solve(9.975087f,-60.203f,99.83885f,0.10334709f,-9.344929f,23.690367f,-0.21677038f,-0.9704286f,5.6799846f ) ;
  }

  @Test
  public void test861() {
    color.laplace.solve(-99.96039f,-76.19554f,0f,-30.929173f,-14.1416f,-72.12897f,-9.614699f,-7.529626f,-6.3622046f ) ;
  }

  @Test
  public void test862() {
    color.laplace.solve(-99.99852f,-99.79109f,0f,-99.9393f,99.99789f,9.849203f,-19.45087f,22.135818f,7.9962554f ) ;
  }
}
