import org.junit.Test;

public class JpfTargetloanTest {

  @Test
  public void test0() {
    color.loan.solve(18.739252f ) ;
  }

  @Test
  public void test1() {
    color.loan.solve(70.83348f ) ;
  }

  @Test
  public void test2() {
    color.loan.solve(99.68685f ) ;
  }
}
