import org.junit.Test;

public class JpfTargetMysinTest {

  @Test
  public void test0() {
    JpfTargetMysin.static_mysin(0.6315209437808846 ) ;
  }

  @Test
  public void test1() {
    JpfTargetMysin.static_mysin(-0.6374494032151716 ) ;
  }

  @Test
  public void test2() {
    JpfTargetMysin.static_mysin(0.7325299089779203 ) ;
  }

  @Test
  public void test3() {
    JpfTargetMysin.static_mysin(-0.9941548840007195 ) ;
  }

  @Test
  public void test4() {
    JpfTargetMysin.static_mysin(-1.079733553168245E-4 ) ;
  }

  @Test
  public void test5() {
    JpfTargetMysin.static_mysin(11.064456250307941 ) ;
  }

  @Test
  public void test6() {
    JpfTargetMysin.static_mysin(14.922565104551518 ) ;
  }

  @Test
  public void test7() {
    JpfTargetMysin.static_mysin(163.08238651694245 ) ;
  }

  @Test
  public void test8() {
    JpfTargetMysin.static_mysin(-21.680817646982604 ) ;
  }

  @Test
  public void test9() {
    JpfTargetMysin.static_mysin(-21.705824749623332 ) ;
  }

  @Test
  public void test10() {
    JpfTargetMysin.static_mysin(-2.4414062500020134E-4 ) ;
  }

  @Test
  public void test11() {
    JpfTargetMysin.static_mysin(2.4414062500039264E-4 ) ;
  }

  @Test
  public void test12() {
    JpfTargetMysin.static_mysin(-2.443511676573525E-4 ) ;
  }

  @Test
  public void test13() {
    JpfTargetMysin.static_mysin(2.486291333410126E-4 ) ;
  }

  @Test
  public void test14() {
    JpfTargetMysin.static_mysin(-26.03097575064102 ) ;
  }

  @Test
  public void test15() {
    JpfTargetMysin.static_mysin(-27.501793234859278 ) ;
  }

  @Test
  public void test16() {
    JpfTargetMysin.static_mysin(-277.2808484669246 ) ;
  }

  @Test
  public void test17() {
    JpfTargetMysin.static_mysin(-289.73192170070695 ) ;
  }

  @Test
  public void test18() {
    JpfTargetMysin.static_mysin(29.216439629950997 ) ;
  }

  @Test
  public void test19() {
    JpfTargetMysin.static_mysin(44.20691334907892 ) ;
  }

  @Test
  public void test20() {
    JpfTargetMysin.static_mysin(-49.25825229847123 ) ;
  }

  @Test
  public void test21() {
    JpfTargetMysin.static_mysin(-52.42685788140471 ) ;
  }

  @Test
  public void test22() {
    JpfTargetMysin.static_mysin(55.052738330488296 ) ;
  }

  @Test
  public void test23() {
    JpfTargetMysin.static_mysin(-55.76326960121882 ) ;
  }

  @Test
  public void test24() {
    JpfTargetMysin.static_mysin(-63.61725123519331 ) ;
  }

  @Test
  public void test25() {
    JpfTargetMysin.static_mysin(-7.815130474041216E-17 ) ;
  }

  @Test
  public void test26() {
    JpfTargetMysin.static_mysin(-79.49360959304286 ) ;
  }

  @Test
  public void test27() {
    JpfTargetMysin.static_mysin(84.63685699122732 ) ;
  }

  @Test
  public void test28() {
    JpfTargetMysin.static_mysin(8.888739607570828E-37 ) ;
  }

  @Test
  public void test29() {
    JpfTargetMysin.static_mysin(96.60397409788614 ) ;
  }
}
