import org.junit.Test;

public class TestzbrentTest {

  @Test
  public void test0() {
    ell.zbrent(-100.0,28.27433388230814,0 ) ;
  }

  @Test
  public void test1() {
    ell.zbrent(100.0,-47.1238898038469,0 ) ;
  }

  @Test
  public void test2() {
    ell.zbrent(-100.0,-50.26548245743669,0 ) ;
  }

  @Test
  public void test3() {
    ell.zbrent(-100.0,-9.42477796076938,0 ) ;
  }

  @Test
  public void test4() {
    ell.zbrent(10.238497917403114,47.1238898038469,0 ) ;
  }

  @Test
  public void test5() {
    ell.zbrent(12.879820494016968,-1.9388929138200552,0 ) ;
  }

  @Test
  public void test6() {
    ell.zbrent(13.93334013040699,43.98229715025711,0 ) ;
  }

  @Test
  public void test7() {
    ell.zbrent(16.164354249296736,66.67746130074264,0 ) ;
  }

  @Test
  public void test8() {
    ell.zbrent(19.652891608666764,-32.36396085579176,0 ) ;
  }

  @Test
  public void test9() {
    ell.zbrent(-20.36241818645433,43.98229715025711,0 ) ;
  }

  @Test
  public void test10() {
    ell.zbrent(21.346015820527597,31.41592653589793,0 ) ;
  }

  @Test
  public void test11() {
    ell.zbrent(-26.83657192733402,50.2654824574367,0 ) ;
  }

  @Test
  public void test12() {
    ell.zbrent(-29.37340374867685,-47.49770313568693,0 ) ;
  }

  @Test
  public void test13() {
    ell.zbrent(-30.366238464008855,15.707963267948966,0 ) ;
  }

  @Test
  public void test14() {
    ell.zbrent(-31.029598319847594,95.46797808284757,0 ) ;
  }

  @Test
  public void test15() {
    ell.zbrent(-36.19681876657029,78.53981633974483,0 ) ;
  }

  @Test
  public void test16() {
    ell.zbrent(-37.17370877130192,-185.35396656179782,0 ) ;
  }

  @Test
  public void test17() {
    ell.zbrent(-38.29021432048461,0,0 ) ;
  }

  @Test
  public void test18() {
    ell.zbrent(-38.37472566030349,0,0 ) ;
  }

  @Test
  public void test19() {
    ell.zbrent(-41.519206707201036,-55.613921426837564,0 ) ;
  }

  @Test
  public void test20() {
    ell.zbrent(43.982297150257104,100.0,0 ) ;
  }

  @Test
  public void test21() {
    ell.zbrent(-47.12388980384689,0,0 ) ;
  }

  @Test
  public void test22() {
    ell.zbrent(-48.062924707741004,-43.98229715025711,0 ) ;
  }

  @Test
  public void test23() {
    ell.zbrent(4.824516952857508,12.566370614359174,0 ) ;
  }

  @Test
  public void test24() {
    ell.zbrent(48.99557248247319,15.707963267960162,0 ) ;
  }

  @Test
  public void test25() {
    ell.zbrent(-59.69026041820607,0,0 ) ;
  }

  @Test
  public void test26() {
    ell.zbrent(6.283185307179587,5.311202979994363,0 ) ;
  }

  @Test
  public void test27() {
    ell.zbrent(-73.00198811060531,-94.24777960769379,0 ) ;
  }

  @Test
  public void test28() {
    ell.zbrent(-74.18303614586759,91.10618695410399,0 ) ;
  }

  @Test
  public void test29() {
    ell.zbrent(74.46991900175053,-81.68140899333461,0 ) ;
  }

  @Test
  public void test30() {
    ell.zbrent(-74.75398054935549,-84.82300164692441,0 ) ;
  }

  @Test
  public void test31() {
    ell.zbrent(75.39822368615505,92.84013022139452,0 ) ;
  }

  @Test
  public void test32() {
    ell.zbrent(-76.05654350291857,65.97344572538566,0 ) ;
  }

  @Test
  public void test33() {
    ell.zbrent(78.24224085811801,-43.982297150257104,0 ) ;
  }

  @Test
  public void test34() {
    ell.zbrent(79.25618860596852,-84.82300164692441,0 ) ;
  }

  @Test
  public void test35() {
    ell.zbrent(80.96004537830366,-3.141592653589793,0 ) ;
  }

  @Test
  public void test36() {
    ell.zbrent(87.96459430051421,0,0 ) ;
  }

  @Test
  public void test37() {
    ell.zbrent(89.76985648003136,-28.27433388230814,0 ) ;
  }

  @Test
  public void test38() {
    ell.zbrent(-9.424777960769381,-7.692916460910183,0 ) ;
  }

  @Test
  public void test39() {
    ell.zbrent(-94.67412843042253,-90.12964704483258,0 ) ;
  }

  @Test
  public void test40() {
    ell.zbrent(95.71528194206303,-71.26667804315518,0 ) ;
  }

  @Test
  public void test41() {
    ell.zbrent(97.46748192433313,57.9875966837254,0 ) ;
  }

  @Test
  public void test42() {
    ell.zbrent(98.14647451095968,-92.40428940875726,0 ) ;
  }

  @Test
  public void test43() {
    ell.zbrent(-98.60479115588659,0,0 ) ;
  }
}
