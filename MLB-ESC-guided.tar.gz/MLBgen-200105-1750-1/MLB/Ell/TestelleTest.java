import org.junit.Test;

public class TestelleTest {

  @Test
  public void test0() {
    ell.elle(15.707963264108429,-1.5786132009147602 ) ;
  }

  @Test
  public void test1() {
    ell.elle(-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test2() {
    ell.elle(2.263315463252141,0.6455044678960462 ) ;
  }

  @Test
  public void test3() {
    ell.elle(-26.703537566005703,0.1012980223792794 ) ;
  }

  @Test
  public void test4() {
    ell.elle(-28.274333904843164,0.43959277401047125 ) ;
  }

  @Test
  public void test5() {
    ell.elle(29.12027143615589,29.466664199393193 ) ;
  }

  @Test
  public void test6() {
    ell.elle(-3.141592657613815,-0.125066712653577 ) ;
  }

  @Test
  public void test7() {
    ell.elle(34.55751918888845,8.459717850407355 ) ;
  }

  @Test
  public void test8() {
    ell.elle(-37.6991118416047,-9.257227896111125 ) ;
  }

  @Test
  public void test9() {
    ell.elle(37.69911184993882,4.1160138087254445 ) ;
  }

  @Test
  public void test10() {
    ell.elle(-37.69911374653936,-0.9999729097932729 ) ;
  }

  @Test
  public void test11() {
    ell.elle(-41.161758848552516,-3.1688970097827003 ) ;
  }

  @Test
  public void test12() {
    ell.elle(46.69297801516319,0.9813733650570902 ) ;
  }

  @Test
  public void test13() {
    ell.elle(-47.123889793224315,1.178023436245413 ) ;
  }

  @Test
  public void test14() {
    ell.elle(-4.71238898038469,0.6952216196501234 ) ;
  }

  @Test
  public void test15() {
    ell.elle(4.712390416306276,-1.0 ) ;
  }

  @Test
  public void test16() {
    ell.elle(-50.26542045577187,-7.056581417627379E-5 ) ;
  }

  @Test
  public void test17() {
    ell.elle(50.26547959774802,-0.0036254515490460326 ) ;
  }

  @Test
  public void test18() {
    ell.elle(50.26548247050475,0.021595085203101938 ) ;
  }

  @Test
  public void test19() {
    ell.elle(50.26548255094613,-0.6843516895115799 ) ;
  }

  @Test
  public void test20() {
    ell.elle(-51.125172773461934,-1.3198872422816355 ) ;
  }

  @Test
  public void test21() {
    ell.elle(-51.836278786521646,1.0 ) ;
  }

  @Test
  public void test22() {
    ell.elle(-52.453731677178745,-0.9366797127755925 ) ;
  }

  @Test
  public void test23() {
    ell.elle(-53.407075095338115,0.5716967696700976 ) ;
  }

  @Test
  public void test24() {
    ell.elle(-56.39256207177033,5.008726873652165 ) ;
  }

  @Test
  public void test25() {
    ell.elle(-59.690260404778854,-0.5855585372714068 ) ;
  }

  @Test
  public void test26() {
    ell.elle(-62.886053781037205,16.16691904465157 ) ;
  }

  @Test
  public void test27() {
    ell.elle(-65.97344571999925,2.3312404944082306 ) ;
  }

  @Test
  public void test28() {
    ell.elle(-69.11503837730348,1.6538983265219693 ) ;
  }

  @Test
  public void test29() {
    ell.elle(-69.11503838816175,-1.1587321533809123 ) ;
  }

  @Test
  public void test30() {
    ell.elle(-69.1150383927816,4.853171201637746 ) ;
  }

  @Test
  public void test31() {
    ell.elle(70.73704348172822,33.22296406732039 ) ;
  }

  @Test
  public void test32() {
    ell.elle(72.25663102142683,0.27822312522872694 ) ;
  }

  @Test
  public void test33() {
    ell.elle(-72.25663102263727,-5.791040039072042 ) ;
  }

  @Test
  public void test34() {
    ell.elle(72.2566310505305,-0.7910112748009581 ) ;
  }

  @Test
  public void test35() {
    ell.elle(-72.32526288128707,14.581939804631205 ) ;
  }

  @Test
  public void test36() {
    ell.elle(75.39822367944953,-1.3282821395646016 ) ;
  }

  @Test
  public void test37() {
    ell.elle(75.39823434404424,3.2291618247820564E-4 ) ;
  }

  @Test
  public void test38() {
    ell.elle(-75.95047851150339,-1.9061844903494636 ) ;
  }

  @Test
  public void test39() {
    ell.elle(-78.53981621031858,0.9923145767144621 ) ;
  }

  @Test
  public void test40() {
    ell.elle(7.853981633974483,-0.8012562243083512 ) ;
  }

  @Test
  public void test41() {
    ell.elle(-79.7070494121698,-0.3016607603021981 ) ;
  }

  @Test
  public void test42() {
    ell.elle(-80.96638094034667,94.42502917449289 ) ;
  }

  @Test
  public void test43() {
    ell.elle(-81.68140900284158,-1.001101740500526 ) ;
  }

  @Test
  public void test44() {
    ell.elle(83.25220531164578,0.6107865807677699 ) ;
  }

  @Test
  public void test45() {
    ell.elle(-83.25220532357257,-1.0000000000000058 ) ;
  }

  @Test
  public void test46() {
    ell.elle(87.96459430020687,-18.103074989550734 ) ;
  }

  @Test
  public void test47() {
    ell.elle(94.24777953492877,0.5356371228362005 ) ;
  }
}
