import org.junit.Test;

public class TestellfTest {

  @Test
  public void test0() {
    ell.ellf(12.336182811974197,-1.7911141251931895 ) ;
  }

  @Test
  public void test1() {
    ell.ellf(-12.54658138699807,-50.5358422364584 ) ;
  }

  @Test
  public void test2() {
    ell.ellf(-12.566370617358286,1.0027026865089372 ) ;
  }

  @Test
  public void test3() {
    ell.ellf(-14.137166941674066,0.4056869586284222 ) ;
  }

  @Test
  public void test4() {
    ell.ellf(17.27875959177983,1.0000000000002107 ) ;
  }

  @Test
  public void test5() {
    ell.ellf(-17.278759594743864,0.15663797153699163 ) ;
  }

  @Test
  public void test6() {
    ell.ellf(-18.849555913953488,-1.1520800084527778 ) ;
  }

  @Test
  public void test7() {
    ell.ellf(21.991148568139447,-13.549097592684642 ) ;
  }

  @Test
  public void test8() {
    ell.ellf(-25.222784977583615,-93.50239025429565 ) ;
  }

  @Test
  public void test9() {
    ell.ellf(28.27433387326667,-1.7889716544796244 ) ;
  }

  @Test
  public void test10() {
    ell.ellf(28.2743338873136,-2.088247802868133 ) ;
  }

  @Test
  public void test11() {
    ell.ellf(3.1415926491868325,-21.094603278997056 ) ;
  }

  @Test
  public void test12() {
    ell.ellf(-3.1415926584488156,-3.9517838152322113 ) ;
  }

  @Test
  public void test13() {
    ell.ellf(-32.98672286269283,1.0 ) ;
  }

  @Test
  public void test14() {
    ell.ellf(-34.408836338246424,6.750569739923729 ) ;
  }

  @Test
  public void test15() {
    ell.ellf(37.699111863203925,-0.7639181813890288 ) ;
  }

  @Test
  public void test16() {
    ell.ellf(-40.43581120702828,88.02127361898928 ) ;
  }

  @Test
  public void test17() {
    ell.ellf(40.84070450924221,0.6388050710093987 ) ;
  }

  @Test
  public void test18() {
    ell.ellf(-40.84082729857662,-7.998111119617566E-5 ) ;
  }

  @Test
  public void test19() {
    ell.ellf(41.318567689205224,-0.2442591695049856 ) ;
  }

  @Test
  public void test20() {
    ell.ellf(43.98229715555883,-0.9995908162141565 ) ;
  }

  @Test
  public void test21() {
    ell.ellf(-45.553092529518985,-1.0 ) ;
  }

  @Test
  public void test22() {
    ell.ellf(-50.24710526533354,0.6111439333549777 ) ;
  }

  @Test
  public void test23() {
    ell.ellf(50.26548246022731,4.952693169940693 ) ;
  }

  @Test
  public void test24() {
    ell.ellf(-58.119464054519966,1.0 ) ;
  }

  @Test
  public void test25() {
    ell.ellf(61.55566987673717,-0.22004022833512238 ) ;
  }

  @Test
  public void test26() {
    ell.ellf(-62.83301056159045,-1.000000000034633 ) ;
  }

  @Test
  public void test27() {
    ell.ellf(-65.97344575613148,0.9912324039843046 ) ;
  }

  @Test
  public void test28() {
    ell.ellf(-69.11503837416969,0.059343534589275396 ) ;
  }

  @Test
  public void test29() {
    ell.ellf(-72.2566310190605,0.8355539126959708 ) ;
  }

  @Test
  public void test30() {
    ell.ellf(72.26459084556336,-0.19910401205791572 ) ;
  }

  @Test
  public void test31() {
    ell.ellf(-73.82742736483458,0.10122493541603401 ) ;
  }

  @Test
  public void test32() {
    ell.ellf(75.3982236892065,0.6556256134672225 ) ;
  }

  @Test
  public void test33() {
    ell.ellf(-7.853981631717234,0.9999999999999999 ) ;
  }

  @Test
  public void test34() {
    ell.ellf(-78.53981635383339,-0.37968506810079533 ) ;
  }

  @Test
  public void test35() {
    ell.ellf(80.1106138887887,-0.999999999999999 ) ;
  }

  @Test
  public void test36() {
    ell.ellf(81.68140899474105,5.418073881827054 ) ;
  }

  @Test
  public void test37() {
    ell.ellf(-83.25220532012952,0.5323959043821429 ) ;
  }

  @Test
  public void test38() {
    ell.ellf(-84.77830205544913,10.368031883987982 ) ;
  }

  @Test
  public void test39() {
    ell.ellf(-84.82300163920355,-1.0934831458999394 ) ;
  }

  @Test
  public void test40() {
    ell.ellf(-87.45020373046155,-2.032502250986534 ) ;
  }

  @Test
  public void test41() {
    ell.ellf(-87.96459428946473,3.3164904336558466E-4 ) ;
  }

  @Test
  public void test42() {
    ell.ellf(89.79942346415268,-17.455862797522045 ) ;
  }

  @Test
  public void test43() {
    ell.ellf(91.10618693850783,0.7329161814867522 ) ;
  }

  @Test
  public void test44() {
    ell.ellf(91.10624936753855,0.9999999933890042 ) ;
  }

  @Test
  public void test45() {
    ell.ellf(-9.424772697872479,-1.000001265215258 ) ;
  }

  @Test
  public void test46() {
    ell.ellf(9.424777968908963,0.7969953071241456 ) ;
  }

  @Test
  public void test47() {
    ell.ellf(-9.517641563291004,10.783974505973594 ) ;
  }
}
