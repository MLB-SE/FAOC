import org.junit.Test;

public class TestcisiTest {

  @Test
  public void test0() {
    frenel.cisi(10.157602334749583 ) ;
  }

  @Test
  public void test1() {
    frenel.cisi(-1.0467132555682923 ) ;
  }

  @Test
  public void test2() {
    frenel.cisi(-12.351069454740866 ) ;
  }

  @Test
  public void test3() {
    frenel.cisi(1.39575256674118 ) ;
  }

  @Test
  public void test4() {
    frenel.cisi(1.4744436900050033 ) ;
  }

  @Test
  public void test5() {
    frenel.cisi(1.7457437052177909 ) ;
  }

  @Test
  public void test6() {
    frenel.cisi(-1.8604958435042676 ) ;
  }

  @Test
  public void test7() {
    frenel.cisi(-1.8726705418768793E-96 ) ;
  }

  @Test
  public void test8() {
    frenel.cisi(-2.0 ) ;
  }

  @Test
  public void test9() {
    frenel.cisi(2.0 ) ;
  }

  @Test
  public void test10() {
    frenel.cisi(2.3738919364399497E-66 ) ;
  }

  @Test
  public void test11() {
    frenel.cisi(-2.465190328815662E-32 ) ;
  }

  @Test
  public void test12() {
    frenel.cisi(-4.0794981317202 ) ;
  }

  @Test
  public void test13() {
    frenel.cisi(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test14() {
    frenel.cisi(-4.4455174989701545E-162 ) ;
  }

  @Test
  public void test15() {
    frenel.cisi(4.4455174989701545E-162 ) ;
  }

  @Test
  public void test16() {
    frenel.cisi(-47.341969535651444 ) ;
  }

  @Test
  public void test17() {
    frenel.cisi(4.930380657631324E-32 ) ;
  }

  @Test
  public void test18() {
    frenel.cisi(5.2484972525261355 ) ;
  }

  @Test
  public void test19() {
    frenel.cisi(-54.90241321460647 ) ;
  }

  @Test
  public void test20() {
    frenel.cisi(93.49385347859126 ) ;
  }

  @Test
  public void test21() {
    frenel.cisi(-9.467216210993797 ) ;
  }

  @Test
  public void test22() {
    frenel.cisi(9.860761315262648E-32 ) ;
  }
}
