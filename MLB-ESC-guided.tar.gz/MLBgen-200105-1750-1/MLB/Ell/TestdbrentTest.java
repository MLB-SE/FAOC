import org.junit.Test;

public class TestdbrentTest {

  @Test
  public void test0() {
    ell.dbrent(0.0,0.0,0.0,0 ) ;
  }

  @Test
  public void test1() {
    ell.dbrent(-0.6684491463423708,0,-0.668449146342371,0 ) ;
  }

  @Test
  public void test2() {
    ell.dbrent(-100.0,0.0,100.0,0 ) ;
  }

  @Test
  public void test3() {
    ell.dbrent(-100.0,0.0,-40.307534780764136,0 ) ;
  }

  @Test
  public void test4() {
    ell.dbrent(-10.823457491876695,-72.41098625569427,58.206440945592135,0 ) ;
  }

  @Test
  public void test5() {
    ell.dbrent(-11.984897515682809,-20.72249717761357,-11.984897515682809,0 ) ;
  }

  @Test
  public void test6() {
    ell.dbrent(-15.798780557143335,-0.29201597748960495,-15.798780557143335,0 ) ;
  }

  @Test
  public void test7() {
    ell.dbrent(-1.8352492145046,0,-1.8352492145046,0 ) ;
  }

  @Test
  public void test8() {
    ell.dbrent(22.34727317408914,0,87.58706634878772,0 ) ;
  }

  @Test
  public void test9() {
    ell.dbrent(-25.010844051765442,0,-25.01084405176544,0 ) ;
  }

  @Test
  public void test10() {
    ell.dbrent(-26.510155517530293,11.381108157407652,99.17810105444991,0 ) ;
  }

  @Test
  public void test11() {
    ell.dbrent(28.097510981560625,95.19700512836775,28.097510981560625,0 ) ;
  }

  @Test
  public void test12() {
    ell.dbrent(28.204320505646123,0,28.20432050564612,0 ) ;
  }

  @Test
  public void test13() {
    ell.dbrent(2.9273625076688243,-48.12571750006833,2.9273625076688243,0 ) ;
  }

  @Test
  public void test14() {
    ell.dbrent(30.533442638797283,0.0,92.08937937191777,0 ) ;
  }

  @Test
  public void test15() {
    ell.dbrent(32.855962134467234,0.0,32.855962134467234,0 ) ;
  }

  @Test
  public void test16() {
    ell.dbrent(-35.67497531714169,0.0,-35.674975317142255,0 ) ;
  }

  @Test
  public void test17() {
    ell.dbrent(-37.56179303520091,-58.947603899839706,-95.60723700020554,0 ) ;
  }

  @Test
  public void test18() {
    ell.dbrent(38.71886429186412,14.42913146235979,38.71886429186412,0 ) ;
  }

  @Test
  public void test19() {
    ell.dbrent(40.207474041552416,75.7277763268695,40.207474041552416,0 ) ;
  }

  @Test
  public void test20() {
    ell.dbrent(-40.457329879563765,-54.74410167169368,53.723643730718464,0 ) ;
  }

  @Test
  public void test21() {
    ell.dbrent(-40.50820726628661,0.0,-40.50820726628661,0 ) ;
  }

  @Test
  public void test22() {
    ell.dbrent(-40.64764404114649,62.13334901208199,70.63883552133942,0 ) ;
  }

  @Test
  public void test23() {
    ell.dbrent(-42.630934874136386,84.64289531709395,-24.166183523959248,0 ) ;
  }

  @Test
  public void test24() {
    ell.dbrent(-43.113901172022516,0,-43.11390117202251,0 ) ;
  }

  @Test
  public void test25() {
    ell.dbrent(43.57233953889434,0,15.67003685445978,0 ) ;
  }

  @Test
  public void test26() {
    ell.dbrent(-43.72226275628455,16.723510026156113,77.16928280859678,0 ) ;
  }

  @Test
  public void test27() {
    ell.dbrent(44.42108191313207,0.0,-44.42108191313207,0 ) ;
  }

  @Test
  public void test28() {
    ell.dbrent(-44.736375130341614,98.78904552079646,-84.52191126367985,0 ) ;
  }

  @Test
  public void test29() {
    ell.dbrent(-47.26955870371974,0,-95.99166976964459,0 ) ;
  }

  @Test
  public void test30() {
    ell.dbrent(-50.168913393137416,0,-50.16891339313734,0 ) ;
  }

  @Test
  public void test31() {
    ell.dbrent(-55.5019667229588,0.0,56.02252331595953,0 ) ;
  }

  @Test
  public void test32() {
    ell.dbrent(59.22396754237151,0,59.22396754237151,0 ) ;
  }

  @Test
  public void test33() {
    ell.dbrent(-59.647600748118904,-2.4678210684732136,-98.50557530607598,0 ) ;
  }

  @Test
  public void test34() {
    ell.dbrent(59.92647159612545,0,59.92647159612546,0 ) ;
  }

  @Test
  public void test35() {
    ell.dbrent(59.94112946811313,17.480819043980617,-24.9794913801519,0 ) ;
  }

  @Test
  public void test36() {
    ell.dbrent(-60.517376672282836,-60.517376672282836,-60.517376672282836,0 ) ;
  }

  @Test
  public void test37() {
    ell.dbrent(6.657406604377371,-11.996211082577219,-30.64982876953181,0 ) ;
  }

  @Test
  public void test38() {
    ell.dbrent(70.2427746113607,0.0,-72.33799374285421,0 ) ;
  }

  @Test
  public void test39() {
    ell.dbrent(-72.80608885708713,-2.379160494553261,30.46476742110613,0 ) ;
  }

  @Test
  public void test40() {
    ell.dbrent(79.60673971379728,79.60673971379728,79.60673971379728,0 ) ;
  }

  @Test
  public void test41() {
    ell.dbrent(80.57591625496188,0.0,-49.23608529069418,0 ) ;
  }

  @Test
  public void test42() {
    ell.dbrent(-81.2253121908247,0.0,-81.2253121908247,0 ) ;
  }

  @Test
  public void test43() {
    ell.dbrent(83.19140973875247,-14.268949295532224,29.979695311873968,0 ) ;
  }

  @Test
  public void test44() {
    ell.dbrent(84.50744796543509,28.63392667347381,67.70781030976471,0 ) ;
  }

  @Test
  public void test45() {
    ell.dbrent(-85.23382980315274,0,96.5392063407366,0 ) ;
  }

  @Test
  public void test46() {
    ell.dbrent(-8.545020058117963,-6.751548654871218,-4.9580772516244735,0 ) ;
  }

  @Test
  public void test47() {
    ell.dbrent(9.147990610721664,36.0309055278386,-74.9742767298334,0 ) ;
  }
}
