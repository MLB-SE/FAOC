import org.junit.Test;

public class TestplgndrTest {

  @Test
  public void test0() {
    plgndr.plgndr(0,0,0 ) ;
  }

  @Test
  public void test1() {
    plgndr.plgndr(0,-1,0 ) ;
  }

  @Test
  public void test2() {
    plgndr.plgndr(0,-492,0 ) ;
  }

  @Test
  public void test3() {
    plgndr.plgndr(0,653,0 ) ;
  }

  @Test
  public void test4() {
    plgndr.plgndr(0,-706,0 ) ;
  }

  @Test
  public void test5() {
    plgndr.plgndr(-1,0,0 ) ;
  }

  @Test
  public void test6() {
    plgndr.plgndr(-115,-115,0 ) ;
  }

  @Test
  public void test7() {
    plgndr.plgndr(1155,651,4.440892098500626E-16 ) ;
  }

  @Test
  public void test8() {
    plgndr.plgndr(1192,301,1.0000000000000002 ) ;
  }

  @Test
  public void test9() {
    plgndr.plgndr(1566,85,1.0000000000007765 ) ;
  }

  @Test
  public void test10() {
    plgndr.plgndr(167,166,34.30845334750293 ) ;
  }

  @Test
  public void test11() {
    plgndr.plgndr(171,167,0 ) ;
  }

  @Test
  public void test12() {
    plgndr.plgndr(1761,202,-1.0 ) ;
  }

  @Test
  public void test13() {
    plgndr.plgndr(-234,0,0 ) ;
  }

  @Test
  public void test14() {
    plgndr.plgndr(250,185,1.0 ) ;
  }

  @Test
  public void test15() {
    plgndr.plgndr(-289,0,0 ) ;
  }

  @Test
  public void test16() {
    plgndr.plgndr(322,212,-81.53790956960086 ) ;
  }

  @Test
  public void test17() {
    plgndr.plgndr(37,710,0 ) ;
  }

  @Test
  public void test18() {
    plgndr.plgndr(400,369,58.504414134255796 ) ;
  }

  @Test
  public void test19() {
    plgndr.plgndr(410,364,-0.2231351755905742 ) ;
  }

  @Test
  public void test20() {
    plgndr.plgndr(436,13,1.0000000000000002 ) ;
  }

  @Test
  public void test21() {
    plgndr.plgndr(511,235,-37.0140661336672 ) ;
  }

  @Test
  public void test22() {
    plgndr.plgndr(559,14,0.0 ) ;
  }

  @Test
  public void test23() {
    plgndr.plgndr(562,501,0.0 ) ;
  }

  @Test
  public void test24() {
    plgndr.plgndr(-61,481,0 ) ;
  }

  @Test
  public void test25() {
    plgndr.plgndr(657,-806,0 ) ;
  }

  @Test
  public void test26() {
    plgndr.plgndr(-686,0,0 ) ;
  }

  @Test
  public void test27() {
    plgndr.plgndr(698,579,1.0 ) ;
  }

  @Test
  public void test28() {
    plgndr.plgndr(-728,0,0 ) ;
  }

  @Test
  public void test29() {
    plgndr.plgndr(800,108,1.0 ) ;
  }

  @Test
  public void test30() {
    plgndr.plgndr(-814,26,0 ) ;
  }

  @Test
  public void test31() {
    plgndr.plgndr(899,-186,0 ) ;
  }

  @Test
  public void test32() {
    plgndr.plgndr(968,452,1.0 ) ;
  }

  @Test
  public void test33() {
    plgndr.plgndr(-96,-97,0 ) ;
  }
}
