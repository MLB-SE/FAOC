import org.junit.Test;

public class TestbrentTest {

  @Test
  public void test0() {
    ell.brent(0.0,0.0,0.0,0 ) ;
  }

  @Test
  public void test1() {
    ell.brent(-0.3512496661031377,-0.3512496661031377,-0.3512496661031377,0 ) ;
  }

  @Test
  public void test2() {
    ell.brent(0.4693381244787389,0,90.42164782970727,0 ) ;
  }

  @Test
  public void test3() {
    ell.brent(100.0,0.0,-77.10133431538762,0 ) ;
  }

  @Test
  public void test4() {
    ell.brent(100.0,100.0,100.0,0 ) ;
  }

  @Test
  public void test5() {
    ell.brent(-100.0,-92.39040841675059,-100.0,0 ) ;
  }

  @Test
  public void test6() {
    ell.brent(-12.540040483913733,0,-12.540040483913735,0 ) ;
  }

  @Test
  public void test7() {
    ell.brent(-13.645092696996604,-16.52441400269646,-19.403735308396314,0 ) ;
  }

  @Test
  public void test8() {
    ell.brent(-16.82190657218751,-14.031033117858385,-11.240159663529262,0 ) ;
  }

  @Test
  public void test9() {
    ell.brent(-16.859952261951396,0,-16.859952261951392,0 ) ;
  }

  @Test
  public void test10() {
    ell.brent(1.694734381255671,-7.667750148018371,96.8352808627304,0 ) ;
  }

  @Test
  public void test11() {
    ell.brent(17.254312293183727,0,17.254312293183723,0 ) ;
  }

  @Test
  public void test12() {
    ell.brent(17.49805511123685,7.598089556366716,5.269271468214882,0 ) ;
  }

  @Test
  public void test13() {
    ell.brent(2.0174469155383266,0.0,2.0174469155383266,0 ) ;
  }

  @Test
  public void test14() {
    ell.brent(-25.81078263909682,93.4100113219657,-25.81078263909682,0 ) ;
  }

  @Test
  public void test15() {
    ell.brent(25.87549973569014,44.25165859492233,62.627817454154524,0 ) ;
  }

  @Test
  public void test16() {
    ell.brent(-3.614173868997945,84.17309240082638,-3.614173868997945,0 ) ;
  }

  @Test
  public void test17() {
    ell.brent(36.167278621270015,-77.31568242889631,62.08883521114578,0 ) ;
  }

  @Test
  public void test18() {
    ell.brent(-3.6185792706925355,0.0,3.6185792706925355,0 ) ;
  }

  @Test
  public void test19() {
    ell.brent(-36.19880162246864,0.0,100.0,0 ) ;
  }

  @Test
  public void test20() {
    ell.brent(-3.6645818231841005,0.0,-24.041006557255148,0 ) ;
  }

  @Test
  public void test21() {
    ell.brent(40.26022401190578,0,40.26022401190577,0 ) ;
  }

  @Test
  public void test22() {
    ell.brent(41.575686113266805,0,41.5756861132668,0 ) ;
  }

  @Test
  public void test23() {
    ell.brent(-4.213028339524417,0,-4.213028339524417,0 ) ;
  }

  @Test
  public void test24() {
    ell.brent(-42.7140880426166,0.0,22.452280536265143,0 ) ;
  }

  @Test
  public void test25() {
    ell.brent(44.33443873555137,41.895930114296675,-22.575740006763723,0 ) ;
  }

  @Test
  public void test26() {
    ell.brent(-45.42750761932223,-100.0,-45.42750761932223,0 ) ;
  }

  @Test
  public void test27() {
    ell.brent(-45.94165595606701,47.96260238856459,-1.5759450377460524,0 ) ;
  }

  @Test
  public void test28() {
    ell.brent(46.439880241379804,-20.899554696534345,46.439880241379804,0 ) ;
  }

  @Test
  public void test29() {
    ell.brent(46.59151712406913,53.117573386808346,-29.032068612310383,0 ) ;
  }

  @Test
  public void test30() {
    ell.brent(-46.9875134222935,-42.43394920559336,-80.22005091334515,0 ) ;
  }

  @Test
  public void test31() {
    ell.brent(-49.05451889152521,4.601991520111909,96.55220832111183,0 ) ;
  }

  @Test
  public void test32() {
    ell.brent(-49.79199056608696,0,-49.79199056608695,0 ) ;
  }

  @Test
  public void test33() {
    ell.brent(51.42770154173627,41.23751964126703,31.047337740797786,0 ) ;
  }

  @Test
  public void test34() {
    ell.brent(56.432549120553205,0.6582437878262226,56.432549120553205,0 ) ;
  }

  @Test
  public void test35() {
    ell.brent(-58.97687072043052,16.43711833361708,-11.19509597672348,0 ) ;
  }

  @Test
  public void test36() {
    ell.brent(61.81913598571823,0.0,61.81913598571823,0 ) ;
  }

  @Test
  public void test37() {
    ell.brent(-62.38389901896259,0.0,34.729874029336315,0 ) ;
  }

  @Test
  public void test38() {
    ell.brent(64.95499228944863,0.0,-64.95499228944863,0 ) ;
  }

  @Test
  public void test39() {
    ell.brent(70.59089725056666,0,-48.59308872614587,0 ) ;
  }

  @Test
  public void test40() {
    ell.brent(-75.54350500101637,0,-75.54350500101637,0 ) ;
  }

  @Test
  public void test41() {
    ell.brent(75.93265298176311,-7.303430617392507,-61.42297471052049,0 ) ;
  }

  @Test
  public void test42() {
    ell.brent(-78.1450401319996,-65.16345681348521,-65.5149732722769,0 ) ;
  }

  @Test
  public void test43() {
    ell.brent(86.16220654292255,-33.94156973284839,64.63797959975037,0 ) ;
  }

  @Test
  public void test44() {
    ell.brent(-88.37386116163978,0.0,-88.37386116163978,0 ) ;
  }

  @Test
  public void test45() {
    ell.brent(-89.96303300259156,0,-36.55168371631723,0 ) ;
  }

  @Test
  public void test46() {
    ell.brent(97.1448337383685,0,-17.009975818327987,0 ) ;
  }

  @Test
  public void test47() {
    ell.brent(99.38717021708061,0.0,86.20922515539738,0 ) ;
  }
}
