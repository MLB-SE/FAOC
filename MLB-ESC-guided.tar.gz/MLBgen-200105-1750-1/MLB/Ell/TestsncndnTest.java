import org.junit.Test;

public class TestsncndnTest {

  @Test
  public void test0() {
    ell.sncndn(0,0.18829219612794645 ) ;
  }

  @Test
  public void test1() {
    ell.sncndn(0,0.8875772183621677 ) ;
  }

  @Test
  public void test2() {
    ell.sncndn(0,0.9999999799999999 ) ;
  }

  @Test
  public void test3() {
    ell.sncndn(0,0.99999998 ) ;
  }

  @Test
  public void test4() {
    ell.sncndn(0,0.9999999826704299 ) ;
  }

  @Test
  public void test5() {
    ell.sncndn(0,0.999999999999999 ) ;
  }

  @Test
  public void test6() {
    ell.sncndn(0,1.0 ) ;
  }

  @Test
  public void test7() {
    ell.sncndn(0,1.0000000000000002 ) ;
  }

  @Test
  public void test8() {
    ell.sncndn(0,1.000000000217107 ) ;
  }

  @Test
  public void test9() {
    ell.sncndn(0,1.0000000199999999 ) ;
  }

  @Test
  public void test10() {
    ell.sncndn(0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test11() {
    ell.sncndn(0,17.589907991312657 ) ;
  }

  @Test
  public void test12() {
    ell.sncndn(0,-1.831017297414121 ) ;
  }

  @Test
  public void test13() {
    ell.sncndn(0,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test14() {
    ell.sncndn(0,36.215171389165505 ) ;
  }

  @Test
  public void test15() {
    ell.sncndn(0,-4.392297974732557 ) ;
  }

  @Test
  public void test16() {
    ell.sncndn(0,4.930380657631324E-32 ) ;
  }

  @Test
  public void test17() {
    ell.sncndn(0,5.773010966626984 ) ;
  }

  @Test
  public void test18() {
    ell.sncndn(0,-6.162975822039155E-33 ) ;
  }

  @Test
  public void test19() {
    ell.sncndn(0,-74.03704291483794 ) ;
  }

  @Test
  public void test20() {
    ell.sncndn(0,-81.588651684296 ) ;
  }

  @Test
  public void test21() {
    ell.sncndn(0,88.86842384128201 ) ;
  }

  @Test
  public void test22() {
    ell.sncndn(0,90.93171955802376 ) ;
  }
}
