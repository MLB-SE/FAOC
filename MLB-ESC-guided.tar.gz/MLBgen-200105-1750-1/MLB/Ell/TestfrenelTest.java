import org.junit.Test;

public class TestfrenelTest {

  @Test
  public void test0() {
    frenel.frenel(-0.35513963628976875 ) ;
  }

  @Test
  public void test1() {
    frenel.frenel(-0.4103796378417144 ) ;
  }

  @Test
  public void test2() {
    frenel.frenel(0.5891773288361009 ) ;
  }

  @Test
  public void test3() {
    frenel.frenel(0.707447469559014 ) ;
  }

  @Test
  public void test4() {
    frenel.frenel(1.1418429393882619 ) ;
  }

  @Test
  public void test5() {
    frenel.frenel(-11.577499722740228 ) ;
  }

  @Test
  public void test6() {
    frenel.frenel(1.2090043400355919 ) ;
  }

  @Test
  public void test7() {
    frenel.frenel(-1.4999999999999991 ) ;
  }

  @Test
  public void test8() {
    frenel.frenel(-1.5 ) ;
  }

  @Test
  public void test9() {
    frenel.frenel(1.5 ) ;
  }

  @Test
  public void test10() {
    frenel.frenel(-1.8803647412137536 ) ;
  }

  @Test
  public void test11() {
    frenel.frenel(-2.2738409141369544 ) ;
  }

  @Test
  public void test12() {
    frenel.frenel(-3.469446951953614E-18 ) ;
  }

  @Test
  public void test13() {
    frenel.frenel(4.440892098500626E-16 ) ;
  }

  @Test
  public void test14() {
    frenel.frenel(-45.307096620408814 ) ;
  }

  @Test
  public void test15() {
    frenel.frenel(45.745064353213166 ) ;
  }

  @Test
  public void test16() {
    frenel.frenel(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test17() {
    frenel.frenel(4.930380657631324E-32 ) ;
  }

  @Test
  public void test18() {
    frenel.frenel(-60.69605414751671 ) ;
  }

  @Test
  public void test19() {
    frenel.frenel(71.80209213280986 ) ;
  }
}
