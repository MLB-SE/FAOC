import org.junit.Test;

public class TestellpiTest {

  @Test
  public void test0() {
    ell.ellpi(0.011968859274676474,0,9.412475480265381E-7 ) ;
  }

  @Test
  public void test1() {
    ell.ellpi(14.137166934156697,0,0.9986458982588111 ) ;
  }

  @Test
  public void test2() {
    ell.ellpi(-15.707963251372513,0,-0.8046928293893822 ) ;
  }

  @Test
  public void test3() {
    ell.ellpi(-1.5707963267948966,0,-1.0 ) ;
  }

  @Test
  public void test4() {
    ell.ellpi(21.99114858179737,0,0.19224015830373276 ) ;
  }

  @Test
  public void test5() {
    ell.ellpi(-25.132741222154284,0,1.6211460515884966 ) ;
  }

  @Test
  public void test6() {
    ell.ellpi(25.132741225325045,0,3.427214717047029 ) ;
  }

  @Test
  public void test7() {
    ell.ellpi(25.909684026257793,0,0.3864596059529153 ) ;
  }

  @Test
  public void test8() {
    ell.ellpi(-26.703537555513243,0,1.0 ) ;
  }

  @Test
  public void test9() {
    ell.ellpi(29.845130209103036,0,0.06184779328097534 ) ;
  }

  @Test
  public void test10() {
    ell.ellpi(29.845130209103036,0,0.35824620886222186 ) ;
  }

  @Test
  public void test11() {
    ell.ellpi(3.1415925381864844,0,-1.0035695541102876 ) ;
  }

  @Test
  public void test12() {
    ell.ellpi(-31.415926549863336,0,1.09778990497351 ) ;
  }

  @Test
  public void test13() {
    ell.ellpi(31.415926943154908,0,-0.2782245090786372 ) ;
  }

  @Test
  public void test14() {
    ell.ellpi(-3.4924890987234914E-10,0,39.484778118089814 ) ;
  }

  @Test
  public void test15() {
    ell.ellpi(-37.09380366710515,0,-0.6927654290060117 ) ;
  }

  @Test
  public void test16() {
    ell.ellpi(38.86712320900827,0,-0.5593384074985721 ) ;
  }

  @Test
  public void test17() {
    ell.ellpi(-39.76482324930405,0,-1.1363519543801346 ) ;
  }

  @Test
  public void test18() {
    ell.ellpi(40.84063456481346,0,-1.8339394676586358E-4 ) ;
  }

  @Test
  public void test19() {
    ell.ellpi(47.123889803401894,0,0.6385553410401181 ) ;
  }

  @Test
  public void test20() {
    ell.ellpi(-4.712388990447728,0,-0.005060997201545464 ) ;
  }

  @Test
  public void test21() {
    ell.ellpi(-48.04439303650416,0,1.162183449637297 ) ;
  }

  @Test
  public void test22() {
    ell.ellpi(-49.490464556697944,0,-74.70585139818658 ) ;
  }

  @Test
  public void test23() {
    ell.ellpi(-53.40574471425407,0,1.0000000000153169 ) ;
  }

  @Test
  public void test24() {
    ell.ellpi(53.40707510777343,0,4.140468463772354 ) ;
  }

  @Test
  public void test25() {
    ell.ellpi(56.548667747416886,0,0.7242913475480045 ) ;
  }

  @Test
  public void test26() {
    ell.ellpi(59.6902604116539,0,-13.201604042446618 ) ;
  }

  @Test
  public void test27() {
    ell.ellpi(59.69026041821907,0,-100.0 ) ;
  }

  @Test
  public void test28() {
    ell.ellpi(-61.26105674819347,0,0.9999999999999944 ) ;
  }

  @Test
  public void test29() {
    ell.ellpi(6.2831852314208,0,0.07701932428086425 ) ;
  }

  @Test
  public void test30() {
    ell.ellpi(62.83185312023077,0,2.2734288533379727 ) ;
  }

  @Test
  public void test31() {
    ell.ellpi(65.97344572619394,0,15.484878262135734 ) ;
  }

  @Test
  public void test32() {
    ell.ellpi(-65.97344580798384,0,0.9922843576041194 ) ;
  }

  @Test
  public void test33() {
    ell.ellpi(65.97729211512016,0,88.76522227340612 ) ;
  }

  @Test
  public void test34() {
    ell.ellpi(-66.8489217718114,0,0.8140035191835295 ) ;
  }

  @Test
  public void test35() {
    ell.ellpi(-69.2289278963953,0,-7.380721461675435 ) ;
  }

  @Test
  public void test36() {
    ell.ellpi(81.68140898512647,0,2.2519768415381627 ) ;
  }

  @Test
  public void test37() {
    ell.ellpi(-84.8230016352923,0,-1.1164015180536984 ) ;
  }

  @Test
  public void test38() {
    ell.ellpi(-84.8230016460376,0,-1.1546862822321335 ) ;
  }

  @Test
  public void test39() {
    ell.ellpi(-86.39379798236679,0,1.0 ) ;
  }

  @Test
  public void test40() {
    ell.ellpi(87.9645942883925,0,-0.975168138153883 ) ;
  }

  @Test
  public void test41() {
    ell.ellpi(87.96459429746004,0,-1.0129055884166183 ) ;
  }

  @Test
  public void test42() {
    ell.ellpi(87.96459431764856,0,0.4669024111877599 ) ;
  }

  @Test
  public void test43() {
    ell.ellpi(93.39384260966423,0,59.379332095860406 ) ;
  }

  @Test
  public void test44() {
    ell.ellpi(-9.424777984926873,0,1.1627156469483626 ) ;
  }

  @Test
  public void test45() {
    ell.ellpi(95.81857651700051,0,1.000000000000285 ) ;
  }

  @Test
  public void test46() {
    ell.ellpi(97.38937224682414,0,-0.2147815252620333 ) ;
  }
}
