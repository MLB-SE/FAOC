import org.junit.Test;

public class TestbetacfTest {

  @Test
  public void test0() {
    beta.betacf(-16.024221945954224,0,0 ) ;
  }

  @Test
  public void test1() {
    beta.betacf(25.54068996747189,-83.1967993278176,-50.1883987110429 ) ;
  }

  @Test
  public void test2() {
    beta.betacf(27.807029339641502,-27.323269137139675,59.54815875853845 ) ;
  }

  @Test
  public void test3() {
    beta.betacf(-28.595223123954455,29.602937405097833,-27.383975438597734 ) ;
  }

  @Test
  public void test4() {
    beta.betacf(34.021480425609525,-86.01647232166,-0.6735548780472016 ) ;
  }

  @Test
  public void test5() {
    beta.betacf(50.61340712171665,-42.04006659937496,6.0202212879815935 ) ;
  }

  @Test
  public void test6() {
    beta.betacf(-53.441109366829664,45.606625144492085,6.693626265441988 ) ;
  }

  @Test
  public void test7() {
    beta.betacf(58.54514041300661,-60.507099532605366,-30.349837475300806 ) ;
  }

  @Test
  public void test8() {
    beta.betacf(5.919570714675544,0,0 ) ;
  }

  @Test
  public void test9() {
    beta.betacf(-62.27446397508234,-98.94165611813803,-24.384868364660207 ) ;
  }

  @Test
  public void test10() {
    beta.betacf(6.852844694960353,-83.59783834004375,-43.1991101762532 ) ;
  }

  @Test
  public void test11() {
    beta.betacf(-71.84353439318521,72.58565079668693,-95.46148563608793 ) ;
  }

  @Test
  public void test12() {
    beta.betacf(-78.20554469110647,40.58141636607027,2.0520221498322826 ) ;
  }

  @Test
  public void test13() {
    beta.betacf(-83.71282377042186,85.68160502645006,-42.012195878625 ) ;
  }

  @Test
  public void test14() {
    beta.betacf(-85.82800050179293,91.47712876067447,-15.016122243007413 ) ;
  }

  @Test
  public void test15() {
    beta.betacf(-86.24731697899617,84.90764264823197,63.63286585506801 ) ;
  }

  @Test
  public void test16() {
    beta.betacf(9.676542078271822,-30.50285765363614,62.369177863050936 ) ;
  }

  @Test
  public void test17() {
    beta.betacf(-97.5633018438037,98.52893486224174,-99.99999999999959 ) ;
  }
}
