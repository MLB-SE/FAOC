import org.junit.Test;

public class TestexpintTest {

  @Test
  public void test0() {
    expint.expint(0,0.0 ) ;
  }

  @Test
  public void test1() {
    expint.expint(0,1.9034290808796328 ) ;
  }

  @Test
  public void test2() {
    expint.expint(107,2.0E-323 ) ;
  }

  @Test
  public void test3() {
    expint.expint(169,4.0E-323 ) ;
  }

  @Test
  public void test4() {
    expint.expint(2,0.0 ) ;
  }

  @Test
  public void test5() {
    expint.expint(275,63.020305903002395 ) ;
  }

  @Test
  public void test6() {
    expint.expint(347,1.5777218104420236E-30 ) ;
  }

  @Test
  public void test7() {
    expint.expint(394,89.72695769255569 ) ;
  }

  @Test
  public void test8() {
    expint.expint(4,-1.0E-322 ) ;
  }

  @Test
  public void test9() {
    expint.expint(423,-7.4E-323 ) ;
  }

  @Test
  public void test10() {
    expint.expint(434,1.93E-322 ) ;
  }

  @Test
  public void test11() {
    expint.expint(530,8.4E-323 ) ;
  }

  @Test
  public void test12() {
    expint.expint(59,0.0 ) ;
  }

  @Test
  public void test13() {
    expint.expint(711,0.0 ) ;
  }

  @Test
  public void test14() {
    expint.expint(713,0 ) ;
  }

  @Test
  public void test15() {
    expint.expint(755,-14.696109626323306 ) ;
  }

  @Test
  public void test16() {
    expint.expint(936,26.363293054977603 ) ;
  }

  @Test
  public void test17() {
    expint.expint(-971,0 ) ;
  }
}
