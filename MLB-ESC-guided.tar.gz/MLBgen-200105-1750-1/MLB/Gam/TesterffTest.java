import org.junit.Test;

public class TesterffTest {

  @Test
  public void test0() {
    gam.erff(0.10572822654209413 ) ;
  }

  @Test
  public void test1() {
    gam.erff(-0.3957388758563152 ) ;
  }

  @Test
  public void test2() {
    gam.erff(1.099182791037031 ) ;
  }

  @Test
  public void test3() {
    gam.erff(11.643357637304334 ) ;
  }

  @Test
  public void test4() {
    gam.erff(-1.2247448713915892 ) ;
  }

  @Test
  public void test5() {
    gam.erff(1.2247448713915892 ) ;
  }

  @Test
  public void test6() {
    gam.erff(-14.699219713174756 ) ;
  }

  @Test
  public void test7() {
    gam.erff(-1.8530151588109334 ) ;
  }

  @Test
  public void test8() {
    gam.erff(21.887089269414233 ) ;
  }

  @Test
  public void test9() {
    gam.erff(-2.220446049250313E-16 ) ;
  }

  @Test
  public void test10() {
    gam.erff(2.465190328815662E-32 ) ;
  }

  @Test
  public void test11() {
    gam.erff(3.556413999176124E-161 ) ;
  }

  @Test
  public void test12() {
    gam.erff(-4.351401483533664 ) ;
  }

  @Test
  public void test13() {
    gam.erff(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test14() {
    gam.erff(4.440892098500626E-16 ) ;
  }

  @Test
  public void test15() {
    gam.erff(-4.445517498970155E-162 ) ;
  }

  @Test
  public void test16() {
    gam.erff(63.33136516925711 ) ;
  }

  @Test
  public void test17() {
    gam.erff(-6.938893903907228E-18 ) ;
  }

  @Test
  public void test18() {
    gam.erff(-7.703719777548943E-34 ) ;
  }

  @Test
  public void test19() {
    gam.erff(-84.23452865582024 ) ;
  }

  @Test
  public void test20() {
    gam.erff(8.881784197001252E-16 ) ;
  }
}
