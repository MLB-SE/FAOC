import org.junit.Test;

public class TesterfccTest {

  @Test
  public void test0() {
    erf.erfcc(1.7531477673776783E-18 ) ;
  }

  @Test
  public void test1() {
    erf.erfcc(-34.654751103453776 ) ;
  }

  @Test
  public void test2() {
    erf.erfcc(-3.5E-323 ) ;
  }

  @Test
  public void test3() {
    erf.erfcc(3.8020722223645294 ) ;
  }

  @Test
  public void test4() {
    erf.erfcc(-3.944304526105059E-31 ) ;
  }

  @Test
  public void test5() {
    erf.erfcc(41.41855640265601 ) ;
  }

  @Test
  public void test6() {
    erf.erfcc(4.930380657631324E-32 ) ;
  }

  @Test
  public void test7() {
    erf.erfcc(4.9E-323 ) ;
  }

  @Test
  public void test8() {
    erf.erfcc(5.421010862427522E-20 ) ;
  }

  @Test
  public void test9() {
    erf.erfcc(-65.226736678186 ) ;
  }

  @Test
  public void test10() {
    erf.erfcc(65.45323023774915 ) ;
  }

  @Test
  public void test11() {
    erf.erfcc(81.57114909142084 ) ;
  }

  @Test
  public void test12() {
    erf.erfcc(-99.11904005254178 ) ;
  }
}
