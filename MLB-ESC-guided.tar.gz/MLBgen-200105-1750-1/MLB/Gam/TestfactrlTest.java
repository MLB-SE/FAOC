import org.junit.Test;

public class TestfactrlTest {

  @Test
  public void test0() {
    gam.factrl(0 ) ;
  }

  @Test
  public void test1() {
    gam.factrl(-1 ) ;
  }

  @Test
  public void test2() {
    gam.factrl(1 ) ;
  }

  @Test
  public void test3() {
    gam.factrl(216 ) ;
  }

  @Test
  public void test4() {
    gam.factrl(233 ) ;
  }

  @Test
  public void test5() {
    gam.factrl(5 ) ;
  }

  @Test
  public void test6() {
    gam.factrl(6 ) ;
  }

  @Test
  public void test7() {
    gam.factrl(-666 ) ;
  }

  @Test
  public void test8() {
    gam.factrl(-717 ) ;
  }

  @Test
  public void test9() {
    gam.factrl(796 ) ;
  }

  @Test
  public void test10() {
    gam.factrl(9 ) ;
  }

  @Test
  public void test11() {
    gam.factrl(-947 ) ;
  }
}
