import org.junit.Test;

public class TestbetaiTest {

  @Test
  public void test0() {
    beta.betai(0,0,0.7866010702367667 ) ;
  }

  @Test
  public void test1() {
    beta.betai(0,0,0.9999997895533045 ) ;
  }

  @Test
  public void test2() {
    beta.betai(0,0,0.9999999999999982 ) ;
  }

  @Test
  public void test3() {
    beta.betai(0,0,0.9999999999999996 ) ;
  }

  @Test
  public void test4() {
    beta.betai(0,0,0.9999999999999998 ) ;
  }

  @Test
  public void test5() {
    beta.betai(0,0,1.0 ) ;
  }

  @Test
  public void test6() {
    beta.betai(0,0,1.0000000000000009 ) ;
  }

  @Test
  public void test7() {
    beta.betai(0,0,1.000393590663455 ) ;
  }

  @Test
  public void test8() {
    beta.betai(0,0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test9() {
    beta.betai(0,0,12.607772039916142 ) ;
  }

  @Test
  public void test10() {
    beta.betai(0,0,13.023428774627547 ) ;
  }

  @Test
  public void test11() {
    beta.betai(0,0,14.88645773980349 ) ;
  }

  @Test
  public void test12() {
    beta.betai(0,0,2.1310231976187737 ) ;
  }

  @Test
  public void test13() {
    beta.betai(0,0,-2.7831824797963662 ) ;
  }

  @Test
  public void test14() {
    beta.betai(0,0,3.0385816786431356E-64 ) ;
  }

  @Test
  public void test15() {
    beta.betai(0,0,35.72748990941426 ) ;
  }

  @Test
  public void test16() {
    beta.betai(0,0,-47.53505071677655 ) ;
  }

  @Test
  public void test17() {
    beta.betai(0,0,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test18() {
    beta.betai(0,0,-5.1368883093730915 ) ;
  }

  @Test
  public void test19() {
    beta.betai(0,0,5.322691790838292 ) ;
  }

  @Test
  public void test20() {
    beta.betai(0,0,-5.661253843770325 ) ;
  }

  @Test
  public void test21() {
    beta.betai(0,0,-5.833394985046823 ) ;
  }

  @Test
  public void test22() {
    beta.betai(0,0,60.36892014342229 ) ;
  }

  @Test
  public void test23() {
    beta.betai(0,0,-72.10753048681758 ) ;
  }

  @Test
  public void test24() {
    beta.betai(0,0,8.472196200891815 ) ;
  }

  @Test
  public void test25() {
    beta.betai(0,0,91.5227291069202 ) ;
  }

  @Test
  public void test26() {
    beta.betai(0,0,-96.68061554215654 ) ;
  }
}
