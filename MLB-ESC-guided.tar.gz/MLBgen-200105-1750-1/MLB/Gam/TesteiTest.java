import org.junit.Test;

public class TesteiTest {

  @Test
  public void test0() {
    expint.ei(-1.0262647359303543 ) ;
  }

  @Test
  public void test1() {
    expint.ei(1.0E-322 ) ;
  }

  @Test
  public void test2() {
    expint.ei(1.3265438015561841 ) ;
  }

  @Test
  public void test3() {
    expint.ei(1.9721522630525295E-31 ) ;
  }

  @Test
  public void test4() {
    expint.ei(2.465190328815662E-32 ) ;
  }

  @Test
  public void test5() {
    expint.ei(-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test6() {
    expint.ei(32.23619130191664 ) ;
  }

  @Test
  public void test7() {
    expint.ei(35.51358614306886 ) ;
  }

  @Test
  public void test8() {
    expint.ei(3.552713678800501E-15 ) ;
  }

  @Test
  public void test9() {
    expint.ei(4.171508631820558 ) ;
  }

  @Test
  public void test10() {
    expint.ei(42.103503943043506 ) ;
  }

  @Test
  public void test11() {
    expint.ei(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test12() {
    expint.ei(4.720791896486503 ) ;
  }

  @Test
  public void test13() {
    expint.ei(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test14() {
    expint.ei(5.184648730962451 ) ;
  }

  @Test
  public void test15() {
    expint.ei(65.32834734717622 ) ;
  }

  @Test
  public void test16() {
    expint.ei(-76.45259000686872 ) ;
  }
}
