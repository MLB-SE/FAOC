import org.junit.Test;

public class TesterffcTest {

  @Test
  public void test0() {
    gam.erffc(0.5441534211099341 ) ;
  }

  @Test
  public void test1() {
    gam.erffc(-0.5682096923203344 ) ;
  }

  @Test
  public void test2() {
    gam.erffc(-11.23317887716388 ) ;
  }

  @Test
  public void test3() {
    gam.erffc(-1.2247448713915892 ) ;
  }

  @Test
  public void test4() {
    gam.erffc(1.2247448713915892 ) ;
  }

  @Test
  public void test5() {
    gam.erffc(-1.3052798939169747 ) ;
  }

  @Test
  public void test6() {
    gam.erffc(-1.5407439555097887E-33 ) ;
  }

  @Test
  public void test7() {
    gam.erffc(1.734723475976807E-18 ) ;
  }

  @Test
  public void test8() {
    gam.erffc(-20.91837396978042 ) ;
  }

  @Test
  public void test9() {
    gam.erffc(-2.220446049250313E-16 ) ;
  }

  @Test
  public void test10() {
    gam.erffc(2.7755575615628914E-17 ) ;
  }

  @Test
  public void test11() {
    gam.erffc(39.855290438071364 ) ;
  }

  @Test
  public void test12() {
    gam.erffc(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test13() {
    gam.erffc(5.556896873712694E-163 ) ;
  }

  @Test
  public void test14() {
    gam.erffc(59.054669808653955 ) ;
  }

  @Test
  public void test15() {
    gam.erffc(-7.001532724824756 ) ;
  }

  @Test
  public void test16() {
    gam.erffc(-7.112827998352248E-161 ) ;
  }

  @Test
  public void test17() {
    gam.erffc(71.19561220736759 ) ;
  }

  @Test
  public void test18() {
    gam.erffc(-8.881784197001252E-16 ) ;
  }

  @Test
  public void test19() {
    gam.erffc(8.881784197001252E-16 ) ;
  }
}
