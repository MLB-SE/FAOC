import org.junit.Test;

public class TestbetaTest {

  @Test
  public void test0() {
    beta.beta(-1.0,0 ) ;
  }

  @Test
  public void test1() {
    beta.beta(-2.0,0 ) ;
  }

  @Test
  public void test2() {
    beta.beta(21.33592406414573,0 ) ;
  }

  @Test
  public void test3() {
    beta.beta(-3.0,0 ) ;
  }

  @Test
  public void test4() {
    beta.beta(-35.92512096808855,0 ) ;
  }

  @Test
  public void test5() {
    beta.beta(-86.5999270037396,0 ) ;
  }
}
