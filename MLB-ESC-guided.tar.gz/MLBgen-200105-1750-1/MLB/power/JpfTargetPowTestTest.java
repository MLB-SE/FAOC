import org.junit.Test;

public class JpfTargetPowTestTest {

  @Test
  public void test0() {
    concolic.PowExample.test(17,289 ) ;
  }

  @Test
  public void test1() {
    concolic.PowExample.test(237,-595 ) ;
  }

  @Test
  public void test2() {
    concolic.PowExample.test(2,4 ) ;
  }

  @Test
  public void test3() {
    concolic.PowExample.test(25,625 ) ;
  }

  @Test
  public void test4() {
    concolic.PowExample.test(426,501 ) ;
  }

  @Test
  public void test5() {
    concolic.PowExample.test(-44,0 ) ;
  }

  @Test
  public void test6() {
    concolic.PowExample.test(741,0 ) ;
  }

  @Test
  public void test7() {
    concolic.PowExample.test(773,-835 ) ;
  }
}
