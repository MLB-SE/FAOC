import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(-111.7525904372207,0.0025856141116080713 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(-20.726892805972085,0.023825373994736054 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(-29.750000000000014,0 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(-36.590335713612454,-92.48292413659654 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(-38.75,-0.042857863951489356 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(40.844004148616904,-44.53305127293616 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonMethod.newton(-42.25,51.30895159769025 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonMethod.newton(-49.568905703119825,0 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonMethod.newton(-55.96351786638463,34.95216247126996 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonMethod.newton(659.6094545074274,0 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonMethod.newton(7.698338887828783,0 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonMethod.newton(-84.7536153752461,0.0036029689174057467 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonMethod.newton(-93.80525626072438,0 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonMethod.newton(-95.25,-1.4210854715202004E-14 ) ;
  }

  @Test
  public void test14() {
    scic.NewtonMethod.newton(-98.59582837187865,1.9013226951257565 ) ;
  }
}
