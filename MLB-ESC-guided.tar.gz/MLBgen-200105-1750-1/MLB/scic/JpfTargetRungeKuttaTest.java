import org.junit.Test;

public class JpfTargetRungeKuttaTest {

  @Test
  public void test0() {
    scic.RungeKutta.rungeKutta(-20.964660600277725 ) ;
  }

  @Test
  public void test1() {
    scic.RungeKutta.rungeKutta(26.090208708849772 ) ;
  }

  @Test
  public void test2() {
    scic.RungeKutta.rungeKutta(2714.201822816718 ) ;
  }

  @Test
  public void test3() {
    scic.RungeKutta.rungeKutta(2716.6982048715386 ) ;
  }

  @Test
  public void test4() {
    scic.RungeKutta.rungeKutta(2718.0169289950263 ) ;
  }

  @Test
  public void test5() {
    scic.RungeKutta.rungeKutta(2721.804301022832 ) ;
  }

  @Test
  public void test6() {
    scic.RungeKutta.rungeKutta(2722.367595634204 ) ;
  }

  @Test
  public void test7() {
    scic.RungeKutta.rungeKutta(2731.170159915802 ) ;
  }

  @Test
  public void test8() {
    scic.RungeKutta.rungeKutta(2731.834819940503 ) ;
  }

  @Test
  public void test9() {
    scic.RungeKutta.rungeKutta(2734.6882275071366 ) ;
  }

  @Test
  public void test10() {
    scic.RungeKutta.rungeKutta(2736.901064525288 ) ;
  }

  @Test
  public void test11() {
    scic.RungeKutta.rungeKutta(2743.4377857167165 ) ;
  }

  @Test
  public void test12() {
    scic.RungeKutta.rungeKutta(29.634495283385377 ) ;
  }

  @Test
  public void test13() {
    scic.RungeKutta.rungeKutta(-68.85922709282919 ) ;
  }

  @Test
  public void test14() {
    scic.RungeKutta.rungeKutta(-70.75933255571915 ) ;
  }

  @Test
  public void test15() {
    scic.RungeKutta.rungeKutta(80.8297727794907 ) ;
  }

  @Test
  public void test16() {
    scic.RungeKutta.rungeKutta(-92.10102102729343 ) ;
  }

  @Test
  public void test17() {
    scic.RungeKutta.rungeKutta(96.90094546599965 ) ;
  }
}
