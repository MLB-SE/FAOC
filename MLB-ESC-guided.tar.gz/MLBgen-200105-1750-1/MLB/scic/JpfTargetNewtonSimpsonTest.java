import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(-0.8293899846386381,78.03717686395174 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(10.621070058519805,0 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(-11.852369997619874,58.49494714903136 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(1.2164534948053927,-4.128250292820269 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(-13.263667946525914,0 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(1.6448549804665573,-92.74474139413682 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonSimpson.newton(-1.7018764160199567,-51.51419291354795 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonSimpson.newton(-20.163635086578353,0 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonSimpson.newton(26.39050765083526,0 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonSimpson.newton(-27.458712921875076,-78.87744477351433 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonSimpson.newton(3.015573089024471,-27.468252431643506 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonSimpson.newton(-34.67117006308884,-86.74181679296755 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonSimpson.newton(34.915370093725386,-48.80811408771566 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonSimpson.newton(87.80116441559821,0 ) ;
  }
}
