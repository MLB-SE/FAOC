import org.junit.Test;

public class JpfTargetCubedRootTest {

  @Test
  public void test0() {
    scic.CubedRoot.check(24.051288904168388 ) ;
  }

  @Test
  public void test1() {
    scic.CubedRoot.check(24.99854013611913 ) ;
  }

  @Test
  public void test2() {
    scic.CubedRoot.check(90.2972167957355 ) ;
  }
}
