import org.junit.Test;

public class JpfTargetEulerMethodTest {

  @Test
  public void test0() {
    scic.EulerMethod.euler(-18.24878174166011 ) ;
  }

  @Test
  public void test1() {
    scic.EulerMethod.euler(-73.19131286772333 ) ;
  }

  @Test
  public void test2() {
    scic.EulerMethod.euler(-9.044922323857278 ) ;
  }
}
