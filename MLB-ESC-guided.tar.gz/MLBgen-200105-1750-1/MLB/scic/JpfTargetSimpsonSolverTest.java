import org.junit.Test;

public class JpfTargetSimpsonSolverTest {

  @Test
  public void test0() {
    scic.SimpsonSolver.simpson(32.32136177560602,-17.75160852702429 ) ;
  }

  @Test
  public void test1() {
    scic.SimpsonSolver.simpson(-37.03342269181244,52.261971229221224 ) ;
  }

  @Test
  public void test2() {
    scic.SimpsonSolver.simpson(-55.92709373697504,86.98055216650121 ) ;
  }
}
