import org.junit.Test;

public class TestAiryTest {

  @Test
  public void test0() {
    airy.main_airy(-10.663337183114137 ) ;
  }

  @Test
  public void test1() {
    airy.main_airy(-1.232595164407831E-32 ) ;
  }

  @Test
  public void test2() {
    airy.main_airy(1.596264752580808 ) ;
  }

  @Test
  public void test3() {
    airy.main_airy(-1.734723475976807E-18 ) ;
  }

  @Test
  public void test4() {
    airy.main_airy(-2.1382117680737565E-50 ) ;
  }

  @Test
  public void test5() {
    airy.main_airy(21.706282220454767 ) ;
  }

  @Test
  public void test6() {
    airy.main_airy(-4.3225817678266135E-224 ) ;
  }

  @Test
  public void test7() {
    airy.main_airy(4.3225817678266135E-224 ) ;
  }

  @Test
  public void test8() {
    airy.main_airy(-43.547759659242715 ) ;
  }

  @Test
  public void test9() {
    airy.main_airy(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test10() {
    airy.main_airy(4.930380657631324E-32 ) ;
  }

  @Test
  public void test11() {
    airy.main_airy(-6.453754979057763 ) ;
  }

  @Test
  public void test12() {
    airy.main_airy(-64.91453315791065 ) ;
  }

  @Test
  public void test13() {
    airy.main_airy(-8.04128914134425 ) ;
  }

  @Test
  public void test14() {
    airy.main_airy(88.43311234905809 ) ;
  }

  @Test
  public void test15() {
    airy.main_airy(8.881784197001252E-16 ) ;
  }

  @Test
  public void test16() {
    airy.main_airy(90.10039606500132 ) ;
  }
}
