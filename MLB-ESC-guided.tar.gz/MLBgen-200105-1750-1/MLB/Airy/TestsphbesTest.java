import org.junit.Test;

public class TestsphbesTest {

  @Test
  public void test0() {
    airy.sphbes(0,1.1068509676675427 ) ;
  }

  @Test
  public void test1() {
    airy.sphbes(0,1.4508650962345486 ) ;
  }

  @Test
  public void test2() {
    airy.sphbes(0,16.658278431340577 ) ;
  }

  @Test
  public void test3() {
    airy.sphbes(0,24.999038761783865 ) ;
  }

  @Test
  public void test4() {
    airy.sphbes(0,41.22245455535162 ) ;
  }

  @Test
  public void test5() {
    airy.sphbes(0,54.065906428741016 ) ;
  }

  @Test
  public void test6() {
    airy.sphbes(1026,5.551115123125783E-17 ) ;
  }

  @Test
  public void test7() {
    airy.sphbes(-1120,2.0000000000000004 ) ;
  }

  @Test
  public void test8() {
    airy.sphbes(-1,17.829230881474075 ) ;
  }

  @Test
  public void test9() {
    airy.sphbes(1319,2.0000000000000004 ) ;
  }

  @Test
  public void test10() {
    airy.sphbes(1454,0.0 ) ;
  }

  @Test
  public void test11() {
    airy.sphbes(-152,0.05133936560277452 ) ;
  }

  @Test
  public void test12() {
    airy.sphbes(-1,97.26755629441394 ) ;
  }

  @Test
  public void test13() {
    airy.sphbes(241,-98.12518717797691 ) ;
  }

  @Test
  public void test14() {
    airy.sphbes(247,4.9E-323 ) ;
  }

  @Test
  public void test15() {
    airy.sphbes(-254,0 ) ;
  }

  @Test
  public void test16() {
    airy.sphbes(2743,2.0000000000044604 ) ;
  }

  @Test
  public void test17() {
    airy.sphbes(30,-15.039598433428807 ) ;
  }

  @Test
  public void test18() {
    airy.sphbes(349,4.9E-324 ) ;
  }

  @Test
  public void test19() {
    airy.sphbes(353,-2.5E-323 ) ;
  }

  @Test
  public void test20() {
    airy.sphbes(-366,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test21() {
    airy.sphbes(368,-1.3E-322 ) ;
  }

  @Test
  public void test22() {
    airy.sphbes(-411,-23.961807214965305 ) ;
  }

  @Test
  public void test23() {
    airy.sphbes(-426,2.0 ) ;
  }

  @Test
  public void test24() {
    airy.sphbes(429,2.1175823681357508E-22 ) ;
  }

  @Test
  public void test25() {
    airy.sphbes(437,1.43E-322 ) ;
  }

  @Test
  public void test26() {
    airy.sphbes(444,2.0000000000000147 ) ;
  }

  @Test
  public void test27() {
    airy.sphbes(475,0.0 ) ;
  }

  @Test
  public void test28() {
    airy.sphbes(47,94.31611083626962 ) ;
  }

  @Test
  public void test29() {
    airy.sphbes(-483,-31.38779475985818 ) ;
  }

  @Test
  public void test30() {
    airy.sphbes(486,-53.32869436330887 ) ;
  }

  @Test
  public void test31() {
    airy.sphbes(491,29.46752472377645 ) ;
  }

  @Test
  public void test32() {
    airy.sphbes(-496,2.0000000000000004 ) ;
  }

  @Test
  public void test33() {
    airy.sphbes(523,0 ) ;
  }

  @Test
  public void test34() {
    airy.sphbes(-56,98.80599162374685 ) ;
  }

  @Test
  public void test35() {
    airy.sphbes(-603,2.000000000000001 ) ;
  }

  @Test
  public void test36() {
    airy.sphbes(698,-8.4E-323 ) ;
  }

  @Test
  public void test37() {
    airy.sphbes(-701,0.0 ) ;
  }

  @Test
  public void test38() {
    airy.sphbes(704,-1.265E-321 ) ;
  }

  @Test
  public void test39() {
    airy.sphbes(78,1.0E-323 ) ;
  }

  @Test
  public void test40() {
    airy.sphbes(-8,0.0 ) ;
  }

  @Test
  public void test41() {
    airy.sphbes(822,0.0 ) ;
  }

  @Test
  public void test42() {
    airy.sphbes(850,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test43() {
    airy.sphbes(-854,82.085295593983 ) ;
  }

  @Test
  public void test44() {
    airy.sphbes(-926,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test45() {
    airy.sphbes(-929,66.84065502922155 ) ;
  }

  @Test
  public void test46() {
    airy.sphbes(969,0.0 ) ;
  }

  @Test
  public void test47() {
    airy.sphbes(-972,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test48() {
    airy.sphbes(987,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test49() {
    airy.sphbes(989,10.16579169213891 ) ;
  }

  @Test
  public void test50() {
    airy.sphbes(-994,0.0 ) ;
  }
}
