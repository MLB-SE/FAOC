import org.junit.Test;

public class TestbessiTest {

  @Test
  public void test0() {
    bess.bessi(1153,3.955353229727797E-36 ) ;
  }

  @Test
  public void test1() {
    bess.bessi(-12,8.13372056485557E-9 ) ;
  }

  @Test
  public void test2() {
    bess.bessi(135,0 ) ;
  }

  @Test
  public void test3() {
    bess.bessi(-1656,4.897552127881605E-9 ) ;
  }

  @Test
  public void test4() {
    bess.bessi(-196,-4.479694829947363 ) ;
  }

  @Test
  public void test5() {
    bess.bessi(280,0.0 ) ;
  }

  @Test
  public void test6() {
    bess.bessi(-344,0.0 ) ;
  }

  @Test
  public void test7() {
    bess.bessi(-43,-1.095514720246344E-50 ) ;
  }

  @Test
  public void test8() {
    bess.bessi(-442,0 ) ;
  }

  @Test
  public void test9() {
    bess.bessi(58,52.143148694002576 ) ;
  }

  @Test
  public void test10() {
    bess.bessi(594,-67.33600880499921 ) ;
  }

  @Test
  public void test11() {
    bess.bessi(-641,-6.3531849629858925 ) ;
  }

  @Test
  public void test12() {
    bess.bessi(666,36.685954854333005 ) ;
  }

  @Test
  public void test13() {
    bess.bessi(-839,76.2395623901098 ) ;
  }

  @Test
  public void test14() {
    bess.bessi(843,1.4801077668010899E-50 ) ;
  }

  @Test
  public void test15() {
    bess.bessi(919,1.8313766973065057E-9 ) ;
  }

  @Test
  public void test16() {
    bess.bessi(95,9.54683107457349E-9 ) ;
  }

  @Test
  public void test17() {
    bess.bessi(-977,-1.363145239490172E-31 ) ;
  }
}
