import org.junit.Test;

public class TestdawsonTest {

  @Test
  public void test0() {
    dawson.dawson(0.04563485360972663 ) ;
  }

  @Test
  public void test1() {
    dawson.dawson(-0.20000000000000004 ) ;
  }

  @Test
  public void test2() {
    dawson.dawson(-0.20000000000000007 ) ;
  }

  @Test
  public void test3() {
    dawson.dawson(-0.20000000000000018 ) ;
  }

  @Test
  public void test4() {
    dawson.dawson(0.20000000000000018 ) ;
  }

  @Test
  public void test5() {
    dawson.dawson(-0.3958418013809961 ) ;
  }

  @Test
  public void test6() {
    dawson.dawson(-0.39999999999999997 ) ;
  }

  @Test
  public void test7() {
    dawson.dawson(0.39999999999999997 ) ;
  }

  @Test
  public void test8() {
    dawson.dawson(-0.4000000000000098 ) ;
  }

  @Test
  public void test9() {
    dawson.dawson(-0.47469109752038596 ) ;
  }

  @Test
  public void test10() {
    dawson.dawson(-0.49267377612686547 ) ;
  }

  @Test
  public void test11() {
    dawson.dawson(-0.510102695941228 ) ;
  }

  @Test
  public void test12() {
    dawson.dawson(0.5320190020108129 ) ;
  }

  @Test
  public void test13() {
    dawson.dawson(0.6548898904709546 ) ;
  }

  @Test
  public void test14() {
    dawson.dawson(-0.6597293418458434 ) ;
  }

  @Test
  public void test15() {
    dawson.dawson(0.6906599648923927 ) ;
  }

  @Test
  public void test16() {
    dawson.dawson(-0.7574618674626095 ) ;
  }

  @Test
  public void test17() {
    dawson.dawson(0.7905912673363673 ) ;
  }

  @Test
  public void test18() {
    dawson.dawson(0.7997806495926184 ) ;
  }

  @Test
  public void test19() {
    dawson.dawson(0.7999999999999997 ) ;
  }

  @Test
  public void test20() {
    dawson.dawson(-0.7999999999999999 ) ;
  }

  @Test
  public void test21() {
    dawson.dawson(0.7999999999999999 ) ;
  }

  @Test
  public void test22() {
    dawson.dawson(0.8506347352376622 ) ;
  }

  @Test
  public void test23() {
    dawson.dawson(-1.1116296033046036 ) ;
  }

  @Test
  public void test24() {
    dawson.dawson(-11.532951300563397 ) ;
  }

  @Test
  public void test25() {
    dawson.dawson(13.381702748479654 ) ;
  }

  @Test
  public void test26() {
    dawson.dawson(-15.500048134419515 ) ;
  }

  @Test
  public void test27() {
    dawson.dawson(-1.5999999999999996 ) ;
  }

  @Test
  public void test28() {
    dawson.dawson(-1.7323114944589095 ) ;
  }

  @Test
  public void test29() {
    dawson.dawson(17.341433637894283 ) ;
  }

  @Test
  public void test30() {
    dawson.dawson(1.8813728078394147 ) ;
  }

  @Test
  public void test31() {
    dawson.dawson(18.884556926732117 ) ;
  }

  @Test
  public void test32() {
    dawson.dawson(2.007682264006718 ) ;
  }

  @Test
  public void test33() {
    dawson.dawson(23.079788394392438 ) ;
  }

  @Test
  public void test34() {
    dawson.dawson(2.419601252303616 ) ;
  }

  @Test
  public void test35() {
    dawson.dawson(-2.520718472880135 ) ;
  }

  @Test
  public void test36() {
    dawson.dawson(27.927077805230894 ) ;
  }

  @Test
  public void test37() {
    dawson.dawson(30.674976633819654 ) ;
  }

  @Test
  public void test38() {
    dawson.dawson(-3.3168557332244735 ) ;
  }

  @Test
  public void test39() {
    dawson.dawson(3.544123577598029 ) ;
  }

  @Test
  public void test40() {
    dawson.dawson(-39.66248184218166 ) ;
  }

  @Test
  public void test41() {
    dawson.dawson(-4.018487628114346 ) ;
  }

  @Test
  public void test42() {
    dawson.dawson(4.063449028737594 ) ;
  }

  @Test
  public void test43() {
    dawson.dawson(-41.22117060433301 ) ;
  }

  @Test
  public void test44() {
    dawson.dawson(-43.00892838616277 ) ;
  }

  @Test
  public void test45() {
    dawson.dawson(-43.00994615421174 ) ;
  }

  @Test
  public void test46() {
    dawson.dawson(45.91348871143907 ) ;
  }

  @Test
  public void test47() {
    dawson.dawson(50.05395184514464 ) ;
  }

  @Test
  public void test48() {
    dawson.dawson(-52.632337576526126 ) ;
  }

  @Test
  public void test49() {
    dawson.dawson(54.995097940276935 ) ;
  }

  @Test
  public void test50() {
    dawson.dawson(-55.26582414338343 ) ;
  }

  @Test
  public void test51() {
    dawson.dawson(-5.551115123125783E-17 ) ;
  }

  @Test
  public void test52() {
    dawson.dawson(62.488675667043225 ) ;
  }

  @Test
  public void test53() {
    dawson.dawson(-67.7136526378541 ) ;
  }

  @Test
  public void test54() {
    dawson.dawson(-67.89813901709796 ) ;
  }

  @Test
  public void test55() {
    dawson.dawson(-6.848138297630513 ) ;
  }

  @Test
  public void test56() {
    dawson.dawson(-69.94250710450135 ) ;
  }

  @Test
  public void test57() {
    dawson.dawson(-70.94639387524958 ) ;
  }

  @Test
  public void test58() {
    dawson.dawson(-74.597355542744 ) ;
  }

  @Test
  public void test59() {
    dawson.dawson(74.7812437716413 ) ;
  }

  @Test
  public void test60() {
    dawson.dawson(76.36256656489599 ) ;
  }

  @Test
  public void test61() {
    dawson.dawson(77.40231247349121 ) ;
  }

  @Test
  public void test62() {
    dawson.dawson(-85.81437258341167 ) ;
  }

  @Test
  public void test63() {
    dawson.dawson(-88.05761700143258 ) ;
  }

  @Test
  public void test64() {
    dawson.dawson(89.69369677638858 ) ;
  }

  @Test
  public void test65() {
    dawson.dawson(91.18256901239303 ) ;
  }

  @Test
  public void test66() {
    dawson.dawson(-97.26471785347827 ) ;
  }

  @Test
  public void test67() {
    dawson.dawson(-98.11801394479835 ) ;
  }

  @Test
  public void test68() {
    dawson.dawson(99.2005106270004 ) ;
  }

  @Test
  public void test69() {
    dawson.dawson(9.973824190770102 ) ;
  }
}
