import org.junit.Test;

public class TestbesskTest {

  @Test
  public void test0() {
    bess.bessk(10,9.860761315262648E-32 ) ;
  }

  @Test
  public void test1() {
    bess.bessk(-1882,4.5897193678777505E-15 ) ;
  }

  @Test
  public void test2() {
    bess.bessk(206,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test3() {
    bess.bessk(-210,-4.0E-323 ) ;
  }

  @Test
  public void test4() {
    bess.bessk(261,75.58130264510865 ) ;
  }

  @Test
  public void test5() {
    bess.bessk(265,-77.67816070722569 ) ;
  }

  @Test
  public void test6() {
    bess.bessk(28,-56.318373523052024 ) ;
  }

  @Test
  public void test7() {
    bess.bessk(305,8.881784197001252E-16 ) ;
  }

  @Test
  public void test8() {
    bess.bessk(-309,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test9() {
    bess.bessk(-332,2.0 ) ;
  }

  @Test
  public void test10() {
    bess.bessk(365,0.0 ) ;
  }

  @Test
  public void test11() {
    bess.bessk(-38,53.64336365431092 ) ;
  }

  @Test
  public void test12() {
    bess.bessk(386,2.0 ) ;
  }

  @Test
  public void test13() {
    bess.bessk(-392,2.3331590462580472E-302 ) ;
  }

  @Test
  public void test14() {
    bess.bessk(-394,2.0 ) ;
  }

  @Test
  public void test15() {
    bess.bessk(-397,-97.38579284588313 ) ;
  }

  @Test
  public void test16() {
    bess.bessk(406,-5.9E-323 ) ;
  }

  @Test
  public void test17() {
    bess.bessk(450,0 ) ;
  }

  @Test
  public void test18() {
    bess.bessk(-458,-1.468993529458956 ) ;
  }

  @Test
  public void test19() {
    bess.bessk(471,80.93237515915817 ) ;
  }

  @Test
  public void test20() {
    bess.bessk(582,1.5727251635226983E-16 ) ;
  }

  @Test
  public void test21() {
    bess.bessk(585,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test22() {
    bess.bessk(-632,0.374412845907666 ) ;
  }

  @Test
  public void test23() {
    bess.bessk(-688,7.79779570611585E-15 ) ;
  }

  @Test
  public void test24() {
    bess.bessk(-743,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test25() {
    bess.bessk(-778,0 ) ;
  }

  @Test
  public void test26() {
    bess.bessk(-786,0.0 ) ;
  }

  @Test
  public void test27() {
    bess.bessk(807,-1.0507614211323843E-286 ) ;
  }

  @Test
  public void test28() {
    bess.bessk(-895,27.41991286262507 ) ;
  }

  @Test
  public void test29() {
    bess.bessk(976,2.0 ) ;
  }
}
