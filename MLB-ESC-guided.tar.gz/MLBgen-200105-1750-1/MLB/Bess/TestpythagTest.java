import org.junit.Test;

public class TestpythagTest {

  @Test
  public void test0() {
    dawson.pythag(-0.00435903427065569,0.004359041782765496 ) ;
  }

  @Test
  public void test1() {
    dawson.pythag(0.007948719508945991,0.007948618045181923 ) ;
  }

  @Test
  public void test2() {
    dawson.pythag(0.016250994601582833,-0.01626951896273964 ) ;
  }

  @Test
  public void test3() {
    dawson.pythag(0.02732790808208458,0.02750512635284103 ) ;
  }

  @Test
  public void test4() {
    dawson.pythag(0.24528663969942865,-0.24550096451758366 ) ;
  }

  @Test
  public void test5() {
    dawson.pythag(-0.8362271936741763,-10.773917032669416 ) ;
  }

  @Test
  public void test6() {
    dawson.pythag(-1.0587911840678754E-22,-1.071632220110408E-22 ) ;
  }

  @Test
  public void test7() {
    dawson.pythag(-1.0607420034621637E-19,-2.4074124304840448E-35 ) ;
  }

  @Test
  public void test8() {
    dawson.pythag(-1.0704967419044184E-18,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test9() {
    dawson.pythag(1.0880748044313753E-32,1.0923861508031818E-32 ) ;
  }

  @Test
  public void test10() {
    dawson.pythag(-1.0E-323,0.0 ) ;
  }

  @Test
  public void test11() {
    dawson.pythag(1.0E-323,0.0 ) ;
  }

  @Test
  public void test12() {
    dawson.pythag(11.610557335793999,75.87922340064227 ) ;
  }

  @Test
  public void test13() {
    dawson.pythag(-1.232595164407831E-32,-9.921676290939393E-17 ) ;
  }

  @Test
  public void test14() {
    dawson.pythag(-1.2759570083227363E-17,1.2759570083227365E-17 ) ;
  }

  @Test
  public void test15() {
    dawson.pythag(-13.06629398726497,0 ) ;
  }

  @Test
  public void test16() {
    dawson.pythag(-1.402757983365378E-191,1.402757983365378E-191 ) ;
  }

  @Test
  public void test17() {
    dawson.pythag(1.4537257913688184E-20,1.4709446187989965E-20 ) ;
  }

  @Test
  public void test18() {
    dawson.pythag(-14.725974869528159,14.725974869528159 ) ;
  }

  @Test
  public void test19() {
    dawson.pythag(-1.5862136483222808E-117,1.761050914342067E-133 ) ;
  }

  @Test
  public void test20() {
    dawson.pythag(-1.7516230804060213E-46,-1.761025560795015E-46 ) ;
  }

  @Test
  public void test21() {
    dawson.pythag(1.807198072618439E-20,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test22() {
    dawson.pythag(-18.28509399053395,0.0 ) ;
  }

  @Test
  public void test23() {
    dawson.pythag(-1.9170203312433463E-20,3.8518598887744717E-34 ) ;
  }

  @Test
  public void test24() {
    dawson.pythag(-1.9791869568752685E-16,-9.101849222084123E-17 ) ;
  }

  @Test
  public void test25() {
    dawson.pythag(2.0108077949373637,-49.38675410787325 ) ;
  }

  @Test
  public void test26() {
    dawson.pythag(-2.112808837094195E-34,-2.1579248745847403E-34 ) ;
  }

  @Test
  public void test27() {
    dawson.pythag(21.217168249604,-22.816900533950886 ) ;
  }

  @Test
  public void test28() {
    dawson.pythag(-23.370412796980673,-23.370412796980673 ) ;
  }

  @Test
  public void test29() {
    dawson.pythag(-2.370520764993831E-16,2.370520821410364E-16 ) ;
  }

  @Test
  public void test30() {
    dawson.pythag(2.4074124304840448E-35,-2.4262203400972014E-35 ) ;
  }

  @Test
  public void test31() {
    dawson.pythag(25.356002507990766,51.974076538860544 ) ;
  }

  @Test
  public void test32() {
    dawson.pythag(-26.457702052268854,0.0 ) ;
  }

  @Test
  public void test33() {
    dawson.pythag(-2.7078371522971398E-5,-2.708074842894035E-5 ) ;
  }

  @Test
  public void test34() {
    dawson.pythag(27.60145287209747,-27.60145287209747 ) ;
  }

  @Test
  public void test35() {
    dawson.pythag(2.77555599454694E-17,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test36() {
    dawson.pythag(-28.509111933812736,-28.509111933812736 ) ;
  }

  @Test
  public void test37() {
    dawson.pythag(-2.926047721682624E-98,4.992786759623917E-83 ) ;
  }

  @Test
  public void test38() {
    dawson.pythag(3.2165720172402307E-35,3.2265434815403783E-35 ) ;
  }

  @Test
  public void test39() {
    dawson.pythag(3.221986853734912E-16,3.2219868537349125E-16 ) ;
  }

  @Test
  public void test40() {
    dawson.pythag(32.35737301279025,-32.35737301279025 ) ;
  }

  @Test
  public void test41() {
    dawson.pythag(-32.56613661806588,-39.44959637902667 ) ;
  }

  @Test
  public void test42() {
    dawson.pythag(3.2854647535725807E-21,-3.2854611210306396E-21 ) ;
  }

  @Test
  public void test43() {
    dawson.pythag(-3.3881317890172014E-21,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test44() {
    dawson.pythag(-3.4315177622335146E-17,-3.431517762233516E-17 ) ;
  }

  @Test
  public void test45() {
    dawson.pythag(-3.506894958413445E-192,-3.506894958413445E-192 ) ;
  }

  @Test
  public void test46() {
    dawson.pythag(3.6113866712798876E-33,3.611386678723944E-33 ) ;
  }

  @Test
  public void test47() {
    dawson.pythag(-3.6931914471142943E-127,4.4063007746266544E-111 ) ;
  }

  @Test
  public void test48() {
    dawson.pythag(-3.76158192263132E-37,3.3782334412776402E-21 ) ;
  }

  @Test
  public void test49() {
    dawson.pythag(-3.7964964810613537,80.47031247042887 ) ;
  }

  @Test
  public void test50() {
    dawson.pythag(3.7982270983039195E-65,-3.798420462292839E-65 ) ;
  }

  @Test
  public void test51() {
    dawson.pythag(38.77013088147611,38.77013088147611 ) ;
  }

  @Test
  public void test52() {
    dawson.pythag(3.944304526105059E-31,5.551115123125783E-17 ) ;
  }

  @Test
  public void test53() {
    dawson.pythag(-3.9484127069845653E-177,-4.383618698016806E-193 ) ;
  }

  @Test
  public void test54() {
    dawson.pythag(-39.63167359661236,-39.63167359661236 ) ;
  }

  @Test
  public void test55() {
    dawson.pythag(-4.119837905795835E-49,1.5192908393215678E-64 ) ;
  }

  @Test
  public void test56() {
    dawson.pythag(41.6062962983477,41.6062962983477 ) ;
  }

  @Test
  public void test57() {
    dawson.pythag(42.49674625346239,-43.560492416126365 ) ;
  }

  @Test
  public void test58() {
    dawson.pythag(-4.2741031326921934E-50,4.2741066478822527E-50 ) ;
  }

  @Test
  public void test59() {
    dawson.pythag(4.3790577010150533E-47,4.379074405794491E-47 ) ;
  }

  @Test
  public void test60() {
    dawson.pythag(-45.02169368243945,16.861067575207045 ) ;
  }

  @Test
  public void test61() {
    dawson.pythag(4.53093748680641E-17,4.53093748680641E-17 ) ;
  }

  @Test
  public void test62() {
    dawson.pythag(4.613061631499026E-273,3.283629441038701E-288 ) ;
  }

  @Test
  public void test63() {
    dawson.pythag(-4.6212976022136836E-274,5.1306710016229703E-290 ) ;
  }

  @Test
  public void test64() {
    dawson.pythag(46.927386653939664,69.18421528609258 ) ;
  }

  @Test
  public void test65() {
    dawson.pythag(-4.871328878818531,63.55577813182512 ) ;
  }

  @Test
  public void test66() {
    dawson.pythag(4.9355158837307067E-178,4.9355158837307067E-178 ) ;
  }

  @Test
  public void test67() {
    dawson.pythag(5.0539682649402436E-175,-5.611031933461512E-191 ) ;
  }

  @Test
  public void test68() {
    dawson.pythag(-51.85450703657744,52.88780281690629 ) ;
  }

  @Test
  public void test69() {
    dawson.pythag(5.201125122568342,0 ) ;
  }

  @Test
  public void test70() {
    dawson.pythag(5.4737999480003654E-48,5.4738221262688167E-48 ) ;
  }

  @Test
  public void test71() {
    dawson.pythag(-5.4E-323,0.0 ) ;
  }

  @Test
  public void test72() {
    dawson.pythag(5.4E-323,0.0 ) ;
  }

  @Test
  public void test73() {
    dawson.pythag(-55.15768817581639,0.0 ) ;
  }

  @Test
  public void test74() {
    dawson.pythag(-5.551115123125783E-17,-2.6469779601696886E-23 ) ;
  }

  @Test
  public void test75() {
    dawson.pythag(-5.7766220027674546E-275,-6.413338752028713E-291 ) ;
  }

  @Test
  public void test76() {
    dawson.pythag(5.930261117422229E-17,4.2351647362715017E-22 ) ;
  }

  @Test
  public void test77() {
    dawson.pythag(6.116236450222695E-297,0.0 ) ;
  }

  @Test
  public void test78() {
    dawson.pythag(-61.18203883169342,46.50827421325977 ) ;
  }

  @Test
  public void test79() {
    dawson.pythag(6.16550819542931E-33,-6.162975822039155E-33 ) ;
  }

  @Test
  public void test80() {
    dawson.pythag(-63.29221443720095,-22.166585277149096 ) ;
  }

  @Test
  public void test81() {
    dawson.pythag(63.70762941029763,-63.70762941029763 ) ;
  }

  @Test
  public void test82() {
    dawson.pythag(-64.25989115903367,64.25989115903367 ) ;
  }

  @Test
  public void test83() {
    dawson.pythag(-6.448388603129706E-130,-3.2033329522929615E-145 ) ;
  }

  @Test
  public void test84() {
    dawson.pythag(-67.49796944279281,-26.250361139161043 ) ;
  }

  @Test
  public void test85() {
    dawson.pythag(-6.9694115951737245,-84.5975881070814 ) ;
  }

  @Test
  public void test86() {
    dawson.pythag(7.01378991682689E-192,-7.786871055544975E-208 ) ;
  }

  @Test
  public void test87() {
    dawson.pythag(7.112827998352248E-161,7.896825413969131E-177 ) ;
  }

  @Test
  public void test88() {
    dawson.pythag(72.69874839919765,23.29422945296129 ) ;
  }

  @Test
  public void test89() {
    dawson.pythag(-73.19954975997297,-57.12937422259004 ) ;
  }

  @Test
  public void test90() {
    dawson.pythag(74.31600780617845,0 ) ;
  }

  @Test
  public void test91() {
    dawson.pythag(76.29994885338951,-3.9414547832508475 ) ;
  }

  @Test
  public void test92() {
    dawson.pythag(-79.92026148067234,79.92026148067234 ) ;
  }

  @Test
  public void test93() {
    dawson.pythag(-7.9E-323,0.0 ) ;
  }

  @Test
  public void test94() {
    dawson.pythag(85.42630155390793,45.609814621648184 ) ;
  }

  @Test
  public void test95() {
    dawson.pythag(85.4949604760022,0.0 ) ;
  }

  @Test
  public void test96() {
    dawson.pythag(87.65125637271885,-44.24172303562952 ) ;
  }

  @Test
  public void test97() {
    dawson.pythag(89.35048551930734,0.043076735108570574 ) ;
  }

  @Test
  public void test98() {
    dawson.pythag(91.68607891500474,91.68607891500474 ) ;
  }

  @Test
  public void test99() {
    dawson.pythag(-91.98852383952065,78.35825771477681 ) ;
  }

  @Test
  public void test100() {
    dawson.pythag(9.327039686977745,0.0 ) ;
  }

  @Test
  public void test101() {
    dawson.pythag(95.73846304932789,0.0 ) ;
  }

  @Test
  public void test102() {
    dawson.pythag(9.583892802481318E-17,-9.583892802481319E-17 ) ;
  }

  @Test
  public void test103() {
    dawson.pythag(-9.956417850272245E-17,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test104() {
    dawson.pythag(9.98197298586392,-8.260639007453236 ) ;
  }
}
