import org.junit.Test;

public class TestbessjTest {

  @Test
  public void test0() {
    bess.bessj(1,-1.0 ) ;
  }

  @Test
  public void test1() {
    bess.bessj(1,1.0 ) ;
  }

  @Test
  public void test2() {
    bess.bessj(112,-5.6902623986817984E-160 ) ;
  }

  @Test
  public void test3() {
    bess.bessj(-113,-2.2761049594727193E-159 ) ;
  }

  @Test
  public void test4() {
    bess.bessj(1167,1.1380524797363597E-159 ) ;
  }

  @Test
  public void test5() {
    bess.bessj(-117,0.0 ) ;
  }

  @Test
  public void test6() {
    bess.bessj(1,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test7() {
    bess.bessj(-163,-4.445517498970155E-162 ) ;
  }

  @Test
  public void test8() {
    bess.bessj(1,7.105427357601002E-15 ) ;
  }

  @Test
  public void test9() {
    bess.bessj(-198,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test10() {
    bess.bessj(-207,-26.7962350589152 ) ;
  }

  @Test
  public void test11() {
    bess.bessj(21,21.0 ) ;
  }

  @Test
  public void test12() {
    bess.bessj(227,0.0 ) ;
  }

  @Test
  public void test13() {
    bess.bessj(-234,84.93338255180888 ) ;
  }

  @Test
  public void test14() {
    bess.bessj(-254,0 ) ;
  }

  @Test
  public void test15() {
    bess.bessj(276,2.5269841324701218E-175 ) ;
  }

  @Test
  public void test16() {
    bess.bessj(333,0.0 ) ;
  }

  @Test
  public void test17() {
    bess.bessj(-370,-41.5736125093469 ) ;
  }

  @Test
  public void test18() {
    bess.bessj(379,-18.014368326714276 ) ;
  }

  @Test
  public void test19() {
    bess.bessj(-399,3.1587301655876523E-176 ) ;
  }

  @Test
  public void test20() {
    bess.bessj(419,9.385923595631311 ) ;
  }

  @Test
  public void test21() {
    bess.bessj(-491,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test22() {
    bess.bessj(504,-4.445517498970155E-162 ) ;
  }

  @Test
  public void test23() {
    bess.bessj(-552,2.0E-323 ) ;
  }

  @Test
  public void test24() {
    bess.bessj(-582,1.4225655996704496E-160 ) ;
  }

  @Test
  public void test25() {
    bess.bessj(597,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test26() {
    bess.bessj(-61,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test27() {
    bess.bessj(637,98.62613263627179 ) ;
  }

  @Test
  public void test28() {
    bess.bessj(-648,-68.12310757070298 ) ;
  }

  @Test
  public void test29() {
    bess.bessj(649,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test30() {
    bess.bessj(696,0 ) ;
  }

  @Test
  public void test31() {
    bess.bessj(69,81.21819499578177 ) ;
  }

  @Test
  public void test32() {
    bess.bessj(70,-70.0 ) ;
  }

  @Test
  public void test33() {
    bess.bessj(72,-93.31190849495339 ) ;
  }

  @Test
  public void test34() {
    bess.bessj(738,3.4730605460704336E-164 ) ;
  }

  @Test
  public void test35() {
    bess.bessj(742,-75.5423725469274 ) ;
  }

  @Test
  public void test36() {
    bess.bessj(-747,80.24161698768489 ) ;
  }

  @Test
  public void test37() {
    bess.bessj(77,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test38() {
    bess.bessj(793,92.48235611256717 ) ;
  }

  @Test
  public void test39() {
    bess.bessj(-797,32.38061253200203 ) ;
  }

  @Test
  public void test40() {
    bess.bessj(836,2.220446049250313E-16 ) ;
  }

  @Test
  public void test41() {
    bess.bessj(-836,-7.112827998352248E-161 ) ;
  }

  @Test
  public void test42() {
    bess.bessj(844,0.0 ) ;
  }

  @Test
  public void test43() {
    bess.bessj(-848,0.0 ) ;
  }

  @Test
  public void test44() {
    bess.bessj(87,-17.795962784812986 ) ;
  }

  @Test
  public void test45() {
    bess.bessj(876,-7.112827998352248E-161 ) ;
  }

  @Test
  public void test46() {
    bess.bessj(-908,0.0 ) ;
  }
}
