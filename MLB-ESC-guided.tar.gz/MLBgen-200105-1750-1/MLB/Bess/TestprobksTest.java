import org.junit.Test;

public class TestprobksTest {

  @Test
  public void test0() {
    dawson.probks(13.276707472940004 ) ;
  }

  @Test
  public void test1() {
    dawson.probks(-1.3961335245481337 ) ;
  }

  @Test
  public void test2() {
    dawson.probks(-19.290743132357665 ) ;
  }

  @Test
  public void test3() {
    dawson.probks(-19.298174313319574 ) ;
  }

  @Test
  public void test4() {
    dawson.probks(19.301104519453105 ) ;
  }

  @Test
  public void test5() {
    dawson.probks(-19.301285832531637 ) ;
  }

  @Test
  public void test6() {
    dawson.probks(-2.9378359336112823 ) ;
  }

  @Test
  public void test7() {
    dawson.probks(-34.26593460774761 ) ;
  }

  @Test
  public void test8() {
    dawson.probks(-47.20830773013651 ) ;
  }

  @Test
  public void test9() {
    dawson.probks(-61.896821682680184 ) ;
  }

  @Test
  public void test10() {
    dawson.probks(74.04147591612767 ) ;
  }

  @Test
  public void test11() {
    dawson.probks(7.875065273343523 ) ;
  }

  @Test
  public void test12() {
    dawson.probks(-8.655468895333044 ) ;
  }

  @Test
  public void test13() {
    dawson.probks(9.51380185531206 ) ;
  }

  @Test
  public void test14() {
    dawson.probks(9.892514056682828 ) ;
  }
}
