import org.junit.Test;

public class TestbessyTest {

  @Test
  public void test0() {
    bess.bessy(1856,8.0 ) ;
  }

  @Test
  public void test1() {
    bess.bessy(-218,0 ) ;
  }

  @Test
  public void test2() {
    bess.bessy(-277,8.0 ) ;
  }

  @Test
  public void test3() {
    bess.bessy(28,0.0 ) ;
  }

  @Test
  public void test4() {
    bess.bessy(297,-98.2222395470471 ) ;
  }

  @Test
  public void test5() {
    bess.bessy(-364,0.0 ) ;
  }

  @Test
  public void test6() {
    bess.bessy(432,80.5093052611858 ) ;
  }

  @Test
  public void test7() {
    bess.bessy(-457,-33.68117639130294 ) ;
  }

  @Test
  public void test8() {
    bess.bessy(703,0 ) ;
  }

  @Test
  public void test9() {
    bess.bessy(-8,-72.7387339346687 ) ;
  }

  @Test
  public void test10() {
    bess.bessy(927,-52.96159822582045 ) ;
  }

  @Test
  public void test11() {
    bess.bessy(-956,79.94554285985251 ) ;
  }
}
