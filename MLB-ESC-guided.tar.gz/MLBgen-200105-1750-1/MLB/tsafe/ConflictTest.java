import org.junit.Test;

public class ConflictTest {

  @Test
  public void test0() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,0.0 ) ;
  }

  @Test
  public void test2() {
    tsafe.Conflict.snippet(0.0,0.0,0,0,0,0,-27.02243655966586 ) ;
  }

  @Test
  public void test3() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,-11.653997968619656 ) ;
  }

  @Test
  public void test4() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,-2.4E-322 ) ;
  }

  @Test
  public void test5() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,85.41704086386677 ) ;
  }

  @Test
  public void test6() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,87.85210794674762 ) ;
  }

  @Test
  public void test7() {
    tsafe.Conflict.snippet(0.0,-100.0,-100.0,-24.326752999973124,-58.71178149784307,100.0,66.1312845480594 ) ;
  }

  @Test
  public void test8() {
    tsafe.Conflict.snippet(0.0,-22.400178499325456,2.627595796405061E-14,0,0,0,-90.0 ) ;
  }

  @Test
  public void test9() {
    tsafe.Conflict.snippet(0.0,-23.603497986317592,46.1887649890692,97.14990872061155,-994.2650025197391,96.31935209266251,40.31526821872194 ) ;
  }

  @Test
  public void test10() {
    tsafe.Conflict.snippet(0.0,28.392879721536197,-100.0,1.557837276612963,0.1521309046082574,5.43098236981195,42.84989764475744 ) ;
  }

  @Test
  public void test11() {
    tsafe.Conflict.snippet(0.0,-32.95202236569827,41.922776321792114,-62.63067668698981,-5.295320825148628,-21.33971118194811,45.18186363990873 ) ;
  }

  @Test
  public void test12() {
    tsafe.Conflict.snippet(0.0,47.427013561772895,0,0,0,0,-23.594022176468798 ) ;
  }

  @Test
  public void test13() {
    tsafe.Conflict.snippet(0.0,51.51454399265984,7.233997656721294E-57,0,0,0,-90.00000000000001 ) ;
  }

  @Test
  public void test14() {
    tsafe.Conflict.snippet(0.05294581012114079,187.46848085128215,-164.41017117392832,-977.6112374057233,204.1489615242583,-148.8072899652598,0.05911808256490936 ) ;
  }

  @Test
  public void test15() {
    tsafe.Conflict.snippet(0.0,-61.208525078815214,-1.5503650723370802E-97,0,0,0,-90.0 ) ;
  }

  @Test
  public void test16() {
    tsafe.Conflict.snippet(0.0,7.140689963143652,-3.045490938730798,0,0,0,-82.2972533510233 ) ;
  }

  @Test
  public void test17() {
    tsafe.Conflict.snippet(0.0,-75.6515634185559,-51.327450172865845,-1.907443439760485,0.6013813466634039,-71.61210527580792,-76.81029359057065 ) ;
  }

  @Test
  public void test18() {
    tsafe.Conflict.snippet(-0.5174625920099784,369.8677143306866,181.02905357285522,176.67276128286187,-982.9752917477139,14.359395751886751,-59.28709852012409 ) ;
  }

  @Test
  public void test19() {
    tsafe.Conflict.snippet(0.9836448465298417,74.60210526250214,-50.777348234292695,13.91012621069288,-93.33712248375676,56.75776597096208,-48.565210580843534 ) ;
  }

  @Test
  public void test20() {
    tsafe.Conflict.snippet(100.0,0.0,0,0,0,0,-1.288464150561218 ) ;
  }

  @Test
  public void test21() {
    tsafe.Conflict.snippet(100.0,0,0,0,0,0,-2.8E-322 ) ;
  }

  @Test
  public void test22() {
    tsafe.Conflict.snippet(-100.0,-115.58433824370618,-13.967582101980172,-128.9911970483849,-990.4130421325206,-133.0908155639733,35.17582933537244 ) ;
  }

  @Test
  public void test23() {
    tsafe.Conflict.snippet(100.0,-130.99163143958867,-2.016699521399966E-17,0,0,0,90.0 ) ;
  }

  @Test
  public void test24() {
    tsafe.Conflict.snippet(-100.0,37.00102279600098,-7.73420959747924E-51,0,0,0,90.0 ) ;
  }

  @Test
  public void test25() {
    tsafe.Conflict.snippet(-1.0052001872855798E-6,-6.05426447784582,-96.89596003771459,22.616604053138328,1015.6468657272891,-85.70318664958675,59.76796940361126 ) ;
  }

  @Test
  public void test26() {
    tsafe.Conflict.snippet(-1.0189605030403617,0,0,0,0,0,-8.9905E-320 ) ;
  }

  @Test
  public void test27() {
    tsafe.Conflict.snippet(108.88991136128615,-261.9979183164621,-95.87279820462727,183.26987155654848,982.3620961732769,-172.85540533649817,73.90361221448296 ) ;
  }

  @Test
  public void test28() {
    tsafe.Conflict.snippet(126.54162471527903,68.69460843272925,-2.837490552381155,-1026.4953024610775,-123.1602036611972,90.7693969331373,42.760301535310475 ) ;
  }

  @Test
  public void test29() {
    tsafe.Conflict.snippet(-128.32536485080757,68.28390027089239,-217.48231591357228,-999.6924522721173,-35.69572116224718,143.23762339098673,-156.2756364031826 ) ;
  }

  @Test
  public void test30() {
    tsafe.Conflict.snippet(1.3322676295501878E-15,-159.12489561834943,-34.65582807601067,-923.7023519210031,380.49305519901276,49.35276423578199,-20.28071387103328 ) ;
  }

  @Test
  public void test31() {
    tsafe.Conflict.snippet(-141.2105956120932,-55.9906983398256,82.92584506174768,-0.20504395832428202,2.1655404653142107,28.8943674685035,-19.326677413043196 ) ;
  }

  @Test
  public void test32() {
    tsafe.Conflict.snippet(1.4210854715202004E-14,-100.0,-1.825816012563645E-21,0,0,0,90.0 ) ;
  }

  @Test
  public void test33() {
    tsafe.Conflict.snippet(-1.83E-322,0,0,0,0,0,100.0 ) ;
  }

  @Test
  public void test34() {
    tsafe.Conflict.snippet(1.83E-322,0,0,0,0,0,-100.0 ) ;
  }

  @Test
  public void test35() {
    tsafe.Conflict.snippet(1.8E-322,0,0,0,0,0,47.75900793355921 ) ;
  }

  @Test
  public void test36() {
    tsafe.Conflict.snippet(-19.149988427610225,-14.245611044184031,-84.76738346416354,96.21603206249321,42.86585386150699,-85.66828409937506,-88.11134745840828 ) ;
  }

  @Test
  public void test37() {
    tsafe.Conflict.snippet(-1.93E-322,0,0,0,0,0,17.49728393259736 ) ;
  }

  @Test
  public void test38() {
    tsafe.Conflict.snippet(-2.0672940974933596,0,0,0,0,0,5.922993342620458 ) ;
  }

  @Test
  public void test39() {
    tsafe.Conflict.snippet(-21.287596784220767,55.86400578384161,230.3465735019446,995.2457183163041,89.73050461223198,29.319093811205192,12.568741334781734 ) ;
  }

  @Test
  public void test40() {
    tsafe.Conflict.snippet(2.17E-322,0,0,0,0,0,100.0 ) ;
  }

  @Test
  public void test41() {
    tsafe.Conflict.snippet(-2.220446049250313E-16,0,0,0,0,0,27.527021767758157 ) ;
  }

  @Test
  public void test42() {
    tsafe.Conflict.snippet(2.220446049250313E-16,29.402376920875646,-59.15921573600363,-271.5158741375172,985.9732421390519,130.2682034530906,7.1744592309564155 ) ;
  }

  @Test
  public void test43() {
    tsafe.Conflict.snippet(-22.804404096811325,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test44() {
    tsafe.Conflict.snippet(2.284978703823621,0,0,0,0,0,1.8E-322 ) ;
  }

  @Test
  public void test45() {
    tsafe.Conflict.snippet(260.4494963892673,-7.372788585871831,-128.92996807461873,-995.255125812383,85.91001945520213,-42.20407870447114,-53.80530542509739 ) ;
  }

  @Test
  public void test46() {
    tsafe.Conflict.snippet(-2.6269035528309608E-287,0,0,0,0,0,-67.67152464741484 ) ;
  }

  @Test
  public void test47() {
    tsafe.Conflict.snippet(-27.22341799628785,0,0,0,0,0,51.01818640608272 ) ;
  }

  @Test
  public void test48() {
    tsafe.Conflict.snippet(2.8E-322,0,0,0,0,0,100.0 ) ;
  }

  @Test
  public void test49() {
    tsafe.Conflict.snippet(-3.0484081552882356E-12,-13.143434125048756,-14.697116995985056,-167.66664574245797,1020.8978176302961,62.91302803845249,34.35292739233816 ) ;
  }

  @Test
  public void test50() {
    tsafe.Conflict.snippet(3.3550186669737758E-68,-100.0,-3.104889180456393E-15,0,0,0,-90.0 ) ;
  }

  @Test
  public void test51() {
    tsafe.Conflict.snippet(33.860618604521164,0,0,0,0,0,-38.24083951794472 ) ;
  }

  @Test
  public void test52() {
    tsafe.Conflict.snippet(-37.077992388600144,-46.846784351153346,-63.957874176326925,0,0,0,67.98359425383373 ) ;
  }

  @Test
  public void test53() {
    tsafe.Conflict.snippet(-3.7106744059185472,47.210472221952415,-5.125258181161706E-29,0,0,0,90.0 ) ;
  }

  @Test
  public void test54() {
    tsafe.Conflict.snippet(-37.24289769775939,63.93703788324049,0,0,0,0,78.2191609232953 ) ;
  }

  @Test
  public void test55() {
    tsafe.Conflict.snippet(-37.35762625918348,0,0,0,0,0,-4.0474E-320 ) ;
  }

  @Test
  public void test56() {
    tsafe.Conflict.snippet(-3.860209150431602E-34,0,0,0,0,0,-180.00000000000003 ) ;
  }

  @Test
  public void test57() {
    tsafe.Conflict.snippet(39.98978646838293,-74.42195891902008,58.63898571427751,-16.4928167992922,-17.47711466261019,69.16372009074593,-45.80294731856904 ) ;
  }

  @Test
  public void test58() {
    tsafe.Conflict.snippet(-41.28949112964422,93.16593054760861,49.84385248177338,-46.36641275349225,69.10749148215186,4.866085178576455,18.71320862953469 ) ;
  }

  @Test
  public void test59() {
    tsafe.Conflict.snippet(4.440892098500626E-15,0,0,0,0,0,-26.153522049060783 ) ;
  }

  @Test
  public void test60() {
    tsafe.Conflict.snippet(-4.440892098500626E-16,0,0,0,0,0,100.0 ) ;
  }

  @Test
  public void test61() {
    tsafe.Conflict.snippet(4.440892098500626E-16,0,0,0,0,0,-51.07114628597331 ) ;
  }

  @Test
  public void test62() {
    tsafe.Conflict.snippet(46.79778135425268,78.339173145225,-3.190817399629231,998.8988754089401,-9.656759561916203,11.495071347730356,-26.78585968609343 ) ;
  }

  @Test
  public void test63() {
    tsafe.Conflict.snippet(-48.613901935056546,0,0,0,0,0,86.62004718401195 ) ;
  }

  @Test
  public void test64() {
    tsafe.Conflict.snippet(58.82604126382962,-39.56122147452575,-26.91487653996736,65.59971514007475,87.38159523500578,-73.94755170580873,0.001490759417076326 ) ;
  }

  @Test
  public void test65() {
    tsafe.Conflict.snippet(60.956155769976284,0,0,0,0,0,0.0 ) ;
  }

  @Test
  public void test66() {
    tsafe.Conflict.snippet(62.857649329911595,0,0,0,0,0,-72.80915292907058 ) ;
  }

  @Test
  public void test67() {
    tsafe.Conflict.snippet(-6.305298405546383,-42.691890572516165,100.0,-37.70179746955199,-45.775109234065454,-56.97762990865761,-5.738335050011756E-4 ) ;
  }

  @Test
  public void test68() {
    tsafe.Conflict.snippet(-6.47582E-319,0,0,0,0,0,48.68083312935805 ) ;
  }

  @Test
  public void test69() {
    tsafe.Conflict.snippet(-71.61450081079805,0,0,0,0,0,0.0 ) ;
  }

  @Test
  public void test70() {
    tsafe.Conflict.snippet(-75.94753429464794,72.22352581058671,-6.364280248475289E-50,0,0,0,90.0 ) ;
  }

  @Test
  public void test71() {
    tsafe.Conflict.snippet(76.45692057762307,-22.192553804199846,0,0,0,0,98.40522844785292 ) ;
  }

  @Test
  public void test72() {
    tsafe.Conflict.snippet(7.711334881145126E-4,18.00702889979452,-57.164995149443065,-994.8555948576998,331.9907685626066,99.7549978816335,73.36475437241927 ) ;
  }

  @Test
  public void test73() {
    tsafe.Conflict.snippet(-7.888609052210118E-31,31.52593616965652,3.0868007392074833E-11,0,0,0,-90.0 ) ;
  }

  @Test
  public void test74() {
    tsafe.Conflict.snippet(79.85868791500413,-100.0,-6.980403620253604E-53,0,0,0,-90.0 ) ;
  }

  @Test
  public void test75() {
    tsafe.Conflict.snippet(80.31495657631424,37.421627007069276,53.26246258149567,0,0,0,47.77485002409014 ) ;
  }

  @Test
  public void test76() {
    tsafe.Conflict.snippet(85.24891246668787,0,0,0,0,0,-47.08698749682539 ) ;
  }

  @Test
  public void test77() {
    tsafe.Conflict.snippet(86.05295658754903,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test78() {
    tsafe.Conflict.snippet(8.707282197245595,-45.34121445489837,124.16955243484813,1.2395689017857083,-1.5801003242540037,-49.56246618640834,-9.718763591859158 ) ;
  }

  @Test
  public void test79() {
    tsafe.Conflict.snippet(8.881784197001252E-16,147.02768512222485,-86.166009738529,998.738699712881,-37.20842240686867,12.335554892038374,-212.34804769387284 ) ;
  }

  @Test
  public void test80() {
    tsafe.Conflict.snippet(91.53266526995777,-100.0,3.456487904303936E-94,0,0,0,-90.0 ) ;
  }

  @Test
  public void test81() {
    tsafe.Conflict.snippet(-9.300785708026986,-276.3934491698812,-46.45329341164367,-1003.0143678597439,89.99634273230313,8.163889318869451,48.84775230635714 ) ;
  }

  @Test
  public void test82() {
    tsafe.Conflict.snippet(-94.26925062186619,0.0,0,0,0,0,-79.7467847607799 ) ;
  }

  @Test
  public void test83() {
    tsafe.Conflict.snippet(-99.99997988153683,-98.70438713852465,95.95395121134266,-0.2771286621658899,-1.976978925708873,86.18938115941137,92.51306344987316 ) ;
  }

  @Test
  public void test84() {
    tsafe.Conflict.snippet(99.99999860166633,-35.44345909390538,20.51855460162346,-0.25817326242736627,1.9807165343055322,100.0,-77.14045005723509 ) ;
  }
}
