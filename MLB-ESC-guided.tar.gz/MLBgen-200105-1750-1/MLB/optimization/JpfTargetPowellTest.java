import org.junit.Test;

public class JpfTargetPowellTest {

  @Test
  public void test0() {
    Optimization.powell(12.383495005819853,34.31119785864411 ) ;
  }

  @Test
  public void test1() {
    Optimization.powell(-1.2466363730943755E-4,-0.8021585296102185 ) ;
  }

  @Test
  public void test2() {
    Optimization.powell(-1.3132015949679499E-4,-0.7614977044133168 ) ;
  }

  @Test
  public void test3() {
    Optimization.powell(-2.4355100881523566E-5,-4.105916066061655 ) ;
  }

  @Test
  public void test4() {
    Optimization.powell(-5.498444028421826,-1.8186963345101503E-5 ) ;
  }

  @Test
  public void test5() {
    Optimization.powell(-82.92629051441943,46.46307252492076 ) ;
  }
}
