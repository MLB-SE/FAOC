import org.junit.Test;

public class JpfTargetBealeTest {

  @Test
  public void test0() {
    Optimization.beale(0.5916171981911588,-1.5354232510247812 ) ;
  }

  @Test
  public void test1() {
    Optimization.beale(-47.71407185734247,-26.339229485215185 ) ;
  }

  @Test
  public void test2() {
    Optimization.beale(78.01048953605743,-21.027903832520693 ) ;
  }
}
