import org.junit.Test;

public class JpfTargetHelicalValleyTest {

  @Test
  public void test0() {
    Optimization.theta(100.0,17.705390187107177 ) ;
  }

  @Test
  public void test1() {
    Optimization.theta(-1.1102230246251565E-16,46.6861784885501 ) ;
  }

  @Test
  public void test2() {
    Optimization.theta(13.471247578731129,-44.062441003315236 ) ;
  }

  @Test
  public void test3() {
    Optimization.theta(-1.3877787807814457E-17,100.0 ) ;
  }

  @Test
  public void test4() {
    Optimization.theta(-16.81063012999911,0 ) ;
  }

  @Test
  public void test5() {
    Optimization.theta(17.00334194679249,1.8454809747440635 ) ;
  }

  @Test
  public void test6() {
    Optimization.theta(18.258622619163603,-73.58996194042362 ) ;
  }

  @Test
  public void test7() {
    Optimization.theta(-2.220446049250313E-16,100.0 ) ;
  }

  @Test
  public void test8() {
    Optimization.theta(24.462764761439228,49.25102512288985 ) ;
  }

  @Test
  public void test9() {
    Optimization.theta(25.951547911182814,0 ) ;
  }

  @Test
  public void test10() {
    Optimization.theta(2.9283488892967426,0 ) ;
  }

  @Test
  public void test11() {
    Optimization.theta(30.32977311851093,-37.0219309690133 ) ;
  }

  @Test
  public void test12() {
    Optimization.theta(3.286065364325694,0 ) ;
  }

  @Test
  public void test13() {
    Optimization.theta(3.8472296964340558,-74.30811186946605 ) ;
  }

  @Test
  public void test14() {
    Optimization.theta(-44.28759728466191,88.08412341034301 ) ;
  }

  @Test
  public void test15() {
    Optimization.theta(-44.386096211572514,-8.363371721003192 ) ;
  }

  @Test
  public void test16() {
    Optimization.theta(-4.440892098500626E-16,56.73450639949291 ) ;
  }

  @Test
  public void test17() {
    Optimization.theta(-4.440892098500626E-16,58.817233806610396 ) ;
  }

  @Test
  public void test18() {
    Optimization.theta(-44.44477778999805,-66.40141120561505 ) ;
  }

  @Test
  public void test19() {
    Optimization.theta(-5.293955920339377E-23,98.06869276698873 ) ;
  }

  @Test
  public void test20() {
    Optimization.theta(56.901040825679104,0 ) ;
  }

  @Test
  public void test21() {
    Optimization.theta(-58.78434041515823,-45.79729081657602 ) ;
  }

  @Test
  public void test22() {
    Optimization.theta(-6.380154564794915E-15,100.0 ) ;
  }

  @Test
  public void test23() {
    Optimization.theta(-6.938893903907228E-18,99.9634660450537 ) ;
  }

  @Test
  public void test24() {
    Optimization.theta(-73.04571681617126,0 ) ;
  }

  @Test
  public void test25() {
    Optimization.theta(79.9574878151757,-50.02179539076245 ) ;
  }

  @Test
  public void test26() {
    Optimization.theta(-85.164316256413,-1.2121639363368515 ) ;
  }

  @Test
  public void test27() {
    Optimization.theta(-8.673617379884035E-19,0 ) ;
  }

  @Test
  public void test28() {
    Optimization.theta(-87.22487352837717,-34.868326588065 ) ;
  }

  @Test
  public void test29() {
    Optimization.theta(-88.78945918880868,0 ) ;
  }

  @Test
  public void test30() {
    Optimization.theta(-96.71329905251385,61.51205738985322 ) ;
  }

  @Test
  public void test31() {
    Optimization.theta(-9.860761315262648E-32,0 ) ;
  }

  @Test
  public void test32() {
    Optimization.theta(99.27358355550825,0.0 ) ;
  }
}
