import org.junit.Test;

public class JpfTargetRosenbrockTest {

  @Test
  public void test0() {
    Optimization.rosenbrock(2.0877449976723432,4.35928245327568 ) ;
  }

  @Test
  public void test1() {
    Optimization.rosenbrock(2.1172807356234205,4.4843373559894815 ) ;
  }

  @Test
  public void test2() {
    Optimization.rosenbrock(2.520975726085249,6.3553521601627665 ) ;
  }

  @Test
  public void test3() {
    Optimization.rosenbrock(-67.76989456118994,-75.86870859059383 ) ;
  }

  @Test
  public void test4() {
    Optimization.rosenbrock(-9.104540906235856,82.89456093600657 ) ;
  }
}
