import org.junit.Test;

public class JpfTargetFreudensteinRothTest {

  @Test
  public void test0() {
    Optimization.freudensteinRoth(-28.155979514052177,5.595152696288764 ) ;
  }

  @Test
  public void test1() {
    Optimization.freudensteinRoth(-32.17273424897964,0.08939240990699204 ) ;
  }

  @Test
  public void test2() {
    Optimization.freudensteinRoth(-71.87323061741992,-26.09800222655751 ) ;
  }
}
