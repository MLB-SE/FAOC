import org.junit.Test;

public class JpfTargetWoodTest {

  @Test
  public void test0() {
    Optimization.wood(-0.9943516176679026,-60.96835168868837,0,0 ) ;
  }

  @Test
  public void test1() {
    Optimization.wood(1.0,0.9999999999999427,1.0,0.9999999999999427 ) ;
  }

  @Test
  public void test2() {
    Optimization.wood(1.0,0.9999999999999998,1.0,1.0 ) ;
  }

  @Test
  public void test3() {
    Optimization.wood(1.0,0.9999999999999999,1.0,1.0 ) ;
  }

  @Test
  public void test4() {
    Optimization.wood(1.0,1.0,0,0 ) ;
  }

  @Test
  public void test5() {
    Optimization.wood(1.0,1.0000000000000002,1.0,1.0 ) ;
  }

  @Test
  public void test6() {
    Optimization.wood(1.0,1.0000000000000004,1.0,1.0 ) ;
  }

  @Test
  public void test7() {
    Optimization.wood(1.0,1.0,1.0,0.9999999999999999 ) ;
  }

  @Test
  public void test8() {
    Optimization.wood(1.0,1.0,1.0,1.0 ) ;
  }

  @Test
  public void test9() {
    Optimization.wood(1.0,1.0,1.0,1.0000000000000004 ) ;
  }

  @Test
  public void test10() {
    Optimization.wood(1.0,1.0,19.417200399030747,-13.339220460253358 ) ;
  }

  @Test
  public void test11() {
    Optimization.wood(1.0,1.0,-2.344522091215776,5.496783836198794 ) ;
  }

  @Test
  public void test12() {
    Optimization.wood(1.0,1.0,2.9815565274312483,22.99247661146362 ) ;
  }

  @Test
  public void test13() {
    Optimization.wood(1.0,1.0,4.130730137913369,17.062931472265802 ) ;
  }

  @Test
  public void test14() {
    Optimization.wood(1.0,1.0,4.820694454454781,23.23909502321108 ) ;
  }

  @Test
  public void test15() {
    Optimization.wood(1.0,-28.626513104367795,1.0,-28.626513104367795 ) ;
  }

  @Test
  public void test16() {
    Optimization.wood(1.2395271611657108,1.536427583267526,0,0 ) ;
  }

  @Test
  public void test17() {
    Optimization.wood(1.2828516264812322,87.38225799630922,0,0 ) ;
  }

  @Test
  public void test18() {
    Optimization.wood(-6.378067684103235,40.679747383002,0,0 ) ;
  }

  @Test
  public void test19() {
    Optimization.wood(-7.405741782045581,54.84501134233566,0,0 ) ;
  }
}
