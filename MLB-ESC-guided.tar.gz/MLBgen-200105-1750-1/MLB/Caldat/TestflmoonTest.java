import org.junit.Test;

public class TestflmoonTest {

  @Test
  public void test0() {
    caldat.flmoon(0,0 ) ;
  }

  @Test
  public void test1() {
    caldat.flmoon(0,1 ) ;
  }

  @Test
  public void test2() {
    caldat.flmoon(0,2 ) ;
  }

  @Test
  public void test3() {
    caldat.flmoon(0,245 ) ;
  }

  @Test
  public void test4() {
    caldat.flmoon(0,3 ) ;
  }

  @Test
  public void test5() {
    caldat.flmoon(0,-448 ) ;
  }

  @Test
  public void test6() {
    caldat.flmoon(0,-559 ) ;
  }

  @Test
  public void test7() {
    caldat.flmoon(0,-632 ) ;
  }

  @Test
  public void test8() {
    caldat.flmoon(-1,0 ) ;
  }

  @Test
  public void test9() {
    caldat.flmoon(-1007,-31 ) ;
  }

  @Test
  public void test10() {
    caldat.flmoon(-1023,25 ) ;
  }

  @Test
  public void test11() {
    caldat.flmoon(-109,437 ) ;
  }

  @Test
  public void test12() {
    caldat.flmoon(-1,1 ) ;
  }

  @Test
  public void test13() {
    caldat.flmoon(1,1 ) ;
  }

  @Test
  public void test14() {
    caldat.flmoon(-1,2 ) ;
  }

  @Test
  public void test15() {
    caldat.flmoon(-124,494 ) ;
  }

  @Test
  public void test16() {
    caldat.flmoon(1270,11 ) ;
  }

  @Test
  public void test17() {
    caldat.flmoon(-1,3 ) ;
  }

  @Test
  public void test18() {
    caldat.flmoon(1365,6 ) ;
  }

  @Test
  public void test19() {
    caldat.flmoon(-15,3 ) ;
  }

  @Test
  public void test20() {
    caldat.flmoon(-162,3 ) ;
  }

  @Test
  public void test21() {
    caldat.flmoon(1667,-4 ) ;
  }

  @Test
  public void test22() {
    caldat.flmoon(17,-70 ) ;
  }

  @Test
  public void test23() {
    caldat.flmoon(198,2 ) ;
  }

  @Test
  public void test24() {
    caldat.flmoon(2,-10 ) ;
  }

  @Test
  public void test25() {
    caldat.flmoon(-2,3 ) ;
  }

  @Test
  public void test26() {
    caldat.flmoon(-2437,-2 ) ;
  }

  @Test
  public void test27() {
    caldat.flmoon(-243,970 ) ;
  }

  @Test
  public void test28() {
    caldat.flmoon(313,-271 ) ;
  }

  @Test
  public void test29() {
    caldat.flmoon(-382,1 ) ;
  }

  @Test
  public void test30() {
    caldat.flmoon(382,12 ) ;
  }

  @Test
  public void test31() {
    caldat.flmoon(-412,1 ) ;
  }

  @Test
  public void test32() {
    caldat.flmoon(419,-6 ) ;
  }

  @Test
  public void test33() {
    caldat.flmoon(-463,1 ) ;
  }

  @Test
  public void test34() {
    caldat.flmoon(-500,1018 ) ;
  }

  @Test
  public void test35() {
    caldat.flmoon(-505,5 ) ;
  }

  @Test
  public void test36() {
    caldat.flmoon(516,220 ) ;
  }

  @Test
  public void test37() {
    caldat.flmoon(-522,2 ) ;
  }

  @Test
  public void test38() {
    caldat.flmoon(-539,3 ) ;
  }

  @Test
  public void test39() {
    caldat.flmoon(547,1 ) ;
  }

  @Test
  public void test40() {
    caldat.flmoon(548,1 ) ;
  }

  @Test
  public void test41() {
    caldat.flmoon(-583,0 ) ;
  }

  @Test
  public void test42() {
    caldat.flmoon(-584,-10 ) ;
  }

  @Test
  public void test43() {
    caldat.flmoon(-693,2 ) ;
  }

  @Test
  public void test44() {
    caldat.flmoon(-720,7 ) ;
  }

  @Test
  public void test45() {
    caldat.flmoon(-721,300 ) ;
  }

  @Test
  public void test46() {
    caldat.flmoon(727,0 ) ;
  }

  @Test
  public void test47() {
    caldat.flmoon(728,3 ) ;
  }

  @Test
  public void test48() {
    caldat.flmoon(733,6 ) ;
  }

  @Test
  public void test49() {
    caldat.flmoon(742,-550 ) ;
  }

  @Test
  public void test50() {
    caldat.flmoon(761,976 ) ;
  }

  @Test
  public void test51() {
    caldat.flmoon(795,3 ) ;
  }

  @Test
  public void test52() {
    caldat.flmoon(-808,-1 ) ;
  }

  @Test
  public void test53() {
    caldat.flmoon(828,36 ) ;
  }

  @Test
  public void test54() {
    caldat.flmoon(837,0 ) ;
  }

  @Test
  public void test55() {
    caldat.flmoon(86,0 ) ;
  }

  @Test
  public void test56() {
    caldat.flmoon(-91,0 ) ;
  }

  @Test
  public void test57() {
    caldat.flmoon(-951,-738 ) ;
  }

  @Test
  public void test58() {
    caldat.flmoon(955,2 ) ;
  }
}
