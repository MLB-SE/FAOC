import org.junit.Test;

public class TestcaldatTest {

  @Test
  public void test0() {
    caldat.caldat(0 ) ;
  }

  @Test
  public void test1() {
    caldat.caldat(-1 ) ;
  }

  @Test
  public void test2() {
    caldat.caldat(11 ) ;
  }

  @Test
  public void test3() {
    caldat.caldat(11120 ) ;
  }

  @Test
  public void test4() {
    caldat.caldat(-132 ) ;
  }

  @Test
  public void test5() {
    caldat.caldat(19 ) ;
  }

  @Test
  public void test6() {
    caldat.caldat(2 ) ;
  }

  @Test
  public void test7() {
    caldat.caldat(26262 ) ;
  }

  @Test
  public void test8() {
    caldat.caldat(-282 ) ;
  }

  @Test
  public void test9() {
    caldat.caldat(2925 ) ;
  }

  @Test
  public void test10() {
    caldat.caldat(-301 ) ;
  }

  @Test
  public void test11() {
    caldat.caldat(318 ) ;
  }

  @Test
  public void test12() {
    caldat.caldat(-322 ) ;
  }

  @Test
  public void test13() {
    caldat.caldat(-328 ) ;
  }

  @Test
  public void test14() {
    caldat.caldat(-343 ) ;
  }

  @Test
  public void test15() {
    caldat.caldat(-363 ) ;
  }

  @Test
  public void test16() {
    caldat.caldat(410 ) ;
  }

  @Test
  public void test17() {
    caldat.caldat(431 ) ;
  }

  @Test
  public void test18() {
    caldat.caldat(457 ) ;
  }

  @Test
  public void test19() {
    caldat.caldat(513 ) ;
  }

  @Test
  public void test20() {
    caldat.caldat(54 ) ;
  }

  @Test
  public void test21() {
    caldat.caldat(559 ) ;
  }

  @Test
  public void test22() {
    caldat.caldat(-624 ) ;
  }

  @Test
  public void test23() {
    caldat.caldat(-648 ) ;
  }

  @Test
  public void test24() {
    caldat.caldat(-678 ) ;
  }

  @Test
  public void test25() {
    caldat.caldat(-756 ) ;
  }

  @Test
  public void test26() {
    caldat.caldat(-787 ) ;
  }

  @Test
  public void test27() {
    caldat.caldat(-794 ) ;
  }

  @Test
  public void test28() {
    caldat.caldat(869 ) ;
  }
}
