import org.junit.Test;

public class TestjuldayTest {

  @Test
  public void test0() {
    caldat.julday(0,0,0 ) ;
  }

  @Test
  public void test1() {
    caldat.julday(0,0,50 ) ;
  }

  @Test
  public void test2() {
    caldat.julday(0,0,-700 ) ;
  }

  @Test
  public void test3() {
    caldat.julday(0,0,919 ) ;
  }

  @Test
  public void test4() {
    caldat.julday(0,32581,2 ) ;
  }

  @Test
  public void test5() {
    caldat.julday(0,48220,-1 ) ;
  }

  @Test
  public void test6() {
    caldat.julday(0,936,1739 ) ;
  }

  @Test
  public void test7() {
    caldat.julday(-10,-1306,930 ) ;
  }

  @Test
  public void test8() {
    caldat.julday(1040,0,0 ) ;
  }

  @Test
  public void test9() {
    caldat.julday(1,1621,-584 ) ;
  }

  @Test
  public void test10() {
    caldat.julday(-12,0,868 ) ;
  }

  @Test
  public void test11() {
    caldat.julday(123,0,-861 ) ;
  }

  @Test
  public void test12() {
    caldat.julday(1,237,1633 ) ;
  }

  @Test
  public void test13() {
    caldat.julday(-13,0,0 ) ;
  }

  @Test
  public void test14() {
    caldat.julday(-13,0,-512 ) ;
  }

  @Test
  public void test15() {
    caldat.julday(-13,0,534 ) ;
  }

  @Test
  public void test16() {
    caldat.julday(-13,0,565 ) ;
  }

  @Test
  public void test17() {
    caldat.julday(-13,0,-933 ) ;
  }

  @Test
  public void test18() {
    caldat.julday(-13,13959,-2 ) ;
  }

  @Test
  public void test19() {
    caldat.julday(-13,-1777,386 ) ;
  }

  @Test
  public void test20() {
    caldat.julday(-13,237,341 ) ;
  }

  @Test
  public void test21() {
    caldat.julday(-13,278,1849 ) ;
  }

  @Test
  public void test22() {
    caldat.julday(-13,30349,4 ) ;
  }

  @Test
  public void test23() {
    caldat.julday(-13,30589,-5 ) ;
  }

  @Test
  public void test24() {
    caldat.julday(-13,-422,2279 ) ;
  }

  @Test
  public void test25() {
    caldat.julday(-13,-447,-996 ) ;
  }

  @Test
  public void test26() {
    caldat.julday(-13,534,0 ) ;
  }

  @Test
  public void test27() {
    caldat.julday(-13,-995,-77 ) ;
  }

  @Test
  public void test28() {
    caldat.julday(-141,-393,384 ) ;
  }

  @Test
  public void test29() {
    caldat.julday(-1,44040,4 ) ;
  }

  @Test
  public void test30() {
    caldat.julday(-14,48937,-8 ) ;
  }

  @Test
  public void test31() {
    caldat.julday(-14,49640,0 ) ;
  }

  @Test
  public void test32() {
    caldat.julday(-147,0,-1 ) ;
  }

  @Test
  public void test33() {
    caldat.julday(-15,49505,-2 ) ;
  }

  @Test
  public void test34() {
    caldat.julday(-155,0,2 ) ;
  }

  @Test
  public void test35() {
    caldat.julday(-160,0,-160 ) ;
  }

  @Test
  public void test36() {
    caldat.julday(-16,21213,-1 ) ;
  }

  @Test
  public void test37() {
    caldat.julday(172,0,1 ) ;
  }

  @Test
  public void test38() {
    caldat.julday(-17,29917,-4 ) ;
  }

  @Test
  public void test39() {
    caldat.julday(-18,0,0 ) ;
  }

  @Test
  public void test40() {
    caldat.julday(-18,48396,-4 ) ;
  }

  @Test
  public void test41() {
    caldat.julday(19257,1342,-9 ) ;
  }

  @Test
  public void test42() {
    caldat.julday(19270,1729,-8 ) ;
  }

  @Test
  public void test43() {
    caldat.julday(19400,-259,0 ) ;
  }

  @Test
  public void test44() {
    caldat.julday(-2,0,0 ) ;
  }

  @Test
  public void test45() {
    caldat.julday(-2,0,-132 ) ;
  }

  @Test
  public void test46() {
    caldat.julday(-2,0,-201 ) ;
  }

  @Test
  public void test47() {
    caldat.julday(203,0,0 ) ;
  }

  @Test
  public void test48() {
    caldat.julday(-2,0,302 ) ;
  }

  @Test
  public void test49() {
    caldat.julday(-2,0,356 ) ;
  }

  @Test
  public void test50() {
    caldat.julday(-2,0,-585 ) ;
  }

  @Test
  public void test51() {
    caldat.julday(-2,0,-631 ) ;
  }

  @Test
  public void test52() {
    caldat.julday(-2,0,784 ) ;
  }

  @Test
  public void test53() {
    caldat.julday(209,0,-209 ) ;
  }

  @Test
  public void test54() {
    caldat.julday(-2,0,929 ) ;
  }

  @Test
  public void test55() {
    caldat.julday(-2,124,797 ) ;
  }

  @Test
  public void test56() {
    caldat.julday(2,19445,-28 ) ;
  }

  @Test
  public void test57() {
    caldat.julday(-22,20927,-4 ) ;
  }

  @Test
  public void test58() {
    caldat.julday(-22,33694,-1 ) ;
  }

  @Test
  public void test59() {
    caldat.julday(2,30775,4 ) ;
  }

  @Test
  public void test60() {
    caldat.julday(2,31655,1 ) ;
  }

  @Test
  public void test61() {
    caldat.julday(2,48762,0 ) ;
  }

  @Test
  public void test62() {
    caldat.julday(-2,607,0 ) ;
  }

  @Test
  public void test63() {
    caldat.julday(-286,0,-673 ) ;
  }

  @Test
  public void test64() {
    caldat.julday(-288,0,2 ) ;
  }

  @Test
  public void test65() {
    caldat.julday(-29,33531,0 ) ;
  }

  @Test
  public void test66() {
    caldat.julday(-295,0,-1 ) ;
  }

  @Test
  public void test67() {
    caldat.julday(-297,0,1 ) ;
  }

  @Test
  public void test68() {
    caldat.julday(-3,0,0 ) ;
  }

  @Test
  public void test69() {
    caldat.julday(-30,23307,1 ) ;
  }

  @Test
  public void test70() {
    caldat.julday(310,-17,0 ) ;
  }

  @Test
  public void test71() {
    caldat.julday(-3,15185,-16 ) ;
  }

  @Test
  public void test72() {
    caldat.julday(316,0,127 ) ;
  }

  @Test
  public void test73() {
    caldat.julday(-3,21891,1 ) ;
  }

  @Test
  public void test74() {
    caldat.julday(-366,0,1 ) ;
  }

  @Test
  public void test75() {
    caldat.julday(-3,677,-819 ) ;
  }

  @Test
  public void test76() {
    caldat.julday(387,449,2036 ) ;
  }

  @Test
  public void test77() {
    caldat.julday(-39,0,1 ) ;
  }

  @Test
  public void test78() {
    caldat.julday(395,0,-340 ) ;
  }

  @Test
  public void test79() {
    caldat.julday(397,0,16 ) ;
  }

  @Test
  public void test80() {
    caldat.julday(4,0,0 ) ;
  }

  @Test
  public void test81() {
    caldat.julday(4,0,-1065 ) ;
  }

  @Test
  public void test82() {
    caldat.julday(4,0,-1223 ) ;
  }

  @Test
  public void test83() {
    caldat.julday(4,0,-23 ) ;
  }

  @Test
  public void test84() {
    caldat.julday(4,0,239 ) ;
  }

  @Test
  public void test85() {
    caldat.julday(4,0,279 ) ;
  }

  @Test
  public void test86() {
    caldat.julday(-4,0,-455 ) ;
  }

  @Test
  public void test87() {
    caldat.julday(4,0,544 ) ;
  }

  @Test
  public void test88() {
    caldat.julday(-4,0,797 ) ;
  }

  @Test
  public void test89() {
    caldat.julday(4,0,-841 ) ;
  }

  @Test
  public void test90() {
    caldat.julday(-412,0,-592 ) ;
  }

  @Test
  public void test91() {
    caldat.julday(-4,18102,-1 ) ;
  }

  @Test
  public void test92() {
    caldat.julday(424,-426,-410 ) ;
  }

  @Test
  public void test93() {
    caldat.julday(-425,0,657 ) ;
  }

  @Test
  public void test94() {
    caldat.julday(434,0,434 ) ;
  }

  @Test
  public void test95() {
    caldat.julday(-444,0,0 ) ;
  }

  @Test
  public void test96() {
    caldat.julday(-454,0,0 ) ;
  }

  @Test
  public void test97() {
    caldat.julday(-456,-1054,0 ) ;
  }

  @Test
  public void test98() {
    caldat.julday(46,0,1 ) ;
  }

  @Test
  public void test99() {
    caldat.julday(476,0,761 ) ;
  }

  @Test
  public void test100() {
    caldat.julday(-48,1675,1809 ) ;
  }

  @Test
  public void test101() {
    caldat.julday(519,0,-1 ) ;
  }

  @Test
  public void test102() {
    caldat.julday(-520,0,1 ) ;
  }

  @Test
  public void test103() {
    caldat.julday(567,0,-1 ) ;
  }

  @Test
  public void test104() {
    caldat.julday(580,935,828 ) ;
  }

  @Test
  public void test105() {
    caldat.julday(610,-792,-773 ) ;
  }

  @Test
  public void test106() {
    caldat.julday(-628,523,-164 ) ;
  }

  @Test
  public void test107() {
    caldat.julday(-6,29882,-1 ) ;
  }

  @Test
  public void test108() {
    caldat.julday(670,-301,1777 ) ;
  }

  @Test
  public void test109() {
    caldat.julday(-68,12923,0 ) ;
  }

  @Test
  public void test110() {
    caldat.julday(690,0,-904 ) ;
  }

  @Test
  public void test111() {
    caldat.julday(-696,0,955 ) ;
  }

  @Test
  public void test112() {
    caldat.julday(704,0,0 ) ;
  }

  @Test
  public void test113() {
    caldat.julday(713,0,484 ) ;
  }

  @Test
  public void test114() {
    caldat.julday(-739,0,7 ) ;
  }

  @Test
  public void test115() {
    caldat.julday(-817,-410,381 ) ;
  }

  @Test
  public void test116() {
    caldat.julday(-819,0,-95 ) ;
  }

  @Test
  public void test117() {
    caldat.julday(-8,45373,0 ) ;
  }

  @Test
  public void test118() {
    caldat.julday(-8,51038,-2 ) ;
  }

  @Test
  public void test119() {
    caldat.julday(-853,163,1660 ) ;
  }

  @Test
  public void test120() {
    caldat.julday(870,0,-1 ) ;
  }

  @Test
  public void test121() {
    caldat.julday(885,0,1 ) ;
  }

  @Test
  public void test122() {
    caldat.julday(909,0,-403 ) ;
  }

  @Test
  public void test123() {
    caldat.julday(-923,-913,-798 ) ;
  }

  @Test
  public void test124() {
    caldat.julday(93,0,1 ) ;
  }

  @Test
  public void test125() {
    caldat.julday(-951,0,703 ) ;
  }

  @Test
  public void test126() {
    caldat.julday(974,0,-1 ) ;
  }

  @Test
  public void test127() {
    caldat.julday(-976,0,0 ) ;
  }

  @Test
  public void test128() {
    caldat.julday(978,766,490 ) ;
  }

  @Test
  public void test129() {
    caldat.julday(-980,0,-784 ) ;
  }

  @Test
  public void test130() {
    caldat.julday(-98,0,897 ) ;
  }
}
