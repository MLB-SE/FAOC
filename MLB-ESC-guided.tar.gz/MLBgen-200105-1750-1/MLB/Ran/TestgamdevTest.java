import org.junit.Test;

public class TestgamdevTest {

  @Test
  public void test0() {
    dev.gamdev(1,0 ) ;
  }

  @Test
  public void test1() {
    dev.gamdev(-120,0 ) ;
  }

  @Test
  public void test2() {
    dev.gamdev(14,-695 ) ;
  }

  @Test
  public void test3() {
    dev.gamdev(210,-627 ) ;
  }

  @Test
  public void test4() {
    dev.gamdev(2,-408 ) ;
  }

  @Test
  public void test5() {
    dev.gamdev(327,0 ) ;
  }

  @Test
  public void test6() {
    dev.gamdev(3,742 ) ;
  }

  @Test
  public void test7() {
    dev.gamdev(4,0 ) ;
  }

  @Test
  public void test8() {
    dev.gamdev(456,591 ) ;
  }

  @Test
  public void test9() {
    dev.gamdev(491,0 ) ;
  }

  @Test
  public void test10() {
    dev.gamdev(493,-1 ) ;
  }

  @Test
  public void test11() {
    dev.gamdev(-584,0 ) ;
  }

  @Test
  public void test12() {
    dev.gamdev(6,0 ) ;
  }

  @Test
  public void test13() {
    dev.gamdev(637,0 ) ;
  }

  @Test
  public void test14() {
    dev.gamdev(872,560 ) ;
  }

  @Test
  public void test15() {
    dev.gamdev(-987,0 ) ;
  }
}
