import org.junit.Test;

public class TestexpdevTest {

  @Test
  public void test0() {
    dev.expdev(0 ) ;
  }

  @Test
  public void test1() {
    dev.expdev(-1 ) ;
  }

  @Test
  public void test2() {
    dev.expdev(-160 ) ;
  }

  @Test
  public void test3() {
    dev.expdev(-233 ) ;
  }

  @Test
  public void test4() {
    dev.expdev(329 ) ;
  }

  @Test
  public void test5() {
    dev.expdev(541 ) ;
  }

  @Test
  public void test6() {
    dev.expdev(-631 ) ;
  }

  @Test
  public void test7() {
    dev.expdev(-669 ) ;
  }

  @Test
  public void test8() {
    dev.expdev(-770 ) ;
  }
}
