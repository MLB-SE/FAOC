import org.junit.Test;

public class TestbnldevTest {

  @Test
  public void test0() {
    dev.bnldev(0.0,25,0 ) ;
  }

  @Test
  public void test1() {
    dev.bnldev(0.0,654,0 ) ;
  }

  @Test
  public void test2() {
    dev.bnldev(1.0,-250,0 ) ;
  }

  @Test
  public void test3() {
    dev.bnldev(1.0,26,0 ) ;
  }

  @Test
  public void test4() {
    dev.bnldev(1.0,30,0 ) ;
  }

  @Test
  public void test5() {
    dev.bnldev(1.0,404,0 ) ;
  }

  @Test
  public void test6() {
    dev.bnldev(1.0,-56,0 ) ;
  }

  @Test
  public void test7() {
    dev.bnldev(1.0,-863,0 ) ;
  }

  @Test
  public void test8() {
    dev.bnldev(1.0,-934,0 ) ;
  }

  @Test
  public void test9() {
    dev.bnldev(-1365.0,3,574 ) ;
  }

  @Test
  public void test10() {
    dev.bnldev(13.97090354425184,0,0 ) ;
  }

  @Test
  public void test11() {
    dev.bnldev(-159.0,-80,0 ) ;
  }

  @Test
  public void test12() {
    dev.bnldev(176.0,23,-853 ) ;
  }

  @Test
  public void test13() {
    dev.bnldev(-180.0,-250,0 ) ;
  }

  @Test
  public void test14() {
    dev.bnldev(199.0,-999,0 ) ;
  }

  @Test
  public void test15() {
    dev.bnldev(-20.0,-977,0 ) ;
  }

  @Test
  public void test16() {
    dev.bnldev(2.798163502856667,0,0 ) ;
  }

  @Test
  public void test17() {
    dev.bnldev(292.0,18,270 ) ;
  }

  @Test
  public void test18() {
    dev.bnldev(-334.0,-1,0 ) ;
  }

  @Test
  public void test19() {
    dev.bnldev(345.0,894,0 ) ;
  }

  @Test
  public void test20() {
    dev.bnldev(-36.033767595513936,0,0 ) ;
  }

  @Test
  public void test21() {
    dev.bnldev(-536.0,25,0 ) ;
  }

  @Test
  public void test22() {
    dev.bnldev(538.0,20,0 ) ;
  }

  @Test
  public void test23() {
    dev.bnldev(544.0,25,0 ) ;
  }

  @Test
  public void test24() {
    dev.bnldev(-571.0,-156,0 ) ;
  }

  @Test
  public void test25() {
    dev.bnldev(581.0,-777,0 ) ;
  }

  @Test
  public void test26() {
    dev.bnldev(-605.0,134,0 ) ;
  }

  @Test
  public void test27() {
    dev.bnldev(695.0,25,0 ) ;
  }

  @Test
  public void test28() {
    dev.bnldev(-697.0,6,-129 ) ;
  }

  @Test
  public void test29() {
    dev.bnldev(-710.0,-229,0 ) ;
  }

  @Test
  public void test30() {
    dev.bnldev(-765.0,-257,0 ) ;
  }

  @Test
  public void test31() {
    dev.bnldev(-768.0,18,0 ) ;
  }

  @Test
  public void test32() {
    dev.bnldev(-772.0,290,0 ) ;
  }

  @Test
  public void test33() {
    dev.bnldev(824.0,960,0 ) ;
  }

  @Test
  public void test34() {
    dev.bnldev(-827.0,-559,0 ) ;
  }

  @Test
  public void test35() {
    dev.bnldev(-85.0,592,0 ) ;
  }

  @Test
  public void test36() {
    dev.bnldev(94.0,-709,0 ) ;
  }

  @Test
  public void test37() {
    dev.bnldev(944.0,154,0 ) ;
  }
}
