import org.junit.Test;

public class TestpoidevTest {

  @Test
  public void test0() {
    dev.poidev(0.0,-1 ) ;
  }

  @Test
  public void test1() {
    dev.poidev(0.0,633 ) ;
  }

  @Test
  public void test2() {
    dev.poidev(-1.0,0 ) ;
  }

  @Test
  public void test3() {
    dev.poidev(-1.0000542588030878,0 ) ;
  }

  @Test
  public void test4() {
    dev.poidev(10.0,-1 ) ;
  }

  @Test
  public void test5() {
    dev.poidev(-1.0,-1 ) ;
  }

  @Test
  public void test6() {
    dev.poidev(-1.0,23 ) ;
  }

  @Test
  public void test7() {
    dev.poidev(10.285565549977832,0 ) ;
  }

  @Test
  public void test8() {
    dev.poidev(-1.0,296 ) ;
  }

  @Test
  public void test9() {
    dev.poidev(-1.0,-572 ) ;
  }

  @Test
  public void test10() {
    dev.poidev(-1.0,-843 ) ;
  }

  @Test
  public void test11() {
    dev.poidev(-116.0,-819 ) ;
  }

  @Test
  public void test12() {
    dev.poidev(13.234972650481865,0 ) ;
  }

  @Test
  public void test13() {
    dev.poidev(-171.0,0 ) ;
  }

  @Test
  public void test14() {
    dev.poidev(-2.0,0 ) ;
  }

  @Test
  public void test15() {
    dev.poidev(20.12064703177829,0 ) ;
  }

  @Test
  public void test16() {
    dev.poidev(2.0,-723 ) ;
  }

  @Test
  public void test17() {
    dev.poidev(-364.0,-1 ) ;
  }

  @Test
  public void test18() {
    dev.poidev(-37.0,-1 ) ;
  }

  @Test
  public void test19() {
    dev.poidev(-400.0,808 ) ;
  }

  @Test
  public void test20() {
    dev.poidev(44.47510614019447,0 ) ;
  }

  @Test
  public void test21() {
    dev.poidev(44.7140658928418,0 ) ;
  }

  @Test
  public void test22() {
    dev.poidev(-484.0,-166 ) ;
  }

  @Test
  public void test23() {
    dev.poidev(5.0,226 ) ;
  }

  @Test
  public void test24() {
    dev.poidev(-69.1916954206317,0 ) ;
  }

  @Test
  public void test25() {
    dev.poidev(7.0,-236 ) ;
  }

  @Test
  public void test26() {
    dev.poidev(-845.0,119 ) ;
  }

  @Test
  public void test27() {
    dev.poidev(9.0,0 ) ;
  }

  @Test
  public void test28() {
    dev.poidev(-94.22264892019298,0 ) ;
  }
}
