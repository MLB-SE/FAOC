import org.junit.Test;

public class JpfTargetSphereIntersectTest {

  @Test
  public void test0() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.19537161f,49.377716f,-57.59033f,74.07741f,8.856526f,72.65011f,12.151491f,-0.6670416f,0.23682939f,-0.059758216f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.47769135f,94.47991f,-77.1965f,47.740906f,-44.360023f,100.0f,-92.63354f,0.9098283f,-0.41358763f,0.034024853f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.04024619f,0.65654045f,0.6809243f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.271602f,-0.13304538f,0.54989094f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.3956256f,0.9155871f,0.07197652f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1.1299832E-14f,-1.4621745E-14f,3.7550136E-14f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1.1407281E-11f,-4.3696557E-12f,-1.106469E-12f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1.3500128E-4f,3.6790057E-5f,1.9973631E-4f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2.571783E-8f,3.9104457E-8f,4.2920316E-8f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-2.9927458E-9f,1.8906272E-7f,-1.070524E-6f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,3.974897E-9f,7.245911E-9f,-2.9611402E-9f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,40.874355f,66.291f,-20.845327f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-5.4445385E-4f,-1.12291855E-5f,-9.482918E-6f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,7.118246E-20f,6.9331823E-20f,-9.9320125E-20f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,87.55606f,-97.49649f,-24.813456f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-9.4856716E-7f,-9.846163E-10f,-8.498815E-6f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,100.0f,0.9250151f,-99.671394f,-99.13548f,99.98416f,-0.5407038f,-0.8396178f,0.051781975f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-100.0f,-100.0f,18.903187f,22.175426f,-100.0f,-28.13809f,-0.06996356f,0.6444336f,-0.44495365f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,100.0f,49.145367f,4.4408655f,100.0f,100.0f,53.586235f,-0.110264435f,-0.034325752f,-0.9933094f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,100.0f,-93.78908f,-93.136955f,100.0f,-100.0f,100.0f,-0.5913617f,-0.14943896f,-0.79243886f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-13.588491f,-49.08277f,99.72508f,34.39194f,-68.84207f,-99.95237f,0.2642413f,0.93609273f,0.23217861f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-33.640705f,-55.261265f,-25.027803f,59.64179f,-100.0f,-74.820244f,-1.4156817f,-2.3281968f,0.1940867f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-42.69724f,-99.999435f,40.302372f,-99.247185f,-82.940865f,-97.95862f,-0.2857312f,0.0797208f,-0.9549881f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,46.31887f,-100.0f,100.0f,-76.27919f,99.999985f,-19.03296f,0.71105003f,0.28983745f,-0.6406264f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-5.150961f,100.0f,82.15842f,98.40904f,3.8989294f,100.0f,-0.6831194f,-0.56842566f,0.4585195f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-59.95955f,-8.590264f,51.776337f,75.76777f,-14.361363f,-4.7964106f,-0.19675927f,-1.3215824f,-0.3134861f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-60.498783f,-100.0f,58.187782f,-100.0f,-19.386969f,-57.787075f,0.82663685f,-0.496987f,0.26396114f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-64.510574f,-100.0f,-18.390116f,100.0f,-29.017958f,-100.0f,0.024449708f,-1.0183645f,0.20029573f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-69.821396f,-100.0f,51.693077f,-71.34277f,-99.99186f,-66.4516f,-0.15689512f,0.91812974f,-0.3638979f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-71.5549f,-54.595455f,100.0f,63.348534f,-100.0f,33.990925f,0.6557424f,-0.27103654f,0.15820533f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,7.862427f,59.070377f,50.33561f,-76.77686f,-18.633492f,95.01931f,-0.7414447f,-0.49957812f,-0.44797483f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-89.51677f,-87.89382f,-99.86093f,-56.0173f,-100.0f,26.251825f,0.5887332f,0.15949203f,0.69358075f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,92.56071f,100.0f,-82.64733f,44.25816f,100.0f,-5.143774f,-0.05602512f,-0.55893576f,-0.8273143f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,99.9846f,-99.895775f,4.527576f,-95.472466f,100.0f,-99.906334f,-0.9804017f,-0.13812709f,0.14047557f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-12.1266985f,58.97139f,100.0f,19.808374f,6.9865527f,54.213318f,97.89855f,-0.82848f,0.55661124f,-0.061682925f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,12.29799f,100.0f,100.0f,100.0f,99.96564f,99.99689f,94.6608f,-0.34425807f,0.8539784f,-0.3901375f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,13.446427f,75.31577f,-73.226494f,90.74231f,-58.071545f,60.832504f,13.230636f,0.110326596f,-0.24843995f,-0.8883543f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,14.016185f,-86.00514f,-13.674755f,75.18378f,59.126f,-34.365993f,17.165201f,0.3201796f,-0.7648167f,-0.3998227f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1.4020002f,96.515945f,19.95284f,90.391556f,1.2082541f,56.632156f,-61.12184f,0.3760408f,0.59578115f,0.31966004f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-19.05767f,39.611473f,38.246426f,47.709686f,-60.9448f,58.12233f,51.626656f,0.31350383f,-0.5717624f,0.12212414f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,19.415293f,6.3758364f,30.007456f,53.27781f,-4.393991f,-4.5416374f,-16.387068f,-0.6555441f,-0.39266205f,0.5232131f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,19.703766f,86.033195f,53.031708f,23.531843f,-21.270134f,66.31275f,100.0f,0.46237376f,-2.7614605f,-2.70746f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,22.844072f,100.0f,-35.697388f,52.16227f,33.694427f,96.344734f,-4.2947683f,-0.18561536f,0.27931765f,-0.27941516f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-24.114128f,18.124159f,-31.518269f,39.084354f,-60.75928f,6.810999f,-40.316338f,-2.7453518f,10.573191f,3.8196552f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,24.538116f,-29.350645f,69.96178f,5.431116f,16.986992f,-8.671326f,74.60523f,5.6675363f,0.89809376f,-1.8265704f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,24.737608f,100.0f,100.0f,61.9015f,-35.878418f,28.295223f,1.2717088f,0.38141626f,-0.6216269f,-0.16011041f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,25.19035f,-100.0f,58.259563f,88.33198f,36.441338f,-16.399927f,32.04923f,-0.10224824f,-0.9941373f,-0.035161305f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,25.90236f,-3.92726f,-72.72021f,38.643555f,48.073917f,-19.975916f,-100.0f,-0.44661105f,-0.3379465f,-0.09313067f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-26.187294f,44.731354f,60.57957f,-100.0f,-8.529372f,-87.45655f,77.95515f,10.837489f,-9.758962f,-1.0897101f ) ;
  }

  @Test
  public void test49() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,26.652325f,-83.18863f,12.912924f,62.826843f,-22.12117f,-62.16844f,46.476444f,0.7909174f,0.022565378f,0.03266994f ) ;
  }

  @Test
  public void test50() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,26.919918f,-1.4173247f,26.89472f,26.002415f,51.112293f,-7.5636177f,34.180164f,-0.3837167f,-0.6746478f,0.46508884f ) ;
  }

  @Test
  public void test51() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,27.727568f,-19.550455f,1.7642589f,82.16935f,39.706657f,-94.15389f,34.05405f,-0.22822285f,0.05518674f,-0.19607152f ) ;
  }

  @Test
  public void test52() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-27.748825f,5.3204546f,-85.47916f,100.0f,-9.8265085f,81.33837f,-67.23294f,0.032407627f,-0.20488328f,-0.008291021f ) ;
  }

  @Test
  public void test53() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-27.966965f,-96.68226f,28.191776f,99.99339f,-100.0f,22.940096f,100.0f,0.029764026f,0.99815166f,0.05298476f ) ;
  }

  @Test
  public void test54() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-3.0719285f,-6.915961f,-9.885557f,83.47508f,-58.926716f,4.5469065f,-70.85223f,0.39608565f,-0.19913135f,-0.36616415f ) ;
  }

  @Test
  public void test55() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,31.280226f,100.0f,-7.1002293f,69.63522f,6.0802097f,-19.680378f,47.107967f,-2.971856f,-2.8154018f,2.0587149f ) ;
  }

  @Test
  public void test56() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-31.456463f,37.676632f,38.104126f,66.12458f,20.924324f,21.14052f,1.2901276f,0.0040710713f,0.23438603f,-0.057575505f ) ;
  }

  @Test
  public void test57() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,32.872204f,100.0f,-63.297047f,70.83819f,-29.114334f,78.62463f,-36.48638f,-0.081724375f,0.7001386f,-0.4816065f ) ;
  }

  @Test
  public void test58() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-3.4397452f,99.999985f,-99.99995f,57.46425f,-23.70175f,46.226475f,-100.0f,-0.13344857f,0.98776907f,-0.080645934f ) ;
  }

  @Test
  public void test59() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-34.84184f,-17.268679f,-49.96154f,41.017868f,-68.16299f,-11.705587f,-73.22565f,-0.22780102f,-0.65631175f,0.42844218f ) ;
  }

  @Test
  public void test60() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,36.711136f,34.71901f,-7.6335025f,43.19466f,-2.9184656f,24.305271f,-21.301989f,0.5682743f,0.37177026f,-1.9280411f ) ;
  }

  @Test
  public void test61() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-37.47753f,25.523506f,50.08894f,55.0738f,-42.90975f,77.4025f,67.75769f,0.13089712f,-0.76859385f,0.28233063f ) ;
  }

  @Test
  public void test62() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,38.72389f,-12.284307f,23.510008f,-54.011475f,16.801699f,-85.343765f,-97.63883f,0.22681373f,-0.55046946f,-0.80345434f ) ;
  }

  @Test
  public void test63() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,3.9205413f,-100.0f,17.411774f,84.20301f,-67.82812f,-56.58143f,24.968517f,-0.23489802f,-0.94390637f,-0.13261905f ) ;
  }

  @Test
  public void test64() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,39.485134f,-25.973898f,86.367775f,40.991493f,74.59527f,-17.346216f,67.050835f,-0.38987386f,-0.2974693f,0.44366252f ) ;
  }

  @Test
  public void test65() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-40.95929f,12.380772f,-13.068189f,54.654346f,-34.510612f,32.904625f,-63.51921f,4.471565f,4.8990746f,3.235219f ) ;
  }

  @Test
  public void test66() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,42.17714f,100.0f,-94.29317f,-100.0f,-62.90963f,99.99999f,-41.566956f,-0.57204163f,0.31704232f,0.7564738f ) ;
  }

  @Test
  public void test67() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-4.2425575f,-54.537254f,56.60121f,26.389431f,-4.872797f,-43.3951f,32.687675f,-0.16869871f,-0.72363627f,0.5879273f ) ;
  }

  @Test
  public void test68() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,42.604977f,99.99899f,97.36643f,100.0f,20.51418f,100.0f,-95.481125f,0.2349895f,-0.9709029f,-0.046124853f ) ;
  }

  @Test
  public void test69() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,42.769966f,2.2467709f,69.791176f,100.0f,100.0f,-5.889613f,100.0f,0.6130155f,-0.53927094f,-0.577407f ) ;
  }

  @Test
  public void test70() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-42.80893f,-38.657936f,99.43935f,73.21154f,12.474757f,9.335082f,100.0f,-0.5255579f,0.4352364f,-0.73099804f ) ;
  }

  @Test
  public void test71() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,43.79846f,-27.025682f,-99.90443f,52.406258f,64.09845f,-75.340546f,-99.88892f,-6.172015f,-2.5899863f,-0.061848134f ) ;
  }

  @Test
  public void test72() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-45.104797f,-52.827545f,72.42459f,84.0228f,-83.77576f,-31.86867f,-12.58128f,-0.25263503f,0.55667436f,0.79138434f ) ;
  }

  @Test
  public void test73() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,45.639748f,-84.162224f,29.4306f,76.35421f,30.561289f,-23.323103f,-14.172234f,0.35937673f,-0.8261577f,-0.12805158f ) ;
  }

  @Test
  public void test74() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,46.757545f,-35.82907f,0.6012818f,-14.6202f,27.57791f,-51.346146f,20.866112f,-0.4020651f,-0.9889603f,0.5340589f ) ;
  }

  @Test
  public void test75() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,48.02551f,-100.0f,-14.708983f,97.636314f,20.253973f,-31.712427f,-78.72772f,0.50883627f,0.042109553f,0.8598328f ) ;
  }

  @Test
  public void test76() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-48.355167f,93.90876f,45.173843f,37.166283f,-63.761375f,100.0f,11.904069f,-0.6794132f,-0.16015776f,0.7160637f ) ;
  }

  @Test
  public void test77() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-49.11049f,100.0f,100.0f,100.0f,-72.18367f,31.691698f,-100.0f,0.7980762f,0.5625954f,0.21577953f ) ;
  }

  @Test
  public void test78() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,49.286312f,87.379555f,42.490044f,86.64274f,-1.3878775f,17.107218f,43.43336f,0.48081908f,0.2822621f,0.39509904f ) ;
  }

  @Test
  public void test79() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-51.87643f,-98.568954f,-80.77165f,36.329517f,-82.66696f,-100.0f,-100.0f,0.99997705f,3.1836214E-4f,0.0067648306f ) ;
  }

  @Test
  public void test80() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-51.884853f,-75.8274f,-33.227093f,55.955612f,14.427712f,-50.74981f,-14.7610445f,-1.0107281f,0.44528922f,0.043175034f ) ;
  }

  @Test
  public void test81() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-54.946106f,100.0f,-100.0f,-99.85179f,21.59749f,69.22821f,41.583717f,-0.81623954f,-2.5187716f,2.4268844f ) ;
  }

  @Test
  public void test82() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,55.136913f,10.1388035f,-13.740321f,41.962288f,41.190395f,-20.107082f,11.784465f,-0.7834173f,0.76492053f,0.47749737f ) ;
  }

  @Test
  public void test83() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,55.735756f,99.999985f,-28.554941f,-70.09647f,86.39359f,32.92465f,-99.97185f,-4.5592585f,-4.6731052f,-11.026623f ) ;
  }

  @Test
  public void test84() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,56.763206f,-95.46038f,51.93253f,-27.32139f,-84.903625f,-45.22547f,-33.40704f,0.14438637f,-0.30377385f,-0.92636365f ) ;
  }

  @Test
  public void test85() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-5.7202034f,76.16179f,-10.664586f,23.84632f,-5.8962517f,100.0f,-11.26088f,-0.6461593f,-0.022136983f,-0.69416785f ) ;
  }

  @Test
  public void test86() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,57.36924f,171.54503f,50.290257f,59.102467f,-64.16587f,100.0f,-82.366806f,-3.9483182f,-1.5980407f,-2.156247f ) ;
  }

  @Test
  public void test87() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-5.8015027f,18.575098f,-88.45307f,24.043598f,8.311566f,-6.5191307f,-80.68896f,-0.38316867f,0.49863994f,0.49296296f ) ;
  }

  @Test
  public void test88() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-58.320824f,-50.316658f,-20.492325f,98.63999f,23.58554f,-81.63198f,100.0f,0.8985151f,-0.38146862f,0.21714574f ) ;
  }

  @Test
  public void test89() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,60.993797f,-50.44529f,80.02381f,58.2081f,24.207731f,-9.998772f,99.999985f,0.6299655f,-0.5405615f,-0.557617f ) ;
  }

  @Test
  public void test90() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-61.050526f,-84.76387f,29.911188f,-47.498043f,17.733522f,30.942152f,84.48842f,0.25045657f,0.8146115f,0.523144f ) ;
  }

  @Test
  public void test91() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,67.287125f,26.904997f,13.559387f,12.749583f,39.733578f,2.3347328f,24.554651f,-2.5309029f,-4.173745f,0.5814557f ) ;
  }

  @Test
  public void test92() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-69.99944f,41.923573f,-35.917988f,48.552757f,-45.383327f,41.3692f,5.928281f,0.057053387f,0.12149937f,-0.98456204f ) ;
  }

  @Test
  public void test93() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-71.50122f,100.0f,-62.38862f,-87.26374f,56.69325f,100.0f,-37.424282f,0.8294831f,0.011292143f,0.5584177f ) ;
  }

  @Test
  public void test94() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-72.92583f,64.51397f,-44.67082f,47.703236f,-66.80596f,100.0f,-87.674286f,3.2013838f,-2.3171482f,1.4258345f ) ;
  }

  @Test
  public void test95() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-73.16851f,-100.0f,47.128567f,97.95978f,-2.5834036f,-57.356445f,100.0f,-0.7628433f,-0.02264698f,-0.64618665f ) ;
  }

  @Test
  public void test96() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-74.68895f,203.08302f,100.0f,87.905815f,-145.12868f,127.1898f,63.337646f,-0.16731691f,0.68061227f,0.71342415f ) ;
  }

  @Test
  public void test97() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,75.11369f,46.727985f,21.313646f,24.935715f,0.7939919f,64.84109f,-91.88551f,0.4319911f,-1.1728834f,-0.19270796f ) ;
  }

  @Test
  public void test98() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-75.312225f,-33.128716f,100.0f,93.7952f,2.5041301f,-46.32941f,49.325596f,-0.5719801f,-0.7385941f,-0.35681573f ) ;
  }

  @Test
  public void test99() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-77.74592f,-3.4386067f,-100.0f,-34.531036f,63.486862f,38.163227f,-94.72313f,0.9924755f,0.060055885f,0.10670371f ) ;
  }

  @Test
  public void test100() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,82.10151f,18.892998f,-18.165861f,83.05449f,19.090878f,-21.200043f,-54.5012f,0.37352857f,0.006068283f,-0.52394336f ) ;
  }

  @Test
  public void test101() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-8.216772f,-80.234856f,34.824673f,25.031166f,-26.446436f,-71.178604f,20.256796f,-0.85202396f,2.9535081f,3.1046705f ) ;
  }

  @Test
  public void test102() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,88.04458f,-14.195319f,-100.0f,87.1215f,14.250524f,-15.618617f,-52.49757f,-0.0028840601f,-0.03523428f,0.002425683f ) ;
  }

  @Test
  public void test103() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,90.40218f,66.99326f,-76.31703f,94.53464f,27.823444f,38.264927f,-11.545267f,0.59531975f,-0.8016039f,0.055005036f ) ;
  }

  @Test
  public void test104() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-90.638596f,32.11196f,19.201756f,93.99536f,19.253735f,85.14132f,33.2333f,-5.487333f,2.3269892f,0.48697782f ) ;
  }

  @Test
  public void test105() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,95.915764f,17.827368f,4.140165f,99.20944f,99.9888f,-71.009026f,-39.837307f,-0.046409328f,0.9876111f,0.14990157f ) ;
  }

  @Test
  public void test106() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,96.12076f,-140.46411f,-155.26329f,-100.0f,100.0f,-100.0f,84.6085f,-0.38024884f,0.2652808f,0.8860231f ) ;
  }

  @Test
  public void test107() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,97.317116f,-36.44647f,-70.50863f,59.165188f,67.901924f,7.7920685f,-44.46601f,0.1410939f,-0.43686023f,0.015063214f ) ;
  }

  @Test
  public void test108() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.99542f,-100.0f,25.235586f,35.41434f,-99.97969f,-85.08865f,-6.8864784f,-0.05186618f,0.2852351f,0.9570532f ) ;
  }

  @Test
  public void test109() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.99986f,57.32288f,-9.659693f,99.9135f,-99.9999f,100.0f,-100.0f,-0.051406275f,-0.9856427f,0.16082889f ) ;
  }

  @Test
  public void test110() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.99999f,77.3194f,99.99989f,84.99957f,16.093481f,99.96688f,99.46485f,-0.7831942f,0.37095883f,-0.49899542f ) ;
  }
}
