import org.junit.Test;

public class JpfTargetVector3DNormalizeTest {

  @Test
  public void test0() {
    TestDrivers.vector3DNormalize(-0.11435754f,0.022314016f,0.06444631f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.vector3DNormalize(0.17209285f,0.16792743f,-0.031493288f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.vector3DNormalize(-0.63646287f,0.24121062f,-0.73262024f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.vector3DNormalize(-0.7061114f,0.6459386f,-0.2901208f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.vector3DNormalize(-0.94356245f,0.29201496f,0.15626007f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.vector3DNormalize(-1.09266735E-13f,4.751982E-10f,-4.88208E-10f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.vector3DNormalize(1.1288505E-11f,-2.4479157E-11f,7.9853745E-12f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.vector3DNormalize(-1.2079838E-9f,1.7593601E-9f,6.497282E-9f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.vector3DNormalize(1.5977373E-7f,3.5131432E-6f,1.9997267E-6f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.vector3DNormalize(-1.7374523E-24f,1.9931147E-24f,5.2931746E-24f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.vector3DNormalize(-20.14331f,67.88155f,46.329227f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.vector3DNormalize(-2.0505258E-4f,1.876486E-4f,-9.913219E-5f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.vector3DNormalize(26.110298f,-59.57843f,15.900886f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.vector3DNormalize(-5.0754666E-6f,-6.3475E-6f,3.51761E-6f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.vector3DNormalize(5.2432204E-4f,8.3837466E-4f,-0.0021566984f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.vector3DNormalize(6.8526545f,-77.842926f,57.59815f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.vector3DNormalize(7.911504E-11f,-6.660707E-10f,-2.9139752E-10f ) ;
  }
}
