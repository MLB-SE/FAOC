import org.junit.Test;

public class JpfTargetSurfaceShadeTest {

  @Test
  public void test0() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,55.3293f,-29.848112f,63.24425f,0f,0f,0f,1,0.02265041f,0.10768851f,-0.22737618f,0f,0f,0f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-6.23807f,-76.00427f,8.921656f,0f,0f,0f,1,-0.4209934f,-0.47562662f,-0.11425634f,0f,0f,0f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.0063152597f,0.116369694f,-0.26178804f,0f,0f,0f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.014445709f,0.0013503957f,-0.09601231f,0f,0f,0f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.040163394f,-0.7110332f,-0.30395463f,0f,0f,0f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.06413655f,0.17028569f,0.8713441f,0f,0f,0f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.06538786f,-0.54152435f,0.07909587f,0f,0f,0f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.077566475f,-0.052922573f,-0.016224997f,0f,0f,0f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.09134087f,-0.2732821f,0.22663313f,0f,0f,0f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.101420924f,-0.016423795f,-0.0074035395f,0f,0f,0f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.15297954f,-0.030714544f,-0.60537153f,0f,0f,0f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.16791199f,0.0873185f,-0.4672481f,0f,0f,0f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.16850898f,-0.5959299f,-0.48175198f,0f,0f,0f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.17543171f,-0.26171786f,0.9371537f,0f,0f,0f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.19638987f,0.52050817f,-0.5731432f,0f,0f,0f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.23526917f,0.44591898f,-0.042538553f,0f,0f,0f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.27250746f,0.72098327f,0.26969635f,0f,0f,0f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.33196276f,-0.6182866f,-0.21055274f,0f,0f,0f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.4224972f,-0.09718041f,0.67494607f,0f,0f,0f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.50993794f,0.07265283f,0.7684109f,0f,0f,0f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.5148615f,0.5545257f,0.45668614f,0f,0f,0f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.542471f,0.6851877f,-0.4473185f,0f,0f,0f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.5556335f,0.3241667f,-0.5225674f,0f,0f,0f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.7877645f,-0.3878278f,0.40073827f,0f,0f,0f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.8946269f,0.33383816f,-0.0660454f,0f,0f,0f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.957189f,0.101876624f,-0.2709434f,0f,0f,0f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-1.1760712E-4f,-9.771972E-4f,7.0338056E-4f,0f,0f,0f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-1.2332267E-14f,1.2282116E-11f,3.3080162E-12f,0f,0f,0f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,1.6608573E-9f,-5.0917794E-9f,1.28278534E-8f,0f,0f,0f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,4.177081E-7f,5.2088246E-5f,-4.8618356E-5f,0f,0f,0f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-6.7948404E-4f,3.8768203E-6f,3.4379514E-4f,0f,0f,0f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,6.873205E-9f,-2.7828924E-9f,-3.8790215E-9f,0f,0f,0f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-7.645516E-12f,-2.0341067E-11f,-9.578261E-8f,0f,0f,0f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-7.784234E-8f,-1.9257724E-5f,9.963269E-5f,0f,0f,0f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-95.65506f,-58.927334f,-7.154421f,0f,0f,0f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-9.991901f,53.91607f,-39.417694f,0f,0f,0f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0.061786357f,0.0032865047f,-0.011580444f,0f,0f,0f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,-0.4725601f,-0.25500628f,0.5682553f,0f,0f,0f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-350,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,462,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-18.007013f,-100.0f,-1.8695065f,0f,0f,0f,-1,-0.49581027f,0.41150796f,-0.62604696f,0f,0f,0f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,22.036636f,-33.9217f,-41.62941f,0f,0f,0f,1,4.7250524f,-15.823832f,15.395257f,0f,0f,0f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-33.248547f,100.0f,-87.74573f,0f,0f,0f,1,-5.196185f,-6.9141307f,-5.9108005f,0f,0f,0f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,39.43095f,-18.792768f,66.56942f,0f,0f,0f,1,-8.357488f,-7.6947355f,2.7781272f,0f,0f,0f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,40.98858f,65.10543f,16.39632f,0f,0f,0f,1,-7.887454f,4.273749f,2.7476444f,0f,0f,0f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,57.974667f,32.295845f,-51.568657f,0f,0f,0f,1,-34.374775f,-5.06756f,-41.818565f,0f,0f,0f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-86.35355f,100.0f,-96.87481f,0f,0f,0f,1,-0.32240456f,-0.928185f,-0.11446012f,0f,0f,0f ) ;
  }

  @Test
  public void test49() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-93.60526f,-27.345837f,86.23953f,0f,0f,0f,1,-0.5183566f,0.6823312f,0.45335525f,0f,0f,0f ) ;
  }

  @Test
  public void test50() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-100.0f,34.720146f,100.0f,1783.0f,736.0f,156.0f,3,-2.6370592f,2.440285f,-0.9878464f,0f,0f,0f ) ;
  }

  @Test
  public void test51() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-100.0f,5.6916485f,47.50969f,2.0f,1549.0f,-181.0f,1,-0.03567881f,-0.45921063f,0.9440399f,0f,0f,0f ) ;
  }

  @Test
  public void test52() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,100.0f,70.89716f,3.198194f,-254.0f,399.0f,-903.0f,1,0.27045792f,-0.23298296f,-0.008316598f,0f,0f,0f ) ;
  }

  @Test
  public void test53() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-13.800096f,0.9130374f,-63.014732f,63.0f,879.0f,-747.0f,1,0.0027174014f,0.7148415f,-0.67865485f,0f,0f,0f ) ;
  }

  @Test
  public void test54() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,39.50364f,-25.933935f,-2.7483866f,-238.0f,-612.0f,2354.0f,1,0.39101627f,0.10960715f,0.36448032f,0f,0f,0f ) ;
  }

  @Test
  public void test55() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,6.5984225f,-7.6191154f,1.6363245f,389.0f,-336.0f,-3132.0f,1,0.7615696f,0.5449235f,-0.31064284f,0f,0f,0f ) ;
  }

  @Test
  public void test56() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,79.96675f,47.661015f,78.26272f,211.0f,967.0f,458.0f,1,0.27007273f,0.61211485f,-0.09516928f,0f,0f,0f ) ;
  }

  @Test
  public void test57() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,84.684456f,-64.7553f,100.0f,1753.0f,-2914.0f,-260.0f,-8,-6.720301E-5f,-0.11185505f,-0.0048428266f,0f,0f,0f ) ;
  }

  @Test
  public void test58() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,94.57603f,46.707836f,100.0f,0f,0f,0f,1,-0.11754012f,-0.04397223f,0.5488672f,0f,0f,0f ) ;
  }

  @Test
  public void test59() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,110.731224f,0f,0f,0f,0f,0f,-89.22461f,-41.176033f,-100.0f,-427.0f,125.0f,-102.0f,1,-0.15620074f,-0.80705965f,0.0016892464f,0f,0f,0f ) ;
  }

  @Test
  public void test60() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,12.951518f,0f,0f,0f,0f,0f,55.300255f,9.6763115f,86.43936f,-557.0f,854.0f,261.0f,1,1.0721085f,-0.6633183f,-0.20830947f,0f,0f,0f ) ;
  }

  @Test
  public void test61() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,144.7816f,0f,0f,0f,0f,0f,23.295286f,-91.03056f,-119.05677f,280.0f,69.0f,2.0f,2,0.22868073f,-0.7365487f,0.03030336f,0f,0f,0f ) ;
  }

  @Test
  public void test62() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,147.36118f,0f,0f,0f,0f,0f,1.0180044f,46.275173f,-40.628475f,1384.0f,-134.0f,-118.0f,1,0.5340309f,-0.39841598f,-0.44919032f,0f,0f,0f ) ;
  }

  @Test
  public void test63() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,20.7729f,0f,0f,0f,0f,0f,0.06530897f,100.0f,51.583027f,1.0f,-391.0f,758.0f,1,0.05582929f,-0.16603649f,0.8851314f,0f,0f,0f ) ;
  }

  @Test
  public void test64() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,246.03387f,0f,0f,0f,0f,0f,6.5244417f,-79.69901f,-186.69084f,-377.0f,-1103.0f,443.0f,3,0.98448044f,5.1659718f,-6.457656f,0f,0f,0f ) ;
  }

  @Test
  public void test65() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,250.13318f,0f,0f,0f,0f,0f,39.293373f,-19.059807f,-92.462616f,151.0f,227.0f,-541.0f,-6,1.449779f,-5.281897f,0.5731467f,0f,0f,0f ) ;
  }

  @Test
  public void test66() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,250.16086f,0f,0f,0f,0f,0f,71.58393f,18.09503f,-161.79585f,-56.0f,-329.0f,-1675.0f,2,3.0625873f,1.408764f,-5.462155f,0f,0f,0f ) ;
  }

  @Test
  public void test67() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,251.11739f,0f,0f,0f,0f,0f,-67.98658f,130.27325f,53.96126f,-77.0f,1097.0f,-2256.0f,8,12.326433f,4.104482f,9.499841f,0f,0f,0f ) ;
  }

  @Test
  public void test68() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,252.34567f,0f,0f,0f,0f,0f,-95.270035f,-9.73144f,-138.04301f,1255.0f,-2409.0f,-1243.0f,-1,-0.46352175f,-5.623921f,-0.55718434f,0f,0f,0f ) ;
  }

  @Test
  public void test69() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.09221f,0f,0f,0f,0f,0f,-92.75214f,-91.95825f,-74.61562f,-721.0f,-429.0f,-901.0f,3,1.6880785f,1.1524501f,-5.7252173f,0f,0f,0f ) ;
  }

  @Test
  public void test70() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.98041f,0f,0f,0f,0f,0f,147.29388f,21.797274f,-80.89487f,983.0f,1610.0f,-1024.0f,2,0.9927705f,0.8431555f,0.0016377256f,0f,0f,0f ) ;
  }

  @Test
  public void test71() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.06255f,0f,0f,0f,0f,0f,-166.83406f,9.837585f,-176.24251f,-880.0f,-578.0f,-721.0f,1,-1.6150017f,0.027322797f,-4.4012513f,0f,0f,0f ) ;
  }

  @Test
  public void test72() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.06915f,0f,0f,0f,0f,0f,70.26683f,145.92062f,-108.03985f,2978.0f,-1236.0f,-597.0f,2,-0.42571214f,0.5404604f,0.2656504f,0f,0f,0f ) ;
  }

  @Test
  public void test73() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.1266f,0f,0f,0f,0f,0f,-78.17138f,111.29119f,-58.82959f,9.0f,1691.0f,-375.0f,1,-0.8402132f,0.26104796f,-0.26259315f,0f,0f,0f ) ;
  }

  @Test
  public void test74() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.56784f,0f,0f,0f,0f,0f,13.139023f,-92.3877f,27.228977f,515.0f,-349.0f,-589.0f,-1,5.194321f,0.45301685f,-0.72092855f,0f,0f,0f ) ;
  }

  @Test
  public void test75() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.58336f,0f,0f,0f,0f,0f,7.0041094f,67.20372f,-17.029106f,-526.0f,-19.0f,-1201.0f,1,-0.013804351f,0.4675777f,0.8773995f,0f,0f,0f ) ;
  }

  @Test
  public void test76() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.61673f,0f,0f,0f,0f,0f,36.4637f,-68.151436f,-8.800003f,-1645.0f,-1023.0f,640.0f,1,0.43574858f,-0.8129815f,0.18892314f,0f,0f,0f ) ;
  }

  @Test
  public void test77() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.62537f,0f,0f,0f,0f,0f,25.46815f,180.2388f,-127.719505f,1833.0f,100.0f,-1131.0f,1,4.499173f,0.8482457f,1.2702153f,0f,0f,0f ) ;
  }

  @Test
  public void test78() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.79745f,0f,0f,0f,0f,0f,44.92128f,-174.55002f,-87.79793f,-744.0f,-1612.0f,-163.0f,1,2.3835874f,-0.30451825f,-0.008288425f,0f,0f,0f ) ;
  }

  @Test
  public void test79() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.80685f,0f,0f,0f,0f,0f,7.6477833f,96.37273f,23.250793f,280.0f,285.0f,530.0f,1,0.05296776f,0.14273112f,-0.06620071f,0f,0f,0f ) ;
  }

  @Test
  public void test80() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.91232f,0f,0f,0f,0f,0f,-13.149988f,-75.889786f,-75.36319f,275.0f,-351.0f,-1849.0f,1,0.01753176f,-0.5510678f,-0.057653043f,0f,0f,0f ) ;
  }

  @Test
  public void test81() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.92844f,0f,0f,0f,0f,0f,-200.57912f,-73.31682f,34.313046f,-1175.0f,-268.0f,-723.0f,1,-1.9315586f,0.037402794f,0.10642049f,0f,0f,0f ) ;
  }

  @Test
  public void test82() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.93225f,0f,0f,0f,0f,0f,-170.09857f,108.61366f,22.090857f,416.0f,934.0f,-570.0f,1,-0.0018226559f,0.23740578f,-0.7246941f,0f,0f,0f ) ;
  }

  @Test
  public void test83() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.96126f,0f,0f,0f,0f,0f,-307.77057f,38.40959f,95.33487f,-1708.0f,-692.0f,-720.0f,1,-0.5377584f,0.08701324f,-0.63067f,0f,0f,0f ) ;
  }

  @Test
  public void test84() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.96677f,0f,0f,0f,0f,0f,33.43156f,-205.8672f,-130.71162f,-882.0f,-723.0f,44.0f,1,0.10976203f,-0.8064108f,-0.14948083f,0f,0f,0f ) ;
  }

  @Test
  public void test85() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.96767f,0f,0f,0f,0f,0f,-129.27263f,-45.06157f,92.50035f,-589.0f,-2342.0f,1023.0f,1,-0.08247504f,-0.61334425f,0.6623775f,0f,0f,0f ) ;
  }

  @Test
  public void test86() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.96812f,0f,0f,0f,0f,0f,121.87435f,-67.879105f,77.873184f,121.0f,597.0f,1323.0f,1,-0.26799327f,-0.7039013f,0.5287863f,0f,0f,0f ) ;
  }

  @Test
  public void test87() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.97395f,0f,0f,0f,0f,0f,-53.818584f,251.82997f,-31.720648f,933.0f,2050.0f,-1377.0f,1,-0.15532763f,0.010200987f,-0.04103021f,0f,0f,0f ) ;
  }

  @Test
  public void test88() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.97993f,0f,0f,0f,0f,0f,193.33543f,65.78355f,54.4131f,1384.0f,1650.0f,515.0f,1,-0.055189114f,-0.050438445f,0.9135574f,0f,0f,0f ) ;
  }

  @Test
  public void test89() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.98184f,0f,0f,0f,0f,0f,-61.29599f,-33.194416f,-163.10252f,-817.0f,-1180.0f,-2178.0f,1,0.58078235f,-0.5929084f,-0.5491999f,0f,0f,0f ) ;
  }

  @Test
  public void test90() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.98657f,0f,0f,0f,0f,0f,-82.37857f,-131.1885f,167.51375f,-739.0f,-653.0f,413.0f,1,0.16993064f,-0.5455812f,-0.10461821f,0f,0f,0f ) ;
  }

  @Test
  public void test91() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.9922f,0f,0f,0f,0f,0f,-322.72806f,-28.009352f,-91.49737f,-503.0f,-888.0f,1027.0f,1,-0.0032036034f,0.11012976f,-0.35013682f,0f,0f,0f ) ;
  }

  @Test
  public void test92() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.99544f,0f,0f,0f,0f,0f,88.5226f,7.6558704f,159.05586f,-365.0f,-1874.0f,2247.0f,1,0.7417862f,-0.037730336f,0.09079021f,0f,0f,0f ) ;
  }

  @Test
  public void test93() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.99707f,0f,0f,0f,0f,0f,-131.06184f,75.89815f,-109.486946f,-2201.0f,920.0f,484.0f,1,-0.43016014f,0.31515262f,-0.7202524f,0f,0f,0f ) ;
  }

  @Test
  public void test94() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.99916f,0f,0f,0f,0f,0f,-142.19125f,-35.99689f,1.1280748f,-1164.0f,-1500.0f,327.0f,1,-0.24924456f,0.40462112f,0.79833484f,0f,0f,0f ) ;
  }

  @Test
  public void test95() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.00052f,0f,0f,0f,0f,0f,296.64017f,-46.016277f,-138.43593f,1011.0f,89.0f,338.0f,1,0.19587967f,-0.027273407f,-0.012651158f,0f,0f,0f ) ;
  }

  @Test
  public void test96() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.00056f,0f,0f,0f,0f,0f,240.31187f,16.830183f,53.32415f,840.0f,-536.0f,-200.0f,1,0.70111394f,-0.25162944f,-0.37211585f,0f,0f,0f ) ;
  }

  @Test
  public void test97() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.00056f,0f,0f,0f,0f,0f,43.912712f,133.22482f,37.038403f,722.0f,4825.0f,-1296.0f,1,0.16931687f,0.9034512f,0.1962504f,0f,0f,0f ) ;
  }

  @Test
  public void test98() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.00076f,0f,0f,0f,0f,0f,106.60541f,28.80531f,-17.798302f,1063.0f,1843.0f,-188.0f,1,0.84745f,0.52404463f,-0.029823633f,0f,0f,0f ) ;
  }

  @Test
  public void test99() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.00162f,0f,0f,0f,0f,0f,-216.22183f,-36.909348f,-88.3661f,-451.0f,-487.0f,-457.0f,1,-0.5647735f,0.42549056f,0.3762403f,0f,0f,0f ) ;
  }

  @Test
  public void test100() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.0017f,0f,0f,0f,0f,0f,-72.8889f,24.048737f,269.75266f,-8.0f,-809.0f,144.0f,1,-0.3275903f,0.25530422f,0.8968922f,0f,0f,0f ) ;
  }

  @Test
  public void test101() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.0021f,0f,0f,0f,0f,0f,78.04267f,201.77353f,-193.15752f,-332.0f,1193.0f,-1062.0f,3,-2.2913802f,-2.1749704f,-7.8447247f,0f,0f,0f ) ;
  }

  @Test
  public void test102() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.01224f,0f,0f,0f,0f,0f,10.363777f,-42.80861f,33.92883f,1345.0f,-3147.0f,-1392.0f,1,0.52422845f,-0.053711668f,0.1819354f,0f,0f,0f ) ;
  }

  @Test
  public void test103() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.05786f,0f,0f,0f,0f,0f,145.4648f,-31.791924f,70.2713f,207.0f,-698.0f,849.0f,2,-0.027723514f,-1.1950948f,7.034283f,0f,0f,0f ) ;
  }

  @Test
  public void test104() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.18536f,0f,0f,0f,0f,0f,-17.746714f,-161.17204f,24.152195f,637.0f,-1527.0f,766.0f,1,0.23448718f,-0.7487526f,-0.20668304f,0f,0f,0f ) ;
  }

  @Test
  public void test105() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.80151f,0f,0f,0f,0f,0f,-123.78771f,38.767788f,-69.88756f,124.0f,-369.0f,-1427.0f,9,-14.329393f,-18.78792f,-1.989239f,0f,0f,0f ) ;
  }

  @Test
  public void test106() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,256.58926f,0f,0f,0f,0f,0f,-105.47201f,2.72227f,-232.47908f,171.0f,3127.0f,-158.0f,-6,3.7885911f,-0.047333308f,-5.8241887f,0f,0f,0f ) ;
  }

  @Test
  public void test107() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,256.6941f,0f,0f,0f,0f,0f,-141.009f,-66.01598f,-45.66622f,-1375.0f,-4.0f,-196.0f,2,-1.4198345f,1.9224467f,-1.2014506f,0f,0f,0f ) ;
  }

  @Test
  public void test108() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,257.45294f,0f,0f,0f,0f,0f,52.75071f,-71.960815f,-73.971375f,-566.0f,55.0f,-1410.0f,-1,5.7117167f,0.63359946f,-7.000087f,0f,0f,0f ) ;
  }

  @Test
  public void test109() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,259.20685f,0f,0f,0f,0f,0f,252.54863f,77.29673f,60.610546f,483.0f,-818.0f,-33.0f,1,1.919103f,-0.3993256f,-1.0229526f,0f,0f,0f ) ;
  }

  @Test
  public void test110() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,261.00085f,0f,0f,0f,0f,0f,47.02059f,-94.36675f,-214.87907f,-807.0f,-587.0f,-329.0f,1,-0.019910732f,-0.53300107f,-0.76174575f,0f,0f,0f ) ;
  }

  @Test
  public void test111() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,27.853249f,0f,0f,0f,0f,0f,55.156643f,90.26906f,-26.835472f,-297.0f,-73.0f,-856.0f,1,0.010057209f,-0.02667648f,-0.36469698f,0f,0f,0f ) ;
  }

  @Test
  public void test112() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,278.668f,0f,0f,0f,0f,0f,100.262314f,-79.277794f,44.847088f,1485.0f,-1799.0f,153.0f,1,-0.18395275f,-6.181576f,2.2376504f,0f,0f,0f ) ;
  }

  @Test
  public void test113() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,28.39159f,0f,0f,0f,0f,0f,19.649319f,-77.488884f,35.41374f,-1437.0f,-427.0f,-137.0f,1,0.2329892f,-0.9492572f,-0.1845103f,0f,0f,0f ) ;
  }

  @Test
  public void test114() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,28.718906f,0f,0f,0f,0f,0f,-94.72015f,3.5908544f,48.559868f,-483.0f,-705.0f,-890.0f,1,0.022486674f,0.8231351f,0.1491481f,0f,0f,0f ) ;
  }

  @Test
  public void test115() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,290.0282f,0f,0f,0f,0f,0f,-100.0f,230.29634f,119.5634f,-566.0f,935.0f,-599.0f,9,-0.9024403f,3.4015331f,1.1530205f,0f,0f,0f ) ;
  }

  @Test
  public void test116() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,292.92444f,0f,0f,0f,0f,0f,18.955177f,80.75108f,160.19235f,-543.0f,1679.0f,1396.0f,1,-0.5482594f,0.94511014f,-0.018198945f,0f,0f,0f ) ;
  }

  @Test
  public void test117() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,29.61982f,0f,0f,0f,0f,0f,-34.699856f,-62.855583f,-79.3295f,-165.0f,-1879.0f,-1689.0f,3,-2.3903356f,-0.22698793f,0.31337622f,0f,0f,0f ) ;
  }

  @Test
  public void test118() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,301.7486f,0f,0f,0f,0f,0f,78.2312f,-95.94417f,129.4141f,-277.0f,-841.0f,416.0f,1,0.20144306f,-0.9061747f,0.73444283f,0f,0f,0f ) ;
  }

  @Test
  public void test119() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,319.99295f,0f,0f,0f,0f,0f,47.527622f,90.3314f,8.761006f,3404.0f,-985.0f,841.0f,1,-0.02866342f,0.03318221f,-0.16524434f,0f,0f,0f ) ;
  }

  @Test
  public void test120() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-32.159443f,0f,0f,0f,0f,0f,-96.326485f,86.53039f,-100.0f,0f,0f,0f,1,0.11722767f,0.94559413f,0.2927971f,0f,0f,0f ) ;
  }

  @Test
  public void test121() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,32.98494f,0f,0f,0f,0f,0f,-57.009983f,52.605965f,-0.92357904f,-313.0f,-349.0f,-558.0f,1,-0.5304392f,0.12064163f,0.14238991f,0f,0f,0f ) ;
  }

  @Test
  public void test122() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,336.07495f,0f,0f,0f,0f,0f,142.87543f,-43.025475f,-102.93259f,1238.0f,2806.0f,-1701.0f,2,0.2468846f,-0.179011f,-4.8940845f,0f,0f,0f ) ;
  }

  @Test
  public void test123() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,33.95399f,0f,0f,0f,0f,0f,51.617126f,45.82374f,-58.822605f,-357.0f,1474.0f,835.0f,1,0.3519625f,-0.099401794f,0.15785462f,0f,0f,0f ) ;
  }

  @Test
  public void test124() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,354.78503f,0f,0f,0f,0f,0f,-245.61327f,44.403328f,173.13379f,-1082.0f,-69.0f,338.0f,1,0.1340262f,-0.84734637f,1.0896004f,0f,0f,0f ) ;
  }

  @Test
  public void test125() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,3.5527137E-15f,0f,0f,0f,0f,0f,-14.364253f,-48.73658f,-46.309315f,167.0f,-435.0f,406.0f,4,-10.339124f,-6.897057f,8.629769f,0f,0f,0f ) ;
  }

  @Test
  public void test126() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,375.04645f,0f,0f,0f,0f,0f,50.667866f,-122.11448f,121.248085f,-538.0f,-1138.0f,464.0f,1,-0.8260421f,-1.7258016f,2.8876688f,0f,0f,0f ) ;
  }

  @Test
  public void test127() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,395.3733f,0f,0f,0f,0f,0f,-172.858f,-53.85616f,5.679105f,-1289.0f,1669.0f,1424.0f,1,-0.39385054f,0.13796821f,-0.14823252f,0f,0f,0f ) ;
  }

  @Test
  public void test128() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,41.038654f,0f,0f,0f,0f,0f,5.408456f,141.82182f,-103.9081f,1563.0f,-781.0f,-985.0f,-3,-0.42714822f,2.9595463f,-3.3616147f,0f,0f,0f ) ;
  }

  @Test
  public void test129() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,41.515285f,0f,0f,0f,0f,0f,2.1808872f,-2.565955f,15.37465f,617.0f,221.0f,190.0f,9,0.99329317f,0.11995288f,2.135593f,0f,0f,0f ) ;
  }

  @Test
  public void test130() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,43.13722f,0f,0f,0f,0f,0f,27.177965f,83.450836f,69.57503f,-359.0f,292.0f,-210.0f,2,-0.4453962f,0.4679388f,0.3565444f,0f,0f,0f ) ;
  }

  @Test
  public void test131() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,46.978622f,0f,0f,0f,0f,0f,7.83299f,100.0f,-5.781287f,1149.0f,1362.0f,-1059.0f,1,0.37257722f,-0.03879073f,-0.25488037f,0f,0f,0f ) ;
  }

  @Test
  public void test132() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,48.269325f,0f,0f,0f,0f,0f,-100.0f,-98.37554f,-56.863274f,681.0f,-387.0f,-1619.0f,2,0.11305608f,0.057047803f,-0.3848008f,0f,0f,0f ) ;
  }

  @Test
  public void test133() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,5.288202f,0f,0f,0f,0f,0f,-86.412094f,-100.0f,46.31097f,-424.0f,-575.0f,933.0f,2,-5.8901005f,0.76056737f,0.020074677f,0f,0f,0f ) ;
  }

  @Test
  public void test134() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,59.79395f,0f,0f,0f,0f,0f,-98.670685f,12.94673f,-13.118221f,1309.0f,367.0f,1010.0f,1,-0.26388553f,0.22821717f,-0.12444707f,0f,0f,0f ) ;
  }

  @Test
  public void test135() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,63.99041f,0f,0f,0f,0f,0f,4.430938f,4.8299694f,6.016031f,901.0f,-423.0f,-324.0f,3,1.7784111f,-1.1130935f,-0.14043392f,0f,0f,0f ) ;
  }

  @Test
  public void test136() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,66.210106f,0f,0f,0f,0f,0f,3.6669207f,-28.776184f,-100.0f,-857.0f,-995.0f,252.0f,-3,-0.052844867f,-0.03791757f,-0.6151819f,0f,0f,0f ) ;
  }

  @Test
  public void test137() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,6.709407E-17f,0f,0f,0f,0f,0f,-62.23004f,-98.918945f,-100.0f,-677.0f,250.0f,174.0f,1,-0.74525505f,-0.47755116f,0.088010795f,0f,0f,0f ) ;
  }

  @Test
  public void test138() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,71.827156f,0f,0f,0f,0f,0f,15.751878f,28.332937f,4.1939373f,-1120.0f,628.0f,-36.0f,-5,-0.24622114f,5.484553f,5.064159f,0f,0f,0f ) ;
  }

  @Test
  public void test139() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,72.712975f,0f,0f,0f,0f,0f,-91.488014f,-6.539751f,63.46874f,438.0f,1235.0f,759.0f,4,-0.30154794f,0.4142151f,0.17443934f,0f,0f,0f ) ;
  }

  @Test
  public void test140() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,76.56442f,0f,0f,0f,0f,0f,-100.0f,-183.18285f,-32.04536f,546.0f,-324.0f,-1241.0f,1,-1.2029656f,-0.045522735f,0.057319403f,0f,0f,0f ) ;
  }

  @Test
  public void test141() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,77.32855f,0f,0f,0f,0f,0f,20.347208f,-3.455385f,11.0332575f,-606.0f,177.0f,1173.0f,1,0.035307128f,-0.97595f,-0.02071191f,0f,0f,0f ) ;
  }

  @Test
  public void test142() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,80.08335f,0f,0f,0f,0f,0f,33.306625f,-10.351696f,2.7165184f,617.0f,162.0f,-4.0f,1,0.57152915f,-0.7686033f,0.14437577f,0f,0f,0f ) ;
  }

  @Test
  public void test143() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,86.44048f,0f,0f,0f,0f,0f,-29.259953f,18.093468f,-36.409092f,-160.0f,355.0f,305.0f,1,-0.62675637f,-0.20757535f,0.17734103f,0f,0f,0f ) ;
  }

  @Test
  public void test144() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,87.11623f,0f,0f,0f,0f,0f,79.10986f,-71.744354f,-142.28575f,916.0f,-1337.0f,433.0f,1,0.07717227f,-0.47718772f,-0.66888005f,0f,0f,0f ) ;
  }

  @Test
  public void test145() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,88.131676f,0f,0f,0f,0f,0f,-92.32839f,34.50554f,-7.478449f,-885.0f,-2164.0f,846.0f,16,-9.205761f,2.6472569f,-2.634179f,0f,0f,0f ) ;
  }

  @Test
  public void test146() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,89.412544f,0f,0f,0f,0f,0f,12.076889f,48.9161f,69.54493f,-304.0f,1735.0f,-489.0f,1,-0.8542392f,2.6562274f,0.07936755f,0f,0f,0f ) ;
  }

  @Test
  public void test147() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,90.57112f,0f,0f,0f,0f,0f,-57.84653f,-89.21925f,-75.42527f,756.0f,12.0f,-594.0f,1,-0.45512867f,0.051622245f,-0.19386952f,0f,0f,0f ) ;
  }

  @Test
  public void test148() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,91.07252f,0f,0f,0f,0f,0f,-100.0f,-73.171906f,93.00621f,296.0f,1347.0f,1378.0f,1,-0.72569597f,0.44358447f,0.31705016f,0f,0f,0f ) ;
  }

  @Test
  public void test149() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,93.400215f,0f,0f,0f,0f,0f,-8.809763f,-31.784529f,30.083363f,1008.0f,-357.0f,-82.0f,1,-0.16538665f,0.19815424f,0.7169833f,0f,0f,0f ) ;
  }

  @Test
  public void test150() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,95.43914f,0f,0f,0f,0f,0f,-100.0f,100.0f,-100.0f,707.0f,1080.0f,-1797.0f,3,0.024297101f,-0.05552159f,-2.1245747f,0f,0f,0f ) ;
  }

  @Test
  public void test151() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,97.27689f,0f,0f,0f,0f,0f,177.39404f,5.0840154f,23.116394f,185.0f,1499.0f,254.0f,1,0.66721237f,-0.7052904f,-0.056204498f,0f,0f,0f ) ;
  }

  @Test
  public void test152() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,99.915016f,0f,0f,0f,0f,0f,32.360714f,-49.18983f,-1.2040001f,1315.0f,877.0f,-486.0f,-3,-0.16323413f,-1.2956982f,0.76705116f,0f,0f,0f ) ;
  }

  @Test
  public void test153() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,4.991251f,-55.488407f,0f,0f,0f,2,0.049435798f,0.02821959f,0.90912485f,0f,0f,0f ) ;
  }

  @Test
  public void test154() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-25.850971f,0f,-1.7347235E-18f,0f,0f,0f,0f,0f,-29.114788f,-100.0f,-100.0f,0f,0f,0f,-1,0.33869642f,0.77716005f,-0.4092845f,0f,0f,0f ) ;
  }

  @Test
  public void test155() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,38.96239f,0f,0f,0f,0f,0f,0f,0f,100.0f,-100.0f,-29.517633f,0f,0f,0f,1,0.36470628f,0.8100738f,-0.37553903f,0f,0f,0f ) ;
  }

  @Test
  public void test156() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-51.548607f,0f,28.816189f,0f,0f,0f,0f,0f,-59.645435f,48.192352f,-49.42857f,0f,0f,0f,1,0.8492198f,-0.35157424f,0.21267796f,0f,0f,0f ) ;
  }

  @Test
  public void test157() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-104.0f,-1567.0f,0f,2672.0f,0f,0f,0f,0f,0f,-327.0f,326.0f,588.0f,-771.0f,-1241.0f,260.0f,4,0.4190426f,-0.3039813f,-1.507903f,0f,0f,0f ) ;
  }

  @Test
  public void test158() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1131.0f,-1216.0f,0f,1834.0f,0f,0f,0f,0f,0f,218.0f,1936.0f,-732.0f,876.0f,2675.0f,-685.0f,1,0.5225571f,-0.48736954f,-0.21447827f,0f,0f,0f ) ;
  }

  @Test
  public void test159() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1175.0f,-542.0f,0f,1174.0f,0f,0f,0f,0f,0f,152.0f,130.0f,-1101.0f,-1429.0f,-893.0f,-303.0f,6,0.55983806f,-8.57044f,-0.87810946f,0f,0f,0f ) ;
  }

  @Test
  public void test160() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-12.494269f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-50.694572f,-100.0f,0f,0f,0f,1,0.7134618f,0.05928323f,-0.46380565f,0f,0f,0f ) ;
  }

  @Test
  public void test161() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1264.0f,-263.0f,0f,1757.0f,0f,0f,0f,0f,0f,675.0f,381.0f,-522.0f,-630.0f,335.0f,-928.0f,6,0.18471256f,0.40148142f,0.7006412f,0f,0f,0f ) ;
  }

  @Test
  public void test162() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-128.0f,-251.0f,0f,67.0f,0f,0f,0f,0f,0f,-911.0f,-273.0f,-39.0f,280.0f,-908.0f,-276.0f,2,1.0518724f,-0.062168095f,-1.1473871f,0f,0f,0f ) ;
  }

  @Test
  public void test163() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1323.0f,-686.0f,0f,1358.0f,0f,0f,0f,0f,0f,-609.0f,-141.0f,-42.0f,-142.0f,777.0f,-606.0f,9,0.11533696f,1.9925181f,-0.9000901f,0f,0f,0f ) ;
  }

  @Test
  public void test164() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,14.25765f,0f,0f,0f,0f,0f,0f,0f,0f,-1.9991837f,15.931688f,63.90471f,0f,0f,0f,3,-0.06754284f,-0.47416866f,-0.070559196f,0f,0f,0f ) ;
  }

  @Test
  public void test165() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1467.0f,-279.0f,0f,2315.0f,0f,0f,0f,0f,0f,689.0f,-871.0f,125.0f,650.0f,368.0f,-1015.0f,1,-0.8330429f,0.060270384f,0.34482655f,0f,0f,0f ) ;
  }

  @Test
  public void test166() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1509.0f,-1077.0f,0f,1143.0f,0f,0f,0f,0f,0f,-430.0f,-89.0f,-222.0f,202.0f,872.0f,-741.0f,1,0.045886446f,0.36254096f,0.8170449f,0f,0f,0f ) ;
  }

  @Test
  public void test167() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-15.340427f,-100.0f,0f,0f,0f,0f,0f,0f,0f,-2.0471032f,38.193283f,100.0f,0f,0f,0f,2,1.4700855f,-0.04017725f,-1.4333727f,0f,0f,0f ) ;
  }

  @Test
  public void test168() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1614.0f,-456.0f,0f,413.0f,0f,0f,0f,0f,0f,800.0f,-370.0f,-532.0f,324.0f,-1049.0f,-1668.0f,1,0.2672544f,0.8715608f,0.024964996f,0f,0f,0f ) ;
  }

  @Test
  public void test169() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1660.0f,-282.0f,0f,597.0f,0f,0f,0f,0f,0f,1587.0f,-1281.0f,-818.0f,481.0f,11.0f,913.0f,4,0.7107939f,6.4501452f,1.8742867f,0f,0f,0f ) ;
  }

  @Test
  public void test170() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1701.0f,-1649.0f,0f,818.0f,0f,0f,0f,0f,0f,857.0f,1062.0f,-889.0f,-660.0f,695.0f,194.0f,1,-0.15403356f,0.3363375f,0.29064095f,0f,0f,0f ) ;
  }

  @Test
  public void test171() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2155.0f,-1113.0f,0f,1919.0f,0f,0f,0f,0f,0f,189.0f,-214.0f,1011.0f,-4.0f,1528.0f,426.0f,-6,13.738732f,-10.220147f,-26.3195f,0f,0f,0f ) ;
  }

  @Test
  public void test172() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2192.0f,-155.0f,0f,2985.0f,0f,0f,0f,0f,0f,-762.0f,701.0f,102.0f,-171.0f,-177.0f,-61.0f,1,-0.14274958f,-0.22384089f,-0.43751454f,0f,0f,0f ) ;
  }

  @Test
  public void test173() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2237.0f,-570.0f,0f,1314.0f,0f,0f,0f,0f,0f,8.0f,12.0f,-71.0f,-436.0f,-1815.0f,-356.0f,1,-0.01853569f,-0.2533488f,0.9633851f,0f,0f,0f ) ;
  }

  @Test
  public void test174() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-232.0f,-341.0f,0f,1835.0f,0f,0f,0f,0f,0f,563.0f,903.0f,925.0f,-552.0f,-378.0f,705.0f,1,-0.6036212f,0.082701f,0.05707357f,0f,0f,0f ) ;
  }

  @Test
  public void test175() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2425.0f,-1585.0f,0f,1427.0f,0f,0f,0f,0f,0f,653.0f,-956.0f,901.0f,-373.0f,461.0f,769.0f,9,1.0314096f,-2.0861075f,-6.3028307f,0f,0f,0f ) ;
  }

  @Test
  public void test176() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2700.0f,-774.0f,0f,2498.0f,0f,0f,0f,0f,0f,-749.0f,-345.0f,-1576.0f,-178.0f,624.0f,-52.0f,1,0.29930827f,-0.211249f,-0.051799957f,0f,0f,0f ) ;
  }

  @Test
  public void test177() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-30.054695f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,96.87814f,-100.0f,0f,0f,0f,6,-0.115827695f,-0.24333791f,0.66815317f,0f,0f,0f ) ;
  }

  @Test
  public void test178() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-374.0f,-3137.0f,0f,1065.0f,0f,0f,0f,0f,0f,862.0f,-1174.0f,1215.0f,-2870.0f,-2930.0f,911.0f,-3,-2.0341291f,-0.3461018f,0.6373655f,0f,0f,0f ) ;
  }

  @Test
  public void test179() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-401.0f,-2157.0f,0f,1352.0f,0f,0f,0f,0f,0f,-245.0f,977.0f,120.0f,153.0f,-61.0f,806.0f,-22,-9.813434f,-3.9163802f,3.0953414f,0f,0f,0f ) ;
  }

  @Test
  public void test180() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-420.0f,-863.0f,0f,332.0f,0f,0f,0f,0f,0f,118.0f,-197.0f,-452.0f,-1238.0f,-1203.0f,196.0f,1,0.70564485f,-0.8196302f,1.5674735f,0f,0f,0f ) ;
  }

  @Test
  public void test181() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-433.0f,-841.0f,0f,2031.0f,0f,0f,0f,0f,0f,-602.0f,-349.0f,844.0f,811.0f,23.0f,588.0f,-1,0.05854911f,-0.21363395f,-0.05383378f,0f,0f,0f ) ;
  }

  @Test
  public void test182() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-461.0f,-151.0f,0f,266.0f,0f,0f,0f,0f,0f,-581.0f,-825.0f,733.0f,782.0f,-963.0f,-464.0f,1,-0.60288674f,-0.058500286f,-0.6141589f,0f,0f,0f ) ;
  }

  @Test
  public void test183() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-493.0f,-1804.0f,0f,1525.0f,0f,0f,0f,0f,0f,-1092.0f,-461.0f,-1174.0f,-692.0f,737.0f,1177.0f,5,-0.48146534f,2.0759425f,2.9287834f,0f,0f,0f ) ;
  }

  @Test
  public void test184() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-501.0f,-207.0f,0f,296.0f,0f,0f,0f,0f,0f,313.0f,96.0f,-804.0f,332.0f,2135.0f,384.0f,-4,1.4159125f,-1.4225955f,1.4879228f,0f,0f,0f ) ;
  }

  @Test
  public void test185() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-51.434345f,-61.757805f,0f,92.47318f,0f,0f,0f,0f,0f,-39.865673f,32.650932f,92.00028f,0f,0f,0f,1,0.041712005f,-2.329881f,0.46097144f,0f,0f,0f ) ;
  }

  @Test
  public void test186() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-522.0f,-947.0f,0f,822.0f,0f,0f,0f,0f,0f,-932.0f,666.0f,-192.0f,-270.0f,-479.0f,-351.0f,1,0.10621075f,-0.7533258f,0.6092196f,0f,0f,0f ) ;
  }

  @Test
  public void test187() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-556.0f,-1414.0f,0f,3638.0f,0f,0f,0f,0f,0f,863.0f,-375.0f,56.0f,-105.0f,67.0f,2067.0f,5,-0.9845059f,-0.4842248f,0.61084765f,0f,0f,0f ) ;
  }

  @Test
  public void test188() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-57.9501f,-22.728966f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,-51.908024f,-45.01226f,0f,0f,0f,1,-0.18196508f,-0.30042458f,0.8403812f,0f,0f,0f ) ;
  }

  @Test
  public void test189() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-6.3189006f,-79.515495f,0f,0f,0f,0f,0f,0f,0f,76.582664f,-19.03001f,-37.488003f,0f,0f,0f,1,-0.9197258f,-0.31471038f,-0.071861975f,0f,0f,0f ) ;
  }

  @Test
  public void test190() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-654.0f,-63.0f,0f,687.0f,0f,0f,0f,0f,0f,-167.0f,-5.0f,-453.0f,96.0f,2012.0f,-59.0f,3,0.679078f,0.061723366f,0.053136118f,0f,0f,0f ) ;
  }

  @Test
  public void test191() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-68.0f,-507.0f,0f,2454.0f,0f,0f,0f,0f,0f,3.0f,559.0f,6.0f,1826.0f,1135.0f,-813.0f,1,2.1145954f,-6.082913f,1.8530141f,0f,0f,0f ) ;
  }

  @Test
  public void test192() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,71.49861f,0f,0f,0f,0f,0f,0f,0f,0f,37.733143f,-100.0f,100.0f,0f,0f,0f,1,0.79410475f,0.57786417f,0.13117467f,0f,0f,0f ) ;
  }

  @Test
  public void test193() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-730.0f,-1803.0f,0f,1435.0f,0f,0f,0f,0f,0f,-920.0f,-953.0f,914.0f,520.0f,-1449.0f,-1754.0f,1,-0.02680013f,-0.019290546f,-0.6770201f,0f,0f,0f ) ;
  }

  @Test
  public void test194() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-826.0f,-870.0f,0f,943.0f,0f,0f,0f,0f,0f,-1402.0f,-1239.0f,1482.0f,-370.0f,666.0f,-1412.0f,-1,0.7311475f,0.06499637f,0.14046067f,0f,0f,0f ) ;
  }

  @Test
  public void test195() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-91.30593f,-76.33926f,0f,-99.87227f,0f,0f,0f,0f,0f,-100.0f,-42.53781f,-6.697546f,0f,0f,0f,1,0.4230305f,-0.08958493f,0.01771773f,0f,0f,0f ) ;
  }

  @Test
  public void test196() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-918.0f,-1007.0f,0f,1768.0f,0f,0f,0f,0f,0f,-549.0f,-40.0f,120.0f,128.0f,-1071.0f,229.0f,-1,6.555444f,-2.4036787f,-2.5728357f,0f,0f,0f ) ;
  }

  @Test
  public void test197() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-933.0f,-811.0f,0f,2501.0f,0f,0f,0f,0f,0f,-494.0f,-372.0f,-423.0f,191.0f,408.0f,-582.0f,1,0.29518628f,-0.6706118f,0.39061737f,0f,0f,0f ) ;
  }

  @Test
  public void test198() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-93.94454f,0.0f,0f,0f,0f,0f,0f,0f,0f,99.492516f,-52.986305f,46.701614f,0f,0f,0f,1,0.20772599f,-0.1098498f,-0.67666847f,0f,0f,0f ) ;
  }

  @Test
  public void test199() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-983.0f,-409.0f,0f,1828.0f,0f,0f,0f,0f,0f,-444.0f,-951.0f,371.0f,296.0f,204.0f,877.0f,1,0.4397157f,-0.005479763f,-0.20596093f,0f,0f,0f ) ;
  }
}
