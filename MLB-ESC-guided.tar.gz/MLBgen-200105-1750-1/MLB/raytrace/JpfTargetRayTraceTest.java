import org.junit.Test;

public class JpfTargetRayTraceTest {

  @Test
  public void test0() {
    TestDrivers.rayTrace(-0.86102444f,65.9885f,88.22456f,-41.589985f,-41.878853f,86.4617f,78.22189f,8.051168f,-84.592064f,-2.7988055f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-0.19632152f,-0.25152445f,-0.74538434f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,0.25476387f,0.6543756f,-0.7119606f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,0.325216f,0.11298109f,-0.8818452f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-0.32695526f,-74.159584f,-71.78001f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-1.0129352E-12f,1.8326412E-12f,-3.2123983E-13f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-1.09542325E-5f,-5.97637E-7f,1.28818065E-5f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,1.1287227E-6f,-2.761655E-6f,-7.728778E-6f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-1.4923345E-14f,-1.733745E-14f,-2.5483094E-15f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,1.7235001E-9f,-5.3148703E-9f,-7.464592E-9f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,2.5108486E-4f,3.2845703E-5f,-7.956283E-4f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,3.221394E-4f,-7.294158E-5f,-1.021381E-4f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-39.17718f,-90.91303f,34.95784f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-6.0271255E-10f,2.990482E-10f,1.26906E-9f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-70.43795f,45.589405f,99.09302f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-7.9877314E-25f,-1.283164E-25f,-5.6778254E-25f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.rayTrace(100.0f,100.0f,100.0f,-100.0f,100.0f,100.0f,7.307015f,-0.6938273f,0.5837563f,-0.42170164f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.rayTrace(-100.0f,-100.0f,100.0f,100.0f,-12.6897335f,-14.155314f,75.26237f,-0.3418868f,-0.9344087f,-0.09996901f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.rayTrace(100.0f,100.0f,-100.0f,49.889923f,100.0f,100.0f,-76.23966f,-0.854726f,-0.51210153f,0.08482602f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.rayTrace(100.0f,100.0f,-31.77265f,-100.0f,61.08307f,100.0f,60.322647f,0.71466297f,0.6105883f,0.34123126f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.rayTrace(100.0f,100.0f,31.932083f,85.74344f,100.0f,10.701244f,10.897339f,-0.77860737f,-0.4672915f,0.41881886f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.rayTrace(100.0f,-100.0f,-91.778305f,-100.0f,45.7464f,100.0f,-100.0f,-0.054537114f,0.9984794f,-0.008032408f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.rayTrace(100.0f,-11.1187525f,45.277905f,-100.0f,99.15862f,-100.0f,91.97049f,-0.67650473f,-0.254007f,-0.69124657f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.rayTrace(100.0f,-28.904514f,70.66448f,-19.039589f,32.862225f,-52.68203f,-47.745773f,-0.12679854f,0.44280642f,-0.22135682f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.rayTrace(100.0f,-3.006328f,-61.686302f,-49.906963f,37.82212f,100.0f,100.0f,-0.46915868f,-0.13177884f,0.25337908f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.rayTrace(-100.0f,3.5241377f,-100.0f,-49.211464f,-100.0f,55.795155f,-100.0f,-0.9367836f,-0.3490298f,0.02479229f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.rayTrace(-100.0f,-45.161728f,-30.008865f,-100.0f,100.0f,5.096744f,-46.92282f,0.9823847f,0.14734699f,-0.11493155f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.rayTrace(100.0f,-62.216194f,-53.81139f,72.86216f,-100.0f,-63.700367f,-100.0f,0.013984491f,-0.99646217f,0.0828706f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.rayTrace(-100.0f,63.47434f,66.31888f,18.45061f,87.060875f,-100.0f,-78.42382f,-0.9696505f,0.07221883f,0.2335857f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.rayTrace(100.0f,73.200455f,-41.66668f,-83.341f,100.0f,27.59359f,6.431615f,-0.21564609f,-0.24833854f,-0.08152163f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.rayTrace(-100.0f,-73.284996f,100.0f,-64.80168f,100.0f,39.409042f,-23.375263f,-0.72723633f,-0.56472033f,0.3901516f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.rayTrace(100.0f,73.91404f,100.0f,-100.0f,-80.227005f,100.0f,100.0f,-0.92936486f,-0.11911469f,-0.34941763f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.rayTrace(-100.0f,-74.4021f,60.679676f,-52.529213f,-69.69248f,-82.37618f,3.4128907f,0.25936273f,0.72306347f,-0.6402423f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.rayTrace(100.0f,-84.09145f,73.506294f,-28.552153f,99.999985f,-81.81112f,37.78285f,0.6840585f,-0.8362879f,-0.90527755f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.rayTrace(-100.0f,85.91758f,-45.193104f,100.0f,-100.0f,100.0f,-100.0f,0.06775881f,-0.05794188f,-0.9960178f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.rayTrace(-100.0f,92.9028f,8.31544f,-100.0f,100.0f,33.619713f,-100.0f,0.9330994f,0.061048616f,-0.35439894f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.rayTrace(100.0f,-96.44302f,100.0f,100.0f,26.381855f,100.0f,99.16458f,0.21653819f,-0.9755497f,0.03760311f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.rayTrace(100.0f,-96.78759f,100.0f,99.967766f,6.1256657f,23.574234f,34.049686f,0.5230261f,-0.55627763f,-0.6457545f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.rayTrace(100.0f,-99.90696f,-43.865475f,18.695107f,81.07126f,-100.0f,-60.73553f,-0.838565f,-0.5343198f,-0.10635346f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.rayTrace(100.0f,-99.99977f,-100.0f,-100.0f,100.0f,-47.710896f,-54.169716f,-0.4580384f,-0.0974811f,-0.8835713f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.rayTrace(-10.767428f,11.641193f,65.19441f,58.801453f,-64.33135f,-61.507954f,-45.882504f,-22.330383f,-61.94015f,-53.490704f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.rayTrace(118.21229f,-26.60477f,-2.9760275f,193.35088f,-65.642784f,-71.69397f,36.324276f,0.8030918f,-0.5126078f,-0.3103919f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.rayTrace(12.337248f,28.190878f,100.0f,-37.37947f,5.289505f,32.601955f,63.556778f,-164.05061f,24.646544f,36.845966f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.rayTrace(13.280913f,-99.27672f,-100.0f,-100.0f,40.532635f,39.35116f,-43.357883f,-0.380973f,-0.9234993f,-0.04481733f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.rayTrace(14.623614f,99.94587f,99.78299f,99.90807f,99.8924f,83.85804f,14.838115f,-0.21765438f,-0.660017f,0.71902996f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.rayTrace(-14.82414f,-100.0f,-100.0f,100.0f,-100.0f,-58.681946f,-100.0f,-0.043302074f,-0.5644639f,0.8243212f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.rayTrace(-14.942288f,31.915167f,-22.680656f,-55.676315f,-65.03588f,-11.084106f,-88.27474f,-0.2875947f,0.10991112f,-0.41491565f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.rayTrace(-15.403644f,50.55877f,56.306606f,-59.943707f,-65.503525f,26.161911f,6.538723f,-76.53291f,49.68807f,-34.835587f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.rayTrace(15.727069f,-13.347048f,-88.190186f,72.91745f,-2.757159f,-39.152515f,-59.146767f,-49.940254f,20.215538f,77.97438f ) ;
  }

  @Test
  public void test49() {
    TestDrivers.rayTrace(-16.549181f,-64.096634f,50.72945f,48.74555f,-3.82833f,-31.830631f,36.165203f,0.84101427f,0.45064703f,0.19121262f ) ;
  }

  @Test
  public void test50() {
    TestDrivers.rayTrace(-17.189169f,99.09965f,78.14338f,-99.98838f,-88.09477f,25.698261f,98.62784f,-0.050672762f,0.6538494f,0.75492597f ) ;
  }

  @Test
  public void test51() {
    TestDrivers.rayTrace(17.532642f,-4.1959033f,-62.13707f,88.175156f,12.228597f,-97.82222f,-27.189632f,80.66357f,66.75006f,39.503094f ) ;
  }

  @Test
  public void test52() {
    TestDrivers.rayTrace(17.770401f,-88.125435f,99.99998f,-99.999985f,3.998939f,-9.841309f,25.47758f,-0.8085909f,-0.57465774f,0.12629023f ) ;
  }

  @Test
  public void test53() {
    TestDrivers.rayTrace(-197.9512f,-100.0f,-49.68542f,-100.0f,-100.0f,-65.08614f,-100.0f,-0.9601433f,0.25532165f,0.11565552f ) ;
  }

  @Test
  public void test54() {
    TestDrivers.rayTrace(-20.359953f,-100.0f,-100.0f,-58.279137f,63.092667f,-55.448f,100.0f,0.981267f,0.18616281f,-0.04958309f ) ;
  }

  @Test
  public void test55() {
    TestDrivers.rayTrace(-20.600027f,-84.70873f,-73.40191f,-86.495476f,60.210186f,-78.32767f,-81.40773f,-89.17204f,25.720919f,68.47654f ) ;
  }

  @Test
  public void test56() {
    TestDrivers.rayTrace(21.177202f,-40.6228f,61.75995f,32.014973f,17.93043f,-67.575485f,35.769848f,-39.954594f,5.111981f,46.002537f ) ;
  }

  @Test
  public void test57() {
    TestDrivers.rayTrace(-21.567385f,90.39596f,97.84884f,95.10113f,-100.0f,35.342617f,100.0f,-0.009028907f,-0.15456338f,0.03259535f ) ;
  }

  @Test
  public void test58() {
    TestDrivers.rayTrace(-21.876883f,56.16476f,60.143097f,-42.905838f,-32.31491f,66.96345f,-25.16036f,-31.407333f,16.644402f,-63.573364f ) ;
  }

  @Test
  public void test59() {
    TestDrivers.rayTrace(-22.26453f,99.98686f,-14.080716f,-100.0f,0.41870075f,-100.0f,54.300438f,-0.1434742f,-0.9889175f,-0.03817458f ) ;
  }

  @Test
  public void test60() {
    TestDrivers.rayTrace(-22.747162f,36.747242f,-13.676081f,-24.91693f,-88.6729f,-73.08151f,-69.94205f,-42.294746f,-28.26788f,-40.718056f ) ;
  }

  @Test
  public void test61() {
    TestDrivers.rayTrace(24.225845f,-63.67482f,-3.9628706f,49.510708f,-43.192986f,-34.713512f,77.27477f,7.1847434f,-1.7573375f,-3.00661f ) ;
  }

  @Test
  public void test62() {
    TestDrivers.rayTrace(2.5444336f,15.938205f,-99.10113f,-33.389057f,5.207721f,100.0f,-1.3845417f,0.24801789f,0.02321186f,-0.7026395f ) ;
  }

  @Test
  public void test63() {
    TestDrivers.rayTrace(26.445484f,-32.07921f,83.03616f,100.0f,41.78653f,-91.44577f,4.040827f,-0.02140233f,0.74858487f,0.6626935f ) ;
  }

  @Test
  public void test64() {
    TestDrivers.rayTrace(-26.685066f,-38.478607f,-38.40134f,-64.76478f,2.278767f,5.1728544f,-0.3208675f,0.020294523f,-0.007645314f,-0.9997648f ) ;
  }

  @Test
  public void test65() {
    TestDrivers.rayTrace(-2.6934385f,92.181076f,-71.60504f,60.303493f,-30.892052f,44.005898f,-48.790527f,0.44614115f,0.1123024f,-0.21173632f ) ;
  }

  @Test
  public void test66() {
    TestDrivers.rayTrace(28.267078f,59.333496f,-42.237274f,60.785954f,-89.18994f,-27.84638f,10.04453f,79.315796f,89.467026f,-82.93415f ) ;
  }

  @Test
  public void test67() {
    TestDrivers.rayTrace(-28.885546f,-29.961342f,-84.45062f,74.339005f,51.12491f,81.70229f,86.77322f,-19.548779f,14.453202f,-45.6439f ) ;
  }

  @Test
  public void test68() {
    TestDrivers.rayTrace(-30.42735f,17.725498f,49.220634f,-79.63432f,-29.58f,-57.231644f,28.08533f,-0.44567832f,-0.6532935f,0.6120281f ) ;
  }

  @Test
  public void test69() {
    TestDrivers.rayTrace(31.560577f,70.518394f,99.45766f,69.40631f,97.86914f,100.0f,98.09008f,0.457856f,-0.34770194f,-0.8182122f ) ;
  }

  @Test
  public void test70() {
    TestDrivers.rayTrace(-32.87328f,69.06629f,-13.87234f,-98.962296f,-64.8287f,-100.0f,30.421469f,0.005499476f,0.95222765f,0.30533957f ) ;
  }

  @Test
  public void test71() {
    TestDrivers.rayTrace(33.160694f,-19.858875f,74.35251f,100.0f,-87.48859f,-26.31496f,81.228355f,0.62561f,-0.6805093f,0.38146973f ) ;
  }

  @Test
  public void test72() {
    TestDrivers.rayTrace(33.214897f,-100.0f,1.1938287f,-100.0f,-100.0f,-44.89891f,100.0f,-0.33782038f,0.87806284f,-0.338944f ) ;
  }

  @Test
  public void test73() {
    TestDrivers.rayTrace(33.525055f,-40.053852f,-77.56475f,78.51997f,-60.65222f,98.47056f,55.34399f,48.6745f,10.885235f,55.301964f ) ;
  }

  @Test
  public void test74() {
    TestDrivers.rayTrace(35.191135f,-30.317753f,59.619175f,100.0f,25.144547f,-95.37098f,-40.635822f,-0.5506231f,0.6466887f,-0.41305238f ) ;
  }

  @Test
  public void test75() {
    TestDrivers.rayTrace(35.2922f,43.23951f,-60.18437f,-8.664235f,82.58373f,-17.20148f,-0.3796181f,93.75854f,-6.1437397f,-17.948723f ) ;
  }

  @Test
  public void test76() {
    TestDrivers.rayTrace(-36.00049f,10.595749f,-57.757607f,96.21591f,-7.429736f,17.305828f,27.934519f,0.633465f,-0.3239051f,0.3589415f ) ;
  }

  @Test
  public void test77() {
    TestDrivers.rayTrace(36.420914f,-61.324703f,64.6277f,84.67103f,-0.5884489f,62.91797f,32.300922f,-37.01324f,68.25384f,-99.95326f ) ;
  }

  @Test
  public void test78() {
    TestDrivers.rayTrace(36.7747f,42.935738f,60.607323f,100.0f,-46.72289f,49.090595f,100.0f,-0.99298704f,0.117580704f,0.012307409f ) ;
  }

  @Test
  public void test79() {
    TestDrivers.rayTrace(38.907154f,54.809227f,-34.859642f,54.786163f,19.807102f,71.95324f,-53.932137f,-27.619759f,-99.39781f,69.11573f ) ;
  }

  @Test
  public void test80() {
    TestDrivers.rayTrace(39.91327f,35.35763f,-12.484899f,91.745125f,-43.63372f,51.210293f,-42.870804f,-0.4067603f,-0.6760715f,-0.19581527f ) ;
  }

  @Test
  public void test81() {
    TestDrivers.rayTrace(-4.0372696f,6.4602623f,65.79613f,36.276905f,65.63402f,38.570393f,31.923677f,61.137592f,79.5959f,-61.285835f ) ;
  }

  @Test
  public void test82() {
    TestDrivers.rayTrace(42.048187f,90.8684f,-100.0f,-91.14315f,100.0f,128.03328f,-70.29446f,0.21777326f,0.69753575f,0.2315918f ) ;
  }

  @Test
  public void test83() {
    TestDrivers.rayTrace(-42.34661f,-26.545706f,-52.5767f,81.27398f,-79.78033f,8.745767f,-10.550781f,70.71589f,-10.923575f,66.491394f ) ;
  }

  @Test
  public void test84() {
    TestDrivers.rayTrace(42.423023f,45.640785f,-63.543854f,-84.06708f,-11.03072f,39.20254f,1.0202187f,-0.16251603f,-0.013160441f,-0.98661816f ) ;
  }

  @Test
  public void test85() {
    TestDrivers.rayTrace(-42.62039f,92.08544f,-61.832287f,-77.51758f,-43.904263f,20.951376f,-15.376906f,23.9302f,98.04721f,52.286293f ) ;
  }

  @Test
  public void test86() {
    TestDrivers.rayTrace(4.3562083f,-15.481459f,68.016975f,-42.184696f,71.300514f,-71.93043f,-45.03351f,-80.7334f,68.365814f,74.30083f ) ;
  }

  @Test
  public void test87() {
    TestDrivers.rayTrace(-45.59246f,-35.008987f,53.605103f,16.939676f,7.4172997f,16.590038f,-45.29071f,0.4166018f,0.41482925f,-0.078295484f ) ;
  }

  @Test
  public void test88() {
    TestDrivers.rayTrace(-47.772366f,-100.0f,62.814987f,-100.0f,-87.75383f,-100.0f,-28.844612f,0.09510444f,-0.006163095f,0.99544823f ) ;
  }

  @Test
  public void test89() {
    TestDrivers.rayTrace(-48.362442f,18.086002f,41.266987f,-48.662296f,46.769344f,6.8929462f,42.55649f,-0.5252877f,0.72970957f,-0.36555296f ) ;
  }

  @Test
  public void test90() {
    TestDrivers.rayTrace(-48.847958f,-43.8481f,-39.462467f,-50.856613f,-22.349394f,-40.7336f,40.179012f,53.101097f,80.89914f,90.20406f ) ;
  }

  @Test
  public void test91() {
    TestDrivers.rayTrace(-49.285835f,21.617943f,-82.059265f,38.53627f,31.455809f,-12.966558f,62.48517f,96.69644f,-15.683834f,71.572845f ) ;
  }

  @Test
  public void test92() {
    TestDrivers.rayTrace(-49.585636f,-7.239406f,21.618174f,92.94636f,2.996786f,24.015656f,51.12664f,-90.68102f,-38.104362f,-2.8567693f ) ;
  }

  @Test
  public void test93() {
    TestDrivers.rayTrace(-49.854774f,84.22953f,100.0f,89.03251f,-100.0f,83.3828f,-23.970217f,-0.864395f,0.1941021f,-0.46383792f ) ;
  }

  @Test
  public void test94() {
    TestDrivers.rayTrace(-51.527912f,-47.483356f,-87.32497f,35.23209f,-54.009087f,-16.688313f,-70.38953f,56.49865f,45.930737f,-75.24834f ) ;
  }

  @Test
  public void test95() {
    TestDrivers.rayTrace(51.63567f,-10.331603f,100.0f,100.0f,100.0f,92.18748f,17.345854f,-0.6684052f,-0.48254147f,0.2626212f ) ;
  }

  @Test
  public void test96() {
    TestDrivers.rayTrace(-5.2167892f,-100.0f,-20.614035f,-68.18357f,100.0f,-29.097773f,-97.610825f,-0.35474098f,-0.7750194f,0.52297586f ) ;
  }

  @Test
  public void test97() {
    TestDrivers.rayTrace(5.5013824f,100.0f,79.94501f,-53.36895f,100.0f,79.64513f,100.0f,-0.6568923f,-0.01777047f,-0.753775f ) ;
  }

  @Test
  public void test98() {
    TestDrivers.rayTrace(-55.070324f,74.897736f,78.501755f,30.590635f,-100.0f,-20.110165f,-13.827808f,0.72524077f,0.15043205f,0.42703697f ) ;
  }

  @Test
  public void test99() {
    TestDrivers.rayTrace(-55.245613f,95.99963f,-12.604853f,-16.520882f,-43.810966f,-20.676022f,-100.0f,-0.2994342f,-0.89651674f,0.19956526f ) ;
  }

  @Test
  public void test100() {
    TestDrivers.rayTrace(55.36659f,-25.249464f,100.0f,82.34126f,32.14069f,-67.92462f,-78.139015f,0.8129924f,0.1051491f,-0.008621308f ) ;
  }

  @Test
  public void test101() {
    TestDrivers.rayTrace(-5.5929036f,70.979706f,-5.1693006f,55.090805f,-36.50135f,68.836105f,-77.900215f,-36.807228f,82.785805f,-82.12372f ) ;
  }

  @Test
  public void test102() {
    TestDrivers.rayTrace(56.664898f,75.632866f,-25.358583f,77.252335f,23.095161f,100.0f,27.657362f,0.5715624f,0.3826899f,-0.1965138f ) ;
  }

  @Test
  public void test103() {
    TestDrivers.rayTrace(57.075924f,3.0600078f,-26.913092f,-50.86036f,-10.897076f,84.255936f,-23.302828f,-57.371994f,96.56393f,62.943047f ) ;
  }

  @Test
  public void test104() {
    TestDrivers.rayTrace(-58.042126f,-12.859751f,-65.72556f,-18.44236f,-1.3631408f,-20.143078f,4.6134853f,-0.033105526f,-0.2496496f,-0.12747279f ) ;
  }

  @Test
  public void test105() {
    TestDrivers.rayTrace(5.82737f,74.298645f,77.1478f,-73.88953f,-9.643307f,-93.6213f,-83.55103f,0.37360966f,0.6266283f,0.68392456f ) ;
  }

  @Test
  public void test106() {
    TestDrivers.rayTrace(60.656727f,69.8668f,60.824436f,59.287964f,19.476538f,80.428215f,60.730118f,-0.75043976f,-0.30789414f,0.27932394f ) ;
  }

  @Test
  public void test107() {
    TestDrivers.rayTrace(60.739723f,-0.1671551f,42.186146f,-53.03504f,8.357893f,-11.415676f,58.170933f,-1.7739177f,1.8633482f,-1.307056f ) ;
  }

  @Test
  public void test108() {
    TestDrivers.rayTrace(60.941853f,-51.35874f,-100.0f,-64.273575f,100.0f,-74.35435f,56.064926f,0.09141797f,-0.15478456f,0.9837096f ) ;
  }

  @Test
  public void test109() {
    TestDrivers.rayTrace(-62.28878f,-68.94146f,75.35689f,-63.805645f,-88.296005f,-12.697492f,60.14502f,0.9655258f,-0.23607282f,-0.109679155f ) ;
  }

  @Test
  public void test110() {
    TestDrivers.rayTrace(-62.436916f,100.0f,-28.287903f,-80.93974f,-100.0f,100.0f,-100.0f,0.14165145f,-0.9898763f,0.008934826f ) ;
  }

  @Test
  public void test111() {
    TestDrivers.rayTrace(65.074974f,-22.359465f,-54.716736f,-53.074764f,38.372257f,-15.057316f,-100.0f,0.4038919f,-0.31997728f,-0.06978143f ) ;
  }

  @Test
  public void test112() {
    TestDrivers.rayTrace(65.46012f,-92.107544f,76.99981f,-77.402214f,100.0f,-99.98661f,8.181039f,-0.8435025f,-0.5359918f,0.03487639f ) ;
  }

  @Test
  public void test113() {
    TestDrivers.rayTrace(67.219864f,-4.329176f,4.1609197f,-40.916332f,-81.20585f,-89.85391f,-72.88202f,-66.06574f,-79.27876f,-17.676634f ) ;
  }

  @Test
  public void test114() {
    TestDrivers.rayTrace(68.00709f,-63.255444f,-56.701256f,77.1409f,56.21573f,-68.492966f,16.00602f,-68.78301f,36.786266f,-54.16503f ) ;
  }

  @Test
  public void test115() {
    TestDrivers.rayTrace(-68.44556f,21.635418f,-7.2231956f,-79.743126f,-100.0f,100.0f,-15.053482f,-0.2549899f,-0.4266755f,-0.048844427f ) ;
  }

  @Test
  public void test116() {
    TestDrivers.rayTrace(70.507195f,-22.234722f,47.328102f,37.489677f,44.31695f,-22.563776f,19.460928f,-86.74217f,91.30016f,44.23707f ) ;
  }

  @Test
  public void test117() {
    TestDrivers.rayTrace(-7.10775f,-87.87553f,63.686092f,60.99286f,-18.881517f,38.821953f,94.04627f,-9.128752f,74.3272f,-34.69699f ) ;
  }

  @Test
  public void test118() {
    TestDrivers.rayTrace(-72.81928f,55.093845f,100.0f,-100.0f,-99.11591f,24.891846f,51.80915f,-0.8467682f,0.4685817f,-0.25182304f ) ;
  }

  @Test
  public void test119() {
    TestDrivers.rayTrace(75.56656f,19.781471f,-98.8319f,-43.87578f,88.99689f,29.922838f,-58.311996f,-25.924736f,-38.226128f,18.159718f ) ;
  }

  @Test
  public void test120() {
    TestDrivers.rayTrace(78.482605f,-81.082535f,-100.0f,18.810242f,71.34442f,100.0f,34.36844f,0.56901896f,-0.3036888f,-0.21685152f ) ;
  }

  @Test
  public void test121() {
    TestDrivers.rayTrace(78.51255f,-4.459912f,-100.0f,13.621758f,100.0f,-57.19649f,-93.80619f,0.5151794f,-2.19725f,0.6813651f ) ;
  }

  @Test
  public void test122() {
    TestDrivers.rayTrace(82.41487f,-75.91136f,17.758438f,67.77911f,96.02212f,-32.196125f,58.038456f,-59.81274f,-86.85996f,7.8786077f ) ;
  }

  @Test
  public void test123() {
    TestDrivers.rayTrace(82.44045f,-26.50713f,34.04939f,-52.07027f,95.483025f,-20.781883f,14.52783f,36.11669f,-95.40136f,-35.07202f ) ;
  }

  @Test
  public void test124() {
    TestDrivers.rayTrace(83.33473f,38.434734f,55.86781f,-58.23379f,91.16475f,-67.05751f,37.257137f,-44.530262f,71.8163f,21.992239f ) ;
  }

  @Test
  public void test125() {
    TestDrivers.rayTrace(-8.366976f,-28.58303f,53.624184f,80.83044f,65.77059f,-72.3259f,83.68596f,-71.99775f,-48.89004f,-2.3847609f ) ;
  }

  @Test
  public void test126() {
    TestDrivers.rayTrace(-8.374493f,-50.591118f,-15.726765f,-31.88441f,-17.917246f,-73.41315f,4.3905535f,95.72524f,-67.55505f,-31.229969f ) ;
  }

  @Test
  public void test127() {
    TestDrivers.rayTrace(-84.5507f,70.89973f,37.888054f,-21.539843f,-60.479355f,65.98412f,57.440125f,-97.671555f,35.50914f,7.433393f ) ;
  }

  @Test
  public void test128() {
    TestDrivers.rayTrace(87.24993f,14.296119f,-82.19373f,100.0f,32.938503f,35.75271f,-57.11721f,0.13594724f,-0.53649944f,0.5908335f ) ;
  }

  @Test
  public void test129() {
    TestDrivers.rayTrace(-8.726666f,-75.59225f,-80.57301f,-100.0f,34.640877f,-63.663567f,-56.09961f,-0.27398625f,-0.7892631f,-0.1851089f ) ;
  }

  @Test
  public void test130() {
    TestDrivers.rayTrace(-87.96008f,-89.59325f,-31.332962f,-75.84335f,-18.015429f,-95.7553f,3.037823f,-27.691376f,-92.08015f,-96.449455f ) ;
  }

  @Test
  public void test131() {
    TestDrivers.rayTrace(-88.51151f,77.90617f,-99.5324f,-100.0f,-71.70898f,14.131213f,-74.32131f,0.46226913f,0.728926f,0.2764307f ) ;
  }

  @Test
  public void test132() {
    TestDrivers.rayTrace(90.03698f,-69.70152f,13.572376f,-87.562004f,-32.8799f,-73.69915f,-27.130335f,-59.07646f,-73.84192f,92.51658f ) ;
  }

  @Test
  public void test133() {
    TestDrivers.rayTrace(90.554405f,32.813866f,-100.0f,-60.219673f,85.24261f,45.087673f,-81.57364f,0.5126773f,0.6836352f,0.41142577f ) ;
  }

  @Test
  public void test134() {
    TestDrivers.rayTrace(91.39843f,-30.403173f,-11.551736f,-36.851334f,-38.133087f,-46.482563f,-95.97143f,-62.388752f,-27.08673f,-45.163925f ) ;
  }

  @Test
  public void test135() {
    TestDrivers.rayTrace(9.148553f,58.36835f,99.655334f,-100.0f,100.0f,100.0f,89.8413f,-0.5073264f,0.8581583f,-0.07863985f ) ;
  }

  @Test
  public void test136() {
    TestDrivers.rayTrace(-92.874664f,-100.0f,29.814486f,100.0f,-100.0f,69.264854f,-67.9948f,0.039901976f,0.9646346f,-0.26055303f ) ;
  }

  @Test
  public void test137() {
    TestDrivers.rayTrace(9.322341f,-48.667965f,92.336464f,87.13759f,78.9665f,-10.740044f,56.223804f,-79.18647f,97.33401f,-50.486267f ) ;
  }

  @Test
  public void test138() {
    TestDrivers.rayTrace(95.0014f,28.75242f,28.194508f,-98.39602f,-100.0f,-45.538754f,12.750943f,-0.8436978f,-0.16610597f,-0.51047313f ) ;
  }

  @Test
  public void test139() {
    TestDrivers.rayTrace(95.81512f,-100.0f,88.60364f,77.155945f,100.0f,-46.758064f,-100.0f,-0.026153365f,0.12730542f,0.9915187f ) ;
  }

  @Test
  public void test140() {
    TestDrivers.rayTrace(97.980705f,-100.0f,5.536415f,11.130943f,82.918015f,-65.06312f,-100.0f,-0.14625914f,-0.04961721f,-0.9880012f ) ;
  }

  @Test
  public void test141() {
    TestDrivers.rayTrace(-99.98944f,40.156998f,-14.778773f,-89.933914f,-75.49196f,42.172836f,71.73087f,-0.93434507f,0.21547768f,0.05859743f ) ;
  }

  @Test
  public void test142() {
    TestDrivers.rayTrace(-99.99379f,-2.0766528f,-100.0f,18.577744f,-43.007355f,31.587576f,-92.44853f,0.7721538f,0.5074637f,0.38243842f ) ;
  }

  @Test
  public void test143() {
    TestDrivers.rayTrace(-99.998886f,100.0f,100.0f,51.6501f,21.145674f,97.10932f,3.940441f,-0.9593077f,-0.28233293f,0.0041065575f ) ;
  }

  @Test
  public void test144() {
    TestDrivers.rayTrace(-99.99998f,-26.048578f,11.387217f,21.696634f,-100.0f,-41.399643f,25.847713f,-0.60022914f,0.5182768f,0.60919136f ) ;
  }

  @Test
  public void test145() {
    TestDrivers.rayTrace(99.99999f,-44.32947f,99.999985f,45.59938f,80.95189f,4.6900177f,88.360695f,-0.44623804f,0.6720297f,0.7861337f ) ;
  }
}
