import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(38.596417670370016,7.278736615563773,-68.26828031667415 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(56.47187420130953,-71.64280555023296,-64.48818554943733 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(79.19371746036052,-19.92694570179168,-11.446151025243822 ) ;
  }
}
