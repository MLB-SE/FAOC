import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(-0.14104695883480106,11.634756058490069 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(39.102597245738764,-34.136749596003185 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(55.05842657921792,34.81349122675857 ) ;
  }
}
