import org.junit.Test;

public class Sample84Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark84(1.0,0.9999999999999998,1.0,1.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark84(1.0,0.9999999999999999,1.0,1.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.000000000000071,1.0,1.000000000000071 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,0.9999999999999998 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,0.9999999999999999 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,1.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,1.0000000000000002 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,1.0000000000000004 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,11.494975733595243,146.4312897807601 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,-2.450918257873836,6.007000306779321 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,2.4740070134061423,6.120710702382779 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,3.265548441688858,10.663806625016528 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,6.8015119665993575,26.28210775924477 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark84(1.0123496687762672,1.0248518518714178,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark84(1.0,67.51784850706483,1.0,67.51784850706483 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark84(1.0,82.48783201586865,1.0,-80.48783201586865 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark84(2.6058179943289588,6.790287419568598,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark84(3.865175367464488,66.04930230501583,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark84(-55.60256059197872,29.214356403057707,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark84(-9.83199205289283,96.66806772814775,0,0 ) ;
  }
}
