import org.junit.Test;

public class Sample91Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark91(0.37604325404853967,-43.26643605799991 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark91(14.274488624945192,-51.69895710044047 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark91(67.59392070849938,7.313231365323205 ) ;
  }
}
