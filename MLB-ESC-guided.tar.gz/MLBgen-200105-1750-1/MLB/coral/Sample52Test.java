import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(34.644543590727714,-32.82942117528729,41.78023368224315 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(37.611612885746155,78.44420151477308,46.9585065128058 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(52.90236798399836,82.23331446304226,50.91080022012392 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark52(56.058092041287196,71.26772701397198,87.41236902740374 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark52(86.5461920465485,-89.25972700463598,54.74185045600524 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark52(89.70955303665056,-64.83594782331716,-66.12911581017218 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark52(9.650337692543104,-41.97341848597345,-40.71972511065671 ) ;
  }
}
