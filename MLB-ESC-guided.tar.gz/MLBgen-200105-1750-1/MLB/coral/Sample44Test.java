import org.junit.Test;

public class Sample44Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark44(-0.956890388299256,100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark44(12.747221772509818,86.10472023679213 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark44(17.389680757942898,0.12591045006270463 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark44(2.5309529719064443,2.5309529719064443 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark44(62.727039682178486,72.3669120554259 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark44(90.32869228132537,17.253008082741417 ) ;
  }
}
