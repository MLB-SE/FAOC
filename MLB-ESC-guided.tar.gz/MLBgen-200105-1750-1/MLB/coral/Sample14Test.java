import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(-0.040081979550009805,33.89324090685969,78.72374323427519,74.89394955276009 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(0.30596935560791394,-62.38747896302852,-84.91056992480202,47.991058681226605 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(0.9764119895784233,77.48325339539984,-12.400816582426273,54.17254159117988 ) ;
  }
}
