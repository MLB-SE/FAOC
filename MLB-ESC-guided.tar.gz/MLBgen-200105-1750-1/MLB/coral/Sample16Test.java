import org.junit.Test;

public class Sample16Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,-15.520583533914632 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,15.919844402496324 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark16(-45.80852020265882,14.028897731028806,17.146417716408674,86.61178923108764,-69.0735332463112 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark16(49.538615549274795,14.805058467002368,36.3135043476704,-43.559869915672664,-68.07135146044305 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark16(-73.01238982851453,15.085516058881538,-82.055890117508,-32.63191937405303,-1.6230256276224821 ) ;
  }
}
