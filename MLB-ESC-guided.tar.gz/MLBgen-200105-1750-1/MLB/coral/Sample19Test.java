import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(0.3503305779344288,-18.24181882630478,-0.4168843453238509 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(0.8350395840491757,19.096175721300657,0.22729316318620135 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(0.9376585551773351,17.443780051357265,-0.25296719668178014 ) ;
  }
}
