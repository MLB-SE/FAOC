import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(-0.7070112372056485,38.410029851762545,13.32838186583625,-78.08994097497694 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(-0.8798945032231842,62.16604819446982,50.7985977024409,12.244300234199557 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(-0.9864189666748076,-100.0,-57.05420227245642,9.535335430186429 ) ;
  }
}
