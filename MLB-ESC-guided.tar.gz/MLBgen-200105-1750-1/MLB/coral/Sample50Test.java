import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(0.0013889892428474145,1.3411873723468283E-4 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(0.752098711217376,0.8672362487911742 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(1.1347050526065061,24.604854346289258 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(1.2467061991596466,62.67971279613437 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(1.5741968491188345,14.574196849118835 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(24.156433820809966,25.843566179190034 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(2.475826877565531,9.904109376100934 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(47.879263974164445,78.41025688264699 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(62.28345091591408,62.6647451397101 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(8.88962118176612,35.15427007520566 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(-95.17318681688923,53.67077900250922 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(98.2338286446466,99.34463953655515 ) ;
  }
}
