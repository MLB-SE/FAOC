import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-3.0995019665822383 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,82.71148196996882 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(0.2540680823096611,-1.210184973390412E-122,89.88280203631143,-65.76757881963165 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(0.5720139772883311,2.358372977711202,1.783662604329243,-0.0018893997510247872 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(0.733451993930596,5.104263783142489,4.370810330329001,-1.4588828913838946E-6 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(0.7955073761102993,-6.242758230464586,-5.567992240005495,0.12356730904201252 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(0.8495149100027981,10.848410667198356,9.998886069216491,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(0.9330978309085848,-11.32394122115866,-10.938586270551477,0.5477428803014129 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(100.0,3.082015043607665,21.847522848214158,37.78654119628749 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(159.7430108907095,2.019473596582216,13.38908129173275,-68.0079895547641 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(1.6065078487065436,-0.09727122881323229,26.170994642657003,-21.195847793071653 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(25.04359602556943,-23.49656274753103,61.40796207443228,-5.050356095044364 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(28.824890314179086,-16.053035935097967,-86.1868502717353,-65.46402091642261 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(3.0317257267696385,-3.0E-323,100.0,-96.96827427323035 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(32.08770007090109,-30.110666984202638,-30.240296389045596,38.66311093448945 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(38.741666676514456,-1.7499460815430012,-82.38678596816762,-66.75062649532973 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(38.906004967889004,46.07860016842517,78.34210427873401,81.7205724843273 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(45.886759430058504,14.002655088294475,77.79135759377027,42.825031678055154 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(49.09961171917984,-47.43477799681181,54.127105368355785,-1.035097322948996 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(55.41420169916097,60.29275726724754,87.32853500738918,-3.2209670779688793 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(63.90392354834745,43.96966233429484,164.5124421269349,-14.011156995591946 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(66.88579217003225,0.0,-60.63199508944539,-81.68477804410601 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(69.91172402232206,40.41025092893301,-95.7520917892724,-56.18510701296175 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(7.118357744636498,-5.424453038840667,-35.67100348142272,-21.058447597064657 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark62(87.53523211120901,18.42874874309325,16.44260536726216,89.5213754870401 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark62(87.86657373148427,12.28257096556284,92.1618029197434,67.99078108088764 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark62(88.75382171815835,20.358001260407676,-5.9262323881686,18.94800793873192 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark62(89.03887589352266,-86.608233139748,7.813893072312197,-81.94177230298017 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark62(9.457452904117577,2.4963102814775366,-3.1835172902215456,3.7882817235700093 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark62(-96.04541223487197,67.3899376373283,24.087677946689823,9.39644423963928 ) ;
  }
}
