import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(-0.6232968915153663,0.8008087947448388,-67.40261394407203,1.7176710653573624 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(0.8621691578145914,-0.7512105017018627,12.010707431844779,-64.42447867185956 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(-0.8978002209600504,-0.40991538280088946,25.48147004491952,76.15705271882297 ) ;
  }
}
