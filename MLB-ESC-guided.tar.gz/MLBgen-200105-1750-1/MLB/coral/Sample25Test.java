import org.junit.Test;

public class Sample25Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark25(-100.0,-59.86620085560529,-100.0,0,9.776658825624967 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark25(24.34224603235748,10.43121425225371,69.10920627080398,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark25(26.246758772710496,-96.0467767521749,15.933985802977375,90.14556320302412,-2.398619203366985 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark25(26.571390418164924,-41.105127045662016,66.5749108319119,36.81417264515786,57.65377589201137 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark25(27.014261966344144,84.71099091789303,57.187507925183084,80.80748772364154,-75.28113954802981 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark25(28.592458849527656,97.73176927421059,-53.06135657167191,86.68575126981355,-74.41078662871266 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark25(-3.384163720854616,100.0,-100.0,-8.501955222892725,75.12337454675675 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark25(34.14153629108043,-73.82163364088115,-79.35079019635468,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark25(-35.5918223548219,36.23645601977657,73.24382478644804,0,36.352897697270805 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark25(39.551508182043804,-86.09788194137577,98.39839199538584,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark25(4.41858544730438,4.559854089058902,49.10201775644913,65.38982904884895,80.30590432292925 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark25(-79.7062094999679,-42.69961004840845,-3.556632959506942,-16.16857901734741,-23.62903682157409 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark25(-91.97300332751017,-55.314298258743165,-78.04619457159639,-55.042077822620364,-49.66229905293058 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark25(-99.08793463819165,27.90408463163017,-44.565849746665684,0,0 ) ;
  }
}
