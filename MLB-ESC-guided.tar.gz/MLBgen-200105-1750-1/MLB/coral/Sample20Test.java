import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(13.607268051060544,44.63197706377525 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(-16.367021303775374,3.095148085937712 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(16.367021303775374,-76.04365992216485 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(75.53423012575749,-47.86139673241803 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(81.5247266176614,-6.9418285455517434 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(-95.32275208921322,-86.64507586350088 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark20(99.79514513833269,34.08844721621077 ) ;
  }
}
