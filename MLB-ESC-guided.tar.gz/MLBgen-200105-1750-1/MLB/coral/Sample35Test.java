import org.junit.Test;

public class Sample35Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark35(-10.694814699722869,-16.267911804561592 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark35(-10.995574295383335,-73.23519621694183 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark35(32.77439401034704,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark35(-48.69468613205495,-86.51437279567374 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark35(-61.26105674106375,-67.3107775952111 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark35(-81.68139409209165,0 ) ;
  }
}
