import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(-20.129519278725052,-79.87046089577426,-99.99998017449931 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(73.63160223636805,93.08634871319222,23.9797520040929 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(-82.305630509303,43.326021398354584,15.56232180238932 ) ;
  }
}
