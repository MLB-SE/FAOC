import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,67.87991898537584 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,-7.486081912394525 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(0.5368152842428917,2.148535543439937,-83.9609739828446,86.65540110318163 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(16.122599168858414,90.53538035778314,74.12101802583118,35.49928730793641 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(20.42492771940823,-1.2154326714572542E-63,78.51275298207119,-100.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(2.341620370357369,-3.2311742677852644E-27,46.73705268333704,-42.06357377238287 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(23.42936937781535,15.743598594956438,70.57096827605932,-24.959702769213436 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(2.368195472762591,-3.0385816786431356E-64,100.0,-97.56256408896556 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(38.24330122368724,-7.620521962409697,-64.53010964630595,-65.46372819363106 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(42.65272187729869,-44.08587449172149,85.48686143588338,-59.64951713834954 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(46.80698565377904,97.65995172757403,78.9692533011102,50.8423771457104 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(50.15288957714847,56.08070891130913,75.46560453186916,60.92786141899356 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(52.25941899085831,-0.6984845260006267,45.52282116777417,-93.74203950345353 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(53.853285426972974,37.64178185221483,91.87981868345337,1.4306784317067145 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(58.347462640627214,0.0,-6.1732068196117496,-97.12067334633876 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(68.28436003613416,18.067657153527648,96.32374226782994,-9.971725078168133 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(77.69155979792745,52.87532524993105,-48.07133702086912,-69.53512154910194 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(81.658773993204,-3.1411420424603165,-75.5429996803224,83.04521934940286 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(83.07859948387696,62.06666481034057,28.03940770229022,-13.89074519150742 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(84.77019771464238,7.716322003187486,71.0447418552314,47.788064380012855 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(93.6248821375647,10.814086364425975,-83.73668722216433,70.93594408829577 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark61(-96.7434692214768,57.96831179293676,21.903439802089437,9.169286170383913 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark61(99.19512622670302,13.141446746420996,85.05521212878534,43.246272532358915 ) ;
  }
}
