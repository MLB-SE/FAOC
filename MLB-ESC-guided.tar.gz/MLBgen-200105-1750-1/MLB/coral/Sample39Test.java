import org.junit.Test;

public class Sample39Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark39(100.0,1.9503789241632246E-18 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark39(31.28891800724898,-15.98844610589147 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark39(94.08402932130835,36.37974424038518 ) ;
  }
}
