import org.junit.Test;

public class Sample01Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark01(20.181997669586817,-4.740664967433835 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark01(33.89126977874534,58.32548567752539 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark01(83.05220535529475,-94.14308511108582 ) ;
  }
}
