import org.junit.Test;

public class Sample46Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark46(0.0,0,-65.25373609237458,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark46(100.0,100.0,-100.0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark46(100.0,1.0,72.64554207658921,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark46(1.3877787807814457E-17,75.34980556971163,1.0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark46(1.734723475976807E-18,100.0,1.1243027382710197E-17,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark46(19.057793962295364,1.0000000000000002,100.0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark46(23.565739152550606,-20.83629899744612,27.702730138126014,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark46(28.24715615292027,0,93.00520957592184,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark46(30.309035823524482,11.736789273248462,99.73164270962175,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark46(31.716346282375355,0.9999999999999986,100.0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark46(4.930380657631324E-32,62.23282099996802,1.0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark46(5.124666135404382,0,86.75643044487964,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark46(51.74167689581242,1.0000000000000002,5.910994164505543,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark46(-54.43448016033748,0,0.22193079917596492,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark46(5.551115123125783E-17,64.28840417494808,1.0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark46(63.99895432041892,1.0000000000000002,19.452496254197854,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark46(-647.5194683038992,0,23.339926189888473,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark46(-744.4814266996111,0,20.20393781314762,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark46(75.09632088855346,0.9999999999999998,47.506200057612205,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark46(92.79368726839533,0,65.29836864895685,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark46(93.38636800013327,1.0000000000000018,62.14994433985052,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark46(96.48874571372883,33.47906504486318,66.31437406953725,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark46(98.28528453247753,69.49909686798549,38.23497523638545,0 ) ;
  }
}
