import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark05(-28.607184946951918,89.81661095194445,55.429234294502606 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(-31.217959425573948,-51.40187484978058,-52.75797583866242 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(49.784588361406634,-28.261117256468495,-5.161218552374265 ) ;
  }
}
