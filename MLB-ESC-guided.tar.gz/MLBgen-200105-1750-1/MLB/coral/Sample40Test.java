import org.junit.Test;

public class Sample40Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark40(12.6012651588876,-90.11292055233527 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark40(-2.3554514491667504,55.85388259403007 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark40(8.745521815373692,67.73863000780347 ) ;
  }
}
