import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(-26.666941777274445,-37.720414956763506 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(2.9498124655707776,8.701298421321091 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(-3.990558871902271,15.924816217916593 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark83(6.719607915351745,45.15333603900727 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark83(9.546316456624455,91.13212576239067 ) ;
  }
}
