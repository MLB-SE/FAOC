import org.junit.Test;

public class Sample81Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark81(47.52352595360355,98.12749414563964 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark81(6.600875482120159,-0.6271361634671693 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark81(7.959235405033395,3.8081463180724455 ) ;
  }
}
