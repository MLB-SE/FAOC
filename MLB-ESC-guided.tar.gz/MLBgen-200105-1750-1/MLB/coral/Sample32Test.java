import org.junit.Test;

public class Sample32Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark32(18.34785192800932 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark32(25.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark32(95.03409124938474 ) ;
  }
}
