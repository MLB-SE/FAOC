import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,-35.76170486054133,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0,-4.265454512685537,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(-1.357919669897302,48.82756922905198,-67.99325317511061,87.9023941810255,-15.284733934075705 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(16.434708585549657,69.48419637484491,-13.801756898723468,40.23042299962435,80.91644505392185 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(22.866863822003708,-2.6751623067138013,5.182783683302603,-27.12189500812252,76.03165624119487 ) ;
  }
}
