import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(-0.3265168122212234 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(2.5713852525059337 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(-3.970055744990873 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark31(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark31(47.692555424056934 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark31(4.8857809677483885 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark31(5.465346785448213 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark31(-66.1468349280625 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark31(-89.26546510243975 ) ;
  }
}
