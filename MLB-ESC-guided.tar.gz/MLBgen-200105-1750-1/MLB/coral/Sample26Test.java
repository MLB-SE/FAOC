import org.junit.Test;

public class Sample26Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark26(-100.0,-100.0,16.16534756701195,65.91394689666829,-73.70842970270407 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark26(-100.0,27.94323273721942,70.22664036566984,58.46031667133791,-11.055465724954061 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark26(-37.80267934301859,40.90173908433622,-6.253183433700585,0,78.41774715615229 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark26(37.88336239898916,-67.29840540649275,89.97803700985466,0,-43.08284821122073 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark26(-41.90222225436002,-86.2519938217642,42.51826589402057,49.739498966319644,94.16267166134867 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark26(-42.12955794809656,26.467752939700745,-74.90836670992647,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark26(55.792455877162965,-81.39387865144718,-78.10651184232114,-41.37643253271779,94.13951445559834 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark26(-68.52394419564308,-96.73992637751981,92.32574994277721,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark26(-69.37569880460708,19.50027328194072,33.93890762848187,8.735118679824126,6.758733141555865 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark26(-71.43031255587417,-78.29773347832152,83.63746944626104,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark26(71.70790354282268,1.6587792746654488,-81.23520850108778,-27.02168732204506,-73.3905129730259 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark26(75.41811322685939,-26.15893374584249,-10.511061125538617,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark26(93.0366285767268,-64.03565781499572,-87.54255693459535,-28.3920969368058,88.25494061548324 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark26(94.02407781513361,97.00852347217716,38.57449281912484,-11.196760109982772,2.390276409270895 ) ;
  }
}
