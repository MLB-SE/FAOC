import org.junit.Test;

public class Sample54Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark54(12.042475020998014,-46.07899320130269,72.76916226548057 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark54(13.139183052370763,-30.84782948329622,14.562446313521818 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark54(17.45428385255098,2.733675081453729,18.40769176668327 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark54(26.42752079797208,-90.06618770309633,50.339702800056614 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark54(27.045054325240443,2.3530970173574133,-76.81210959286425 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark54(3.3352354146545196,1.3598191610579136,81.87707460026269 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark54(3.4368238281015584,88.68521391539024,1.1474116838907784 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark54(34.7279259320932,-10.495885686639411,51.62269878488436 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark54(39.076096095151904,68.69439228588901,39.01896881653886 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark54(42.1159895252396,89.52646091813301,43.182335416983875 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark54(53.78329949938012,-52.207166016666996,56.96307535854922 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark54(6.030051679353332,-46.06157612288082,25.11942670091405 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark54(62.87112694293208,30.88219708590296,41.735557830904185 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark54(65.01594721797377,18.751066280916433,67.82233328905798 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark54(69.56692476829406,-22.404212599536933,95.24981173066575 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark54(84.44337424202041,-98.67826435155563,90.35540001975846 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark54(89.93172578218426,-45.74324255064563,1.9000643343642452 ) ;
  }
}
