import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(-0.04615625418007596,-9.193250980600467,-70.52807979021252,-13.904687570149022 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(0.7261089855826555,96.27026823692404,47.76960567131056,-69.212631960125 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(-0.852398949770311,21.95913906750295,59.212047140997846,86.04702352589965 ) ;
  }
}
