import org.junit.Test;

public class Sample30Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark30(100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark30(168.71485900804447 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark30(23.650736369157798 ) ;
  }
}
