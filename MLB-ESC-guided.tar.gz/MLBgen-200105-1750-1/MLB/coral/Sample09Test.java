import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(-28.729149580430033,-51.4195963799615 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(-55.678092140927205,77.31361651374488 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(56.101287735639005,21.29180960265513 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark09(-82.47039496595461,-27.9164712475702 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark09(90.24853424388766,-95.66680958268041 ) ;
  }
}
