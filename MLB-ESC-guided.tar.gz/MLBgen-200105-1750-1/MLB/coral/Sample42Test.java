import org.junit.Test;

public class Sample42Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark42(0.9755248803426416,0.518067806493903 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark42(-100.0,-100.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark42(1.0,-70.956663900196 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark42(1.6285253316928703,10.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark42(30.512382889895633,52.95270913485135 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark42(32.99438332897495,10.51311651843912 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark42(52.457374932336364,98.22878318946479 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark42(63.087552579676725,86.57126835670155 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark42(81.26364951753013,0.6638131140741308 ) ;
  }
}
