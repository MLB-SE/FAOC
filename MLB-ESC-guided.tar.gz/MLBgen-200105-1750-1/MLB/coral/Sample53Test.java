import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark53(0.7907362962657771,-97.6061706930189,70.97840372164231 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(1.5357948378280923,0.6506778403353195,22.53182178473203 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(21.105243862072072,-90.75877315529546,29.417978985051874 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark53(21.11579118644326,90.0914831962541,22.403298508101148 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark53(25.95838491578904,44.46202818797593,24.089456201852826 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark53(31.146829835294085,6.630817010804506,32.056408436764485 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark53(32.855072356247916,-97.73442298032664,42.250630770235404 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark53(36.52391684971181,10.999161110230531,79.3136181140514 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark53(45.99021344633846,75.4763805412108,69.93102571270427 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark53(46.20031470836379,2.77395664121105,49.78642854438851 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark53(56.96315609750559,25.625901939031692,13.013254891125968 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark53(70.38919777394847,8.741439640247833,-83.38151280591306 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark53(7.8588626955220064,87.2980579726406,-26.00681123049982 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark53(90.28499435528957,65.60575719868811,7.636807466845582 ) ;
  }
}
