import org.junit.Test;

public class Sample34Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark34(-11.780972450961725 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark34(12.67408944194473 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark34(-29.895180608528378 ) ;
  }
}
