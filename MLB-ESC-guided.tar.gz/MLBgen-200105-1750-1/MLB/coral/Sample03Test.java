import org.junit.Test;

public class Sample03Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark03(17.29057767605275,-35.02778069017593 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark03(76.37284769493249,-16.466758507067254 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark03(86.28711712622962,-59.79694126569577 ) ;
  }
}
