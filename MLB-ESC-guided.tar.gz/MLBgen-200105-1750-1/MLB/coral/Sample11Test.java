import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(-0.16278773602726915,99.83117386196315,13.635063332336443,-99.94051339322382 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(-0.6839986963156832,-53.86705006363817,68.37513954780087,40.586493935171916 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(0.9079902808125269,-70.09733088052917,60.43381627964249,-42.13098264956279 ) ;
  }
}
