import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0,-6.006376537852034,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(0,-84.62314279428429,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(20.567969266716332,21.621945734443983,79.4910466382207,-97.74747070591062,99.74924548152822 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(31.728250603393093,33.88066378482867,77.15312246357755,-89.97551109995636,-82.41806839795522 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(66.24224598563342,-35.30525868437972,15.857514577230674,87.09534062929023,-7.788409193468041 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(-7.054176294542934,5.7310600305201405,-38.37200810499695,-82.43252184360632,19.469122049817543 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(81.92688754328395,49.276902341310546,47.14533529533554,-39.3855563034232,-6.407284859112934 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(9.831439439617752,37.351018510010775,59.71589072015823,-61.31599542224771,49.59691335092003 ) ;
  }
}
