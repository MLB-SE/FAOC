import org.junit.Test;

public class Sample51Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark51(0.9667073345978768,44.83633551983425 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark51(11.797549930605982,60.206335683573826 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark51(11.88268659488702,60.06395169232056 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark51(12.783485459679557,37.216514540320446 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark51(13.10221667349891,35.924924150274876 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark51(1.3280179217107217,28.676650987611648 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark51(14.357131780646398,24.742730127642872 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark51(1.5140022514405953E-4,0.012304492748924634 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark51(2.8714922680816655E-7,1.5353058105109435E-6 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark51(62.41957665804509,69.8643994828727 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark51(69.35924624429845,61.14129961749154 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark51(82.80380687824645,83.13414650379245 ) ;
  }
}
