import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(17.05959070225771,32.94040929774229 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(19.368403553012424,29.14159882132546 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(2.5053176694906085,52.35197913163401 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(3.4341719988914257,5.478959935117903 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(35.12860201047502,70.35742368128629 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(4.2705368321488413E-16,2.0666368559240122E-8 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(5.797771117366235E-17,7.614007203918348E-9 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(62.62668195030031,80.45125554119639 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(-69.40364191536483,65.74410738659728 ) ;
  }
}
