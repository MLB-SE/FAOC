import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(31.596895952884797,-35.70371678902046,27.631640606679483 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(-63.84263789446061,59.215935905643406,-34.71646040925477 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(6.614166747153121,98.06433215260421,-80.30273240071966 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark08(86.43565496970479,-46.67269727710095,-71.6319553571056 ) ;
  }
}
