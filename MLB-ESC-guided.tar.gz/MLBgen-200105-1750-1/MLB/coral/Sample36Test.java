import org.junit.Test;

public class Sample36Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark36(-11.172763917080886,-96.0321579865176,19.60603301051971 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark36(-36.90267539162193,-46.6215103025012,7.006467929746104 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark36(38.05299332242208,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark36(45.05321113405688,82.3490827564442,5.462375821995408 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark36(62.83192095117091,0,0 ) ;
  }
}
