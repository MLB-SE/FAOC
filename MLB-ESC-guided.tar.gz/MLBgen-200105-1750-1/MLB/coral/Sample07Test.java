import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark07(0,-11.519173065428095,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(0,73.59175557478366,0,14.255002832134679 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(0,-77.95829337786795,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(0,-97.55241397194274,0,-63.306660836584406 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(-14.53255137955756,81.43443166237537,57.314570445748814,-28.021785512544398 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(-56.24946732423173,20.85315522499316,-5.683584086114351,1.6393655613218243 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(-5.926449512235927,-48.21703899510322,87.65901235121385,23.42004393019354 ) ;
  }
}
