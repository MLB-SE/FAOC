import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(1.0658217592534713E-9,-100.0,100.0,-100.0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(1.7982341517016412E-9,-118.13734447405957,-100.0,100.0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(3.0142171369681297E-33,60.7004115513231,12.477856447230636,100.0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark79(-3.229647535624074E-8,100.0,-100.0,-100.0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark79(60.980062543449776,53.92194269317494,51.59023452373751,20.978440927503357,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark79(-6.702440474148076E-9,-100.0,-100.0,-100.0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark79(6.74588484766403E-9,-100.0,100.0,100.0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark79(8.10024368476778E-9,68.22470766038035,-1.381431986386565,-84.73869850073316,0 ) ;
  }
}
