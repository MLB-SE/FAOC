import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(100.0,-5.781116124092951,0,-99.99660134782488 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(10.226751788336413,-61.431545545192186,-89.05664645853562,-79.67004821491305 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(-131.8396122239776,-30.985319321352964,77.74500350967003,-58.51595468833963 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(-17.375322813008534,-54.5475533478051,-8.414766802338882,92.61127985138096 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(-23.28248062342668,-12.793570171916684,0,-9.754767659516219 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(-30.4986495718793,-82.97513189600755,-12.225022044067211,59.66686631793457 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(-30.59670208733725,61.58369412334395,38.24136347893046,-79.40708511517278 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark23(-37.23247603550904,-41.416589064134534,84.9073833263534,63.34246474462527 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark23(39.929095699963426,38.91416719661464,50.36339361221914,73.8044316816634 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark23(-40.746849928777216,-41.42159303178441,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark23(-44.05851602425057,-42.866707825226506,-47.57523828166735,-0.4334465052522489 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark23(48.72216647241685,-39.10015040608814,18.827319198724116,100.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark23(69.70725475227167,35.440052966090846,-20.570060948669514,-2.201228565046044 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark23(87.48802355172765,-37.4119307899635,-68.7150022857674,-60.62444276095153 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark23(-94.04657425177938,-61.361659425634016,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark23(96.24059556458383,28.247882778765614,25.75703516935289,-23.642353174693326 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark23(99.08849934367949,-68.33943322943489,23.748754428658717,-13.921575316065136 ) ;
  }
}
