import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(27.883223878674272,69.38532512574702,2.173233381369613 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(-28.84318944858617,67.14030104739388,-69.26967481665953 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(-91.10903444018419,80.69435977259229,-44.542114086817186 ) ;
  }
}
