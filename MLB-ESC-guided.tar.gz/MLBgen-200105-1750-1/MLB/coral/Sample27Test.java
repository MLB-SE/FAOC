import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(-15.144777869838006,87.99917867042781,-91.18428859665164 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(-2.3179759592644884,-33.320532569847224,57.462129079305214 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(27.23022156693861,-40.38596119912703,33.10425820859848 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(28.49774941444801,-8.806933047490759,-67.21669832100315 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(35.09488352423003,-1.0939440899057833,-79.85969293521893 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(-56.07423485559853,-62.87307700174849,77.1260269734722 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark27(-60.84347474920055,82.35873937378597,8.886940996147842 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark27(73.82426374583075,64.26745618270382,52.22122367137658 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark27(73.90104067087827,-98.46439574074672,-24.96002682455864 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark27(74.52778353757488,68.46626795813293,166.0615068394235 ) ;
  }
}
