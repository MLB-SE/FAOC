import org.junit.Test;

public class Sample28Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark28(2.5307937904058804 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark28(52.45667745101264 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark28(7.389056098930651 ) ;
  }
}
