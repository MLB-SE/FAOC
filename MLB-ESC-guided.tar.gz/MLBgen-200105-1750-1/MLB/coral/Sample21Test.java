import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(17.45639173844495,81.90129996369802 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(22.966637435934032,50.133316675220684 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(31.3290357938952,26.58685812057729 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(-33.31641216391729,98.13082225033565 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(51.27602320446479,59.07620490518093 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(-61.387396872572005,62.97732435861962 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark21(-87.83825417294317,75.35489683407397 ) ;
  }
}
