import org.junit.Test;

public class Sample78Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,0.0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0.0,16.856146713710757,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,36.19850054253834,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,87.43786084658731,0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-90.0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-100.0,1.5E-322,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,100.0,-90.0,0,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,2.000541352977583,-7.26E-322,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-39.67417921061354,29.142115829749855,0,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-45.08511924868785,73.84725663058919,0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-55.847702081679685,-39.275315970989745,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-76.07036574700055,-90.0,0,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark78(0.355444809562556,0,0,35.30931006490394,-35.84762074588697,0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark78(-0.5338764586799982,0,0,-59.911154707947276,-17.49390890177827,0,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark78(0.95995137835828,0,0,100.0,1.49213E-319,0,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark78(-100.0,0,0,3.653359848957861,-4.7E-321,0,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark78(100.0,0,0,5.1253327236687384E-144,7.6301769663078245,0,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark78(-100.0,-100.0,-100.0,-100.0,100.0,0,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark78(100.0,-100.0,-100.0,100.0,100.0,0,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark78(100.0,100.0,100.0,100.0,-100.0,0,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark78(-100.0,100.0,100.0,-100.0,25.159091079005808,0,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark78(-102.0,134.0,134.0,-102.0,-1804.0,0,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark78(104.0,885.0,-375.0,-104.0,-242.0,-501,0,116 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark78(1.0499494156901306E-44,0,0,167.3521964773259,90.0,0,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark78(-1.1976317599805904E-72,0,0,100.0,-90.0,0,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark78(12.65643817326927,0,0,2.131197353912215E-255,-41.407647419645855,0,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark78(-14.51190124510005,0,0,12.022728165720721,-3.2692614408464376E-300,0,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark78(-1.518410973471846E-28,0,0,3.574542681901574,-90.0,0,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark78(-165.0,-759.0,-399.0,-165.0,-228.0,0,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark78(188.0,479.0,1559.0,188.0,-1268.0,774,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark78(19.0,280.0,820.0,-19.0,1858.0,0,0,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark78(-1.9546085222524442E-72,0,0,20.555000237203245,-90.0,0,0,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark78(20.503559644083715,0,0,-39.79424217938673,-90.0,0,0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark78(-2.0,698.0,-202.0,2.0,-197.0,318,0,-985 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark78(-21.108185397924295,0,0,42.820935168182224,5.094E-321,0,0,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark78(22.315470894664678,0,0,24.030372067239142,-90.0,0,0,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark78(-224.0,-1469.0,1051.0,-224.0,-768.0,0,0,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark78(-25.172790271283205,0,0,92.70914791904553,17.317621699971284,0,0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark78(-259.0,710.0,-550.0,259.0,-592.0,94,0,1 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark78(-31.099334304047588,0,0,-73.5042659219735,-74.23284595526513,0,0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark78(3.6730468657021423E-26,0,0,-32.795227203270755,-90.0,0,0,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark78(37.71711105326468,0,0,-49.41815592337097,8.915767354716818E-229,0,0,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark78(-4.06012289522171,-24.06369168348212,-32.074855548992986,-22.497317344791796,85.52206216902871,0,0,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark78(-4.134870751425225,0,0,9.461460163916428,-55.86027586943592,0,0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark78(-52.0,1400.0,320.0,-52.0,-816.0,0,0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark78(-543.0,-740.0,-560.0,543.0,867.0,-589,0,-519 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark78(-54.86089840529203,0,0,-19.49727148614215,-90.0,0,0,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark78(-58.26669658126234,0,0,9.420727212322277,-90.0,0,0,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark78(59.906639496641674,0,0,61.499582324153806,-6.621780566218675,0,0,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark78(64.11834363336001,0,0,-66.85358935691157,-90.0,0,0,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark78(-647.0,296.0,296.0,-647.0,115.0,732,0,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark78(6.853582398858251,0,0,-21.213360955196322,18.01436108780821,0,0,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark78(-80.36411103716262,0,0,-4.764192081924264,90.0,0,0,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark78(8.89781208453636E-49,0,0,99.8067973451852,-90.0,0,0,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark78(89.0,900.0,1440.0,-89.0,-28.0,-407,0,-807 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark78(-91.0,140.0,-1480.0,91.0,890.0,843,0,-640 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark78(97.0,-741.0,-741.0,97.0,-287.0,-1277,0,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark78(99.24014667495881,0,0,-99.32759202758365,-3.66E-322,0,0,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark78(99.99999999999989,0,0,-1.24E-322,-88.95560211349941,0,0,0 ) ;
  }
}
