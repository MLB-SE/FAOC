import org.junit.Test;

public class Sample33Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark33(-61.414785759787115 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark33(6.910178911332849 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark33(-74.61282552275759 ) ;
  }
}
