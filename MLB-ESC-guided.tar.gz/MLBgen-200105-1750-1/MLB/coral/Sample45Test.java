import org.junit.Test;

public class Sample45Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark45(0.0,-42.133893327584836,95.06419940623498 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark45(100.0,1.0000000000000036,-100.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark45(1.2876399477558493,-40.07518795606684,68.78062185165416 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark45(-13.86863334754274,-129.50777946777146,31.002023671838202 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark45(-215.56084301361474,-469.44195089052374,47.55373170671723 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark45(-378.0997791375718,-229.72014857641548,75.28591587540302 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark45(39.61149520330983,54.95316483261607,53.360572207953794 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark45(42.67834056401537,80.27299018278183,75.88309965465012 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark45(48.03103220274036,50.03103220274036,74.69712892050521 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark45(-498.46275239316515,-168.73471095511087,10.203417322209745 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark45(50.69827219437582,73.47405383802217,50.16380847886089 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark45(5.421010862427522E-20,1.0000000000005234,1.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark45(5.551115123125783E-17,1.0000000000000004,1.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark45(59.49074076474514,28.302533035799314,17.502311848774283 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark45(63.18257897068921,27.592617587718806,92.04964656547187 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark45(-85.42775764923556,-71.19103358206104,86.15940320401776 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark45(8.673617379884035E-19,1.0000000000000004,1.0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark45(8.818332820997332,1.0,29.2588446203428 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark45(96.94782413881043,-74.06596828266404,87.07312213428594 ) ;
  }
}
