import org.junit.Test;

public class Sample43Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark43(0.02504210348498681,0.0250421034849868 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark43(1.7266168114646403,78.47081845042874 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark43(23.72484207006744,25.419265459938174 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark43(30.706583753636917,30.706583753636917 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark43(46.49508187286844,34.780664765920875 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark43(52.76425238212542,74.71159985073433 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark43(82.17460659510834,88.7566362298183 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark43(89.44676906759165,0.31505058507650574 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark43(9.160948492207753,83.9229772768835 ) ;
  }
}
