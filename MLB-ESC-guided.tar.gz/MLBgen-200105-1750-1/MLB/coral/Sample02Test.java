import org.junit.Test;

public class Sample02Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark02(23.563985350003776,-44.373030096113354 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark02(-41.95902368352471,57.31132195468834 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark02(-83.84764114679338,59.09482459172051 ) ;
  }
}
