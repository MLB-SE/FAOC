import org.junit.Test;

public class Sample41Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark41(-0.20673745216306028,1.8707908032582026 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark41(-0.5730992691454637,0.9015420414405284 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark41(0.9870899136758593,-0.012743415995243979 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.000000000000017 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,1.9999999999999998 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0000000000000004 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark41(-27.796953818836116,-22.2629995891874 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark41(-3.117111963640127,12.833498957508537 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark41(4.203286504037635,13.464330930987288 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark41(5.94674836345601,29.417067734810722 ) ;
  }
}
