import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(-38.77865016601743,24.456779614284102,-94.68801402352271 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(-40.08525678527472,2.9704811629154904,-37.11477562235923 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(-92.75204378022217,-84.90550307850255,96.33748648824096 ) ;
  }
}
