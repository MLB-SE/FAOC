import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(29.508399977473236,18.947125733572335 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(-33.501057818783295,44.855170691083174 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(9.571100434275209,-13.334373688273942 ) ;
  }
}
