import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(17.855050929951755,-2.2392589795390863,38.45912580026376 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(18.132936006913326,-47.948513573579746,28.170655413451215 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(24.118539271258584,-84.78061466326395,33.88084164303518 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark55(27.069701315131603,47.51902723449487,37.580118428713035 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark55(2.9247852085496753,1.3252818013809629,4.240406817680673 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark55(30.862396970555437,-35.02014684222439,47.306055498017685 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark55(34.842374739199265,2.7659863186169265,35.80015047003931 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark55(39.85234910582204,-54.31079743064582,-61.966131177272565 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark55(52.90984507968736,68.90006655663555,62.5418452136916 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark55(53.07137324948851,-46.337518401458226,53.483637767262294 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark55(56.15229688578293,-37.879897100615764,86.9933325656128 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark55(58.37551596186145,-1.491543603053188,87.22440176379394 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark55(61.0692163732941,-42.33369679684762,-96.95045960531215 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark55(63.42503844882731,-7.437705170916203,72.24851188490757 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark55(64.57370406744397,-19.556756479472554,68.50386415104012 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark55(65.9278194217774,-31.930978013525888,88.09007335674852 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark55(72.43560115313588,-49.59899439052258,-6.187554068248531 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark55(72.4884184997502,-52.24412210172296,98.37340348988064 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark55(7.386750450263493,2.630655193452184,10.172297087656458 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark55(7.470238301550136,-77.44018390833654,51.80041418528513 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark55(7.517690207404473,2.6477759467499316,1833.6414272173033 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark55(86.67257766820597,8.50568071999001,59.60676233994687 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark55(87.00726591853137,12.753603794613639,85.64914955720941 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark55(97.7178687614718,-41.60221005116918,98.70497597669261 ) ;
  }
}
