import org.junit.Test;

public class TestStatCalcTest {

  @Test
  public void test0() {
    concolic.TestStatCalc.run(-127 ) ;
  }

  @Test
  public void test1() {
    concolic.TestStatCalc.run(148 ) ;
  }

  @Test
  public void test2() {
    concolic.TestStatCalc.run(162 ) ;
  }

  @Test
  public void test3() {
    concolic.TestStatCalc.run(-18 ) ;
  }

  @Test
  public void test4() {
    concolic.TestStatCalc.run(-202 ) ;
  }

  @Test
  public void test5() {
    concolic.TestStatCalc.run(3 ) ;
  }

  @Test
  public void test6() {
    concolic.TestStatCalc.run(323 ) ;
  }

  @Test
  public void test7() {
    concolic.TestStatCalc.run(-407 ) ;
  }

  @Test
  public void test8() {
    concolic.TestStatCalc.run(546 ) ;
  }

  @Test
  public void test9() {
    concolic.TestStatCalc.run(547 ) ;
  }

  @Test
  public void test10() {
    concolic.TestStatCalc.run(670 ) ;
  }

  @Test
  public void test11() {
    concolic.TestStatCalc.run(750 ) ;
  }

  @Test
  public void test12() {
    concolic.TestStatCalc.run(-752 ) ;
  }

  @Test
  public void test13() {
    concolic.TestStatCalc.run(-774 ) ;
  }

  @Test
  public void test14() {
    concolic.TestStatCalc.run(877 ) ;
  }

  @Test
  public void test15() {
    concolic.TestStatCalc.run(899 ) ;
  }

  @Test
  public void test16() {
    concolic.TestStatCalc.run(928 ) ;
  }
}
