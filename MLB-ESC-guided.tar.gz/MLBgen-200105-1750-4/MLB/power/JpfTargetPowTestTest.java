import org.junit.Test;

public class JpfTargetPowTestTest {

  @Test
  public void test0() {
    concolic.PowExample.test(1,1 ) ;
  }

  @Test
  public void test1() {
    concolic.PowExample.test(125,250 ) ;
  }

  @Test
  public void test2() {
    concolic.PowExample.test(-142,0 ) ;
  }

  @Test
  public void test3() {
    concolic.PowExample.test(151,-656 ) ;
  }

  @Test
  public void test4() {
    concolic.PowExample.test(20,400 ) ;
  }

  @Test
  public void test5() {
    concolic.PowExample.test(338,0 ) ;
  }

  @Test
  public void test6() {
    concolic.PowExample.test(40,1600 ) ;
  }

  @Test
  public void test7() {
    concolic.PowExample.test(431,122 ) ;
  }
}
