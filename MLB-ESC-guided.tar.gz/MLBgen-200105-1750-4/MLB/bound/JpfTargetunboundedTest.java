import org.junit.Test;

public class JpfTargetunboundedTest {

  @Test
  public void test0() {
    bound.unbounded.solve(-370,493 ) ;
  }

  @Test
  public void test1() {
    bound.unbounded.solve(547,862 ) ;
  }

  @Test
  public void test2() {
    bound.unbounded.solve(-730,-186 ) ;
  }

  @Test
  public void test3() {
    bound.unbounded.solve(-894,970 ) ;
  }
}
