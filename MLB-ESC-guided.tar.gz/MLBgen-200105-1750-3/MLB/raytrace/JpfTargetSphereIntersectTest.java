import org.junit.Test;

public class JpfTargetSphereIntersectTest {

  @Test
  public void test0() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.05428495f,0.9087839f,0.28549397f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.12380272f,-0.10076271f,0.98717767f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.43781632f,0.36536285f,-0.50054663f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1.0550112E-5f,7.239246E-6f,-3.7842797E-6f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1.1775937E-21f,8.155814E-21f,-2.1445013E-21f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1.7638999E-4f,1.3726966E-4f,1.13875976E-4f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2.2448097E-8f,-5.4938756E-8f,6.495338E-8f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-2.2501665E-9f,7.4216207E-9f,-5.0740354E-9f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2.8057034E-6f,2.6086944E-5f,1.2309362E-5f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,29.084827f,9.517956f,-24.784985f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-4.149015f,-89.86513f,79.16996f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-5.826096E-4f,1.8453366E-5f,9.458395E-5f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-6.456948E-11f,-7.243558E-11f,-1.5499242E-10f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,7.1385116E-9f,-3.8308356E-9f,-2.3499835E-10f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,100.0f,100.0f,40.331383f,-100.0f,44.66579f,99.99996f,0.25128686f,0.27192518f,-0.14372595f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-100.0f,100.0f,79.079445f,100.0f,-61.252274f,31.064003f,-0.30460906f,0.29164907f,0.65392315f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-100.0f,-30.537218f,78.12003f,22.487553f,-100.0f,-20.813005f,0.059053123f,-0.0033279553f,-0.9982493f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,100.0f,-32.73888f,95.58091f,48.554268f,22.163515f,-11.98969f,-0.036132544f,0.8258936f,-0.5626671f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,100.0f,-99.99899f,97.75258f,18.32514f,100.0f,-99.792885f,-0.56306636f,-0.79250604f,-0.23428707f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,28.072582f,-15.160263f,89.10928f,-8.934939f,24.643713f,-8.144259f,-0.8755f,-3.430062f,-0.8913754f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,34.903145f,34.409683f,13.84868f,21.726236f,54.447865f,-100.0f,-6.158665f,4.314312f,5.1530876f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,45.533226f,-100.0f,54.466675f,-99.99911f,99.9999f,-100.0f,0.122559145f,-0.8995484f,-0.4192755f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,60.575848f,79.04938f,99.686714f,99.67811f,-99.506424f,-30.449839f,0.033001825f,-0.9975892f,-0.061046768f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-67.53158f,15.215746f,52.868034f,-92.58719f,-99.66056f,-14.891886f,0.6989124f,0.4474093f,0.55798423f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,71.72033f,-82.75574f,99.99998f,-48.429863f,100.0f,-1.880765f,-0.7719378f,0.6185509f,-0.1466521f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,74.91292f,53.537663f,99.97044f,-100.0f,-8.715799f,-1.237583f,-0.0013330131f,0.56015587f,0.8283861f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,83.1941f,-99.993996f,-0.80495834f,99.99372f,83.889885f,-100.0f,-0.82671154f,-0.51088834f,-0.2356718f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-83.37558f,-46.891006f,99.90646f,-29.455296f,-36.640274f,-100.0f,-0.23988798f,0.8649197f,0.4408714f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,8.459294f,-95.69456f,73.33428f,-46.85637f,-22.177843f,-44.10552f,-0.10497787f,0.33734226f,0.93551046f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,90.330154f,-99.2061f,-39.91809f,-100.0f,34.542088f,-54.996944f,0.012358569f,-0.93400365f,0.3570497f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-96.975914f,68.62261f,-60.612465f,75.497314f,-35.89335f,-6.09354f,0.094162695f,0.12249944f,-0.9879915f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,99.975624f,-100.0f,-22.776161f,100.0f,22.702942f,-6.160166f,-2.0563917f,0.20953017f,0.7024111f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-102.33719f,-27.673481f,60.157215f,100.0f,-175.37054f,32.00422f,92.54016f,1.0005229f,-0.012647539f,0.03402153f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,10.740095f,43.14164f,49.331886f,-94.11958f,-100.0f,-27.090765f,23.073593f,-0.2701801f,-0.9589576f,0.08604703f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1.1145762f,-74.33923f,42.82203f,84.75888f,80.99482f,-64.08122f,11.098979f,-0.67747676f,-0.4311317f,0.5959452f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,116.3526f,55.53307f,-183.84715f,95.21173f,76.06825f,59.531925f,-100.0f,0.39752784f,0.5605141f,-0.72623557f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-11.747188f,99.99097f,100.0f,-56.519794f,100.0f,96.23918f,-76.004364f,13.721256f,8.878308f,3.1761224f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-11.747925f,-2.3147829f,-40.675003f,90.921776f,73.42528f,-30.152956f,-25.269455f,-0.01674557f,0.3118605f,0.24923882f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1.2794592f,19.734453f,4.167709f,55.46598f,12.073293f,71.48977f,-12.605934f,0.2959277f,-1.8030971f,-0.82719857f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-14.986832f,-99.99996f,99.19327f,100.0f,-99.81091f,-99.99999f,46.231003f,0.98480433f,0.007559468f,-0.1735031f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-15.181895f,-52.666344f,-9.661789f,-4.505695f,-19.751001f,-48.48633f,-6.3562083f,-0.922182f,0.19947132f,0.0095796995f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,15.512455f,-96.70804f,36.479115f,98.08358f,-42.78757f,-17.851614f,38.256687f,-0.17277984f,-0.23208873f,0.7185452f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,16.764744f,-71.70965f,100.0f,100.0f,100.0f,-100.0f,52.33924f,-0.116598345f,-0.5129573f,0.8504585f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-17.303246f,3.9814441f,28.31875f,61.38101f,-47.04689f,-48.579727f,17.352112f,0.35182118f,0.70132524f,0.29442197f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,18.921192f,-39.981857f,100.0f,61.87558f,20.86388f,-94.03152f,69.9426f,0.33557183f,0.9402091f,0.058295675f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,19.208735f,-41.071537f,99.54439f,100.0f,100.0f,-100.0f,100.0f,-0.008366113f,0.9647195f,0.26314712f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-20.037182f,-92.53053f,5.711811f,98.86555f,76.29155f,-85.47153f,-15.391341f,-0.74681866f,-0.27081278f,0.23617613f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-20.04538f,-72.9864f,-56.348293f,93.062096f,-69.72748f,-48.385365f,18.398153f,-0.07410083f,-0.28540167f,-0.16179238f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,22.166233f,-33.616154f,19.197567f,99.99995f,99.678246f,-60.94182f,-37.768967f,-0.47276488f,0.69220203f,0.5452978f ) ;
  }

  @Test
  public void test49() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-22.651451f,30.554926f,2.3014948f,66.52014f,-35.927624f,-17.421162f,46.425953f,-0.2976823f,0.3188902f,0.19845136f ) ;
  }

  @Test
  public void test50() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,24.066586f,-99.999954f,4.2458463f,74.80898f,57.560436f,-34.137245f,-7.4438615f,-0.025909185f,-0.9877757f,0.15371361f ) ;
  }

  @Test
  public void test51() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,24.306087f,9.197838f,57.225655f,100.0f,17.553118f,-90.37333f,50.902714f,-0.20588455f,0.8813063f,-0.4253361f ) ;
  }

  @Test
  public void test52() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-24.4525f,98.365585f,-97.378815f,86.94269f,-23.825516f,-13.350033f,-95.36722f,0.6375168f,0.63955104f,0.42958903f ) ;
  }

  @Test
  public void test53() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-25.264996f,-19.522282f,49.810287f,99.637436f,-76.60526f,-98.55779f,82.13956f,0.71565837f,-0.1876981f,-0.6727574f ) ;
  }

  @Test
  public void test54() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-26.676533f,-36.659767f,41.402287f,72.20609f,-92.41589f,-12.714907f,23.55012f,0.57213336f,0.7475414f,-0.02611965f ) ;
  }

  @Test
  public void test55() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,28.564016f,75.68025f,-100.0f,100.0f,83.430244f,100.0f,-20.010958f,-0.013242026f,-0.09518263f,-0.99537176f ) ;
  }

  @Test
  public void test56() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-29.590689f,-9.90244f,92.65576f,39.400127f,-68.21803f,-7.3804426f,99.99999f,0.6607559f,0.1393308f,-0.29379964f ) ;
  }

  @Test
  public void test57() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-31.097542f,34.713387f,-100.0f,69.24654f,-100.0f,41.607903f,-100.0f,0.59351677f,0.3641299f,-0.0027518172f ) ;
  }

  @Test
  public void test58() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-31.332626f,-33.049286f,-99.50946f,97.68721f,-99.99995f,-99.8887f,-0.5709309f,0.75834346f,-0.22946416f,-0.6101323f ) ;
  }

  @Test
  public void test59() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-35.993004f,-9.601298f,-82.66309f,36.791332f,-29.234056f,-44.551052f,-73.36613f,0.22133265f,0.515982f,0.13172367f ) ;
  }

  @Test
  public void test60() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-36.058067f,26.974094f,55.545f,76.155426f,39.948174f,28.386215f,50.99459f,-0.5040694f,0.5264494f,-0.6846642f ) ;
  }

  @Test
  public void test61() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,36.14093f,-17.451134f,-34.22399f,80.491684f,87.54477f,-16.694891f,-100.0f,-0.99047637f,0.08040285f,0.045140058f ) ;
  }

  @Test
  public void test62() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,3.7318935f,-123.928116f,90.93915f,74.75921f,59.25018f,-100.0f,134.86787f,-0.011579821f,0.7593785f,-0.6505456f ) ;
  }

  @Test
  public void test63() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,38.858547f,43.38587f,33.855423f,83.59462f,4.014467f,13.842345f,-36.152657f,0.283039f,-0.04783774f,0.1420607f ) ;
  }

  @Test
  public void test64() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-38.981598f,11.580299f,70.10024f,99.95086f,-83.31067f,99.99116f,-11.555723f,0.8087458f,-0.5819907f,-0.08495305f ) ;
  }

  @Test
  public void test65() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,39.304855f,-25.985094f,28.847858f,56.82886f,34.14702f,-63.81476f,70.941f,0.13673644f,0.5011837f,0.1931873f ) ;
  }

  @Test
  public void test66() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,39.35351f,100.0f,-100.0f,98.06586f,-56.387085f,78.77147f,-100.0f,0.94137806f,-0.15433587f,-0.29997963f ) ;
  }

  @Test
  public void test67() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,40.118305f,99.76336f,-92.34632f,59.3913f,100.0f,100.0f,-89.06968f,0.0843761f,0.10960463f,0.99038756f ) ;
  }

  @Test
  public void test68() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-40.21204f,11.775432f,42.03024f,95.23605f,-99.89545f,58.114437f,100.0f,0.3760835f,-0.92582196f,-0.03761454f ) ;
  }

  @Test
  public void test69() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,40.7225f,14.416549f,57.73699f,15.01593f,32.80768f,15.735212f,45.044674f,-0.19093746f,-0.5643752f,0.10660384f ) ;
  }

  @Test
  public void test70() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-46.64866f,98.84884f,32.11358f,99.98722f,100.0f,32.11357f,99.99774f,0.45216247f,-0.83408034f,0.31600496f ) ;
  }

  @Test
  public void test71() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-48.773075f,-3.3882587f,19.268005f,63.082718f,-87.50472f,38.22945f,-8.067958f,0.1029922f,-1.2040671f,0.53211486f ) ;
  }

  @Test
  public void test72() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,51.17136f,91.89989f,24.204447f,70.88693f,-13.169604f,70.11938f,44.47235f,0.3508308f,1.1328229f,-1.0197688f ) ;
  }

  @Test
  public void test73() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,51.989334f,-77.757515f,-27.389797f,63.579773f,-100.0f,-85.14391f,65.764175f,0.31943372f,0.069645375f,0.6509125f ) ;
  }

  @Test
  public void test74() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-53.74972f,99.63199f,1.6055148f,87.718216f,16.088465f,99.99998f,-52.372932f,-0.7966203f,-0.5581182f,0.23215216f ) ;
  }

  @Test
  public void test75() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-55.428146f,-100.0f,-74.47612f,-100.0f,51.250023f,47.822388f,100.0f,0.23288794f,0.43091676f,1.1689551f ) ;
  }

  @Test
  public void test76() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,60.393555f,-14.015895f,11.553287f,91.98707f,16.666838f,-67.13082f,72.61391f,0.32504192f,0.35228002f,-0.8776369f ) ;
  }

  @Test
  public void test77() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,60.88204f,32.97084f,-71.0432f,89.52651f,-16.842945f,-10.511932f,-61.928837f,0.40589553f,0.88365823f,-0.23323165f ) ;
  }

  @Test
  public void test78() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-6.1361103f,-63.49009f,81.304405f,45.846718f,15.835955f,-99.32306f,62.997356f,-0.024450915f,0.27838883f,-0.25718105f ) ;
  }

  @Test
  public void test79() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,61.62487f,-98.789764f,88.561264f,-100.0f,3.4820623f,-99.87576f,-100.0f,-0.6008673f,-0.06566487f,-0.79664713f ) ;
  }

  @Test
  public void test80() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-63.30016f,49.940666f,100.0f,53.822098f,-82.20389f,54.435863f,49.807766f,0.37411654f,-0.34822056f,0.83104765f ) ;
  }

  @Test
  public void test81() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-63.466286f,-32.690792f,-54.075397f,19.896664f,-73.44728f,-34.311302f,-71.21106f,0.19546056f,0.61493695f,0.74859744f ) ;
  }

  @Test
  public void test82() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,67.29211f,100.0f,100.0f,19.536085f,98.93233f,-100.0f,100.0f,-0.23026596f,-0.923667f,-0.3062953f ) ;
  }

  @Test
  public void test83() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,68.05418f,-17.163582f,100.0f,-99.936424f,98.877075f,99.98131f,22.95574f,0.7498254f,0.6608153f,-0.032939006f ) ;
  }

  @Test
  public void test84() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,68.59535f,-19.275259f,-67.66823f,15.407661f,-100.0f,100.0f,-93.63983f,-1.1210032f,-3.8108974f,-5.97036f ) ;
  }

  @Test
  public void test85() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-69.050064f,65.40559f,22.205023f,82.034584f,-26.010088f,23.020594f,77.70948f,-0.87259555f,0.48052734f,-0.08758164f ) ;
  }

  @Test
  public void test86() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,70.513016f,-93.11759f,-20.828627f,6.3492227f,100.0f,100.0f,82.36683f,-0.7986005f,0.60093343f,0.033410694f ) ;
  }

  @Test
  public void test87() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,71.42276f,-14.695879f,71.87087f,52.499702f,100.0f,-11.478244f,92.2071f,0.5588178f,-0.2880255f,0.753753f ) ;
  }

  @Test
  public void test88() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,7.1570015f,-17.838354f,-21.783558f,100.0f,75.51924f,-52.880337f,-85.80436f,0.007936081f,-0.6821302f,0.73118764f ) ;
  }

  @Test
  public void test89() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,73.21358f,-29.900402f,-76.5006f,100.0f,157.03085f,23.716389f,-66.584274f,-0.750314f,-0.53033674f,0.39467588f ) ;
  }

  @Test
  public void test90() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-73.99637f,-36.170216f,-66.444405f,22.13793f,-61.326042f,-41.171562f,-83.8954f,0.4319684f,-0.20509401f,0.70907164f ) ;
  }

  @Test
  public void test91() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,74.49784f,-96.32805f,4.834716f,100.0f,38.5295f,-45.540966f,83.10956f,0.9296891f,0.18946953f,-0.31587884f ) ;
  }

  @Test
  public void test92() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,75.67633f,-100.0f,100.0f,99.93635f,100.0f,-98.90593f,3.0751038f,0.47112387f,-0.8182673f,0.32936442f ) ;
  }

  @Test
  public void test93() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-75.94734f,95.257225f,63.960392f,99.392746f,19.793139f,73.06557f,78.79983f,-0.23015164f,-0.10690687f,-0.9672648f ) ;
  }

  @Test
  public void test94() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-78.295906f,-46.902298f,99.820496f,100.0f,-85.214554f,-67.493675f,2.208364f,-0.016093545f,0.206677f,0.97827685f ) ;
  }

  @Test
  public void test95() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-79.66712f,96.354965f,26.502373f,60.658226f,-55.469795f,100.0f,-29.00099f,0.3407692f,-0.43255693f,0.834728f ) ;
  }

  @Test
  public void test96() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,81.93682f,-3.350447f,-99.520676f,100.0f,98.08702f,6.6236167f,100.0f,-0.66618145f,-0.60149276f,-0.4409181f ) ;
  }

  @Test
  public void test97() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-82.19473f,16.099821f,-0.14794455f,100.0f,-100.0f,74.588005f,-100.0f,0.40122497f,0.27950835f,0.7038534f ) ;
  }

  @Test
  public void test98() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-85.70005f,70.278366f,-50.49468f,-24.18324f,-51.98257f,75.50629f,-47.987865f,0.60184336f,0.7929575f,-0.09488587f ) ;
  }

  @Test
  public void test99() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,86.349304f,29.180286f,9.11778f,-100.0f,25.883125f,-16.078516f,-100.0f,0.04254108f,-0.15048262f,-0.98769695f ) ;
  }

  @Test
  public void test100() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,87.435196f,99.9404f,-66.44771f,59.087116f,100.0f,43.785294f,-79.86476f,0.23003738f,0.30639195f,-0.14857641f ) ;
  }

  @Test
  public void test101() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-88.41008f,-59.55468f,-100.0f,-13.624028f,-46.605484f,65.736176f,-95.31456f,0.8142709f,1.9839301f,-0.09178989f ) ;
  }

  @Test
  public void test102() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-89.61949f,-59.74632f,-45.029922f,64.70181f,-29.083776f,-37.279583f,-40.907135f,-0.14886124f,-0.8991374f,-0.41157302f ) ;
  }

  @Test
  public void test103() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-90.43183f,60.41716f,59.751064f,-82.34505f,-100.0f,89.67366f,-99.90321f,2.4688783f,-1.3174547f,-7.051351f ) ;
  }

  @Test
  public void test104() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,92.20075f,97.89808f,-48.91303f,99.95666f,42.505108f,14.584302f,-73.006386f,0.22497289f,-0.14485058f,0.89503103f ) ;
  }

  @Test
  public void test105() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,94.99235f,100.0f,99.52894f,86.746315f,87.1328f,81.14292f,15.222581f,0.726705f,0.68677f,0.015711166f ) ;
  }

  @Test
  public void test106() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,95.131386f,100.0f,-24.434912f,100.0f,100.0f,-5.3921256f,-100.0f,-0.19432428f,0.2621115f,0.9452701f ) ;
  }

  @Test
  public void test107() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,97.116135f,100.0f,-55.529465f,-100.0f,100.0f,-100.0f,55.976818f,0.21403334f,-0.008401371f,0.042328194f ) ;
  }

  @Test
  public void test108() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-98.86742f,1.1504784f,-95.60176f,-73.64678f,101.61184f,100.0f,-100.0f,0.7661517f,0.5180239f,0.11073985f ) ;
  }

  @Test
  public void test109() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.22081f,-98.65852f,-14.364953f,72.31033f,-100.0f,50.44795f,-17.366592f,0.48025703f,0.8768509f,-0.022038028f ) ;
  }

  @Test
  public void test110() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.94861f,-75.495995f,-100.0f,-100.0f,6.8319535f,99.58161f,-99.999794f,3.7856395f,0.4279138f,2.9059308f ) ;
  }

  @Test
  public void test111() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,99.95f,100.0f,100.0f,22.400635f,100.0f,77.59942f,100.0f,0.20341909f,0.95652974f,0.20897745f ) ;
  }

  @Test
  public void test112() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.98008f,100.0f,-44.349083f,100.0f,-54.46753f,-56.062042f,-5.1144238f,-0.03203388f,-0.7999723f,0.27364233f ) ;
  }

  @Test
  public void test113() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,99.99972f,-99.537056f,100.0f,32.474174f,73.77977f,-93.87986f,80.494484f,-0.611427f,-0.7474568f,0.259741f ) ;
  }

  @Test
  public void test114() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.99992f,-100.0f,100.0f,100.0f,-29.13735f,-100.0f,29.441544f,-0.4951551f,-0.0696311f,-0.26131475f ) ;
  }

  @Test
  public void test115() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.999985f,93.65992f,-99.99992f,100.0f,-100.0f,-6.347168f,-100.0f,0.15853111f,0.9842409f,-0.07834399f ) ;
  }
}
