import org.junit.Test;

public class JpfTargetSurfaceShadeTest {

  @Test
  public void test0() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,100.0f,14.709859f,0f,0f,0f,1,0.8191567f,0.45127538f,0.06587721f,0f,0f,0f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,-69.29115f,-100.0f,18.717915f,0f,0f,0f,2,0.1369155f,-0.04978908f,-2.51058f,0f,0f,0f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.01938189f,0f,0f,0f,0f,0f,-2.3718789f,-3.0574853f,2.0744638f,-142.0f,59.0f,-75.0f,1,-0.14341079f,0.1885796f,0.23983611f,0f,0f,0f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,54.206112f,100.0f,0f,0f,0f,1,0.7129181f,-0.56160086f,0.23716512f,0f,0f,0f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,16.669607f,16.871428f,52.903934f,0f,0f,0f,-1,1.830102f,-0.21042255f,-0.2801379f,0f,0f,0f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.0010219545f,-9.6210344E-5f,2.7274858E-4f,0f,0f,0f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.012366672f,0.018450666f,9.929449E-4f,0f,0f,0f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.037172757f,0.27908084f,0.08241292f,0f,0f,0f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.063488804f,-0.06920923f,-0.38514656f,0f,0f,0f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.07820497f,0.30612555f,0.36988953f,0f,0f,0f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.084076054f,-0.17450549f,-0.9462314f,0f,0f,0f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.17102757f,0.8307474f,-0.34412915f,0f,0f,0f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.2146744f,0.8444157f,-0.43445393f,0f,0f,0f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.2704148f,0.6233766f,-0.008095161f,0f,0f,0f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.28045672f,0.5962204f,0.6871383f,0f,0f,0f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.28341275f,-0.32921937f,-0.16616908f,0f,0f,0f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.3260447f,-0.03693467f,0.1146538f,0f,0f,0f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.34288552f,0.55129915f,0.14792341f,0f,0f,0f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.3833721f,-0.1778962f,-0.10783728f,0f,0f,0f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.3894421f,0.2644626f,-0.25020477f,0f,0f,0f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.40648878f,-0.83667916f,-0.28013667f,0f,0f,0f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.42654827f,-0.028290763f,-0.5941219f,0f,0f,0f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.4558575f,0.80441165f,0.12938048f,0f,0f,0f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.5074387f,-0.4598002f,-0.23768817f,0f,0f,0f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.5544941f,0.78898245f,0.076627105f,0f,0f,0f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.56991214f,0.6153781f,0.5445273f,0f,0f,0f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.612559f,-0.2897691f,-0.17402472f,0f,0f,0f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.663681f,-0.6042703f,-0.08531296f,0f,0f,0f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.7039262f,0.37041536f,0.18151067f,0f,0f,0f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.82078475f,-0.40164933f,-0.19649152f,0f,0f,0f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.9254252f,-0.018334135f,0.060058612f,0f,0f,0f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,2.2208143E-8f,9.230596E-13f,-4.9503884E-10f,0f,0f,0f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,3.697255E-9f,3.2060496E-10f,-5.5949796E-9f,0f,0f,0f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,3.9769384E-13f,-4.0109455E-13f,-5.540953E-12f,0f,0f,0f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-4.097603E-6f,-2.6346388E-6f,-0.0016120587f,0f,0f,0f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-62.386925f,-49.25261f,36.915554f,0f,0f,0f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,86.12645f,-6.1231775f,39.227013f,0f,0f,0f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,9.167029E-10f,-8.071824E-9f,-5.9522716E-9f,0f,0f,0f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0.1657933f,0.017210444f,-0.16101079f,0f,0f,0f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,-0.29059595f,-0.2692042f,-0.0742225f,0f,0f,0f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,1.8737525E-8f,5.5363248E-8f,-1.987294E-5f,0f,0f,0f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-239,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,744,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,-98.09981f,0f,0f,0f,1,-0.66941583f,0.31266195f,-0.53823954f,0f,0f,0f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-18.428215f,52.45971f,0f,0f,0f,1,7.599237f,-6.1809688f,12.314584f,0f,0f,0f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,47.843674f,88.56645f,100.0f,0f,0f,0f,1,-19.687593f,12.736335f,-1.8608521f,0f,0f,0f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,61.41321f,39.577503f,1.3901322f,0f,0f,0f,1,-8.353624f,12.998284f,-1.0191232f,0f,0f,0f ) ;
  }

  @Test
  public void test49() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-68.06949f,-89.92093f,-48.85927f,0f,0f,0f,1,17.306906f,-18.993437f,10.844113f,0f,0f,0f ) ;
  }

  @Test
  public void test50() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,92.778656f,-9.881384f,49.28008f,0f,0f,0f,1,-1.5922976f,-1.5890148f,2.679167f,0f,0f,0f ) ;
  }

  @Test
  public void test51() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-95.94021f,-100.0f,24.050497f,0f,0f,0f,1,-0.024299508f,0.25454494f,0.062023766f,0f,0f,0f ) ;
  }

  @Test
  public void test52() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-10.278992f,-17.762302f,46.449955f,-2033.0f,86.0f,-417.0f,1,-0.062842965f,0.28098208f,0.7641089f,0f,0f,0f ) ;
  }

  @Test
  public void test53() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,23.05727f,-55.04509f,65.88581f,-204.0f,-995.0f,-759.0f,-8,36.11769f,12.077834f,11.682036f,0f,0f,0f ) ;
  }

  @Test
  public void test54() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-35.842625f,-55.30933f,22.998194f,49.0f,-843.0f,-1951.0f,1,0.2809795f,-1.0501354f,-0.18663312f,0f,0f,0f ) ;
  }

  @Test
  public void test55() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-4.6231203f,5.0932083f,13.565589f,-247.0f,162.0f,-145.0f,1,0.0249665f,-0.56137216f,0.82659835f,0f,0f,0f ) ;
  }

  @Test
  public void test56() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-58.643528f,-100.0f,-35.722588f,0f,0f,0f,2,0.15348616f,-0.36747578f,0.5487047f,0f,0f,0f ) ;
  }

  @Test
  public void test57() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,82.55426f,55.702557f,-12.812682f,90.0f,1010.0f,-1873.0f,-1,-0.49107343f,1.720818f,1.1522652f,0f,0f,0f ) ;
  }

  @Test
  public void test58() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,82.56054f,100.0f,100.0f,454.0f,765.0f,-1065.0f,3,2.870847f,0.18120079f,-1.0043471f,0f,0f,0f ) ;
  }

  @Test
  public void test59() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,95.18983f,-53.01753f,-75.69468f,947.0f,35.0f,-938.0f,-1,0.6038025f,0.875332f,0.12222923f,0f,0f,0f ) ;
  }

  @Test
  public void test60() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,112.47535f,0f,0f,0f,0f,0f,-100.0f,-125.85245f,-49.51294f,217.0f,-979.0f,-552.0f,1,-0.050550975f,0.15954548f,-0.5859133f,0f,0f,0f ) ;
  }

  @Test
  public void test61() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-12.110415f,0f,0f,0f,0f,0f,63.99525f,-88.557106f,100.0f,0f,0f,0f,1,0.85427403f,0.013228128f,-0.4596783f,0f,0f,0f ) ;
  }

  @Test
  public void test62() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,12.328588f,0f,0f,0f,0f,0f,-44.476677f,-67.776764f,-33.345432f,286.0f,-698.0f,1033.0f,1,-1.9686413f,0.84555435f,0.040834073f,0f,0f,0f ) ;
  }

  @Test
  public void test63() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,149.50279f,0f,0f,0f,0f,0f,66.581955f,100.0f,-29.551931f,1423.0f,-442.0f,-496.0f,1,-0.076674774f,2.506508f,1.1557459f,0f,0f,0f ) ;
  }

  @Test
  public void test64() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,15.468717f,0f,0f,0f,0f,0f,-55.941654f,98.07137f,-70.22871f,925.0f,-119.0f,-903.0f,1,-0.11520804f,0.6970592f,-0.7071648f,0f,0f,0f ) ;
  }

  @Test
  public void test65() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,16.588215f,0f,0f,0f,0f,0f,-45.51916f,41.344242f,42.765503f,-1322.0f,-568.0f,-858.0f,6,-0.07960066f,0.5847701f,0.43442613f,0f,0f,0f ) ;
  }

  @Test
  public void test66() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,18.604963f,0f,0f,0f,0f,0f,37.312412f,0.9120831f,21.745998f,-148.0f,-182.0f,262.0f,6,0.21326913f,-0.38481683f,-0.30855462f,0f,0f,0f ) ;
  }

  @Test
  public void test67() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,22.937073f,0f,0f,0f,0f,0f,37.263405f,100.0f,-82.95334f,1661.0f,292.0f,522.0f,1,-0.53075325f,0.018467143f,-0.3425042f,0f,0f,0f ) ;
  }

  @Test
  public void test68() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,247.11258f,0f,0f,0f,0f,0f,-117.67086f,56.286793f,-3.3178613f,-863.0f,228.0f,1509.0f,2,-2.2791533f,-0.32370418f,-5.3429837f,0f,0f,0f ) ;
  }

  @Test
  public void test69() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,247.32367f,0f,0f,0f,0f,0f,-208.6869f,119.383156f,99.38971f,-1089.0f,-935.0f,-828.0f,-1,-4.4849505f,-1.1592239f,-3.2981145f,0f,0f,0f ) ;
  }

  @Test
  public void test70() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,24.95062f,0f,0f,0f,0f,0f,23.181665f,1.3399377f,66.90617f,-934.0f,1276.0f,1137.0f,2,0.78351533f,-0.13938008f,0.53475136f,0f,0f,0f ) ;
  }

  @Test
  public void test71() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,252.02124f,0f,0f,0f,0f,0f,-167.90825f,-272.72775f,-90.56625f,-947.0f,-820.0f,-1988.0f,-4,-7.002058f,3.7048736f,1.0436825f,0f,0f,0f ) ;
  }

  @Test
  public void test72() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,252.1942f,0f,0f,0f,0f,0f,-44.907f,219.08157f,99.85849f,-254.0f,679.0f,303.0f,-1,0.7267617f,-1.7471077f,4.2951703f,0f,0f,0f ) ;
  }

  @Test
  public void test73() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.7506f,0f,0f,0f,0f,0f,-101.523705f,-85.99093f,77.565254f,-1925.0f,1418.0f,231.0f,1,-1.3981743f,1.2749286f,0.2217157f,0f,0f,0f ) ;
  }

  @Test
  public void test74() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.80971f,0f,0f,0f,0f,0f,334.33658f,-16.422422f,182.0896f,269.0f,-5.0f,982.0f,1,10.752815f,0.39033875f,-5.4439526f,0f,0f,0f ) ;
  }

  @Test
  public void test75() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.94241f,0f,0f,0f,0f,0f,-87.888596f,-58.243484f,-66.821144f,1320.0f,-592.0f,-2207.0f,11,0.25404656f,-1.4010313f,-3.4069936f,0f,0f,0f ) ;
  }

  @Test
  public void test76() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.16487f,0f,0f,0f,0f,0f,-99.765465f,-3.2689154f,-74.23418f,-1936.0f,-67.0f,-465.0f,1,-0.9567508f,0.12083686f,-0.20362894f,0f,0f,0f ) ;
  }

  @Test
  public void test77() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.32321f,0f,0f,0f,0f,0f,-17.429377f,50.071503f,-91.836975f,-1615.0f,2035.0f,-2628.0f,1,0.03579996f,0.34838653f,-0.8281335f,0f,0f,0f ) ;
  }

  @Test
  public void test78() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.3437f,0f,0f,0f,0f,0f,108.317314f,42.89014f,194.10672f,104.0f,-679.0f,664.0f,3,-0.5849787f,3.7481859f,4.140179f,0f,0f,0f ) ;
  }

  @Test
  public void test79() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.43616f,0f,0f,0f,0f,0f,-73.56614f,12.824298f,160.40353f,-419.0f,116.0f,1168.0f,1,-0.60111845f,-0.15426318f,0.6665207f,0f,0f,0f ) ;
  }

  @Test
  public void test80() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.49942f,0f,0f,0f,0f,0f,-93.44668f,-64.7377f,162.19078f,155.0f,-1746.0f,496.0f,1,0.20940076f,0.050953805f,4.3918395f,0f,0f,0f ) ;
  }

  @Test
  public void test81() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.59897f,0f,0f,0f,0f,0f,-93.54944f,89.05717f,-82.55898f,-1783.0f,652.0f,651.0f,1,-0.17677313f,2.2634969f,-0.038382817f,0f,0f,0f ) ;
  }

  @Test
  public void test82() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.70335f,0f,0f,0f,0f,0f,-28.739176f,-81.59509f,242.6593f,-1417.0f,365.0f,2367.0f,1,-0.12713918f,-0.41410843f,0.24010198f,0f,0f,0f ) ;
  }

  @Test
  public void test83() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.71396f,0f,0f,0f,0f,0f,101.5028f,150.26471f,69.51581f,861.0f,176.0f,-1137.0f,-1,-0.43385148f,0.60104764f,0.5487421f,0f,0f,0f ) ;
  }

  @Test
  public void test84() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.76633f,0f,0f,0f,0f,0f,-51.130054f,-87.34605f,-97.80623f,-514.0f,1103.0f,-2980.0f,1,-0.18086183f,-0.4765092f,0.18187258f,0f,0f,0f ) ;
  }

  @Test
  public void test85() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.7699f,0f,0f,0f,0f,0f,-47.066074f,-243.6911f,152.22299f,-808.0f,-2528.0f,1262.0f,1,0.1489811f,-0.32620335f,0.309612f,0f,0f,0f ) ;
  }

  @Test
  public void test86() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.83699f,0f,0f,0f,0f,0f,-3.611648f,46.444546f,-196.97531f,-2028.0f,388.0f,-734.0f,1,0.6372996f,0.52489924f,-1.0826948f,0f,0f,0f ) ;
  }

  @Test
  public void test87() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.84427f,0f,0f,0f,0f,0f,-85.58988f,81.0592f,-61.93751f,-357.0f,1508.0f,1075.0f,1,0.44325382f,0.64367867f,-0.57211155f,0f,0f,0f ) ;
  }

  @Test
  public void test88() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.87642f,0f,0f,0f,0f,0f,102.20468f,-158.5363f,-64.47607f,-780.0f,-658.0f,-695.0f,1,0.1193564f,-0.29122436f,-0.3358924f,0f,0f,0f ) ;
  }

  @Test
  public void test89() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.90929f,0f,0f,0f,0f,0f,-199.9786f,-119.09498f,-21.419779f,-729.0f,-2345.0f,-2612.0f,1,-0.18481544f,0.1304822f,0.09224303f,0f,0f,0f ) ;
  }

  @Test
  public void test90() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.9505f,0f,0f,0f,0f,0f,-53.62053f,157.19952f,87.62391f,301.0f,998.0f,70.0f,1,0.044018894f,0.15684809f,0.09678755f,0f,0f,0f ) ;
  }

  @Test
  public void test91() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.95206f,0f,0f,0f,0f,0f,22.439695f,44.457783f,-120.012764f,533.0f,1422.0f,-289.0f,1,-0.19168167f,0.015323991f,-0.36206278f,0f,0f,0f ) ;
  }

  @Test
  public void test92() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.96878f,0f,0f,0f,0f,0f,-5.288618f,126.951904f,75.70741f,-121.0f,1367.0f,-615.0f,1,0.18251748f,-0.04053739f,0.7518873f,0f,0f,0f ) ;
  }

  @Test
  public void test93() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.97104f,0f,0f,0f,0f,0f,32.929394f,193.33769f,162.54512f,50.0f,35.0f,1228.0f,1,0.38049543f,0.85000396f,-0.17704813f,0f,0f,0f ) ;
  }

  @Test
  public void test94() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.97697f,0f,0f,0f,0f,0f,-100.0f,62.386734f,93.715096f,-672.0f,-459.0f,309.0f,1,0.4876808f,-0.11620178f,0.7462353f,0f,0f,0f ) ;
  }

  @Test
  public void test95() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.97787f,0f,0f,0f,0f,0f,24.995426f,188.7706f,33.606167f,-131.0f,432.0f,1260.0f,1,0.79002655f,-0.13817348f,0.24470158f,0f,0f,0f ) ;
  }

  @Test
  public void test96() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.98132f,0f,0f,0f,0f,0f,98.18707f,-371.4753f,-165.84883f,-1555.0f,-2187.0f,609.0f,1,0.6810238f,-3.24123E-4f,-0.45136452f,0f,0f,0f ) ;
  }

  @Test
  public void test97() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.99529f,0f,0f,0f,0f,0f,-42.009224f,-86.33185f,83.16813f,-142.0f,-1140.0f,42.0f,1,0.47436184f,-0.6427705f,0.29329762f,0f,0f,0f ) ;
  }

  @Test
  public void test98() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.99936f,0f,0f,0f,0f,0f,-54.187775f,58.03509f,-57.21138f,-1047.0f,465.0f,-1248.0f,1,0.3672717f,0.11038943f,-0.37844583f,0f,0f,0f ) ;
  }

  @Test
  public void test99() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.99997f,0f,0f,0f,0f,0f,-72.99837f,-111.18533f,56.041763f,-1455.0f,-1629.0f,-808.0f,1,-0.011198244f,-0.8382998f,0.057139385f,0f,0f,0f ) ;
  }

  @Test
  public void test100() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.0002f,0f,0f,0f,0f,0f,-70.43534f,-71.45813f,-18.78439f,-1475.0f,-22.0f,2527.0f,1,0.07572615f,-0.39781433f,-0.0184658f,0f,0f,0f ) ;
  }

  @Test
  public void test101() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.00058f,0f,0f,0f,0f,0f,43.373226f,131.41335f,257.38055f,-251.0f,1380.0f,1517.0f,1,-0.1881935f,0.9709641f,-0.046306957f,0f,0f,0f ) ;
  }

  @Test
  public void test102() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.0006f,0f,0f,0f,0f,0f,-60.18144f,238.77188f,0.49546427f,-231.0f,4920.0f,-320.0f,1,-0.0069944113f,0.66478205f,-0.02520608f,0f,0f,0f ) ;
  }

  @Test
  public void test103() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.00098f,0f,0f,0f,0f,0f,33.056164f,64.250565f,-11.275869f,999.0f,1955.0f,-454.0f,1,0.4859287f,0.6487992f,0.35496914f,0f,0f,0f ) ;
  }

  @Test
  public void test104() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.00357f,0f,0f,0f,0f,0f,174.43561f,12.00558f,-160.63763f,974.0f,-949.0f,314.0f,1,0.008485562f,0.02002224f,-0.49891838f,0f,0f,0f ) ;
  }

  @Test
  public void test105() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.01268f,0f,0f,0f,0f,0f,-218.31058f,-125.13781f,96.08967f,-1706.0f,-961.0f,-471.0f,1,-0.53263474f,0.07931042f,0.2366588f,0f,0f,0f ) ;
  }

  @Test
  public void test106() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.08551f,0f,0f,0f,0f,0f,147.64503f,116.40659f,68.99302f,1374.0f,-564.0f,-609.0f,1,-0.124936834f,0.28134498f,0.48833916f,0f,0f,0f ) ;
  }

  @Test
  public void test107() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.09416f,0f,0f,0f,0f,0f,44.09716f,-25.15668f,50.24583f,871.0f,-34.0f,1482.0f,1,-0.07306388f,0.09436022f,0.8985058f,0f,0f,0f ) ;
  }

  @Test
  public void test108() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.17955f,0f,0f,0f,0f,0f,-64.573875f,-49.732567f,27.46893f,-1433.0f,-716.0f,-690.0f,1,1.5292605f,2.062815f,11.254232f,0f,0f,0f ) ;
  }

  @Test
  public void test109() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.33476f,0f,0f,0f,0f,0f,-114.94347f,-15.111214f,24.53581f,-1389.0f,890.0f,-637.0f,1,0.14958763f,0.11396489f,2.2508276f,0f,0f,0f ) ;
  }

  @Test
  public void test110() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.34427f,0f,0f,0f,0f,0f,80.44881f,-35.592213f,-112.45252f,-598.0f,3748.0f,-2289.0f,-4,0.7231367f,-0.97729075f,-1.2310418f,0f,0f,0f ) ;
  }

  @Test
  public void test111() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.35138f,0f,0f,0f,0f,0f,-89.101944f,18.490261f,-12.152143f,-2887.0f,-142.0f,-238.0f,1,-7.3139763f,-4.5207705f,-1.3215045f,0f,0f,0f ) ;
  }

  @Test
  public void test112() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,256.35257f,0f,0f,0f,0f,0f,143.07256f,23.294954f,138.84125f,93.0f,829.0f,990.0f,2,1.1486841f,-6.154285f,2.0163224f,0f,0f,0f ) ;
  }

  @Test
  public void test113() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,256.9611f,0f,0f,0f,0f,0f,100.28554f,122.63896f,115.02128f,519.0f,271.0f,-6.0f,4,-0.098710105f,8.058587f,-3.2916074f,0f,0f,0f ) ;
  }

  @Test
  public void test114() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,257.13715f,0f,0f,0f,0f,0f,85.10334f,60.367294f,51.696053f,-254.0f,559.0f,901.0f,2,-0.44042864f,0.311563f,2.5115469f,0f,0f,0f ) ;
  }

  @Test
  public void test115() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,26.015331f,0f,0f,0f,0f,0f,69.857216f,-15.857516f,-26.653852f,-36.0f,307.0f,-277.0f,10,2.394643f,-5.791076f,-0.1142866f,0f,0f,0f ) ;
  }

  @Test
  public void test116() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,26.367735f,0f,0f,0f,0f,0f,-108.75286f,31.986906f,-32.76403f,1946.0f,408.0f,-825.0f,1,-0.8404607f,0.5071816f,0.17828345f,0f,0f,0f ) ;
  }

  @Test
  public void test117() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,26.921656f,0f,0f,0f,0f,0f,5.1660843f,31.848785f,13.14582f,1079.0f,2656.0f,-373.0f,1,-0.1788195f,0.74003255f,0.5968504f,0f,0f,0f ) ;
  }

  @Test
  public void test118() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,278.44424f,0f,0f,0f,0f,0f,-36.86428f,-78.08255f,-28.863073f,-567.0f,-151.0f,159.0f,-11,-2.2827754f,-7.7175283f,3.2864058f,0f,0f,0f ) ;
  }

  @Test
  public void test119() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,2.842171E-14f,0f,0f,0f,0f,0f,-15.719717f,9.72603f,48.95552f,-1311.0f,694.0f,-552.0f,-3,2.5590534f,-0.14491971f,4.4230137f,0f,0f,0f ) ;
  }

  @Test
  public void test120() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,28.73892f,0f,0f,0f,0f,0f,-17.352907f,26.852211f,-4.0869107f,-92.0f,-201.0f,-930.0f,1,-0.70857435f,0.5547071f,-0.35132322f,0f,0f,0f ) ;
  }

  @Test
  public void test121() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,306.8716f,0f,0f,0f,0f,0f,72.12651f,87.605125f,20.489504f,2069.0f,169.0f,1053.0f,1,-0.0065892036f,1.8624957f,-2.6242828f,0f,0f,0f ) ;
  }

  @Test
  public void test122() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,30.868826f,0f,0f,0f,0f,0f,19.154537f,26.066513f,0.007113294f,0f,0f,0f,1,0.11852663f,0.2897515f,-0.286985f,0f,0f,0f ) ;
  }

  @Test
  public void test123() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,321.5219f,0f,0f,0f,0f,0f,-80.450775f,-26.733273f,-129.4012f,-1988.0f,1165.0f,982.0f,1,-0.4135363f,0.6088928f,-0.104926385f,0f,0f,0f ) ;
  }

  @Test
  public void test124() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,340.8195f,0f,0f,0f,0f,0f,-19.649256f,-71.40208f,60.188873f,-1469.0f,-1318.0f,464.0f,2,5.872538f,-0.23530048f,5.3383927f,0f,0f,0f ) ;
  }

  @Test
  public void test125() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,34.27046f,0f,0f,0f,0f,0f,-100.0f,-37.719265f,4.51692f,-950.0f,-1337.0f,2525.0f,2,-0.08282018f,0.09254117f,-0.0023004161f,0f,0f,0f ) ;
  }

  @Test
  public void test126() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,343.6079f,0f,0f,0f,0f,0f,-122.71887f,-43.25952f,21.101223f,-1782.0f,819.0f,617.0f,-1,-2.2141757f,8.01378f,6.1734076f,0f,0f,0f ) ;
  }

  @Test
  public void test127() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,35.80904f,0f,0f,0f,0f,0f,-61.151077f,100.0f,-3.669289f,-965.0f,-649.0f,-1605.0f,1,-0.9400069f,0.29615635f,-6.618436E-4f,0f,0f,0f ) ;
  }

  @Test
  public void test128() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,36.877693f,0f,0f,0f,0f,0f,3.5256634f,95.36021f,99.31765f,835.0f,1150.0f,788.0f,3,-0.6191314f,-0.89039165f,2.4528987f,0f,0f,0f ) ;
  }

  @Test
  public void test129() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,380.9376f,0f,0f,0f,0f,0f,361.05826f,-188.10428f,76.85025f,1211.0f,935.0f,727.0f,1,-0.16136454f,-1.9908845f,0.65299976f,0f,0f,0f ) ;
  }

  @Test
  public void test130() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,385.88837f,0f,0f,0f,0f,0f,-81.97529f,165.00224f,-58.651173f,-1762.0f,-159.0f,-64.0f,1,-0.014558528f,0.6931083f,0.47662413f,0f,0f,0f ) ;
  }

  @Test
  public void test131() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,387.10333f,0f,0f,0f,0f,0f,78.49051f,-221.11775f,159.09375f,-1767.0f,-2721.0f,-620.0f,1,-0.15135753f,-0.6825658f,0.20055743f,0f,0f,0f ) ;
  }

  @Test
  public void test132() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-39.27553f,0f,0f,0f,0f,0f,4.3191686f,-37.645798f,11.376813f,0f,0f,0f,2,0.30185354f,-0.61881864f,-0.11326663f,0f,0f,0f ) ;
  }

  @Test
  public void test133() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,39.79767f,0f,0f,0f,0f,0f,-10.33648f,-98.68178f,3.515255f,853.0f,-72.0f,487.0f,-3,-2.1396077f,0.11246335f,-0.72970647f,0f,0f,0f ) ;
  }

  @Test
  public void test134() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,40.33206f,0f,0f,0f,0f,0f,-100.0f,0.35468757f,-21.79124f,-1116.0f,753.0f,-1253.0f,-1,-0.1105723f,0.010619305f,-0.18882947f,0f,0f,0f ) ;
  }

  @Test
  public void test135() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,4.2510633f,0f,0f,0f,0f,0f,-54.013348f,19.601194f,34.618526f,57.0f,-507.0f,376.0f,1,-0.30778354f,0.8732723f,-0.06822483f,0f,0f,0f ) ;
  }

  @Test
  public void test136() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,43.699284f,0f,0f,0f,0f,0f,28.498667f,-61.67145f,67.89055f,1601.0f,517.0f,2213.0f,1,0.11506394f,-0.59616107f,0.5785875f,0f,0f,0f ) ;
  }

  @Test
  public void test137() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,4.725109E-13f,0f,0f,0f,0f,0f,73.30524f,69.6483f,-80.26173f,1172.0f,-443.0f,686.0f,1,0.7825551f,0.26980656f,0.084502116f,0f,0f,0f ) ;
  }

  @Test
  public void test138() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,47.777336f,0f,0f,0f,0f,0f,97.38675f,2.733152f,-59.5789f,-463.0f,-1312.0f,-817.0f,1,0.83862174f,0.34408697f,0.12771924f,0f,0f,0f ) ;
  }

  @Test
  public void test139() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,5.619309f,0f,0f,0f,0f,0f,-14.852743f,-3.0913718f,-2.4956627f,-277.0f,903.0f,530.0f,1,-0.35959062f,-0.1275571f,0.6663589f,0f,0f,0f ) ;
  }

  @Test
  public void test140() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,62.68781f,0f,0f,0f,0f,0f,100.0f,53.092743f,65.13507f,754.0f,-364.0f,-114.0f,1,0.33923554f,0.01928587f,0.44617173f,0f,0f,0f ) ;
  }

  @Test
  public void test141() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,6.893108f,0f,0f,0f,0f,0f,99.29433f,27.275572f,100.0f,-254.0f,854.0f,1507.0f,1,0.093403f,0.9784255f,0.014105978f,0f,0f,0f ) ;
  }

  @Test
  public void test142() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,76.666794f,0f,0f,0f,0f,0f,-17.15165f,62.64473f,49.632416f,-287.0f,129.0f,-262.0f,3,-1.6039239f,-1.4026103f,1.2971016f,0f,0f,0f ) ;
  }

  @Test
  public void test143() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,79.64852f,0f,0f,0f,0f,0f,-66.46499f,2.606081f,-96.232414f,473.0f,-691.0f,-346.0f,7,0.07509485f,-1.3738407f,-1.957109f,0f,0f,0f ) ;
  }

  @Test
  public void test144() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,80.27221f,0f,0f,0f,0f,0f,-25.82489f,-62.61083f,-70.02405f,-1195.0f,-838.0f,1190.0f,1,-0.5436359f,-0.43107238f,0.49739575f,0f,0f,0f ) ;
  }

  @Test
  public void test145() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,81.90195f,0f,0f,0f,0f,0f,-27.10189f,-68.25312f,-36.50709f,200.0f,183.0f,-485.0f,1,0.22337286f,-5.684612f,0.58805746f,0f,0f,0f ) ;
  }

  @Test
  public void test146() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,87.22671f,0f,0f,0f,0f,0f,9.346554f,3.715072f,-11.367076f,-283.0f,764.0f,17.0f,1,0.5794777f,0.44622818f,0.04744959f,0f,0f,0f ) ;
  }

  @Test
  public void test147() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,87.730896f,0f,0f,0f,0f,0f,100.0f,-30.052954f,70.54804f,952.0f,625.0f,563.0f,1,-0.022220325f,-0.3174767f,0.028976746f,0f,0f,0f ) ;
  }

  @Test
  public void test148() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,88.963104f,0f,0f,0f,0f,0f,-27.468372f,14.654569f,18.077684f,36.0f,-2095.0f,1753.0f,1,-0.10600012f,-0.4919124f,0.660587f,0f,0f,0f ) ;
  }

  @Test
  public void test149() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,91.675285f,0f,0f,0f,0f,0f,68.18168f,0.6916775f,4.2087555f,-29.0f,-774.0f,597.0f,1,0.16001664f,0.34339735f,0.42720047f,0f,0f,0f ) ;
  }

  @Test
  public void test150() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,96.04709f,0f,0f,0f,0f,0f,0.84741336f,-68.93769f,60.888832f,-893.0f,-813.0f,-908.0f,2,0.7125213f,3.40393f,6.4545665f,0f,0f,0f ) ;
  }

  @Test
  public void test151() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,97.49086f,0f,0f,0f,0f,0f,11.542281f,-3.7732658f,0.5511596f,-394.0f,-1307.0f,-695.0f,1,0.6870228f,0.67823654f,0.05030641f,0f,0f,0f ) ;
  }

  @Test
  public void test152() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,98.80202f,0f,0f,0f,0f,0f,56.59691f,-5.1651993f,32.651405f,-583.0f,-269.0f,968.0f,1,0.9724331f,0.10987018f,0.15927522f,0f,0f,0f ) ;
  }

  @Test
  public void test153() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-75.31812f,0f,93.722855f,0f,0f,0f,0f,0f,8.856288f,-71.83445f,100.0f,0f,0f,0f,1,0.5818333f,-0.28085575f,-0.4087027f,0f,0f,0f ) ;
  }

  @Test
  public void test154() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,8.258707f,0f,0f,0f,0f,0f,0f,0f,-33.71024f,100.0f,61.92211f,0f,0f,0f,1,0.22815946f,-0.23988834f,0.04608856f,0f,0f,0f ) ;
  }

  @Test
  public void test155() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1030.0f,-536.0f,0f,34.0f,0f,0f,0f,0f,0f,-150.0f,185.0f,-112.0f,-1476.0f,559.0f,-1310.0f,-12,0.26012054f,2.194476f,6.4155416f,0f,0f,0f ) ;
  }

  @Test
  public void test156() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1049.0f,-2893.0f,0f,159.0f,0f,0f,0f,0f,0f,1903.0f,-670.0f,-585.0f,826.0f,1300.0f,-386.0f,-10,-6.4820533f,-0.22779411f,-0.32789162f,0f,0f,0f ) ;
  }

  @Test
  public void test157() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1085.0f,-689.0f,0f,777.0f,0f,0f,0f,0f,0f,-2182.0f,1042.0f,-323.0f,-1155.0f,-311.0f,199.0f,1,0.62844926f,-0.33507472f,0.4239537f,0f,0f,0f ) ;
  }

  @Test
  public void test158() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1094.0f,-217.0f,0f,448.0f,0f,0f,0f,0f,0f,1164.0f,2191.0f,549.0f,-447.0f,1387.0f,-486.0f,1,-0.87444323f,-0.13025537f,-0.1049671f,0f,0f,0f ) ;
  }

  @Test
  public void test159() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1116.0f,-800.0f,0f,1190.0f,0f,0f,0f,0f,0f,2063.0f,-562.0f,2103.0f,357.0f,888.0f,2563.0f,4,-0.7613248f,-0.03526479f,0.14673293f,0f,0f,0f ) ;
  }

  @Test
  public void test160() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1140.0f,-1241.0f,0f,144.0f,0f,0f,0f,0f,0f,-559.0f,1597.0f,2871.0f,823.0f,2369.0f,3542.0f,2,-0.13806462f,-0.03522474f,-0.53312105f,0f,0f,0f ) ;
  }

  @Test
  public void test161() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1143.0f,-2408.0f,0f,771.0f,0f,0f,0f,0f,0f,58.0f,-183.0f,-375.0f,-355.0f,-1299.0f,579.0f,1,-0.37495178f,0.084375694f,0.36838192f,0f,0f,0f ) ;
  }

  @Test
  public void test162() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1150.0f,-1196.0f,0f,248.0f,0f,0f,0f,0f,0f,-416.0f,-1220.0f,-64.0f,-4237.0f,-908.0f,1835.0f,1,-0.33012438f,0.13100454f,-0.20418441f,0f,0f,0f ) ;
  }

  @Test
  public void test163() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1177.0f,-1248.0f,0f,550.0f,0f,0f,0f,0f,0f,-430.0f,-1164.0f,-500.0f,-908.0f,866.0f,-1312.0f,-17,0.9023537f,18.216011f,-4.1555924f,0f,0f,0f ) ;
  }

  @Test
  public void test164() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1198.0f,-1124.0f,0f,833.0f,0f,0f,0f,0f,0f,-107.0f,-171.0f,-181.0f,-49.0f,-180.0f,199.0f,2,0.8574013f,-0.20877938f,0.34134588f,0f,0f,0f ) ;
  }

  @Test
  public void test165() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1212.0f,-1298.0f,0f,255.0f,0f,0f,0f,0f,0f,633.0f,412.0f,-1241.0f,1348.0f,-2363.0f,-1108.0f,2,-0.40844294f,0.37475193f,0.8141928f,0f,0f,0f ) ;
  }

  @Test
  public void test166() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-122.0f,-299.0f,0f,255.0f,0f,0f,0f,0f,0f,-640.0f,-3657.0f,937.0f,-405.0f,-2126.0f,1362.0f,1,0.5998453f,0.0425224f,-0.31703383f,0f,0f,0f ) ;
  }

  @Test
  public void test167() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1223.0f,-41.0f,0f,163.0f,0f,0f,0f,0f,0f,-1351.0f,-471.0f,-286.0f,445.0f,-1633.0f,587.0f,1,0.34229335f,0.31683478f,0.52277803f,0f,0f,0f ) ;
  }

  @Test
  public void test168() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1234.0f,-1038.0f,0f,255.0f,0f,0f,0f,0f,0f,-1371.0f,947.0f,-128.0f,-1846.0f,716.0f,-1135.0f,2,0.8646271f,-1.9531912f,-0.7658103f,0f,0f,0f ) ;
  }

  @Test
  public void test169() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-124.0f,-221.0f,0f,255.0f,0f,0f,0f,0f,0f,-1541.0f,-771.0f,938.0f,-843.0f,-344.0f,1188.0f,1,-0.005039458f,-0.1702365f,-0.19128747f,0f,0f,0f ) ;
  }

  @Test
  public void test170() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1252.0f,-1516.0f,0f,659.0f,0f,0f,0f,0f,0f,301.0f,402.0f,698.0f,-786.0f,-1422.0f,1158.0f,1,-0.970582f,-0.004314086f,0.039332416f,0f,0f,0f ) ;
  }

  @Test
  public void test171() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1261.0f,-538.0f,0f,84.0f,0f,0f,0f,0f,0f,1317.0f,974.0f,-1263.0f,1522.0f,-1118.0f,-1517.0f,10,-0.09451816f,-0.66399354f,-0.1410458f,0f,0f,0f ) ;
  }

  @Test
  public void test172() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1264.0f,-273.0f,0f,254.0f,0f,0f,0f,0f,0f,185.0f,-3529.0f,817.0f,449.0f,-1192.0f,160.0f,-5,1.8833312f,2.8502471f,-2.6932514f,0f,0f,0f ) ;
  }

  @Test
  public void test173() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1268.0f,-675.0f,0f,255.0f,0f,0f,0f,0f,0f,359.0f,634.0f,2085.0f,-276.0f,-1772.0f,2894.0f,2,0.084374115f,0.31001842f,-0.7053794f,0f,0f,0f ) ;
  }

  @Test
  public void test174() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1284.0f,-2257.0f,0f,1003.0f,0f,0f,0f,0f,0f,73.0f,-460.0f,-2285.0f,-69.0f,669.0f,-1325.0f,3,-0.49716574f,0.18609521f,0.8159825f,0f,0f,0f ) ;
  }

  @Test
  public void test175() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-132.0f,-999.0f,0f,1361.0f,0f,0f,0f,0f,0f,-333.0f,-488.0f,-1092.0f,-2793.0f,-542.0f,-2062.0f,-2,-0.31324983f,0.5795014f,0.65839326f,0f,0f,0f ) ;
  }

  @Test
  public void test176() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1374.0f,-2860.0f,0f,1103.0f,0f,0f,0f,0f,0f,829.0f,794.0f,-940.0f,-546.0f,-436.0f,-850.0f,-4,-8.728701f,-4.595683f,-2.1360552f,0f,0f,0f ) ;
  }

  @Test
  public void test177() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1409.0f,-251.0f,0f,255.0f,0f,0f,0f,0f,0f,1468.0f,-279.0f,670.0f,387.0f,685.0f,432.0f,1,-0.918206f,0.062342733f,-0.19997522f,0f,0f,0f ) ;
  }

  @Test
  public void test178() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1471.0f,-100.0f,0f,704.0f,0f,0f,0f,0f,0f,-366.0f,421.0f,375.0f,115.0f,-414.0f,577.0f,1,-0.004539287f,-0.11878706f,-0.034581073f,0f,0f,0f ) ;
  }

  @Test
  public void test179() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1536.0f,-688.0f,0f,2572.0f,0f,0f,0f,0f,0f,-623.0f,-732.0f,694.0f,-666.0f,-350.0f,-967.0f,2,-0.014475602f,-0.0518798f,-0.44038704f,0f,0f,0f ) ;
  }

  @Test
  public void test180() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1558.0f,-701.0f,0f,537.0f,0f,0f,0f,0f,0f,61.0f,-49.0f,-5.0f,605.0f,831.0f,-765.0f,2,-0.24367355f,0.56610644f,-0.77460194f,0f,0f,0f ) ;
  }

  @Test
  public void test181() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1583.0f,-1456.0f,0f,1172.0f,0f,0f,0f,0f,0f,-1128.0f,-87.0f,-153.0f,2100.0f,-250.0f,-7.0f,12,1.9187045f,-0.74042183f,0.6336919f,0f,0f,0f ) ;
  }

  @Test
  public void test182() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1636.0f,-976.0f,0f,1982.0f,0f,0f,0f,0f,0f,231.0f,26.0f,-56.0f,-164.0f,919.0f,-250.0f,1,-0.13067584f,0.9664357f,0.0024879246f,0f,0f,0f ) ;
  }

  @Test
  public void test183() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1667.0f,-595.0f,0f,1392.0f,0f,0f,0f,0f,0f,782.0f,-1146.0f,-813.0f,-293.0f,-1189.0f,1393.0f,1,0.24688146f,0.12632087f,2.6193137f,0f,0f,0f ) ;
  }

  @Test
  public void test184() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1787.0f,-708.0f,0f,2429.0f,0f,0f,0f,0f,0f,269.0f,-32.0f,257.0f,53.0f,1491.0f,140.0f,-3,-4.0552483f,-2.4961264f,3.596374f,0f,0f,0f ) ;
  }

  @Test
  public void test185() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-18.0f,-608.0f,0f,255.0f,0f,0f,0f,0f,0f,-353.0f,1463.0f,-856.0f,1920.0f,1704.0f,858.0f,1,0.1005118f,-0.71729094f,-0.6013198f,0f,0f,0f ) ;
  }

  @Test
  public void test186() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1866.0f,-2089.0f,0f,450.0f,0f,0f,0f,0f,0f,-1596.0f,1571.0f,-1343.0f,963.0f,81.0f,-1051.0f,2,0.26419407f,0.26829314f,1.1493824f,0f,0f,0f ) ;
  }

  @Test
  public void test187() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1907.0f,-401.0f,0f,1111.0f,0f,0f,0f,0f,0f,770.0f,987.0f,-1171.0f,790.0f,-795.0f,-152.0f,-4,-0.38771847f,0.08977411f,-0.057286527f,0f,0f,0f ) ;
  }

  @Test
  public void test188() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-195.0f,-646.0f,0f,244.0f,0f,0f,0f,0f,0f,647.0f,-1618.0f,572.0f,578.0f,-2370.0f,-263.0f,-3,1.4195011f,0.23450197f,-2.0967813f,0f,0f,0f ) ;
  }

  @Test
  public void test189() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1971.0f,-455.0f,0f,1006.0f,0f,0f,0f,0f,0f,771.0f,-572.0f,-1288.0f,1313.0f,-2600.0f,-1456.0f,-1,-0.09420785f,0.31932193f,-0.0017373533f,0f,0f,0f ) ;
  }

  @Test
  public void test190() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2004.0f,-96.0f,0f,1175.0f,0f,0f,0f,0f,0f,133.0f,159.0f,762.0f,1059.0f,1037.0f,-355.0f,13,2.8132508f,-2.7860498f,-13.905837f,0f,0f,0f ) ;
  }

  @Test
  public void test191() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2161.0f,-881.0f,0f,973.0f,0f,0f,0f,0f,0f,392.0f,-517.0f,223.0f,-59.0f,365.0f,951.0f,1,-0.669831f,-0.048907127f,-2.3123288f,0f,0f,0f ) ;
  }

  @Test
  public void test192() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-234.0f,-428.0f,0f,847.0f,0f,0f,0f,0f,0f,-1450.0f,1159.0f,374.0f,72.0f,-1500.0f,-313.0f,1,0.35070577f,0.12976016f,0.008050201f,0f,0f,0f ) ;
  }

  @Test
  public void test193() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2356.0f,-656.0f,0f,1333.0f,0f,0f,0f,0f,0f,137.0f,-59.0f,-286.0f,-1599.0f,401.0f,-849.0f,-2,0.09152477f,-0.054897506f,0.59667873f,0f,0f,0f ) ;
  }

  @Test
  public void test194() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2356.0f,-7.0f,0f,255.0f,0f,0f,0f,0f,0f,-1956.0f,957.0f,1043.0f,-194.0f,-86.0f,2707.0f,1,0.47946554f,-0.606084f,-0.62662685f,0f,0f,0f ) ;
  }

  @Test
  public void test195() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2442.0f,-1042.0f,0f,739.0f,0f,0f,0f,0f,0f,59.0f,2534.0f,-904.0f,-1338.0f,-88.0f,-334.0f,1,-0.17604996f,0.008097853f,0.038092565f,0f,0f,0f ) ;
  }

  @Test
  public void test196() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2718.0f,-686.0f,0f,25.0f,0f,0f,0f,0f,0f,-273.0f,-1084.0f,597.0f,738.0f,-1046.0f,547.0f,9,1.0796076f,-8.416261E-5f,-0.7899479f,0f,0f,0f ) ;
  }

  @Test
  public void test197() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-30.0f,-840.0f,0f,255.0f,0f,0f,0f,0f,0f,1788.0f,-1856.0f,-100.0f,38.0f,-331.0f,1002.0f,-1,-0.0030823802f,0.68974537f,0.20283732f,0f,0f,0f ) ;
  }

  @Test
  public void test198() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-302.0f,-1189.0f,0f,1103.0f,0f,0f,0f,0f,0f,-389.0f,-2.0f,3.0f,-17.0f,849.0f,-1634.0f,1,0.07008463f,0.32202244f,-0.082616314f,0f,0f,0f ) ;
  }

  @Test
  public void test199() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-30.622274f,-100.0f,0f,3.7189766E-17f,0f,0f,0f,0f,0f,38.87559f,90.81869f,-100.0f,0f,0f,0f,1,-0.018473012f,0.044431f,1.0538466f,0f,0f,0f ) ;
  }

  @Test
  public void test200() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3095.0f,-2049.0f,0f,253.0f,0f,0f,0f,0f,0f,-997.0f,-326.0f,1459.0f,-1038.0f,336.0f,802.0f,3,-0.2155276f,0.31304523f,-2.98903f,0f,0f,0f ) ;
  }

  @Test
  public void test201() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3154.0f,-382.0f,0f,1139.0f,0f,0f,0f,0f,0f,958.0f,191.0f,-77.0f,240.0f,-1341.0f,-336.0f,2,-0.4584307f,-0.06422411f,0.26251894f,0f,0f,0f ) ;
  }

  @Test
  public void test202() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-35.241776f,-100.0f,0f,0f,0f,0f,0f,0f,0f,-53.318016f,-36.482758f,100.0f,0f,0f,0f,1,-0.00447492f,0.17812684f,-0.098254494f,0f,0f,0f ) ;
  }

  @Test
  public void test203() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-438.0f,-598.0f,0f,81.0f,0f,0f,0f,0f,0f,-418.0f,929.0f,-176.0f,-958.0f,-370.0f,313.0f,16,-1.2040809f,-1.6857073f,-5.53075f,0f,0f,0f ) ;
  }

  @Test
  public void test204() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-440.0f,-1545.0f,0f,254.0f,0f,0f,0f,0f,0f,1029.0f,-1950.0f,-841.0f,1458.0f,-731.0f,344.0f,-15,-2.1194425f,0.527445f,3.3184614f,0f,0f,0f ) ;
  }

  @Test
  public void test205() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-45.532303f,-87.11352f,0f,0f,0f,0f,0f,0f,0f,-72.83469f,100.0f,61.01513f,0f,0f,0f,2,0.7779002f,-0.7620549f,-0.4387566f,0f,0f,0f ) ;
  }

  @Test
  public void test206() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-473.0f,-649.0f,0f,387.0f,0f,0f,0f,0f,0f,128.0f,253.0f,253.0f,-2741.0f,718.0f,669.0f,2,-0.09427421f,0.40126392f,-0.6844842f,0f,0f,0f ) ;
  }

  @Test
  public void test207() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-489.0f,-1304.0f,0f,55.0f,0f,0f,0f,0f,0f,-795.0f,-752.0f,1879.0f,-1814.0f,113.0f,-638.0f,1,0.6529936f,0.2849912f,-0.020348633f,0f,0f,0f ) ;
  }

  @Test
  public void test208() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-50.0f,-1161.0f,0f,255.0f,0f,0f,0f,0f,0f,-222.0f,-706.0f,2393.0f,-488.0f,-584.0f,609.0f,1,0.5441633f,0.41875508f,-0.42845753f,0f,0f,0f ) ;
  }

  @Test
  public void test209() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-544.0f,-758.0f,0f,696.0f,0f,0f,0f,0f,0f,-400.0f,-1197.0f,-576.0f,52.0f,815.0f,899.0f,-2,-0.016884234f,-0.036055118f,0.3635412f,0f,0f,0f ) ;
  }

  @Test
  public void test210() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,55.32359f,0f,0f,0f,0f,0f,0f,0f,0f,-95.36229f,-48.210064f,-100.0f,0f,0f,0f,1,-0.0852143f,0.13358113f,2.034882f,0f,0f,0f ) ;
  }

  @Test
  public void test211() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-580.0f,-2350.0f,0f,144.0f,0f,0f,0f,0f,0f,-2721.0f,156.0f,1822.0f,-527.0f,-532.0f,1676.0f,1,-0.020846166f,0.045929994f,-0.42804646f,0f,0f,0f ) ;
  }

  @Test
  public void test212() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-58.0f,-274.0f,0f,572.0f,0f,0f,0f,0f,0f,714.0f,402.0f,18.0f,-129.0f,237.0f,-175.0f,1,-0.021837277f,-0.9277048f,0.22151397f,0f,0f,0f ) ;
  }

  @Test
  public void test213() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-589.0f,-1381.0f,0f,255.0f,0f,0f,0f,0f,0f,-1958.0f,-702.0f,-1426.0f,-969.0f,338.0f,-1571.0f,1,-0.0032609766f,-0.2115192f,0.14684497f,0f,0f,0f ) ;
  }

  @Test
  public void test214() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-61.117977f,-174.126f,0f,0.0f,0f,0f,0f,0f,0f,31.58541f,40.994682f,68.624756f,0f,0f,0f,1,0.15154679f,0.59412587f,-0.523562f,0f,0f,0f ) ;
  }

  @Test
  public void test215() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-61.36904f,0.0f,0f,0f,0f,0f,0f,0f,0f,-70.96572f,59.35766f,-79.82435f,0f,0f,0f,-4,0.6685049f,-0.9211212f,-0.064275585f,0f,0f,0f ) ;
  }

  @Test
  public void test216() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-625.0f,-1598.0f,0f,255.0f,0f,0f,0f,0f,0f,1712.0f,-551.0f,1106.0f,1441.0f,-859.0f,621.0f,1,-0.90400153f,0.2061876f,-0.044651702f,0f,0f,0f ) ;
  }

  @Test
  public void test217() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-654.0f,-770.0f,0f,215.0f,0f,0f,0f,0f,0f,-192.0f,359.0f,12.0f,641.0f,2929.0f,-480.0f,3,-0.11447087f,-3.4562387f,0.5584918f,0f,0f,0f ) ;
  }

  @Test
  public void test218() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-65.736885f,0.0f,0f,0f,0f,0f,0f,0f,0f,3.9063995f,-61.305576f,42.35572f,0f,0f,0f,1,-0.5112628f,-0.2481765f,-0.7253305f,0f,0f,0f ) ;
  }

  @Test
  public void test219() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-682.0f,-463.0f,0f,588.0f,0f,0f,0f,0f,0f,1385.0f,1007.0f,1505.0f,-647.0f,1381.0f,484.0f,-4,-0.6573899f,0.7461266f,-0.096380554f,0f,0f,0f ) ;
  }

  @Test
  public void test220() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-70.96415f,0f,0f,0f,0f,0f,0f,0f,0f,107.80997f,-62.213852f,-10.990765f,0f,0f,0f,1,0.099922925f,0.5292483f,-0.12524463f,0f,0f,0f ) ;
  }

  @Test
  public void test221() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-722.0f,-880.0f,0f,258.0f,0f,0f,0f,0f,0f,1332.0f,745.0f,-336.0f,864.0f,288.0f,-1300.0f,3,-0.095219545f,-0.26995662f,-0.0049510305f,0f,0f,0f ) ;
  }

  @Test
  public void test222() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-725.0f,-836.0f,0f,255.0f,0f,0f,0f,0f,0f,-2071.0f,1028.0f,-1730.0f,-840.0f,521.0f,-1125.0f,1,-0.028163316f,-0.16625136f,-0.027274061f,0f,0f,0f ) ;
  }

  @Test
  public void test223() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-737.0f,-899.0f,0f,2123.0f,0f,0f,0f,0f,0f,407.0f,-38.0f,-1611.0f,-434.0f,-906.0f,-568.0f,1,-0.44393596f,0.8454931f,0.16427353f,0f,0f,0f ) ;
  }

  @Test
  public void test224() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-751.0f,-1248.0f,0f,142.0f,0f,0f,0f,0f,0f,694.0f,-866.0f,-1837.0f,-523.0f,-1369.0f,-832.0f,-3,-7.9556026f,1.0317237f,-2.0593321f,0f,0f,0f ) ;
  }

  @Test
  public void test225() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-76.0f,-189.0f,0f,578.0f,0f,0f,0f,0f,0f,-215.0f,1187.0f,-65.0f,-1426.0f,-321.0f,-1154.0f,2,-1.2566844f,-0.26737383f,0.76218307f,0f,0f,0f ) ;
  }

  @Test
  public void test226() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-800.0f,-1342.0f,0f,252.0f,0f,0f,0f,0f,0f,1242.0f,-1317.0f,91.0f,1114.0f,-296.0f,-391.0f,3,-2.7936811f,1.0780874f,-0.00959217f,0f,0f,0f ) ;
  }

  @Test
  public void test227() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,8.015795f,0f,0f,0f,0f,0f,0f,0f,0f,22.520863f,100.0f,-59.102917f,0f,0f,0f,1,0.803149f,-0.44645903f,0.029583395f,0f,0f,0f ) ;
  }

  @Test
  public void test228() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-85.443085f,-47.481438f,0f,0.0f,0f,0f,0f,0f,0f,99.50062f,-32.262356f,-23.156752f,0f,0f,0f,-2,-1.5864228f,3.098259f,-4.088054f,0f,0f,0f ) ;
  }

  @Test
  public void test229() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-86.15661f,-99.9938f,0f,-35.970646f,0f,0f,0f,0f,0f,20.047222f,-100.0f,16.310244f,0f,0f,0f,2,-0.42335021f,1.2224005f,-0.60201365f,0f,0f,0f ) ;
  }

  @Test
  public void test230() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-869.0f,-2181.0f,0f,3445.0f,0f,0f,0f,0f,0f,479.0f,1052.0f,204.0f,1097.0f,-453.0f,-101.0f,1,-2.5602937f,1.3177034f,-2.3411994f,0f,0f,0f ) ;
  }

  @Test
  public void test231() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-885.0f,-284.0f,0f,1276.0f,0f,0f,0f,0f,0f,-1528.0f,115.0f,1805.0f,-600.0f,-541.0f,439.0f,6,3.3129903E-4f,-0.023709353f,-0.8943989f,0f,0f,0f ) ;
  }

  @Test
  public void test232() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-909.0f,-381.0f,0f,67.0f,0f,0f,0f,0f,0f,-169.0f,1534.0f,-386.0f,235.0f,2401.0f,1257.0f,1,0.09688421f,-0.3784381f,0.111903526f,0f,0f,0f ) ;
  }

  @Test
  public void test233() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-934.0f,-835.0f,0f,69.0f,0f,0f,0f,0f,0f,633.0f,-611.0f,309.0f,871.0f,749.0f,1762.0f,-1,-0.6893916f,-0.4406521f,-0.23708527f,0f,0f,0f ) ;
  }

  @Test
  public void test234() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-93.914986f,7.1054274E-15f,0f,0f,0f,0f,0f,0f,0f,69.04464f,-65.31653f,-15.814569f,0f,0f,0f,2,-0.8426373f,-0.5528824f,1.7978255f,0f,0f,0f ) ;
  }

  @Test
  public void test235() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-948.0f,-1335.0f,0f,255.0f,0f,0f,0f,0f,0f,622.0f,-2639.0f,1159.0f,1602.0f,667.0f,1797.0f,1,-0.34772047f,-0.30190188f,-0.7579694f,0f,0f,0f ) ;
  }

  @Test
  public void test236() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-964.0f,-30.0f,0f,630.0f,0f,0f,0f,0f,0f,1053.0f,1158.0f,-2192.0f,636.0f,-1090.0f,-454.0f,5,-0.2242342f,2.5453925f,6.1617274f,0f,0f,0f ) ;
  }

  @Test
  public void test237() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-97.275085f,-64.30772f,0f,-35.877167f,0f,0f,0f,0f,0f,-18.804295f,36.54997f,78.61082f,0f,0f,0f,1,0.017148416f,0.008722852f,-0.102235995f,0f,0f,0f ) ;
  }

  @Test
  public void test238() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-989.0f,-609.0f,0f,315.0f,0f,0f,0f,0f,0f,397.0f,-142.0f,-545.0f,-115.0f,-107.0f,-2268.0f,1,0.23133118f,-0.5976209f,0.5611467f,0f,0f,0f ) ;
  }
}
