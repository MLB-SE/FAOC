import org.junit.Test;

public class JpfTargetRayTraceTest {

  @Test
  public void test0() {
    TestDrivers.rayTrace(-0.7397832f,-100.0f,-100.0f,-99.98829f,-99.99999f,-81.65179f,-100.0f,0.30359757f,0.88637996f,-0.34951273f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,0.044290032f,-0.18902735f,-0.9809725f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-0.75496405f,-0.2621021f,0.3704234f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,0.9413871f,-0.018479789f,-0.33680043f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-1.0928359E-4f,-1.6858123E-4f,2.1416375E-4f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-2.360304E-10f,1.3440159E-10f,-2.779345E-12f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-2.9536895E-10f,6.922477E-10f,-3.1373213E-11f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,3.4436134E-6f,-3.512526E-6f,-4.1730577E-6f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,36.560772f,-50.421543f,-78.04764f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,3.8683914E-10f,4.9016285E-10f,-4.972261E-11f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,40.250217f,27.410538f,18.216509f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-4.0650725E-6f,-8.5896625E-7f,6.01625E-7f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,8.4754846E-27f,2.5244772E-28f,-1.2132974E-26f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-8.507278E-4f,2.7855305E-4f,-4.69512E-4f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,9.041095E-9f,1.1903137E-9f,-1.6550211E-10f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-92.49388f,-58.368866f,8.518192f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.rayTrace(100.0f,-100.0f,-100.0f,100.0f,-100.0f,-42.09488f,-18.714062f,-0.13434197f,-0.7972307f,0.5885367f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.rayTrace(-100.0f,100.0f,-100.0f,-100.0f,20.26117f,100.0f,-100.0f,-0.9036728f,0.24268962f,0.35281333f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.rayTrace(-100.0f,-100.0f,100.0f,68.120926f,100.0f,9.397717f,100.0f,-0.5769218f,-0.815686f,0.042633507f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.rayTrace(-100.0f,-100.0f,100.0f,99.59607f,-27.532269f,-100.0f,11.237473f,0.10393288f,0.9837878f,0.14614931f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.rayTrace(-100.0f,100.0f,25.97883f,100.0f,-60.355453f,-100.0f,34.67045f,0.76969975f,-0.45388028f,0.44894874f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.rayTrace(100.0f,100.0f,-34.828667f,95.60876f,100.0f,7.953873f,102.97027f,-0.23180604f,0.015565242f,-0.9726375f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.rayTrace(-100.0f,-100.0f,43.523872f,100.0f,25.181715f,99.24333f,72.75449f,-0.52530307f,0.78367627f,0.33152404f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.rayTrace(-100.0f,-100.0f,-85.381096f,39.21675f,91.24121f,100.0f,-9.485681f,0.16136014f,-0.95209306f,-0.2597723f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.rayTrace(-100.0f,-13.728042f,-31.91949f,100.0f,-100.0f,45.36539f,-65.65628f,-0.34017736f,0.02309362f,0.94007766f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.rayTrace(100.0f,15.479708f,99.999466f,15.869235f,99.98545f,35.475445f,96.48688f,-2.7865407f,3.5758314f,2.1973746f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.rayTrace(-100.0f,-15.929743f,74.25193f,-6.608113f,-100.0f,-15.718692f,83.75209f,0.93619496f,-0.502722f,1.1217932f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.rayTrace(100.0f,18.744186f,100.0f,-92.47191f,100.0f,-36.012f,99.2641f,-0.36447686f,-0.07381965f,-0.76781046f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.rayTrace(100.0f,27.79193f,86.11307f,100.0f,100.0f,52.150013f,5.6968446f,0.64942497f,0.46661302f,0.37256646f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.rayTrace(-100.0f,32.172043f,100.0f,-100.0f,-49.15724f,27.152376f,93.974304f,-0.10208777f,-0.31323037f,0.41874245f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.rayTrace(-100.0f,3.7800028f,-94.395485f,-99.62392f,89.32971f,18.977692f,-49.577515f,-0.9393785f,-0.1869365f,0.2874417f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.rayTrace(100.0f,-42.120987f,100.0f,-57.946922f,100.0f,-100.0f,99.08665f,-0.7698374f,-0.036517415f,-0.6371946f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.rayTrace(100.0f,-53.943256f,-100.0f,99.995125f,79.87188f,100.0f,-10.467247f,0.29480773f,0.76355034f,0.5745253f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.rayTrace(-100.0f,55.826603f,-198.12321f,100.0f,-140.2577f,-26.672913f,-100.0f,-0.12027247f,-0.9922364f,0.031647384f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.rayTrace(100.0f,57.369522f,-100.0f,-100.0f,-42.943954f,100.0f,-100.0f,-0.83645356f,0.5338459f,0.123911195f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.rayTrace(100.0f,73.89419f,55.016468f,142.96219f,-86.76309f,75.718315f,32.118984f,-0.50957686f,-0.36033994f,0.7097145f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.rayTrace(-100.0f,-7.763328f,-100.0f,100.0f,-100.0f,-100.0f,48.141285f,-0.012137468f,-0.8206482f,0.57130486f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.rayTrace(-100.0f,-81.01457f,-99.94424f,92.98999f,-96.5318f,59.367943f,-51.99259f,0.21295191f,-0.9306337f,0.29761106f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.rayTrace(-100.0f,-90.56899f,-96.52977f,45.74518f,-100.0f,-99.57069f,-100.0f,-0.28346592f,-0.07631184f,0.75131726f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.rayTrace(-100.0f,99.999535f,-100.0f,-100.0f,-100.0f,-100.0f,-47.942017f,-0.005036786f,0.99759305f,0.069157265f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.rayTrace(100.0f,-99.999985f,56.163345f,100.0f,99.999954f,100.0f,17.427046f,-0.057582583f,0.7852456f,-0.6165011f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.rayTrace(11.350087f,93.53833f,11.897537f,81.14848f,67.1268f,98.08751f,-50.36805f,-0.90497756f,-0.006237471f,0.13102238f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.rayTrace(12.0021f,38.127262f,99.99904f,-78.41439f,59.67225f,100.0f,93.06137f,-0.13781992f,-0.77640057f,0.614986f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.rayTrace(-1.2095307f,-64.498726f,45.06163f,-7.6391406f,9.913259f,-55.23623f,65.01976f,79.85073f,39.09184f,70.95875f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.rayTrace(-12.5204115f,99.99582f,-55.511818f,-100.0f,-29.391436f,2.3774562f,-69.150856f,0.011414185f,0.9995738f,-0.026868325f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.rayTrace(12.701004f,80.88701f,16.23171f,-73.06758f,-43.9326f,2.139249f,92.43098f,-3.6203318f,92.42772f,86.103195f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.rayTrace(-15.072118f,-9.721885f,-76.51357f,-37.881744f,-39.88229f,-1.4502711f,-49.10806f,-92.9241f,-48.022327f,-69.63007f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.rayTrace(15.881764f,34.59356f,-0.45334482f,67.09676f,-31.272524f,-7.7403183f,21.598682f,0.30268988f,0.8459159f,0.4390958f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.rayTrace(16.19458f,-70.93285f,34.057537f,78.432686f,8.331175f,-20.25561f,-1.1766334f,0.22664584f,-0.044654038f,-0.20603071f ) ;
  }

  @Test
  public void test49() {
    TestDrivers.rayTrace(-17.847597f,-34.73157f,68.703606f,50.27826f,-44.368717f,-0.63140154f,42.979843f,0.056236364f,-0.93789995f,-0.34231737f ) ;
  }

  @Test
  public void test50() {
    TestDrivers.rayTrace(-179.1044f,166.96733f,-92.32376f,-100.0f,-100.0f,183.31277f,-151.27562f,-0.89558905f,0.057273626f,0.44121233f ) ;
  }

  @Test
  public void test51() {
    TestDrivers.rayTrace(18.603172f,-1.526338f,25.730412f,-27.183939f,-4.137638f,9.828766f,35.368034f,-73.78036f,-63.935764f,-98.76213f ) ;
  }

  @Test
  public void test52() {
    TestDrivers.rayTrace(20.42773f,-47.424446f,20.151419f,11.84696f,13.096184f,-42.215847f,28.600653f,-1.5265355f,-1.5521815f,0.5497788f ) ;
  }

  @Test
  public void test53() {
    TestDrivers.rayTrace(20.610332f,89.85111f,6.0629907f,-79.55252f,-67.09679f,82.64805f,-22.221846f,-0.77133024f,-0.34357882f,0.2134436f ) ;
  }

  @Test
  public void test54() {
    TestDrivers.rayTrace(-2.0838158f,-29.090464f,49.48425f,82.17485f,-48.783924f,-23.013752f,-71.320305f,29.988092f,-21.794994f,83.49155f ) ;
  }

  @Test
  public void test55() {
    TestDrivers.rayTrace(21.643639f,-58.45675f,-100.0f,-14.226136f,93.48064f,-28.780252f,-100.0f,0.13251676f,-0.057365045f,-0.43975693f ) ;
  }

  @Test
  public void test56() {
    TestDrivers.rayTrace(-22.012339f,-95.845924f,-167.31624f,95.08669f,111.302f,43.288536f,-86.32147f,-0.23760542f,-0.90448713f,-0.35418454f ) ;
  }

  @Test
  public void test57() {
    TestDrivers.rayTrace(-23.42894f,49.407444f,8.453015f,11.407987f,46.886036f,0.113841906f,-8.004841f,0.06461204f,-0.21981357f,0.02822673f ) ;
  }

  @Test
  public void test58() {
    TestDrivers.rayTrace(23.657219f,-20.223394f,9.757367f,40.071613f,8.363226f,50.433002f,81.614555f,-1.981703f,-5.2290154f,-5.6287203f ) ;
  }

  @Test
  public void test59() {
    TestDrivers.rayTrace(-24.232042f,-80.72226f,56.837112f,100.0f,-114.018875f,-100.0f,17.330837f,-0.0063854065f,0.95289075f,-0.3032464f ) ;
  }

  @Test
  public void test60() {
    TestDrivers.rayTrace(24.427902f,99.80884f,19.235403f,100.0f,-37.517216f,71.76245f,76.45589f,-0.8491869f,-0.22803931f,-0.42202282f ) ;
  }

  @Test
  public void test61() {
    TestDrivers.rayTrace(-24.706078f,34.668465f,-51.59412f,-28.792328f,-73.625f,-45.908257f,87.75552f,-18.347645f,-68.22935f,93.632645f ) ;
  }

  @Test
  public void test62() {
    TestDrivers.rayTrace(25.066118f,100.0f,-100.0f,-100.0f,-100.0f,-100.0f,100.0f,0.3020623f,0.94633496f,0.11492853f ) ;
  }

  @Test
  public void test63() {
    TestDrivers.rayTrace(25.687626f,-29.244568f,7.969141f,58.6035f,-1.295634f,-100.0f,-1.8430257f,0.27531826f,1.1257244f,1.7982254f ) ;
  }

  @Test
  public void test64() {
    TestDrivers.rayTrace(26.177698f,-1.4861226f,-0.35664102f,-48.5967f,-77.13199f,-100.0f,-31.97371f,6.081535f,2.8124554f,0.7928084f ) ;
  }

  @Test
  public void test65() {
    TestDrivers.rayTrace(26.569334f,60.195488f,75.708084f,-15.078788f,-85.372894f,32.436817f,81.493225f,69.92831f,56.909855f,19.845133f ) ;
  }

  @Test
  public void test66() {
    TestDrivers.rayTrace(-27.506227f,100.0f,-78.45306f,-100.0f,100.0f,69.22817f,100.0f,-0.54605216f,-0.13540417f,-0.8267362f ) ;
  }

  @Test
  public void test67() {
    TestDrivers.rayTrace(29.348652f,-49.50106f,-38.217957f,37.479282f,89.11015f,47.71817f,-56.599213f,5.6947384f,-58.87535f,50.80027f ) ;
  }

  @Test
  public void test68() {
    TestDrivers.rayTrace(30.856524f,80.53217f,100.0f,-54.820633f,37.42863f,100.0f,81.36601f,-0.016204275f,-0.025200607f,0.99955106f ) ;
  }

  @Test
  public void test69() {
    TestDrivers.rayTrace(-31.184748f,3.7506776f,-15.445067f,-8.792453f,70.948616f,45.92755f,91.35575f,0.44743645f,-0.41694695f,0.13100284f ) ;
  }

  @Test
  public void test70() {
    TestDrivers.rayTrace(32.301468f,-8.285901f,99.999405f,-30.389273f,30.806143f,25.085318f,99.999985f,0.0044006933f,-2.4740276f,5.414467f ) ;
  }

  @Test
  public void test71() {
    TestDrivers.rayTrace(3.253453f,-18.91923f,52.87297f,-12.605209f,-3.988236f,-8.720699f,51.497562f,-1.8615557f,-1.4280859f,-1.4328748f ) ;
  }

  @Test
  public void test72() {
    TestDrivers.rayTrace(-32.988155f,-99.978325f,-42.56967f,-99.97572f,100.0f,-65.20759f,-99.78059f,0.37904984f,0.26402113f,-0.88691264f ) ;
  }

  @Test
  public void test73() {
    TestDrivers.rayTrace(33.43365f,-55.06847f,6.5913157f,-98.02372f,39.97667f,33.66357f,-58.20435f,-0.01796294f,-0.59690434f,0.06179081f ) ;
  }

  @Test
  public void test74() {
    TestDrivers.rayTrace(-33.63635f,75.451294f,100.0f,-100.0f,-2.9955404f,65.177536f,89.80741f,-0.49121585f,-0.5781861f,0.48825592f ) ;
  }

  @Test
  public void test75() {
    TestDrivers.rayTrace(-34.247818f,99.99955f,100.0f,100.0f,100.0f,42.839874f,-100.0f,0.17520306f,-0.0705205f,-1.0254016f ) ;
  }

  @Test
  public void test76() {
    TestDrivers.rayTrace(35.313892f,40.539623f,-72.295906f,-8.073895f,80.47556f,41.703583f,97.07746f,-2.7269478f,34.819515f,-63.755013f ) ;
  }

  @Test
  public void test77() {
    TestDrivers.rayTrace(35.595947f,100.0f,2.526879f,99.94353f,100.0f,99.72649f,79.10205f,0.78644055f,-0.14944379f,-0.5993144f ) ;
  }

  @Test
  public void test78() {
    TestDrivers.rayTrace(36.05836f,25.333652f,-100.0f,19.602448f,54.88308f,34.355797f,-68.10251f,0.8600392f,0.028283833f,0.50944346f ) ;
  }

  @Test
  public void test79() {
    TestDrivers.rayTrace(37.113663f,-52.273365f,-99.95224f,44.94698f,21.870821f,-66.94675f,-80.10227f,-0.24809302f,0.023407413f,-0.9684534f ) ;
  }

  @Test
  public void test80() {
    TestDrivers.rayTrace(39.273457f,61.139286f,-18.01367f,93.07237f,71.553856f,6.4607525f,-1.5594187f,0.51439214f,0.25078017f,-0.56412035f ) ;
  }

  @Test
  public void test81() {
    TestDrivers.rayTrace(-4.049978f,-99.98353f,34.185894f,13.172751f,-8.075591f,-100.0f,20.416481f,1.4250543f,0.15956323f,-1.1841917f ) ;
  }

  @Test
  public void test82() {
    TestDrivers.rayTrace(42.566025f,-58.131763f,-91.48027f,-99.99991f,-44.090816f,-44.09046f,-43.589462f,-0.775753f,-0.8093457f,-1.1778915f ) ;
  }

  @Test
  public void test83() {
    TestDrivers.rayTrace(43.45082f,-100.0f,-100.0f,34.585236f,-100.0f,-100.0f,-66.60698f,-0.1219301f,0.6110559f,0.12877856f ) ;
  }

  @Test
  public void test84() {
    TestDrivers.rayTrace(44.531815f,-57.02662f,-68.41537f,96.86391f,-8.978098f,-52.770412f,12.214597f,0.40440762f,-0.56062776f,-0.72260016f ) ;
  }

  @Test
  public void test85() {
    TestDrivers.rayTrace(44.542698f,47.17915f,68.61902f,-45.37693f,34.567398f,75.850204f,34.60184f,0.36697873f,19.475794f,13.239098f ) ;
  }

  @Test
  public void test86() {
    TestDrivers.rayTrace(-44.715855f,-100.0f,-47.30679f,100.0f,-100.0f,-100.0f,-26.740128f,0.5877558f,-0.5548034f,0.5888432f ) ;
  }

  @Test
  public void test87() {
    TestDrivers.rayTrace(45.125576f,-64.86773f,-1.5370833f,90.67156f,-64.171135f,-30.878977f,2.1269336f,0.36444765f,-0.6283169f,-0.4453648f ) ;
  }

  @Test
  public void test88() {
    TestDrivers.rayTrace(-45.699203f,-6.362603f,-65.87542f,31.925552f,-37.242626f,87.161285f,-7.677849f,-1.8282678f,33.21422f,10.031494f ) ;
  }

  @Test
  public void test89() {
    TestDrivers.rayTrace(45.76803f,16.482399f,-100.0f,99.60675f,-12.780589f,51.60661f,100.0f,0.5523257f,0.20882566f,-0.80704904f ) ;
  }

  @Test
  public void test90() {
    TestDrivers.rayTrace(-46.903244f,-63.1212f,92.74365f,-100.0f,-62.499775f,-100.0f,-11.334782f,-0.42135608f,-0.5371315f,0.730718f ) ;
  }

  @Test
  public void test91() {
    TestDrivers.rayTrace(47.361813f,92.42817f,82.507866f,-100.0f,-33.63271f,-99.41048f,20.875698f,0.08540956f,0.99344647f,-0.075956315f ) ;
  }

  @Test
  public void test92() {
    TestDrivers.rayTrace(48.88695f,10.602547f,-78.67571f,32.340218f,-36.21122f,75.58595f,8.228643f,-0.2623786f,-0.5342628f,0.050171774f ) ;
  }

  @Test
  public void test93() {
    TestDrivers.rayTrace(4.8902116f,-46.357616f,17.482424f,-89.100494f,-10.444667f,13.909774f,-46.32652f,62.67854f,-24.711267f,-38.13284f ) ;
  }

  @Test
  public void test94() {
    TestDrivers.rayTrace(52.466606f,72.57935f,34.417915f,-62.708485f,-20.98263f,90.93589f,-26.993713f,3.94926f,-2.3905168f,0.1768239f ) ;
  }

  @Test
  public void test95() {
    TestDrivers.rayTrace(52.965927f,35.08285f,25.542051f,84.380066f,-34.679115f,12.865273f,1.69925f,-0.3041405f,0.34076416f,-0.8895945f ) ;
  }

  @Test
  public void test96() {
    TestDrivers.rayTrace(-53.341015f,-50.19384f,98.12448f,-14.526279f,38.119377f,69.72875f,32.153934f,-69.847206f,95.75319f,89.56887f ) ;
  }

  @Test
  public void test97() {
    TestDrivers.rayTrace(-53.914692f,-46.721916f,-100.0f,-100.0f,-100.0f,-100.0f,100.0f,0.038727563f,-0.011540384f,0.9991832f ) ;
  }

  @Test
  public void test98() {
    TestDrivers.rayTrace(5.4708056f,-60.330635f,-99.7198f,-79.61994f,-65.34206f,-100.0f,-74.19745f,0.41832095f,-2.501987f,0.27080688f ) ;
  }

  @Test
  public void test99() {
    TestDrivers.rayTrace(55.019737f,12.421227f,15.696844f,-98.20005f,7.147307f,-13.403992f,-65.853874f,0.31899625f,0.19934556f,-0.62082416f ) ;
  }

  @Test
  public void test100() {
    TestDrivers.rayTrace(-55.25788f,57.229195f,-75.3246f,-79.24113f,-18.479206f,10.483666f,98.846016f,-0.5523781f,0.40566248f,-0.7282283f ) ;
  }

  @Test
  public void test101() {
    TestDrivers.rayTrace(57.13299f,100.0f,-34.71796f,-53.693798f,100.0f,-60.630894f,-100.0f,-0.034387775f,0.98649794f,0.16012293f ) ;
  }

  @Test
  public void test102() {
    TestDrivers.rayTrace(-59.252354f,-102.43765f,118.163315f,100.0f,-48.128513f,-199.15909f,95.32305f,0.30856374f,0.9493083f,0.061408184f ) ;
  }

  @Test
  public void test103() {
    TestDrivers.rayTrace(-60.142647f,48.45166f,-16.226597f,36.251278f,15.029156f,87.16609f,-85.35954f,0.15048362f,-0.1121762f,-0.73999053f ) ;
  }

  @Test
  public void test104() {
    TestDrivers.rayTrace(60.390392f,-100.0f,-29.349619f,29.4525f,100.0f,-100.0f,-53.810123f,-0.6860803f,-0.582349f,0.2766612f ) ;
  }

  @Test
  public void test105() {
    TestDrivers.rayTrace(60.80298f,-17.151531f,19.285536f,-3.1423452f,63.419968f,-17.341501f,21.014587f,-52.36657f,-100.0f,68.27115f ) ;
  }

  @Test
  public void test106() {
    TestDrivers.rayTrace(-6.3748612f,-0.40800962f,29.919739f,-52.897785f,45.74555f,-56.872437f,90.7587f,-29.14995f,-51.00567f,-24.566095f ) ;
  }

  @Test
  public void test107() {
    TestDrivers.rayTrace(-6.431458f,20.459858f,-42.255894f,35.037f,31.343685f,23.001305f,-65.41651f,-31.696363f,52.894764f,41.620064f ) ;
  }

  @Test
  public void test108() {
    TestDrivers.rayTrace(64.40742f,36.92852f,7.3199415f,-82.43191f,100.0f,-2.6236432f,-18.381578f,0.05456555f,0.4454885f,0.042215515f ) ;
  }

  @Test
  public void test109() {
    TestDrivers.rayTrace(6.507883f,100.0f,65.703285f,112.06733f,-100.0f,94.61754f,100.0f,0.5568271f,-0.8268387f,0.07929237f ) ;
  }

  @Test
  public void test110() {
    TestDrivers.rayTrace(65.47007f,45.495697f,96.89757f,-35.994392f,-69.72071f,-48.831005f,-5.5597315f,69.43218f,35.53431f,66.63988f ) ;
  }

  @Test
  public void test111() {
    TestDrivers.rayTrace(-6.7533407f,8.178721f,-44.555706f,-18.325815f,-8.549153f,6.223281f,-17.262081f,0.14471482f,-0.0494337f,-0.28953293f ) ;
  }

  @Test
  public void test112() {
    TestDrivers.rayTrace(6.908713f,40.899582f,-38.242382f,-58.56424f,-8.98966f,71.48174f,-99.07174f,36.09413f,58.559895f,92.25726f ) ;
  }

  @Test
  public void test113() {
    TestDrivers.rayTrace(-70.683105f,-50.57932f,65.7581f,29.593395f,52.567265f,3.2172859f,-49.845825f,0.68799454f,0.28956473f,-0.0075796223f ) ;
  }

  @Test
  public void test114() {
    TestDrivers.rayTrace(72.66595f,-100.0f,100.0f,99.700676f,100.0f,-4.030132f,100.0f,-0.034771774f,0.08327535f,-0.99591976f ) ;
  }

  @Test
  public void test115() {
    TestDrivers.rayTrace(-73.24114f,99.48266f,-90.30921f,-58.67798f,-68.84878f,-100.0f,-74.66863f,0.07112696f,0.97667396f,0.20260546f ) ;
  }

  @Test
  public void test116() {
    TestDrivers.rayTrace(75.03565f,-76.941345f,-67.35725f,64.988144f,-74.099884f,-21.55122f,-85.20691f,-52.3963f,40.381794f,-8.480145f ) ;
  }

  @Test
  public void test117() {
    TestDrivers.rayTrace(-75.083374f,46.53995f,-95.77522f,-89.48987f,-6.638436f,19.318695f,-26.212597f,33.235146f,43.40071f,-84.35515f ) ;
  }

  @Test
  public void test118() {
    TestDrivers.rayTrace(-75.904205f,40.397736f,-93.29028f,-78.376015f,8.985135f,-81.23308f,97.36823f,63.28705f,-18.915192f,36.186905f ) ;
  }

  @Test
  public void test119() {
    TestDrivers.rayTrace(-76.35663f,50.093235f,56.250294f,-52.771236f,-47.778755f,-40.439293f,5.7581034f,66.68091f,-61.24072f,-92.13453f ) ;
  }

  @Test
  public void test120() {
    TestDrivers.rayTrace(77.681435f,-68.2416f,6.011682f,59.967304f,92.602684f,-15.576405f,-32.251f,-0.5335809f,-0.105786115f,0.104148954f ) ;
  }

  @Test
  public void test121() {
    TestDrivers.rayTrace(78.35507f,-93.28502f,-100.0f,-117.145805f,-26.695393f,-105.33185f,-49.412655f,0.8390929f,-0.54279286f,-0.043216377f ) ;
  }

  @Test
  public void test122() {
    TestDrivers.rayTrace(78.93286f,-100.0f,99.983826f,99.99678f,100.0f,10.674118f,-93.54885f,0.025468906f,0.060726073f,-0.9978295f ) ;
  }

  @Test
  public void test123() {
    TestDrivers.rayTrace(81.685745f,19.223015f,-14.227381f,31.268677f,53.059334f,13.183402f,-25.262863f,0.10399716f,-0.05028457f,0.17458576f ) ;
  }

  @Test
  public void test124() {
    TestDrivers.rayTrace(8.299539f,36.003258f,100.0f,100.0f,-9.126061f,68.699295f,19.949411f,0.9581069f,0.26964596f,0.096551776f ) ;
  }

  @Test
  public void test125() {
    TestDrivers.rayTrace(8.366574f,100.0f,90.79852f,-100.0f,6.924893f,4.5574365f,-100.0f,0.042212494f,0.19621827f,0.9796512f ) ;
  }

  @Test
  public void test126() {
    TestDrivers.rayTrace(84.06243f,79.84436f,-99.9406f,3.0207286f,70.32001f,54.437515f,-100.0f,-0.6054003f,-1.1144972f,-0.1360519f ) ;
  }

  @Test
  public void test127() {
    TestDrivers.rayTrace(-8.541912f,20.776655f,-66.60673f,-73.53612f,-65.5072f,-10.921382f,-89.690186f,-0.25293934f,0.42805788f,-0.12539282f ) ;
  }

  @Test
  public void test128() {
    TestDrivers.rayTrace(85.58921f,23.895838f,-65.47252f,45.651955f,-5.340515f,43.59423f,-69.59936f,9.68393f,-8.465814f,-0.5479997f ) ;
  }

  @Test
  public void test129() {
    TestDrivers.rayTrace(87.584435f,74.85866f,-91.39698f,-71.12092f,73.97506f,60.271263f,0.8874408f,3.9007363f,35.375206f,-94.3594f ) ;
  }

  @Test
  public void test130() {
    TestDrivers.rayTrace(-89.34244f,32.915813f,75.702126f,70.135704f,-38.012817f,-3.1993546f,31.184414f,0.6988959f,2.8430912f,0.62838376f ) ;
  }

  @Test
  public void test131() {
    TestDrivers.rayTrace(-91.42345f,-100.0f,-100.0f,-100.0f,49.24825f,100.0f,100.0f,0.31611222f,0.513694f,0.7976162f ) ;
  }

  @Test
  public void test132() {
    TestDrivers.rayTrace(-92.17649f,100.0f,100.0f,100.0f,-100.0f,58.95007f,-20.64502f,-0.8704405f,-0.45216408f,-0.19463044f ) ;
  }

  @Test
  public void test133() {
    TestDrivers.rayTrace(-93.07361f,92.02338f,-99.96507f,100.0f,100.0f,30.46878f,-50.625908f,-0.9841634f,-0.16512762f,-0.06446102f ) ;
  }

  @Test
  public void test134() {
    TestDrivers.rayTrace(93.149414f,93.86262f,20.813768f,-15.725097f,-72.65771f,82.44351f,-9.187241f,0.5902355f,0.35893717f,-0.72303957f ) ;
  }

  @Test
  public void test135() {
    TestDrivers.rayTrace(-93.375984f,27.379843f,23.60058f,-58.814896f,-80.01417f,38.98756f,49.94108f,6.948432f,1.4634281f,-44.754562f ) ;
  }

  @Test
  public void test136() {
    TestDrivers.rayTrace(9.348118f,-99.99979f,97.402115f,99.7036f,-65.42427f,-63.606144f,42.398487f,-1.0712286f,-1.8440764f,0.5344528f ) ;
  }

  @Test
  public void test137() {
    TestDrivers.rayTrace(94.13956f,36.693935f,-96.53852f,-99.999214f,-100.0f,-3.8668644f,-100.0f,0.026010403f,-0.9170078f,-0.39802033f ) ;
  }

  @Test
  public void test138() {
    TestDrivers.rayTrace(-94.32792f,25.630398f,-32.922077f,-100.0f,32.383682f,64.38298f,-90.134735f,-0.38242912f,-0.6729684f,0.6331363f ) ;
  }

  @Test
  public void test139() {
    TestDrivers.rayTrace(-9.471973f,100.0f,5.785292f,-33.67274f,-65.995f,-52.306053f,-18.659119f,-0.08604057f,-0.51514953f,0.33359033f ) ;
  }

  @Test
  public void test140() {
    TestDrivers.rayTrace(94.78149f,95.22508f,83.19843f,-42.931507f,57.543167f,71.92465f,98.83618f,-0.087342486f,0.027062308f,0.9958107f ) ;
  }

  @Test
  public void test141() {
    TestDrivers.rayTrace(96.909065f,100.0f,100.0f,-48.707966f,100.0f,100.0f,100.0f,0.06385883f,0.91001993f,0.40961665f ) ;
  }

  @Test
  public void test142() {
    TestDrivers.rayTrace(-97.93081f,-80.73178f,-82.131226f,-38.42132f,-45.902878f,91.57755f,-15.709272f,-57.666737f,64.73062f,-8.204404f ) ;
  }

  @Test
  public void test143() {
    TestDrivers.rayTrace(-99.4151f,-86.06058f,-99.57739f,-0.5137845f,-99.67263f,-86.19862f,-100.0f,-102.05979f,-103.25957f,96.25281f ) ;
  }

  @Test
  public void test144() {
    TestDrivers.rayTrace(-99.717155f,-90.50324f,-55.666313f,-40.379185f,-75.72304f,-49.062496f,-94.4161f,95.27919f,-56.078033f,13.312267f ) ;
  }

  @Test
  public void test145() {
    TestDrivers.rayTrace(99.999825f,42.1923f,-99.79707f,-91.48675f,99.824554f,-95.53901f,57.426743f,-3.5144932f,4.46066f,-5.793525f ) ;
  }
}
