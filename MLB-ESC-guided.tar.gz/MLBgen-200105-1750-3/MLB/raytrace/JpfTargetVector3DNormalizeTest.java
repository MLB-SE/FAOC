import org.junit.Test;

public class JpfTargetVector3DNormalizeTest {

  @Test
  public void test0() {
    TestDrivers.vector3DNormalize(-0.0990217f,0.4932446f,0.6310311f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.vector3DNormalize(-0.11126238f,0.9325329f,-0.31378132f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.vector3DNormalize(-0.2497721f,0.05285597f,-0.96686095f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.vector3DNormalize(-0.70525664f,-0.42822722f,-0.5650084f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.vector3DNormalize(-0.8094778f,0.4393521f,0.3895066f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.vector3DNormalize(1.7919493E-8f,-2.6247963E-7f,-3.9745038E-7f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.vector3DNormalize(-2.07269E-8f,-1.1233591E-7f,-6.5199714E-8f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.vector3DNormalize(-3.1883489E-18f,-1.0416758E-17f,-1.295088E-17f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.vector3DNormalize(3.3943323E-8f,1.2803827E-8f,8.7359E-9f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.vector3DNormalize(-3.7975143E-9f,-6.9321056E-9f,3.1846352E-9f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.vector3DNormalize(-3.801454E-4f,1.19149365E-4f,-4.551238E-5f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.vector3DNormalize(-4.434161E-6f,2.9639039E-6f,-8.5900365E-6f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.vector3DNormalize(47.24284f,-44.507866f,11.558786f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.vector3DNormalize(5.7508963E-15f,-6.9623262E-15f,8.743066E-16f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.vector3DNormalize(7.9955417E-4f,4.417347E-4f,-3.6115496E-4f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.vector3DNormalize(-85.11398f,-58.34858f,-74.86095f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.vector3DNormalize(89.099846f,79.53388f,-5.6872673f ) ;
  }
}
