import org.junit.Test;

public class Testran3Test {

  @Test
  public void test0() {
    ran.ran3(0 ) ;
  }

  @Test
  public void test1() {
    ran.ran3(121 ) ;
  }

  @Test
  public void test2() {
    ran.ran3(166 ) ;
  }

  @Test
  public void test3() {
    ran.ran3(-23 ) ;
  }

  @Test
  public void test4() {
    ran.ran3(26193 ) ;
  }

  @Test
  public void test5() {
    ran.ran3(-26291 ) ;
  }

  @Test
  public void test6() {
    ran.ran3(-27198 ) ;
  }

  @Test
  public void test7() {
    ran.ran3(27287 ) ;
  }

  @Test
  public void test8() {
    ran.ran3(-351 ) ;
  }

  @Test
  public void test9() {
    ran.ran3(412 ) ;
  }

  @Test
  public void test10() {
    ran.ran3(-838 ) ;
  }

  @Test
  public void test11() {
    ran.ran3(-952 ) ;
  }

  @Test
  public void test12() {
    ran.ran3(966 ) ;
  }
}
