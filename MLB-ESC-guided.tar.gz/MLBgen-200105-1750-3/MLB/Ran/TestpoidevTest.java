import org.junit.Test;

public class TestpoidevTest {

  @Test
  public void test0() {
    dev.poidev(0.0,-1 ) ;
  }

  @Test
  public void test1() {
    dev.poidev(-0.4237101937941219,0 ) ;
  }

  @Test
  public void test2() {
    dev.poidev(-0.9999999999999973,0 ) ;
  }

  @Test
  public void test3() {
    dev.poidev(-1.0,0 ) ;
  }

  @Test
  public void test4() {
    dev.poidev(-1.0000000000000018,0 ) ;
  }

  @Test
  public void test5() {
    dev.poidev(-1.0,-1 ) ;
  }

  @Test
  public void test6() {
    dev.poidev(-1.0,594 ) ;
  }

  @Test
  public void test7() {
    dev.poidev(-1.0,67 ) ;
  }

  @Test
  public void test8() {
    dev.poidev(-1.0,-679 ) ;
  }

  @Test
  public void test9() {
    dev.poidev(-1.0,-723 ) ;
  }

  @Test
  public void test10() {
    dev.poidev(-2.000000000000001,0 ) ;
  }

  @Test
  public void test11() {
    dev.poidev(-293.0,992 ) ;
  }

  @Test
  public void test12() {
    dev.poidev(3.0,-1 ) ;
  }

  @Test
  public void test13() {
    dev.poidev(-319.0,-1 ) ;
  }

  @Test
  public void test14() {
    dev.poidev(4.0,-332 ) ;
  }

  @Test
  public void test15() {
    dev.poidev(5.0,632 ) ;
  }

  @Test
  public void test16() {
    dev.poidev(-509.0,728 ) ;
  }

  @Test
  public void test17() {
    dev.poidev(5.505395742489625,0 ) ;
  }

  @Test
  public void test18() {
    dev.poidev(58.25289613926313,0 ) ;
  }

  @Test
  public void test19() {
    dev.poidev(59.68237450661175,0 ) ;
  }

  @Test
  public void test20() {
    dev.poidev(64.67306517249483,0 ) ;
  }

  @Test
  public void test21() {
    dev.poidev(-649.0,-1 ) ;
  }

  @Test
  public void test22() {
    dev.poidev(-65.55381201016593,0 ) ;
  }

  @Test
  public void test23() {
    dev.poidev(8.0,609 ) ;
  }

  @Test
  public void test24() {
    dev.poidev(-89.4455847602164,0 ) ;
  }

  @Test
  public void test25() {
    dev.poidev(9.0,0 ) ;
  }

  @Test
  public void test26() {
    dev.poidev(9.0,-167 ) ;
  }

  @Test
  public void test27() {
    dev.poidev(-907.0,0 ) ;
  }

  @Test
  public void test28() {
    dev.poidev(-92.0,-156 ) ;
  }

  @Test
  public void test29() {
    dev.poidev(-99.0,-29 ) ;
  }
}
