import org.junit.Test;

public class TestgamdevTest {

  @Test
  public void test0() {
    dev.gamdev(1,0 ) ;
  }

  @Test
  public void test1() {
    dev.gamdev(1,-507 ) ;
  }

  @Test
  public void test2() {
    dev.gamdev(197,0 ) ;
  }

  @Test
  public void test3() {
    dev.gamdev(203,534 ) ;
  }

  @Test
  public void test4() {
    dev.gamdev(207,-351 ) ;
  }

  @Test
  public void test5() {
    dev.gamdev(28,0 ) ;
  }

  @Test
  public void test6() {
    dev.gamdev(3,138 ) ;
  }

  @Test
  public void test7() {
    dev.gamdev(37,-1 ) ;
  }

  @Test
  public void test8() {
    dev.gamdev(4,0 ) ;
  }

  @Test
  public void test9() {
    dev.gamdev(-413,0 ) ;
  }

  @Test
  public void test10() {
    dev.gamdev(-461,0 ) ;
  }

  @Test
  public void test11() {
    dev.gamdev(481,-301 ) ;
  }

  @Test
  public void test12() {
    dev.gamdev(-487,0 ) ;
  }

  @Test
  public void test13() {
    dev.gamdev(5,0 ) ;
  }

  @Test
  public void test14() {
    dev.gamdev(6,0 ) ;
  }

  @Test
  public void test15() {
    dev.gamdev(723,0 ) ;
  }

  @Test
  public void test16() {
    dev.gamdev(95,-1 ) ;
  }

  @Test
  public void test17() {
    dev.gamdev(989,334 ) ;
  }
}
