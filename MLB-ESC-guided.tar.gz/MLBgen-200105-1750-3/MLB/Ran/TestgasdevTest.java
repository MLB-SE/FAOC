import org.junit.Test;

public class TestgasdevTest {

  @Test
  public void test0() {
    dev.gasdev(0 ) ;
  }

  @Test
  public void test1() {
    dev.gasdev(-1 ) ;
  }

  @Test
  public void test2() {
    dev.gasdev(1 ) ;
  }

  @Test
  public void test3() {
    dev.gasdev(23 ) ;
  }

  @Test
  public void test4() {
    dev.gasdev(-480 ) ;
  }

  @Test
  public void test5() {
    dev.gasdev(492 ) ;
  }

  @Test
  public void test6() {
    dev.gasdev(-505 ) ;
  }

  @Test
  public void test7() {
    dev.gasdev(-653 ) ;
  }

  @Test
  public void test8() {
    dev.gasdev(81 ) ;
  }

  @Test
  public void test9() {
    dev.gasdev(-850 ) ;
  }
}
