import org.junit.Test;

public class TestbnldevTest {

  @Test
  public void test0() {
    dev.bnldev(0.0,235,0 ) ;
  }

  @Test
  public void test1() {
    dev.bnldev(0.0,25,0 ) ;
  }

  @Test
  public void test2() {
    dev.bnldev(0.0,29,0 ) ;
  }

  @Test
  public void test3() {
    dev.bnldev(0.0,54,0 ) ;
  }

  @Test
  public void test4() {
    dev.bnldev(1.0,226,0 ) ;
  }

  @Test
  public void test5() {
    dev.bnldev(1.0,372,0 ) ;
  }

  @Test
  public void test6() {
    dev.bnldev(1.0,-435,0 ) ;
  }

  @Test
  public void test7() {
    dev.bnldev(-105.0,-177,0 ) ;
  }

  @Test
  public void test8() {
    dev.bnldev(1.0,54,0 ) ;
  }

  @Test
  public void test9() {
    dev.bnldev(1.0,-556,0 ) ;
  }

  @Test
  public void test10() {
    dev.bnldev(1.0,-870,0 ) ;
  }

  @Test
  public void test11() {
    dev.bnldev(1.0,-932,0 ) ;
  }

  @Test
  public void test12() {
    dev.bnldev(1.0,997,0 ) ;
  }

  @Test
  public void test13() {
    dev.bnldev(1.1794872657892768,0,0 ) ;
  }

  @Test
  public void test14() {
    dev.bnldev(212.0,19,144 ) ;
  }

  @Test
  public void test15() {
    dev.bnldev(-252.0,681,0 ) ;
  }

  @Test
  public void test16() {
    dev.bnldev(26.0,20,-727 ) ;
  }

  @Test
  public void test17() {
    dev.bnldev(-27.0,-424,0 ) ;
  }

  @Test
  public void test18() {
    dev.bnldev(-36.50102018097623,0,0 ) ;
  }

  @Test
  public void test19() {
    dev.bnldev(426.0,967,0 ) ;
  }

  @Test
  public void test20() {
    dev.bnldev(-433.0,958,0 ) ;
  }

  @Test
  public void test21() {
    dev.bnldev(436.0,-1,0 ) ;
  }

  @Test
  public void test22() {
    dev.bnldev(-464.0,24,-317 ) ;
  }

  @Test
  public void test23() {
    dev.bnldev(47.47984370855542,0,0 ) ;
  }

  @Test
  public void test24() {
    dev.bnldev(-492.0,465,0 ) ;
  }

  @Test
  public void test25() {
    dev.bnldev(554.0,13,0 ) ;
  }

  @Test
  public void test26() {
    dev.bnldev(-575.0,19,0 ) ;
  }

  @Test
  public void test27() {
    dev.bnldev(-576.0,25,0 ) ;
  }

  @Test
  public void test28() {
    dev.bnldev(580.0,-89,0 ) ;
  }

  @Test
  public void test29() {
    dev.bnldev(-597.0,-205,0 ) ;
  }

  @Test
  public void test30() {
    dev.bnldev(612.0,25,0 ) ;
  }

  @Test
  public void test31() {
    dev.bnldev(652.0,-267,0 ) ;
  }

  @Test
  public void test32() {
    dev.bnldev(-729.0,-603,0 ) ;
  }

  @Test
  public void test33() {
    dev.bnldev(-75.0,3,862 ) ;
  }

  @Test
  public void test34() {
    dev.bnldev(822.0,-317,0 ) ;
  }

  @Test
  public void test35() {
    dev.bnldev(-847.0,-588,0 ) ;
  }

  @Test
  public void test36() {
    dev.bnldev(847.0,762,0 ) ;
  }

  @Test
  public void test37() {
    dev.bnldev(-927.0,-555,0 ) ;
  }

  @Test
  public void test38() {
    dev.bnldev(995.0,874,0 ) ;
  }
}
