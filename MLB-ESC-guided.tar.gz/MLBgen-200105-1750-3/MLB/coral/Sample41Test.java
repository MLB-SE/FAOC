import org.junit.Test;

public class Sample41Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark41(0.5248746282624277,-0.24938125286880602 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,1.9999999999999998 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0000000000000004 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark41(13.608790444605617,-73.97814080188054 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark41(-3.9045383128112077,19.1499577490218 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark41(-4.93965665442331,33.94926114631244 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark41(5.925142544460854,29.182171627719192 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark41(6.351228380790431,33.98687356416741 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark41(-7.169772742830842,58.57541392667094 ) ;
  }
}
