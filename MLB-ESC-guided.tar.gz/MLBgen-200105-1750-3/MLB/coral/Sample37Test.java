import org.junit.Test;

public class Sample37Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark37(-17.125736123734356,-43.83518434344449,-20.649087510883476 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark37(-28.294991380720006,91.4387957357545,45.51057492413037 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark37(-41.79715981165398,-16.97690414822364,-7.978088777654079 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark37(-53.564363482321454,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark37(56.548766829044794,0,0 ) ;
  }
}
