import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(-0.7622881601107423,-82.88579437208105,79.505977009363,100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(0.7866453780985836,48.85585868370325,-59.82610113002591,37.097781845733806 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(-0.9587417655019266,-52.294984715845416,107.28306954827954,61.6619737926552 ) ;
  }
}
