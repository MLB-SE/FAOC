import org.junit.Test;

public class Sample44Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark44(-100.0,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark44(10.53471549262919,38.23011360646325 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark44(16.69331571699344,49.30328484923902 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark44(2.1898240224261207,2.1898240224261207 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark44(26.72713073203225,0.4037391263691035 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark44(76.60503021089104,13.207261686139589 ) ;
  }
}
