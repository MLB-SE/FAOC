import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,36.503949009047744 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-3.7640597264473996 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(0.4420529442883822,2.098006269129335,-74.5641354598653,77.10420784347875 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(0.5627586235589099,-4.9E-324,30.40375996727322,-28.700670512398247 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(0.7330932261102664,4.98230254306862,4.265890457991629,-3.3911058700620605E-21 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(0.8516764483336227,11.04111427413501,10.189437825787085,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(0.9804725849124508,99.98930107202085,99.00822167940053,-5.901458371950495E-4 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(100.0,-2.6171253065622118,100.0,94.09566926155298 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(100.0,-39.45225482086669,100.0,-3.8196092547887197 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(1.0215000544448096,-86.81172109952682,-87.7396214264455,0.0935997275263394 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(1.0329689341944663,63.17546442967615,64.20843336387063,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(11.06032767971206,15.8067747525225,-80.78402989127906,-81.3729892437162 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(20.39360404206566,-46.073176954617935,100.0,-0.5855586019594057 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(-21.4672441900058,60.559902741347116,6.396631384894931,39.825957531735355 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(2.2473259407643837,43.95278699331104,65.88999139073333,-61.77225913280247 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(2.352675826624681,-4.9E-324,33.47698975605287,-30.814619796561974 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(26.79114006487933,-8.463409382825859,17.00943438543139,26.95018791223525 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(3.3649847988333785E-30,1.310665522886623E-15,-5.767136189631295E-16,1.8873791418627724E-15 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(38.05479586550712,67.86904301802466,67.8710023014439,38.05675514892635 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(3.975178241066746E-5,14.02450785123295,14.024547603015362,-6.162975822039155E-33 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(42.8411938524705,68.93751416454265,-9.995615566094514,-57.80252109536646 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(43.17392822668339,-5.08485571679735,-40.83216269292021,-7.425484434873482 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(43.582554469146345,-3.9157192247954384,17.30580464827905,22.361030596071856 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(5.175187686941728,2.0720051008499527,-21.161935619803707,28.409413904739495 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark62(-62.48750874729756,-95.08557140600686,-83.09420957304229,-58.08098316320729 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark62(64.2030029496515,2.4308653429145085E-63,-74.71051032378027,-100.0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark62(70.46151978507659,0.0,83.37759775882176,-20.965368397355945 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark62(77.26546131140918,-56.991700820443626,63.31793170963624,94.70669472505261 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark62(80.24359877463866,68.11678733324155,-99.22627747480703,19.915611529073246 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark62(83.5707350331632,42.69378990117255,32.3181974839263,-48.0321268008645 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark62(-91.77868185182687,92.09225959238671,-26.198310694690413,-83.5464617096803 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark62(95.33217784556368,34.27987921424585,91.86462096668146,59.55897254043444 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark62(97.20873037563494,-73.42476424683306,92.1894356958017,-1.323922948514305 ) ;
  }
}
