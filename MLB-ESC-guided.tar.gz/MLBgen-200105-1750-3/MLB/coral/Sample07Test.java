import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark07(0,-1.950197822498282,0,74.31206569011627 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(0,52.314510433156926,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(0,61.00317366550329,0,20.549293783204035 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(0,-63.879050623997266,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(-23.53245972226376,-85.5273457868147,0.3800290606528508,73.88416253004729 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(23.724183877324975,76.99992988926488,84.4951429833186,81.32876200714125 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(-37.22938223589962,61.51122937032713,76.76009483484444,15.759358999463501 ) ;
  }
}
