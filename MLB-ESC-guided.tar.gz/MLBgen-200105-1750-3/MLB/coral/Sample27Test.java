import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(-32.898812416083274,60.50358611652504,97.87617825080338 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(34.72653769840874,22.41577482546996,-100.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(-35.52754827649877,79.91846237662023,-1.0469837050686976 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(47.68324643931169,10.630532073449459,-41.30766900776257 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(59.01689945159479,58.67349632084945,23.024984771696218 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(-68.06260244174801,-15.888322846898362,-77.0845551972579 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark27(-8.003410552124608,-13.650059928708146,93.77879615879036 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark27(83.24644017082693,86.11084981183846,46.66853826523615 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark27(91.81825674418882,-19.42676720211388,-60.9439099282956 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark27(99.56101913636982,-72.79055891620018,8.050598529939009 ) ;
  }
}
