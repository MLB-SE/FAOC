import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(39.519482643966874,-82.45534778868664,-42.93586514471976 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(65.76219529078662,65.97708768311679,-35.434087637532 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(-93.88543152297675,14.724825679571723,-55.81433099749547 ) ;
  }
}
