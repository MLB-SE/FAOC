import org.junit.Test;

public class Sample91Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark91(-64.50538780986469,-35.65756217664901 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark91(85.13028101249404,26.76923350873885 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark91(-89.97335545437981,2.0087611538656027 ) ;
  }
}
