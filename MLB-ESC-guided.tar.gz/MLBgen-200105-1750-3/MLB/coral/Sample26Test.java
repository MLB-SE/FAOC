import org.junit.Test;

public class Sample26Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark26(100.0,100.0,100.0,94.76769531801358,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark26(-11.758065363707672,24.30308800327063,97.49739541695297,0,-77.50661948438014 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark26(-20.306165425991097,88.6128404439664,19.88647650269189,0,-98.68586454976673 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark26(20.49937174457932,-99.95637682352636,71.5221380816229,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark26(27.079239577718045,20.11450278636659,24.20172319901632,-6.547844671015857,17.091551401318227 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark26(30.26427131548336,72.4528090762766,-92.81624953822734,-75.41381205719897,-25.336169782134846 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark26(-30.659102247836174,7.430202140889918,79.94396013417503,-3.9238712571247873,38.48106352161932 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark26(36.116326568781574,86.79072047591129,-28.565686835674427,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark26(-47.92402767010371,-65.26084073722063,47.05167315119928,2.230425705051104,49.553228205838735 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark26(-48.281909810238616,-25.97035381348616,39.48029125313704,93.69607703253403,62.62876264876309 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark26(-58.1674097175612,-37.23413447228068,-92.63807332428411,-77.05082630449056,-92.79858583977467 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark26(66.49226451302799,-90.3627361911475,51.47255146559405,60.457365030147244,53.884797509611914 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark26(68.48487043047034,-6.160941180466247,-27.36450836778718,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark26(87.9377140610066,-31.913849050026727,96.38322645742184,0,0 ) ;
  }
}
