import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,3.4696831532455406,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0.39110595269625525,67.8417751447999,31.199218515420057,51.70096726453792,91.54656039526603 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(0,-98.62306128651363,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(-31.728866354819374,46.914194732284585,-76.16053023886265,-15.581088976279702,-58.05531391213938 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(56.32494750121768,60.300429279318564,-20.82964927169644,-6.005041916700833,1.8863555491794841 ) ;
  }
}
