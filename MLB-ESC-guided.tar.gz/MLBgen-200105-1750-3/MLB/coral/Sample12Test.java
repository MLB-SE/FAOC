import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(0.09648808980358581,-0.8460147620916985,-65.26882598179584,-77.04038411627138 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(0.31321337603644395,0.9907457106347124,1.063089829775322,-99.38879961568357 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(-0.8868711145657555,0.9108804848325178,-8.617656177232945,39.503451059468205 ) ;
  }
}
