import org.junit.Test;

public class Sample30Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark30(100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark30(152.10830647104584 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark30(45.09300133284083 ) ;
  }
}
