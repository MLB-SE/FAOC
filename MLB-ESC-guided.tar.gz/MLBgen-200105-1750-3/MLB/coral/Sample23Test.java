import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(100.0,91.37634733326128,0,-54.32755346432658 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(-12.279770045647028,-43.770773687030236,7.130762293564642,-22.96773212426018 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(-22.817842236768655,-96.30035603311566,-0.28748795466555066,-4.375197890513547 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(29.18343272789187,-45.562539210260546,0,17.182103036650005 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(38.00242112513405,45.153804525923505,24.578756546630373,-47.04316843392444 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(50.27540235279832,-76.97397995619858,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(5.84689045018267,-32.959362958031676,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark23(75.81953430019797,-65.79922068907626,-60.347693650285954,-27.946948876020826 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark23(98.68766631975512,-23.477581022777688,-44.36276127932396,-36.86908626232657 ) ;
  }
}
