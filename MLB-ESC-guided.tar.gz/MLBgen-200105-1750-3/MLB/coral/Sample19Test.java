import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(0.5328158486990162,-83.6646512057488,-0.5563140341892705 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(0.6561640995538291,76.43099165773762,0.8455011177994152 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(0.9555465544046373,58.35070595964049,-0.5144527953148099 ) ;
  }
}
