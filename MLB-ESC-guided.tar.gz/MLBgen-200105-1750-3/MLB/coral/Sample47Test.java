import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(11.670029894184239,94.9187336844777,0.07619490882460411 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(-71.05879011145382,-74.28629280353661,68.5113664864846 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(-9.944460698037126E-16,-100.0,-100.0 ) ;
  }
}
