import org.junit.Test;

public class Sample81Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark81(-1.2381994228525735,-1.6982522120090104 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark81(-41.46216520739618,2.1943533316406842 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark81(6.343913865495182,-64.38314283714455 ) ;
  }
}
