import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(-0.06110754915640371,10.48618914973612 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(22.285192013563986,-3.4897833553025492 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(23.567978578618252,-97.31931371272815 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(-27.61527584648173,-52.02879099739168 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(-41.80616751942604,-45.68915178591855 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(59.623769012312664,-60.260199469896094 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark20(76.05728172198144,-100.0 ) ;
  }
}
