import org.junit.Test;

public class Sample84Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark84(1.0,0.9999999999999998,1.0,1.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark84(1.0,0.9999999999999999,1.0,1.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0000000000000004,1.0,1.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,0.5657684997771868,0.3200939953401286 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,0.9999999999999998 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,0.9999999999999999 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,1.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,1.0000000000000004 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.2637509926496742,1.5970665714230368 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.8718757022933517,99.99999999999997 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,-4.66962909313383,21.805435867441876 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,94.02299994295976,-35.844821617534464 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark84(2.23550733533962,4.997493046357249,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark84(3.4136370800310374,11.652918114162826,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark84(-7.197490022416233,93.49435400537575,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark84(-82.21521039759602,64.23717267793307,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark84(-9.777122613329794,95.59212659608482,0,0 ) ;
  }
}
