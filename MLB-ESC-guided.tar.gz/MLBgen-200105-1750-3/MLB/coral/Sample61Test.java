import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,1.4758347122547235 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,-65.82679019567286 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(100.0,-67.94022137146274,89.91547181364635,-40.461165395571676 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(1.19117138699903,-1.58E-322,17.436217226606523,-14.404096424983816 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(11.929484759306774,64.97270687355231,40.415675828888624,41.951414661753375 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(16.072834443636125,28.153956513089526,4.260859053246719,37.476937636959065 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(16.520134104031243,19.53468315152446,-97.57550742577166,42.151792948361646 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(21.813768024667148,0.0,-19.292585810896572,7.241857734030383 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(27.482908440175212,-2.436402271827774,-5.80445253810953,9.465311586661851 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(3.5051806739495053,-5.3510970434775465E-197,38.26108517357285,-33.68614502162056 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(40.66010923387071,-36.43694593336979,-1.3429053087010914,27.315848081232346 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(40.99927368443208,-21.029577878665123,-45.488213508216504,65.45790931398346 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(4.272438356774059,-3.3735033418337674E-80,61.39955438253969,-52.12017376970706 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(4.405896829904293,32.366473033400354,67.93796573921009,-52.1011507203663 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(4.706678494350483,-41.98502199959084,89.67164613448404,-0.11210375200937972 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(48.46519356214016,8.881784197001252E-16,-71.21516708077472,-54.849633636029814 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(5.080010553436879,-2.0E-323,100.0,-79.08937941757375 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(-51.35342361559891,52.552571950412585,-15.872021402438563,-13.236078424696997 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(54.67812064219666,24.25346806279407,-81.69377476136572,-71.83939287540551 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(63.5591934713554,-37.42592295237106,47.88383945907799,-5.700782757108129 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(64.60259901607117,-81.33776788739544,64.84329542919306,-93.01996714183322 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark61(93.2231994614377,-4.10351685774846,-86.62278651190832,-92.216655835116 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark61(9.807211623329607,88.06827245679244,-95.78198080885517,6.998182220176034 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark61(99.8936984101901,24.722986186586255,-60.575667511965506,16.841552003010477 ) ;
  }
}
