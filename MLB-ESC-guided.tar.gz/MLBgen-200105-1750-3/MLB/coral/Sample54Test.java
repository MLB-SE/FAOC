import org.junit.Test;

public class Sample54Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark54(27.781881009116717,-30.177135224524434,-87.1930048879483 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark54(36.40849650779805,-2.2670730612016,32.0558900763682 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark54(42.85395491378987,68.48109622258329,66.60838538604541 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark54(91.23871265829854,3.9242139061150425,-14.090855120147381 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark54(93.25749538812241,12.87915933117128,-41.72949534043624 ) ;
  }
}
