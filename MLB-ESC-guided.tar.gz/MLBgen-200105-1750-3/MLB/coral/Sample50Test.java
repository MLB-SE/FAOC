import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(10.306797056618478,29.898303672883543 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(21.182809273638153,21.844914907432486 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(23.594351655724335,26.40564834427566 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(2.3698567636159282,8.620571283343992 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(25.888073037391564,82.41847618286042 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(3.366196470871996E-11,5.801869180412761E-6 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(38.08867283641203,90.33334444327124 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(5.1993662887265515,6.691982828158472 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(5.522521302678712,18.52252130267871 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(56.906578781771884,73.1257433752171 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(-65.03986968781433,0.31666227655475154 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(7.623619617536104E-13,1.886415251860193E-7 ) ;
  }
}
