import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(22.117488702699593,49.29310690533392 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(4.586048852813651,58.33039851881347 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(58.96952601371589,45.69052592791081 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(-61.56871893860401,-6.479132085206459 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(-70.6225618720387,-32.148797972426564 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(81.68090757471077,94.26833230856053 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark21(84.89481151206543,-70.10731487848334 ) ;
  }
}
