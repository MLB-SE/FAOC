import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark05(35.50758197925694,-16.338472558707124,32.13924698987711 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(-67.4109910962358,-40.43366384565126,-67.13008564738897 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(-88.24471531724677,64.00488868681157,-37.08782614335313 ) ;
  }
}
