import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark53(11.420701664120799,-51.06347755810879,16.539832496988808 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(20.943313933597807,78.71968179655556,-81.00169197543651 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(23.28667530063822,37.72150389197288,-37.02283938737339 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark53(25.25235226335876,-49.84317440989263,83.96323884817664 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark53(39.130892328863496,2.7695397311977237,81.45354314394508 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark53(47.523995859994926,-79.96180979323593,-75.66174418008116 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark53(50.96059432714091,-55.32097344896349,84.7576044625026 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark53(54.72534134674851,8.673073971775864,59.46345458654122 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark53(57.97946020178145,97.38553100949588,69.12121899924753 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark53(58.255424069398245,2.7790148496131373,59.30662636020653 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark53(61.82448458075501,-88.80853956186922,-6.343068091066556 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark53(7.430457691531903,39.32087524189612,26.08622032736052 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark53(81.3656416391083,-48.94925852057921,-22.279877792456105 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark53(82.75753990459413,99.18600380079789,87.86069870812463 ) ;
  }
}
