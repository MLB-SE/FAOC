import org.junit.Test;

public class Sample43Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark43(0.5690593910019999,0.5690593910019999 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark43(17.40068812778067,1.2027871422880736 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark43(1.8286378629788231,29.020711437435466 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark43(20.302580591865805,2.0032716372984254 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark43(20.3860938310457,22.209032972309714 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark43(2.3678074191662972,31.371490042248325 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark43(30.74665691655477,62.66036153270963 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark43(3.305943238406571,3.305943238406571 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark43(7.691021271111494,59.151808192689465 ) ;
  }
}
