import org.junit.Test;

public class Sample46Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark46(0.0,0,-86.53266552737595,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark46(100.0,0.9999999999999978,60.677496067931436,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark46(100.0,1.0000000000000002,12.34949961266453,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark46(100.0,1.0000000000000002,12.907974710624647,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark46(100.0,71.56967369059547,-39.800240162116395,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark46(18.97589672306634,57.05827031793052,86.63008638573439,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark46(1.9721522630525295E-31,25.630858955658734,1.0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark46(25.153532933598598,0.9999999999999999,13.503388769788899,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark46(30.386141829265387,0.9999999999999999,4.140094187713503,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark46(-32.45653486015439,0,19.34501151818087,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark46(3.467947796775341E-18,99.99999941927204,6.516411252964495E-16,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark46(3.469446951953614E-18,10.335580015561414,1.0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark46(39.448555754720985,1.0,27.137707514528984,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark46(39.76164894894923,1.0000000000000016,100.0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark46(47.392025717588865,68.20509829483956,4.885503557931287,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark46(57.987942599067196,0,85.04148591410825,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark46(64.57576895901445,-86.88617741097832,18.577334384269406,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark46(-648.5477617183908,0,8.293747173120508,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark46(66.78322937047793,0,98.6414663109166,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark46(67.75948611390851,33.86283166755214,3.2862626523064478,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark46(-74.91776745440984,0,0.6299261323212448,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark46(9.860761315262648E-32,100.0,1.0,0 ) ;
  }
}
