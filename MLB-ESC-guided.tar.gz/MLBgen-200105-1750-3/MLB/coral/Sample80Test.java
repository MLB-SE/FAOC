import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(-0.1549206461880034,10.682376344981677 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(18.4407853942528,-56.392435973972724 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(-5.860054868863614,-9.060835113931162 ) ;
  }
}
