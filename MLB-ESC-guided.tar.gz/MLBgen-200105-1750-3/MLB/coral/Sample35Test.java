import org.junit.Test;

public class Sample35Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark35(-34.594525381353634,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark35(-56.21792673384611,-43.17458195231969 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark35(-65.97354831130808,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark35(76.9690200153477,-43.236308751541344 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark35(83.25220532575904,-59.049062399027584 ) ;
  }
}
