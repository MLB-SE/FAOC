import org.junit.Test;

public class Sample42Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark42(0.4664057953136112,0.42492106260939344 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark42(1.0,-26.215174514867314 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark42(1.365331556265515,1.365331556265515 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark42(18.069533429392592,0.8946451640616875 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark42(19.590803655072747,13.706326160202792 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark42(37.833080707627886,78.11750992854095 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark42(46.79044596757066,77.27186121154531 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark42(65.30552943132042,67.26036720533085 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark42(9.774385458535889,10.0 ) ;
  }
}
