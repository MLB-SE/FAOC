import org.junit.Test;

public class Sample39Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark39(12.209207742635726,7.984859652577469E-18 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark39(87.19818046591644,80.37488911688587 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark39(89.4008079914401,-96.09059428825968 ) ;
  }
}
