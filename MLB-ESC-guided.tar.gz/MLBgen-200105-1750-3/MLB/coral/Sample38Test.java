import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(26.311552768455435,16.894453746391733 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(-3.6047810746252367,-54.62516432724196 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(99.10308810600642,-34.880047447814235 ) ;
  }
}
