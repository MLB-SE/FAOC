import org.junit.Test;

public class Sample36Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark36(-18.167988315560706,-30.589111711356182,6.219170097074549 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark36(21.290853625159542,49.533250282133025,30.295971557830825 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark36(-62.83185039062302,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark36(89.29702921600747,-37.4856048110747,3.01825722654263 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark36(-91.9724317291083,0,0 ) ;
  }
}
