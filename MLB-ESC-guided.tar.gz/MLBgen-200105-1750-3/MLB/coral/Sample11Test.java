import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(-0.3966980820565311,21.418198135254457,7.484447983516091,83.83735886825386 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(-0.9627422854266712,45.66927402661648,20.25866751249565,-26.778105629045683 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(-0.963805648534958,-73.15589642324,-67.16348461805984,25.859761381043494 ) ;
  }
}
