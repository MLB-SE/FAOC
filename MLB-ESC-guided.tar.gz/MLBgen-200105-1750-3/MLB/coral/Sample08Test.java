import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(48.02801290838539,-67.28296165783807,-57.4046008273362 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(81.81280651296447,-16.13840299275786,-82.38399778956851 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(-89.75497687179842,38.22703885678403,-63.44574705821592 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark08(98.77397889869347,52.55740194145636,-9.302807292810044 ) ;
  }
}
