import org.junit.Test;

public class Sample51Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark51(0.0499338638435576,0.22345883737366928 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark51(0.3394537094913451,78.78290428046307 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark51(0.8043203538587136,38.73888601668867 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark51(10.247661898405283,39.75233810159472 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark51(10.523298122607997,77.70845440181105 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark51(1.2568329884985638,21.51947839268261 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark51(15.955170575696258,30.96389406818784 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark51(-29.960882620702733,50.08509093805992 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark51(50.99017022457778,81.3147347736014 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark51(7.107535438127082,42.89246456187291 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark51(9.077075498907305,30.401410693481466 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark51(9.792313878168035E-12,3.129095400420784E-6 ) ;
  }
}
