import org.junit.Test;

public class Sample25Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark25(100.0,-100.0,100.0,-62.48909410742274,51.15076062756922 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark25(-100.0,100.0,-85.30707651815815,-66.36864487072256,-91.88658497991158 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark25(11.702424035110752,-38.43717662563868,85.98777431579146,51.10263560090203,-96.37259291484406 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark25(-2.349861436823872,-10.818415537758531,-13.64968323211022,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark25(23.99875804662055,-80.63813483208746,-87.52658334844472,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark25(-48.21560257767034,90.37111058775574,-72.08154178118973,10.689804224109803,-2.125498487264164 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark25(-57.47287534149372,56.574308810341,15.993823472808476,21.138670910480545,87.47335016717521 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark25(73.72925706857484,20.382402613646676,-89.68674675152934,-42.50844653226582,-40.215707454535796 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark25(80.04650493359557,-52.36936734603215,-50.885932606919184,-18.05069770904366,-28.4756533036645 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark25(87.94464166952879,83.93141372943771,-15.614769720364245,22.439307092435296,78.20668092711183 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark25(-88.53201864388285,-32.28650594591616,-73.66405712930182,0,-34.930658334305534 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark25(-89.85055225230207,-32.990997482629155,-157.50920125263468,0,-75.38967445181045 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark25(93.72771285578291,92.04381153658288,-52.66409989519283,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark25(-93.87563911580361,-24.655054233052297,-75.90078193214697,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark25(95.16140437535812,79.41245716557322,-71.4989182393917,5.591809751615995,61.836582977051734 ) ;
  }
}
