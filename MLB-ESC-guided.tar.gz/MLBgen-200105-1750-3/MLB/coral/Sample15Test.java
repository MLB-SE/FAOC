import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(0.8744173021494532,-94.00639403807534,75.3836528772735,67.17341316201177 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(0.9841626917136816,35.21418885058861,-96.86059471651217,8.001313659274897 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(-0.991206546610357,35.997965768804505,81.39127659076658,-15.649750365370977 ) ;
  }
}
