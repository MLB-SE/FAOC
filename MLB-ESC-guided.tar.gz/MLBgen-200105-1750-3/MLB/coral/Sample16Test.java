import org.junit.Test;

public class Sample16Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,10.067769544951986 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,-34.44310136234094 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark16(-10.009672125309635,15.194627364955892,88.4168329591956,16.985428141348407,-48.25152330248619 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark16(-20.608972271151544,15.573315441333492,65.812368254545,-92.37062482753694,70.6093592667959 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark16(87.36271498301929,14.09443833460206,24.137899653822316,-62.113702203716855,19.068304142780292 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark16(98.3777994098517,14.960285579576563,207.86568824570392,-71.59884626239786,48.10629739549492 ) ;
  }
}
