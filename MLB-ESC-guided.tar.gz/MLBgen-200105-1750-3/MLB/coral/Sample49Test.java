import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(1.0052143754737592,48.994785624526244 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(1.3156086592045274E-7,1.1802694704006714E-9 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(-21.902272775944127,45.51446054575473 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(27.419522103944033,78.9910758682106 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(4.181365559548027,11.365516120902413 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(45.417129094579366,75.16240041793475 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(65.55951144488611,82.19135689175562 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(7.696619916193815E-12,2.7742782630735986E-6 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(94.04795849084383,94.35781514006248 ) ;
  }
}
