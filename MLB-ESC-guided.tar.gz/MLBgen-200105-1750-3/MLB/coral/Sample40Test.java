import org.junit.Test;

public class Sample40Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark40(-3.166736305932133,52.806571700549384 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark40(-5.524024995830686,36.0388771503929 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark40(6.830001162832161,-92.84505902500383 ) ;
  }
}
