import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(11.809202970048503,26.35611256638886,76.85643567710062,96.47707682535881,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(-1.5387116157771974E-10,-100.0,-100.0,-100.0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(-2.600025090305173E-7,-100.0,-100.0,100.0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark79(2.902335550408384E-9,-100.0,100.0,100.0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark79(5.512982687207723E-9,-100.0,100.0,-100.0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark79(7.355634619195827E-9,100.0,-132.78455122727507,-2.8424498492939563,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark79(-8.032976198613353E-6,20.28574337769015,100.0,-100.0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark79(8.179111765491609E-9,-100.0,100.0,-32.366781008291895,0 ) ;
  }
}
