import org.junit.Test;

public class Sample72Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark72(0.6457266540760287,-50.96670796922671,-45.4497939000124,-43.2486750810684,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark72(0.6592888471677298,-87.51634426961799,-93.91233833527788,49.910055617596555,100.0,-20.801059378650507,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark72(-12.117775489991061,55.63839432711703,63.78387164869946,0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark72(13.498639855868475,82.09496220927792,-52.56884729146867,0,0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark72(14.246512140870278,-60.09999387777393,-34.70181073493026,-75.69513512223608,-75.83926934632537,-14.487494544767552,-95.46824833087521 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark72(145.60572558912833,14.714309466615248,-18.04890321716384,-50.43266515478992,79.01003685916533,-49.42462639318619,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark72(32.72727836863997,-100.0,97.64174823094878,100.0,100.0,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark72(33.55395840676425,-43.22371015782984,-66.08500052830067,91.52085519652957,100.0,-27.030958057098033,-35.554461078654825 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark72(-36.26154966947206,-92.13849028799866,-74.47483670840712,-81.96624825442011,80.68611717773848,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark72(-36.45872755770881,-78.5955007629385,59.85059675456377,5.98907497440738,66.36332549268928,-95.4569232911061,74.18908000274274 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark72(43.420461171217596,3.225442867920563,0,0,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark72(-4.376650550165209,71.63149681486095,73.16257087693083,17.011889802829486,0,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark72(-53.209436577081284,62.47972898686521,0,0,0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark72(82.64770140518229,-47.78679176127252,13.164655621133313,6.6399389651146095,6.235302283238411,87.8224171450605,30.983560982328783 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark72(8.372304111245171,-104.72494764600442,27.97637792287982,37.076650502419,57.48654951889296,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark72(-85.21823055574558,100.0,100.0,0,0,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark72(90.64943418934266,-87.78531784656907,-103.49281230231165,49.94970051608024,-2.6464551769958895,-32.54277490392205,-115.11764960800014 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark72(-92.27358714373824,-42.81489696062287,0,0,0,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark72(-97.85900648701829,-84.89252467935353,-44.10987945927947,-90.22751108481056,-20.352429524054784,-70.75375743004922,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark72(-9.841568959732605,-97.03444687646453,100.0,100.0,0,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark72(99.83745608710728,-52.548315714429194,-83.78158818250117,92.18527076151402,48.21085187529506,-7.904403380782641,29.794708462294878 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark72(-99.85272976344518,100.0,-58.34909171746624,-96.04820356054375,0,0,0 ) ;
  }
}
