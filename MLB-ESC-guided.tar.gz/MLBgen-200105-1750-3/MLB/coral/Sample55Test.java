import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(1.0350070572347458,-20.32915996722926,12.875212085115791 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(15.122486979022561,-33.589357352598206,-75.37886411620111 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(19.206962305544238,0.9682196529393037,73.39939769217496 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark55(30.958781263658608,-19.665729798228895,83.67614591736273 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark55(31.111475736692302,2.762097603796287,47.96664257368439 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark55(3.155362555602821,-0.01520902409267677,66.3200496661456 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark55(36.04432003161767,17.68035472092339,48.14755935897739 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark55(3.7351684910604313,2.3669197403892897,4.816805626334703 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark55(41.681969463796094,83.6515001113113,-57.326035296644015 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark55(4.318140551977763,-81.38904030415439,76.85013656892409 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark55(45.03345101683311,-83.38350508911527,97.13773532178718 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark55(50.646771177872495,-29.35123141090486,61.06176689983357 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark55(55.55377602917858,-89.41105369687266,23.98741608807589 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark55(61.106744126962894,82.23481844195604,59.11260969622649 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark55(68.7430211369927,2.78197169756225,100.0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark55(69.0160592997305,62.28363112879848,78.42008820595862 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark55(7.706162619599425,-41.766563778164546,70.52934970204413 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark55(83.28900083860452,-46.337932567559186,83.70209933108285 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark55(89.38582416293099,-10.502234302319849,98.52866537274701 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark55(89.46358015505936,-25.598094986714443,71.48750276738232 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark55(89.47469568535575,-87.4470935167306,96.51968737763806 ) ;
  }
}
