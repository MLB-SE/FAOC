import org.junit.Test;

public class Sample03Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark03(-10.729578713857151,-87.72663575195465 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark03(21.69133205475677,66.74501964762493 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark03(73.27949535551996,-79.08774834358502 ) ;
  }
}
