import org.junit.Test;

public class Sample34Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark34(-49.480084294039244 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark34(-87.86520012547845 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark34(-93.11262960728925 ) ;
  }
}
