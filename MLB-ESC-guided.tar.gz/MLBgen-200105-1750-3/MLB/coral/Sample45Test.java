import org.junit.Test;

public class Sample45Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark45(0.0,-26.334527172948356,83.71164382266508 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark45(100.0,10.713914230108328,-15.336057671578967 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark45(1.1525245576555498E-18,1.0000000000000004,1.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark45(2.0178300591192288E-16,1.0000000000000004,1.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark45(-248.82780149627933,-371.9891802107373,79.50615641677538 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark45(-371.87695287359134,-313.78410649541917,82.24364469037127 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark45(39.51932359948901,1.0,73.4257261651666 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark45(45.49994022935556,47.49994022935556,70.05770451187925 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark45(-554.8420915601456,-106.23519959996781,37.80455883667483 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark45(-58.85028636232681,-16.932591795647966,1.691979430566846 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark45(5.8920160598890305,7.051434051166638,99.06058693765772 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark45(64.67705495392119,1.4030623608551451,65.03040910287882 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark45(79.80294464172636,88.81804022978679,20.65151242710283 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark45(8.673617379884035E-19,1.0000000005442895,1.0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark45(-87.63100551946485,84.22749938853133,18.50753491928829 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark45(87.73394248529547,-77.99736022837098,68.35476275223095 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark45(87.93928636118804,22.061561002833145,24.175424556908666 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark45(96.0531450371945,-10.451722155949199,64.75610801171715 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark45(99.71204549428384,43.1555704099284,3.589550918998512 ) ;
  }
}
