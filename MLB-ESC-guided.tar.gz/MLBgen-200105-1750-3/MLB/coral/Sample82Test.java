import org.junit.Test;

public class Sample82Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark82(-2.5394446899588132,-3.937868794520659E-5 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark82(-27.034338208024124,-99.09440849305848 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark82(-29.93597907642417,-3.3404619820420094E-6 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark82(35.72858707003206,-34.217536541092585 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark82(-7.744341889958436E-6,-12.912653059605134 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark82(83.62297947653298,1.1958435423610192E-6 ) ;
  }
}
