import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(38.695088865266456,-77.96455863547035,-30.59457716154563 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(43.646322506461644,-38.777231049724016,76.93206241593998 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(50.69518036682473,-54.09690236938778,-85.73018385248079 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark52(55.164512787579774,-56.54770962401437,-87.02217854114275 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark52(56.6988232161672,66.94943219939117,56.6093298307947 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark52(72.0710818473247,-12.000478736098955,74.3855911482249 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark52(7.38281880178053,-91.39130015225494,89.28625753301753 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark52(84.56459910520383,-73.7473542581974,81.40051857764087 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark52(97.56750766189407,89.00183603377647,94.50500459937193 ) ;
  }
}
