import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(-23.547813112515527,55.150476386381854 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(-4.835229193291576,1.442726623942913 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(62.60734325327058,101.75255556122103 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark09(-78.0336217910743,-1.6820206454003361 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark09(-99.6584604410408,-46.346631373827 ) ;
  }
}
