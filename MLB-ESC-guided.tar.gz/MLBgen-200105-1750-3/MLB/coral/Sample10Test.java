import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(-28.754444691990667,-15.811705367596147,32.562648822425786 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(-61.91076082631095,-64.57049184999028,-10.044929231669727 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(-63.75206594380205,-78.40806355064808,-49.28268289686215 ) ;
  }
}
