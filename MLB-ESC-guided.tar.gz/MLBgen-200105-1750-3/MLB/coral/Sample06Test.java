import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(27.466067318418112,-75.89914659785944,41.026064658619276 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(-58.61559378765473,75.5446300378998,-79.1931260327617 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(72.5975629916464,-98.51672870943392,50.50636714801187 ) ;
  }
}
