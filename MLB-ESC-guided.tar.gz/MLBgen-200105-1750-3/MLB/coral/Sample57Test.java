import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0,0.8539185773691429,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(0,42.97322682274381,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(1.3675017780036067,-7.256302880883808,-13.099086465694327,66.9883161192815,66.05109138887414 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(-18.226463513728547,45.56288225555102,-45.76001746435034,87.03422302803702,29.4801267359816 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(31.130572507181256,74.71496586351799,23.1191412953968,33.56369531871343,64.91688298152394 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(5.4580035197879795,28.869264575000486,-60.696835189787485,24.706399717578897,73.46533293956776 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(71.62287673358122,83.64094827805576,81.99177555544296,3.874419461770742,15.709813205384648 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(90.74053403517459,-0.22125406395980463,68.64416202654937,79.44724035647627,-33.82179123288283 ) ;
  }
}
