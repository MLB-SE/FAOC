import org.junit.Test;

public class Sample33Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark33(-54.979917926253805 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark33(-55.87454680913486 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark33(63.617251235193315 ) ;
  }
}
