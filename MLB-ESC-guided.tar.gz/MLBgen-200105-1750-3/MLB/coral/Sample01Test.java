import org.junit.Test;

public class Sample01Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark01(6.348771818776314,69.97992173220183 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark01(94.26055084745884,69.27502692958856 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark01(-9.879276069863636,-50.44306203668747 ) ;
  }
}
