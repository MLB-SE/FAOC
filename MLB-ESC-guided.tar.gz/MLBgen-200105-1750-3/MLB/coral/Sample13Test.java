import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(0.07705685243386995,-86.75370248674872,11.71202327495746,-60.11151324253399 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(-0.2086173370104092,-21.255865882492927,90.74481273354249,17.671685212984386 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(0.9146142735952162,-65.35134029772998,47.221351151525816,11.18267794706764 ) ;
  }
}
