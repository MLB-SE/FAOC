import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(0.7713392029679889,0.5937023342439413 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(2.654078698455141,7.045151423181287 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(45.86559371276428,-16.829082117481747 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark83(6.301995360597898,39.71514050062378 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark83(-9.372746761167912,87.84968766464526 ) ;
  }
}
