import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(-0.23932788220233103 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(13.645258974861022 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(-2.220446049250313E-16 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark31(-3.029625850239242 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark31(3.165640345132596 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark31(-34.08039429092085 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark31(-4.811000403623922 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark31(5.198790854636177 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark31(79.92092345303067 ) ;
  }
}
