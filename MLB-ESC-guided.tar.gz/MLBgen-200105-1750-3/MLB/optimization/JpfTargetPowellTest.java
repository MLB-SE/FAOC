import org.junit.Test;

public class JpfTargetPowellTest {

  @Test
  public void test0() {
    Optimization.powell(0.24345718482019438,4.107498411840058E-4 ) ;
  }

  @Test
  public void test1() {
    Optimization.powell(0.8181775988467876,1.2222285252119945E-4 ) ;
  }

  @Test
  public void test2() {
    Optimization.powell(-71.36834103455188,-1.4011815120038528E-6 ) ;
  }

  @Test
  public void test3() {
    Optimization.powell(77.43204263780127,1.291455017760068E-6 ) ;
  }

  @Test
  public void test4() {
    Optimization.powell(-80.44317443326266,50.45259163220629 ) ;
  }

  @Test
  public void test5() {
    Optimization.powell(-87.3696778403027,-77.57212563942431 ) ;
  }
}
