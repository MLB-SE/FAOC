import org.junit.Test;

public class JpfTargetWoodTest {

  @Test
  public void test0() {
    Optimization.wood(0.2510518000350608,34.444978079881224,0,0 ) ;
  }

  @Test
  public void test1() {
    Optimization.wood(1.0,0.9999999999999998,1.0,1.0 ) ;
  }

  @Test
  public void test2() {
    Optimization.wood(1.0,1.0,0,0 ) ;
  }

  @Test
  public void test3() {
    Optimization.wood(1.0,1.0000000000000004,1.0,1.0 ) ;
  }

  @Test
  public void test4() {
    Optimization.wood(1.0,1.00000000000008,1.0,0.9999999999999201 ) ;
  }

  @Test
  public void test5() {
    Optimization.wood(1.0,1.0,-0.24244325174108994,0.05877873031479351 ) ;
  }

  @Test
  public void test6() {
    Optimization.wood(1.0,1.0,1.0,0.9999999999999998 ) ;
  }

  @Test
  public void test7() {
    Optimization.wood(1.0,1.0,1.0,1.0 ) ;
  }

  @Test
  public void test8() {
    Optimization.wood(1.0,1.0,1.0,1.0000000000000004 ) ;
  }

  @Test
  public void test9() {
    Optimization.wood(1.0,1.0,-2.602514564697259,6.773082059461363 ) ;
  }

  @Test
  public void test10() {
    Optimization.wood(1.0,1.0,-38.70222507152541,1.7258795027132834 ) ;
  }

  @Test
  public void test11() {
    Optimization.wood(1.0,1.0,-6.3604418748925955,100.0 ) ;
  }

  @Test
  public void test12() {
    Optimization.wood(1.0,1.0,9.003131240099083,81.05637212644807 ) ;
  }

  @Test
  public void test13() {
    Optimization.wood(1.0,22.678020405148885,1.0,-20.678020405148885 ) ;
  }

  @Test
  public void test14() {
    Optimization.wood(1.0,5.339313659133616,1.0,-3.339313659133616 ) ;
  }

  @Test
  public void test15() {
    Optimization.wood(1.9672518474618244,3.870079831341961,0,0 ) ;
  }

  @Test
  public void test16() {
    Optimization.wood(6.776868720056484,45.92594964888001,0,0 ) ;
  }

  @Test
  public void test17() {
    Optimization.wood(-6.91566947256031,47.8264842537026,0,0 ) ;
  }

  @Test
  public void test18() {
    Optimization.wood(96.13047978612522,6.36442744691918,0,0 ) ;
  }
}
