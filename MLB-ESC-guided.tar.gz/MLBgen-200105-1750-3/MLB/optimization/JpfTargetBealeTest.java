import org.junit.Test;

public class JpfTargetBealeTest {

  @Test
  public void test0() {
    Optimization.beale(4.935110728304352,0.6960554519279484 ) ;
  }

  @Test
  public void test1() {
    Optimization.beale(59.70577614472475,-44.99498675386897 ) ;
  }

  @Test
  public void test2() {
    Optimization.beale(69.69037192883022,68.34401577643516 ) ;
  }
}
