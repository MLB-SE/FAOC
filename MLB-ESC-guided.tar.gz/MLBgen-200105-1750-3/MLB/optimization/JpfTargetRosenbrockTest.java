import org.junit.Test;

public class JpfTargetRosenbrockTest {

  @Test
  public void test0() {
    Optimization.rosenbrock(-10.207525187851278,104.1924283338808 ) ;
  }

  @Test
  public void test1() {
    Optimization.rosenbrock(3.8593335382170277,14.895073669708749 ) ;
  }

  @Test
  public void test2() {
    Optimization.rosenbrock(4.429881084562562,19.625828278249788 ) ;
  }

  @Test
  public void test3() {
    Optimization.rosenbrock(88.21000482549849,-56.70585459542132 ) ;
  }

  @Test
  public void test4() {
    Optimization.rosenbrock(9.937809250417699,98.75745550680745 ) ;
  }
}
