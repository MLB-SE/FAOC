import org.junit.Test;

public class JpfTargetFreudensteinRothTest {

  @Test
  public void test0() {
    Optimization.freudensteinRoth(17.74225675249106,-0.3589113870348797 ) ;
  }

  @Test
  public void test1() {
    Optimization.freudensteinRoth(-22.373240370814827,3.5345635576817074 ) ;
  }

  @Test
  public void test2() {
    Optimization.freudensteinRoth(57.71430217297916,47.96327452640551 ) ;
  }
}
