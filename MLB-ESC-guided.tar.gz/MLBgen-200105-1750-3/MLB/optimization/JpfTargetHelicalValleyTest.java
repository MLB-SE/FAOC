import org.junit.Test;

public class JpfTargetHelicalValleyTest {

  @Test
  public void test0() {
    Optimization.theta(-1.1102230246251565E-16,99.99576755172679 ) ;
  }

  @Test
  public void test1() {
    Optimization.theta(-1.5777218104420236E-30,100.0 ) ;
  }

  @Test
  public void test2() {
    Optimization.theta(16.710371249549112,48.179985542043084 ) ;
  }

  @Test
  public void test3() {
    Optimization.theta(-1.7763568394002505E-15,35.56791539291118 ) ;
  }

  @Test
  public void test4() {
    Optimization.theta(19.037838381780176,28.046644712816516 ) ;
  }

  @Test
  public void test5() {
    Optimization.theta(-2.1128878168073015,0 ) ;
  }

  @Test
  public void test6() {
    Optimization.theta(-2.220446049250313E-16,21.973541259698692 ) ;
  }

  @Test
  public void test7() {
    Optimization.theta(-2.220446049250313E-16,77.3946997044269 ) ;
  }

  @Test
  public void test8() {
    Optimization.theta(-2.220446049250313E-16,96.18421765340611 ) ;
  }

  @Test
  public void test9() {
    Optimization.theta(-24.23097949020672,-26.977647261172482 ) ;
  }

  @Test
  public void test10() {
    Optimization.theta(-2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test11() {
    Optimization.theta(2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test12() {
    Optimization.theta(-2.576523834620545E-10,277.9396677435189 ) ;
  }

  @Test
  public void test13() {
    Optimization.theta(-2.5849394142282115E-26,100.0 ) ;
  }

  @Test
  public void test14() {
    Optimization.theta(-26.234372274616717,0 ) ;
  }

  @Test
  public void test15() {
    Optimization.theta(-27.847497126699764,0 ) ;
  }

  @Test
  public void test16() {
    Optimization.theta(-30.373868375947776,-47.437089965287754 ) ;
  }

  @Test
  public void test17() {
    Optimization.theta(3.3196708526682244,-87.56402461587014 ) ;
  }

  @Test
  public void test18() {
    Optimization.theta(35.52855553983787,0 ) ;
  }

  @Test
  public void test19() {
    Optimization.theta(-36.16363395096125,-18.184858692059862 ) ;
  }

  @Test
  public void test20() {
    Optimization.theta(-36.39701168408781,24.064264631798295 ) ;
  }

  @Test
  public void test21() {
    Optimization.theta(4.3368086899420177E-19,0 ) ;
  }

  @Test
  public void test22() {
    Optimization.theta(48.93433736125536,0 ) ;
  }

  @Test
  public void test23() {
    Optimization.theta(-4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test24() {
    Optimization.theta(-50.31471263500198,72.46205771382469 ) ;
  }

  @Test
  public void test25() {
    Optimization.theta(64.7896397145725,15.605434039894163 ) ;
  }

  @Test
  public void test26() {
    Optimization.theta(-65.9619373907137,-62.73998635048061 ) ;
  }

  @Test
  public void test27() {
    Optimization.theta(71.73240817126464,94.53795128473539 ) ;
  }

  @Test
  public void test28() {
    Optimization.theta(75.76869908876833,-37.75896164036419 ) ;
  }

  @Test
  public void test29() {
    Optimization.theta(76.82216749225724,99.98847402448284 ) ;
  }

  @Test
  public void test30() {
    Optimization.theta(-80.19959395003815,90.96199915252953 ) ;
  }

  @Test
  public void test31() {
    Optimization.theta(81.36783348032479,0.0 ) ;
  }

  @Test
  public void test32() {
    Optimization.theta(84.62816324532186,43.50926757618046 ) ;
  }

  @Test
  public void test33() {
    Optimization.theta(-93.31419927439113,0 ) ;
  }
}
