import org.junit.Test;

public class JpfTargetMysinTest {

  @Test
  public void test0() {
    JpfTargetMysin.static_mysin(0.25213657476645324 ) ;
  }

  @Test
  public void test1() {
    JpfTargetMysin.static_mysin(-0.29051889365049854 ) ;
  }

  @Test
  public void test2() {
    JpfTargetMysin.static_mysin(-0.713852477229155 ) ;
  }

  @Test
  public void test3() {
    JpfTargetMysin.static_mysin(0.9639300682329788 ) ;
  }

  @Test
  public void test4() {
    JpfTargetMysin.static_mysin(-1.2806868702799014E-39 ) ;
  }

  @Test
  public void test5() {
    JpfTargetMysin.static_mysin(138.90263439803743 ) ;
  }

  @Test
  public void test6() {
    JpfTargetMysin.static_mysin(-14.588315435372351 ) ;
  }

  @Test
  public void test7() {
    JpfTargetMysin.static_mysin(1.676994381843876E-13 ) ;
  }

  @Test
  public void test8() {
    JpfTargetMysin.static_mysin(-1.8897102294946786E-4 ) ;
  }

  @Test
  public void test9() {
    JpfTargetMysin.static_mysin(2.441406250063326E-4 ) ;
  }

  @Test
  public void test10() {
    JpfTargetMysin.static_mysin(-2.4414062526361037E-4 ) ;
  }

  @Test
  public void test11() {
    JpfTargetMysin.static_mysin(2.44140636715796E-4 ) ;
  }

  @Test
  public void test12() {
    JpfTargetMysin.static_mysin(-2.44213253059506E-4 ) ;
  }

  @Test
  public void test13() {
    JpfTargetMysin.static_mysin(25.824437273053974 ) ;
  }

  @Test
  public void test14() {
    JpfTargetMysin.static_mysin(260.95846986277166 ) ;
  }

  @Test
  public void test15() {
    JpfTargetMysin.static_mysin(-271.9094201706022 ) ;
  }

  @Test
  public void test16() {
    JpfTargetMysin.static_mysin(31.94738432927383 ) ;
  }

  @Test
  public void test17() {
    JpfTargetMysin.static_mysin(32.99272459735562 ) ;
  }

  @Test
  public void test18() {
    JpfTargetMysin.static_mysin(-38.48451000647496 ) ;
  }

  @Test
  public void test19() {
    JpfTargetMysin.static_mysin(46.33849164044945 ) ;
  }

  @Test
  public void test20() {
    JpfTargetMysin.static_mysin(-67.42136930668144 ) ;
  }

  @Test
  public void test21() {
    JpfTargetMysin.static_mysin(68.65130734213153 ) ;
  }

  @Test
  public void test22() {
    JpfTargetMysin.static_mysin(-70.22316249172957 ) ;
  }

  @Test
  public void test23() {
    JpfTargetMysin.static_mysin(7.893103978288821 ) ;
  }

  @Test
  public void test24() {
    JpfTargetMysin.static_mysin(-80.89601082993717 ) ;
  }

  @Test
  public void test25() {
    JpfTargetMysin.static_mysin(8.63937979737193 ) ;
  }

  @Test
  public void test26() {
    JpfTargetMysin.static_mysin(-87.67330161948689 ) ;
  }

  @Test
  public void test27() {
    JpfTargetMysin.static_mysin(-91.73319408756791 ) ;
  }

  @Test
  public void test28() {
    JpfTargetMysin.static_mysin(-9.388893875410218 ) ;
  }

  @Test
  public void test29() {
    JpfTargetMysin.static_mysin(99.52747510685606 ) ;
  }
}
