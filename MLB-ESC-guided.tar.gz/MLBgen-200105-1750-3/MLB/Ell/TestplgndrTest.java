import org.junit.Test;

public class TestplgndrTest {

  @Test
  public void test0() {
    plgndr.plgndr(0,0,0 ) ;
  }

  @Test
  public void test1() {
    plgndr.plgndr(0,1,0 ) ;
  }

  @Test
  public void test2() {
    plgndr.plgndr(0,111,0 ) ;
  }

  @Test
  public void test3() {
    plgndr.plgndr(0,-32,0 ) ;
  }

  @Test
  public void test4() {
    plgndr.plgndr(0,-348,0 ) ;
  }

  @Test
  public void test5() {
    plgndr.plgndr(1160,934,39.95049354629904 ) ;
  }

  @Test
  public void test6() {
    plgndr.plgndr(-16,0,0 ) ;
  }

  @Test
  public void test7() {
    plgndr.plgndr(-174,-342,0 ) ;
  }

  @Test
  public void test8() {
    plgndr.plgndr(184,153,1.0000000000000002 ) ;
  }

  @Test
  public void test9() {
    plgndr.plgndr(-39,-39,0 ) ;
  }

  @Test
  public void test10() {
    plgndr.plgndr(-395,0,0 ) ;
  }

  @Test
  public void test11() {
    plgndr.plgndr(400,80,-31.580941138436458 ) ;
  }

  @Test
  public void test12() {
    plgndr.plgndr(594,301,1.0000000000000002 ) ;
  }

  @Test
  public void test13() {
    plgndr.plgndr(612,17,97.94463587593935 ) ;
  }

  @Test
  public void test14() {
    plgndr.plgndr(-617,0,0 ) ;
  }

  @Test
  public void test15() {
    plgndr.plgndr(623,490,0.0 ) ;
  }

  @Test
  public void test16() {
    plgndr.plgndr(-634,470,0 ) ;
  }

  @Test
  public void test17() {
    plgndr.plgndr(660,531,0.0 ) ;
  }

  @Test
  public void test18() {
    plgndr.plgndr(679,553,-0.6007941307336854 ) ;
  }

  @Test
  public void test19() {
    plgndr.plgndr(686,158,0 ) ;
  }

  @Test
  public void test20() {
    plgndr.plgndr(-691,0,0 ) ;
  }

  @Test
  public void test21() {
    plgndr.plgndr(69,36,0.0 ) ;
  }

  @Test
  public void test22() {
    plgndr.plgndr(786,257,1.0000000000000002 ) ;
  }

  @Test
  public void test23() {
    plgndr.plgndr(791,574,-33.54886360708717 ) ;
  }

  @Test
  public void test24() {
    plgndr.plgndr(819,746,-1.0 ) ;
  }

  @Test
  public void test25() {
    plgndr.plgndr(-848,-439,0 ) ;
  }

  @Test
  public void test26() {
    plgndr.plgndr(-857,-858,0 ) ;
  }

  @Test
  public void test27() {
    plgndr.plgndr(89,80,0.9999999999999979 ) ;
  }

  @Test
  public void test28() {
    plgndr.plgndr(-933,630,0 ) ;
  }

  @Test
  public void test29() {
    plgndr.plgndr(952,570,0.9999999999999991 ) ;
  }

  @Test
  public void test30() {
    plgndr.plgndr(984,995,0 ) ;
  }

  @Test
  public void test31() {
    plgndr.plgndr(997,18,1.0 ) ;
  }
}
