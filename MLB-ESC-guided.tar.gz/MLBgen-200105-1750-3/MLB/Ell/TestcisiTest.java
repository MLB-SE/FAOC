import org.junit.Test;

public class TestcisiTest {

  @Test
  public void test0() {
    frenel.cisi(0.3368329908268395 ) ;
  }

  @Test
  public void test1() {
    frenel.cisi(0.4377897783657687 ) ;
  }

  @Test
  public void test2() {
    frenel.cisi(-1.128303240998548 ) ;
  }

  @Test
  public void test3() {
    frenel.cisi(11.923661853291236 ) ;
  }

  @Test
  public void test4() {
    frenel.cisi(-14.081757575552317 ) ;
  }

  @Test
  public void test5() {
    frenel.cisi(1.4981364335015035E-95 ) ;
  }

  @Test
  public void test6() {
    frenel.cisi(-17.644232595108903 ) ;
  }

  @Test
  public void test7() {
    frenel.cisi(1.9999999999999982 ) ;
  }

  @Test
  public void test8() {
    frenel.cisi(-2.0 ) ;
  }

  @Test
  public void test9() {
    frenel.cisi(2.0 ) ;
  }

  @Test
  public void test10() {
    frenel.cisi(2.465190328815662E-32 ) ;
  }

  @Test
  public void test11() {
    frenel.cisi(-25.479473739374754 ) ;
  }

  @Test
  public void test12() {
    frenel.cisi(3.0814879110195774E-33 ) ;
  }

  @Test
  public void test13() {
    frenel.cisi(-4.243219324725004 ) ;
  }

  @Test
  public void test14() {
    frenel.cisi(-4.4455174989701545E-162 ) ;
  }

  @Test
  public void test15() {
    frenel.cisi(48.17877528285078 ) ;
  }

  @Test
  public void test16() {
    frenel.cisi(4.930380657631324E-32 ) ;
  }

  @Test
  public void test17() {
    frenel.cisi(-64.99522482661524 ) ;
  }

  @Test
  public void test18() {
    frenel.cisi(71.2946921098497 ) ;
  }

  @Test
  public void test19() {
    frenel.cisi(-7.490682167507517E-96 ) ;
  }

  @Test
  public void test20() {
    frenel.cisi(-78.24628754601366 ) ;
  }

  @Test
  public void test21() {
    frenel.cisi(8.366406229940154 ) ;
  }

  @Test
  public void test22() {
    frenel.cisi(-9.563742359005744 ) ;
  }

  @Test
  public void test23() {
    frenel.cisi(9.716732346500606 ) ;
  }

  @Test
  public void test24() {
    frenel.cisi(-9.860761315262648E-32 ) ;
  }

  @Test
  public void test25() {
    frenel.cisi(9.860761315262648E-32 ) ;
  }
}
