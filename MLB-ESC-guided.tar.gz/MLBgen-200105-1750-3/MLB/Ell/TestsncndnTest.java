import org.junit.Test;

public class TestsncndnTest {

  @Test
  public void test0() {
    ell.sncndn(0,0.06132823025669154 ) ;
  }

  @Test
  public void test1() {
    ell.sncndn(0,-0.6380856072234309 ) ;
  }

  @Test
  public void test2() {
    ell.sncndn(0,0.9097703700876849 ) ;
  }

  @Test
  public void test3() {
    ell.sncndn(0,0.99999998 ) ;
  }

  @Test
  public void test4() {
    ell.sncndn(0,0.999999994608682 ) ;
  }

  @Test
  public void test5() {
    ell.sncndn(0,1.0 ) ;
  }

  @Test
  public void test6() {
    ell.sncndn(0,1.0000000000000002 ) ;
  }

  @Test
  public void test7() {
    ell.sncndn(0,1.0000000000001195 ) ;
  }

  @Test
  public void test8() {
    ell.sncndn(0,1.0000000199999999 ) ;
  }

  @Test
  public void test9() {
    ell.sncndn(0,19.28312566027695 ) ;
  }

  @Test
  public void test10() {
    ell.sncndn(0,1.9721522630525295E-31 ) ;
  }

  @Test
  public void test11() {
    ell.sncndn(0,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test12() {
    ell.sncndn(0,2.465190328815662E-32 ) ;
  }

  @Test
  public void test13() {
    ell.sncndn(0,29.628438747882598 ) ;
  }

  @Test
  public void test14() {
    ell.sncndn(0,-45.88934262001276 ) ;
  }

  @Test
  public void test15() {
    ell.sncndn(0,5.313529094602316 ) ;
  }

  @Test
  public void test16() {
    ell.sncndn(0,65.59422224868663 ) ;
  }

  @Test
  public void test17() {
    ell.sncndn(0,-67.9740687331346 ) ;
  }

  @Test
  public void test18() {
    ell.sncndn(0,7.717185728504745 ) ;
  }

  @Test
  public void test19() {
    ell.sncndn(0,-78.25756877009425 ) ;
  }

  @Test
  public void test20() {
    ell.sncndn(0,9.860761315262648E-32 ) ;
  }
}
