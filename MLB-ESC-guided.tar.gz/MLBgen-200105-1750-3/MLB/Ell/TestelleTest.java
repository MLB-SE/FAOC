import org.junit.Test;

public class TestelleTest {

  @Test
  public void test0() {
    ell.elle(12.566370607354505,-0.6667079343795397 ) ;
  }

  @Test
  public void test1() {
    ell.elle(-14.137166495393576,0.9999999999999879 ) ;
  }

  @Test
  public void test2() {
    ell.elle(-14.137166941154069,0.8402059202356122 ) ;
  }

  @Test
  public void test3() {
    ell.elle(-21.991148562374413,-1.2656704759068935 ) ;
  }

  @Test
  public void test4() {
    ell.elle(-21.99114857314115,1.2839400338319678 ) ;
  }

  @Test
  public void test5() {
    ell.elle(-25.132741210555217,0.41361586316556764 ) ;
  }

  @Test
  public void test6() {
    ell.elle(-25.13274133349708,0.9971410327069741 ) ;
  }

  @Test
  public void test7() {
    ell.elle(-28.274333877456115,-2.5225908437064115 ) ;
  }

  @Test
  public void test8() {
    ell.elle(-37.69909047286439,5.068900646861552E-4 ) ;
  }

  @Test
  public void test9() {
    ell.elle(38.356480721766765,1.6365643384804718 ) ;
  }

  @Test
  public void test10() {
    ell.elle(-40.84070449645722,67.90697488628109 ) ;
  }

  @Test
  public void test11() {
    ell.elle(40.840704502383225,-8.579362562837524 ) ;
  }

  @Test
  public void test12() {
    ell.elle(-43.775772242104665,-3.89693892036496 ) ;
  }

  @Test
  public void test13() {
    ell.elle(45.553093481000516,1.0000000000001812 ) ;
  }

  @Test
  public void test14() {
    ell.elle(-46.511954415900924,-97.03548507509305 ) ;
  }

  @Test
  public void test15() {
    ell.elle(-48.69468613079163,0.5721489173308911 ) ;
  }

  @Test
  public void test16() {
    ell.elle(-50.42480051042368,-4.490109530982699 ) ;
  }

  @Test
  public void test17() {
    ell.elle(-52.70316503425424,0.5916253865621908 ) ;
  }

  @Test
  public void test18() {
    ell.elle(53.38782500362052,-4.779503276575252E-7 ) ;
  }

  @Test
  public void test19() {
    ell.elle(-56.938142177183295,42.82750141571549 ) ;
  }

  @Test
  public void test20() {
    ell.elle(-59.564881034528064,-7.996727866638369 ) ;
  }

  @Test
  public void test21() {
    ell.elle(-59.69026041851693,25.175283632330892 ) ;
  }

  @Test
  public void test22() {
    ell.elle(59.690260447180975,0.9335587385677663 ) ;
  }

  @Test
  public void test23() {
    ell.elle(-61.26105674500097,1.0 ) ;
  }

  @Test
  public void test24() {
    ell.elle(61.261056745000985,-1.0 ) ;
  }

  @Test
  public void test25() {
    ell.elle(62.80374586239563,-35.58274559023889 ) ;
  }

  @Test
  public void test26() {
    ell.elle(-6.2831853038555625,-21.98801275265286 ) ;
  }

  @Test
  public void test27() {
    ell.elle(65.97344566678258,1.027577536308484 ) ;
  }

  @Test
  public void test28() {
    ell.elle(65.97344572503758,8.214947279181425 ) ;
  }

  @Test
  public void test29() {
    ell.elle(65.97344573909105,-0.9930109571860951 ) ;
  }

  @Test
  public void test30() {
    ell.elle(68.79825682947853,0.937685751534616 ) ;
  }

  @Test
  public void test31() {
    ell.elle(69.13349006364024,0.2838338954637698 ) ;
  }

  @Test
  public void test32() {
    ell.elle(-70.71927702895417,-0.3801084162712858 ) ;
  }

  @Test
  public void test33() {
    ell.elle(71.94702661086059,-3.282111712278965 ) ;
  }

  @Test
  public void test34() {
    ell.elle(-72.25664921778859,-0.9999999805251474 ) ;
  }

  @Test
  public void test35() {
    ell.elle(73.82742736175132,-0.650628535265388 ) ;
  }

  @Test
  public void test36() {
    ell.elle(75.39822369321271,-0.8707613190406249 ) ;
  }

  @Test
  public void test37() {
    ell.elle(-78.53981488359935,-0.9999942044063959 ) ;
  }

  @Test
  public void test38() {
    ell.elle(-80.11061266999604,-1.0 ) ;
  }

  @Test
  public void test39() {
    ell.elle(81.68140900166298,1.0007312798701644 ) ;
  }

  @Test
  public void test40() {
    ell.elle(-87.96459431314304,0.7917860118298561 ) ;
  }

  @Test
  public void test41() {
    ell.elle(-87.96515375113576,9.370459764400027E-6 ) ;
  }

  @Test
  public void test42() {
    ell.elle(-91.10618695305737,-2.844397776268554 ) ;
  }

  @Test
  public void test43() {
    ell.elle(-91.10618695469682,-4.765328071754254 ) ;
  }

  @Test
  public void test44() {
    ell.elle(-91.10618695948502,80.46944273403719 ) ;
  }

  @Test
  public void test45() {
    ell.elle(-94.24777960767761,-100.0 ) ;
  }

  @Test
  public void test46() {
    ell.elle(9.424777960836291,54.104980803113776 ) ;
  }

  @Test
  public void test47() {
    ell.elle(-96.51169517864994,-99.75212982612295 ) ;
  }

  @Test
  public void test48() {
    ell.elle(-98.96016858807849,0.1957128733174992 ) ;
  }
}
