import org.junit.Test;

public class TestellpiTest {

  @Test
  public void test0() {
    ell.ellpi(15.70796325294094,0,0.8703079199250602 ) ;
  }

  @Test
  public void test1() {
    ell.ellpi(18.86750975419318,0,-1.0000000000003024 ) ;
  }

  @Test
  public void test2() {
    ell.ellpi(-25.129968665070866,0,-0.8313301409320049 ) ;
  }

  @Test
  public void test3() {
    ell.ellpi(-25.158136865415393,0,-39.381075959865974 ) ;
  }

  @Test
  public void test4() {
    ell.ellpi(-26.703537555513243,0,0.9459781765537543 ) ;
  }

  @Test
  public void test5() {
    ell.ellpi(-29.206305756320077,0,-0.7992849984312045 ) ;
  }

  @Test
  public void test6() {
    ell.ellpi(-37.69152537001733,0,0.9999999999997166 ) ;
  }

  @Test
  public void test7() {
    ell.ellpi(-40.8407044969882,0,19.405856284333876 ) ;
  }

  @Test
  public void test8() {
    ell.ellpi(-40.84070478637563,0,-0.053237169221714155 ) ;
  }

  @Test
  public void test9() {
    ell.ellpi(44.01768730914557,0,16.957693420008003 ) ;
  }

  @Test
  public void test10() {
    ell.ellpi(46.10887291223733,0,-26.457039153825647 ) ;
  }

  @Test
  public void test11() {
    ell.ellpi(-50.26548246837825,0,-0.4950090240271346 ) ;
  }

  @Test
  public void test12() {
    ell.ellpi(-56.54866776156563,0,2.6712964570643845 ) ;
  }

  @Test
  public void test13() {
    ell.ellpi(-56.548667774016224,0,0.1495914733465389 ) ;
  }

  @Test
  public void test14() {
    ell.ellpi(-56.54866778274592,0,0.7283420659638444 ) ;
  }

  @Test
  public void test15() {
    ell.ellpi(-63.34396805481204,0,-75.30979254158588 ) ;
  }

  @Test
  public void test16() {
    ell.ellpi(-64.40264939859077,0,-1.0 ) ;
  }

  @Test
  public void test17() {
    ell.ellpi(-70.6858347148363,0,0.9999999999999899 ) ;
  }

  @Test
  public void test18() {
    ell.ellpi(72.25663105413328,0,-0.6541000640663516 ) ;
  }

  @Test
  public void test19() {
    ell.ellpi(-78.16579153982559,0,2.7369896080092864 ) ;
  }

  @Test
  public void test20() {
    ell.ellpi(78.53981632924598,0,1.1571551625932743 ) ;
  }

  @Test
  public void test21() {
    ell.ellpi(78.62877372682814,0,7.64391894102694 ) ;
  }

  @Test
  public void test22() {
    ell.ellpi(-80.11061266957418,0,0.9000745781683575 ) ;
  }

  @Test
  public void test23() {
    ell.ellpi(-81.66694401378652,0,-0.8542878638973042 ) ;
  }

  @Test
  public void test24() {
    ell.ellpi(-81.68140899527089,0,8.42241705968645 ) ;
  }

  @Test
  public void test25() {
    ell.ellpi(81.69050536719512,0,109.93543208956174 ) ;
  }

  @Test
  public void test26() {
    ell.ellpi(83.25220532836704,0,0.870604690537933 ) ;
  }

  @Test
  public void test27() {
    ell.ellpi(-84.82300166320421,0,-0.9995083260584567 ) ;
  }

  @Test
  public void test28() {
    ell.ellpi(86.31643663507685,0,-32.39995265399112 ) ;
  }

  @Test
  public void test29() {
    ell.ellpi(86.39379797956616,0,-1.0 ) ;
  }

  @Test
  public void test30() {
    ell.ellpi(-87.9645234553468,0,-0.037681459973450515 ) ;
  }

  @Test
  public void test31() {
    ell.ellpi(-87.96459430654694,0,-1.4187243140991441 ) ;
  }

  @Test
  public void test32() {
    ell.ellpi(87.96477468146735,0,0.999999999987755 ) ;
  }

  @Test
  public void test33() {
    ell.ellpi(-94.24777961510141,0,31.74900728181359 ) ;
  }

  @Test
  public void test34() {
    ell.ellpi(-9.424777967399068,0,-1.0416930534076645 ) ;
  }

  @Test
  public void test35() {
    ell.ellpi(-95.81857593448869,0,-0.6925862167478771 ) ;
  }

  @Test
  public void test36() {
    ell.ellpi(97.4947805755765,0,9.504508527491609 ) ;
  }

  @Test
  public void test37() {
    ell.ellpi(-9.913486633383261,0,-2.1299884425901516 ) ;
  }
}
