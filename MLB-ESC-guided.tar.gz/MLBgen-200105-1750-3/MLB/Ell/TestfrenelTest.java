import org.junit.Test;

public class TestfrenelTest {

  @Test
  public void test0() {
    frenel.frenel(0.38643391315933684 ) ;
  }

  @Test
  public void test1() {
    frenel.frenel(-1.1436226876410842 ) ;
  }

  @Test
  public void test2() {
    frenel.frenel(12.102886430384487 ) ;
  }

  @Test
  public void test3() {
    frenel.frenel(13.485185918799587 ) ;
  }

  @Test
  public void test4() {
    frenel.frenel(1.4999999999999991 ) ;
  }

  @Test
  public void test5() {
    frenel.frenel(-1.5 ) ;
  }

  @Test
  public void test6() {
    frenel.frenel(1.5 ) ;
  }

  @Test
  public void test7() {
    frenel.frenel(-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test8() {
    frenel.frenel(2.465190328815662E-32 ) ;
  }

  @Test
  public void test9() {
    frenel.frenel(34.62534214949736 ) ;
  }

  @Test
  public void test10() {
    frenel.frenel(-4.210353688273642 ) ;
  }

  @Test
  public void test11() {
    frenel.frenel(5.551115123125783E-17 ) ;
  }

  @Test
  public void test12() {
    frenel.frenel(59.78314490616913 ) ;
  }

  @Test
  public void test13() {
    frenel.frenel(6.162975822039155E-33 ) ;
  }

  @Test
  public void test14() {
    frenel.frenel(-6.644651944961851 ) ;
  }

  @Test
  public void test15() {
    frenel.frenel(-84.84307456773598 ) ;
  }

  @Test
  public void test16() {
    frenel.frenel(-94.90468428511612 ) ;
  }
}
