import org.junit.Test;

public class TestellfTest {

  @Test
  public void test0() {
    ell.ellf(-100.0,1.670340081031199 ) ;
  }

  @Test
  public void test1() {
    ell.ellf(-10.995574282862139,0.49286303225582884 ) ;
  }

  @Test
  public void test2() {
    ell.ellf(-144.51625731063444,-1.7461191032020415E-6 ) ;
  }

  @Test
  public void test3() {
    ell.ellf(15.707963260375736,-0.9569393841062974 ) ;
  }

  @Test
  public void test4() {
    ell.ellf(18.84858034705536,-0.9999999999664171 ) ;
  }

  @Test
  public void test5() {
    ell.ellf(-19.313742951931218,-1.8044200722172548 ) ;
  }

  @Test
  public void test6() {
    ell.ellf(21.991148602675874,1.0000036907191625 ) ;
  }

  @Test
  public void test7() {
    ell.ellf(21.991148610207304,8.6495082932602 ) ;
  }

  @Test
  public void test8() {
    ell.ellf(-22.10022979840112,9.185686089760631 ) ;
  }

  @Test
  public void test9() {
    ell.ellf(23.56194489170488,-1.0 ) ;
  }

  @Test
  public void test10() {
    ell.ellf(-28.27433387980754,6.3328778636979735 ) ;
  }

  @Test
  public void test11() {
    ell.ellf(29.090775014601377,-94.34445572187717 ) ;
  }

  @Test
  public void test12() {
    ell.ellf(-30.134374588536623,-1.043340714109073 ) ;
  }

  @Test
  public void test13() {
    ell.ellf(3.1415926509355203,-4.48959594019969 ) ;
  }

  @Test
  public void test14() {
    ell.ellf(34.55751918313979,1.5003413283851925 ) ;
  }

  @Test
  public void test15() {
    ell.ellf(34.557519188439215,6.723653299831776 ) ;
  }

  @Test
  public void test16() {
    ell.ellf(37.69911185351771,-88.14649267784384 ) ;
  }

  @Test
  public void test17() {
    ell.ellf(40.84070447739082,-0.5362207032488978 ) ;
  }

  @Test
  public void test18() {
    ell.ellf(43.749448348950665,-0.728843771367039 ) ;
  }

  @Test
  public void test19() {
    ell.ellf(-45.553093485135854,-0.8978767591838371 ) ;
  }

  @Test
  public void test20() {
    ell.ellf(47.12388922731137,0.8045199837427361 ) ;
  }

  @Test
  public void test21() {
    ell.ellf(50.26548243449928,-0.7874101529501552 ) ;
  }

  @Test
  public void test22() {
    ell.ellf(50.26548245077693,-10.585208238499689 ) ;
  }

  @Test
  public void test23() {
    ell.ellf(-51.35194414837332,0.549047242420768 ) ;
  }

  @Test
  public void test24() {
    ell.ellf(56.548667780021724,-0.7383075207562833 ) ;
  }

  @Test
  public void test25() {
    ell.ellf(56.54868243184997,8.77203559698859E-4 ) ;
  }

  @Test
  public void test26() {
    ell.ellf(-56.997934013821805,-84.84376456737972 ) ;
  }

  @Test
  public void test27() {
    ell.ellf(58.119464091411174,-0.25811432348925023 ) ;
  }

  @Test
  public void test28() {
    ell.ellf(-59.690260416451125,39.27285711457412 ) ;
  }

  @Test
  public void test29() {
    ell.ellf(6.283185305312651,-4.560413109833149 ) ;
  }

  @Test
  public void test30() {
    ell.ellf(-62.83185311362646,0.2380050338255444 ) ;
  }

  @Test
  public void test31() {
    ell.ellf(-6.2831853142164915,15.752296690574767 ) ;
  }

  @Test
  public void test32() {
    ell.ellf(62.86882799627707,-27.051519587653175 ) ;
  }

  @Test
  public void test33() {
    ell.ellf(-65.97344573507573,0.15059797604833136 ) ;
  }

  @Test
  public void test34() {
    ell.ellf(-66.08107632311805,9.309000952785807 ) ;
  }

  @Test
  public void test35() {
    ell.ellf(70.68583470577035,1.0 ) ;
  }

  @Test
  public void test36() {
    ell.ellf(72.25663103691629,2.7089015274065242 ) ;
  }

  @Test
  public void test37() {
    ell.ellf(72.2566313216577,-2.9071552108848238 ) ;
  }

  @Test
  public void test38() {
    ell.ellf(76.96902001294994,-1.0 ) ;
  }

  @Test
  public void test39() {
    ell.ellf(-7.853981623914777,1.0 ) ;
  }

  @Test
  public void test40() {
    ell.ellf(83.25220532012952,0.9712888828215677 ) ;
  }

  @Test
  public void test41() {
    ell.ellf(84.82300162478604,1.125897951147783 ) ;
  }

  @Test
  public void test42() {
    ell.ellf(84.8355016808408,-0.10365326816964462 ) ;
  }

  @Test
  public void test43() {
    ell.ellf(87.96459431242357,-0.7795864898545344 ) ;
  }

  @Test
  public void test44() {
    ell.ellf(-87.96459433375243,-0.7678808105406514 ) ;
  }

  @Test
  public void test45() {
    ell.ellf(-91.10618695223745,-2.057390139381364 ) ;
  }

  @Test
  public void test46() {
    ell.ellf(94.24777959378046,-1.271546027778779 ) ;
  }

  @Test
  public void test47() {
    ell.ellf(94.2477796086706,10.606024492179984 ) ;
  }

  @Test
  public void test48() {
    ell.ellf(9.424777961342757,-25.448662182420193 ) ;
  }

  @Test
  public void test49() {
    ell.ellf(-9.424778045218167,0.9952896913286582 ) ;
  }

  @Test
  public void test50() {
    ell.ellf(-94.45096249933937,-51.006521399429474 ) ;
  }

  @Test
  public void test51() {
    ell.ellf(98.9345820162718,-1.000327425643081 ) ;
  }
}
