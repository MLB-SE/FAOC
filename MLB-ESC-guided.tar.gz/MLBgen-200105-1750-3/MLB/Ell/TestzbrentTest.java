import org.junit.Test;

public class TestzbrentTest {

  @Test
  public void test0() {
    ell.zbrent(-100.0,-3.141592653589793,0 ) ;
  }

  @Test
  public void test1() {
    ell.zbrent(-100.0,-43.982297150257104,0 ) ;
  }

  @Test
  public void test2() {
    ell.zbrent(100.0,47.1238898038469,0 ) ;
  }

  @Test
  public void test3() {
    ell.zbrent(100.0,87.96459430051421,0 ) ;
  }

  @Test
  public void test4() {
    ell.zbrent(-10.541712193709856,31.415926535897935,0 ) ;
  }

  @Test
  public void test5() {
    ell.zbrent(12.754495608910684,-34.55751918948773,0 ) ;
  }

  @Test
  public void test6() {
    ell.zbrent(-16.773030363869125,-81.68140899333461,0 ) ;
  }

  @Test
  public void test7() {
    ell.zbrent(18.84955592153876,0,0 ) ;
  }

  @Test
  public void test8() {
    ell.zbrent(-20.664202007651042,-83.6132181962409,0 ) ;
  }

  @Test
  public void test9() {
    ell.zbrent(-28.316104440630127,-13.779196525003059,0 ) ;
  }

  @Test
  public void test10() {
    ell.zbrent(31.29591323908349,-40.77610708898145,0 ) ;
  }

  @Test
  public void test11() {
    ell.zbrent(42.43323748182848,12.566370614359174,0 ) ;
  }

  @Test
  public void test12() {
    ell.zbrent(-4.303979716905104,-78.53981633974482,0 ) ;
  }

  @Test
  public void test13() {
    ell.zbrent(43.892727211572456,12.566370614359174,0 ) ;
  }

  @Test
  public void test14() {
    ell.zbrent(43.938228353337884,84.82300164692442,0 ) ;
  }

  @Test
  public void test15() {
    ell.zbrent(-47.12388980384689,0,0 ) ;
  }

  @Test
  public void test16() {
    ell.zbrent(-47.62695513221844,0,0 ) ;
  }

  @Test
  public void test17() {
    ell.zbrent(-50.3337907383651,52.20644291021591,0 ) ;
  }

  @Test
  public void test18() {
    ell.zbrent(-53.40707511102648,0,0 ) ;
  }

  @Test
  public void test19() {
    ell.zbrent(-5.412250402771136,-78.53981633974483,0 ) ;
  }

  @Test
  public void test20() {
    ell.zbrent(-54.148303882754625,37.69911184307752,0 ) ;
  }

  @Test
  public void test21() {
    ell.zbrent(-55.34995387212418,-18.849555921538762,0 ) ;
  }

  @Test
  public void test22() {
    ell.zbrent(-57.27544768193573,21.991148575128555,0 ) ;
  }

  @Test
  public void test23() {
    ell.zbrent(58.50261207083389,88.73445383280745,0 ) ;
  }

  @Test
  public void test24() {
    ell.zbrent(59.690260418206066,100.0,0 ) ;
  }

  @Test
  public void test25() {
    ell.zbrent(63.48663026097401,-94.8394464141578,0 ) ;
  }

  @Test
  public void test26() {
    ell.zbrent(-6.41484158732797,-12.566370614359172,0 ) ;
  }

  @Test
  public void test27() {
    ell.zbrent(70.80552263203344,58.342231036888364,0 ) ;
  }

  @Test
  public void test28() {
    ell.zbrent(-70.9849549993381,0,0 ) ;
  }

  @Test
  public void test29() {
    ell.zbrent(73.34355292908901,-31.41592653589793,0 ) ;
  }

  @Test
  public void test30() {
    ell.zbrent(-75.5968969095693,59.690260418206066,0 ) ;
  }

  @Test
  public void test31() {
    ell.zbrent(77.28767260185964,-83.82008344970203,0 ) ;
  }

  @Test
  public void test32() {
    ell.zbrent(77.64439750739345,-21.991148575128555,0 ) ;
  }

  @Test
  public void test33() {
    ell.zbrent(-81.68140899333461,48.36715843699042,0 ) ;
  }

  @Test
  public void test34() {
    ell.zbrent(84.82300164692441,-97.03553444889614,0 ) ;
  }

  @Test
  public void test35() {
    ell.zbrent(85.43883639347791,0,0 ) ;
  }

  @Test
  public void test36() {
    ell.zbrent(8.945643989280597,-35.81893687590019,0 ) ;
  }

  @Test
  public void test37() {
    ell.zbrent(-89.75831132258487,-17.684327484947076,0 ) ;
  }

  @Test
  public void test38() {
    ell.zbrent(99.99999994089694,6.283185307179586,0 ) ;
  }
}
