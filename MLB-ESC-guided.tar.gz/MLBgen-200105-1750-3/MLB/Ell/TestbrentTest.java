import org.junit.Test;

public class TestbrentTest {

  @Test
  public void test0() {
    ell.brent(0.0,0.0,0.0,0 ) ;
  }

  @Test
  public void test1() {
    ell.brent(0.3694186738474343,20.670802669235627,65.26287922834743,0 ) ;
  }

  @Test
  public void test2() {
    ell.brent(-100.0,0.0,-74.97150315346877,0 ) ;
  }

  @Test
  public void test3() {
    ell.brent(-100.0,-100.0,-100.0,0 ) ;
  }

  @Test
  public void test4() {
    ell.brent(-100.0,79.5574843931357,-100.0,0 ) ;
  }

  @Test
  public void test5() {
    ell.brent(10.085877287778723,-99.70828201000494,10.085877287778723,0 ) ;
  }

  @Test
  public void test6() {
    ell.brent(10.972774217260403,0,10.972774217260401,0 ) ;
  }

  @Test
  public void test7() {
    ell.brent(12.671283619823665,0.0,12.671283619823665,0 ) ;
  }

  @Test
  public void test8() {
    ell.brent(12.865111576543883,0,12.865111576543883,0 ) ;
  }

  @Test
  public void test9() {
    ell.brent(-14.825240073791885,0.0,14.825240073791885,0 ) ;
  }

  @Test
  public void test10() {
    ell.brent(-15.727303424185706,0.0,-16.689646898320447,0 ) ;
  }

  @Test
  public void test11() {
    ell.brent(-16.69221538289227,0.0,-16.69221538289227,0 ) ;
  }

  @Test
  public void test12() {
    ell.brent(-19.134838811723213,-4.563207501747371,-34.03421256169243,0 ) ;
  }

  @Test
  public void test13() {
    ell.brent(-20.70795747693801,0.0,82.28454421368515,0 ) ;
  }

  @Test
  public void test14() {
    ell.brent(23.613211589738142,0,-96.50797066823908,0 ) ;
  }

  @Test
  public void test15() {
    ell.brent(25.009072228892197,0,25.0090722288922,0 ) ;
  }

  @Test
  public void test16() {
    ell.brent(-29.219587966160418,0,15.288175285891398,0 ) ;
  }

  @Test
  public void test17() {
    ell.brent(-30.152443453106685,21.962182715556125,74.07680888421893,0 ) ;
  }

  @Test
  public void test18() {
    ell.brent(30.637838085866413,-52.971184564069176,30.637838085866413,0 ) ;
  }

  @Test
  public void test19() {
    ell.brent(-32.80858508586313,-6.314905114842718,-32.80858508586313,0 ) ;
  }

  @Test
  public void test20() {
    ell.brent(36.178434348050246,33.14672215039437,36.178434348050246,0 ) ;
  }

  @Test
  public void test21() {
    ell.brent(36.19004449437515,36.19004449437515,36.19004449437515,0 ) ;
  }

  @Test
  public void test22() {
    ell.brent(39.78705056444093,93.83605894428018,39.78705056444093,0 ) ;
  }

  @Test
  public void test23() {
    ell.brent(40.63976868334504,0.0,-40.63976868334504,0 ) ;
  }

  @Test
  public void test24() {
    ell.brent(41.449266797465015,-33.97626411607675,-46.71374788307021,0 ) ;
  }

  @Test
  public void test25() {
    ell.brent(-4.49708710531995,0,-4.497087105319951,0 ) ;
  }

  @Test
  public void test26() {
    ell.brent(-46.02181631050846,-34.69597316713035,-23.370130023752225,0 ) ;
  }

  @Test
  public void test27() {
    ell.brent(47.30060163555558,0,47.30060163555559,0 ) ;
  }

  @Test
  public void test28() {
    ell.brent(-48.19523898402092,-90.32178075503651,5.315624461916158,0 ) ;
  }

  @Test
  public void test29() {
    ell.brent(52.02616371186138,0,52.026163711861386,0 ) ;
  }

  @Test
  public void test30() {
    ell.brent(-53.904594279940895,0,61.2385724451978,0 ) ;
  }

  @Test
  public void test31() {
    ell.brent(54.992006615537775,72.80209850534413,-86.50151086638267,0 ) ;
  }

  @Test
  public void test32() {
    ell.brent(-55.41242181799436,0,-55.41242181799436,0 ) ;
  }

  @Test
  public void test33() {
    ell.brent(-62.611771134937165,4.179057747863453,33.58974715927474,0 ) ;
  }

  @Test
  public void test34() {
    ell.brent(65.79677049290197,0.0,41.18791166269676,0 ) ;
  }

  @Test
  public void test35() {
    ell.brent(70.80320527358609,-24.116976880700534,-87.64969964409572,0 ) ;
  }

  @Test
  public void test36() {
    ell.brent(73.0146108551136,0.0,-4.585920745158333,0 ) ;
  }

  @Test
  public void test37() {
    ell.brent(75.01368763608397,-73.97844891784487,94.98936569704867,0 ) ;
  }

  @Test
  public void test38() {
    ell.brent(75.30380512133925,67.99342605268117,60.68304698402309,0 ) ;
  }

  @Test
  public void test39() {
    ell.brent(-7.533580928344008,0,-7.533580928344007,0 ) ;
  }

  @Test
  public void test40() {
    ell.brent(81.22081933089316,53.968252887706626,28.02160618684399,0 ) ;
  }

  @Test
  public void test41() {
    ell.brent(-8.286558731334608,-51.029440075886676,-93.77232142043874,0 ) ;
  }

  @Test
  public void test42() {
    ell.brent(-83.16593620245318,41.91941810926028,91.7575593493973,0 ) ;
  }

  @Test
  public void test43() {
    ell.brent(-84.54028797948033,0.0,-81.60492561980182,0 ) ;
  }

  @Test
  public void test44() {
    ell.brent(-8.615915852486594,0.0,-8.615915852486594,0 ) ;
  }

  @Test
  public void test45() {
    ell.brent(-91.57290662421485,-32.37249229221018,-57.41871389343394,0 ) ;
  }

  @Test
  public void test46() {
    ell.brent(93.59771464249894,63.15246785732381,31.42813221937223,0 ) ;
  }

  @Test
  public void test47() {
    ell.brent(97.11930282595159,0,-16.458887789389422,0 ) ;
  }
}
