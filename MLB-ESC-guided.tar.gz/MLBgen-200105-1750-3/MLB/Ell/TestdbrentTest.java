import org.junit.Test;

public class TestdbrentTest {

  @Test
  public void test0() {
    ell.dbrent(0.0,0.0,0.0,0 ) ;
  }

  @Test
  public void test1() {
    ell.dbrent(0.0,9.867907256530568E-17,0.0,0 ) ;
  }

  @Test
  public void test2() {
    ell.dbrent(100.0,0.0,-100.0,0 ) ;
  }

  @Test
  public void test3() {
    ell.dbrent(100.0,0.0,100.0,0 ) ;
  }

  @Test
  public void test4() {
    ell.dbrent(-100.0,0.0,-40.87246295774223,0 ) ;
  }

  @Test
  public void test5() {
    ell.dbrent(-100.0,-100.0,-100.0,0 ) ;
  }

  @Test
  public void test6() {
    ell.dbrent(10.474974466764952,0,10.474974466764953,0 ) ;
  }

  @Test
  public void test7() {
    ell.dbrent(1.1441052075326947,0,1.144105207532695,0 ) ;
  }

  @Test
  public void test8() {
    ell.dbrent(12.030840699766618,-32.56811983664985,-77.16708037306631,0 ) ;
  }

  @Test
  public void test9() {
    ell.dbrent(-156.29612237258763,-65.03676414201149,-44.05633184561819,0 ) ;
  }

  @Test
  public void test10() {
    ell.dbrent(-17.992289519094918,0.0,17.992289519094918,0 ) ;
  }

  @Test
  public void test11() {
    ell.dbrent(18.35915857319354,0,34.78799186519058,0 ) ;
  }

  @Test
  public void test12() {
    ell.dbrent(27.180445398095785,0,-60.32622245575152,0 ) ;
  }

  @Test
  public void test13() {
    ell.dbrent(-35.29829677734806,21.950611493814833,-51.72185255198407,0 ) ;
  }

  @Test
  public void test14() {
    ell.dbrent(-35.691657771766586,0.0,-35.69165777176661,0 ) ;
  }

  @Test
  public void test15() {
    ell.dbrent(3.802306043835589,0,3.8023060438355887,0 ) ;
  }

  @Test
  public void test16() {
    ell.dbrent(40.5489010311578,0.0,-40.5489010311578,0 ) ;
  }

  @Test
  public void test17() {
    ell.dbrent(-4.1447777491018485,23.76990613233994,51.68459001378173,0 ) ;
  }

  @Test
  public void test18() {
    ell.dbrent(42.60556254909608,20.07321388449401,69.8976442110066,0 ) ;
  }

  @Test
  public void test19() {
    ell.dbrent(44.1441160788968,0,44.1441160788968,0 ) ;
  }

  @Test
  public void test20() {
    ell.dbrent(-4.661230629899517,0.0,-4.661230629899517,0 ) ;
  }

  @Test
  public void test21() {
    ell.dbrent(48.46618658800139,0.0,1.748676986449496,0 ) ;
  }

  @Test
  public void test22() {
    ell.dbrent(-49.06793961041907,-32.587639343828315,91.15171765105038,0 ) ;
  }

  @Test
  public void test23() {
    ell.dbrent(-51.289533503817125,-4.144898661166377,-51.289533503817125,0 ) ;
  }

  @Test
  public void test24() {
    ell.dbrent(52.330454904361886,33.73323724596733,15.136019587572775,0 ) ;
  }

  @Test
  public void test25() {
    ell.dbrent(-54.339205231532226,0.0,50.918139426553466,0 ) ;
  }

  @Test
  public void test26() {
    ell.dbrent(57.67954146921841,57.67954146921841,57.67954146921841,0 ) ;
  }

  @Test
  public void test27() {
    ell.dbrent(-61.47427045835872,0,-61.474270458358724,0 ) ;
  }

  @Test
  public void test28() {
    ell.dbrent(-61.50968271740904,-39.36323853714121,-94.38925799527375,0 ) ;
  }

  @Test
  public void test29() {
    ell.dbrent(62.7571850227787,15.819686530070856,62.7571850227787,0 ) ;
  }

  @Test
  public void test30() {
    ell.dbrent(63.32187382293449,-32.74569093827199,-55.95320839929207,0 ) ;
  }

  @Test
  public void test31() {
    ell.dbrent(-63.801912906567246,0,-63.80191290656724,0 ) ;
  }

  @Test
  public void test32() {
    ell.dbrent(-63.934222344930866,-35.034391145966765,-6.134559947002666,0 ) ;
  }

  @Test
  public void test33() {
    ell.dbrent(64.54462958562938,0,64.54462958562937,0 ) ;
  }

  @Test
  public void test34() {
    ell.dbrent(66.79995533355407,77.5431239852357,41.5575258806295,0 ) ;
  }

  @Test
  public void test35() {
    ell.dbrent(-66.82035803159359,61.17046462803438,-17.456413609917206,0 ) ;
  }

  @Test
  public void test36() {
    ell.dbrent(69.18124310125421,16.64707924827225,69.18124310125421,0 ) ;
  }

  @Test
  public void test37() {
    ell.dbrent(-70.00023450271364,0.0,97.48138490790993,0 ) ;
  }

  @Test
  public void test38() {
    ell.dbrent(71.41562594195574,0.0,71.41562594195574,0 ) ;
  }

  @Test
  public void test39() {
    ell.dbrent(-76.52856824684548,0,-76.52856824684548,0 ) ;
  }

  @Test
  public void test40() {
    ell.dbrent(-79.56386321400169,-37.61056527708481,-79.56386321400169,0 ) ;
  }

  @Test
  public void test41() {
    ell.dbrent(81.13019742386223,58.7697927944144,50.14083963513232,0 ) ;
  }

  @Test
  public void test42() {
    ell.dbrent(-82.03052753097043,-100.0,-82.03052753097043,0 ) ;
  }

  @Test
  public void test43() {
    ell.dbrent(-83.05930848437737,0,-53.436338562406064,0 ) ;
  }

  @Test
  public void test44() {
    ell.dbrent(8.575476488330196,-98.90296092322201,70.77594366589102,0 ) ;
  }

  @Test
  public void test45() {
    ell.dbrent(89.2269572626727,0,-95.22966624715595,0 ) ;
  }

  @Test
  public void test46() {
    ell.dbrent(-93.07714363805442,32.498636166526836,-75.55321938632207,0 ) ;
  }

  @Test
  public void test47() {
    ell.dbrent(-94.9617783059137,-26.028495011122104,-98.34593006266196,0 ) ;
  }

  @Test
  public void test48() {
    ell.dbrent(-96.52648505922845,56.26545667234154,-96.52648505922845,0 ) ;
  }
}
