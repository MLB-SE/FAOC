import org.junit.Test;

public class JpfTargetCollision1Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision1(569,-649,51,266,533,405 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision1(-917,1580,455,-906,1230,734 ) ;
  }
}
