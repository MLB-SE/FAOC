import org.junit.Test;

public class JpfTargetCollision2Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision2(792,-245,768,-462 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision2(819,986,-605,-568 ) ;
  }
}
