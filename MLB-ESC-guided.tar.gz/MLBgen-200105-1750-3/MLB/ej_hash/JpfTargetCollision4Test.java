import org.junit.Test;

public class JpfTargetCollision4Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision4(-25829,975,640 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision4(-36495,230,476 ) ;
  }

  @Test
  public void test2() {
    EffectiveJavaHashCode.testCollision4(-53239,721,-12 ) ;
  }

  @Test
  public void test3() {
    EffectiveJavaHashCode.testCollision4(831,774,-380 ) ;
  }
}
