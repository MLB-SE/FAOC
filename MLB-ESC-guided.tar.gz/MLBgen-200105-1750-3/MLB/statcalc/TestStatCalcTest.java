import org.junit.Test;

public class TestStatCalcTest {

  @Test
  public void test0() {
    concolic.TestStatCalc.run(-17 ) ;
  }

  @Test
  public void test1() {
    concolic.TestStatCalc.run(3 ) ;
  }

  @Test
  public void test2() {
    concolic.TestStatCalc.run(-361 ) ;
  }

  @Test
  public void test3() {
    concolic.TestStatCalc.run(-38 ) ;
  }

  @Test
  public void test4() {
    concolic.TestStatCalc.run(471 ) ;
  }

  @Test
  public void test5() {
    concolic.TestStatCalc.run(62 ) ;
  }

  @Test
  public void test6() {
    concolic.TestStatCalc.run(656 ) ;
  }

  @Test
  public void test7() {
    concolic.TestStatCalc.run(-670 ) ;
  }

  @Test
  public void test8() {
    concolic.TestStatCalc.run(724 ) ;
  }

  @Test
  public void test9() {
    concolic.TestStatCalc.run(-768 ) ;
  }

  @Test
  public void test10() {
    concolic.TestStatCalc.run(815 ) ;
  }

  @Test
  public void test11() {
    concolic.TestStatCalc.run(-828 ) ;
  }

  @Test
  public void test12() {
    concolic.TestStatCalc.run(-85 ) ;
  }

  @Test
  public void test13() {
    concolic.TestStatCalc.run(-863 ) ;
  }

  @Test
  public void test14() {
    concolic.TestStatCalc.run(870 ) ;
  }

  @Test
  public void test15() {
    concolic.TestStatCalc.run(931 ) ;
  }

  @Test
  public void test16() {
    concolic.TestStatCalc.run(980 ) ;
  }
}
