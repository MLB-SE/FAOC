import org.junit.Test;

public class TestexpintTest {

  @Test
  public void test0() {
    expint.expint(0,0.0 ) ;
  }

  @Test
  public void test1() {
    expint.expint(0,6.5187888899152 ) ;
  }

  @Test
  public void test2() {
    expint.expint(1485,-3.3087224502121107E-24 ) ;
  }

  @Test
  public void test3() {
    expint.expint(1786,8.4E-323 ) ;
  }

  @Test
  public void test4() {
    expint.expint(178,-88.97294778924545 ) ;
  }

  @Test
  public void test5() {
    expint.expint(1799,-7.4E-323 ) ;
  }

  @Test
  public void test6() {
    expint.expint(191,-5.293955920339377E-23 ) ;
  }

  @Test
  public void test7() {
    expint.expint(213,62.470201616790064 ) ;
  }

  @Test
  public void test8() {
    expint.expint(219,0 ) ;
  }

  @Test
  public void test9() {
    expint.expint(302,2.08E-322 ) ;
  }

  @Test
  public void test10() {
    expint.expint(313,5.4E-323 ) ;
  }

  @Test
  public void test11() {
    expint.expint(428,0.0 ) ;
  }

  @Test
  public void test12() {
    expint.expint(490,7.9E-323 ) ;
  }

  @Test
  public void test13() {
    expint.expint(495,-9.4E-323 ) ;
  }

  @Test
  public void test14() {
    expint.expint(-596,0 ) ;
  }

  @Test
  public void test15() {
    expint.expint(649,0.0 ) ;
  }

  @Test
  public void test16() {
    expint.expint(743,95.03113233982887 ) ;
  }

  @Test
  public void test17() {
    expint.expint(799,17.715907532110037 ) ;
  }

  @Test
  public void test18() {
    expint.expint(977,0.0 ) ;
  }
}
