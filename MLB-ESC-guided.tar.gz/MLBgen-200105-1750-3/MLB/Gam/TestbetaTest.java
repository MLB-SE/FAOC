import org.junit.Test;

public class TestbetaTest {

  @Test
  public void test0() {
    beta.beta(-0.2005772326411801,0 ) ;
  }

  @Test
  public void test1() {
    beta.beta(-1.0,0 ) ;
  }

  @Test
  public void test2() {
    beta.beta(-2.0,0 ) ;
  }

  @Test
  public void test3() {
    beta.beta(-27.16044769233126,0 ) ;
  }

  @Test
  public void test4() {
    beta.beta(-3.0,0 ) ;
  }

  @Test
  public void test5() {
    beta.beta(-81.56271678924995,0 ) ;
  }
}
