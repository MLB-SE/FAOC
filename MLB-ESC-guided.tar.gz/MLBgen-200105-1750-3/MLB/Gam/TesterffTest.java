import org.junit.Test;

public class TesterffTest {

  @Test
  public void test0() {
    gam.erff(0.021930088419996323 ) ;
  }

  @Test
  public void test1() {
    gam.erff(0.26009501948529135 ) ;
  }

  @Test
  public void test2() {
    gam.erff(-0.5198927655952819 ) ;
  }

  @Test
  public void test3() {
    gam.erff(-0.6388447287333634 ) ;
  }

  @Test
  public void test4() {
    gam.erff(-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test5() {
    gam.erff(11.511169819413198 ) ;
  }

  @Test
  public void test6() {
    gam.erff(-1.2247448713915892 ) ;
  }

  @Test
  public void test7() {
    gam.erff(1.2247448713915892 ) ;
  }

  @Test
  public void test8() {
    gam.erff(-1.4225655996704496E-160 ) ;
  }

  @Test
  public void test9() {
    gam.erff(-1.5407439555097887E-33 ) ;
  }

  @Test
  public void test10() {
    gam.erff(1.9721522630525295E-31 ) ;
  }

  @Test
  public void test11() {
    gam.erff(23.181982419484413 ) ;
  }

  @Test
  public void test12() {
    gam.erff(2.5269841324701218E-175 ) ;
  }

  @Test
  public void test13() {
    gam.erff(2.710505431213761E-20 ) ;
  }

  @Test
  public void test14() {
    gam.erff(29.709986333269313 ) ;
  }

  @Test
  public void test15() {
    gam.erff(-42.45304524586455 ) ;
  }

  @Test
  public void test16() {
    gam.erff(4.574369721689692 ) ;
  }

  @Test
  public void test17() {
    gam.erff(-71.25253884792426 ) ;
  }

  @Test
  public void test18() {
    gam.erff(8.673617379884035E-19 ) ;
  }

  @Test
  public void test19() {
    gam.erff(-88.43215957320179 ) ;
  }
}
