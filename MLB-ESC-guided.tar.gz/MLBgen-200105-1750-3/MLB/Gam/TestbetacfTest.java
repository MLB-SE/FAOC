import org.junit.Test;

public class TestbetacfTest {

  @Test
  public void test0() {
    beta.betacf(-0.8650836470538934,0,0 ) ;
  }

  @Test
  public void test1() {
    beta.betacf(17.259244702842253,0,0 ) ;
  }

  @Test
  public void test2() {
    beta.betacf(19.41073725841332,9.610337214411047,0.7033074284525939 ) ;
  }

  @Test
  public void test3() {
    beta.betacf(-37.418801648221354,-80.72050020264973,8.31568474108306 ) ;
  }

  @Test
  public void test4() {
    beta.betacf(-45.47560987271875,96.04325691918427,92.67156607847735 ) ;
  }

  @Test
  public void test5() {
    beta.betacf(53.86302736813781,-57.7972612922085,-13.945034389661254 ) ;
  }

  @Test
  public void test6() {
    beta.betacf(60.819974587433165,-61.733070767137875,-67.70368331562337 ) ;
  }

  @Test
  public void test7() {
    beta.betacf(-65.17153425198465,62.97521726091825,29.217792565009802 ) ;
  }

  @Test
  public void test8() {
    beta.betacf(-67.48467731100654,46.56027167497959,3.1773747110185733 ) ;
  }

  @Test
  public void test9() {
    beta.betacf(68.32066439050314,0.6758359614107832,1.004698267838743 ) ;
  }

  @Test
  public void test10() {
    beta.betacf(-69.77539794243286,37.258947427755146,2.1150954933223143 ) ;
  }

  @Test
  public void test11() {
    beta.betacf(-70.76115606518565,87.74033924443677,-4.108628508727975 ) ;
  }

  @Test
  public void test12() {
    beta.betacf(-77.36711201997684,70.88941077384293,11.789230333145568 ) ;
  }

  @Test
  public void test13() {
    beta.betacf(-79.29560715736253,13.63836276645165,73.72971357387976 ) ;
  }

  @Test
  public void test14() {
    beta.betacf(79.93803174104167,-84.39441859428145,-18.16225440172457 ) ;
  }

  @Test
  public void test15() {
    beta.betacf(80.94744591728173,-56.367340836249966,-84.778290079824 ) ;
  }

  @Test
  public void test16() {
    beta.betacf(86.29538791856478,-97.06593760112212,-8.10500768219265 ) ;
  }

  @Test
  public void test17() {
    beta.betacf(91.4892153418923,-90.49322324230506,92.86139456349271 ) ;
  }

  @Test
  public void test18() {
    beta.betacf(94.27177246217758,-58.996747135078294,2.7008278967552455 ) ;
  }
}
