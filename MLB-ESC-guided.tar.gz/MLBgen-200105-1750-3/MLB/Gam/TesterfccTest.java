import org.junit.Test;

public class TesterfccTest {

  @Test
  public void test0() {
    erf.erfcc(1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1() {
    erf.erfcc(-1.2141104988033362 ) ;
  }

  @Test
  public void test2() {
    erf.erfcc(13.115286907108327 ) ;
  }

  @Test
  public void test3() {
    erf.erfcc(1.8E-322 ) ;
  }

  @Test
  public void test4() {
    erf.erfcc(23.161948380354417 ) ;
  }

  @Test
  public void test5() {
    erf.erfcc(4.930380657631324E-32 ) ;
  }

  @Test
  public void test6() {
    erf.erfcc(-4.9E-324 ) ;
  }

  @Test
  public void test7() {
    erf.erfcc(50.449398789843656 ) ;
  }

  @Test
  public void test8() {
    erf.erfcc(-5.551115123125783E-17 ) ;
  }

  @Test
  public void test9() {
    erf.erfcc(-59.31242963206578 ) ;
  }

  @Test
  public void test10() {
    erf.erfcc(-62.40406563317082 ) ;
  }

  @Test
  public void test11() {
    erf.erfcc(-76.75676038636053 ) ;
  }
}
