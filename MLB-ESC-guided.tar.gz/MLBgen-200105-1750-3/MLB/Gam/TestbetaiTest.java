import org.junit.Test;

public class TestbetaiTest {

  @Test
  public void test0() {
    beta.betai(0,0,0.15973834679908272 ) ;
  }

  @Test
  public void test1() {
    beta.betai(0,0,0.9999999999999907 ) ;
  }

  @Test
  public void test2() {
    beta.betai(0,0,0.9999999999999991 ) ;
  }

  @Test
  public void test3() {
    beta.betai(0,0,0.9999999999999998 ) ;
  }

  @Test
  public void test4() {
    beta.betai(0,0,0.9999999999999999 ) ;
  }

  @Test
  public void test5() {
    beta.betai(0,0,1.0000000000000004 ) ;
  }

  @Test
  public void test6() {
    beta.betai(0,0,1.0000000000000018 ) ;
  }

  @Test
  public void test7() {
    beta.betai(0,0,1.0000000000000067 ) ;
  }

  @Test
  public void test8() {
    beta.betai(0,0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test9() {
    beta.betai(0,0,-12.680400413982312 ) ;
  }

  @Test
  public void test10() {
    beta.betai(0,0,-2.2290441239920256 ) ;
  }

  @Test
  public void test11() {
    beta.betai(0,0,31.531289199956348 ) ;
  }

  @Test
  public void test12() {
    beta.betai(0,0,54.93733837889815 ) ;
  }

  @Test
  public void test13() {
    beta.betai(0,0,5.611578061640742 ) ;
  }

  @Test
  public void test14() {
    beta.betai(0,0,-56.69314015598352 ) ;
  }

  @Test
  public void test15() {
    beta.betai(0,0,60.41846725462642 ) ;
  }

  @Test
  public void test16() {
    beta.betai(0,0,6.077163357286271E-64 ) ;
  }

  @Test
  public void test17() {
    beta.betai(0,0,63.1873318143283 ) ;
  }

  @Test
  public void test18() {
    beta.betai(0,0,-64.81002789249091 ) ;
  }

  @Test
  public void test19() {
    beta.betai(0,0,6.863120913952628 ) ;
  }

  @Test
  public void test20() {
    beta.betai(0,0,-73.08251766619486 ) ;
  }

  @Test
  public void test21() {
    beta.betai(0,0,8.843106913072532 ) ;
  }

  @Test
  public void test22() {
    beta.betai(0,0,-9.860761315262648E-32 ) ;
  }
}
