import org.junit.Test;

public class TestbicoTest {

  @Test
  public void test0() {
    gam.bico(0,1 ) ;
  }

  @Test
  public void test1() {
    gam.bico(0,2 ) ;
  }

  @Test
  public void test2() {
    gam.bico(0,747 ) ;
  }

  @Test
  public void test3() {
    gam.bico(0,-898 ) ;
  }

  @Test
  public void test4() {
    gam.bico(1,0 ) ;
  }

  @Test
  public void test5() {
    gam.bico(1,-1 ) ;
  }

  @Test
  public void test6() {
    gam.bico(137,0 ) ;
  }

  @Test
  public void test7() {
    gam.bico(-156,0 ) ;
  }

  @Test
  public void test8() {
    gam.bico(1,-604 ) ;
  }

  @Test
  public void test9() {
    gam.bico(1,758 ) ;
  }

  @Test
  public void test10() {
    gam.bico(2,0 ) ;
  }

  @Test
  public void test11() {
    gam.bico(228,0 ) ;
  }

  @Test
  public void test12() {
    gam.bico(-288,-807 ) ;
  }

  @Test
  public void test13() {
    gam.bico(-370,643 ) ;
  }

  @Test
  public void test14() {
    gam.bico(-472,2 ) ;
  }

  @Test
  public void test15() {
    gam.bico(-492,0 ) ;
  }

  @Test
  public void test16() {
    gam.bico(-506,0 ) ;
  }

  @Test
  public void test17() {
    gam.bico(-518,-224 ) ;
  }

  @Test
  public void test18() {
    gam.bico(519,0 ) ;
  }

  @Test
  public void test19() {
    gam.bico(-565,-1 ) ;
  }

  @Test
  public void test20() {
    gam.bico(63,0 ) ;
  }

  @Test
  public void test21() {
    gam.bico(-713,273 ) ;
  }
}
