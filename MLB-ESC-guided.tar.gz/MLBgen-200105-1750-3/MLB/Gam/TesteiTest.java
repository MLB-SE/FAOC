import org.junit.Test;

public class TesteiTest {

  @Test
  public void test0() {
    expint.ei(21.821636736695524 ) ;
  }

  @Test
  public void test1() {
    expint.ei(2.1913665824935435 ) ;
  }

  @Test
  public void test2() {
    expint.ei(32.23619130191664 ) ;
  }

  @Test
  public void test3() {
    expint.ei(3.63743538610497E-15 ) ;
  }

  @Test
  public void test4() {
    expint.ei(-3.764208578027194 ) ;
  }

  @Test
  public void test5() {
    expint.ei(3.9968028886505635E-15 ) ;
  }

  @Test
  public void test6() {
    expint.ei(40.42492815684645 ) ;
  }

  @Test
  public void test7() {
    expint.ei(-41.208666013138995 ) ;
  }

  @Test
  public void test8() {
    expint.ei(42.101356732938484 ) ;
  }

  @Test
  public void test9() {
    expint.ei(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test10() {
    expint.ei(5.4E-323 ) ;
  }

  @Test
  public void test11() {
    expint.ei(55.92757924905442 ) ;
  }

  @Test
  public void test12() {
    expint.ei(-6.162975822039155E-33 ) ;
  }

  @Test
  public void test13() {
    expint.ei(-79.8604178958588 ) ;
  }

  @Test
  public void test14() {
    expint.ei(9.282304372432378 ) ;
  }

  @Test
  public void test15() {
    expint.ei(9.860761315262648E-32 ) ;
  }
}
