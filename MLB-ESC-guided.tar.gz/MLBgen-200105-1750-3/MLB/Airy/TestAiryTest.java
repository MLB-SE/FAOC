import org.junit.Test;

public class TestAiryTest {

  @Test
  public void test0() {
    airy.main_airy(-0.2084620442351195 ) ;
  }

  @Test
  public void test1() {
    airy.main_airy(-0.6844011771613765 ) ;
  }

  @Test
  public void test2() {
    airy.main_airy(-11.162410813928773 ) ;
  }

  @Test
  public void test3() {
    airy.main_airy(15.89792245514073 ) ;
  }

  @Test
  public void test4() {
    airy.main_airy(-2.220446049250313E-16 ) ;
  }

  @Test
  public void test5() {
    airy.main_airy(-2.465190328815662E-32 ) ;
  }

  @Test
  public void test6() {
    airy.main_airy(2.465190328815662E-32 ) ;
  }

  @Test
  public void test7() {
    airy.main_airy(-3.243452597403234 ) ;
  }

  @Test
  public void test8() {
    airy.main_airy(-33.91188895020359 ) ;
  }

  @Test
  public void test9() {
    airy.main_airy(39.73389140759477 ) ;
  }

  @Test
  public void test10() {
    airy.main_airy(4.3225817678266135E-224 ) ;
  }

  @Test
  public void test11() {
    airy.main_airy(5.551115123125783E-17 ) ;
  }

  @Test
  public void test12() {
    airy.main_airy(-55.973769237290405 ) ;
  }

  @Test
  public void test13() {
    airy.main_airy(-8.645163535653227E-224 ) ;
  }

  @Test
  public void test14() {
    airy.main_airy(86.56829239524308 ) ;
  }

  @Test
  public void test15() {
    airy.main_airy(-8.673617379884035E-19 ) ;
  }

  @Test
  public void test16() {
    airy.main_airy(8.673617379884035E-19 ) ;
  }

  @Test
  public void test17() {
    airy.main_airy(-9.860761315262648E-32 ) ;
  }
}
