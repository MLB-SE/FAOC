import org.junit.Test;

public class TestsphbesTest {

  @Test
  public void test0() {
    airy.sphbes(0,24.550431137693224 ) ;
  }

  @Test
  public void test1() {
    airy.sphbes(0,28.86393800908172 ) ;
  }

  @Test
  public void test2() {
    airy.sphbes(0,33.85933043877529 ) ;
  }

  @Test
  public void test3() {
    airy.sphbes(0,65.68552973902823 ) ;
  }

  @Test
  public void test4() {
    airy.sphbes(0,67.68648895915777 ) ;
  }

  @Test
  public void test5() {
    airy.sphbes(0,75.86008213986898 ) ;
  }

  @Test
  public void test6() {
    airy.sphbes(1000,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test7() {
    airy.sphbes(120,2.0000000000000004 ) ;
  }

  @Test
  public void test8() {
    airy.sphbes(-1,33.71696424861247 ) ;
  }

  @Test
  public void test9() {
    airy.sphbes(1341,2.0000000000000004 ) ;
  }

  @Test
  public void test10() {
    airy.sphbes(-1,69.67778888505373 ) ;
  }

  @Test
  public void test11() {
    airy.sphbes(184,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test12() {
    airy.sphbes(1897,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test13() {
    airy.sphbes(215,24.458983309576226 ) ;
  }

  @Test
  public void test14() {
    airy.sphbes(304,0.0 ) ;
  }

  @Test
  public void test15() {
    airy.sphbes(305,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test16() {
    airy.sphbes(-326,0.0 ) ;
  }

  @Test
  public void test17() {
    airy.sphbes(32,-98.11645001584472 ) ;
  }

  @Test
  public void test18() {
    airy.sphbes(-331,2.0000000000000004 ) ;
  }

  @Test
  public void test19() {
    airy.sphbes(378,3.788804613539168E-17 ) ;
  }

  @Test
  public void test20() {
    airy.sphbes(-403,97.65320346472404 ) ;
  }

  @Test
  public void test21() {
    airy.sphbes(-406,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test22() {
    airy.sphbes(432,7.9E-323 ) ;
  }

  @Test
  public void test23() {
    airy.sphbes(-436,41.18165453096364 ) ;
  }

  @Test
  public void test24() {
    airy.sphbes(-52,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test25() {
    airy.sphbes(556,-3.944304526105059E-31 ) ;
  }

  @Test
  public void test26() {
    airy.sphbes(-56,-19.327487227709412 ) ;
  }

  @Test
  public void test27() {
    airy.sphbes(611,0 ) ;
  }

  @Test
  public void test28() {
    airy.sphbes(652,0.0 ) ;
  }

  @Test
  public void test29() {
    airy.sphbes(659,-6.4E-323 ) ;
  }

  @Test
  public void test30() {
    airy.sphbes(-66,0.0 ) ;
  }

  @Test
  public void test31() {
    airy.sphbes(-67,38.71897093162255 ) ;
  }

  @Test
  public void test32() {
    airy.sphbes(-693,0.0 ) ;
  }

  @Test
  public void test33() {
    airy.sphbes(-774,2.0 ) ;
  }

  @Test
  public void test34() {
    airy.sphbes(803,0.0 ) ;
  }

  @Test
  public void test35() {
    airy.sphbes(807,7.9E-323 ) ;
  }

  @Test
  public void test36() {
    airy.sphbes(813,0.0 ) ;
  }

  @Test
  public void test37() {
    airy.sphbes(-814,2.0000000000000004 ) ;
  }

  @Test
  public void test38() {
    airy.sphbes(829,2.000000000000001 ) ;
  }

  @Test
  public void test39() {
    airy.sphbes(850,15.04942182883849 ) ;
  }

  @Test
  public void test40() {
    airy.sphbes(855,-3.5E-323 ) ;
  }

  @Test
  public void test41() {
    airy.sphbes(862,7.4E-323 ) ;
  }

  @Test
  public void test42() {
    airy.sphbes(896,50.6864285361583 ) ;
  }

  @Test
  public void test43() {
    airy.sphbes(-911,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test44() {
    airy.sphbes(-92,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test45() {
    airy.sphbes(946,-85.17887684310665 ) ;
  }

  @Test
  public void test46() {
    airy.sphbes(-95,0 ) ;
  }

  @Test
  public void test47() {
    airy.sphbes(-953,0.0 ) ;
  }

  @Test
  public void test48() {
    airy.sphbes(-967,-45.75796105316323 ) ;
  }

  @Test
  public void test49() {
    airy.sphbes(-980,0.2565945215714285 ) ;
  }

  @Test
  public void test50() {
    airy.sphbes(983,-1.5E-323 ) ;
  }

  @Test
  public void test51() {
    airy.sphbes(986,-1.5E-323 ) ;
  }

  @Test
  public void test52() {
    airy.sphbes(995,-9.663850545294125 ) ;
  }
}
