import org.junit.Test;

public class JpfTargetPowTestTest {

  @Test
  public void test0() {
    concolic.PowExample.test(1,1 ) ;
  }

  @Test
  public void test1() {
    concolic.PowExample.test(12,144 ) ;
  }

  @Test
  public void test2() {
    concolic.PowExample.test(140,-343 ) ;
  }

  @Test
  public void test3() {
    concolic.PowExample.test(26,-115 ) ;
  }

  @Test
  public void test4() {
    concolic.PowExample.test(38,1444 ) ;
  }

  @Test
  public void test5() {
    concolic.PowExample.test(522,949 ) ;
  }

  @Test
  public void test6() {
    concolic.PowExample.test(57,0 ) ;
  }

  @Test
  public void test7() {
    concolic.PowExample.test(-791,0 ) ;
  }
}
