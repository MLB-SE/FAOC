import org.junit.Test;

public class TestbessiTest {

  @Test
  public void test0() {
    bess.bessi(-212,0 ) ;
  }

  @Test
  public void test1() {
    bess.bessi(234,0.0 ) ;
  }

  @Test
  public void test2() {
    bess.bessi(-255,0.0 ) ;
  }

  @Test
  public void test3() {
    bess.bessi(257,-9.612112446462679E-9 ) ;
  }

  @Test
  public void test4() {
    bess.bessi(371,70.71240830525466 ) ;
  }

  @Test
  public void test5() {
    bess.bessi(-401,9.972734948966686E-9 ) ;
  }

  @Test
  public void test6() {
    bess.bessi(-55,1.0097694583033759E-8 ) ;
  }

  @Test
  public void test7() {
    bess.bessi(-615,-3.174687891005077E-59 ) ;
  }

  @Test
  public void test8() {
    bess.bessi(-684,6.832545862190311E-36 ) ;
  }

  @Test
  public void test9() {
    bess.bessi(-710,95.94148294062535 ) ;
  }

  @Test
  public void test10() {
    bess.bessi(769,-1.0669715991112383E-35 ) ;
  }

  @Test
  public void test11() {
    bess.bessi(788,-1.7503677385671152E-54 ) ;
  }

  @Test
  public void test12() {
    bess.bessi(8,-35.114807411841014 ) ;
  }

  @Test
  public void test13() {
    bess.bessi(838,1.0792341094285383E-10 ) ;
  }

  @Test
  public void test14() {
    bess.bessi(877,0 ) ;
  }

  @Test
  public void test15() {
    bess.bessi(881,-2.341490308575729 ) ;
  }

  @Test
  public void test16() {
    bess.bessi(-8,-86.26480149875965 ) ;
  }

  @Test
  public void test17() {
    bess.bessi(-936,36.45764199663398 ) ;
  }
}
