import org.junit.Test;

public class TestprobksTest {

  @Test
  public void test0() {
    dawson.probks(-15.841081754099491 ) ;
  }

  @Test
  public void test1() {
    dawson.probks(-15.932866213694567 ) ;
  }

  @Test
  public void test2() {
    dawson.probks(18.421810903624888 ) ;
  }

  @Test
  public void test3() {
    dawson.probks(-19.28832388348122 ) ;
  }

  @Test
  public void test4() {
    dawson.probks(-19.288796759403787 ) ;
  }

  @Test
  public void test5() {
    dawson.probks(-19.297331849135507 ) ;
  }

  @Test
  public void test6() {
    dawson.probks(19.299232155960453 ) ;
  }

  @Test
  public void test7() {
    dawson.probks(25.68584793354971 ) ;
  }

  @Test
  public void test8() {
    dawson.probks(4.525628299458646 ) ;
  }

  @Test
  public void test9() {
    dawson.probks(49.94402901656872 ) ;
  }

  @Test
  public void test10() {
    dawson.probks(5.81560486949175 ) ;
  }

  @Test
  public void test11() {
    dawson.probks(-6.461430323348665 ) ;
  }

  @Test
  public void test12() {
    dawson.probks(6.751287137335481 ) ;
  }

  @Test
  public void test13() {
    dawson.probks(76.79235679528824 ) ;
  }

  @Test
  public void test14() {
    dawson.probks(-77.99099238661043 ) ;
  }
}
