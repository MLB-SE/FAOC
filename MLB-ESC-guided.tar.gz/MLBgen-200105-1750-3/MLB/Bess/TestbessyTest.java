import org.junit.Test;

public class TestbessyTest {

  @Test
  public void test0() {
    bess.bessy(135,0 ) ;
  }

  @Test
  public void test1() {
    bess.bessy(-153,0 ) ;
  }

  @Test
  public void test2() {
    bess.bessy(22,17.312196986692598 ) ;
  }

  @Test
  public void test3() {
    bess.bessy(-275,0.0 ) ;
  }

  @Test
  public void test4() {
    bess.bessy(-281,-68.9379883434035 ) ;
  }

  @Test
  public void test5() {
    bess.bessy(39,62.92422865165918 ) ;
  }

  @Test
  public void test6() {
    bess.bessy(-414,8.0 ) ;
  }

  @Test
  public void test7() {
    bess.bessy(680,-49.30470673629519 ) ;
  }

  @Test
  public void test8() {
    bess.bessy(-731,75.2265244389572 ) ;
  }

  @Test
  public void test9() {
    bess.bessy(853,0.0 ) ;
  }

  @Test
  public void test10() {
    bess.bessy(860,8.0 ) ;
  }

  @Test
  public void test11() {
    bess.bessy(-887,8.400563146643862 ) ;
  }
}
