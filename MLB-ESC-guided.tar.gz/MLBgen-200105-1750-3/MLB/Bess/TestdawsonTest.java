import org.junit.Test;

public class TestdawsonTest {

  @Test
  public void test0() {
    dawson.dawson(-0.1999999999999984 ) ;
  }

  @Test
  public void test1() {
    dawson.dawson(-0.1999999999999993 ) ;
  }

  @Test
  public void test2() {
    dawson.dawson(-0.2 ) ;
  }

  @Test
  public void test3() {
    dawson.dawson(-0.20000000000000018 ) ;
  }

  @Test
  public void test4() {
    dawson.dawson(0.20000000000000018 ) ;
  }

  @Test
  public void test5() {
    dawson.dawson(-0.2365269551960819 ) ;
  }

  @Test
  public void test6() {
    dawson.dawson(0.2898959468640189 ) ;
  }

  @Test
  public void test7() {
    dawson.dawson(-0.360389098419013 ) ;
  }

  @Test
  public void test8() {
    dawson.dawson(-0.39999999999999997 ) ;
  }

  @Test
  public void test9() {
    dawson.dawson(0.39999999999999997 ) ;
  }

  @Test
  public void test10() {
    dawson.dawson(-0.4 ) ;
  }

  @Test
  public void test11() {
    dawson.dawson(0.5073187806516315 ) ;
  }

  @Test
  public void test12() {
    dawson.dawson(-0.5110266905287701 ) ;
  }

  @Test
  public void test13() {
    dawson.dawson(-0.5329515167101668 ) ;
  }

  @Test
  public void test14() {
    dawson.dawson(0.5354726994531234 ) ;
  }

  @Test
  public void test15() {
    dawson.dawson(-0.545878822226296 ) ;
  }

  @Test
  public void test16() {
    dawson.dawson(-0.5585396457507291 ) ;
  }

  @Test
  public void test17() {
    dawson.dawson(0.6326914881762902 ) ;
  }

  @Test
  public void test18() {
    dawson.dawson(0.6449357883631789 ) ;
  }

  @Test
  public void test19() {
    dawson.dawson(0.6703485279716874 ) ;
  }

  @Test
  public void test20() {
    dawson.dawson(-0.7003570779414092 ) ;
  }

  @Test
  public void test21() {
    dawson.dawson(-0.7999999999999997 ) ;
  }

  @Test
  public void test22() {
    dawson.dawson(0.7999999999999999 ) ;
  }

  @Test
  public void test23() {
    dawson.dawson(-1.0329009587594782 ) ;
  }

  @Test
  public void test24() {
    dawson.dawson(-10.665873370208928 ) ;
  }

  @Test
  public void test25() {
    dawson.dawson(1.1102230246251565E-16 ) ;
  }

  @Test
  public void test26() {
    dawson.dawson(-1.1436179390813521 ) ;
  }

  @Test
  public void test27() {
    dawson.dawson(1.1594345109043767 ) ;
  }

  @Test
  public void test28() {
    dawson.dawson(-1.4591364555167843 ) ;
  }

  @Test
  public void test29() {
    dawson.dawson(-15.143921723238435 ) ;
  }

  @Test
  public void test30() {
    dawson.dawson(-1.5999999999999999 ) ;
  }

  @Test
  public void test31() {
    dawson.dawson(-1.7005860905822103 ) ;
  }

  @Test
  public void test32() {
    dawson.dawson(-17.149472295335542 ) ;
  }

  @Test
  public void test33() {
    dawson.dawson(1.807212250898199 ) ;
  }

  @Test
  public void test34() {
    dawson.dawson(-20.430037181519495 ) ;
  }

  @Test
  public void test35() {
    dawson.dawson(-20.74674036294934 ) ;
  }

  @Test
  public void test36() {
    dawson.dawson(-21.87104679995737 ) ;
  }

  @Test
  public void test37() {
    dawson.dawson(22.830185497209825 ) ;
  }

  @Test
  public void test38() {
    dawson.dawson(-23.078093386331005 ) ;
  }

  @Test
  public void test39() {
    dawson.dawson(23.75035979536038 ) ;
  }

  @Test
  public void test40() {
    dawson.dawson(2.3999999999999972 ) ;
  }

  @Test
  public void test41() {
    dawson.dawson(-2.4962081374822898 ) ;
  }

  @Test
  public void test42() {
    dawson.dawson(-25.1745930509057 ) ;
  }

  @Test
  public void test43() {
    dawson.dawson(2.595067064320838 ) ;
  }

  @Test
  public void test44() {
    dawson.dawson(26.128443965077125 ) ;
  }

  @Test
  public void test45() {
    dawson.dawson(-27.744774687264197 ) ;
  }

  @Test
  public void test46() {
    dawson.dawson(30.998289687336325 ) ;
  }

  @Test
  public void test47() {
    dawson.dawson(32.59080918367786 ) ;
  }

  @Test
  public void test48() {
    dawson.dawson(-3.5475339562214074 ) ;
  }

  @Test
  public void test49() {
    dawson.dawson(3.593361420723655 ) ;
  }

  @Test
  public void test50() {
    dawson.dawson(40.63596757560015 ) ;
  }

  @Test
  public void test51() {
    dawson.dawson(4.168630768002517 ) ;
  }

  @Test
  public void test52() {
    dawson.dawson(42.92518948223113 ) ;
  }

  @Test
  public void test53() {
    dawson.dawson(-4.31980096960613 ) ;
  }

  @Test
  public void test54() {
    dawson.dawson(4.392586709140318 ) ;
  }

  @Test
  public void test55() {
    dawson.dawson(-48.36204268889808 ) ;
  }

  @Test
  public void test56() {
    dawson.dawson(-4.886944023712626E-11 ) ;
  }

  @Test
  public void test57() {
    dawson.dawson(4.930380657631324E-32 ) ;
  }

  @Test
  public void test58() {
    dawson.dawson(-51.0452365488417 ) ;
  }

  @Test
  public void test59() {
    dawson.dawson(52.408891126556824 ) ;
  }

  @Test
  public void test60() {
    dawson.dawson(53.2039191040171 ) ;
  }

  @Test
  public void test61() {
    dawson.dawson(-54.550607224496225 ) ;
  }

  @Test
  public void test62() {
    dawson.dawson(57.024457299215214 ) ;
  }

  @Test
  public void test63() {
    dawson.dawson(57.024744315849205 ) ;
  }

  @Test
  public void test64() {
    dawson.dawson(-63.36386554774715 ) ;
  }

  @Test
  public void test65() {
    dawson.dawson(6.894300700036808 ) ;
  }

  @Test
  public void test66() {
    dawson.dawson(-6.938893903907228E-18 ) ;
  }

  @Test
  public void test67() {
    dawson.dawson(-70.31649637789138 ) ;
  }

  @Test
  public void test68() {
    dawson.dawson(-71.03884109475591 ) ;
  }

  @Test
  public void test69() {
    dawson.dawson(73.1810976943085 ) ;
  }

  @Test
  public void test70() {
    dawson.dawson(-76.97841904070819 ) ;
  }

  @Test
  public void test71() {
    dawson.dawson(77.39681385161197 ) ;
  }

  @Test
  public void test72() {
    dawson.dawson(-78.44431195506675 ) ;
  }

  @Test
  public void test73() {
    dawson.dawson(8.311542322009075 ) ;
  }

  @Test
  public void test74() {
    dawson.dawson(-86.89895328414066 ) ;
  }

  @Test
  public void test75() {
    dawson.dawson(91.53841759486892 ) ;
  }

  @Test
  public void test76() {
    dawson.dawson(98.01235176199506 ) ;
  }
}
