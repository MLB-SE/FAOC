import org.junit.Test;

public class TestpythagTest {

  @Test
  public void test0() {
    dawson.pythag(0.006696898038465911,-0.0068613101741201365 ) ;
  }

  @Test
  public void test1() {
    dawson.pythag(-0.00929177834374778,6.938893903907228E-18 ) ;
  }

  @Test
  public void test2() {
    dawson.pythag(-0.07105492298965893,-0.07139709206802074 ) ;
  }

  @Test
  public void test3() {
    dawson.pythag(-0.09041331953607468,0.090456288036426 ) ;
  }

  @Test
  public void test4() {
    dawson.pythag(0.17312247014023052,0.1937606900719427 ) ;
  }

  @Test
  public void test5() {
    dawson.pythag(-0.2464108868630984,-0.24641088686309842 ) ;
  }

  @Test
  public void test6() {
    dawson.pythag(-11.202576514876622,-11.202576514876622 ) ;
  }

  @Test
  public void test7() {
    dawson.pythag(1.2154326714572542E-63,6.077163357286271E-64 ) ;
  }

  @Test
  public void test8() {
    dawson.pythag(1.3171582004776283,0.0 ) ;
  }

  @Test
  public void test9() {
    dawson.pythag(-1.33E-322,0.0 ) ;
  }

  @Test
  public void test10() {
    dawson.pythag(-1.347124100284563E-79,-1.3471163367671981E-79 ) ;
  }

  @Test
  public void test11() {
    dawson.pythag(1.3684555315672042E-48,-2.30283248609311E-33 ) ;
  }

  @Test
  public void test12() {
    dawson.pythag(-1.3877787807814457E-17,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test13() {
    dawson.pythag(-1.419980774266862E-16,2.465190328815662E-32 ) ;
  }

  @Test
  public void test14() {
    dawson.pythag(1.4492365555417297E-4,1.5307221916477154E-4 ) ;
  }

  @Test
  public void test15() {
    dawson.pythag(-1.4665382465949007E-15,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test16() {
    dawson.pythag(-15.270511221846974,-70.55948527270432 ) ;
  }

  @Test
  public void test17() {
    dawson.pythag(15.80971888412273,97.34263087075684 ) ;
  }

  @Test
  public void test18() {
    dawson.pythag(1.6016664761464807E-145,-1.6016664761464807E-145 ) ;
  }

  @Test
  public void test19() {
    dawson.pythag(-1.6414786670151784,1.6414786670151784 ) ;
  }

  @Test
  public void test20() {
    dawson.pythag(1.672691727021652E-36,1.6726697317965396E-36 ) ;
  }

  @Test
  public void test21() {
    dawson.pythag(-16.951983474993625,-44.125985137173714 ) ;
  }

  @Test
  public void test22() {
    dawson.pythag(-1.7105694144590177E-49,1.710569414459018E-49 ) ;
  }

  @Test
  public void test23() {
    dawson.pythag(1.734723475976807E-18,3.3087224502121107E-24 ) ;
  }

  @Test
  public void test24() {
    dawson.pythag(1.734723475976807E-18,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test25() {
    dawson.pythag(1.737297061559927E-49,-1.7105694144590052E-49 ) ;
  }

  @Test
  public void test26() {
    dawson.pythag(-17.759839395892662,-17.759839395892662 ) ;
  }

  @Test
  public void test27() {
    dawson.pythag(18.476959514065584,0 ) ;
  }

  @Test
  public void test28() {
    dawson.pythag(-1.8485190408855855E-273,-1.8485190408855855E-273 ) ;
  }

  @Test
  public void test29() {
    dawson.pythag(-1.9114027928366588E-15,-1.9118994796130675E-15 ) ;
  }

  @Test
  public void test30() {
    dawson.pythag(-1.9513107268334483E-81,1.9512956899143948E-81 ) ;
  }

  @Test
  public void test31() {
    dawson.pythag(19.7078692604655,-59.028481505388555 ) ;
  }

  @Test
  public void test32() {
    dawson.pythag(2.0812474159298974E-258,-2.0812474159298974E-258 ) ;
  }

  @Test
  public void test33() {
    dawson.pythag(2.1684043449710089E-19,-0.0014599442727518711 ) ;
  }

  @Test
  public void test34() {
    dawson.pythag(21.715805242689015,59.25235342399358 ) ;
  }

  @Test
  public void test35() {
    dawson.pythag(2.1890398968474071E-47,2.1890398968474215E-47 ) ;
  }

  @Test
  public void test36() {
    dawson.pythag(2.191809349008403E-193,2.4333972048578046E-209 ) ;
  }

  @Test
  public void test37() {
    dawson.pythag(-22.802505745260756,-22.802505745260756 ) ;
  }

  @Test
  public void test38() {
    dawson.pythag(-2.3106488011069819E-274,2.3106488011069819E-274 ) ;
  }

  @Test
  public void test39() {
    dawson.pythag(-2.465190328815662E-32,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test40() {
    dawson.pythag(-2.5989273243022133E-16,-1.0518125775047264E-16 ) ;
  }

  @Test
  public void test41() {
    dawson.pythag(-26.358281853736784,0 ) ;
  }

  @Test
  public void test42() {
    dawson.pythag(26.409120574529595,58.93177078322992 ) ;
  }

  @Test
  public void test43() {
    dawson.pythag(2.7755575615628914E-17,-4.163336342344337E-17 ) ;
  }

  @Test
  public void test44() {
    dawson.pythag(2.805515966730756E-191,3.11474842221799E-207 ) ;
  }

  @Test
  public void test45() {
    dawson.pythag(-29.43723807596686,0.0 ) ;
  }

  @Test
  public void test46() {
    dawson.pythag(-3.0E-323,0.0 ) ;
  }

  @Test
  public void test47() {
    dawson.pythag(3.1164983347608174E-18,3.1165005440270117E-18 ) ;
  }

  @Test
  public void test48() {
    dawson.pythag(32.70108744215071,58.070143477270875 ) ;
  }

  @Test
  public void test49() {
    dawson.pythag(-3.647179577673412E-66,3.6471795776734126E-66 ) ;
  }

  @Test
  public void test50() {
    dawson.pythag(-37.776241955967805,40.7185088181682 ) ;
  }

  @Test
  public void test51() {
    dawson.pythag(3.7973543291797114,0 ) ;
  }

  @Test
  public void test52() {
    dawson.pythag(-3.8509296259375494E-34,-3.8518598887744717E-34 ) ;
  }

  @Test
  public void test53() {
    dawson.pythag(3.8934355277724873E-208,-3.8934355277724873E-208 ) ;
  }

  @Test
  public void test54() {
    dawson.pythag(-3.9484127069845653E-177,-4.383618698016806E-193 ) ;
  }

  @Test
  public void test55() {
    dawson.pythag(-4.383618698016806E-193,4.866794409715609E-209 ) ;
  }

  @Test
  public void test56() {
    dawson.pythag(-46.695801084013816,0.0 ) ;
  }

  @Test
  public void test57() {
    dawson.pythag(4.930380657631324E-32,6.699995066831328E-17 ) ;
  }

  @Test
  public void test58() {
    dawson.pythag(-4.9E-324,0.0 ) ;
  }

  @Test
  public void test59() {
    dawson.pythag(-5.018971805102218,78.41743545767983 ) ;
  }

  @Test
  public void test60() {
    dawson.pythag(50.518590737088346,-73.48612587664114 ) ;
  }

  @Test
  public void test61() {
    dawson.pythag(5.367900371262654E-51,-5.345529420184391E-51 ) ;
  }

  @Test
  public void test62() {
    dawson.pythag(53.7147954677971,53.7147954677971 ) ;
  }

  @Test
  public void test63() {
    dawson.pythag(-5.421010862427522E-20,5.421010862427522E-20 ) ;
  }

  @Test
  public void test64() {
    dawson.pythag(5.421010862427522E-20,5.421010862427522E-20 ) ;
  }

  @Test
  public void test65() {
    dawson.pythag(-54.686450114894505,-29.683185105081208 ) ;
  }

  @Test
  public void test66() {
    dawson.pythag(5.551115123125783E-17,6.938893903907228E-17 ) ;
  }

  @Test
  public void test67() {
    dawson.pythag(55.91462872046981,-55.91462872046981 ) ;
  }

  @Test
  public void test68() {
    dawson.pythag(-59.391581889767174,0.0 ) ;
  }

  @Test
  public void test69() {
    dawson.pythag(6.162975822039155E-33,6.162975833345529E-33 ) ;
  }

  @Test
  public void test70() {
    dawson.pythag(6.1941267784932705,-9.333527063179986 ) ;
  }

  @Test
  public void test71() {
    dawson.pythag(-6.22949684443598E-207,-6.22949684443598E-207 ) ;
  }

  @Test
  public void test72() {
    dawson.pythag(-6.26798351880562E-18,6.267983518805645E-18 ) ;
  }

  @Test
  public void test73() {
    dawson.pythag(-62.764480470554915,-83.20475190406597 ) ;
  }

  @Test
  public void test74() {
    dawson.pythag(-6.295632414722888,-35.340128781178734 ) ;
  }

  @Test
  public void test75() {
    dawson.pythag(63.6768257822703,-63.6768257822703 ) ;
  }

  @Test
  public void test76() {
    dawson.pythag(64.31676452371181,0.0 ) ;
  }

  @Test
  public void test77() {
    dawson.pythag(-6.747006683667535E-80,6.747010288274753E-80 ) ;
  }

  @Test
  public void test78() {
    dawson.pythag(7.1202363472230444E-307,0.0 ) ;
  }

  @Test
  public void test79() {
    dawson.pythag(75.48592264736598,68.64506997206809 ) ;
  }

  @Test
  public void test80() {
    dawson.pythag(7.669166043241944,-75.46960838196233 ) ;
  }

  @Test
  public void test81() {
    dawson.pythag(-7.703719777548943E-34,7.707457960399999E-34 ) ;
  }

  @Test
  public void test82() {
    dawson.pythag(-7.87453334088093,64.78364783254895 ) ;
  }

  @Test
  public void test83() {
    dawson.pythag(-7.888609052210118E-31,1.0966811101631496E-16 ) ;
  }

  @Test
  public void test84() {
    dawson.pythag(80.69787727362993,61.94979496391929 ) ;
  }

  @Test
  public void test85() {
    dawson.pythag(81.2683512831035,-81.2683512831035 ) ;
  }

  @Test
  public void test86() {
    dawson.pythag(82.02361029154186,82.02361029154186 ) ;
  }

  @Test
  public void test87() {
    dawson.pythag(-82.94503893619398,78.83609331622819 ) ;
  }

  @Test
  public void test88() {
    dawson.pythag(-8.404308730554439E-52,-8.404308730554444E-52 ) ;
  }

  @Test
  public void test89() {
    dawson.pythag(-84.31670152444173,9.581977018611141 ) ;
  }

  @Test
  public void test90() {
    dawson.pythag(8.552847072295026E-50,-8.569551851733102E-50 ) ;
  }

  @Test
  public void test91() {
    dawson.pythag(86.98312811553964,-8.057473982111631 ) ;
  }

  @Test
  public void test92() {
    dawson.pythag(-88.89527693149788,96.30116988580318 ) ;
  }

  @Test
  public void test93() {
    dawson.pythag(-91.19080749229533,91.19080749229533 ) ;
  }

  @Test
  public void test94() {
    dawson.pythag(9.241293110140678E-67,9.242021722500242E-67 ) ;
  }

  @Test
  public void test95() {
    dawson.pythag(-92.57117897879415,92.57117897879415 ) ;
  }

  @Test
  public void test96() {
    dawson.pythag(9.273015376718553E-69,-9.852578837763463E-69 ) ;
  }

  @Test
  public void test97() {
    dawson.pythag(-94.83873494434962,-91.64358671156569 ) ;
  }

  @Test
  public void test98() {
    dawson.pythag(9.4E-323,0.0 ) ;
  }

  @Test
  public void test99() {
    dawson.pythag(9.629649721936179E-35,9.629928475485128E-35 ) ;
  }

  @Test
  public void test100() {
    dawson.pythag(96.49901027344868,0.0 ) ;
  }

  @Test
  public void test101() {
    dawson.pythag(-9.757252424891547E-35,9.757252486860912E-35 ) ;
  }

  @Test
  public void test102() {
    dawson.pythag(98.44136344158457,98.44136344158457 ) ;
  }

  @Test
  public void test103() {
    dawson.pythag(-9.871031767461413E-178,9.871031767461413E-178 ) ;
  }

  @Test
  public void test104() {
    dawson.pythag(99.45505356125634,-14.177045033847861 ) ;
  }
}
