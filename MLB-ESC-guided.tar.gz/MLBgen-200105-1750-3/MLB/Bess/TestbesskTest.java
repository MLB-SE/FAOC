import org.junit.Test;

public class TestbesskTest {

  @Test
  public void test0() {
    bess.bessk(-1218,2.0 ) ;
  }

  @Test
  public void test1() {
    bess.bessk(123,-5.4E-323 ) ;
  }

  @Test
  public void test2() {
    bess.bessk(-199,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test3() {
    bess.bessk(239,56.87281996004768 ) ;
  }

  @Test
  public void test4() {
    bess.bessk(-284,1.7032145122068658 ) ;
  }

  @Test
  public void test5() {
    bess.bessk(-306,-38.41735089195848 ) ;
  }

  @Test
  public void test6() {
    bess.bessk(388,2.0 ) ;
  }

  @Test
  public void test7() {
    bess.bessk(406,-79.32796536014379 ) ;
  }

  @Test
  public void test8() {
    bess.bessk(-407,-76.17520793993114 ) ;
  }

  @Test
  public void test9() {
    bess.bessk(-410,2.0 ) ;
  }

  @Test
  public void test10() {
    bess.bessk(450,1.3198160702491748 ) ;
  }

  @Test
  public void test11() {
    bess.bessk(530,-92.35101298228838 ) ;
  }

  @Test
  public void test12() {
    bess.bessk(541,9.4E-323 ) ;
  }

  @Test
  public void test13() {
    bess.bessk(574,0.0 ) ;
  }

  @Test
  public void test14() {
    bess.bessk(-641,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test15() {
    bess.bessk(644,1.6105493574023377E-16 ) ;
  }

  @Test
  public void test16() {
    bess.bessk(656,-83.56227688447093 ) ;
  }

  @Test
  public void test17() {
    bess.bessk(-665,0.0 ) ;
  }

  @Test
  public void test18() {
    bess.bessk(-666,8.98332417383296E-14 ) ;
  }

  @Test
  public void test19() {
    bess.bessk(-682,1.4345826087274479E-16 ) ;
  }

  @Test
  public void test20() {
    bess.bessk(-708,-0.6426454645237669 ) ;
  }

  @Test
  public void test21() {
    bess.bessk(-709,0 ) ;
  }

  @Test
  public void test22() {
    bess.bessk(751,4.440892098500626E-16 ) ;
  }

  @Test
  public void test23() {
    bess.bessk(-757,14.035386773720873 ) ;
  }

  @Test
  public void test24() {
    bess.bessk(76,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test25() {
    bess.bessk(810,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test26() {
    bess.bessk(-823,7.4E-323 ) ;
  }

  @Test
  public void test27() {
    bess.bessk(-976,1.5E-323 ) ;
  }

  @Test
  public void test28() {
    bess.bessk(976,2.0 ) ;
  }

  @Test
  public void test29() {
    bess.bessk(985,0 ) ;
  }
}
