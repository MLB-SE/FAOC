import org.junit.Test;

public class TestbessjTest {

  @Test
  public void test0() {
    bess.bessj(0,4.9E-324 ) ;
  }

  @Test
  public void test1() {
    bess.bessj(100,-100.0 ) ;
  }

  @Test
  public void test2() {
    bess.bessj(-1003,-8.682651365176084E-165 ) ;
  }

  @Test
  public void test3() {
    bess.bessj(1,-0.7792295830119791 ) ;
  }

  @Test
  public void test4() {
    bess.bessj(1,-1.0 ) ;
  }

  @Test
  public void test5() {
    bess.bessj(1,1.0 ) ;
  }

  @Test
  public void test6() {
    bess.bessj(1,3.552713678800501E-15 ) ;
  }

  @Test
  public void test7() {
    bess.bessj(163,87.40016774312065 ) ;
  }

  @Test
  public void test8() {
    bess.bessj(189,189.0 ) ;
  }

  @Test
  public void test9() {
    bess.bessj(-206,4.9E-323 ) ;
  }

  @Test
  public void test10() {
    bess.bessj(-21,-5.882269116644707 ) ;
  }

  @Test
  public void test11() {
    bess.bessj(259,-87.03603145755446 ) ;
  }

  @Test
  public void test12() {
    bess.bessj(-267,-2.2761049594727193E-159 ) ;
  }

  @Test
  public void test13() {
    bess.bessj(2826,9.892073618781494E-161 ) ;
  }

  @Test
  public void test14() {
    bess.bessj(-284,94.20278877609096 ) ;
  }

  @Test
  public void test15() {
    bess.bessj(286,-5.4266571032350524E-166 ) ;
  }

  @Test
  public void test16() {
    bess.bessj(301,70.72616728423901 ) ;
  }

  @Test
  public void test17() {
    bess.bessj(302,0 ) ;
  }

  @Test
  public void test18() {
    bess.bessj(304,22.101388941088913 ) ;
  }

  @Test
  public void test19() {
    bess.bessj(335,0.0 ) ;
  }

  @Test
  public void test20() {
    bess.bessj(-364,0.0 ) ;
  }

  @Test
  public void test21() {
    bess.bessj(3704,6.480399879996644E-162 ) ;
  }

  @Test
  public void test22() {
    bess.bessj(-379,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test23() {
    bess.bessj(404,-22.128076209461483 ) ;
  }

  @Test
  public void test24() {
    bess.bessj(-440,0 ) ;
  }

  @Test
  public void test25() {
    bess.bessj(-493,3.552713678800501E-15 ) ;
  }

  @Test
  public void test26() {
    bess.bessj(496,6.3174603311753045E-176 ) ;
  }

  @Test
  public void test27() {
    bess.bessj(555,-55.17180078529198 ) ;
  }

  @Test
  public void test28() {
    bess.bessj(-571,0.0 ) ;
  }

  @Test
  public void test29() {
    bess.bessj(-577,65.24842435259123 ) ;
  }

  @Test
  public void test30() {
    bess.bessj(63,96.43203521410527 ) ;
  }

  @Test
  public void test31() {
    bess.bessj(672,-7.112827998352248E-161 ) ;
  }

  @Test
  public void test32() {
    bess.bessj(-679,-21.55079876290766 ) ;
  }

  @Test
  public void test33() {
    bess.bessj(68,-94.08740192967852 ) ;
  }

  @Test
  public void test34() {
    bess.bessj(-691,5.6902623986817984E-160 ) ;
  }

  @Test
  public void test35() {
    bess.bessj(-693,0.0 ) ;
  }

  @Test
  public void test36() {
    bess.bessj(743,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test37() {
    bess.bessj(-755,-47.28719188977391 ) ;
  }

  @Test
  public void test38() {
    bess.bessj(-762,1.0107936529880487E-174 ) ;
  }

  @Test
  public void test39() {
    bess.bessj(764,1.7365302730352168E-164 ) ;
  }

  @Test
  public void test40() {
    bess.bessj(803,2.0E-323 ) ;
  }

  @Test
  public void test41() {
    bess.bessj(830,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test42() {
    bess.bessj(-840,8.881784197001252E-16 ) ;
  }

  @Test
  public void test43() {
    bess.bessj(-924,-5.0539682649402436E-175 ) ;
  }

  @Test
  public void test44() {
    bess.bessj(94,0.0 ) ;
  }

  @Test
  public void test45() {
    bess.bessj(-956,83.10751809572642 ) ;
  }

  @Test
  public void test46() {
    bess.bessj(-976,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test47() {
    bess.bessj(984,0.0 ) ;
  }
}
