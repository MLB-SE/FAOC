import org.junit.Test;

public class ConflictTest {

  @Test
  public void test0() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,0.0 ) ;
  }

  @Test
  public void test2() {
    tsafe.Conflict.snippet(0.0,0.0,0,0,0,0,49.59095489767688 ) ;
  }

  @Test
  public void test3() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,2.134E-321 ) ;
  }

  @Test
  public void test4() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,-4.5E-322 ) ;
  }

  @Test
  public void test5() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,-47.82713546484432 ) ;
  }

  @Test
  public void test6() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,-9.078269345434492 ) ;
  }

  @Test
  public void test7() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,97.88161376865537 ) ;
  }

  @Test
  public void test8() {
    tsafe.Conflict.snippet(0.0,100.0,85.52903196066217,-0.9626225770993764,-1.445075375741169,66.40559505150726,-95.86298201295573 ) ;
  }

  @Test
  public void test9() {
    tsafe.Conflict.snippet(0.0,-100.0,8.577719588324516E-11,0,0,0,90.0 ) ;
  }

  @Test
  public void test10() {
    tsafe.Conflict.snippet(0.0,-108.89926500374969,82.29570253150516,1017.1735538768421,60.09664641007738,31.933314854137052,-100.0 ) ;
  }

  @Test
  public void test11() {
    tsafe.Conflict.snippet(0.0,-11.021907327668771,6.494561962813915,-20.995114819331313,-40.71592936758199,-67.46691494175282,-66.14972731935082 ) ;
  }

  @Test
  public void test12() {
    tsafe.Conflict.snippet(0.0,-16.85457455902562,-58.16650124265952,-979.6010093631024,195.91544690787583,2.4352670748738348,-214.1271824792983 ) ;
  }

  @Test
  public void test13() {
    tsafe.Conflict.snippet(0.0,25.817458256597224,50.22301123539851,1.9996827814277307,-0.035619849262096485,-40.04003638934471,-30.2227372782762 ) ;
  }

  @Test
  public void test14() {
    tsafe.Conflict.snippet(0.0,26.00570864319556,-162.07941420215275,980.0880846215397,193.46407892162918,63.20678821649415,53.42795295054498 ) ;
  }

  @Test
  public void test15() {
    tsafe.Conflict.snippet(0.0,27.506815923896486,100.0,0,0,0,35.34378340693416 ) ;
  }

  @Test
  public void test16() {
    tsafe.Conflict.snippet(0.0,29.256330766848677,-5.80055423563359,-69.35442179656891,6.423998877127419,65.06229733577246,-8.091442320745845 ) ;
  }

  @Test
  public void test17() {
    tsafe.Conflict.snippet(0.0,35.96878030357496,-152.8264279159869,-997.9296758941077,46.23161223536517,110.15024410738002,97.15731941844135 ) ;
  }

  @Test
  public void test18() {
    tsafe.Conflict.snippet(0.0,39.48362932458554,-7.0958444012034665E-62,0,0,0,90.0 ) ;
  }

  @Test
  public void test19() {
    tsafe.Conflict.snippet(0.0,43.95050325837626,242.07488104462556,988.566295391271,144.04495061054538,-133.01525609205575,86.70670787260212 ) ;
  }

  @Test
  public void test20() {
    tsafe.Conflict.snippet(0.0,63.81646723403614,-7.051379786536867E-99,0,0,0,-90.0 ) ;
  }

  @Test
  public void test21() {
    tsafe.Conflict.snippet(0.0,-68.65419492189048,1.000500532994888E-27,0,0,0,90.0 ) ;
  }

  @Test
  public void test22() {
    tsafe.Conflict.snippet(0.0,-73.3621709903288,0,0,0,0,-4.190985998350067 ) ;
  }

  @Test
  public void test23() {
    tsafe.Conflict.snippet(0.0,-79.94335254880406,-29.59856148519421,-244.97021306539366,-968.4991454362238,91.41994299920015,-5.355535683531443 ) ;
  }

  @Test
  public void test24() {
    tsafe.Conflict.snippet(-100.0,0,0,0,0,0,1.1817387203E-314 ) ;
  }

  @Test
  public void test25() {
    tsafe.Conflict.snippet(-100.0,0,0,0,0,0,-6.32E-322 ) ;
  }

  @Test
  public void test26() {
    tsafe.Conflict.snippet(-100.0,100.0,-1.5673489367736314E-10,0,0,0,-90.0 ) ;
  }

  @Test
  public void test27() {
    tsafe.Conflict.snippet(-100.0,100.0,6.762110015541278E-42,0,0,0,90.0 ) ;
  }

  @Test
  public void test28() {
    tsafe.Conflict.snippet(-100.0,-23.48346257040517,-9.949235952877995E-31,0,0,0,90.0 ) ;
  }

  @Test
  public void test29() {
    tsafe.Conflict.snippet(100.0,34.04027407077473,-13.642229863098747,-20.470292546650068,-2.548988756947417,4.943077636704421,0.0014550487884674723 ) ;
  }

  @Test
  public void test30() {
    tsafe.Conflict.snippet(-100.0,73.9488502868181,-100.0,-2.867817103476904,5.385554311191086,-37.2258040642831,2.9020568555587847 ) ;
  }

  @Test
  public void test31() {
    tsafe.Conflict.snippet(11.165803294590637,-66.00589002459546,8.606288103311773E-76,0,0,0,-90.0 ) ;
  }

  @Test
  public void test32() {
    tsafe.Conflict.snippet(-11.927740588318784,-72.02812967727763,0,0,0,0,-91.18822475630151 ) ;
  }

  @Test
  public void test33() {
    tsafe.Conflict.snippet(-155.4576208277684,45.59609054144117,-14.106865583116104,267.4482544946147,962.5381513695085,-86.76680965501208,-152.9477680177082 ) ;
  }

  @Test
  public void test34() {
    tsafe.Conflict.snippet(1.7E-322,0,0,0,0,0,-79.00340717029002 ) ;
  }

  @Test
  public void test35() {
    tsafe.Conflict.snippet(-1.83E-322,0,0,0,0,0,-71.287039160266 ) ;
  }

  @Test
  public void test36() {
    tsafe.Conflict.snippet(-1.8E-322,0,0,0,0,0,59.15145586211288 ) ;
  }

  @Test
  public void test37() {
    tsafe.Conflict.snippet(2.0E-322,0,0,0,0,0,-22.618600089606268 ) ;
  }

  @Test
  public void test38() {
    tsafe.Conflict.snippet(-220.307393016056,92.11748833420188,165.2600564418184,-980.3524762437602,-187.9147639373846,-7.023481526279426,-35.86318080177527 ) ;
  }

  @Test
  public void test39() {
    tsafe.Conflict.snippet(-2.4113677446213622E-4,-84.54795661889858,-45.62339453271828,-55.91372965349264,-1022.067932498665,-66.30191729039359,-11.52328007699063 ) ;
  }

  @Test
  public void test40() {
    tsafe.Conflict.snippet(-25.209498070594265,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test41() {
    tsafe.Conflict.snippet(2.590327E-318,0,0,0,0,0,10.431366793645338 ) ;
  }

  @Test
  public void test42() {
    tsafe.Conflict.snippet(26.43196862392079,0,0,0,0,0,-1.83E-322 ) ;
  }

  @Test
  public void test43() {
    tsafe.Conflict.snippet(-27.466410592446564,-73.65809890648806,90.43332192460579,-87.14519377558318,-23.351158027029626,-19.61459088890733,36.29173772855043 ) ;
  }

  @Test
  public void test44() {
    tsafe.Conflict.snippet(2.8E-322,0,0,0,0,0,-100.0 ) ;
  }

  @Test
  public void test45() {
    tsafe.Conflict.snippet(3.552713678800501E-15,0,0,0,0,0,-4.070447311238354 ) ;
  }

  @Test
  public void test46() {
    tsafe.Conflict.snippet(36.44076624578355,-100.0,-1.3365515239706263E-12,0,0,0,90.0 ) ;
  }

  @Test
  public void test47() {
    tsafe.Conflict.snippet(37.18475564131404,63.211285115487755,0,0,0,0,-60.24608441460704 ) ;
  }

  @Test
  public void test48() {
    tsafe.Conflict.snippet(-38.1293730558443,102.12346274506675,144.2482732359303,-983.8771703594107,-172.71675080875815,-84.481638649334,46.142048468628644 ) ;
  }

  @Test
  public void test49() {
    tsafe.Conflict.snippet(-4.4092581548671035,0,0,0,0,0,-38.329047594798624 ) ;
  }

  @Test
  public void test50() {
    tsafe.Conflict.snippet(-46.327617779853234,0,0,0,0,0,0.0 ) ;
  }

  @Test
  public void test51() {
    tsafe.Conflict.snippet(4.908500567858809,0,0,0,0,0,9.695145391465545 ) ;
  }

  @Test
  public void test52() {
    tsafe.Conflict.snippet(50.933980456064035,82.75521905042747,-11.178209759677808,82.76069149195392,89.33870867599545,-67.60544823890368,-8.274040282617301E-5 ) ;
  }

  @Test
  public void test53() {
    tsafe.Conflict.snippet(-57.039425797778826,22.522391974740998,-78.7805373686398,1.9453503541680974,0.4667284666891449,-70.1159745023753,91.44038227369688 ) ;
  }

  @Test
  public void test54() {
    tsafe.Conflict.snippet(57.17264696798381,100.0,4.49459963133408E-27,0,0,0,-90.0 ) ;
  }

  @Test
  public void test55() {
    tsafe.Conflict.snippet(-60.81107448992733,0,0,0,0,0,-54.1060885791987 ) ;
  }

  @Test
  public void test56() {
    tsafe.Conflict.snippet(-61.58876434677113,39.769378521717414,-2.603637535939677E-83,0,0,0,-90.0 ) ;
  }

  @Test
  public void test57() {
    tsafe.Conflict.snippet(62.778962256970146,-44.817806093291225,25.4564208834623,-11.309138049160254,-64.36689963248688,5.202312250919334,-43.074003754777564 ) ;
  }

  @Test
  public void test58() {
    tsafe.Conflict.snippet(-6.47582E-319,0,0,0,0,0,2.096896219923822 ) ;
  }

  @Test
  public void test59() {
    tsafe.Conflict.snippet(-6.47582E-319,0,0,0,0,0,-94.50680869528199 ) ;
  }

  @Test
  public void test60() {
    tsafe.Conflict.snippet(-66.45199009606661,88.37210199694769,-111.47373647988309,156.17078854402519,-987.3386512636587,-51.66014054548572,-188.66836376876037 ) ;
  }

  @Test
  public void test61() {
    tsafe.Conflict.snippet(-68.83822026152939,0.0,0,0,0,0,-71.61817172559915 ) ;
  }

  @Test
  public void test62() {
    tsafe.Conflict.snippet(70.25744503101772,0,0,0,0,0,-2.8E-322 ) ;
  }

  @Test
  public void test63() {
    tsafe.Conflict.snippet(-71.07359726477415,-70.39105131220307,63.45644618707769,-81.2395194465352,12.781887945000591,-70.64909644056763,-54.354163929045015 ) ;
  }

  @Test
  public void test64() {
    tsafe.Conflict.snippet(-72.48459133447213,60.08257033823503,-85.14199343767126,-274.87233443804485,985.8908436677663,-9.007530295862594,100.0 ) ;
  }

  @Test
  public void test65() {
    tsafe.Conflict.snippet(75.37274122347677,136.2076048920281,100.0,0.4294018996087763,2.0228679312612714,-75.39699377400979,-143.01499744831864 ) ;
  }

  @Test
  public void test66() {
    tsafe.Conflict.snippet(76.9557818712612,0.0,0,0,0,0,69.12151162954179 ) ;
  }

  @Test
  public void test67() {
    tsafe.Conflict.snippet(78.07992294504123,19.56456445238055,18.952177159351507,0,0,0,19.420280985871912 ) ;
  }

  @Test
  public void test68() {
    tsafe.Conflict.snippet(78.85481935463689,0,0,0,0,0,0.0 ) ;
  }

  @Test
  public void test69() {
    tsafe.Conflict.snippet(79.12044245697084,0.9147200342135591,-93.55374126665875,-12.831325236132727,70.70223736248283,-5.629018813309372,8.149677419386663 ) ;
  }

  @Test
  public void test70() {
    tsafe.Conflict.snippet(-80.15311997395429,-68.27216772602718,20.287942288122096,0,0,0,-6.209950525477922 ) ;
  }

  @Test
  public void test71() {
    tsafe.Conflict.snippet(-80.962776550355,0,0,0,0,0,-86.8838939928138 ) ;
  }

  @Test
  public void test72() {
    tsafe.Conflict.snippet(87.60955121453098,-29.04017948687946,46.29976120374952,-1.85834700112943,0.7395860633321042,-26.05231502546246,-90.28898174672221 ) ;
  }

  @Test
  public void test73() {
    tsafe.Conflict.snippet(87.947893412839,0,0,0,0,0,-92.75823974726916 ) ;
  }

  @Test
  public void test74() {
    tsafe.Conflict.snippet(8.881784197001252E-16,0,0,0,0,0,-100.0 ) ;
  }

  @Test
  public void test75() {
    tsafe.Conflict.snippet(-8.881784197001252E-16,0,0,0,0,0,-6.399569571911173 ) ;
  }

  @Test
  public void test76() {
    tsafe.Conflict.snippet(89.38506797360753,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test77() {
    tsafe.Conflict.snippet(92.75030791584727,67.52408527544085,2.9724362071600814E-45,0,0,0,-90.0 ) ;
  }

  @Test
  public void test78() {
    tsafe.Conflict.snippet(98.03008749519157,0,0,0,0,0,-14.99393531731667 ) ;
  }
}
