import org.junit.Test;

public class JpfTargetRungeKuttaTest {

  @Test
  public void test0() {
    scic.RungeKutta.rungeKutta(2711.7999466947076 ) ;
  }

  @Test
  public void test1() {
    scic.RungeKutta.rungeKutta(2714.5364487513384 ) ;
  }

  @Test
  public void test2() {
    scic.RungeKutta.rungeKutta(2715.9228149656765 ) ;
  }

  @Test
  public void test3() {
    scic.RungeKutta.rungeKutta(2721.2673685271984 ) ;
  }

  @Test
  public void test4() {
    scic.RungeKutta.rungeKutta(2732.768601932426 ) ;
  }

  @Test
  public void test5() {
    scic.RungeKutta.rungeKutta(2735.418898839084 ) ;
  }

  @Test
  public void test6() {
    scic.RungeKutta.rungeKutta(40.74013548969924 ) ;
  }

  @Test
  public void test7() {
    scic.RungeKutta.rungeKutta(-58.93056821226792 ) ;
  }

  @Test
  public void test8() {
    scic.RungeKutta.rungeKutta(65.34024528294694 ) ;
  }

  @Test
  public void test9() {
    scic.RungeKutta.rungeKutta(-69.27050432318853 ) ;
  }

  @Test
  public void test10() {
    scic.RungeKutta.rungeKutta(-70.89964401179569 ) ;
  }

  @Test
  public void test11() {
    scic.RungeKutta.rungeKutta(-78.61142498288723 ) ;
  }

  @Test
  public void test12() {
    scic.RungeKutta.rungeKutta(85.11440406926212 ) ;
  }

  @Test
  public void test13() {
    scic.RungeKutta.rungeKutta(87.7168326254801 ) ;
  }

  @Test
  public void test14() {
    scic.RungeKutta.rungeKutta(93.12289503343109 ) ;
  }

  @Test
  public void test15() {
    scic.RungeKutta.rungeKutta(95.64640054424513 ) ;
  }

  @Test
  public void test16() {
    scic.RungeKutta.rungeKutta(96.52319181545192 ) ;
  }

  @Test
  public void test17() {
    scic.RungeKutta.rungeKutta(97.5134334575906 ) ;
  }
}
