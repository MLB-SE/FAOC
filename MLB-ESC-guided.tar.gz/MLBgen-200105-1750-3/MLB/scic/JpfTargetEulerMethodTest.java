import org.junit.Test;

public class JpfTargetEulerMethodTest {

  @Test
  public void test0() {
    scic.EulerMethod.euler(-16.567104700295786 ) ;
  }

  @Test
  public void test1() {
    scic.EulerMethod.euler(-1.994622194607021 ) ;
  }

  @Test
  public void test2() {
    scic.EulerMethod.euler(-27.250609501238117 ) ;
  }
}
