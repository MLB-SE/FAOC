import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(-0.0388788332129319,0.3767545770676237 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(-0.1252182734446876,-33.17589709683028 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(-0.257311085914381,0 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(-0.5157455773107102,-98.3707974933288 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(-0.7729147979895142,0.05190173018551847 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(-0.9386606951586174,0 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonSimpson.newton(1.8031898856115731,0 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonSimpson.newton(-18.799150444700416,0 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonSimpson.newton(-20.415452644592634,31.985787552537005 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonSimpson.newton(-2.162085559785453,-14.69052234139781 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonSimpson.newton(22.576951109773518,0 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonSimpson.newton(-26.726562303396534,78.04371113953673 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonSimpson.newton(2.7407936043931187,-9.223037577334225 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonSimpson.newton(2.7885498561656163,0 ) ;
  }

  @Test
  public void test14() {
    scic.NewtonSimpson.newton(-29.69633162008438,0 ) ;
  }

  @Test
  public void test15() {
    scic.NewtonSimpson.newton(3.3074711965651176,-37.46925215832595 ) ;
  }

  @Test
  public void test16() {
    scic.NewtonSimpson.newton(-35.29085371233191,-10.355219203917756 ) ;
  }

  @Test
  public void test17() {
    scic.NewtonSimpson.newton(-35.95662536167819,69.9097785777771 ) ;
  }

  @Test
  public void test18() {
    scic.NewtonSimpson.newton(-4.659990330121616,0 ) ;
  }

  @Test
  public void test19() {
    scic.NewtonSimpson.newton(-5.296379175270303,0 ) ;
  }

  @Test
  public void test20() {
    scic.NewtonSimpson.newton(-91.39421724349688,0 ) ;
  }

  @Test
  public void test21() {
    scic.NewtonSimpson.newton(9.611032323618048,-36.61049385275206 ) ;
  }
}
