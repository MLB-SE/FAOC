import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(-25.80324176464468,0.05242098327368794 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(-29.75000000000001,70.68520102165667 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(-3.1793236587328835,0.07795605479552581 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(35.3158994382172,0 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(-38.52467862443798,42.25025410564322 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(-40.45754430269759,36.474907870604454 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonMethod.newton(-54.640234069542416,51.72247789593567 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonMethod.newton(-63.25,0 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonMethod.newton(667.0766994263023,0 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonMethod.newton(-6.750093166964541,-99.99081835055289 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonMethod.newton(-69.25,0.0 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonMethod.newton(-72.30830210779804,0 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonMethod.newton(-7.249943482922493,-8.881784197001252E-15 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonMethod.newton(-84.36516732079824,0 ) ;
  }

  @Test
  public void test14() {
    scic.NewtonMethod.newton(84.44514534122234,-34.631997195121755 ) ;
  }
}
