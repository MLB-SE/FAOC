import org.junit.Test;

public class JpfTargetSimpsonSolverTest {

  @Test
  public void test0() {
    scic.SimpsonSolver.simpson(-40.73698421899847,-61.772026362764954 ) ;
  }

  @Test
  public void test1() {
    scic.SimpsonSolver.simpson(-57.97418548659422,36.38848762096648 ) ;
  }

  @Test
  public void test2() {
    scic.SimpsonSolver.simpson(-58.41515038245355,38.307068731739434 ) ;
  }
}
