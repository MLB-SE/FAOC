import org.junit.Test;

public class JpfTargetCubedRootTest {

  @Test
  public void test0() {
    scic.CubedRoot.check(22.711292103352676 ) ;
  }

  @Test
  public void test1() {
    scic.CubedRoot.check(24.998540136119125 ) ;
  }

  @Test
  public void test2() {
    scic.CubedRoot.check(31.24179007758272 ) ;
  }
}
