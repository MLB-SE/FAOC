import org.junit.Test;

public class TestjuldayTest {

  @Test
  public void test0() {
    caldat.julday(0,0,0 ) ;
  }

  @Test
  public void test1() {
    caldat.julday(0,0,-1 ) ;
  }

  @Test
  public void test2() {
    caldat.julday(0,0,126 ) ;
  }

  @Test
  public void test3() {
    caldat.julday(0,0,-714 ) ;
  }

  @Test
  public void test4() {
    caldat.julday(0,0,823 ) ;
  }

  @Test
  public void test5() {
    caldat.julday(0,18823,4 ) ;
  }

  @Test
  public void test6() {
    caldat.julday(0,46706,0 ) ;
  }

  @Test
  public void test7() {
    caldat.julday(0,47403,-8 ) ;
  }

  @Test
  public void test8() {
    caldat.julday(-10,0,581 ) ;
  }

  @Test
  public void test9() {
    caldat.julday(-10,757,682 ) ;
  }

  @Test
  public void test10() {
    caldat.julday(-12,0,0 ) ;
  }

  @Test
  public void test11() {
    caldat.julday(-12,0,795 ) ;
  }

  @Test
  public void test12() {
    caldat.julday(-13,0,0 ) ;
  }

  @Test
  public void test13() {
    caldat.julday(-13,0,-1076 ) ;
  }

  @Test
  public void test14() {
    caldat.julday(-13,0,-123 ) ;
  }

  @Test
  public void test15() {
    caldat.julday(-13,0,2089 ) ;
  }

  @Test
  public void test16() {
    caldat.julday(-13,0,583 ) ;
  }

  @Test
  public void test17() {
    caldat.julday(-13,1287,1353 ) ;
  }

  @Test
  public void test18() {
    caldat.julday(-13,1324,0 ) ;
  }

  @Test
  public void test19() {
    caldat.julday(-13,144,-869 ) ;
  }

  @Test
  public void test20() {
    caldat.julday(-13,1563,618 ) ;
  }

  @Test
  public void test21() {
    caldat.julday(-13,19097,-4 ) ;
  }

  @Test
  public void test22() {
    caldat.julday(-13,2299,1669 ) ;
  }

  @Test
  public void test23() {
    caldat.julday(-13,-424,-932 ) ;
  }

  @Test
  public void test24() {
    caldat.julday(-13,45652,-4 ) ;
  }

  @Test
  public void test25() {
    caldat.julday(-13,49587,0 ) ;
  }

  @Test
  public void test26() {
    caldat.julday(-13,49869,-1 ) ;
  }

  @Test
  public void test27() {
    caldat.julday(-13,-704,1899 ) ;
  }

  @Test
  public void test28() {
    caldat.julday(14,0,188 ) ;
  }

  @Test
  public void test29() {
    caldat.julday(1437,16,1736 ) ;
  }

  @Test
  public void test30() {
    caldat.julday(-14,48477,-1 ) ;
  }

  @Test
  public void test31() {
    caldat.julday(-15,30312,-4 ) ;
  }

  @Test
  public void test32() {
    caldat.julday(158,0,1 ) ;
  }

  @Test
  public void test33() {
    caldat.julday(-162,0,522 ) ;
  }

  @Test
  public void test34() {
    caldat.julday(-16,22908,1 ) ;
  }

  @Test
  public void test35() {
    caldat.julday(169,0,-1 ) ;
  }

  @Test
  public void test36() {
    caldat.julday(-18,18721,0 ) ;
  }

  @Test
  public void test37() {
    caldat.julday(-18,45007,-4 ) ;
  }

  @Test
  public void test38() {
    caldat.julday(19188,233,0 ) ;
  }

  @Test
  public void test39() {
    caldat.julday(-19,21746,-7 ) ;
  }

  @Test
  public void test40() {
    caldat.julday(-19,23161,-4 ) ;
  }

  @Test
  public void test41() {
    caldat.julday(19336,845,-21 ) ;
  }

  @Test
  public void test42() {
    caldat.julday(19692,-853,-48 ) ;
  }

  @Test
  public void test43() {
    caldat.julday(-2,0,0 ) ;
  }

  @Test
  public void test44() {
    caldat.julday(-2,0,1000 ) ;
  }

  @Test
  public void test45() {
    caldat.julday(-2,0,-21 ) ;
  }

  @Test
  public void test46() {
    caldat.julday(-20,27987,0 ) ;
  }

  @Test
  public void test47() {
    caldat.julday(-2,0,337 ) ;
  }

  @Test
  public void test48() {
    caldat.julday(-2,0,520 ) ;
  }

  @Test
  public void test49() {
    caldat.julday(-20,52200,0 ) ;
  }

  @Test
  public void test50() {
    caldat.julday(-2,0,697 ) ;
  }

  @Test
  public void test51() {
    caldat.julday(-2,0,-734 ) ;
  }

  @Test
  public void test52() {
    caldat.julday(-208,1164,2189 ) ;
  }

  @Test
  public void test53() {
    caldat.julday(-2,0,-889 ) ;
  }

  @Test
  public void test54() {
    caldat.julday(-2,0,-90 ) ;
  }

  @Test
  public void test55() {
    caldat.julday(2,15918,-3 ) ;
  }

  @Test
  public void test56() {
    caldat.julday(222,0,70 ) ;
  }

  @Test
  public void test57() {
    caldat.julday(-227,0,0 ) ;
  }

  @Test
  public void test58() {
    caldat.julday(-2,31452,-9 ) ;
  }

  @Test
  public void test59() {
    caldat.julday(-23,19918,-3 ) ;
  }

  @Test
  public void test60() {
    caldat.julday(-238,-474,1690 ) ;
  }

  @Test
  public void test61() {
    caldat.julday(2,48594,-1 ) ;
  }

  @Test
  public void test62() {
    caldat.julday(-2,498,861 ) ;
  }

  @Test
  public void test63() {
    caldat.julday(-2,510,1708 ) ;
  }

  @Test
  public void test64() {
    caldat.julday(-254,0,-574 ) ;
  }

  @Test
  public void test65() {
    caldat.julday(-269,961,366 ) ;
  }

  @Test
  public void test66() {
    caldat.julday(-270,0,1 ) ;
  }

  @Test
  public void test67() {
    caldat.julday(29,0,0 ) ;
  }

  @Test
  public void test68() {
    caldat.julday(-29,31683,-3 ) ;
  }

  @Test
  public void test69() {
    caldat.julday(-3,1270,2121 ) ;
  }

  @Test
  public void test70() {
    caldat.julday(-3,29943,0 ) ;
  }

  @Test
  public void test71() {
    caldat.julday(-333,0,1 ) ;
  }

  @Test
  public void test72() {
    caldat.julday(353,0,360 ) ;
  }

  @Test
  public void test73() {
    caldat.julday(369,323,-217 ) ;
  }

  @Test
  public void test74() {
    caldat.julday(-385,0,-233 ) ;
  }

  @Test
  public void test75() {
    caldat.julday(-389,0,0 ) ;
  }

  @Test
  public void test76() {
    caldat.julday(4,0,0 ) ;
  }

  @Test
  public void test77() {
    caldat.julday(4,0,-1354 ) ;
  }

  @Test
  public void test78() {
    caldat.julday(4,0,1682 ) ;
  }

  @Test
  public void test79() {
    caldat.julday(4,0,1760 ) ;
  }

  @Test
  public void test80() {
    caldat.julday(4,0,-325 ) ;
  }

  @Test
  public void test81() {
    caldat.julday(4,0,479 ) ;
  }

  @Test
  public void test82() {
    caldat.julday(4,0,-481 ) ;
  }

  @Test
  public void test83() {
    caldat.julday(4,0,816 ) ;
  }

  @Test
  public void test84() {
    caldat.julday(4,0,-900 ) ;
  }

  @Test
  public void test85() {
    caldat.julday(-418,0,-456 ) ;
  }

  @Test
  public void test86() {
    caldat.julday(-42,0,1 ) ;
  }

  @Test
  public void test87() {
    caldat.julday(423,0,0 ) ;
  }

  @Test
  public void test88() {
    caldat.julday(459,0,0 ) ;
  }

  @Test
  public void test89() {
    caldat.julday(470,907,1789 ) ;
  }

  @Test
  public void test90() {
    caldat.julday(475,0,0 ) ;
  }

  @Test
  public void test91() {
    caldat.julday(480,0,-433 ) ;
  }

  @Test
  public void test92() {
    caldat.julday(481,0,1 ) ;
  }

  @Test
  public void test93() {
    caldat.julday(489,0,1 ) ;
  }

  @Test
  public void test94() {
    caldat.julday(-498,0,-1 ) ;
  }

  @Test
  public void test95() {
    caldat.julday(-5,0,-560 ) ;
  }

  @Test
  public void test96() {
    caldat.julday(-53,15716,-4 ) ;
  }

  @Test
  public void test97() {
    caldat.julday(550,0,-400 ) ;
  }

  @Test
  public void test98() {
    caldat.julday(-558,714,-248 ) ;
  }

  @Test
  public void test99() {
    caldat.julday(-564,0,15 ) ;
  }

  @Test
  public void test100() {
    caldat.julday(-58,0,0 ) ;
  }

  @Test
  public void test101() {
    caldat.julday(-6,18443,0 ) ;
  }

  @Test
  public void test102() {
    caldat.julday(641,0,-1 ) ;
  }

  @Test
  public void test103() {
    caldat.julday(-663,0,297 ) ;
  }

  @Test
  public void test104() {
    caldat.julday(-693,0,-1 ) ;
  }

  @Test
  public void test105() {
    caldat.julday(-707,0,2 ) ;
  }

  @Test
  public void test106() {
    caldat.julday(712,443,796 ) ;
  }

  @Test
  public void test107() {
    caldat.julday(-722,0,-512 ) ;
  }

  @Test
  public void test108() {
    caldat.julday(-725,0,905 ) ;
  }

  @Test
  public void test109() {
    caldat.julday(733,0,607 ) ;
  }

  @Test
  public void test110() {
    caldat.julday(750,-189,-143 ) ;
  }

  @Test
  public void test111() {
    caldat.julday(761,0,-1 ) ;
  }

  @Test
  public void test112() {
    caldat.julday(77,208,0 ) ;
  }

  @Test
  public void test113() {
    caldat.julday(789,0,1 ) ;
  }

  @Test
  public void test114() {
    caldat.julday(792,0,-583 ) ;
  }

  @Test
  public void test115() {
    caldat.julday(-8,0,-343 ) ;
  }

  @Test
  public void test116() {
    caldat.julday(-804,-824,65 ) ;
  }

  @Test
  public void test117() {
    caldat.julday(-8,1043,0 ) ;
  }

  @Test
  public void test118() {
    caldat.julday(-8,-1304,-796 ) ;
  }

  @Test
  public void test119() {
    caldat.julday(-8,25823,-1 ) ;
  }

  @Test
  public void test120() {
    caldat.julday(-8,31022,0 ) ;
  }

  @Test
  public void test121() {
    caldat.julday(-8,31427,-4 ) ;
  }

  @Test
  public void test122() {
    caldat.julday(-844,-61,0 ) ;
  }

  @Test
  public void test123() {
    caldat.julday(878,0,408 ) ;
  }

  @Test
  public void test124() {
    caldat.julday(-8,88,-223 ) ;
  }

  @Test
  public void test125() {
    caldat.julday(889,-830,331 ) ;
  }

  @Test
  public void test126() {
    caldat.julday(-895,0,-452 ) ;
  }

  @Test
  public void test127() {
    caldat.julday(-948,0,2 ) ;
  }

  @Test
  public void test128() {
    caldat.julday(-956,815,-109 ) ;
  }

  @Test
  public void test129() {
    caldat.julday(-968,0,1 ) ;
  }

  @Test
  public void test130() {
    caldat.julday(970,0,-545 ) ;
  }

  @Test
  public void test131() {
    caldat.julday(-97,0,834 ) ;
  }

  @Test
  public void test132() {
    caldat.julday(991,0,-62 ) ;
  }
}
