import org.junit.Test;

public class TestflmoonTest {

  @Test
  public void test0() {
    caldat.flmoon(0,0 ) ;
  }

  @Test
  public void test1() {
    caldat.flmoon(0,1 ) ;
  }

  @Test
  public void test2() {
    caldat.flmoon(0,163 ) ;
  }

  @Test
  public void test3() {
    caldat.flmoon(0,2 ) ;
  }

  @Test
  public void test4() {
    caldat.flmoon(0,3 ) ;
  }

  @Test
  public void test5() {
    caldat.flmoon(0,-769 ) ;
  }

  @Test
  public void test6() {
    caldat.flmoon(0,-85 ) ;
  }

  @Test
  public void test7() {
    caldat.flmoon(0,-865 ) ;
  }

  @Test
  public void test8() {
    caldat.flmoon(-1,0 ) ;
  }

  @Test
  public void test9() {
    caldat.flmoon(-1021,3 ) ;
  }

  @Test
  public void test10() {
    caldat.flmoon(-1046,-4 ) ;
  }

  @Test
  public void test11() {
    caldat.flmoon(-106,-1261 ) ;
  }

  @Test
  public void test12() {
    caldat.flmoon(-1,-1 ) ;
  }

  @Test
  public void test13() {
    caldat.flmoon(-1,1 ) ;
  }

  @Test
  public void test14() {
    caldat.flmoon(1,1 ) ;
  }

  @Test
  public void test15() {
    caldat.flmoon(-1122,4 ) ;
  }

  @Test
  public void test16() {
    caldat.flmoon(-1,2 ) ;
  }

  @Test
  public void test17() {
    caldat.flmoon(-123,-82 ) ;
  }

  @Test
  public void test18() {
    caldat.flmoon(-1260,1 ) ;
  }

  @Test
  public void test19() {
    caldat.flmoon(1277,5 ) ;
  }

  @Test
  public void test20() {
    caldat.flmoon(-1,3 ) ;
  }

  @Test
  public void test21() {
    caldat.flmoon(1352,410 ) ;
  }

  @Test
  public void test22() {
    caldat.flmoon(14,-58 ) ;
  }

  @Test
  public void test23() {
    caldat.flmoon(-149,0 ) ;
  }

  @Test
  public void test24() {
    caldat.flmoon(-176,2 ) ;
  }

  @Test
  public void test25() {
    caldat.flmoon(184,0 ) ;
  }

  @Test
  public void test26() {
    caldat.flmoon(18,-74 ) ;
  }

  @Test
  public void test27() {
    caldat.flmoon(-196,6 ) ;
  }

  @Test
  public void test28() {
    caldat.flmoon(200,1 ) ;
  }

  @Test
  public void test29() {
    caldat.flmoon(200,-4 ) ;
  }

  @Test
  public void test30() {
    caldat.flmoon(218,74 ) ;
  }

  @Test
  public void test31() {
    caldat.flmoon(-2,3 ) ;
  }

  @Test
  public void test32() {
    caldat.flmoon(-23,2 ) ;
  }

  @Test
  public void test33() {
    caldat.flmoon(-318,-9 ) ;
  }

  @Test
  public void test34() {
    caldat.flmoon(-3341,4 ) ;
  }

  @Test
  public void test35() {
    caldat.flmoon(35,-139 ) ;
  }

  @Test
  public void test36() {
    caldat.flmoon(354,2 ) ;
  }

  @Test
  public void test37() {
    caldat.flmoon(381,1 ) ;
  }

  @Test
  public void test38() {
    caldat.flmoon(-434,-5 ) ;
  }

  @Test
  public void test39() {
    caldat.flmoon(-462,446 ) ;
  }

  @Test
  public void test40() {
    caldat.flmoon(495,0 ) ;
  }

  @Test
  public void test41() {
    caldat.flmoon(-53,210 ) ;
  }

  @Test
  public void test42() {
    caldat.flmoon(-609,282 ) ;
  }

  @Test
  public void test43() {
    caldat.flmoon(657,6 ) ;
  }

  @Test
  public void test44() {
    caldat.flmoon(707,6 ) ;
  }

  @Test
  public void test45() {
    caldat.flmoon(710,477 ) ;
  }

  @Test
  public void test46() {
    caldat.flmoon(74,-298 ) ;
  }

  @Test
  public void test47() {
    caldat.flmoon(-745,396 ) ;
  }

  @Test
  public void test48() {
    caldat.flmoon(767,3 ) ;
  }

  @Test
  public void test49() {
    caldat.flmoon(776,2 ) ;
  }

  @Test
  public void test50() {
    caldat.flmoon(796,3 ) ;
  }

  @Test
  public void test51() {
    caldat.flmoon(807,-19 ) ;
  }

  @Test
  public void test52() {
    caldat.flmoon(-87,0 ) ;
  }

  @Test
  public void test53() {
    caldat.flmoon(-873,3 ) ;
  }

  @Test
  public void test54() {
    caldat.flmoon(885,2 ) ;
  }

  @Test
  public void test55() {
    caldat.flmoon(889,-686 ) ;
  }

  @Test
  public void test56() {
    caldat.flmoon(-915,3 ) ;
  }

  @Test
  public void test57() {
    caldat.flmoon(-941,1 ) ;
  }

  @Test
  public void test58() {
    caldat.flmoon(962,11 ) ;
  }
}
