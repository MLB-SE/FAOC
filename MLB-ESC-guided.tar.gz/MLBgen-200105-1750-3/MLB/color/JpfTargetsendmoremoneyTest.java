import org.junit.Test;

public class JpfTargetsendmoremoneyTest {

  @Test
  public void test0() {
    color.sendmoremoney.solve(1,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    color.sendmoremoney.solve(1,0,1,1,3,1,1719,0 ) ;
  }

  @Test
  public void test2() {
    color.sendmoremoney.solve(1,1,1,2,-3,6,2846,0 ) ;
  }

  @Test
  public void test3() {
    color.sendmoremoney.solve(-1,11,7,6,23,-5,-1477,0 ) ;
  }

  @Test
  public void test4() {
    color.sendmoremoney.solve(1,126,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    color.sendmoremoney.solve(1,661,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test6() {
    color.sendmoremoney.solve(1,9,-829,0,0,0,0,0 ) ;
  }

  @Test
  public void test7() {
    color.sendmoremoney.solve(2,3,4,-2,-10,9,-23,41 ) ;
  }

  @Test
  public void test8() {
    color.sendmoremoney.solve(2,9,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test9() {
    color.sendmoremoney.solve(3,0,6,8,5,-1225,0,0 ) ;
  }

  @Test
  public void test10() {
    color.sendmoremoney.solve(-313,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test11() {
    color.sendmoremoney.solve(3,2,9,-5,16,2,-1,-14 ) ;
  }

  @Test
  public void test12() {
    color.sendmoremoney.solve(35,16,21,4,2,-8,-15,-8 ) ;
  }

  @Test
  public void test13() {
    color.sendmoremoney.solve(3,6,10,5,4,0,7,-1 ) ;
  }

  @Test
  public void test14() {
    color.sendmoremoney.solve(3,6,24,0,15,3,-12,-39 ) ;
  }

  @Test
  public void test15() {
    color.sendmoremoney.solve(3,6,9,5,1,0,6,-1 ) ;
  }

  @Test
  public void test16() {
    color.sendmoremoney.solve(3,9,3,8,8,1582,0,0 ) ;
  }

  @Test
  public void test17() {
    color.sendmoremoney.solve(4,0,5,102,0,0,0,0 ) ;
  }

  @Test
  public void test18() {
    color.sendmoremoney.solve(4,2,6,1,3,7,1,7 ) ;
  }

  @Test
  public void test19() {
    color.sendmoremoney.solve(4,5,0,5,7,7,0,0 ) ;
  }

  @Test
  public void test20() {
    color.sendmoremoney.solve(4,-533,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test21() {
    color.sendmoremoney.solve(4,9,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test22() {
    color.sendmoremoney.solve(5,1,3,5,5,6,3,-1029 ) ;
  }

  @Test
  public void test23() {
    color.sendmoremoney.solve(5,1,975,0,0,0,0,0 ) ;
  }

  @Test
  public void test24() {
    color.sendmoremoney.solve(5,5,1,8,7,5,9,0 ) ;
  }

  @Test
  public void test25() {
    color.sendmoremoney.solve(-5,6,0,14,25,9,-7,953 ) ;
  }

  @Test
  public void test26() {
    color.sendmoremoney.solve(5,7,4,0,1,-4,3,-1 ) ;
  }

  @Test
  public void test27() {
    color.sendmoremoney.solve(5,9,4,7,4,1,536,0 ) ;
  }

  @Test
  public void test28() {
    color.sendmoremoney.solve(5,9,9,0,1,0,2,9 ) ;
  }

  @Test
  public void test29() {
    color.sendmoremoney.solve(604,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test30() {
    color.sendmoremoney.solve(6,31,11,-12,0,10,7,-1277 ) ;
  }

  @Test
  public void test31() {
    color.sendmoremoney.solve(6,-3,17,-12,-5,17,0,1251 ) ;
  }

  @Test
  public void test32() {
    color.sendmoremoney.solve(6,6,3,9,7,0,0,0 ) ;
  }

  @Test
  public void test33() {
    color.sendmoremoney.solve(6,7,6,7,845,0,0,0 ) ;
  }

  @Test
  public void test34() {
    color.sendmoremoney.solve(6,8,2,3,-674,0,0,0 ) ;
  }

  @Test
  public void test35() {
    color.sendmoremoney.solve(6,8,9,5,599,0,0,0 ) ;
  }

  @Test
  public void test36() {
    color.sendmoremoney.solve(7,0,1,4,-12,16,8,0 ) ;
  }

  @Test
  public void test37() {
    color.sendmoremoney.solve(7,0,4,1,3,5,1,935 ) ;
  }

  @Test
  public void test38() {
    color.sendmoremoney.solve(7,7,0,9,1,0,9,0 ) ;
  }

  @Test
  public void test39() {
    color.sendmoremoney.solve(7,8,1,8,8,1,6,6 ) ;
  }

  @Test
  public void test40() {
    color.sendmoremoney.solve(7,9,2,4,-4,15,60,0 ) ;
  }

  @Test
  public void test41() {
    color.sendmoremoney.solve(7,9,5,-752,0,0,0,0 ) ;
  }

  @Test
  public void test42() {
    color.sendmoremoney.solve(81,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test43() {
    color.sendmoremoney.solve(8,1,4,1,9,554,0,0 ) ;
  }

  @Test
  public void test44() {
    color.sendmoremoney.solve(8,5,4,3,0,0,0,0 ) ;
  }

  @Test
  public void test45() {
    color.sendmoremoney.solve(8,7,0,5,8,1,6,0 ) ;
  }

  @Test
  public void test46() {
    color.sendmoremoney.solve(8,8,0,9,1,0,9,0 ) ;
  }

  @Test
  public void test47() {
    color.sendmoremoney.solve(-8,-8,-5,1,1,8,7,-16 ) ;
  }

  @Test
  public void test48() {
    color.sendmoremoney.solve(8,9,641,0,0,0,0,0 ) ;
  }

  @Test
  public void test49() {
    color.sendmoremoney.solve(9,0,0,8,1,0,0,6 ) ;
  }

  @Test
  public void test50() {
    color.sendmoremoney.solve(9,-1,1,1,2,5,3,21 ) ;
  }

  @Test
  public void test51() {
    color.sendmoremoney.solve(9,2,6,4,4,6,-1344,0 ) ;
  }

  @Test
  public void test52() {
    color.sendmoremoney.solve(9,4,7,832,0,0,0,0 ) ;
  }

  @Test
  public void test53() {
    color.sendmoremoney.solve(9,6,1,5,10,348,0,0 ) ;
  }

  @Test
  public void test54() {
    color.sendmoremoney.solve(9,8,0,9,1,1,9,0 ) ;
  }

  @Test
  public void test55() {
    color.sendmoremoney.solve(9,8,5,7,6,3,4,2578 ) ;
  }

  @Test
  public void test56() {
    color.sendmoremoney.solve(9,9,0,0,1,1,8,1 ) ;
  }

  @Test
  public void test57() {
    color.sendmoremoney.solve(9,9,0,0,1,1,9,9 ) ;
  }
}
