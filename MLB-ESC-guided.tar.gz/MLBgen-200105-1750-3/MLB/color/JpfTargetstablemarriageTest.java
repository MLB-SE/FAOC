import org.junit.Test;

public class JpfTargetstablemarriageTest {

  @Test
  public void test0() {
    color.stablemarriage.solve(1,0 ) ;
  }

  @Test
  public void test1() {
    color.stablemarriage.solve(2,243 ) ;
  }

  @Test
  public void test2() {
    color.stablemarriage.solve(3,189 ) ;
  }

  @Test
  public void test3() {
    color.stablemarriage.solve(3,-239 ) ;
  }

  @Test
  public void test4() {
    color.stablemarriage.solve(4,3 ) ;
  }

  @Test
  public void test5() {
    color.stablemarriage.solve(553,0 ) ;
  }

  @Test
  public void test6() {
    color.stablemarriage.solve(582,0 ) ;
  }

  @Test
  public void test7() {
    color.stablemarriage.solve(-955,0 ) ;
  }
}
