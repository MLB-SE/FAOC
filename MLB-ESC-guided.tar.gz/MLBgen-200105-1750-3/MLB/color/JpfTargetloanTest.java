import org.junit.Test;

public class JpfTargetloanTest {

  @Test
  public void test0() {
    color.loan.solve(0.86613125f ) ;
  }

  @Test
  public void test1() {
    color.loan.solve(65.46777f ) ;
  }

  @Test
  public void test2() {
    color.loan.solve(82.63617f ) ;
  }
}
