import org.junit.Test;

public class JpfTargetlaplaceTest {

  @Test
  public void test0() {
    color.laplace.solve(-0.0021490871f,-87.11743f,-100.0f,-12.891163f,9.981158f,93.90064f,-61.54366f,46.03259f,100.0f ) ;
  }

  @Test
  public void test1() {
    color.laplace.solve(-0.115442075f,-99.99133f,-16.234558f,-0.47050884f,-2.1556537f,89.81225f,0.38905412f,2.0269804f,9.874521f ) ;
  }

  @Test
  public void test2() {
    color.laplace.solve(0.13147007f,-99.07959f,-32.214752f,-0.39453027f,22.995852f,2.4105623f,-24.705442f,-98.42724f,-95.25261f ) ;
  }

  @Test
  public void test3() {
    color.laplace.solve(0.22146767f,-82.747894f,-76.48879f,-16.366867f,-49.801144f,-52.904736f,-15.887793f,-47.184303f,-85.328995f ) ;
  }

  @Test
  public void test4() {
    color.laplace.solve(-0.46636593f,98.8148f,-53.8806f,18.6597f,39.732548f,42.323357f,35.372616f,-0.8676643f,64.30654f ) ;
  }

  @Test
  public void test5() {
    color.laplace.solve(-0.5481444f,-3.772677f,-45.6027f,-98.4199f,83.30798f,-72.685394f,-21.226688f,13.513147f,-8.028704f ) ;
  }

  @Test
  public void test6() {
    color.laplace.solve(-0.69355315f,-17.19875f,13.79495f,-0.7488112f,-2.1193423f,9.450777f,-0.18234919f,0.019414399f,2.379349f ) ;
  }

  @Test
  public void test7() {
    color.laplace.solve(0.7042841f,-93.015015f,11.647205f,-4.167849f,-19.212477f,8.817927f,1.8367962f,11.515034f,42.83698f ) ;
  }

  @Test
  public void test8() {
    color.laplace.solve(-0.7200652f,81.429504f,0f,28.45794f,72.52746f,-12.620777f,42.024364f,-49.549282f,0f ) ;
  }

  @Test
  public void test9() {
    color.laplace.solve(0.73196846f,-59.611065f,-48.647038f,-37.461063f,78.30383f,0f,14.55416f,95.677704f,0f ) ;
  }

  @Test
  public void test10() {
    color.laplace.solve(-0.86983293f,-92.298615f,17.72429f,-11.180715f,94.1698f,0f,4.483124f,0f,0f ) ;
  }

  @Test
  public void test11() {
    color.laplace.solve(-0.9690896f,-82.06606f,-23.012966f,-21.810291f,-56.110584f,-21.730246f,-30.161497f,-98.835724f,-7.797435f ) ;
  }

  @Test
  public void test12() {
    color.laplace.solve(-100.0f,-100.0f,0f,7.630454f,100.0f,0f,23.920433f,88.05128f,100.0f ) ;
  }

  @Test
  public void test13() {
    color.laplace.solve(-100.0f,100.0f,0f,-78.00003f,-90.132355f,0f,-10.429944f,36.28025f,0f ) ;
  }

  @Test
  public void test14() {
    color.laplace.solve(100.0f,-100.0f,0f,94.952f,-49.039284f,0f,48.63812f,99.60047f,8.218865f ) ;
  }

  @Test
  public void test15() {
    color.laplace.solve(100.0f,-24.677393f,0f,56.6379f,95.00289f,-66.37668f,31.548712f,69.556946f,-36.913357f ) ;
  }

  @Test
  public void test16() {
    color.laplace.solve(100.0f,77.3678f,0f,79.934425f,-44.52526f,91.736824f,19.86879f,-0.45927107f,22.819387f ) ;
  }

  @Test
  public void test17() {
    color.laplace.solve(100.0f,84.369545f,41.605946f,36.354935f,36.306118f,24.400434f,9.113623f,0.09955394f,19.689676f ) ;
  }

  @Test
  public void test18() {
    color.laplace.solve(100.0f,96.17318f,0f,51.167603f,-100.0f,0f,9.537066f,-13.019339f,0f ) ;
  }

  @Test
  public void test19() {
    color.laplace.solve(10.034744f,-60.805332f,29.165913f,-3.1036603f,-20.016762f,-9.535973f,-2.4320352f,-6.62208f,-4.0395236f ) ;
  }

  @Test
  public void test20() {
    color.laplace.solve(10.120294f,-83.17039f,31.226925f,23.651564f,75.123085f,-78.76802f,9.362874f,13.799933f,-29.28623f ) ;
  }

  @Test
  public void test21() {
    color.laplace.solve(10.185833f,-50.970078f,-78.516014f,-8.286592f,-34.096626f,-24.731262f,-9.235573f,-52.398567f,16.191713f ) ;
  }

  @Test
  public void test22() {
    color.laplace.solve(10.36059f,-59.27701f,-32.80525f,0.7193792f,-10.740006f,3.291079f,3.2565422f,12.306527f,56.70957f ) ;
  }

  @Test
  public void test23() {
    color.laplace.solve(10.680366f,-12.154663f,6.8938212f,-45.132404f,-166.19348f,-60.245777f,-25.031706f,-55.008812f,-28.813179f ) ;
  }

  @Test
  public void test24() {
    color.laplace.solve(10.80222f,-94.94825f,68.13344f,38.15713f,69.66056f,74.95228f,72.16574f,-25.51513f,0f ) ;
  }

  @Test
  public void test25() {
    color.laplace.solve(11.352931f,-60.91683f,-25.285622f,2.1770635f,-3.7096093f,41.818665f,1.0649318f,2.0826635f,10.975332f ) ;
  }

  @Test
  public void test26() {
    color.laplace.solve(11.493863f,-52.648506f,7.4633436f,-1.3688037f,-15.449964f,-2.4451003f,-1.523163f,-4.703803f,-1.793781f ) ;
  }

  @Test
  public void test27() {
    color.laplace.solve(-1.1644332f,-94.69634f,-100.0f,-9.96139f,-34.721325f,-28.349771f,-3.9597979f,-5.877802f,15.169916f ) ;
  }

  @Test
  public void test28() {
    color.laplace.solve(11.796348f,-40.52598f,-23.488583f,-7.290857f,-30.3443f,-38.38932f,-10.615475f,-35.171043f,-99.724396f ) ;
  }

  @Test
  public void test29() {
    color.laplace.solve(12.060684f,14.384197f,37.08101f,-66.141464f,-91.604904f,-56.622646f,-30.267088f,-54.926895f,-97.83558f ) ;
  }

  @Test
  public void test30() {
    color.laplace.solve(12.101002f,-70.315605f,25.236946f,18.719612f,51.379387f,-9.498888f,11.398058f,26.87262f,44.71303f ) ;
  }

  @Test
  public void test31() {
    color.laplace.solve(-12.133589f,-88.59225f,-47.62747f,-59.94211f,81.46938f,0f,-28.131575f,22.646877f,0f ) ;
  }

  @Test
  public void test32() {
    color.laplace.solve(12.362015f,42.20606f,11.071683f,-92.936165f,45.293083f,100.81313f,-29.090395f,-23.425415f,-109.45959f ) ;
  }

  @Test
  public void test33() {
    color.laplace.solve(12.520269f,-21.19637f,-100.0f,-28.722553f,-97.43331f,-20.230253f,-29.977177f,3.497691f,0f ) ;
  }

  @Test
  public void test34() {
    color.laplace.solve(12.529694f,-87.42933f,0f,-21.416204f,-91.80155f,-16.144066f,-6.392962f,-4.1556435f,-14.030397f ) ;
  }

  @Test
  public void test35() {
    color.laplace.solve(12.790448f,-50.080082f,3.95819f,-4.42184f,-23.903948f,-19.240261f,-6.573861f,-21.873606f,-57.01529f ) ;
  }

  @Test
  public void test36() {
    color.laplace.solve(12.81827f,-65.040955f,0f,1.8068813f,-3.9775732f,-83.833244f,-1.6131707f,-8.259564f,-27.447514f ) ;
  }

  @Test
  public void test37() {
    color.laplace.solve(12.895071f,-51.19469f,-47.350266f,2.7749755f,-14.6467085f,-58.7983f,12.85154f,48.631184f,-87.42252f ) ;
  }

  @Test
  public void test38() {
    color.laplace.solve(13.023484f,-43.37632f,47.492737f,-4.5297446f,-28.97079f,-63.82016f,-2.171671f,-4.1569395f,14.514704f ) ;
  }

  @Test
  public void test39() {
    color.laplace.solve(13.14736f,-44.098495f,-17.3667f,-3.312064f,-20.718704f,-16.06867f,-5.6769123f,-19.395586f,-26.189278f ) ;
  }

  @Test
  public void test40() {
    color.laplace.solve(13.282526f,-67.10917f,-19.903109f,-2.8968225f,-22.29184f,-11.746323f,-2.5779645f,-7.4150357f,-4.790343f ) ;
  }

  @Test
  public void test41() {
    color.laplace.solve(13.416462f,58.726784f,0f,6.279097f,17.179277f,26.300167f,-5.47935f,-28.196499f,0f ) ;
  }

  @Test
  public void test42() {
    color.laplace.solve(-13.481276f,-89.40028f,0f,13.549708f,100.0f,-81.81621f,7.4829793f,16.382208f,-41.954144f ) ;
  }

  @Test
  public void test43() {
    color.laplace.solve(13.568817f,-45.823814f,-47.672398f,0.09908414f,-12.967437f,-5.22576f,-0.20504375f,-0.91925913f,39.736797f ) ;
  }

  @Test
  public void test44() {
    color.laplace.solve(13.649486f,-28.828964f,87.9081f,-16.556566f,-62.103462f,35.160305f,-17.706676f,-54.346424f,-137.69685f ) ;
  }

  @Test
  public void test45() {
    color.laplace.solve(13.667539f,-42.796124f,-49.297066f,-2.5337195f,-20.174929f,-23.393631f,-3.627489f,-11.976236f,-24.10253f ) ;
  }

  @Test
  public void test46() {
    color.laplace.solve(13.835241f,-40.72998f,100.0f,-3.9290519f,-20.47263f,-4.845251f,-9.07882f,-32.38623f,-99.99347f ) ;
  }

  @Test
  public void test47() {
    color.laplace.solve(-14.089138f,-80.72641f,60.159237f,-75.63014f,-64.91346f,0f,18.179138f,-54.33019f,0f ) ;
  }

  @Test
  public void test48() {
    color.laplace.solve(-14.112631f,-36.464436f,5.0923367f,-4.5483503f,-5.116429f,11.856086f,1.0356582f,8.690984f,38.844704f ) ;
  }

  @Test
  public void test49() {
    color.laplace.solve(-1.4284633f,-92.03642f,-87.00704f,-13.677427f,-66.65567f,-100.0f,13.374422f,-60.908817f,-36.234184f ) ;
  }

  @Test
  public void test50() {
    color.laplace.solve(14.405387f,-30.45568f,-182.71732f,-11.92268f,-53.510643f,-149.45154f,-8.5607395f,-22.194609f,-26.71394f ) ;
  }

  @Test
  public void test51() {
    color.laplace.solve(14.440318f,-48.075172f,-41.05053f,5.836443f,64.44506f,-6.44469f,0.39115372f,-4.2718277f,-81.92353f ) ;
  }

  @Test
  public void test52() {
    color.laplace.solve(14.833732f,-44.42506f,-62.056362f,1.5195853f,-5.3213177f,36.876083f,-3.4340734f,-15.255879f,-52.268124f ) ;
  }

  @Test
  public void test53() {
    color.laplace.solve(14.847102f,32.26586f,23.780096f,-72.87745f,-9.563755f,-37.145477f,-70.1491f,-47.720905f,0f ) ;
  }

  @Test
  public void test54() {
    color.laplace.solve(1.5067255f,-6.8690357f,-73.91764f,-87.104065f,65.50234f,-53.27173f,-19.603987f,8.688113f,-11.145904f ) ;
  }

  @Test
  public void test55() {
    color.laplace.solve(15.177294f,-100.0f,71.93537f,1.7225955f,-8.537318f,64.849106f,0.25040573f,-0.7209726f,5.403022f ) ;
  }

  @Test
  public void test56() {
    color.laplace.solve(-152.11983f,-53.498512f,-134.05551f,-45.081306f,-20.381424f,3.4007246f,-7.869845f,13.601928f,82.683205f ) ;
  }

  @Test
  public void test57() {
    color.laplace.solve(15.254085f,-31.205334f,100.0f,-7.7782135f,-39.58271f,-99.988594f,-6.784241f,-19.358704f,-31.06786f ) ;
  }

  @Test
  public void test58() {
    color.laplace.solve(15.383717f,-38.318047f,-14.506313f,-0.36685026f,-13.844621f,-5.034452f,-3.0064964f,-11.659135f,-29.785423f ) ;
  }

  @Test
  public void test59() {
    color.laplace.solve(15.43585f,-37.42998f,99.85589f,-0.82661694f,-12.771346f,10.436671f,-5.970972f,-23.057272f,67.17595f ) ;
  }

  @Test
  public void test60() {
    color.laplace.solve(15.623936f,-27.947863f,34.06327f,-9.556395f,-23.106308f,-34.035923f,-30.743206f,-10.379899f,0f ) ;
  }

  @Test
  public void test61() {
    color.laplace.solve(15.631368f,-42.57036f,75.52328f,5.09583f,-6.247174f,9.737878f,10.999126f,2.7479541f,-30.324594f ) ;
  }

  @Test
  public void test62() {
    color.laplace.solve(-15.7717085f,13.259247f,14.053785f,-7.6660924f,-7.742922f,-15.631981f,-7.1497383f,-20.932861f,-68.83878f ) ;
  }

  @Test
  public void test63() {
    color.laplace.solve(15.78258f,19.163706f,20.904121f,-56.033382f,-60.031876f,-35.54722f,-17.570435f,-14.248357f,20.608885f ) ;
  }

  @Test
  public void test64() {
    color.laplace.solve(15.869911f,-26.599264f,0f,74.34538f,-9.549195f,0f,2.6190467f,-86.92021f,0f ) ;
  }

  @Test
  public void test65() {
    color.laplace.solve(16.159405f,-31.66052f,-30.567696f,3.5942557f,-0.9918651f,30.855127f,-0.7905167f,-6.7563224f,-25.242908f ) ;
  }

  @Test
  public void test66() {
    color.laplace.solve(16.20455f,-20.494658f,99.99999f,-14.68714f,-52.082108f,-96.34975f,-22.871006f,-76.79688f,100.0f ) ;
  }

  @Test
  public void test67() {
    color.laplace.solve(16.348907f,28.133083f,46.468594f,15.344011f,28.864326f,22.67297f,16.162813f,49.30724f,15.358961f ) ;
  }

  @Test
  public void test68() {
    color.laplace.solve(16.645216f,-29.739922f,0f,3.9578946f,-1.7480423f,-0.04966804f,0.9344043f,-0.22027914f,-0.06748586f ) ;
  }

  @Test
  public void test69() {
    color.laplace.solve(16.668505f,36.064053f,37.58315f,-69.39004f,-9.995442f,14.268538f,-15.194145f,8.613457f,59.643417f ) ;
  }

  @Test
  public void test70() {
    color.laplace.solve(16.69271f,-18.495136f,-173.00462f,-14.741019f,-17.608116f,-43.65874f,-58.030308f,6.4579053f,16.00219f ) ;
  }

  @Test
  public void test71() {
    color.laplace.solve(16.789677f,-38.594246f,-25.887562f,5.752953f,4.857789f,52.56802f,1.3643453f,-0.29557174f,-7.4044213f ) ;
  }

  @Test
  public void test72() {
    color.laplace.solve(16.997583f,-31.793287f,-80.460884f,-0.2163769f,-16.18137f,-26.205303f,-1.681722f,-6.5105114f,-8.178953f ) ;
  }

  @Test
  public void test73() {
    color.laplace.solve(17.09728f,-38.15502f,0f,5.0947003f,1.5692621f,13.18894f,1.7122588f,1.7543349f,3.7358186f ) ;
  }

  @Test
  public void test74() {
    color.laplace.solve(-17.231241f,88.11819f,-63.387337f,-1.4898069f,13.678251f,-23.780237f,-2.406237f,-8.13514f,-45.41186f ) ;
  }

  @Test
  public void test75() {
    color.laplace.solve(17.240858f,-43.719738f,-4.542187f,4.3783526f,-4.010328f,10.546904f,4.282881f,12.753171f,50.740128f ) ;
  }

  @Test
  public void test76() {
    color.laplace.solve(17.459843f,-31.600237f,-66.59004f,1.4396101f,-25.526625f,-50.34065f,13.825221f,-21.605219f,0f ) ;
  }

  @Test
  public void test77() {
    color.laplace.solve(17.619034f,16.85333f,26.99134f,-46.496353f,-76.29469f,-21.303427f,-127.9761f,-250.47574f,-36.193665f ) ;
  }

  @Test
  public void test78() {
    color.laplace.solve(17.629362f,-39.443253f,51.5565f,9.960703f,16.529915f,6.987184f,5.6835327f,12.773428f,28.880262f ) ;
  }

  @Test
  public void test79() {
    color.laplace.solve(17.781834f,-24.362171f,67.84204f,-1.2323788f,-16.771713f,-18.966143f,-5.9396353f,-22.526163f,-67.3933f ) ;
  }

  @Test
  public void test80() {
    color.laplace.solve(17.831066f,-37.373684f,-95.37848f,8.697952f,-7.3264885f,55.640636f,24.287231f,71.85157f,0f ) ;
  }

  @Test
  public void test81() {
    color.laplace.solve(18.153708f,-30.466423f,-99.9966f,3.0815768f,-6.0785947f,5.146645f,0.25136995f,-2.076097f,-2.476989f ) ;
  }

  @Test
  public void test82() {
    color.laplace.solve(18.167578f,-23.287369f,-229.76585f,-9.343933f,-35.56541f,-72.33065f,-9.11112f,-25.70021f,-23.84002f ) ;
  }

  @Test
  public void test83() {
    color.laplace.solve(18.667427f,-0.37100297f,-76.9356f,-24.959286f,-43.21584f,-132.36789f,-10.753292f,-18.05388f,-18.246393f ) ;
  }

  @Test
  public void test84() {
    color.laplace.solve(18.826607f,-20.685717f,29.937902f,-4.007855f,-15.111351f,39.227016f,-19.746675f,-74.97885f,71.941284f ) ;
  }

  @Test
  public void test85() {
    color.laplace.solve(-1.8910892f,-8.571551f,-100.0f,-0.2447902f,0.73258835f,10.784545f,0.1793401f,0.9621506f,2.9366739f ) ;
  }

  @Test
  public void test86() {
    color.laplace.solve(18.915163f,-26.330797f,91.02958f,1.9914473f,-10.487719f,-13.773461f,-0.46165404f,-3.8380635f,-4.402881f ) ;
  }

  @Test
  public void test87() {
    color.laplace.solve(19.160894f,-28.326965f,72.19462f,4.9705763f,-0.8763313f,18.430079f,1.597875f,1.4210835f,4.9627905f ) ;
  }

  @Test
  public void test88() {
    color.laplace.solve(19.165539f,-23.810102f,-120.59084f,1.0841715f,-93.85125f,59.281826f,-5.021668f,-21.76469f,9.271834f ) ;
  }

  @Test
  public void test89() {
    color.laplace.solve(19.422089f,-72.61069f,0f,-64.84347f,23.347664f,0f,2.0441499f,73.020065f,0f ) ;
  }

  @Test
  public void test90() {
    color.laplace.solve(-19.494371f,97.71487f,-100.0f,5.03951f,35.312748f,26.177477f,4.3396626f,12.319141f,9.624154f ) ;
  }

  @Test
  public void test91() {
    color.laplace.solve(19.591717f,-7.558628f,19.99569f,-14.074506f,-78.08906f,59.470566f,2.199319f,22.871782f,14.4066305f ) ;
  }

  @Test
  public void test92() {
    color.laplace.solve(19.59477f,-26.645157f,-28.27283f,5.0242343f,-1.0570021f,16.180382f,1.5591977f,1.2126069f,4.348232f ) ;
  }

  @Test
  public void test93() {
    color.laplace.solve(-19.609396f,61.260406f,0f,-28.81289f,-57.59711f,0f,-16.554512f,-37.405163f,-75.469025f ) ;
  }

  @Test
  public void test94() {
    color.laplace.solve(19.715113f,-19.543352f,-37.257526f,-1.5961941f,-19.534952f,-32.336704f,-6.564938f,-24.663557f,-72.55434f ) ;
  }

  @Test
  public void test95() {
    color.laplace.solve(19.733f,31.64706f,-74.36367f,-52.715065f,81.21891f,54.54247f,-8.403671f,19.10038f,3.8421636f ) ;
  }

  @Test
  public void test96() {
    color.laplace.solve(19.815817f,-23.99477f,-243.63889f,3.2508001f,-12.198664f,-41.170486f,4.170714f,13.066314f,60.359596f ) ;
  }

  @Test
  public void test97() {
    color.laplace.solve(19.830708f,-40.613506f,-14.715045f,15.527028f,13.94596f,-16.928438f,28.331446f,97.79876f,-66.94467f ) ;
  }

  @Test
  public void test98() {
    color.laplace.solve(19.876972f,-16.727669f,82.06687f,-3.7644434f,-32.021366f,-99.70429f,-2.913378f,-7.889068f,-4.230395f ) ;
  }

  @Test
  public void test99() {
    color.laplace.solve(-20.012926f,-68.33939f,0f,-35.935036f,-76.80258f,37.938328f,-46.92464f,93.23132f,0f ) ;
  }

  @Test
  public void test100() {
    color.laplace.solve(20.022844f,-19.617123f,5.999547f,-0.29149663f,6.851542f,83.45158f,-28.040373f,-36.136787f,0f ) ;
  }

  @Test
  public void test101() {
    color.laplace.solve(20.214985f,50.614567f,26.43566f,-69.75463f,55.807625f,-47.109226f,-17.080313f,1.4333788f,-32.993797f ) ;
  }

  @Test
  public void test102() {
    color.laplace.solve(20.383654f,32.696323f,44.885437f,-51.161705f,-34.4838f,46.84543f,-17.857159f,-20.26693f,-28.72676f ) ;
  }

  @Test
  public void test103() {
    color.laplace.solve(20.398302f,-29.716927f,-1.9185562f,11.310134f,1.6803387f,6.7454967f,23.161896f,18.382652f,27.220205f ) ;
  }

  @Test
  public void test104() {
    color.laplace.solve(20.429325f,-15.502455f,-235.08432f,-2.8264687f,-26.650991f,-75.08571f,-4.768456f,-13.339567f,-22.231586f ) ;
  }

  @Test
  public void test105() {
    color.laplace.solve(20.490244f,36.693466f,18.276535f,8.232232f,9.699247f,-8.85542f,2.739438f,2.7265732f,-1.5322118f ) ;
  }

  @Test
  public void test106() {
    color.laplace.solve(20.672445f,6.37287f,-99.999504f,-23.683088f,-20.051218f,-27.065416f,-95.353584f,-35.829235f,0f ) ;
  }

  @Test
  public void test107() {
    color.laplace.solve(20.800623f,20.366312f,60.66461f,-37.163826f,-99.999985f,1.75992f,-22.93895f,-54.591972f,-95.42896f ) ;
  }

  @Test
  public void test108() {
    color.laplace.solve(20.949713f,-19.845709f,63.554653f,3.6445591f,-6.596794f,-7.442741f,0.22531807f,-2.7432868f,-4.601671f ) ;
  }

  @Test
  public void test109() {
    color.laplace.solve(-2.1022365f,-100.0f,71.35042f,-5.2721844f,-19.690905f,18.418768f,0.7044033f,8.089798f,51.34569f ) ;
  }

  @Test
  public void test110() {
    color.laplace.solve(21.10936f,-35.927185f,28.83977f,20.364624f,50.602333f,37.942135f,9.7468f,18.622578f,14.141178f ) ;
  }

  @Test
  public void test111() {
    color.laplace.solve(21.17447f,72.1774f,86.33126f,-87.479515f,81.203865f,78.42726f,-11.247636f,42.488976f,100.0f ) ;
  }

  @Test
  public void test112() {
    color.laplace.solve(21.21368f,-27.602772f,53.654053f,12.457495f,22.325195f,91.73914f,6.2911024f,12.706915f,22.211363f ) ;
  }

  @Test
  public void test113() {
    color.laplace.solve(21.215874f,-20.089613f,-60.22688f,4.9531035f,-2.7745187f,-74.26921f,1.3710601f,78.30764f,-47.50103f ) ;
  }

  @Test
  public void test114() {
    color.laplace.solve(21.584343f,60.91906f,-7.389758f,6.429183f,3.1238914f,-52.457485f,1.0084969f,-2.3951952f,-13.71317f ) ;
  }

  @Test
  public void test115() {
    color.laplace.solve(21.587446f,9.087305f,4.4258146f,-22.737547f,-89.66405f,-91.38405f,-22.8736f,-68.75686f,0f ) ;
  }

  @Test
  public void test116() {
    color.laplace.solve(21.801546f,-2.9647486f,-100.0f,-9.829044f,-33.66024f,-21.847118f,-27.457272f,-100.0f,46.271767f ) ;
  }

  @Test
  public void test117() {
    color.laplace.solve(21.902248f,-44.2407f,0f,-7.717564f,-63.60588f,49.07685f,10.833377f,51.05107f,0f ) ;
  }

  @Test
  public void test118() {
    color.laplace.solve(21.961267f,-90.7408f,-12.440925f,2.2679863f,-20.903973f,-24.933695f,8.01465f,29.790615f,77.67454f ) ;
  }

  @Test
  public void test119() {
    color.laplace.solve(21.993761f,0.96124923f,-48.197166f,-12.986201f,-69.9516f,67.98824f,-3.9869678f,-2.96167f,-96.40069f ) ;
  }

  @Test
  public void test120() {
    color.laplace.solve(22.010178f,-77.61807f,0f,-66.47536f,15.769228f,0f,-7.3945084f,36.89732f,-10.728134f ) ;
  }

  @Test
  public void test121() {
    color.laplace.solve(22.079374f,-15.126615f,-34.36671f,3.4441133f,-11.01077f,-39.74786f,2.7078485f,7.3872805f,38.216415f ) ;
  }

  @Test
  public void test122() {
    color.laplace.solve(22.155523f,-13.727496f,-171.03078f,2.4345887f,-5.9949217f,15.326619f,-6.407534f,-27.951101f,-311.15186f ) ;
  }

  @Test
  public void test123() {
    color.laplace.solve(22.172655f,-9.137564f,100.0f,-2.1718166f,-26.884642f,-82.49988f,-3.9752803f,-13.729304f,-24.057297f ) ;
  }

  @Test
  public void test124() {
    color.laplace.solve(-22.217676f,-100.0f,0f,10.218913f,74.6355f,100.0f,-11.542172f,-56.387604f,100.0f ) ;
  }

  @Test
  public void test125() {
    color.laplace.solve(22.24455f,20.383204f,43.76079f,-31.405003f,-84.472534f,54.659966f,-63.392025f,-78.152596f,0f ) ;
  }

  @Test
  public void test126() {
    color.laplace.solve(22.471497f,43.068714f,1.4989895f,-53.182724f,38.85098f,33.904224f,-10.86487f,9.723244f,10.906867f ) ;
  }

  @Test
  public void test127() {
    color.laplace.solve(22.471552f,-45.773945f,2.7491972f,2.3353477f,-12.652327f,-2.9240227f,-0.4778349f,-4.246687f,-1.7926774f ) ;
  }

  @Test
  public void test128() {
    color.laplace.solve(22.504206f,-51.070328f,-19.331442f,41.087147f,100.0f,60.646557f,41.844387f,-100.0f,0f ) ;
  }

  @Test
  public void test129() {
    color.laplace.solve(22.644747f,5.085929f,-31.625027f,-14.506946f,-70.676f,-59.497227f,-9.996526f,-25.479156f,-21.244095f ) ;
  }

  @Test
  public void test130() {
    color.laplace.solve(22.65498f,3.3142383f,-55.525826f,-12.69432f,-53.8722f,-38.430218f,-11.839716f,-34.664547f,0f ) ;
  }

  @Test
  public void test131() {
    color.laplace.solve(22.885796f,13.566506f,31.376461f,-22.023325f,-99.99625f,11.939278f,-12.828495f,-29.290648f,-4.3378425f ) ;
  }

  @Test
  public void test132() {
    color.laplace.solve(22.945578f,-10.390609f,100.0f,2.1729155f,-13.211703f,-38.110752f,-1.0422114f,-6.341761f,-11.113129f ) ;
  }

  @Test
  public void test133() {
    color.laplace.solve(22.98988f,-95.64769f,0f,5.099472f,-4.8185315f,67.46831f,2.2265391f,3.8066888f,17.818748f ) ;
  }

  @Test
  public void test134() {
    color.laplace.solve(23.11442f,15.142005f,36.77884f,-22.684322f,-99.32524f,-75.916664f,-14.526473f,-35.421566f,-27.834557f ) ;
  }

  @Test
  public void test135() {
    color.laplace.solve(23.119383f,23.81937f,50.94778f,15.516568f,27.47899f,40.225f,11.467898f,30.355026f,82.47322f ) ;
  }

  @Test
  public void test136() {
    color.laplace.solve(23.164675f,-10.541742f,-95.41754f,3.2005303f,-10.07534f,-28.414585f,-0.3362587f,-4.545565f,-8.239999f ) ;
  }

  @Test
  public void test137() {
    color.laplace.solve(23.471926f,25.0135f,19.587631f,-31.125795f,-43.005554f,-46.662975f,-12.242359f,-17.843641f,-16.126654f ) ;
  }

  @Test
  public void test138() {
    color.laplace.solve(23.54591f,4.76008f,-64.86937f,-10.576437f,-39.63622f,-16.103464f,-26.215439f,0f,0f ) ;
  }

  @Test
  public void test139() {
    color.laplace.solve(23.548971f,35.680298f,31.85022f,-41.474422f,-12.6635065f,-8.27937f,-176.78053f,-36.58023f,-52.29511f ) ;
  }

  @Test
  public void test140() {
    color.laplace.solve(23.574743f,3.9454486f,-54.554756f,-9.6471195f,-53.25755f,-180.10663f,-9.186355f,-27.291252f,-46.76261f ) ;
  }

  @Test
  public void test141() {
    color.laplace.solve(23.591799f,10.993667f,4.2007413f,-16.620436f,-83.81787f,-94.18466f,-6.243144f,-8.35214f,56.649094f ) ;
  }

  @Test
  public void test142() {
    color.laplace.solve(23.600248f,-3.5490456f,-206.97517f,-2.029956f,-55.76698f,-27.038809f,23.40232f,-190.43423f,45.649044f ) ;
  }

  @Test
  public void test143() {
    color.laplace.solve(23.60591f,16.539396f,32.33814f,-22.11573f,-89.78647f,12.813207f,-22.282366f,-67.01373f,-88.981155f ) ;
  }

  @Test
  public void test144() {
    color.laplace.solve(23.651018f,-16.107943f,100.0f,10.712012f,11.578213f,31.945517f,7.618819f,19.763266f,59.85603f ) ;
  }

  @Test
  public void test145() {
    color.laplace.solve(23.655489f,-14.386355f,38.51855f,9.008312f,-8.57271f,-100.0f,20.95047f,74.793564f,0f ) ;
  }

  @Test
  public void test146() {
    color.laplace.solve(23.665785f,23.326286f,0f,6.133177f,3.4447958f,22.018871f,-2.577874f,-16.444674f,-66.645615f ) ;
  }

  @Test
  public void test147() {
    color.laplace.solve(23.696365f,49.807255f,6.8896503f,-55.02179f,68.643f,-100.0f,100.0f,-38.89981f,0f ) ;
  }

  @Test
  public void test148() {
    color.laplace.solve(-23.797432f,-4.0073996f,58.58143f,-14.31376f,-23.020315f,-46.324696f,-10.437292f,-27.435408f,-76.28402f ) ;
  }

  @Test
  public void test149() {
    color.laplace.solve(24.080128f,10.187096f,-19.30709f,-14.116127f,-57.24568f,-188.03706f,-12.249412f,-35.31765f,-212.78531f ) ;
  }

  @Test
  public void test150() {
    color.laplace.solve(24.085209f,-17.973349f,28.745487f,14.314181f,21.305687f,55.732777f,11.865831f,33.149143f,99.42506f ) ;
  }

  @Test
  public void test151() {
    color.laplace.solve(24.22419f,-11.750829f,8.742175f,8.647589f,6.2504997f,20.02135f,4.1843634f,8.089967f,21.925003f ) ;
  }

  @Test
  public void test152() {
    color.laplace.solve(24.355238f,20.557743f,57.875736f,-23.136763f,-100.0f,-100.0f,-16.90229f,-44.472378f,-60.987225f ) ;
  }

  @Test
  public void test153() {
    color.laplace.solve(24.381962f,25.2144f,11.60381f,-27.686554f,-35.128178f,-78.96861f,-100.0f,-59.071938f,-99.24496f ) ;
  }

  @Test
  public void test154() {
    color.laplace.solve(24.392336f,18.562439f,-29.952858f,-20.993095f,-20.189724f,27.958237f,-83.33167f,7.786314f,0f ) ;
  }

  @Test
  public void test155() {
    color.laplace.solve(-24.493301f,-159.98694f,60.705f,-37.967804f,-110.0264f,110.99791f,-18.402525f,-24.760084f,28.957794f ) ;
  }

  @Test
  public void test156() {
    color.laplace.solve(24.513422f,-4.8705525f,-2.885333f,2.9242394f,-9.178189f,-17.289104f,-3.6382751f,-17.477339f,-57.092896f ) ;
  }

  @Test
  public void test157() {
    color.laplace.solve(24.541004f,11.869252f,-14.999731f,-13.472621f,-61.66808f,-247.47198f,-16.079294f,-50.00857f,-122.40918f ) ;
  }

  @Test
  public void test158() {
    color.laplace.solve(24.565681f,-6.1769104f,0f,52.836666f,35.417984f,0f,-58.39846f,-57.470795f,0f ) ;
  }

  @Test
  public void test159() {
    color.laplace.solve(24.623484f,-8.51998f,31.211302f,7.017012f,1.3941257f,5.7620296f,2.0629282f,1.3060163f,1.7670115f ) ;
  }

  @Test
  public void test160() {
    color.laplace.solve(24.623508f,1.5816026f,-79.91946f,-3.0875688f,-38.377644f,82.89245f,1.4038589f,8.703004f,0f ) ;
  }

  @Test
  public void test161() {
    color.laplace.solve(24.734652f,0.544152f,-100.0f,-1.6044688f,-22.550447f,-55.638515f,-8.601334f,-32.787945f,-100.0f ) ;
  }

  @Test
  public void test162() {
    color.laplace.solve(24.754639f,5.310474f,-58.682125f,-6.291923f,-44.830616f,47.67723f,-5.0917144f,-14.074934f,-6.377406f ) ;
  }

  @Test
  public void test163() {
    color.laplace.solve(24.782341f,5.058962f,-81.29934f,1.6692399f,-23.205414f,-125.34504f,5.7634535f,25.562342f,185.52237f ) ;
  }

  @Test
  public void test164() {
    color.laplace.solve(24.787136f,2.5458815f,-98.0909f,-3.3973362f,-30.652424f,4.6640325f,-7.724058f,-27.498896f,-71.6191f ) ;
  }

  @Test
  public void test165() {
    color.laplace.solve(24.911612f,13.590053f,3.8393807f,-13.943608f,-74.390785f,-98.23253f,-6.295261f,-11.237435f,35.7363f ) ;
  }

  @Test
  public void test166() {
    color.laplace.solve(25.052347f,-8.216258f,7.460564f,8.425649f,4.256613f,7.6681733f,4.393634f,9.148888f,27.945303f ) ;
  }

  @Test
  public void test167() {
    color.laplace.solve(2.5127153f,22.60723f,0f,-24.434872f,-87.21546f,-44.561752f,-13.036737f,-27.71208f,-10.596124f ) ;
  }

  @Test
  public void test168() {
    color.laplace.solve(25.229689f,13.407217f,-45.294876f,-12.488466f,-26.305944f,-7.1363845f,-48.87761f,-99.00614f,43.05528f ) ;
  }

  @Test
  public void test169() {
    color.laplace.solve(25.232296f,7.706314f,-62.569378f,-6.7771316f,-31.837664f,-28.319422f,-20.503159f,-99.96041f,-38.36213f ) ;
  }

  @Test
  public void test170() {
    color.laplace.solve(25.311209f,2.497626f,-54.046803f,-1.2527908f,-20.297234f,-43.58601f,-10.025138f,-38.847763f,-99.99999f ) ;
  }

  @Test
  public void test171() {
    color.laplace.solve(25.354565f,-5.1974406f,-271.2809f,7.734757f,8.527723f,22.696756f,2.7575035f,8.290565f,21.076435f ) ;
  }

  @Test
  public void test172() {
    color.laplace.solve(25.569473f,2.961438f,-88.633f,-0.6835401f,-25.09072f,-90.47266f,-3.212915f,-12.168119f,-44.79248f ) ;
  }

  @Test
  public void test173() {
    color.laplace.solve(25.611004f,0.8697172f,-19.361155f,7.0866165f,0.8632024f,-4.9059563f,1.8722614f,0.40242895f,-1.1258808f ) ;
  }

  @Test
  public void test174() {
    color.laplace.solve(25.61946f,1.641034f,-95.106285f,0.8351533f,-23.923347f,-160.94118f,1.4923489f,5.1342425f,42.959934f ) ;
  }

  @Test
  public void test175() {
    color.laplace.solve(25.676464f,-52.737423f,21.697386f,-3.4437099f,-13.083423f,23.98606f,-26.367882f,-20.138615f,-73.126045f ) ;
  }

  @Test
  public void test176() {
    color.laplace.solve(-2.567695f,-99.999825f,38.27145f,-10.5875845f,-37.158142f,-38.134563f,-2.6245015f,0.08957835f,30.054537f ) ;
  }

  @Test
  public void test177() {
    color.laplace.solve(25.763008f,1.9029623f,-100.0f,1.1554009f,-18.15116f,-62.563026f,-2.9868984f,-13.102995f,-31.27095f ) ;
  }

  @Test
  public void test178() {
    color.laplace.solve(25.782566f,19.22665f,33.597984f,-16.096222f,-82.473946f,15.165294f,-7.920013f,-15.583829f,28.058645f ) ;
  }

  @Test
  public void test179() {
    color.laplace.solve(25.829203f,44.620655f,30.670696f,-41.30384f,21.982712f,-21.937864f,-9.885082f,1.7635103f,-5.0435886f ) ;
  }

  @Test
  public void test180() {
    color.laplace.solve(25.882853f,22.362999f,5.5908194f,-18.83159f,-42.02167f,-99.99972f,-59.187542f,-71.61838f,100.0f ) ;
  }

  @Test
  public void test181() {
    color.laplace.solve(-25.962296f,-26.774477f,0f,-49.441036f,-66.78205f,0f,81.95005f,58.15905f,0f ) ;
  }

  @Test
  public void test182() {
    color.laplace.solve(25.964224f,7.8569818f,-74.6977f,-4.000088f,-19.838596f,1.2925555f,-22.12598f,-84.50383f,99.70652f ) ;
  }

  @Test
  public void test183() {
    color.laplace.solve(-26.050852f,-38.52422f,0f,53.864624f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test184() {
    color.laplace.solve(26.109013f,3.048868f,-63.558033f,1.3871813f,-50.355507f,23.44487f,-0.7246012f,-4.2855864f,-31.87081f ) ;
  }

  @Test
  public void test185() {
    color.laplace.solve(26.205204f,4.7845216f,-96.95156f,0.036292672f,-10.115556f,18.531162f,-15.944477f,-63.814198f,-13.206889f ) ;
  }

  @Test
  public void test186() {
    color.laplace.solve(26.29453f,3.4736028f,-100.0f,1.7888962f,-12.360341f,-25.79789f,-6.7786045f,-28.891575f,-100.0f ) ;
  }

  @Test
  public void test187() {
    color.laplace.solve(26.3023f,-7.866694f,-26.988073f,13.075889f,10.071688f,-15.56483f,15.929568f,50.642387f,-45.342934f ) ;
  }

  @Test
  public void test188() {
    color.laplace.solve(26.399809f,56.88819f,71.69222f,-51.28895f,29.460733f,-48.89049f,-73.72856f,37.46989f,0f ) ;
  }

  @Test
  public void test189() {
    color.laplace.solve(26.423462f,3.7458882f,-97.235176f,1.9479792f,-14.204733f,-42.85728f,-4.426806f,-19.65519f,-59.989204f ) ;
  }

  @Test
  public void test190() {
    color.laplace.solve(26.427113f,4.9675884f,-99.479805f,0.74086076f,-20.79361f,-77.46179f,-2.6700592f,-11.421098f,-22.220722f ) ;
  }

  @Test
  public void test191() {
    color.laplace.solve(26.551031f,18.102728f,10.201791f,-11.898601f,-64.34191f,-77.29557f,-9.803523f,-27.315493f,-35.11654f ) ;
  }

  @Test
  public void test192() {
    color.laplace.solve(26.576202f,17.644697f,14.857378f,-11.339887f,-70.8548f,-58.215187f,-1.0809562f,7.0160623f,100.0f ) ;
  }

  @Test
  public void test193() {
    color.laplace.solve(26.652924f,-4.9615564f,-99.77256f,11.573251f,9.4242f,1.7939696f,10.216099f,29.291145f,97.52424f ) ;
  }

  @Test
  public void test194() {
    color.laplace.solve(26.683216f,18.84359f,28.548044f,-12.1107235f,-79.8569f,-13.95346f,4.730795f,31.033903f,-45.40268f ) ;
  }

  @Test
  public void test195() {
    color.laplace.solve(2.6704042f,-78.81732f,-6.712355f,-10.502277f,-35.428112f,-25.878792f,-9.253897f,-26.514177f,-61.3747f ) ;
  }

  @Test
  public void test196() {
    color.laplace.solve(26.757727f,28.582691f,87.57304f,-21.551783f,-100.0f,-21.286139f,-12.964859f,-30.307652f,-8.265751f ) ;
  }

  @Test
  public void test197() {
    color.laplace.solve(26.772602f,-4.5741653f,-88.578865f,11.664628f,9.849474f,3.8267763f,10.036311f,28.480658f,94.03649f ) ;
  }

  @Test
  public void test198() {
    color.laplace.solve(26.978191f,3.8262649f,-127.82452f,3.8579776f,-5.2819433f,-25.984396f,0.9241939f,-0.16120203f,5.6621656f ) ;
  }

  @Test
  public void test199() {
    color.laplace.solve(26.999338f,23.452082f,6.503511f,-15.454726f,-39.686672f,-97.43841f,-8.711616f,-19.40122f,-29.209906f ) ;
  }

  @Test
  public void test200() {
    color.laplace.solve(27.11299f,29.832811f,86.217476f,-21.380205f,-93.999176f,-30.916363f,-18.63462f,-53.157547f,-99.99639f ) ;
  }

  @Test
  public void test201() {
    color.laplace.solve(27.12541f,26.512741f,66.74641f,-18.011103f,-87.82078f,-89.81737f,-11.351429f,-27.394613f,-10.405526f ) ;
  }

  @Test
  public void test202() {
    color.laplace.solve(-27.185038f,-100.0f,0f,4.83476f,43.87958f,-100.0f,2.6444952f,5.7432213f,-23.551193f ) ;
  }

  @Test
  public void test203() {
    color.laplace.solve(27.224472f,3.5039952f,-99.99989f,5.39389f,-7.6190643f,-41.860867f,1.9701536f,2.4867241f,15.595807f ) ;
  }

  @Test
  public void test204() {
    color.laplace.solve(27.226875f,33.64814f,33.40715f,-24.740635f,-26.041473f,-0.019532043f,-20.571474f,-57.54526f,0f ) ;
  }

  @Test
  public void test205() {
    color.laplace.solve(27.230007f,31.392973f,26.978704f,-22.472834f,-28.636818f,-23.47811f,-88.484566f,-99.98926f,-92.2543f ) ;
  }

  @Test
  public void test206() {
    color.laplace.solve(27.254412f,-5.857329f,-28.769554f,6.6794677f,-2.0329678f,-8.260256f,1.4964285f,-0.693754f,-2.2385025f ) ;
  }

  @Test
  public void test207() {
    color.laplace.solve(27.326628f,-100.0f,0f,-39.077446f,6.931831f,45.040333f,-9.167751f,2.4064436f,11.861694f ) ;
  }

  @Test
  public void test208() {
    color.laplace.solve(27.367214f,-0.43774256f,-99.81437f,9.906602f,8.625217f,20.402714f,3.6339753f,4.629299f,6.2580028f ) ;
  }

  @Test
  public void test209() {
    color.laplace.solve(27.381824f,8.956791f,-78.0897f,0.57050383f,-13.464966f,-16.277283f,-11.634843f,-47.109875f,99.65119f ) ;
  }

  @Test
  public void test210() {
    color.laplace.solve(27.42171f,21.95488f,25.104658f,-12.267998f,-64.70685f,-21.536201f,-11.7871f,-34.8804f,-63.02796f ) ;
  }

  @Test
  public void test211() {
    color.laplace.solve(27.488173f,-23.740705f,-14.623356f,-5.085497f,-32.64134f,-46.069366f,-15.188822f,-55.66979f,-84.47524f ) ;
  }

  @Test
  public void test212() {
    color.laplace.solve(27.613358f,15.515854f,-22.977308f,-5.0624247f,-42.550922f,-50.43712f,-5.297542f,-16.121946f,-16.639767f ) ;
  }

  @Test
  public void test213() {
    color.laplace.solve(27.677767f,31.740908f,21.086918f,-21.029839f,-21.801054f,-47.393234f,-89.99607f,65.086945f,0f ) ;
  }

  @Test
  public void test214() {
    color.laplace.solve(27.733028f,-8.824684f,100.0f,19.7568f,78.07536f,60.753395f,-26.78119f,-18.607714f,0f ) ;
  }

  @Test
  public void test215() {
    color.laplace.solve(27.735245f,21.820147f,22.818218f,-10.879168f,-63.272873f,-30.547277f,-7.9790406f,-21.036995f,-12.896069f ) ;
  }

  @Test
  public void test216() {
    color.laplace.solve(27.745144f,-2.160057f,76.872536f,13.138362f,15.564028f,27.438404f,9.24417f,23.83832f,70.54508f ) ;
  }

  @Test
  public void test217() {
    color.laplace.solve(27.747162f,-29.931053f,-99.99891f,12.929987f,17.859938f,76.91971f,6.1127896f,11.521107f,22.110205f ) ;
  }

  @Test
  public void test218() {
    color.laplace.solve(27.755215f,15.698966f,-80.001884f,-4.6781077f,-23.920944f,-21.195957f,-22.5467f,-85.508675f,-30.35522f ) ;
  }

  @Test
  public void test219() {
    color.laplace.solve(-27.835026f,99.26737f,100.0f,-2.1490173f,19.11836f,-23.276318f,0.12059621f,2.631402f,-100.0f ) ;
  }

  @Test
  public void test220() {
    color.laplace.solve(27.85004f,21.704174f,41.706066f,-10.304014f,-100.0f,55.87204f,-13.550646f,-43.898567f,-62.04363f ) ;
  }

  @Test
  public void test221() {
    color.laplace.solve(28.063717f,6.9972115f,-100.0f,5.2576594f,-0.07485265f,20.53628f,-6.9582257f,-33.090557f,99.998474f ) ;
  }

  @Test
  public void test222() {
    color.laplace.solve(28.204893f,6.0441866f,100.0f,6.775387f,-1.0057156f,-9.67653f,-0.097629465f,-7.165905f,-29.048346f ) ;
  }

  @Test
  public void test223() {
    color.laplace.solve(28.215836f,26.066826f,-10.838762f,-13.203482f,-13.109769f,3.4764578f,-67.91999f,-68.77888f,0f ) ;
  }

  @Test
  public void test224() {
    color.laplace.solve(28.231949f,25.14093f,45.96177f,-12.213131f,-73.630005f,58.70615f,-3.4544709f,-100.0f,0f ) ;
  }

  @Test
  public void test225() {
    color.laplace.solve(28.304647f,6.9883165f,-95.93923f,6.2302737f,-4.4121475f,-28.751291f,1.0285962f,-2.1158893f,-100.0f ) ;
  }

  @Test
  public void test226() {
    color.laplace.solve(28.306276f,7.3761873f,-99.12786f,5.848919f,0.32633594f,23.970732f,-5.236937f,-35.89049f,0f ) ;
  }

  @Test
  public void test227() {
    color.laplace.solve(28.327059f,7.882469f,-91.83524f,5.4257655f,-4.9619346f,-21.08196f,-1.6620618f,-12.074013f,-41.672054f ) ;
  }

  @Test
  public void test228() {
    color.laplace.solve(28.38648f,8.651703f,-86.408356f,4.894217f,-7.3713174f,-32.383793f,-1.4382946f,-10.647395f,-35.75551f ) ;
  }

  @Test
  public void test229() {
    color.laplace.solve(28.410069f,88.3715f,0f,33.60855f,76.29487f,-29.712507f,29.729273f,85.30854f,-7.5285053f ) ;
  }

  @Test
  public void test230() {
    color.laplace.solve(28.41578f,8.449674f,-88.690926f,5.2134395f,-5.9261584f,-33.643818f,0.3723774f,-3.7239294f,-9.341936f ) ;
  }

  @Test
  public void test231() {
    color.laplace.solve(28.4246f,3.991364f,6.7432866f,9.707041f,9.44623f,49.129356f,0.95733076f,-5.8777175f,-33.91443f ) ;
  }

  @Test
  public void test232() {
    color.laplace.solve(28.524637f,6.787053f,-99.68676f,7.311481f,-1.6898768f,-23.191341f,2.4111643f,2.3331618f,8.611278f ) ;
  }

  @Test
  public void test233() {
    color.laplace.solve(28.580406f,-41.298492f,-86.684074f,55.620117f,20.320004f,0f,35.323933f,85.67561f,0f ) ;
  }

  @Test
  public void test234() {
    color.laplace.solve(28.654667f,8.00387f,-73.65352f,7.1202755f,-1.6065124f,-20.161207f,1.4329473f,-1.3898866f,-5.386748f ) ;
  }

  @Test
  public void test235() {
    color.laplace.solve(-28.672606f,-19.806906f,-100.0f,-2.9390516f,12.26736f,50.280186f,4.6490393f,21.53521f,69.22444f ) ;
  }

  @Test
  public void test236() {
    color.laplace.solve(28.692205f,-8.018557f,61.956665f,-1.3756701f,-15.865634f,17.873028f,-18.329252f,-71.94134f,-80.872406f ) ;
  }

  @Test
  public void test237() {
    color.laplace.solve(28.740454f,23.540018f,20.435505f,-8.5782f,-55.015884f,-48.33718f,-8.037371f,-23.571281f,-31.23187f ) ;
  }

  @Test
  public void test238() {
    color.laplace.solve(28.756334f,6.588877f,-90.89632f,8.436457f,-11.504511f,-5.228706f,16.494003f,-55.81467f,-100.0f ) ;
  }

  @Test
  public void test239() {
    color.laplace.solve(28.832293f,4.513136f,7.406799f,10.816035f,9.081818f,28.790457f,5.3500295f,10.584084f,27.904488f ) ;
  }

  @Test
  public void test240() {
    color.laplace.solve(28.847666f,40.591568f,37.472683f,-25.224264f,-3.8285089f,9.340255f,-125.76311f,-39.86257f,-84.0658f ) ;
  }

  @Test
  public void test241() {
    color.laplace.solve(28.91277f,25.5102f,34.305607f,-9.859124f,-61.177574f,-9.017513f,-7.1716905f,-18.827639f,-6.961288f ) ;
  }

  @Test
  public void test242() {
    color.laplace.solve(28.915882f,22.131704f,-24.583668f,-6.4681783f,-15.805394f,-81.89669f,-38.9832f,3.0115876f,99.98575f ) ;
  }

  @Test
  public void test243() {
    color.laplace.solve(28.93226f,24.266293f,31.147556f,-8.5372505f,-63.014645f,-20.316618f,-0.06661825f,8.270777f,96.16437f ) ;
  }

  @Test
  public void test244() {
    color.laplace.solve(28.956688f,35.78581f,30.88211f,-19.959053f,-16.695566f,-12.257368f,-92.097336f,-70.351654f,-63.216015f ) ;
  }

  @Test
  public void test245() {
    color.laplace.solve(29.021957f,22.122019f,-93.31071f,-6.0341873f,-5.1305323f,-7.1549563f,-48.028175f,-29.455006f,35.48661f ) ;
  }

  @Test
  public void test246() {
    color.laplace.solve(29.044353f,11.84986f,-76.92728f,4.4371653f,-4.717638f,-2.185988f,-6.5780544f,-32.97159f,72.90096f ) ;
  }

  @Test
  public void test247() {
    color.laplace.solve(29.121214f,6.1977944f,-100.0f,10.287068f,-4.330039f,-5.626197f,16.357101f,-28.178812f,81.82526f ) ;
  }

  @Test
  public void test248() {
    color.laplace.solve(29.167053f,13.349745f,0f,17.54831f,-84.41273f,0f,-3.2663658f,-30.613773f,0f ) ;
  }

  @Test
  public void test249() {
    color.laplace.solve(29.222275f,21.674019f,-7.0108185f,-2.3826365f,-35.330933f,-147.46841f,-2.8377428f,-10.94501f,-20.701677f ) ;
  }

  @Test
  public void test250() {
    color.laplace.solve(29.254744f,93.07852f,-1.3943297f,-76.05955f,-23.769608f,0f,-25.106907f,-24.36808f,0f ) ;
  }

  @Test
  public void test251() {
    color.laplace.solve(29.288626f,27.28693f,-27.499477f,-10.132429f,7.3585715f,-20.293291f,-77.17691f,32.573074f,-61.680798f ) ;
  }

  @Test
  public void test252() {
    color.laplace.solve(29.320185f,-8.426726f,-40.338917f,20.506678f,33.042747f,61.942596f,19.66378f,58.148445f,7.882801f ) ;
  }

  @Test
  public void test253() {
    color.laplace.solve(29.349844f,11.559102f,-85.35171f,5.840248f,-7.7021604f,-49.220562f,1.7130133f,1.011805f,10.036072f ) ;
  }

  @Test
  public void test254() {
    color.laplace.solve(29.393713f,26.60903f,15.314276f,-9.034175f,-38.27187f,-70.66234f,-27.258543f,-100.0f,100.0f ) ;
  }

  @Test
  public void test255() {
    color.laplace.solve(29.412197f,45.264668f,44.86278f,-27.615877f,6.7836895f,34.186462f,0f,0f,0f ) ;
  }

  @Test
  public void test256() {
    color.laplace.solve(29.441809f,38.193f,29.463505f,-18.635914f,-3.8766594f,-18.785194f,-100.0f,-15.937869f,-113.589035f ) ;
  }

  @Test
  public void test257() {
    color.laplace.solve(29.452755f,22.901728f,18.675438f,-5.0907097f,-56.521282f,-48.199974f,-6.2615314f,-19.955416f,-17.038847f ) ;
  }

  @Test
  public void test258() {
    color.laplace.solve(29.457268f,15.728957f,-49.822136f,2.1001167f,-16.719303f,-65.25618f,-4.337498f,-19.45011f,59.7499f ) ;
  }

  @Test
  public void test259() {
    color.laplace.solve(29.46237f,-6.95549f,-1.7212522f,24.412865f,37.085873f,30.886114f,31.103216f,100.0f,88.17984f ) ;
  }

  @Test
  public void test260() {
    color.laplace.solve(29.584003f,10.705248f,-87.1957f,7.6307664f,0.4326954f,-14.294809f,0.50636584f,-5.6053023f,-23.360271f ) ;
  }

  @Test
  public void test261() {
    color.laplace.solve(29.60258f,19.601929f,-19.650072f,-1.191612f,-31.544796f,70.16096f,-2.7791584f,-9.925022f,-5.3761325f ) ;
  }

  @Test
  public void test262() {
    color.laplace.solve(29.716326f,29.58202f,7.395505f,-10.71672f,-18.78375f,-100.0f,-53.799454f,5.999697f,-100.0f ) ;
  }

  @Test
  public void test263() {
    color.laplace.solve(29.757988f,12.843236f,-74.07607f,6.1889853f,-4.3089733f,-27.306808f,-0.6930731f,-8.961082f,-30.842283f ) ;
  }

  @Test
  public void test264() {
    color.laplace.solve(29.77823f,34.10691f,22.310019f,-8.703501f,-13.17197f,-47.73837f,-50.814785f,-28.986818f,-201.38985f ) ;
  }

  @Test
  public void test265() {
    color.laplace.solve(29.84731f,28.23654f,14.728618f,-8.847301f,-31.629766f,-69.32207f,-33.606747f,-76.586235f,-31.50068f ) ;
  }

  @Test
  public void test266() {
    color.laplace.solve(-29.848055f,24.709856f,0f,-18.640697f,-76.34645f,-21.545847f,31.631714f,-70.762634f,0f ) ;
  }

  @Test
  public void test267() {
    color.laplace.solve(29.866367f,12.189675f,-93.131226f,7.2758574f,-2.098922f,-25.929188f,1.3359561f,-1.9320331f,-6.9653053f ) ;
  }

  @Test
  public void test268() {
    color.laplace.solve(29.867573f,93.45796f,23.223587f,-73.98766f,-87.351616f,0f,71.35002f,-25.285568f,0f ) ;
  }

  @Test
  public void test269() {
    color.laplace.solve(29.938673f,25.315876f,19.808592f,-5.5611863f,-48.483757f,-46.081512f,-5.7756133f,-17.541267f,-15.905694f ) ;
  }

  @Test
  public void test270() {
    color.laplace.solve(29.95091f,29.767885f,31.43745f,-9.964243f,-42.316822f,-4.0180798f,-27.49106f,-100.0f,0f ) ;
  }

  @Test
  public void test271() {
    color.laplace.solve(29.99535f,8.809404f,-4.5801587f,11.171997f,96.08942f,0f,27.453688f,98.64275f,28.97215f ) ;
  }

  @Test
  public void test272() {
    color.laplace.solve(29.99945f,9.828057f,-92.08186f,10.169984f,1.3946435f,-41.392635f,9.285841f,26.97317f,-74.88332f ) ;
  }

  @Test
  public void test273() {
    color.laplace.solve(30.042395f,-23.12457f,-100.0f,16.36338f,27.313286f,99.98694f,8.097845f,16.02739f,28.69843f ) ;
  }

  @Test
  public void test274() {
    color.laplace.solve(30.150856f,24.703661f,6.177015f,-4.1002336f,-37.513226f,-99.995605f,-9.038565f,-32.05403f,-81.66433f ) ;
  }

  @Test
  public void test275() {
    color.laplace.solve(30.232273f,10.21567f,-99.9995f,10.713427f,9.043323f,11.645184f,3.5781088f,3.5990088f,1.7746043f ) ;
  }

  @Test
  public void test276() {
    color.laplace.solve(30.279402f,28.424618f,33.616215f,-7.307009f,-50.197144f,6.040243f,-9.310295f,-29.934172f,-60.229248f ) ;
  }

  @Test
  public void test277() {
    color.laplace.solve(30.318579f,31.759907f,29.16331f,-7.976948f,-28.988409f,-15.063105f,-33.004875f,-124.97925f,0f ) ;
  }

  @Test
  public void test278() {
    color.laplace.solve(30.403921f,19.709354f,-35.68248f,1.9063265f,-15.884024f,99.99972f,-6.89459f,-29.484686f,-95.16013f ) ;
  }

  @Test
  public void test279() {
    color.laplace.solve(30.499979f,37.75638f,14.051382f,-15.756467f,6.4741564f,-81.55085f,-100.0f,85.44756f,-74.59846f ) ;
  }

  @Test
  public void test280() {
    color.laplace.solve(30.529995f,31.14242f,-8.017644f,-9.022443f,2.0573301f,20.87761f,-68.67709f,-34.768265f,100.0f ) ;
  }

  @Test
  public void test281() {
    color.laplace.solve(30.542572f,31.651548f,29.424452f,-9.484773f,-32.06413f,-13.95612f,-36.46059f,-136.46378f,-53.237488f ) ;
  }

  @Test
  public void test282() {
    color.laplace.solve(30.582035f,21.07788f,-73.49717f,1.2825642f,-22.419727f,-98.62751f,-3.032052f,-13.37948f,-28.00177f ) ;
  }

  @Test
  public void test283() {
    color.laplace.solve(30.61095f,17.566727f,-53.326336f,4.877075f,-7.883019f,-36.22028f,-3.2196302f,-17.755596f,-59.919735f ) ;
  }

  @Test
  public void test284() {
    color.laplace.solve(30.673796f,14.787582f,-99.99231f,7.9076037f,-0.6827847f,-24.076334f,1.6394032f,-1.3499906f,-6.356581f ) ;
  }

  @Test
  public void test285() {
    color.laplace.solve(30.799725f,21.376139f,87.552574f,1.7826787f,-25.83916f,-132.58751f,1.9560245f,6.0678773f,15.984946f ) ;
  }

  @Test
  public void test286() {
    color.laplace.solve(30.800247f,17.204027f,-56.48175f,5.99696f,-5.5023856f,44.519157f,-1.310048f,-11.237152f,-38.136173f ) ;
  }

  @Test
  public void test287() {
    color.laplace.solve(30.805443f,16.35022f,-97.694756f,6.8715496f,-3.461205f,-30.762884f,0.14196104f,-6.3037057f,-21.895578f ) ;
  }

  @Test
  public void test288() {
    color.laplace.solve(30.857847f,1.9407206f,-39.20158f,21.490665f,-83.89339f,-73.81255f,-12.713893f,30.412235f,0f ) ;
  }

  @Test
  public void test289() {
    color.laplace.solve(30.901472f,15.371854f,-70.09184f,8.234036f,0.677782f,-18.088297f,1.356893f,-2.8064651f,99.99998f ) ;
  }

  @Test
  public void test290() {
    color.laplace.solve(30.921515f,21.844477f,-9.38523f,2.0602474f,-33.33885f,-159.1547f,10.754532f,1.9756347f,-49.422718f ) ;
  }

  @Test
  public void test291() {
    color.laplace.solve(30.929207f,20.64521f,-29.905188f,3.0716174f,-18.44318f,16.523222f,-0.1995578f,-3.8698485f,3.1633434f ) ;
  }

  @Test
  public void test292() {
    color.laplace.solve(30.982792f,13.386287f,-83.42147f,10.544877f,5.983825f,-10.302972f,5.212996f,10.307224f,30.032206f ) ;
  }

  @Test
  public void test293() {
    color.laplace.solve(31.022633f,15.691866f,-69.046555f,8.398665f,1.0346779f,-18.857214f,1.800741f,-1.094605f,-7.1899405f ) ;
  }

  @Test
  public void test294() {
    color.laplace.solve(31.128881f,0.14545774f,-136.73878f,24.370071f,6.1770015f,85.06243f,59.987083f,-83.73982f,0f ) ;
  }

  @Test
  public void test295() {
    color.laplace.solve(31.13619f,10.07093f,-80.314125f,14.473835f,-10.538345f,-5.4105754f,37.297497f,-61.28757f,-72.40852f ) ;
  }

  @Test
  public void test296() {
    color.laplace.solve(31.184975f,44.033287f,-16.493057f,-19.293388f,-59.60778f,0f,-42.256313f,-58.798946f,0f ) ;
  }

  @Test
  public void test297() {
    color.laplace.solve(31.19953f,48.777683f,99.74926f,-23.979563f,-35.83806f,-38.211864f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test298() {
    color.laplace.solve(31.307884f,29.61985f,16.06806f,-4.388316f,-28.896544f,-65.34761f,-19.964603f,-75.4701f,-100.0f ) ;
  }

  @Test
  public void test299() {
    color.laplace.solve(31.323244f,-28.6955f,-5.466779f,53.988472f,27.151949f,0f,18.485453f,19.953335f,34.17594f ) ;
  }

  @Test
  public void test300() {
    color.laplace.solve(31.380642f,0.50087196f,163.71848f,12.659652f,13.266626f,28.600246f,5.9913383f,11.305753f,25.965075f ) ;
  }

  @Test
  public void test301() {
    color.laplace.solve(3.1387615f,-80.07437f,6.6555886f,-7.3705864f,-27.561996f,-9.937179f,-5.0591097f,-12.865853f,-18.842306f ) ;
  }

  @Test
  public void test302() {
    color.laplace.solve(31.414398f,14.168519f,24.941101f,11.48907f,-99.68142f,-14.404118f,2.1229925f,-2.9971f,0f ) ;
  }

  @Test
  public void test303() {
    color.laplace.solve(31.497534f,43.60366f,44.86883f,-17.613527f,-1.9517246f,-100.0f,-99.999916f,52.57267f,0f ) ;
  }

  @Test
  public void test304() {
    color.laplace.solve(31.526665f,15.474024f,-74.52592f,10.632637f,4.8953547f,-99.72242f,6.1085486f,13.801558f,44.202335f ) ;
  }

  @Test
  public void test305() {
    color.laplace.solve(31.605265f,29.129679f,7.2824206f,-2.7086225f,-22.36897f,-100.0f,-20.070784f,-77.57451f,67.62965f ) ;
  }

  @Test
  public void test306() {
    color.laplace.solve(3.1671298f,-83.9681f,-76.52949f,-3.3633802f,-18.278456f,4.223065f,1.6578041f,9.9945965f,48.539707f ) ;
  }

  @Test
  public void test307() {
    color.laplace.solve(31.701948f,-8.166498f,-62.548634f,34.97429f,-9.169769f,4.20489f,10.28305f,6.157911f,23.518362f ) ;
  }

  @Test
  public void test308() {
    color.laplace.solve(31.755344f,16.508959f,-99.38611f,10.512416f,7.007087f,-1.6295421f,3.287233f,2.6365159f,0.25174347f ) ;
  }

  @Test
  public void test309() {
    color.laplace.solve(31.763092f,23.95062f,-29.451612f,3.1017458f,-6.5089965f,1.401839f,-12.847112f,-54.490192f,20.621681f ) ;
  }

  @Test
  public void test310() {
    color.laplace.solve(-31.770422f,16.818748f,32.0628f,-6.896916f,5.4593825f,10.1252775f,-1.2766238f,1.7904204f,2.978924f ) ;
  }

  @Test
  public void test311() {
    color.laplace.solve(31.817299f,21.215551f,-50.475754f,6.053643f,-6.862823f,-45.707233f,-0.73990196f,-9.013251f,-28.45028f ) ;
  }

  @Test
  public void test312() {
    color.laplace.solve(31.81925f,33.428364f,18.077595f,-6.1513624f,-16.183388f,-61.11799f,-40.241314f,-30.892565f,0f ) ;
  }

  @Test
  public void test313() {
    color.laplace.solve(31.825089f,27.199568f,-9.629314f,0.10078797f,-13.397502f,-8.692027f,-18.024477f,-72.19878f,-11.741291f ) ;
  }

  @Test
  public void test314() {
    color.laplace.solve(-31.88999f,73.403824f,20.515253f,-19.102207f,-2.5492227f,-8.1837225f,-41.96962f,-56.31478f,-50.700916f ) ;
  }

  @Test
  public void test315() {
    color.laplace.solve(31.91888f,19.004145f,-56.21175f,8.671377f,0.30944666f,-27.595083f,2.4571817f,1.1573493f,-54.47803f ) ;
  }

  @Test
  public void test316() {
    color.laplace.solve(31.996998f,33.4075f,42.593708f,-5.4209547f,-40.961117f,36.96734f,-3.72701f,-9.486291f,6.742963f ) ;
  }

  @Test
  public void test317() {
    color.laplace.solve(32.1077f,41.175655f,34.99638f,-12.74486f,-2.4014583f,-1.1901385f,-80.68568f,-36.84649f,-90.93612f ) ;
  }

  @Test
  public void test318() {
    color.laplace.solve(32.13094f,18.465555f,54.297287f,10.058197f,3.463231f,-23.168863f,4.639058f,8.498036f,25.889856f ) ;
  }

  @Test
  public void test319() {
    color.laplace.solve(32.136456f,31.35694f,27.008196f,-2.8111224f,-33.716892f,-23.324158f,-9.664053f,-35.84509f,-99.99941f ) ;
  }

  @Test
  public void test320() {
    color.laplace.solve(32.19459f,28.690695f,14.778121f,0.087674014f,-32.209934f,-69.57821f,0.3660369f,1.3764721f,37.349785f ) ;
  }

  @Test
  public void test321() {
    color.laplace.solve(32.202003f,26.191738f,-37.507088f,2.616274f,10.072036f,4.305035f,-31.808943f,7.1750946f,44.655193f ) ;
  }

  @Test
  public void test322() {
    color.laplace.solve(32.228695f,32.292812f,36.43771f,-3.3780348f,-39.495155f,12.631534f,-1.5519711f,-2.8298495f,26.133387f ) ;
  }

  @Test
  public void test323() {
    color.laplace.solve(32.23404f,17.834333f,27.211878f,11.1018505f,6.990703f,-10.601952f,5.1826606f,9.62861f,-76.6105f ) ;
  }

  @Test
  public void test324() {
    color.laplace.solve(32.4192f,18.287075f,-68.72288f,11.389716f,9.434442f,0.7425991f,3.7355866f,3.5526304f,1.0738076f ) ;
  }

  @Test
  public void test325() {
    color.laplace.solve(32.422604f,27.010391f,-100.0f,2.6800225f,-14.197989f,-53.784252f,-7.504524f,-32.69812f,15.476504f ) ;
  }

  @Test
  public void test326() {
    color.laplace.solve(32.436035f,31.391256f,-99.998985f,-1.6471196f,-23.971762f,-67.06729f,-15.052752f,-58.56389f,-63.444485f ) ;
  }

  @Test
  public void test327() {
    color.laplace.solve(32.437355f,31.005466f,33.268803f,-1.2560444f,-41.68429f,2.069749f,4.2227607f,18.147087f,-56.90458f ) ;
  }

  @Test
  public void test328() {
    color.laplace.solve(32.445724f,29.492498f,17.660908f,0.29039273f,-32.13663f,-58.848873f,0.8524804f,3.119529f,63.60245f ) ;
  }

  @Test
  public void test329() {
    color.laplace.solve(32.453545f,21.82988f,-9.616827f,7.9842973f,13.1919985f,85.77153f,-13.708354f,-62.817715f,34.022064f ) ;
  }

  @Test
  public void test330() {
    color.laplace.solve(32.460297f,32.26017f,33.870872f,-2.4189763f,-37.290493f,3.2233274f,-4.8457117f,-16.963871f,0f ) ;
  }

  @Test
  public void test331() {
    color.laplace.solve(32.51672f,20.179821f,-56.104748f,9.887056f,4.3200636f,-13.745336f,2.7114425f,0.95871294f,-3.1966555f ) ;
  }

  @Test
  public void test332() {
    color.laplace.solve(32.5381f,22.629194f,34.38197f,7.5232096f,-76.40329f,14.89869f,0.2837689f,-6.388134f,-14.973991f ) ;
  }

  @Test
  public void test333() {
    color.laplace.solve(32.55717f,14.099186f,17.55947f,16.129503f,21.28137f,28.308393f,10.679475f,26.588394f,74.39273f ) ;
  }

  @Test
  public void test334() {
    color.laplace.solve(32.55981f,32.07237f,33.710255f,-1.833124f,-37.98059f,72.36309f,-1.9117166f,-5.813742f,16.637339f ) ;
  }

  @Test
  public void test335() {
    color.laplace.solve(32.56669f,35.012356f,20.426888f,-4.7456f,-12.944147f,-53.304806f,-38.604942f,-28.738543f,-100.0f ) ;
  }

  @Test
  public void test336() {
    color.laplace.solve(32.659866f,34.068314f,39.986595f,-3.428841f,-36.373215f,25.878063f,-10.002017f,-36.579227f,-99.94169f ) ;
  }

  @Test
  public void test337() {
    color.laplace.solve(32.674706f,29.416044f,14.863458f,1.2829217f,-29.873861f,-69.96221f,2.3308434f,-80.23205f,99.22997f ) ;
  }

  @Test
  public void test338() {
    color.laplace.solve(32.776646f,23.130665f,-43.30305f,8.945223f,3.049061f,-12.187921f,1.782932f,-0.9164249f,-8.497693f ) ;
  }

  @Test
  public void test339() {
    color.laplace.solve(32.78423f,45.71565f,47.70496f,-14.578731f,2.3734045f,43.2975f,-93.47256f,-64.9408f,-23.140171f ) ;
  }

  @Test
  public void test340() {
    color.laplace.solve(32.81944f,26.31795f,-13.529311f,4.9598074f,-14.018183f,63.733448f,1.0378811f,-0.808283f,9.7471695f ) ;
  }

  @Test
  public void test341() {
    color.laplace.solve(32.83344f,19.50464f,-49.495316f,11.82911f,-5.319325f,-22.261404f,19.802328f,-30.349648f,-34.230976f ) ;
  }

  @Test
  public void test342() {
    color.laplace.solve(32.846066f,18.45714f,-50.359352f,12.927123f,11.84034f,0.81586707f,7.0220876f,15.161227f,41.782482f ) ;
  }

  @Test
  public void test343() {
    color.laplace.solve(32.873375f,45.69311f,83.2766f,-14.199606f,-33.377537f,-99.51064f,-5.243548f,-6.7745857f,11.522743f ) ;
  }

  @Test
  public void test344() {
    color.laplace.solve(32.873512f,29.985102f,7.7214084f,1.506605f,-20.534044f,-100.0f,-3.365784f,-13.155168f,-28.720842f ) ;
  }

  @Test
  public void test345() {
    color.laplace.solve(32.91935f,47.09307f,52.914524f,-15.415677f,1.1476526f,35.202065f,-95.72971f,-62.288845f,86.918846f ) ;
  }

  @Test
  public void test346() {
    color.laplace.solve(32.95002f,25.008627f,-96.57064f,6.791451f,-7.554842f,-62.3105f,1.7706264f,0.2910549f,6.9484353f ) ;
  }

  @Test
  public void test347() {
    color.laplace.solve(32.95778f,20.886843f,-1.2691519f,10.944279f,11.62033f,86.08862f,-0.80099666f,-14.148265f,-67.41239f ) ;
  }

  @Test
  public void test348() {
    color.laplace.solve(32.978752f,87.38061f,-42.349632f,-55.465595f,-50.0482f,0f,-29.549864f,-62.73386f,26.88197f ) ;
  }

  @Test
  public void test349() {
    color.laplace.solve(33.027466f,43.61991f,34.631466f,-11.5100565f,6.820719f,-5.0940456f,-85.888405f,0.26706383f,-87.5813f ) ;
  }

  @Test
  public void test350() {
    color.laplace.solve(33.11188f,38.76815f,39.604515f,-5.466474f,-17.991781f,18.434675f,-32.41143f,-124.48889f,52.425945f ) ;
  }

  @Test
  public void test351() {
    color.laplace.solve(33.14262f,24.815382f,-100.0f,7.7551036f,7.1831636f,41.138752f,-9.30537f,-44.976585f,-100.0f ) ;
  }

  @Test
  public void test352() {
    color.laplace.solve(33.202995f,38.871227f,72.48101f,-6.059239f,-50.199104f,71.15661f,-7.240849f,-22.904158f,99.99999f ) ;
  }

  @Test
  public void test353() {
    color.laplace.solve(33.220295f,25.900879f,-27.178623f,6.9803f,-2.4381535f,-24.209726f,-2.8609416f,-18.424067f,-68.39717f ) ;
  }

  @Test
  public void test354() {
    color.laplace.solve(33.249043f,-64.638176f,0f,24.981441f,56.099888f,80.36238f,10.576834f,17.325895f,79.19402f ) ;
  }

  @Test
  public void test355() {
    color.laplace.solve(33.32477f,55.132343f,91.03427f,-21.833252f,-3.8296783f,-55.394638f,-10.413904f,-19.822367f,-65.04588f ) ;
  }

  @Test
  public void test356() {
    color.laplace.solve(33.357647f,30.641193f,7.298671f,2.789388f,-18.091545f,60.38417f,-4.108549f,-19.223583f,-45.19372f ) ;
  }

  @Test
  public void test357() {
    color.laplace.solve(33.413757f,42.70515f,40.085854f,-9.050117f,-2.6790168f,17.638271f,-66.93521f,-62.009373f,-99.99982f ) ;
  }

  @Test
  public void test358() {
    color.laplace.solve(33.42991f,27.19579f,-18.73543f,6.523839f,-5.911321f,-45.14815f,-1.4232305f,-12.216761f,-63.052452f ) ;
  }

  @Test
  public void test359() {
    color.laplace.solve(33.444046f,15.642996f,-97.00322f,18.13319f,19.741957f,-14.062187f,19.346754f,59.253826f,7.1154585f ) ;
  }

  @Test
  public void test360() {
    color.laplace.solve(33.47587f,29.564085f,3.9881463f,4.277918f,-18.23988f,-113.62916f,2.6480532f,7.2294984f,44.78011f ) ;
  }

  @Test
  public void test361() {
    color.laplace.solve(33.504974f,23.302238f,-47.285408f,10.717655f,6.2422976f,-10.826447f,3.1233494f,1.7757428f,-2.262676f ) ;
  }

  @Test
  public void test362() {
    color.laplace.solve(33.506584f,15.626733f,-99.999886f,18.3996f,29.00023f,56.007874f,11.091579f,25.966719f,-100.0f ) ;
  }

  @Test
  public void test363() {
    color.laplace.solve(33.507763f,24.972525f,-35.08958f,9.058533f,1.4719173f,-24.102648f,1.2544479f,-4.0407405f,40.546673f ) ;
  }

  @Test
  public void test364() {
    color.laplace.solve(33.519474f,31.640388f,9.263301f,2.4375067f,-18.946707f,-88.13626f,-4.822739f,-21.728462f,-63.144405f ) ;
  }

  @Test
  public void test365() {
    color.laplace.solve(33.594345f,23.825132f,-47.8687f,10.552242f,9.574882f,18.315413f,-0.9602544f,-14.39326f,-66.18767f ) ;
  }

  @Test
  public void test366() {
    color.laplace.solve(33.72462f,29.42519f,-5.2734337f,5.473294f,-10.750429f,-99.634605f,-1.0810164f,-9.797359f,-27.357992f ) ;
  }

  @Test
  public void test367() {
    color.laplace.solve(33.728924f,40.08586f,44.84175f,-5.1701612f,-35.115356f,0f,-85.92325f,0f,0f ) ;
  }

  @Test
  public void test368() {
    color.laplace.solve(33.731174f,24.817162f,-34.01148f,10.107532f,-0.45104623f,-55.221344f,7.1499987f,18.492464f,89.29934f ) ;
  }

  @Test
  public void test369() {
    color.laplace.solve(33.83335f,24.586157f,-42.21494f,10.747683f,6.4614267f,-9.530971f,3.2478485f,1.8346076f,-2.3708448f ) ;
  }

  @Test
  public void test370() {
    color.laplace.solve(33.8803f,24.704601f,-49.762127f,10.816597f,6.641917f,23.914248f,2.744238f,0.16035473f,-8.744673f ) ;
  }

  @Test
  public void test371() {
    color.laplace.solve(33.89811f,23.269194f,60.955795f,12.323244f,10.938847f,20.933126f,4.456021f,5.5008397f,6.6084914f ) ;
  }

  @Test
  public void test372() {
    color.laplace.solve(33.89854f,33.97464f,26.116955f,1.6195263f,-24.116934f,-29.506824f,-3.3035035f,-14.83354f,-31.913725f ) ;
  }

  @Test
  public void test373() {
    color.laplace.solve(33.901726f,23.056824f,-55.243603f,12.550078f,12.235743f,-9.674835f,4.0628448f,3.7013009f,-1.4933835f ) ;
  }

  @Test
  public void test374() {
    color.laplace.solve(33.93457f,34.333164f,5.84593f,1.4051104f,-10.729135f,-6.909727f,-17.584993f,-71.74509f,-22.755703f ) ;
  }

  @Test
  public void test375() {
    color.laplace.solve(33.998375f,24.220251f,-53.42915f,11.773248f,16.311779f,53.895527f,-3.2171643f,-24.641905f,-47.735676f ) ;
  }

  @Test
  public void test376() {
    color.laplace.solve(34.00936f,32.481087f,16.745512f,3.5563557f,-20.830526f,-99.99157f,1.0465894f,0.63000184f,22.303946f ) ;
  }

  @Test
  public void test377() {
    color.laplace.solve(3.402261f,19.365639f,0f,7.6873045f,13.031969f,0.14336823f,14.314987f,49.572643f,0f ) ;
  }

  @Test
  public void test378() {
    color.laplace.solve(34.044876f,49.620575f,52.59561f,-13.441066f,11.84181f,60.761875f,-99.650955f,-49.574142f,-100.0f ) ;
  }

  @Test
  public void test379() {
    color.laplace.solve(34.114086f,24.888227f,-71.62702f,11.568123f,10.800971f,12.885931f,1.3574319f,-6.138395f,-36.711983f ) ;
  }

  @Test
  public void test380() {
    color.laplace.solve(34.11638f,29.180956f,-9.453296f,7.2845597f,-7.9392595f,-5.9858212f,2.961119f,4.5599165f,23.217806f ) ;
  }

  @Test
  public void test381() {
    color.laplace.solve(34.258972f,36.65935f,31.496454f,0.37653968f,-19.118015f,-58.592213f,-13.6348f,-54.91574f,100.0f ) ;
  }

  @Test
  public void test382() {
    color.laplace.solve(34.32341f,38.681545f,40.473915f,-1.387911f,-20.071146f,-39.7505f,-19.803907f,-77.82771f,-100.0f ) ;
  }

  @Test
  public void test383() {
    color.laplace.solve(34.378822f,22.690819f,100.0f,14.825078f,19.055378f,30.066267f,5.866114f,8.639347f,9.635504f ) ;
  }

  @Test
  public void test384() {
    color.laplace.solve(34.498016f,34.647514f,19.90499f,3.3445466f,-15.812941f,-76.67172f,-5.3068895f,-24.572104f,-90.58464f ) ;
  }

  @Test
  public void test385() {
    color.laplace.solve(34.510048f,26.443789f,-37.02968f,11.596069f,8.30767f,-7.481091f,3.5664413f,2.6696959f,-1.2028587f ) ;
  }

  @Test
  public void test386() {
    color.laplace.solve(34.51767f,30.900969f,100.0f,7.169709f,2.1645315f,9.770613f,-8.003364f,-39.183163f,-23.246609f ) ;
  }

  @Test
  public void test387() {
    color.laplace.solve(34.604095f,29.256319f,-22.97361f,9.160056f,5.394793f,-26.417177f,-3.358663f,-22.594707f,-92.41496f ) ;
  }

  @Test
  public void test388() {
    color.laplace.solve(34.63773f,58.21522f,92.719475f,-19.664354f,-100.0f,-49.561527f,-13.295149f,-33.51611f,-20.769283f ) ;
  }

  @Test
  public void test389() {
    color.laplace.solve(34.638958f,51.461773f,14.022818f,-12.905978f,57.185284f,-95.3705f,-1.0753454f,8.604597f,-21.691479f ) ;
  }

  @Test
  public void test390() {
    color.laplace.solve(34.642025f,24.946833f,-100.0f,13.621266f,21.814203f,0f,-8.658013f,-48.253323f,0f ) ;
  }

  @Test
  public void test391() {
    color.laplace.solve(34.67092f,16.242516f,-43.483948f,22.441162f,39.803596f,81.81133f,15.2901325f,38.719368f,99.783745f ) ;
  }

  @Test
  public void test392() {
    color.laplace.solve(34.69068f,32.32362f,0.90155053f,6.439108f,-6.297746f,-46.968586f,-2.636505f,-16.985128f,-59.00626f ) ;
  }

  @Test
  public void test393() {
    color.laplace.solve(34.693104f,35.24627f,20.575085f,3.5255337f,-14.283118f,-67.14795f,-6.3078513f,-28.756939f,-100.0f ) ;
  }

  @Test
  public void test394() {
    color.laplace.solve(34.70825f,43.224148f,73.368744f,-4.3911586f,-35.18041f,-63.97919f,-17.092474f,-100.0f,0f ) ;
  }

  @Test
  public void test395() {
    color.laplace.solve(34.72979f,-40.75369f,4.2196627f,9.276218f,-2.6015396f,10.441035f,4.9766235f,10.630276f,40.14602f ) ;
  }

  @Test
  public void test396() {
    color.laplace.solve(34.73793f,37.057453f,14.672332f,1.8942622f,-1.1804488f,-2.19763f,-25.98043f,-41.47588f,-22.282404f ) ;
  }

  @Test
  public void test397() {
    color.laplace.solve(34.754738f,35.79558f,21.735498f,3.2233741f,-13.307908f,-54.813877f,-8.553334f,-37.43671f,-13.173655f ) ;
  }

  @Test
  public void test398() {
    color.laplace.solve(34.780724f,39.86125f,37.674118f,-0.73835784f,-12.527199f,10.83521f,-25.184587f,-100.0f,18.181698f ) ;
  }

  @Test
  public void test399() {
    color.laplace.solve(34.839962f,24.123234f,-60.475418f,15.236619f,16.241545f,31.238657f,9.86497f,-5.632336f,23.602251f ) ;
  }

  @Test
  public void test400() {
    color.laplace.solve(34.898067f,30.357235f,50.365097f,9.235037f,-63.83422f,49.81825f,-1.196305f,-14.020257f,8.949498f ) ;
  }

  @Test
  public void test401() {
    color.laplace.solve(34.903908f,21.435427f,96.33988f,18.180206f,29.683285f,64.16963f,8.135632f,14.362319f,19.632988f ) ;
  }

  @Test
  public void test402() {
    color.laplace.solve(34.971447f,18.577724f,-6.7308264f,21.308067f,36.679512f,73.81508f,13.58131f,33.017174f,-14.124337f ) ;
  }

  @Test
  public void test403() {
    color.laplace.solve(-34.98715f,-29.050728f,-100.0f,-14.606497f,-17.831347f,-19.844677f,-5.6074953f,-7.8234844f,38.45264f ) ;
  }

  @Test
  public void test404() {
    color.laplace.solve(-34.99877f,-71.96449f,0f,-18.06745f,13.47147f,-35.78378f,-50.742496f,69.45667f,0f ) ;
  }

  @Test
  public void test405() {
    color.laplace.solve(35.01176f,42.656986f,-73.69506f,-3.1552086f,-42.292866f,-198.89084f,-5.334732f,-10.691359f,5.1189613f ) ;
  }

  @Test
  public void test406() {
    color.laplace.solve(35.03888f,25.80329f,-46.083233f,14.35223f,14.25751f,-1.223376f,8.112532f,18.097897f,26.93222f ) ;
  }

  @Test
  public void test407() {
    color.laplace.solve(35.043972f,44.09361f,26.818274f,-3.9177213f,14.512188f,-36.820515f,-65.22704f,100.0f,0f ) ;
  }

  @Test
  public void test408() {
    color.laplace.solve(35.053646f,-29.984829f,-71.295456f,70.19941f,8.77906f,0f,12.447658f,-20.408781f,-13.238039f ) ;
  }

  @Test
  public void test409() {
    color.laplace.solve(35.072384f,34.806007f,16.09926f,5.4835224f,-11.947485f,-77.8285f,-1.1918626f,-10.250973f,-27.86454f ) ;
  }

  @Test
  public void test410() {
    color.laplace.solve(35.07515f,26.938812f,-40.643105f,13.361783f,10.667038f,-15.090435f,7.704944f,17.457994f,-30.385677f ) ;
  }

  @Test
  public void test411() {
    color.laplace.solve(35.122204f,35.49416f,0f,4.1956735f,-30.746937f,-70.09983f,12.407428f,-49.485855f,0f ) ;
  }

  @Test
  public void test412() {
    color.laplace.solve(35.167534f,27.24858f,-38.90366f,13.408228f,12.544262f,-0.854401f,5.9571877f,10.437161f,22.941793f ) ;
  }

  @Test
  public void test413() {
    color.laplace.solve(35.174583f,43.088226f,8.2552805f,-2.389897f,-45.547775f,65.469124f,0.81360614f,5.644322f,-23.378658f ) ;
  }

  @Test
  public void test414() {
    color.laplace.solve(35.179108f,27.681799f,0f,13.034627f,-8.369658f,0f,-9.760814f,-52.07788f,4.4573774f ) ;
  }

  @Test
  public void test415() {
    color.laplace.solve(35.18953f,24.983988f,-7.1181774f,15.774129f,22.662035f,-33.477856f,5.244951f,5.2056746f,-7.084288f ) ;
  }

  @Test
  public void test416() {
    color.laplace.solve(35.207325f,30.85118f,-14.640655f,9.978331f,2.838768f,-26.965164f,1.8672314f,-2.5090585f,6.1362085f ) ;
  }

  @Test
  public void test417() {
    color.laplace.solve(35.229595f,32.869156f,1.637443f,8.049224f,-5.3904076f,66.1812f,2.3577065f,1.3816029f,8.559113f ) ;
  }

  @Test
  public void test418() {
    color.laplace.solve(35.243965f,31.109875f,42.724297f,9.865989f,7.739742f,13.928106f,-3.5197535f,-23.945004f,-100.0f ) ;
  }

  @Test
  public void test419() {
    color.laplace.solve(35.2914f,2.2828188f,0f,14.74714f,16.877346f,93.19298f,6.819812f,12.532107f,26.431273f ) ;
  }

  @Test
  public void test420() {
    color.laplace.solve(35.30438f,36.08387f,13.192358f,5.133639f,-4.160981f,-10.29358f,-10.608554f,-47.567852f,-100.0f ) ;
  }

  @Test
  public void test421() {
    color.laplace.solve(35.33438f,36.742958f,28.163658f,4.5945625f,-16.526209f,-26.889284f,-0.42992264f,-6.3142533f,-8.300884f ) ;
  }

  @Test
  public void test422() {
    color.laplace.solve(35.338272f,34.131145f,10.8565235f,7.221942f,-9.67021f,-90.705055f,3.219706f,5.6568823f,29.078033f ) ;
  }

  @Test
  public void test423() {
    color.laplace.solve(35.383038f,26.153246f,-45.17463f,15.378906f,14.404575f,99.96194f,11.728012f,31.533144f,99.999985f ) ;
  }

  @Test
  public void test424() {
    color.laplace.solve(35.410885f,62.83697f,65.61685f,-21.193436f,50.32014f,99.62272f,-0.3035403f,19.979275f,29.900497f ) ;
  }

  @Test
  public void test425() {
    color.laplace.solve(35.414635f,35.04046f,14.4789f,6.618084f,-9.7317f,-77.124855f,0.7893996f,-3.4604852f,-99.99769f ) ;
  }

  @Test
  public void test426() {
    color.laplace.solve(35.442043f,33.17288f,-5.354072f,8.595298f,2.6035428f,-8.101122f,-3.6643965f,-23.252884f,-29.653957f ) ;
  }

  @Test
  public void test427() {
    color.laplace.solve(35.472797f,37.585842f,24.33024f,4.305322f,-9.460747f,-40.264877f,-8.790986f,-39.46927f,80.13338f ) ;
  }

  @Test
  public void test428() {
    color.laplace.solve(35.503777f,37.976196f,-29.807032f,4.0389023f,46.208042f,-19.040998f,-0.19629568f,-4.824085f,-65.30809f ) ;
  }

  @Test
  public void test429() {
    color.laplace.solve(35.519676f,39.87f,33.684326f,1.861126f,-9.684609f,-5.0897017f,-18.38486f,-75.400566f,30.674335f ) ;
  }

  @Test
  public void test430() {
    color.laplace.solve(35.57331f,36.41354f,23.603523f,5.8943877f,-6.6672716f,-41.99954f,-5.253681f,-26.84028f,-184.82487f ) ;
  }

  @Test
  public void test431() {
    color.laplace.solve(35.602154f,37.218967f,22.016449f,5.2219906f,-8.781483f,-49.153168f,-5.884669f,-28.666538f,-100.0f ) ;
  }

  @Test
  public void test432() {
    color.laplace.solve(35.621124f,28.517494f,-42.45689f,13.966998f,17.308332f,28.961687f,2.9385366f,-2.2128513f,-100.0f ) ;
  }

  @Test
  public void test433() {
    color.laplace.solve(35.665974f,30.476166f,-21.146673f,12.187733f,7.385359f,-7.397299f,5.700868f,10.6159315f,29.37745f ) ;
  }

  @Test
  public void test434() {
    color.laplace.solve(35.674988f,37.62256f,26.030941f,5.0773854f,-11.215687f,-65.88628f,-4.1497583f,-21.676418f,-47.904213f ) ;
  }

  @Test
  public void test435() {
    color.laplace.solve(-35.727684f,21.634853f,0f,-15.029263f,-11.200229f,40.323235f,-13.189138f,-37.72729f,-55.927532f ) ;
  }

  @Test
  public void test436() {
    color.laplace.solve(35.729477f,61.90329f,-46.88627f,-18.985386f,-82.26005f,3.5964243f,-29.410967f,-98.658485f,30.44225f ) ;
  }

  @Test
  public void test437() {
    color.laplace.solve(35.7305f,34.98144f,13.17139f,7.9405565f,-8.976121f,-91.226875f,5.0078483f,12.090837f,52.33162f ) ;
  }

  @Test
  public void test438() {
    color.laplace.solve(35.736042f,31.15898f,-20.528645f,11.870674f,9.44501f,-2.5648654f,2.307977f,-2.6387658f,-22.316084f ) ;
  }

  @Test
  public void test439() {
    color.laplace.solve(35.739048f,11.833697f,-108.19414f,31.11725f,19.784414f,-160.14568f,68.94441f,-48.784664f,0f ) ;
  }

  @Test
  public void test440() {
    color.laplace.solve(35.817043f,41.890324f,41.997025f,1.3811272f,-10.250808f,-2.7266324f,-20.041725f,-81.5448f,-42.660103f ) ;
  }

  @Test
  public void test441() {
    color.laplace.solve(35.83607f,35.46374f,13.93835f,7.8963156f,-7.513163f,-79.71034f,3.5524313f,6.3134103f,29.175661f ) ;
  }

  @Test
  public void test442() {
    color.laplace.solve(35.883324f,37.13661f,-114.23414f,6.4043694f,-4.5360775f,-32.943092f,-5.5843287f,-28.73983f,-104.76746f ) ;
  }

  @Test
  public void test443() {
    color.laplace.solve(35.89243f,36.979618f,19.524073f,6.589883f,-7.498131f,-58.8819f,-2.0347657f,-14.728982f,-49.38303f ) ;
  }

  @Test
  public void test444() {
    color.laplace.solve(35.923767f,35.848873f,34.404514f,8.186977f,-23.681677f,0.6293911f,21.264318f,-139.35483f,-128.00307f ) ;
  }

  @Test
  public void test445() {
    color.laplace.solve(36.001087f,40.037735f,30.96192f,3.9667058f,-6.812067f,-16.190132f,-13.322197f,-55.062717f,-100.0f ) ;
  }

  @Test
  public void test446() {
    color.laplace.solve(36.024784f,42.2998f,57.675766f,1.799329f,-24.50134f,88.40326f,-6.424187f,-27.496077f,-79.058784f ) ;
  }

  @Test
  public void test447() {
    color.laplace.solve(36.077507f,28.36102f,-28.020796f,15.949007f,18.742582f,10.705561f,8.975938f,19.954744f,52.100456f ) ;
  }

  @Test
  public void test448() {
    color.laplace.solve(36.118324f,35.510998f,14.078892f,8.962215f,-8.15322f,-99.658966f,7.8837576f,22.572866f,91.09925f ) ;
  }

  @Test
  public void test449() {
    color.laplace.solve(36.143456f,38.633698f,32.130257f,5.9401207f,-13.7389145f,-99.78303f,1.3559414f,-0.51635504f,10.317553f ) ;
  }

  @Test
  public void test450() {
    color.laplace.solve(36.16181f,43.721626f,51.235077f,1.6732931f,-9.028658f,65.091995f,-21.34501f,-146.29883f,45.424973f ) ;
  }

  @Test
  public void test451() {
    color.laplace.solve(36.200363f,26.087666f,-40.348503f,18.713785f,36.253113f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test452() {
    color.laplace.solve(36.26658f,23.405678f,-53.263645f,21.660635f,64.204384f,0f,5.4138026f,-0.0054239673f,-69.63988f ) ;
  }

  @Test
  public void test453() {
    color.laplace.solve(36.313084f,41.772724f,37.74055f,3.4796107f,-6.9627314f,7.7768245f,-15.4319105f,-80.88009f,0.32947722f ) ;
  }

  @Test
  public void test454() {
    color.laplace.solve(36.408028f,44.936214f,36.066154f,0.6958966f,7.2706804f,-0.764622f,-40.895123f,-15.784769f,-46.39532f ) ;
  }

  @Test
  public void test455() {
    color.laplace.solve(36.470978f,40.061558f,28.2865f,6.023385f,-4.486388f,-27.450294f,-7.918633f,-36.538074f,-133.66696f ) ;
  }

  @Test
  public void test456() {
    color.laplace.solve(36.472527f,31.181385f,-47.417793f,14.708724f,34.098427f,100.0f,-11.736059f,-61.65296f,0f ) ;
  }

  @Test
  public void test457() {
    color.laplace.solve(36.524014f,39.480495f,30.626883f,6.6155605f,-9.228914f,-73.06472f,-0.8328572f,-9.94699f,-34.560825f ) ;
  }

  @Test
  public void test458() {
    color.laplace.solve(36.55413f,67.59191f,-63.63544f,15.895533f,22.813116f,6.8010173f,4.214884f,0.96400326f,-23.171988f ) ;
  }

  @Test
  public void test459() {
    color.laplace.solve(36.568996f,32.23359f,-50.605595f,14.042391f,13.412738f,-3.3339605f,6.1878304f,10.708931f,23.857012f ) ;
  }

  @Test
  public void test460() {
    color.laplace.solve(36.572655f,46.828377f,64.34176f,-0.5377636f,-13.600897f,-0.7407197f,-25.12281f,-99.95348f,-53.70374f ) ;
  }

  @Test
  public void test461() {
    color.laplace.solve(36.60703f,34.4597f,-7.7623115f,11.968417f,8.994087f,-23.576342f,2.272551f,-2.8782132f,-22.77949f ) ;
  }

  @Test
  public void test462() {
    color.laplace.solve(36.610943f,38.296486f,31.650042f,8.147289f,-15.075035f,-31.508638f,11.053248f,-75.235275f,72.21199f ) ;
  }

  @Test
  public void test463() {
    color.laplace.solve(36.655453f,30.917171f,-93.89096f,15.704645f,20.696373f,-12.216922f,5.4667544f,6.162372f,-1.5136375f ) ;
  }

  @Test
  public void test464() {
    color.laplace.solve(36.660095f,55.552567f,59.472927f,-8.912185f,26.077242f,27.494854f,-98.38608f,30.173729f,20.372398f ) ;
  }

  @Test
  public void test465() {
    color.laplace.solve(36.67565f,57.07461f,-52.63485f,-10.372013f,0.2786204f,22.8262f,-7.4306417f,-19.350554f,-70.2502f ) ;
  }

  @Test
  public void test466() {
    color.laplace.solve(36.727886f,35.90392f,-53.358013f,11.007622f,1.8219041f,-75.90528f,5.480697f,10.915167f,36.358063f ) ;
  }

  @Test
  public void test467() {
    color.laplace.solve(36.734047f,39.360687f,27.431618f,7.587583f,-6.7229147f,-67.63985f,0.33920047f,-6.214456f,-18.463552f ) ;
  }

  @Test
  public void test468() {
    color.laplace.solve(36.74487f,39.75765f,26.520323f,7.221828f,-4.2345996f,-34.260242f,-3.6229575f,-21.713657f,-10.975273f ) ;
  }

  @Test
  public void test469() {
    color.laplace.solve(36.76178f,38.16163f,19.77986f,8.885492f,-3.1936128f,-59.04219f,2.1132276f,-0.27606624f,-0.023879796f ) ;
  }

  @Test
  public void test470() {
    color.laplace.solve(36.762383f,37.527813f,16.791098f,9.5217085f,-3.4422235f,-70.36342f,4.7666783f,9.545005f,-100.0f ) ;
  }

  @Test
  public void test471() {
    color.laplace.solve(36.767086f,36.679337f,-14.712424f,10.389003f,24.662687f,45.78764f,-19.873762f,5.7947707f,-43.81494f ) ;
  }

  @Test
  public void test472() {
    color.laplace.solve(36.77834f,38.83906f,29.447664f,8.274267f,-10.869753f,-21.048403f,0.13909268f,-7.717897f,-20.140924f ) ;
  }

  @Test
  public void test473() {
    color.laplace.solve(36.798767f,84.11169f,23.39494f,-36.91662f,-94.96582f,0f,-17.900082f,-34.68371f,-86.60956f ) ;
  }

  @Test
  public void test474() {
    color.laplace.solve(36.81434f,15.272222f,-92.70172f,31.985132f,16.976269f,6.068637f,74.14992f,14.579082f,100.0f ) ;
  }

  @Test
  public void test475() {
    color.laplace.solve(36.821587f,41.69075f,37.56112f,5.592085f,-7.6215787f,-44.783123f,-6.8333187f,-32.93857f,-378.37976f ) ;
  }

  @Test
  public void test476() {
    color.laplace.solve(36.96705f,40.709976f,35.4598f,7.1582184f,-9.586938f,1.1292244f,1.2527634f,-2.147165f,-0.25448513f ) ;
  }

  @Test
  public void test477() {
    color.laplace.solve(37.024067f,42.428192f,34.909725f,5.66807f,-2.2210295f,-2.7892845f,-12.130756f,-54.191093f,-96.96111f ) ;
  }

  @Test
  public void test478() {
    color.laplace.solve(37.029343f,18.785439f,25.944221f,29.331936f,-87.83181f,-15.008555f,-14.08709f,-85.6803f,81.10734f ) ;
  }

  @Test
  public void test479() {
    color.laplace.solve(-37.067196f,5.0966363f,0f,-22.690786f,-41.532387f,87.85632f,-12.163559f,-25.963451f,-54.600754f ) ;
  }

  @Test
  public void test480() {
    color.laplace.solve(37.069668f,44.82168f,59.06078f,7.0776367f,-16.466627f,-143.17688f,7.7972894f,24.849371f,-4.5322804f ) ;
  }

  @Test
  public void test481() {
    color.laplace.solve(37.08277f,-60.594822f,0f,6.7743325f,-10.342754f,-65.92424f,0.3573113f,-5.345087f,-11.394905f ) ;
  }

  @Test
  public void test482() {
    color.laplace.solve(37.08639f,42.193855f,40.075546f,6.1517167f,-8.386523f,18.108335f,-4.0930023f,-100.0f,0f ) ;
  }

  @Test
  public void test483() {
    color.laplace.solve(37.11826f,41.466072f,-91.9996f,7.0069675f,5.0146065f,35.012337f,-14.104996f,-63.426952f,100.0f ) ;
  }

  @Test
  public void test484() {
    color.laplace.solve(37.16039f,50.753445f,55.819252f,-2.1118848f,10.034132f,38.573067f,-55.64206f,-47.0781f,65.65216f ) ;
  }

  @Test
  public void test485() {
    color.laplace.solve(-37.24154f,-74.1127f,0f,-6.320417f,99.78701f,0f,-21.742252f,0f,0f ) ;
  }

  @Test
  public void test486() {
    color.laplace.solve(37.246616f,37.445927f,1.1281214f,11.540547f,11.408962f,18.163485f,-2.4933903f,-21.514109f,60.11685f ) ;
  }

  @Test
  public void test487() {
    color.laplace.solve(37.454437f,38.888065f,13.525392f,10.929973f,4.5724506f,-86.752594f,1.704584f,-4.111637f,-22.715721f ) ;
  }

  @Test
  public void test488() {
    color.laplace.solve(37.467857f,34.877995f,-14.193516f,14.993429f,16.234373f,4.9735374f,6.27149f,10.09253f,17.853292f ) ;
  }

  @Test
  public void test489() {
    color.laplace.solve(37.468575f,20.944078f,-94.78089f,28.930225f,41.08863f,-74.07048f,37.163692f,60.994064f,0f ) ;
  }

  @Test
  public void test490() {
    color.laplace.solve(37.495346f,47.79955f,-9.35404f,2.1818368f,-31.569902f,0f,2.8019037f,1.1851885f,0f ) ;
  }

  @Test
  public void test491() {
    color.laplace.solve(37.510204f,-66.221504f,0f,22.973331f,42.10976f,58.973648f,12.273366f,26.12013f,50.097397f ) ;
  }

  @Test
  public void test492() {
    color.laplace.solve(37.60791f,37.296543f,-1.9273652f,13.135187f,13.505684f,0.39945993f,1.4273095f,3.1915443f,-9.9804125f ) ;
  }

  @Test
  public void test493() {
    color.laplace.solve(37.628044f,40.552444f,24.186937f,9.959727f,1.1753384f,-43.65591f,1.7340122f,-2.1729832f,-10.223612f ) ;
  }

  @Test
  public void test494() {
    color.laplace.solve(37.642563f,-199.84256f,0f,-13.617923f,-98.31857f,0f,-17.712593f,-57.232452f,-112.91349f ) ;
  }

  @Test
  public void test495() {
    color.laplace.solve(37.64821f,42.833454f,40.600323f,7.7593727f,-6.9147077f,-71.70825f,0.3039912f,-6.543408f,-19.562914f ) ;
  }

  @Test
  public void test496() {
    color.laplace.solve(37.713253f,38.819565f,17.900553f,12.0377f,1.9107465f,-67.17793f,8.976679f,23.963652f,85.13422f ) ;
  }

  @Test
  public void test497() {
    color.laplace.solve(37.72749f,28.11479f,35.82196f,22.795172f,-61.090294f,15.173056f,1.0526431f,-18.5846f,-14.300749f ) ;
  }

  @Test
  public void test498() {
    color.laplace.solve(37.760185f,38.307243f,9.764373f,12.733531f,5.7043805f,-99.24975f,7.469557f,17.144665f,55.404716f ) ;
  }

  @Test
  public void test499() {
    color.laplace.solve(37.77619f,45.55454f,22.055561f,5.550229f,22.386408f,-57.82458f,-37.96168f,96.26544f,-12.516681f ) ;
  }

  @Test
  public void test500() {
    color.laplace.solve(37.78202f,44.50415f,23.927183f,6.623935f,16.307394f,-48.795414f,-27.593674f,62.8969f,-56.70051f ) ;
  }

  @Test
  public void test501() {
    color.laplace.solve(-37.798405f,28.564182f,0f,-4.8467007f,19.320263f,0f,0.40284973f,42.934155f,0f ) ;
  }

  @Test
  public void test502() {
    color.laplace.solve(37.818226f,30.02571f,-52.30517f,21.247196f,34.58978f,54.035767f,12.580779f,61.797585f,0f ) ;
  }

  @Test
  public void test503() {
    color.laplace.solve(37.85005f,37.933086f,4.7318053f,13.467126f,2.360098f,-83.126114f,13.658354f,41.16629f,7.1016893f ) ;
  }

  @Test
  public void test504() {
    color.laplace.solve(37.853416f,37.014793f,-4.6252813f,14.39887f,14.710143f,3.0041533f,4.7593665f,4.704589f,1.9296812f ) ;
  }

  @Test
  public void test505() {
    color.laplace.solve(37.860172f,40.418354f,22.132435f,11.022337f,1.6808054f,-51.888615f,4.548371f,7.171146f,96.25754f ) ;
  }

  @Test
  public void test506() {
    color.laplace.solve(37.929928f,34.474613f,14.935595f,17.245096f,-14.96702f,-34.258644f,2.9383879f,-5.4915447f,-9.937548f ) ;
  }

  @Test
  public void test507() {
    color.laplace.solve(37.939346f,23.940615f,-76.27449f,27.816776f,34.097603f,-58.64187f,39.230152f,62.09081f,0f ) ;
  }

  @Test
  public void test508() {
    color.laplace.solve(37.992744f,67.61941f,32.672844f,-15.648437f,99.81204f,-37.460293f,52.878613f,0f,0f ) ;
  }

  @Test
  public void test509() {
    color.laplace.solve(38.02151f,47.63128f,50.952488f,4.4547663f,-3.753809f,3.1480308f,-16.448637f,-70.24931f,-34.606556f ) ;
  }

  @Test
  public void test510() {
    color.laplace.solve(38.056892f,22.282003f,-51.068287f,29.945559f,46.358856f,45.73671f,35.36649f,87.47116f,-6.5485125f ) ;
  }

  @Test
  public void test511() {
    color.laplace.solve(38.07689f,40.926514f,27.610483f,11.381037f,-1.9813206f,-44.006866f,9.428581f,26.333288f,97.88589f ) ;
  }

  @Test
  public void test512() {
    color.laplace.solve(38.097317f,47.898956f,73.910995f,4.490311f,-20.412481f,44.86944f,0.27640885f,-3.3846757f,6.5973706f ) ;
  }

  @Test
  public void test513() {
    color.laplace.solve(38.117676f,35.787567f,-14.662057f,16.683239f,19.694416f,7.3066382f,8.920865f,19.000532f,24.194193f ) ;
  }

  @Test
  public void test514() {
    color.laplace.solve(38.138687f,46.006f,58.60571f,6.549091f,-12.720395f,-100.0f,0.77884734f,-3.4337566f,-1.7935169f ) ;
  }

  @Test
  public void test515() {
    color.laplace.solve(38.1502f,42.110382f,28.581526f,10.491198f,1.7100674f,-43.59625f,2.104803f,-1.8891177f,-11.371342f ) ;
  }

  @Test
  public void test516() {
    color.laplace.solve(38.155415f,34.729618f,10.229787f,17.892046f,-60.41822f,0f,3.3358953f,-4.5484657f,16.90093f ) ;
  }

  @Test
  public void test517() {
    color.laplace.solve(38.16217f,40.720585f,21.628733f,11.928899f,3.0912018f,-54.204662f,6.462221f,13.919149f,76.00389f ) ;
  }

  @Test
  public void test518() {
    color.laplace.solve(38.178154f,42.26354f,93.390015f,10.449077f,18.727034f,36.466217f,-15.108882f,-14.270698f,33.74782f ) ;
  }

  @Test
  public void test519() {
    color.laplace.solve(38.210606f,46.312916f,61.506165f,6.529503f,-14.465108f,99.71174f,2.3725152f,2.9605577f,23.934824f ) ;
  }

  @Test
  public void test520() {
    color.laplace.solve(38.224987f,43.299774f,32.132053f,9.600171f,2.842035f,-14.771555f,-2.6661408f,-20.26481f,-81.23514f ) ;
  }

  @Test
  public void test521() {
    color.laplace.solve(38.23789f,62.021717f,85.95417f,-9.070165f,23.894812f,33.984543f,-0.11586921f,8.606688f,10.647808f ) ;
  }

  @Test
  public void test522() {
    color.laplace.solve(-38.259884f,-44.92432f,0f,-2.3014648f,26.956026f,44.185894f,2.0980003f,10.693466f,13.71984f ) ;
  }

  @Test
  public void test523() {
    color.laplace.solve(38.28646f,42.586967f,24.308586f,10.55887f,7.7528224f,-45.352623f,-3.8038006f,-25.774073f,0f ) ;
  }

  @Test
  public void test524() {
    color.laplace.solve(38.309635f,33.35049f,-72.42391f,19.888052f,40.948322f,13.3260565f,0.29425183f,97.22869f,84.77981f ) ;
  }

  @Test
  public void test525() {
    color.laplace.solve(38.312588f,41.34025f,23.295565f,11.910102f,3.7528453f,-48.62877f,5.574975f,10.389798f,32.231373f ) ;
  }

  @Test
  public void test526() {
    color.laplace.solve(38.322235f,46.278385f,45.20153f,7.0105596f,1.589773f,7.5597906f,-11.869771f,-54.489643f,-16.552141f ) ;
  }

  @Test
  public void test527() {
    color.laplace.solve(38.377907f,42.227272f,26.433758f,11.284743f,4.0974646f,-36.49229f,2.6635993f,-0.62996334f,-9.28051f ) ;
  }

  @Test
  public void test528() {
    color.laplace.solve(38.42568f,47.923496f,54.54719f,5.7792144f,-1.2788782f,3.0807617f,-14.029943f,-61.898987f,-100.0f ) ;
  }

  @Test
  public void test529() {
    color.laplace.solve(38.42577f,40.305225f,11.23074f,13.397862f,11.5643835f,-95.38226f,3.601296f,1.0073208f,100.0f ) ;
  }

  @Test
  public void test530() {
    color.laplace.solve(38.45701f,42.5675f,35.39761f,11.260539f,-3.584613f,-97.58499f,10.16976f,29.4185f,-79.88228f ) ;
  }

  @Test
  public void test531() {
    color.laplace.solve(38.46116f,37.56958f,18.982008f,16.275183f,-7.1643357f,-61.64155f,33.803925f,-20.86056f,-15.622236f ) ;
  }

  @Test
  public void test532() {
    color.laplace.solve(38.514805f,28.333448f,-100.0f,25.725775f,33.003323f,-21.860037f,31.38497f,99.8141f,99.99952f ) ;
  }

  @Test
  public void test533() {
    color.laplace.solve(-38.55414f,-69.6874f,13.878377f,-13.518394f,-17.447788f,48.064255f,1.9283482f,-34.649616f,40.210384f ) ;
  }

  @Test
  public void test534() {
    color.laplace.solve(38.5547f,39.9935f,33.931484f,14.2253f,-12.512187f,-4.267557f,30.858685f,-99.99999f,-38.48953f ) ;
  }

  @Test
  public void test535() {
    color.laplace.solve(38.55998f,48.73353f,29.342646f,5.5063863f,27.03144f,-31.3629f,-43.565876f,85.24874f,-8.139415f ) ;
  }

  @Test
  public void test536() {
    color.laplace.solve(38.598373f,46.442898f,54.24055f,7.9505806f,-7.067337f,-75.79739f,0.27128533f,-6.8654394f,-20.665709f ) ;
  }

  @Test
  public void test537() {
    color.laplace.solve(38.603966f,32.952f,-39.4783f,21.463865f,32.682327f,-100.0f,14.569165f,36.812798f,99.999695f ) ;
  }

  @Test
  public void test538() {
    color.laplace.solve(38.64161f,30.228598f,-42.855892f,16.59695f,18.548983f,7.1786094f,9.197208f,20.191881f,53.021347f ) ;
  }

  @Test
  public void test539() {
    color.laplace.solve(38.644524f,-93.49627f,-9.313316f,2.420262f,-27.464832f,-10.368495f,-1.498641f,-8.414826f,-4.6958303f ) ;
  }

  @Test
  public void test540() {
    color.laplace.solve(38.671597f,42.71651f,26.72748f,11.969876f,5.4669714f,-35.806595f,3.7409375f,2.9938738f,-54.553127f ) ;
  }

  @Test
  public void test541() {
    color.laplace.solve(38.68f,45.32385f,46.59851f,9.423994f,-3.9786677f,41.07019f,2.9950745f,2.47627f,10.888673f ) ;
  }

  @Test
  public void test542() {
    color.laplace.solve(38.78452f,38.252953f,10.289237f,16.885118f,3.938055f,-97.09601f,24.8179f,57.710155f,-93.401405f ) ;
  }

  @Test
  public void test543() {
    color.laplace.solve(38.787025f,54.857292f,-62.548428f,0.29080218f,36.67384f,63.741f,-74.29765f,19.281303f,0f ) ;
  }

  @Test
  public void test544() {
    color.laplace.solve(38.795135f,37.020744f,-14.993318f,18.159798f,23.608854f,16.473871f,10.2352f,22.781f,57.27995f ) ;
  }

  @Test
  public void test545() {
    color.laplace.solve(38.814564f,15.46085f,-94.33398f,11.4213915f,3.7400072f,-13.024813f,3.130998f,1.1025996f,-2.4606066f ) ;
  }

  @Test
  public void test546() {
    color.laplace.solve(3.8822055f,143.30147f,-32.453754f,13.647114f,43.71058f,4.028996f,6.9955816f,13.864769f,4.859113f ) ;
  }

  @Test
  public void test547() {
    color.laplace.solve(-38.82763f,160.33066f,4.6951957f,6.7675066f,55.336823f,17.774887f,10.334091f,34.56886f,11.176932f ) ;
  }

  @Test
  public void test548() {
    color.laplace.solve(38.840504f,45.6112f,37.34862f,9.750809f,6.2556763f,3.783286f,-6.092945f,-34.12259f,-20.41425f ) ;
  }

  @Test
  public void test549() {
    color.laplace.solve(38.857067f,47.071526f,57.91385f,8.329147f,-8.484811f,-92.22634f,2.804533f,2.8864255f,17.225973f ) ;
  }

  @Test
  public void test550() {
    color.laplace.solve(38.894623f,46.69174f,10.744545f,8.88675f,31.732307f,-10.283568f,-35.079926f,81.63431f,23.77515f ) ;
  }

  @Test
  public void test551() {
    color.laplace.solve(38.94491f,51.283173f,-23.219336f,4.4964614f,2.833254f,55.55336f,-23.792316f,-99.99998f,1.1227564f ) ;
  }

  @Test
  public void test552() {
    color.laplace.solve(39.012802f,44.96227f,33.776543f,11.088931f,7.059735f,-9.856095f,-1.7168089f,-17.956167f,-77.167595f ) ;
  }

  @Test
  public void test553() {
    color.laplace.solve(39.026165f,42.106445f,17.505259f,13.998213f,11.894362f,-72.08541f,5.0723233f,6.2910814f,8.197639f ) ;
  }

  @Test
  public void test554() {
    color.laplace.solve(-39.076607f,50.44189f,-9.745091f,-12.3167305f,11.137896f,79.42253f,-21.328209f,-72.99611f,-55.609917f ) ;
  }

  @Test
  public void test555() {
    color.laplace.solve(39.159466f,37.585197f,-21.031752f,19.052658f,32.213078f,-61.306145f,6.309572f,6.185631f,-13.7801285f ) ;
  }

  @Test
  public void test556() {
    color.laplace.solve(39.19696f,46.15856f,37.801098f,10.629283f,7.6361823f,1.6502178f,-4.3160124f,-27.893333f,-73.41354f ) ;
  }

  @Test
  public void test557() {
    color.laplace.solve(39.281902f,40.960995f,28.756025f,16.166609f,-4.1939487f,-43.636646f,29.578485f,-30.26675f,25.79993f ) ;
  }

  @Test
  public void test558() {
    color.laplace.solve(39.379986f,40.13874f,27.721596f,17.381197f,-6.5466113f,4.632509f,36.691414f,-88.3389f,-2.6449466f ) ;
  }

  @Test
  public void test559() {
    color.laplace.solve(3.9388592f,-54.83109f,-435.1937f,-29.122631f,-27.62514f,4.665734f,-90.96233f,-31.072071f,-94.49516f ) ;
  }

  @Test
  public void test560() {
    color.laplace.solve(39.44338f,47.19482f,40.69903f,10.578691f,8.636872f,15.601301f,-5.7654886f,-38.82732f,-0.87047404f ) ;
  }

  @Test
  public void test561() {
    color.laplace.solve(39.53318f,42.46964f,13.3574505f,15.66308f,16.987919f,-78.929634f,6.1312213f,8.861804f,0f ) ;
  }

  @Test
  public void test562() {
    color.laplace.solve(39.53363f,46.32371f,31.290878f,11.810814f,14.470331f,-21.160194f,23.415136f,0f,0f ) ;
  }

  @Test
  public void test563() {
    color.laplace.solve(39.542137f,42.884903f,34.421535f,15.283641f,-2.424065f,-34.050797f,24.016493f,80.78233f,0f ) ;
  }

  @Test
  public void test564() {
    color.laplace.solve(39.636627f,42.82568f,19.369127f,15.720833f,12.296956f,-65.34917f,10.949749f,28.078161f,89.06594f ) ;
  }

  @Test
  public void test565() {
    color.laplace.solve(39.667618f,39.516018f,51.62053f,19.154453f,30.154943f,-27.40247f,6.795252f,8.026554f,-4.843979f ) ;
  }

  @Test
  public void test566() {
    color.laplace.solve(39.674473f,43.729584f,18.389164f,14.968308f,16.854706f,-70.17293f,3.3440561f,-1.5920843f,-26.567099f ) ;
  }

  @Test
  public void test567() {
    color.laplace.solve(39.680317f,34.568424f,5.6342764f,24.152843f,-7.040903f,-73.14477f,63.97196f,-13.740107f,100.0f ) ;
  }

  @Test
  public void test568() {
    color.laplace.solve(39.68401f,40.084797f,-1.966848f,18.651249f,22.611708f,1.1199179f,12.310529f,30.590868f,-16.165203f ) ;
  }

  @Test
  public void test569() {
    color.laplace.solve(39.727383f,46.51421f,35.96311f,12.39533f,10.366338f,-2.9992502f,-0.5124019f,-14.444938f,-76.02206f ) ;
  }

  @Test
  public void test570() {
    color.laplace.solve(39.738495f,42.57115f,9.795215f,16.382826f,20.750902f,-99.9882f,5.041908f,3.784805f,-10.990662f ) ;
  }

  @Test
  public void test571() {
    color.laplace.solve(39.746696f,36.356476f,-76.329025f,22.63031f,66.42274f,18.49526f,-15.648194f,-85.22309f,64.26972f ) ;
  }

  @Test
  public void test572() {
    color.laplace.solve(-39.788254f,31.09579f,4.3146f,-7.991443f,8.577881f,6.2373385f,-0.7554012f,4.9698386f,12.056873f ) ;
  }

  @Test
  public void test573() {
    color.laplace.solve(39.790203f,46.66173f,30.776712f,12.499083f,16.080008f,45.254967f,-5.8738823f,-35.994614f,-24.816393f ) ;
  }

  @Test
  public void test574() {
    color.laplace.solve(39.79938f,46.1188f,36.395283f,13.078702f,11.614896f,-0.5647216f,0.8992964f,-9.403749f,-50.12919f ) ;
  }

  @Test
  public void test575() {
    color.laplace.solve(39.801155f,40.995945f,-73.95364f,16.241322f,19.22388f,12.138585f,5.9402485f,7.5196733f,4.9145646f ) ;
  }

  @Test
  public void test576() {
    color.laplace.solve(-39.842976f,98.69072f,0f,-1.4714705f,31.337015f,43.44846f,2.6200798f,11.951789f,13.850062f ) ;
  }

  @Test
  public void test577() {
    color.laplace.solve(-39.853012f,-68.90288f,62.042263f,-13.955093f,-13.719801f,23.013918f,-2.2475605f,4.9648514f,35.811893f ) ;
  }

  @Test
  public void test578() {
    color.laplace.solve(39.85826f,57.238422f,0.08748176f,2.1946242f,-22.803032f,-39.35874f,-8.2767315f,100.0f,0f ) ;
  }

  @Test
  public void test579() {
    color.laplace.solve(39.871513f,35.888622f,-41.475677f,23.597437f,31.90988f,0f,22.608355f,0f,0f ) ;
  }

  @Test
  public void test580() {
    color.laplace.solve(39.889477f,47.596737f,46.717415f,11.961178f,3.7800412f,39.272915f,4.175193f,4.7396035f,11.003131f ) ;
  }

  @Test
  public void test581() {
    color.laplace.solve(39.90876f,45.312687f,-73.52229f,14.322355f,13.638192f,-5.7297635f,3.7424643f,0.64748967f,-14.790697f ) ;
  }

  @Test
  public void test582() {
    color.laplace.solve(39.91607f,42.015556f,26.80317f,17.648727f,23.794336f,25.623787f,6.8845005f,9.889276f,8.878265f ) ;
  }

  @Test
  public void test583() {
    color.laplace.solve(39.979694f,43.66583f,-85.59656f,16.994558f,18.915813f,-4.333479f,9.082726f,19.336342f,49.346832f ) ;
  }

  @Test
  public void test584() {
    color.laplace.solve(40.100365f,46.05431f,29.390202f,14.347144f,14.726668f,2.6061912f,2.5615432f,-4.100974f,-33.69211f ) ;
  }

  @Test
  public void test585() {
    color.laplace.solve(40.121616f,46.082523f,31.403921f,14.403941f,12.804552f,-4.659913f,4.6895967f,4.3544455f,-0.07636676f ) ;
  }

  @Test
  public void test586() {
    color.laplace.solve(40.142467f,24.257484f,-48.219635f,36.312393f,5.1070986f,88.02731f,100.0f,2.2670243f,0f ) ;
  }

  @Test
  public void test587() {
    color.laplace.solve(40.186874f,47.558212f,37.50722f,13.189297f,12.538768f,2.4706743f,0.03154495f,-13.063117f,-95.010025f ) ;
  }

  @Test
  public void test588() {
    color.laplace.solve(40.22532f,44.744865f,26.295391f,16.156813f,12.458756f,-42.683575f,11.943174f,31.616669f,-60.581745f ) ;
  }

  @Test
  public void test589() {
    color.laplace.solve(40.398666f,46.206657f,28.80879f,15.388052f,15.619176f,-5.8674564f,5.534364f,6.7494507f,5.8442626f ) ;
  }

  @Test
  public void test590() {
    color.laplace.solve(40.434006f,49.33125f,21.243395f,12.404768f,5.974962f,-38.271816f,3.2101038f,0.4356474f,-7.4424763f ) ;
  }

  @Test
  public void test591() {
    color.laplace.solve(40.447372f,56.364746f,35.48525f,5.4287477f,-16.88454f,-116.56178f,-1.840677f,-12.767644f,-32.33313f ) ;
  }

  @Test
  public void test592() {
    color.laplace.solve(40.485184f,60.44004f,-63.630104f,1.5006965f,-37.786545f,76.45029f,4.258256f,15.532328f,95.6576f ) ;
  }

  @Test
  public void test593() {
    color.laplace.solve(40.50927f,42.591217f,2.6163085f,19.44587f,26.95375f,21.862127f,10.836342f,23.917135f,57.87845f ) ;
  }

  @Test
  public void test594() {
    color.laplace.solve(40.6173f,47.423294f,34.612434f,15.0459f,14.463448f,-9.980925f,5.102855f,5.365519f,1.8957742f ) ;
  }

  @Test
  public void test595() {
    color.laplace.solve(40.64478f,51.692608f,65.206985f,10.886505f,0.91867125f,-55.94821f,1.9825724f,-2.9562159f,-14.726108f ) ;
  }

  @Test
  public void test596() {
    color.laplace.solve(40.672348f,47.650238f,34.350597f,15.039158f,14.419127f,-10.169761f,5.0498247f,5.1562624f,0.96718216f ) ;
  }

  @Test
  public void test597() {
    color.laplace.solve(40.683334f,48.01669f,37.73196f,14.716967f,13.591195f,-11.95899f,4.575665f,3.5856926f,-3.8276541f ) ;
  }

  @Test
  public void test598() {
    color.laplace.solve(40.69127f,42.924488f,76.85316f,19.840582f,30.368881f,45.37363f,8.294321f,13.3351965f,14.677583f ) ;
  }

  @Test
  public void test599() {
    color.laplace.solve(40.694252f,58.774036f,51.381252f,4.0028567f,43.031296f,46.750977f,-67.71894f,62.597378f,92.59945f ) ;
  }

  @Test
  public void test600() {
    color.laplace.solve(40.697346f,45.160458f,40.84427f,17.628931f,-0.8997819f,9.578729f,30.718163f,18.138271f,0f ) ;
  }

  @Test
  public void test601() {
    color.laplace.solve(40.708946f,16.843868f,-172.18153f,46.042717f,98.84475f,51.512264f,44.672768f,149.83148f,0f ) ;
  }

  @Test
  public void test602() {
    color.laplace.solve(40.729683f,52.327736f,32.225258f,10.590996f,36.356f,67.62353f,-34.7217f,14.881738f,-33.754234f ) ;
  }

  @Test
  public void test603() {
    color.laplace.solve(40.73875f,63.24062f,67.10698f,-0.28562135f,45.116753f,36.941772f,-86.997986f,80.57024f,35.54336f ) ;
  }

  @Test
  public void test604() {
    color.laplace.solve(4.076036f,13.534225f,-35.14112f,-97.23008f,-14.798013f,-82.35706f,-28.571434f,-17.055656f,-24.85318f ) ;
  }

  @Test
  public void test605() {
    color.laplace.solve(40.833954f,60.094414f,58.501633f,3.2413955f,41.04207f,51.90636f,-68.91044f,100.0f,0f ) ;
  }

  @Test
  public void test606() {
    color.laplace.solve(40.858524f,47.01845f,39.062f,16.415646f,8.153278f,9.229552f,16.650784f,-40.050537f,0f ) ;
  }

  @Test
  public void test607() {
    color.laplace.solve(40.905014f,22.955914f,-92.18122f,40.66415f,81.06901f,0f,-42.992916f,53.982967f,0f ) ;
  }

  @Test
  public void test608() {
    color.laplace.solve(40.91051f,49.8484f,45.005447f,13.793649f,13.477643f,0.9164117f,0.78643954f,-10.64789f,-57.145958f ) ;
  }

  @Test
  public void test609() {
    color.laplace.solve(40.930855f,50.340626f,51.235775f,13.382793f,9.722723f,-22.960123f,2.877597f,-1.8724054f,-20.089941f ) ;
  }

  @Test
  public void test610() {
    color.laplace.solve(40.943752f,48.85314f,38.395573f,14.924238f,16.073355f,4.7216454f,2.6798418f,-4.2038245f,-35.582348f ) ;
  }

  @Test
  public void test611() {
    color.laplace.solve(41.01172f,49.968582f,46.158993f,14.078291f,12.703619f,-9.545414f,2.597827f,-3.6869833f,-30.04938f ) ;
  }

  @Test
  public void test612() {
    color.laplace.solve(41.091812f,56.56615f,62.652855f,7.8011f,22.519936f,45.75208f,-32.40735f,-20.03959f,100.0f ) ;
  }

  @Test
  public void test613() {
    color.laplace.solve(41.148975f,43.5371f,-1.3890425f,21.058796f,29.442425f,19.657467f,13.643783f,33.516335f,50.576485f ) ;
  }

  @Test
  public void test614() {
    color.laplace.solve(41.19127f,52.912697f,-96.5057f,11.852377f,5.1769996f,-36.369663f,1.041241f,-7.687413f,-36.96789f ) ;
  }

  @Test
  public void test615() {
    color.laplace.solve(41.230106f,74.39089f,94.15406f,-9.470475f,62.179405f,97.123535f,-19.9743f,-70.42673f,0f ) ;
  }

  @Test
  public void test616() {
    color.laplace.solve(41.232426f,45.801983f,14.758107f,19.127714f,27.217402f,12.485889f,8.061034f,31.454018f,7.9680505f ) ;
  }

  @Test
  public void test617() {
    color.laplace.solve(41.26592f,58.465927f,92.09529f,6.5977497f,0.50249404f,5.053706f,-15.377414f,-68.10741f,-77.9718f ) ;
  }

  @Test
  public void test618() {
    color.laplace.solve(41.30263f,50.194824f,40.464962f,15.015698f,19.0117f,-99.99994f,-0.2515353f,-16.02184f,-82.84753f ) ;
  }

  @Test
  public void test619() {
    color.laplace.solve(41.304436f,48.807766f,35.772507f,16.409983f,18.154121f,-5.7177396f,6.181371f,-0.031877268f,0f ) ;
  }

  @Test
  public void test620() {
    color.laplace.solve(41.316883f,49.599125f,39.269913f,15.668412f,17.80973f,7.4510384f,3.54718f,-1.4796492f,-27.275492f ) ;
  }

  @Test
  public void test621() {
    color.laplace.solve(41.32655f,75.771065f,41.183674f,-10.46487f,-83.61448f,-23.638252f,-9.197664f,-26.325788f,-12.49101f ) ;
  }

  @Test
  public void test622() {
    color.laplace.solve(41.333378f,51.401264f,-169.3344f,13.9451885f,10.447703f,-25.694881f,4.0203605f,2.1486168f,-5.9000487f ) ;
  }

  @Test
  public void test623() {
    color.laplace.solve(41.384686f,43.578407f,-5.5693293f,21.960335f,38.49828f,-37.72914f,7.958375f,9.873165f,-6.9639945f ) ;
  }

  @Test
  public void test624() {
    color.laplace.solve(41.394627f,46.999058f,15.491304f,18.57945f,22.427721f,0.7299935f,10.495458f,23.40238f,-34.99905f ) ;
  }

  @Test
  public void test625() {
    color.laplace.solve(41.39814f,48.20388f,-3.7519634f,17.388683f,21.826326f,13.780375f,6.3302636f,7.932372f,3.5728974f ) ;
  }

  @Test
  public void test626() {
    color.laplace.solve(41.41808f,49.73664f,-80.91206f,15.935674f,12.60886f,-38.16422f,9.715755f,22.927347f,-84.86088f ) ;
  }

  @Test
  public void test627() {
    color.laplace.solve(41.475777f,49.907284f,39.60202f,15.995819f,18.551338f,8.4734125f,3.9561641f,-0.1711627f,-24.259708f ) ;
  }

  @Test
  public void test628() {
    color.laplace.solve(41.544968f,49.269527f,34.583645f,16.910345f,20.70232f,11.9634f,5.3940887f,4.66601f,-7.432369f ) ;
  }

  @Test
  public void test629() {
    color.laplace.solve(41.5456f,48.447826f,99.99776f,17.734592f,24.12823f,27.00694f,5.2645397f,3.3235776f,-16.098225f ) ;
  }

  @Test
  public void test630() {
    color.laplace.solve(41.624535f,50.94782f,34.927597f,15.55032f,14.094423f,73.37748f,6.482321f,10.378963f,20.93911f ) ;
  }

  @Test
  public void test631() {
    color.laplace.solve(41.699253f,43.657112f,-24.337008f,23.139896f,30.847591f,-0.31771037f,20.012741f,56.911068f,-62.931286f ) ;
  }

  @Test
  public void test632() {
    color.laplace.solve(41.699306f,31.052692f,-100.0f,35.744537f,82.51146f,41.385807f,18.767385f,39.325005f,56.021183f ) ;
  }

  @Test
  public void test633() {
    color.laplace.solve(41.70112f,53.124245f,57.625816f,13.680231f,13.170047f,0.16440992f,-0.14986952f,-14.279579f,-70.13822f ) ;
  }

  @Test
  public void test634() {
    color.laplace.solve(41.70807f,49.116386f,50.164246f,17.715887f,4.593231f,51.5406f,24.56225f,-99.99995f,88.75428f ) ;
  }

  @Test
  public void test635() {
    color.laplace.solve(41.779568f,50.115364f,40.939648f,17.002901f,21.062237f,13.1510105f,5.2502303f,3.9980187f,-10.3865795f ) ;
  }

  @Test
  public void test636() {
    color.laplace.solve(41.788475f,51.295193f,48.44813f,15.858702f,14.944161f,-38.447636f,6.702174f,10.949994f,-54.30493f ) ;
  }

  @Test
  public void test637() {
    color.laplace.solve(41.79622f,50.748035f,42.050625f,16.436848f,19.145292f,17.45447f,5.586183f,5.907883f,-1.0999426f ) ;
  }

  @Test
  public void test638() {
    color.laplace.solve(41.88665f,49.61956f,31.91843f,17.92704f,24.673153f,-79.2903f,5.1483555f,2.6663826f,-19.15598f ) ;
  }

  @Test
  public void test639() {
    color.laplace.solve(41.906174f,30.501799f,0f,-85.96696f,99.04363f,97.302246f,-18.347904f,12.57534f,-30.394365f ) ;
  }

  @Test
  public void test640() {
    color.laplace.solve(41.913746f,50.270584f,33.47214f,17.385365f,25.697037f,44.794815f,1.9306984f,-9.662572f,99.98488f ) ;
  }

  @Test
  public void test641() {
    color.laplace.solve(41.973007f,48.89636f,32.743702f,18.994513f,20.868776f,-17.921555f,13.123538f,33.49964f,100.0f ) ;
  }

  @Test
  public void test642() {
    color.laplace.solve(41.97875f,50.854218f,40.539337f,17.060776f,20.898788f,11.278662f,5.3655686f,4.4014974f,-16.32348f ) ;
  }

  @Test
  public void test643() {
    color.laplace.solve(42.013485f,52.58178f,49.852367f,15.472166f,35.96767f,0f,-16.092493f,0f,0f ) ;
  }

  @Test
  public void test644() {
    color.laplace.solve(42.01362f,49.79614f,32.40098f,18.258326f,24.769962f,-20.19221f,6.249727f,6.7405815f,-4.0573635f ) ;
  }

  @Test
  public void test645() {
    color.laplace.solve(42.018333f,57.230297f,67.20166f,10.84303f,19.701202f,94.96417f,-18.347414f,-84.23269f,-27.11086f ) ;
  }

  @Test
  public void test646() {
    color.laplace.solve(42.032627f,50.738495f,39.794064f,17.445702f,21.22537f,8.377741f,6.4683065f,8.427524f,-96.98134f ) ;
  }

  @Test
  public void test647() {
    color.laplace.solve(42.037235f,48.712105f,26.208563f,19.436838f,26.602623f,21.268408f,9.107495f,16.993141f,32.262447f ) ;
  }

  @Test
  public void test648() {
    color.laplace.solve(42.077904f,51.254414f,44.71498f,17.057198f,18.224699f,27.60554f,7.9260526f,-23.018343f,0f ) ;
  }

  @Test
  public void test649() {
    color.laplace.solve(42.08333f,54.220284f,-62.305943f,14.184692f,11.2077265f,-23.180288f,3.4477165f,-0.34731284f,-16.044718f ) ;
  }

  @Test
  public void test650() {
    color.laplace.solve(42.107952f,57.875263f,58.07781f,10.556587f,31.315296f,28.002335f,-31.196898f,28.827003f,-30.947435f ) ;
  }

  @Test
  public void test651() {
    color.laplace.solve(42.123142f,51.08202f,40.705833f,17.41f,21.498817f,10.849641f,6.0159326f,6.653611f,-18.806177f ) ;
  }

  @Test
  public void test652() {
    color.laplace.solve(42.127796f,50.10822f,31.985888f,18.402761f,24.45691f,19.61369f,7.0263376f,9.70309f,7.329195f ) ;
  }

  @Test
  public void test653() {
    color.laplace.solve(42.270508f,47.30711f,-4.0636325f,21.774921f,36.875385f,0f,-17.780651f,-85.73737f,0f ) ;
  }

  @Test
  public void test654() {
    color.laplace.solve(42.296432f,53.058716f,48.194973f,16.127316f,21.743675f,32.039f,0.469156f,-14.250384f,-79.21413f ) ;
  }

  @Test
  public void test655() {
    color.laplace.solve(42.313183f,52.213463f,47.56626f,17.03927f,18.974403f,-3.793819f,6.8694925f,10.438701f,15.910906f ) ;
  }

  @Test
  public void test656() {
    color.laplace.solve(42.34399f,47.06245f,41.06742f,22.313513f,4.83839f,17.207235f,42.071674f,-67.22964f,28.466028f ) ;
  }

  @Test
  public void test657() {
    color.laplace.solve(42.420784f,61.429256f,98.49839f,8.253887f,4.7978406f,14.574417f,-14.203077f,-65.06619f,82.28232f ) ;
  }

  @Test
  public void test658() {
    color.laplace.solve(42.456306f,50.672764f,33.170624f,19.151714f,27.064123f,29.23801f,7.0864305f,9.194813f,56.71729f ) ;
  }

  @Test
  public void test659() {
    color.laplace.solve(42.481777f,52.398857f,48.367664f,17.528381f,18.745989f,40.78918f,6.762471f,9.521503f,12.577671f ) ;
  }

  @Test
  public void test660() {
    color.laplace.solve(42.48744f,51.948906f,42.056194f,18.000853f,23.25199f,16.003126f,6.2639813f,7.055073f,-1.2956785f ) ;
  }

  @Test
  public void test661() {
    color.laplace.solve(42.498528f,48.0472f,12.016717f,21.946909f,37.673553f,-99.98033f,7.615559f,8.515327f,-11.227804f ) ;
  }

  @Test
  public void test662() {
    color.laplace.solve(42.566452f,-29.228224f,69.1227f,11.31816f,-0.5386683f,14.094133f,3.2448547f,1.6612586f,3.938848f ) ;
  }

  @Test
  public void test663() {
    color.laplace.solve(42.622215f,50.657696f,31.023582f,19.831223f,27.44784f,22.405432f,9.254842f,16.963247f,31.150307f ) ;
  }

  @Test
  public void test664() {
    color.laplace.solve(42.62352f,51.37561f,38.96917f,19.118467f,23.909763f,4.501069f,9.940592f,20.643904f,48.72526f ) ;
  }

  @Test
  public void test665() {
    color.laplace.solve(42.623802f,52.120216f,40.45703f,18.37499f,25.400034f,-0.64631486f,5.4761243f,31.751245f,-68.44232f ) ;
  }

  @Test
  public void test666() {
    color.laplace.solve(42.687996f,25.121378f,57.797516f,45.630604f,-100.0f,-67.015175f,32.675083f,85.06973f,31.405205f ) ;
  }

  @Test
  public void test667() {
    color.laplace.solve(42.727707f,43.24554f,-7.4243307f,27.665287f,37.678795f,-13.548943f,30.254642f,93.35329f,44.108345f ) ;
  }

  @Test
  public void test668() {
    color.laplace.solve(42.73556f,61.166668f,85.80956f,9.775576f,16.121649f,82.33904f,-19.754803f,-88.794785f,-21.012585f ) ;
  }

  @Test
  public void test669() {
    color.laplace.solve(42.74802f,75.49119f,60.335712f,-4.499112f,98.881035f,64.234505f,7.004858f,32.51854f,24.188261f ) ;
  }

  @Test
  public void test670() {
    color.laplace.solve(42.754017f,61.24353f,38.069237f,9.772544f,64.150856f,-8.966579f,-67.814705f,-29.929546f,0f ) ;
  }

  @Test
  public void test671() {
    color.laplace.solve(42.78064f,52.43911f,42.071407f,18.683449f,24.904398f,15.236399f,7.0487537f,9.511568f,6.0931196f ) ;
  }

  @Test
  public void test672() {
    color.laplace.solve(42.86691f,57.368446f,83.49082f,14.099188f,10.113806f,0.1091282f,3.4160383f,-0.43503475f,-15.269982f ) ;
  }

  @Test
  public void test673() {
    color.laplace.solve(42.87971f,53.470413f,48.384464f,18.048437f,22.635046f,10.291299f,6.696574f,8.730036f,-83.42667f ) ;
  }

  @Test
  public void test674() {
    color.laplace.solve(42.927544f,49.701378f,35.935764f,22.008791f,32.87324f,32.85407f,12.234378f,26.928722f,62.607273f ) ;
  }

  @Test
  public void test675() {
    color.laplace.solve(-42.942867f,-70.599236f,0f,-55.736526f,-75.412704f,0f,-35.235703f,-85.20628f,-94.74353f ) ;
  }

  @Test
  public void test676() {
    color.laplace.solve(-42.95416f,-27.73655f,-94.44789f,-18.323988f,-22.823269f,-33.48244f,-7.5185213f,-11.750097f,-16.6586f ) ;
  }

  @Test
  public void test677() {
    color.laplace.solve(42.98006f,52.599854f,42.31207f,19.320393f,25.107283f,11.0523615f,9.194229f,17.456524f,35.524582f ) ;
  }

  @Test
  public void test678() {
    color.laplace.solve(42.980328f,52.733585f,43.339447f,19.187733f,26.055885f,20.607882f,7.720519f,11.6943445f,13.00055f ) ;
  }

  @Test
  public void test679() {
    color.laplace.solve(42.994564f,56.189667f,62.77761f,15.7885895f,18.986492f,15.063102f,1.1733006f,-11.0953865f,-45.49891f ) ;
  }

  @Test
  public void test680() {
    color.laplace.solve(43.035885f,53.65942f,22.377f,18.484125f,23.779757f,12.975088f,7.1211295f,10.000394f,5.7435856f ) ;
  }

  @Test
  public void test681() {
    color.laplace.solve(43.073727f,45.405403f,24.000431f,26.88951f,14.547448f,71.20092f,49.936863f,9.784071f,0f ) ;
  }

  @Test
  public void test682() {
    color.laplace.solve(43.12595f,59.852173f,-99.14979f,12.6516285f,4.7721715f,-57.387695f,2.7069893f,-1.8310288f,-14.804681f ) ;
  }

  @Test
  public void test683() {
    color.laplace.solve(43.2035f,52.59538f,34.019466f,20.218618f,33.158546f,61.76286f,4.512428f,-2.1689072f,-46.346603f ) ;
  }

  @Test
  public void test684() {
    color.laplace.solve(43.234177f,55.42481f,40.551945f,17.5119f,37.913116f,-45.484863f,-11.099694f,-61.91068f,-57.49354f ) ;
  }

  @Test
  public void test685() {
    color.laplace.solve(43.285503f,51.77966f,36.590343f,21.577957f,27.24505f,-5.424681f,15.821552f,41.708252f,-85.53412f ) ;
  }

  @Test
  public void test686() {
    color.laplace.solve(43.312008f,55.510403f,56.62847f,17.737621f,22.101137f,10.744798f,5.537338f,4.41173f,-9.991556f ) ;
  }

  @Test
  public void test687() {
    color.laplace.solve(43.31572f,50.709232f,17.565138f,22.55364f,41.95591f,-22.230572f,4.942838f,-2.7822888f,-58.02795f ) ;
  }

  @Test
  public void test688() {
    color.laplace.solve(43.351913f,49.86791f,-0.55457675f,23.539742f,56.674294f,-23.06956f,-5.8672366f,-47.00869f,-98.678825f ) ;
  }

  @Test
  public void test689() {
    color.laplace.solve(43.47687f,-65.01263f,0f,14.21427f,4.0284786f,53.601437f,9.351728f,23.192646f,79.39037f ) ;
  }

  @Test
  public void test690() {
    color.laplace.solve(43.543377f,51.57982f,20.487934f,22.593695f,42.28796f,-100.0f,4.5434413f,29.116573f,0f ) ;
  }

  @Test
  public void test691() {
    color.laplace.solve(43.574398f,57.042408f,-80.82788f,17.255192f,18.552391f,-10.408744f,6.893975f,10.320708f,15.836467f ) ;
  }

  @Test
  public void test692() {
    color.laplace.solve(43.585396f,58.730137f,-100.0f,15.611446f,14.060165f,-21.69038f,4.8002253f,3.5894547f,-4.5025716f ) ;
  }

  @Test
  public void test693() {
    color.laplace.solve(43.676506f,65.07419f,42.35067f,9.631839f,-5.846709f,-90.19072f,0.69755644f,-6.841613f,-22.2173f ) ;
  }

  @Test
  public void test694() {
    color.laplace.solve(43.697937f,49.66597f,17.771559f,25.125778f,37.194386f,20.668415f,19.610788f,53.317375f,27.707714f ) ;
  }

  @Test
  public void test695() {
    color.laplace.solve(43.72301f,59.35048f,99.88883f,15.541571f,13.717987f,-23.379662f,4.725283f,3.3595614f,-5.005025f ) ;
  }

  @Test
  public void test696() {
    color.laplace.solve(43.751926f,44.446167f,37.550373f,30.561537f,-3.517633f,5.7553253f,82.01185f,-94.83356f,-100.0f ) ;
  }

  @Test
  public void test697() {
    color.laplace.solve(43.836895f,56.144012f,52.94718f,19.203573f,27.79191f,55.644604f,5.185435f,1.5381659f,-95.06401f ) ;
  }

  @Test
  public void test698() {
    color.laplace.solve(43.871395f,51.496708f,45.83362f,23.988848f,16.281807f,30.860826f,35.802193f,-41.219162f,61.327877f ) ;
  }

  @Test
  public void test699() {
    color.laplace.solve(43.893017f,56.59168f,57.030018f,18.953701f,25.440668f,19.421953f,6.447539f,6.795339f,-4.7858987f ) ;
  }

  @Test
  public void test700() {
    color.laplace.solve(43.906876f,55.85991f,63.770267f,19.7676f,15.762492f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test701() {
    color.laplace.solve(43.991314f,55.003765f,45.895603f,21.383818f,31.20588f,28.43521f,10.346172f,20.000723f,36.37841f ) ;
  }

  @Test
  public void test702() {
    color.laplace.solve(44.037075f,50.688744f,-42.09595f,25.459557f,43.87782f,69.11073f,13.927952f,30.252377f,63.203835f ) ;
  }

  @Test
  public void test703() {
    color.laplace.solve(44.096832f,47.877716f,-1.1854519f,28.50962f,48.599483f,61.151566f,21.342163f,56.859028f,-100.0f ) ;
  }

  @Test
  public void test704() {
    color.laplace.solve(44.10722f,76.42135f,-70.01328f,7.7243056f,3.5503995f,-4.691976f,-16.760395f,-65.25208f,47.694977f ) ;
  }

  @Test
  public void test705() {
    color.laplace.solve(44.108826f,59.563793f,77.58745f,16.87337f,17.785612f,-10.355747f,5.605099f,5.547028f,-1.2021798f ) ;
  }

  @Test
  public void test706() {
    color.laplace.solve(44.1133f,56.837418f,56.71545f,19.61578f,26.520926f,17.93071f,7.828892f,11.69979f,12.449344f ) ;
  }

  @Test
  public void test707() {
    color.laplace.solve(44.144295f,40.56182f,-78.72785f,36.015354f,90.299126f,15.25149f,9.618002f,2.4566543f,-90.09051f ) ;
  }

  @Test
  public void test708() {
    color.laplace.solve(44.28537f,52.22825f,17.831163f,24.913227f,46.79646f,-80.903595f,8.571083f,9.371104f,-17.883123f ) ;
  }

  @Test
  public void test709() {
    color.laplace.solve(4.433786f,-100.0f,6.954514f,-32.60039f,-50.226044f,-3.5451272f,-84.60931f,-64.75866f,29.09102f ) ;
  }

  @Test
  public void test710() {
    color.laplace.solve(44.344822f,55.96779f,47.09616f,21.411495f,32.43018f,38.268993f,8.870983f,14.072435f,73.43042f ) ;
  }

  @Test
  public void test711() {
    color.laplace.solve(44.391083f,54.48802f,44.29325f,23.076303f,29.267752f,22.684982f,18.64638f,16.821703f,97.51614f ) ;
  }

  @Test
  public void test712() {
    color.laplace.solve(44.419018f,1.6926657f,0f,-17.073391f,-71.56437f,0f,-41.148205f,0f,0f ) ;
  }

  @Test
  public void test713() {
    color.laplace.solve(44.437553f,49.79216f,2.3515224f,27.958063f,52.379555f,97.90356f,15.015139f,32.102493f,61.015274f ) ;
  }

  @Test
  public void test714() {
    color.laplace.solve(44.493366f,47.020016f,54.18098f,30.953445f,-10.594289f,36.16206f,89.9147f,0f,0f ) ;
  }

  @Test
  public void test715() {
    color.laplace.solve(44.545715f,61.65252f,-100.0f,16.530338f,16.627174f,-16.217365f,4.948463f,4.309016f,-3.1048665f ) ;
  }

  @Test
  public void test716() {
    color.laplace.solve(44.55236f,61.5394f,84.59125f,16.670044f,17.013983f,-13.938792f,5.1138306f,3.785279f,-6.9866967f ) ;
  }

  @Test
  public void test717() {
    color.laplace.solve(44.596558f,55.467075f,36.215546f,22.919159f,41.056187f,-99.92436f,6.023892f,1.176409f,-42.374443f ) ;
  }

  @Test
  public void test718() {
    color.laplace.solve(44.64248f,56.075024f,46.65287f,22.494898f,33.004753f,26.614563f,12.3323555f,26.834524f,-14.393949f ) ;
  }

  @Test
  public void test719() {
    color.laplace.solve(44.663826f,36.11711f,59.01365f,42.538197f,-2.9771888f,-54.316486f,8.715516f,-7.676129f,-36.442844f ) ;
  }

  @Test
  public void test720() {
    color.laplace.solve(44.799118f,52.66984f,17.32972f,26.526634f,48.550533f,99.94873f,12.756887f,24.500914f,36.696236f ) ;
  }

  @Test
  public void test721() {
    color.laplace.solve(44.827118f,55.3193f,42.256866f,23.989174f,34.193222f,13.70817f,16.936354f,43.75624f,-24.178312f ) ;
  }

  @Test
  public void test722() {
    color.laplace.solve(44.8373f,66.530495f,29.392006f,12.818699f,24.645761f,13.816984f,-18.208265f,5.4168687f,1.2301695f ) ;
  }

  @Test
  public void test723() {
    color.laplace.solve(44.85197f,58.51975f,58.993317f,20.888128f,30.233717f,28.547806f,8.466828f,12.979183f,13.2161875f ) ;
  }

  @Test
  public void test724() {
    color.laplace.solve(44.853024f,44.28908f,-63.03529f,35.123016f,46.162174f,0f,73.402596f,0f,0f ) ;
  }

  @Test
  public void test725() {
    color.laplace.solve(44.86466f,62.04701f,-49.296516f,17.411623f,16.13439f,-32.09924f,8.647447f,17.178165f,-5.109343f ) ;
  }

  @Test
  public void test726() {
    color.laplace.solve(44.86468f,34.473503f,28.634584f,43.082775f,-19.278095f,-30.480173f,155.11076f,-123.78498f,-148.69893f ) ;
  }

  @Test
  public void test727() {
    color.laplace.solve(44.882053f,27.031673f,0f,43.926674f,57.863052f,45.19591f,72.961586f,33.3859f,0f ) ;
  }

  @Test
  public void test728() {
    color.laplace.solve(44.9055f,62.852318f,88.81302f,16.769608f,17.69075f,-10.019158f,4.4824553f,1.1602122f,-17.53187f ) ;
  }

  @Test
  public void test729() {
    color.laplace.solve(44.951077f,62.07454f,74.873825f,17.731272f,28.474234f,61.79841f,-2.494032f,-27.707283f,-38.039017f ) ;
  }

  @Test
  public void test730() {
    color.laplace.solve(44.968323f,64.05485f,-10.527535f,15.818436f,15.955025f,-9.636334f,2.3503962f,-6.416851f,-43.972824f ) ;
  }

  @Test
  public void test731() {
    color.laplace.solve(-4.5075717f,7.900244f,0f,-9.640428f,52.08888f,-9.126572f,-86.14302f,54.03934f,0f ) ;
  }

  @Test
  public void test732() {
    color.laplace.solve(45.1612f,59.06824f,58.155685f,21.57657f,32.956074f,40.000015f,8.189008f,11.179461f,68.888306f ) ;
  }

  @Test
  public void test733() {
    color.laplace.solve(45.181053f,57.48848f,48.927948f,23.235739f,35.84492f,38.223305f,11.916975f,24.432163f,84.36014f ) ;
  }

  @Test
  public void test734() {
    color.laplace.solve(45.204807f,52.72744f,-3.6737747f,28.091793f,55.327194f,-30.592922f,11.835167f,19.248875f,9.833138f ) ;
  }

  @Test
  public void test735() {
    color.laplace.solve(45.2148f,57.331394f,44.664932f,23.527819f,39.445847f,21.328337f,9.450622f,14.274669f,99.99994f ) ;
  }

  @Test
  public void test736() {
    color.laplace.solve(4.523224f,-76.49353f,-46.808662f,-5.4116154f,-24.306292f,-13.276164f,-1.863394f,-2.039822f,18.010397f ) ;
  }

  @Test
  public void test737() {
    color.laplace.solve(45.298225f,58.335613f,51.48812f,22.857288f,36.617897f,47.70665f,9.650487f,15.7446575f,15.862826f ) ;
  }

  @Test
  public void test738() {
    color.laplace.solve(45.299114f,23.957304f,-100.0f,57.23915f,-30.209257f,-55.607582f,15.141369f,3.3263216f,28.373175f ) ;
  }

  @Test
  public void test739() {
    color.laplace.solve(45.357014f,54.376057f,35.481155f,27.051996f,36.666065f,-12.451434f,26.184908f,77.68764f,-100.0f ) ;
  }

  @Test
  public void test740() {
    color.laplace.solve(45.430958f,41.75336f,-70.64799f,39.970474f,92.23048f,-94.76831f,22.220457f,60.13379f,0f ) ;
  }

  @Test
  public void test741() {
    color.laplace.solve(45.47246f,48.67089f,15.968779f,33.21896f,33.242325f,-84.79578f,54.161057f,0f,0f ) ;
  }

  @Test
  public void test742() {
    color.laplace.solve(45.530003f,56.75696f,16.534454f,25.363043f,64.96339f,39.565998f,-90.10264f,0f,0f ) ;
  }

  @Test
  public void test743() {
    color.laplace.solve(45.613358f,56.66069f,50.562893f,25.792738f,30.466518f,7.154008f,27.091074f,32.258636f,-52.413376f ) ;
  }

  @Test
  public void test744() {
    color.laplace.solve(45.647392f,-42.380474f,81.90532f,34.18646f,19.409683f,8.683468f,71.68877f,77.14928f,-60.423653f ) ;
  }

  @Test
  public void test745() {
    color.laplace.solve(45.720924f,72.83158f,82.72021f,10.052114f,62.885197f,86.43877f,-68.39767f,82.21832f,81.43815f ) ;
  }

  @Test
  public void test746() {
    color.laplace.solve(45.8316f,56.683445f,42.021362f,26.642963f,38.880806f,11.402012f,21.859444f,60.79481f,-67.29998f ) ;
  }

  @Test
  public void test747() {
    color.laplace.solve(45.94315f,60.22451f,56.847744f,23.548088f,38.107147f,95.548004f,10.142057f,17.020142f,-22.545805f ) ;
  }

  @Test
  public void test748() {
    color.laplace.solve(45.955914f,58.49303f,42.13928f,25.330631f,45.876926f,10.064058f,10.458788f,16.50452f,9.682382f ) ;
  }

  @Test
  public void test749() {
    color.laplace.solve(45.962666f,72.31164f,-10.222634f,11.539022f,7.3461037f,-14.316507f,-7.1526794f,-40.149742f,-54.3895f ) ;
  }

  @Test
  public void test750() {
    color.laplace.solve(45.970898f,66.448296f,99.94423f,17.435291f,16.888206f,4.2081094f,6.8820653f,-20.538872f,-100.0f ) ;
  }

  @Test
  public void test751() {
    color.laplace.solve(46.047222f,15.666343f,3.9165857f,68.522545f,-87.29844f,-100.0f,70.80602f,-100.0f,0f ) ;
  }

  @Test
  public void test752() {
    color.laplace.solve(46.11153f,23.622911f,39.273827f,60.82321f,-90.89371f,-100.0f,10.822018f,-17.535137f,9.931143f ) ;
  }

  @Test
  public void test753() {
    color.laplace.solve(46.11723f,50.115986f,40.904236f,34.35293f,13.442481f,13.500953f,77.852005f,-44.199944f,-43.074486f ) ;
  }

  @Test
  public void test754() {
    color.laplace.solve(46.13418f,44.866215f,16.898823f,39.670494f,16.431864f,-90.55978f,96.11594f,71.75052f,0f ) ;
  }

  @Test
  public void test755() {
    color.laplace.solve(46.142002f,49.460205f,34.420547f,35.12677f,18.475191f,-11.778241f,75.887024f,1.0920346f,-100.0f ) ;
  }

  @Test
  public void test756() {
    color.laplace.solve(46.14872f,62.901535f,70.96521f,21.69335f,34.768513f,52.747856f,5.8561635f,1.7313051f,-33.699455f ) ;
  }

  @Test
  public void test757() {
    color.laplace.solve(46.188972f,32.053894f,6.127689f,-1.7230899f,-12.595711f,-27.141722f,-40.485622f,-53.571926f,-0.4691533f ) ;
  }

  @Test
  public void test758() {
    color.laplace.solve(46.213078f,64.774536f,79.78575f,20.077776f,33.099327f,-89.51424f,0.9986959f,-16.082993f,0f ) ;
  }

  @Test
  public void test759() {
    color.laplace.solve(-46.21321f,40.36639f,0f,-26.797562f,42.97331f,0f,15.002124f,86.80605f,-37.111088f ) ;
  }

  @Test
  public void test760() {
    color.laplace.solve(46.22696f,-76.64117f,-25.477581f,9.547714f,-8.207753f,43.12355f,0.17165114f,-8.86111f,-32.74648f ) ;
  }

  @Test
  public void test761() {
    color.laplace.solve(46.240337f,62.406822f,68.55469f,22.554527f,34.832264f,40.340214f,9.145506f,14.027495f,16.582102f ) ;
  }

  @Test
  public void test762() {
    color.laplace.solve(46.263443f,61.633125f,57.225533f,23.420645f,43.04352f,-76.74738f,4.3756156f,-5.918183f,-100.0f ) ;
  }

  @Test
  public void test763() {
    color.laplace.solve(46.31063f,55.074036f,27.62963f,30.168495f,46.35588f,-44.555523f,28.007467f,81.861374f,100.0f ) ;
  }

  @Test
  public void test764() {
    color.laplace.solve(46.330463f,60.29415f,65.07354f,25.027708f,29.772606f,100.0f,100.0f,32.45566f,0f ) ;
  }

  @Test
  public void test765() {
    color.laplace.solve(46.347683f,9.416497f,-8.681705f,75.97424f,-99.99999f,-65.21419f,12.042848f,-27.80285f,-23.25426f ) ;
  }

  @Test
  public void test766() {
    color.laplace.solve(46.410526f,52.31779f,38.382153f,33.324314f,24.47848f,1.2108227f,62.408245f,11.060992f,47.50776f ) ;
  }

  @Test
  public void test767() {
    color.laplace.solve(46.5222f,-99.937325f,-9.648557f,2.2775102f,-33.58053f,-19.058268f,-3.8316317f,-17.604036f,-33.003986f ) ;
  }

  @Test
  public void test768() {
    color.laplace.solve(46.55401f,38.999847f,50.69867f,47.21618f,-41.25329f,-43.04101f,0f,0f,0f ) ;
  }

  @Test
  public void test769() {
    color.laplace.solve(46.778835f,55.722786f,28.092237f,31.39255f,31.327238f,18.720798f,47.464127f,100.0f,0f ) ;
  }

  @Test
  public void test770() {
    color.laplace.solve(46.856976f,67.81157f,99.82945f,19.616339f,24.559834f,2.2341912f,7.048547f,8.5778475f,2.7030096f ) ;
  }

  @Test
  public void test771() {
    color.laplace.solve(46.87716f,55.51816f,77.02315f,31.99047f,61.7017f,8.975124f,19.383028f,45.541645f,-39.553356f ) ;
  }

  @Test
  public void test772() {
    color.laplace.solve(47.083664f,82.04134f,100.0f,-1.0573081f,-27.90128f,-100.0f,-23.411617f,-92.58916f,-10.443554f ) ;
  }

  @Test
  public void test773() {
    color.laplace.solve(47.1247f,62.29798f,39.807766f,26.200817f,62.25946f,-3.0669184f,-4.580891f,-44.524384f,0f ) ;
  }

  @Test
  public void test774() {
    color.laplace.solve(47.170013f,66.99259f,-70.72495f,21.687462f,28.456947f,2.343427f,11.122884f,22.804306f,51.642048f ) ;
  }

  @Test
  public void test775() {
    color.laplace.solve(47.22318f,61.920124f,47.325253f,26.972591f,53.132072f,75.63742f,17.401495f,42.633392f,100.0f ) ;
  }

  @Test
  public void test776() {
    color.laplace.solve(47.257122f,56.090286f,53.265026f,32.938206f,23.838997f,-48.23049f,60.656696f,-6.772366f,0f ) ;
  }

  @Test
  public void test777() {
    color.laplace.solve(47.33557f,59.89321f,33.050507f,29.449066f,59.186768f,-27.691177f,11.273929f,15.646648f,-7.8741045f ) ;
  }

  @Test
  public void test778() {
    color.laplace.solve(47.367466f,83.42314f,50.853146f,6.046725f,-0.25733507f,7.238738f,-22.92269f,-97.73787f,-21.641026f ) ;
  }

  @Test
  public void test779() {
    color.laplace.solve(47.38003f,64.64646f,70.822845f,24.873674f,40.382954f,41.68657f,11.73171f,22.053167f,36.098007f ) ;
  }

  @Test
  public void test780() {
    color.laplace.solve(47.495144f,23.725359f,-94.43039f,2.946169f,11.634124f,39.401535f,-47.344593f,-19.536568f,-19.301865f ) ;
  }

  @Test
  public void test781() {
    color.laplace.solve(47.76787f,62.40613f,-10.827208f,28.58767f,45.04512f,34.025303f,20.961836f,55.180508f,153.92679f ) ;
  }

  @Test
  public void test782() {
    color.laplace.solve(47.815567f,64.02844f,-100.0f,27.233828f,47.447742f,-100.0f,13.672001f,27.454176f,48.69696f ) ;
  }

  @Test
  public void test783() {
    color.laplace.solve(47.870747f,38.384384f,34.855083f,53.09861f,-29.188293f,22.772823f,-8.996763f,-89.08566f,0f ) ;
  }

  @Test
  public void test784() {
    color.laplace.solve(47.978058f,43.217472f,-118.84167f,49.06286f,143.86414f,158.11359f,4.1907067f,-34.95361f,0f ) ;
  }

  @Test
  public void test785() {
    color.laplace.solve(48.00368f,55.67948f,23.074366f,36.335247f,51.639877f,-22.846096f,45.697433f,49.0096f,0f ) ;
  }

  @Test
  public void test786() {
    color.laplace.solve(48.04711f,68.992546f,100.0f,23.588726f,27.563978f,143.79218f,20.524908f,60.131268f,195.45874f ) ;
  }

  @Test
  public void test787() {
    color.laplace.solve(48.04884f,69.46906f,-10.197132f,22.726292f,32.02809f,15.330332f,10.828241f,20.586676f,39.490368f ) ;
  }

  @Test
  public void test788() {
    color.laplace.solve(48.23716f,69.609505f,94.928375f,23.339142f,35.272472f,32.092632f,9.846938f,16.04861f,19.075031f ) ;
  }

  @Test
  public void test789() {
    color.laplace.solve(48.306343f,42.85268f,0f,9.312989f,47.439114f,-37.195f,-58.493496f,-76.25488f,0f ) ;
  }

  @Test
  public void test790() {
    color.laplace.solve(48.46719f,64.1407f,58.6562f,29.728064f,47.788555f,-1.7255306f,22.656504f,-12.634772f,0f ) ;
  }

  @Test
  public void test791() {
    color.laplace.solve(48.519356f,60.983612f,72.268906f,33.093815f,23.146189f,67.593155f,60.709713f,-69.08583f,15.236658f ) ;
  }

  @Test
  public void test792() {
    color.laplace.solve(48.552166f,66.25715f,66.20677f,27.959608f,50.45183f,97.56807f,12.834429f,23.37958f,30.23206f ) ;
  }

  @Test
  public void test793() {
    color.laplace.solve(48.630085f,74.02856f,-64.14102f,20.51104f,25.237816f,-5.7908535f,8.2002325f,12.2958765f,15.745459f ) ;
  }

  @Test
  public void test794() {
    color.laplace.solve(48.647053f,62.087673f,31.281313f,32.500538f,68.42233f,-36.962425f,12.932767f,19.230532f,-4.4329734f ) ;
  }

  @Test
  public void test795() {
    color.laplace.solve(48.806675f,56.235847f,39.691593f,38.99085f,36.445126f,10.815511f,70.7116f,39.738293f,-32.874676f ) ;
  }

  @Test
  public void test796() {
    color.laplace.solve(48.849957f,77.77468f,152.53612f,17.630722f,9.714502f,-66.828964f,4.955936f,116.28215f,0f ) ;
  }

  @Test
  public void test797() {
    color.laplace.solve(49.17004f,40.179035f,21.958982f,56.501125f,-10.412884f,-52.343105f,13.455754f,-2.678108f,-13.755303f ) ;
  }

  @Test
  public void test798() {
    color.laplace.solve(49.30813f,74.78086f,133.34508f,16.548565f,14.620227f,-128.53214f,-0.36572167f,-12.832578f,-65.584816f ) ;
  }

  @Test
  public void test799() {
    color.laplace.solve(49.355595f,71.208885f,-15.874211f,18.127098f,17.455809f,-24.173597f,5.6969876f,4.660853f,-4.509384f ) ;
  }

  @Test
  public void test800() {
    color.laplace.solve(49.471996f,63.064087f,100.0f,23.276804f,34.294487f,36.75094f,9.340732f,14.086121f,12.709265f ) ;
  }

  @Test
  public void test801() {
    color.laplace.solve(49.51216f,67.434074f,61.052147f,30.614922f,59.152836f,76.774506f,13.79857f,24.573292f,25.341759f ) ;
  }

  @Test
  public void test802() {
    color.laplace.solve(49.740673f,63.968945f,50.01596f,34.990143f,56.110752f,24.02086f,34.10197f,101.448654f,-10.045061f ) ;
  }

  @Test
  public void test803() {
    color.laplace.solve(49.77967f,9.972088f,57.345318f,89.1466f,72.376205f,63.414387f,30.180681f,31.576128f,23.74763f ) ;
  }

  @Test
  public void test804() {
    color.laplace.solve(49.893307f,74.0636f,40.93687f,25.509634f,39.429356f,32.79036f,12.715868f,25.353836f,65.46712f ) ;
  }

  @Test
  public void test805() {
    color.laplace.solve(49.98694f,11.028996f,-9.80224f,88.91876f,14.765776f,0f,31.321331f,36.366566f,-20.947733f ) ;
  }

  @Test
  public void test806() {
    color.laplace.solve(49.987446f,37.52164f,46.30638f,62.428146f,-17.833914f,0f,34.48167f,-4.1182866f,0f ) ;
  }

  @Test
  public void test807() {
    color.laplace.solve(50.090195f,73.73552f,99.61005f,26.625256f,45.241844f,-99.97027f,11.168982f,18.05067f,15.791859f ) ;
  }

  @Test
  public void test808() {
    color.laplace.solve(50.175568f,27.305794f,0f,3.0262535f,23.247969f,45.179375f,-61.318523f,17.480455f,0f ) ;
  }

  @Test
  public void test809() {
    color.laplace.solve(50.177883f,46.909264f,22.67567f,53.802547f,14.783679f,-56.206306f,20.953794f,30.01256f,84.31277f ) ;
  }

  @Test
  public void test810() {
    color.laplace.solve(50.240547f,85.99181f,0.90943414f,14.970376f,10.4570675f,-40.899097f,-0.816111f,-18.23482f,-82.58024f ) ;
  }

  @Test
  public void test811() {
    color.laplace.solve(50.352997f,73.9625f,100.0f,27.449493f,45.497078f,25.159685f,13.948024f,28.342602f,53.92536f ) ;
  }

  @Test
  public void test812() {
    color.laplace.solve(50.42235f,99.969154f,99.98872f,1.7202595f,-55.401928f,-73.87786f,11.860614f,45.722195f,0f ) ;
  }

  @Test
  public void test813() {
    color.laplace.solve(50.601627f,58.354107f,7.9032474f,44.148502f,74.923f,34.695007f,51.454845f,162.53212f,294.21854f ) ;
  }

  @Test
  public void test814() {
    color.laplace.solve(5.063522f,31.168232f,-79.6501f,2.850091f,5.4209905f,-13.147674f,0.91585094f,0.8133129f,-3.08359f ) ;
  }

  @Test
  public void test815() {
    color.laplace.solve(50.71438f,64.02039f,61.695724f,38.837112f,43.67148f,82.762505f,60.962593f,-10.9341f,100.0f ) ;
  }

  @Test
  public void test816() {
    color.laplace.solve(50.769764f,17.802666f,20.4409f,85.2764f,-100.0f,-50.250755f,10.738957f,100.0f,0f ) ;
  }

  @Test
  public void test817() {
    color.laplace.solve(50.789673f,56.094326f,-26.894258f,29.860691f,39.681747f,-13.252726f,28.971348f,86.024704f,-65.79839f ) ;
  }

  @Test
  public void test818() {
    color.laplace.solve(5.096344f,-56.05768f,-59.44676f,-23.556946f,-7.30654f,75.62049f,-92.017586f,-25.232029f,-100.0f ) ;
  }

  @Test
  public void test819() {
    color.laplace.solve(51.129677f,88.1957f,99.50023f,16.322996f,5.870893f,-97.89717f,8.29144f,16.862038f,53.28582f ) ;
  }

  @Test
  public void test820() {
    color.laplace.solve(51.268982f,67.22231f,37.640553f,37.853527f,79.97973f,-61.012337f,20.165375f,42.807976f,71.08679f ) ;
  }

  @Test
  public void test821() {
    color.laplace.solve(5.1366396f,6.363296f,-100.0f,-85.81674f,20.316282f,0f,-21.755884f,-1.2067949f,-3.3875782f ) ;
  }

  @Test
  public void test822() {
    color.laplace.solve(51.478462f,63.64371f,3.1460545f,42.270138f,99.950325f,-61.382484f,20.999886f,41.72941f,45.96742f ) ;
  }

  @Test
  public void test823() {
    color.laplace.solve(51.571857f,38.61578f,33.487377f,67.67165f,-30.596113f,-38.809776f,14.198936f,-10.875906f,-27.106447f ) ;
  }

  @Test
  public void test824() {
    color.laplace.solve(51.671227f,57.24523f,31.133108f,49.439674f,46.17659f,-81.32737f,65.70583f,-33.32618f,0f ) ;
  }

  @Test
  public void test825() {
    color.laplace.solve(51.684296f,13.315447f,-90.351265f,93.42173f,83.566536f,0f,95.74293f,0f,0f ) ;
  }

  @Test
  public void test826() {
    color.laplace.solve(51.897507f,47.0076f,59.512383f,60.582428f,-23.3795f,91.04194f,16.246784f,4.4047103f,24.751556f ) ;
  }

  @Test
  public void test827() {
    color.laplace.solve(51.92915f,99.120575f,100.0f,8.596029f,-17.221712f,-78.15959f,-0.32332152f,-9.889316f,-22.012226f ) ;
  }

  @Test
  public void test828() {
    color.laplace.solve(51.99935f,64.62128f,7.9528093f,43.376137f,98.532936f,99.99996f,22.972263f,48.512917f,72.54647f ) ;
  }

  @Test
  public void test829() {
    color.laplace.solve(52.04268f,70.16057f,48.25987f,38.01014f,80.33974f,22.878904f,19.658146f,40.62244f,62.491886f ) ;
  }

  @Test
  public void test830() {
    color.laplace.solve(52.059532f,73.945404f,72.89631f,34.29272f,70.82578f,2.297435f,14.28556f,22.849522f,6.286739f ) ;
  }

  @Test
  public void test831() {
    color.laplace.solve(52.266575f,70.02982f,62.618515f,32.05541f,61.259197f,59.634285f,21.503412f,55.827084f,131.49689f ) ;
  }

  @Test
  public void test832() {
    color.laplace.solve(5.2365847f,-9.162817f,-68.39418f,-69.89085f,-73.493675f,86.05853f,-30.158428f,-50.742867f,-100.0f ) ;
  }

  @Test
  public void test833() {
    color.laplace.solve(52.430317f,87.55787f,19.532888f,22.163399f,30.996151f,15.518233f,5.227126f,-1.2548931f,-41.242844f ) ;
  }

  @Test
  public void test834() {
    color.laplace.solve(52.579086f,72.21991f,53.3584f,38.09651f,82.94214f,41.21369f,16.864824f,29.362782f,17.644117f ) ;
  }

  @Test
  public void test835() {
    color.laplace.solve(52.77037f,74.022f,-24.4534f,37.059483f,61.46318f,26.081926f,34.00438f,98.95804f,43.46533f ) ;
  }

  @Test
  public void test836() {
    color.laplace.solve(52.92919f,26.773767f,27.562748f,84.94301f,-73.39687f,-47.104668f,16.668802f,-18.267796f,-16.343115f ) ;
  }

  @Test
  public void test837() {
    color.laplace.solve(-53.077744f,36.705376f,-52.330452f,-12.817907f,4.2926f,-9.58903f,-2.4864864f,2.8719618f,9.681733f ) ;
  }

  @Test
  public void test838() {
    color.laplace.solve(5.3101144f,100.0f,0f,18.442816f,62.643887f,100.0f,5.8172593f,4.8262224f,-49.156258f ) ;
  }

  @Test
  public void test839() {
    color.laplace.solve(53.294205f,45.72011f,-45.139297f,67.45671f,74.72554f,-72.65401f,16.303495f,-2.2427247f,-99.99994f ) ;
  }

  @Test
  public void test840() {
    color.laplace.solve(53.630905f,42.0295f,17.88287f,72.49412f,-3.3957803f,44.676353f,64.73983f,18.341124f,0f ) ;
  }

  @Test
  public void test841() {
    color.laplace.solve(53.64864f,90.44668f,-3.400014f,24.14788f,33.894142f,8.934907f,9.048744f,12.047096f,5.245501f ) ;
  }

  @Test
  public void test842() {
    color.laplace.solve(53.735233f,49.47763f,12.356071f,61.78629f,25.957417f,-100.0f,166.90561f,93.27057f,-33.97348f ) ;
  }

  @Test
  public void test843() {
    color.laplace.solve(53.752f,45.455574f,0f,69.55243f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test844() {
    color.laplace.solve(53.971424f,89.77803f,65.03379f,26.107664f,40.084076f,29.057632f,10.37516f,15.392972f,11.112652f ) ;
  }

  @Test
  public void test845() {
    color.laplace.solve(-54.18813f,267.60886f,88.67767f,1.6831297f,70.76772f,54.238895f,-10.457729f,-40.41243f,57.081444f ) ;
  }

  @Test
  public void test846() {
    color.laplace.solve(54.1917f,88.593475f,161.59886f,28.238226f,39.325462f,52.93941f,14.74414f,26.260042f,49.94359f ) ;
  }

  @Test
  public void test847() {
    color.laplace.solve(54.2092f,59.378727f,24.774609f,57.458088f,58.531094f,-60.28029f,-65.27259f,0f,0f ) ;
  }

  @Test
  public void test848() {
    color.laplace.solve(54.325336f,36.13889f,-4.1163774f,81.16245f,-5.653398f,28.14437f,20.556326f,1.0628568f,-10.651501f ) ;
  }

  @Test
  public void test849() {
    color.laplace.solve(54.4316f,97.36357f,100.0f,20.362825f,30.323154f,37.142864f,-3.3034549f,-33.576645f,-100.0f ) ;
  }

  @Test
  public void test850() {
    color.laplace.solve(-55.19754f,2.6470673f,-36.434223f,-41.29956f,-20.119556f,-7.7810674f,-89.88115f,-34.044662f,67.93526f ) ;
  }

  @Test
  public void test851() {
    color.laplace.solve(55.368416f,81.191055f,69.3958f,40.282608f,100.0f,-28.994692f,87.04696f,69.7856f,0f ) ;
  }

  @Test
  public void test852() {
    color.laplace.solve(55.54459f,43.498917f,-10.011113f,78.67944f,28.462185f,-100.0f,28.515757f,35.383583f,84.5564f ) ;
  }

  @Test
  public void test853() {
    color.laplace.solve(55.660007f,97.110115f,94.4517f,25.304403f,36.044125f,9.012458f,9.513483f,12.749526f,5.440496f ) ;
  }

  @Test
  public void test854() {
    color.laplace.solve(55.81986f,23.281847f,20.09843f,99.99759f,-82.79089f,-42.88813f,21.03715f,-15.848987f,-1.6421989f ) ;
  }

  @Test
  public void test855() {
    color.laplace.solve(55.83675f,41.302353f,-31.574707f,82.04465f,40.947372f,-56.006756f,0f,0f,0f ) ;
  }

  @Test
  public void test856() {
    color.laplace.solve(-56.145905f,-119.6275f,38.19999f,-29.222612f,-45.286015f,-9.43655f,-13.3403845f,-22.791695f,-30.422234f ) ;
  }

  @Test
  public void test857() {
    color.laplace.solve(56.249508f,60.090973f,-15.497552f,64.90706f,99.61194f,-41.551994f,19.934315f,14.830204f,17.494452f ) ;
  }

  @Test
  public void test858() {
    color.laplace.solve(56.34075f,36.85783f,43.099422f,88.50518f,-52.008854f,35.539856f,23.339743f,4.8537908f,48.084274f ) ;
  }

  @Test
  public void test859() {
    color.laplace.solve(-5.651577f,97.93237f,0f,-5.722829f,-8.496184f,-100.0f,-8.743553f,-29.251385f,-99.7658f ) ;
  }

  @Test
  public void test860() {
    color.laplace.solve(56.639572f,98.31367f,-56.996807f,28.244623f,41.316795f,54.002983f,15.022128f,31.843891f,71.03664f ) ;
  }

  @Test
  public void test861() {
    color.laplace.solve(56.658936f,62.143948f,56.302185f,64.4918f,35.614666f,-36.51504f,17.132023f,4.036286f,-36.601543f ) ;
  }

  @Test
  public void test862() {
    color.laplace.solve(56.664112f,-76.11805f,98.516785f,8.119613f,-24.205923f,-20.786674f,0.020259028f,-8.038576f,-7.968642f ) ;
  }

  @Test
  public void test863() {
    color.laplace.solve(56.741264f,98.88741f,75.83091f,28.078285f,44.292942f,33.16886f,11.277289f,17.030872f,12.551649f ) ;
  }

  @Test
  public void test864() {
    color.laplace.solve(-56.81718f,39.987423f,-92.06128f,-4.322346f,36.41908f,93.253586f,3.108718f,16.757652f,27.50281f ) ;
  }

  @Test
  public void test865() {
    color.laplace.solve(56.829887f,54.560974f,39.436214f,72.758575f,21.980125f,3.1672647f,21.119932f,11.70635f,3.7187023f ) ;
  }

  @Test
  public void test866() {
    color.laplace.solve(5.685034f,-66.42313f,-3.6843286f,-10.83674f,-37.726395f,-39.260075f,-11.305595f,-34.385643f,-99.607445f ) ;
  }

  @Test
  public void test867() {
    color.laplace.solve(-57.024902f,-26.479406f,0f,29.789873f,30.342627f,0f,11.688095f,16.962505f,25.8193f ) ;
  }

  @Test
  public void test868() {
    color.laplace.solve(5.707766f,22.831064f,30.42508f,-100.0f,-44.808586f,-1.1307504f,-22.835665f,8.65734f,-18.686653f ) ;
  }

  @Test
  public void test869() {
    color.laplace.solve(57.167793f,80.26886f,64.233986f,48.402317f,99.67367f,76.66709f,36.76781f,98.66893f,53.958786f ) ;
  }

  @Test
  public void test870() {
    color.laplace.solve(57.261528f,93.37596f,25.548952f,35.670143f,31.89347f,-48.59269f,53.525574f,47.120464f,15.134857f ) ;
  }

  @Test
  public void test871() {
    color.laplace.solve(57.456013f,39.73235f,-13.9243965f,15.847052f,5.6492524f,-18.267115f,0.28294325f,-14.715279f,-64.79331f ) ;
  }

  @Test
  public void test872() {
    color.laplace.solve(57.5035f,55.181973f,24.473259f,25.54366f,31.12257f,15.114051f,13.548564f,28.650597f,69.93125f ) ;
  }

  @Test
  public void test873() {
    color.laplace.solve(57.73593f,100.0f,0f,-37.29691f,90.7219f,0f,-10.2908535f,-3.8665044f,-95.897064f ) ;
  }

  @Test
  public void test874() {
    color.laplace.solve(-57.898182f,26.47375f,0f,10.521571f,16.991972f,0f,82.99249f,0f,0f ) ;
  }

  @Test
  public void test875() {
    color.laplace.solve(58.131428f,28.226847f,0f,11.943261f,-16.83189f,76.456764f,6.4735065f,13.950765f,66.161446f ) ;
  }

  @Test
  public void test876() {
    color.laplace.solve(58.950443f,-36.32919f,0f,5.266126f,-28.43122f,-16.987656f,-9.4547205f,-41.728695f,0f ) ;
  }

  @Test
  public void test877() {
    color.laplace.solve(-5.9147615f,-77.30353f,-22.724371f,-46.355522f,-33.258636f,0f,-26.983757f,-61.57951f,100.0f ) ;
  }

  @Test
  public void test878() {
    color.laplace.solve(59.1862f,74.47229f,47.310143f,62.272507f,91.39281f,14.768286f,98.511024f,35.79546f,0f ) ;
  }

  @Test
  public void test879() {
    color.laplace.solve(59.715557f,38.868195f,37.24116f,99.994026f,-41.48394f,5.7600956f,14.758626f,-40.959526f,-19.143917f ) ;
  }

  @Test
  public void test880() {
    color.laplace.solve(59.820045f,-28.900997f,55.88041f,20.838127f,12.390521f,38.798218f,11.141943f,18.826738f,81.581375f ) ;
  }

  @Test
  public void test881() {
    color.laplace.solve(-60.030933f,-91.238235f,84.5807f,-16.724327f,-2.9212716f,95.33357f,-3.945106f,0.9439038f,10.641993f ) ;
  }

  @Test
  public void test882() {
    color.laplace.solve(60.056236f,-29.535448f,-13.509018f,14.587395f,-5.197909f,-5.041591f,3.4463763f,-0.79622686f,-1.4594378f ) ;
  }

  @Test
  public void test883() {
    color.laplace.solve(60.189827f,54.09839f,-8.5595255f,0.11783079f,7.247504f,-22.636473f,-66.96601f,-2.5897322f,-89.233864f ) ;
  }

  @Test
  public void test884() {
    color.laplace.solve(6.0236926f,8.661269f,25.520319f,-84.5665f,-96.89893f,-6.579993f,-22.642603f,-6.003912f,100.0f ) ;
  }

  @Test
  public void test885() {
    color.laplace.solve(60.480133f,-91.763115f,100.0f,1.0742223f,-51.15987f,-92.78286f,-5.023375f,-21.167723f,-28.487646f ) ;
  }

  @Test
  public void test886() {
    color.laplace.solve(61.241722f,100.0f,0f,-70.58298f,61.633213f,-32.292515f,-8.046579f,38.39666f,100.0f ) ;
  }

  @Test
  public void test887() {
    color.laplace.solve(-61.395267f,100.0f,1.3916024f,-15.89124f,6.19111f,-41.79235f,-8.360803f,-17.55197f,8.6799135f ) ;
  }

  @Test
  public void test888() {
    color.laplace.solve(61.417374f,59.815044f,55.1471f,85.85444f,22.695715f,60.773346f,-56.41125f,-60.340885f,0f ) ;
  }

  @Test
  public void test889() {
    color.laplace.solve(61.525623f,97.712364f,97.31174f,48.39013f,3.1083114f,0f,19.608648f,30.044464f,97.46089f ) ;
  }

  @Test
  public void test890() {
    color.laplace.solve(6.157292f,-68.24541f,51.62366f,-16.207466f,-42.634384f,11.118966f,-28.352774f,-97.20363f,35.486584f ) ;
  }

  @Test
  public void test891() {
    color.laplace.solve(61.77842f,-2.7123942f,0f,16.251495f,-0.35095102f,60.752293f,3.5785167f,-1.9374294f,-10.9772835f ) ;
  }

  @Test
  public void test892() {
    color.laplace.solve(6.2074904f,7.900907f,-10.519475f,-78.36274f,-63.840332f,-177.97267f,-256.0632f,-5.674657f,-53.16514f ) ;
  }

  @Test
  public void test893() {
    color.laplace.solve(-62.148285f,-30.67939f,0f,2.780356f,23.269802f,0f,-38.9217f,0f,0f ) ;
  }

  @Test
  public void test894() {
    color.laplace.solve(62.69388f,15.776264f,0f,57.589554f,-64.01203f,0f,30.6042f,-31.208115f,0f ) ;
  }

  @Test
  public void test895() {
    color.laplace.solve(62.770535f,57.860962f,71.87533f,25.89545f,31.1678f,28.23638f,9.643466f,12.678412f,9.902383f ) ;
  }

  @Test
  public void test896() {
    color.laplace.solve(62.976154f,-5.117615f,19.614084f,25.395382f,19.925308f,10.154824f,18.680067f,49.268646f,12.957137f ) ;
  }

  @Test
  public void test897() {
    color.laplace.solve(-63.10136f,-87.888855f,0f,42.288715f,80.98341f,0f,18.976906f,33.618904f,40.60132f ) ;
  }

  @Test
  public void test898() {
    color.laplace.solve(64.247604f,86.890854f,-15.261601f,70.09958f,-87.81725f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test899() {
    color.laplace.solve(64.4574f,66.077644f,39.21265f,91.75195f,60.64053f,-59.687645f,39.178497f,64.96203f,0f ) ;
  }

  @Test
  public void test900() {
    color.laplace.solve(64.88495f,98.29249f,8.307124f,61.24731f,-30.163963f,0f,0.30908445f,-60.010975f,27.720371f ) ;
  }

  @Test
  public void test901() {
    color.laplace.solve(65.313324f,99.19061f,0f,2.4946756f,-59.76254f,0f,-0.18236886f,-3.2241511f,47.0483f ) ;
  }

  @Test
  public void test902() {
    color.laplace.solve(6.5386868f,24.30097f,29.00397f,-98.146225f,-38.338776f,-8.285097f,-23.518757f,4.0711985f,78.14233f ) ;
  }

  @Test
  public void test903() {
    color.laplace.solve(65.393845f,79.15725f,0f,-74.3095f,-87.15657f,0f,-50.35095f,54.787716f,0f ) ;
  }

  @Test
  public void test904() {
    color.laplace.solve(65.93697f,-40.62629f,-21.129114f,13.572362f,-12.744615f,-14.7405405f,1.0970935f,-9.183989f,-25.088434f ) ;
  }

  @Test
  public void test905() {
    color.laplace.solve(65.96266f,63.850643f,33.830715f,100.0f,55.60919f,-28.52778f,28.034096f,12.136383f,-35.09775f ) ;
  }

  @Test
  public void test906() {
    color.laplace.solve(6.6981816f,-71.5287f,-33.641666f,-1.6785713f,-15.711937f,-0.5169235f,2.29947f,10.8764515f,47.285908f ) ;
  }

  @Test
  public void test907() {
    color.laplace.solve(6.713259f,10.474384f,-50.168667f,-0.54071f,-5.9844117f,-22.845284f,-2.8916872f,-11.026038f,-35.228054f ) ;
  }

  @Test
  public void test908() {
    color.laplace.solve(-67.855095f,-96.82083f,0f,37.118004f,75.843895f,-71.504486f,14.082878f,19.213509f,-13.072744f ) ;
  }

  @Test
  public void test909() {
    color.laplace.solve(-68.062325f,-4.845404f,-49.549915f,-27.180044f,-21.906618f,-7.7761493f,-18.75123f,-47.824875f,40.351936f ) ;
  }

  @Test
  public void test910() {
    color.laplace.solve(6.837092f,-99.48936f,-34.955566f,26.837725f,98.3618f,4.9059796f,2.152003f,-18.229712f,0f ) ;
  }

  @Test
  public void test911() {
    color.laplace.solve(69.55228f,87.03212f,79.99183f,91.17698f,98.58437f,55.43777f,36.58173f,55.149933f,85.433624f ) ;
  }

  @Test
  public void test912() {
    color.laplace.solve(6.960455f,12.389049f,-24.28274f,-84.547226f,-33.12152f,41.512856f,-24.623535f,-13.946912f,1.9574084f ) ;
  }

  @Test
  public void test913() {
    color.laplace.solve(7.0866747f,-69.59258f,100.0f,-2.0607214f,-13.962667f,19.209482f,-1.3668926f,-3.4068491f,1.7021632f ) ;
  }

  @Test
  public void test914() {
    color.laplace.solve(70.87201f,-93.98125f,0f,28.521187f,42.635628f,5.605782f,0.5771158f,-55.919167f,0f ) ;
  }

  @Test
  public void test915() {
    color.laplace.solve(71.076454f,-86.86082f,0f,15.990948f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test916() {
    color.laplace.solve(7.2046423f,-59.466724f,-396.80243f,-12.179621f,-42.405163f,-60.474224f,-12.410338f,-37.244102f,-93.77728f ) ;
  }

  @Test
  public void test917() {
    color.laplace.solve(72.316284f,-12.850566f,0f,32.525227f,-40.701958f,41.097652f,1.190498f,-27.763233f,-71.54147f ) ;
  }

  @Test
  public void test918() {
    color.laplace.solve(-74.614975f,12.791007f,63.35378f,-29.054054f,-29.586975f,-83.081856f,-12.014263f,-19.002998f,-34.41075f ) ;
  }

  @Test
  public void test919() {
    color.laplace.solve(7.496098f,-76.93871f,19.01723f,6.923102f,1.4306213f,7.5984383f,18.76569f,68.139656f,9.945902f ) ;
  }

  @Test
  public void test920() {
    color.laplace.solve(7.51463f,16.620071f,53.4486f,-86.561554f,-94.48295f,97.17433f,-28.199656f,-26.237072f,17.734314f ) ;
  }

  @Test
  public void test921() {
    color.laplace.solve(75.41359f,39.889484f,0f,21.417461f,-45.160282f,31.347948f,55.41654f,-71.06724f,0f ) ;
  }

  @Test
  public void test922() {
    color.laplace.solve(7.5892305f,94.80697f,-65.32169f,3.232584f,11.751998f,-22.155407f,-6.410892f,-28.876152f,96.48107f ) ;
  }

  @Test
  public void test923() {
    color.laplace.solve(76.598335f,173.23445f,100.236176f,41.228073f,74.48017f,76.342804f,12.441929f,7.022945f,-137.66495f ) ;
  }

  @Test
  public void test924() {
    color.laplace.solve(-76.890366f,-38.759556f,0f,-16.956673f,-34.19346f,-84.08166f,43.257133f,3.0240512f,0f ) ;
  }

  @Test
  public void test925() {
    color.laplace.solve(-77.98214f,7.555152f,0f,-10.359755f,27.331957f,-33.871037f,-1.4274915f,4.6497884f,-7.3053117f ) ;
  }

  @Test
  public void test926() {
    color.laplace.solve(7.9101577f,-66.04517f,68.216515f,-2.314199f,-17.157187f,-2.5445023f,-0.009767552f,2.2751288f,-63.584118f ) ;
  }

  @Test
  public void test927() {
    color.laplace.solve(-79.13928f,72.10697f,-36.060352f,-25.103897f,29.95298f,44.524166f,-51.22929f,28.284676f,-7.4660726f ) ;
  }

  @Test
  public void test928() {
    color.laplace.solve(7.934441f,-62.67595f,-51.65323f,-5.5862846f,-27.651213f,-37.415432f,-2.628367f,-4.927183f,10.5708475f ) ;
  }

  @Test
  public void test929() {
    color.laplace.solve(79.36638f,-85.18695f,0f,40.614067f,68.64471f,-74.860085f,14.445174f,17.16663f,-14.423363f ) ;
  }

  @Test
  public void test930() {
    color.laplace.solve(8.053055f,-7.303729f,-80.79075f,-60.48405f,-56.477222f,-37.943363f,16.846119f,0f,0f ) ;
  }

  @Test
  public void test931() {
    color.laplace.solve(81.52235f,-0.64668554f,100.0f,32.46403f,35.476753f,91.125626f,12.857019f,18.964048f,27.522419f ) ;
  }

  @Test
  public void test932() {
    color.laplace.solve(81.54159f,-33.85468f,0f,-72.59604f,15.995003f,0f,55.88131f,37.04535f,0f ) ;
  }

  @Test
  public void test933() {
    color.laplace.solve(-83.365944f,77.12956f,-61.595963f,-27.136806f,14.895329f,-51.031914f,-40.07661f,60.620476f,42.90424f ) ;
  }

  @Test
  public void test934() {
    color.laplace.solve(-83.422226f,30.495615f,100.0f,-17.551035f,12.781845f,18.886822f,0.4362359f,19.295979f,63.965836f ) ;
  }

  @Test
  public void test935() {
    color.laplace.solve(83.43153f,-100.0f,0f,-100.0f,-100.0f,0f,-46.857494f,-87.42998f,-41.727993f ) ;
  }

  @Test
  public void test936() {
    color.laplace.solve(-83.52175f,25.243864f,0f,-47.555187f,-24.029104f,76.2737f,-82.66988f,56.030018f,0f ) ;
  }

  @Test
  public void test937() {
    color.laplace.solve(84.88491f,36.703186f,0f,39.810997f,59.926483f,62.562992f,14.432589f,17.919361f,0f ) ;
  }

  @Test
  public void test938() {
    color.laplace.solve(8.556623f,-63.44919f,-7.8568773f,-2.3243198f,-16.627542f,-99.99986f,-1.2263604f,-2.581122f,7.529415f ) ;
  }

  @Test
  public void test939() {
    color.laplace.solve(87.73699f,24.606564f,0f,57.167755f,-56.561802f,0f,61.52462f,0f,0f ) ;
  }

  @Test
  public void test940() {
    color.laplace.solve(-87.85306f,100.0f,-100.0f,-33.997314f,-14.917441f,-26.794744f,-33.218758f,-98.87771f,87.80771f ) ;
  }

  @Test
  public void test941() {
    color.laplace.solve(89.65284f,-50.873928f,36.97827f,22.169476f,-6.4987087f,2.7839983f,5.523773f,-0.07438299f,0.6774038f ) ;
  }

  @Test
  public void test942() {
    color.laplace.solve(-9.028319f,-16.275232f,22.75945f,-3.926959f,-5.2667947f,0.8589542f,-1.4127251f,-1.7239411f,-0.21624695f ) ;
  }

  @Test
  public void test943() {
    color.laplace.solve(90.76095f,-99.370735f,0f,-40.919334f,89.716385f,0f,91.61616f,0f,0f ) ;
  }

  @Test
  public void test944() {
    color.laplace.solve(9.098495f,35.836006f,41.190907f,-99.442024f,-6.9453754f,28.927612f,-21.842636f,12.071482f,77.073944f ) ;
  }

  @Test
  public void test945() {
    color.laplace.solve(-91.02494f,181.38591f,0f,-6.4593167f,63.098675f,112.16772f,6.1579943f,28.235056f,34.788464f ) ;
  }

  @Test
  public void test946() {
    color.laplace.solve(91.248886f,-76.531624f,0f,26.033243f,-32.908783f,-69.75955f,4.925444f,-6.331466f,2.6574745f ) ;
  }

  @Test
  public void test947() {
    color.laplace.solve(92.959465f,-2.650163f,70.80611f,23.509138f,2.449439f,30.846844f,-1.3723505f,-41.908062f,50.131832f ) ;
  }

  @Test
  public void test948() {
    color.laplace.solve(9.458037f,60.934578f,0f,-90.41367f,-44.857704f,-48.94394f,-28.29607f,-22.770603f,-17.928635f ) ;
  }

  @Test
  public void test949() {
    color.laplace.solve(-94.79366f,63.222347f,0f,13.156783f,26.103004f,32.598206f,5.0150704f,6.903499f,-3.504078f ) ;
  }

  @Test
  public void test950() {
    color.laplace.solve(-95.28065f,11.926917f,-3.215254f,-26.336819f,0.5393557f,32.654415f,-10.605977f,-16.087091f,-54.281742f ) ;
  }

  @Test
  public void test951() {
    color.laplace.solve(-95.40355f,5.4050617f,59.231617f,-25.955873f,-1.6243213f,15.2801695f,-6.795629f,-1.2266421f,3.5133817f ) ;
  }

  @Test
  public void test952() {
    color.laplace.solve(-95.473946f,79.36793f,-8.428884f,-22.869219f,-18.41035f,-30.140112f,22.407423f,-100.0f,-93.721214f ) ;
  }

  @Test
  public void test953() {
    color.laplace.solve(9.693694f,-58.084637f,-43.63883f,-3.140588f,-20.183092f,-14.355914f,-2.0729544f,-5.15123f,1.651126f ) ;
  }

  @Test
  public void test954() {
    color.laplace.solve(9.736755f,-68.23634f,2.1358197f,7.183362f,-40.621574f,31.6011f,59.618267f,1.1933526f,0f ) ;
  }

  @Test
  public void test955() {
    color.laplace.solve(-97.49212f,-4.8800807f,0f,-43.830444f,-31.00409f,-38.366608f,-11.020728f,-0.2524675f,41.014946f ) ;
  }

  @Test
  public void test956() {
    color.laplace.solve(97.857346f,100.0f,0f,8.298725f,-57.367992f,-89.7629f,-7.2944527f,-37.476536f,-40.250084f ) ;
  }

  @Test
  public void test957() {
    color.laplace.solve(98.42523f,-41.473827f,0f,95.06078f,-86.42574f,0f,-50.31038f,71.040955f,0f ) ;
  }

  @Test
  public void test958() {
    color.laplace.solve(-99.999794f,-17.149212f,0f,-27.804834f,-3.504809f,34.62151f,-7.714738f,-3.0541165f,-0.9969193f ) ;
  }
}
