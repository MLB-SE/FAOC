import org.junit.Test;

public class JpfTargetunconstrainedTest {

  @Test
  public void test0() {
    bound.unconstrained.solve(101,0,0,0 ) ;
  }

  @Test
  public void test1() {
    bound.unconstrained.solve(10,988,0,0 ) ;
  }

  @Test
  public void test2() {
    bound.unconstrained.solve(292,0,0,0 ) ;
  }

  @Test
  public void test3() {
    bound.unconstrained.solve(3,1,6,1 ) ;
  }

  @Test
  public void test4() {
    bound.unconstrained.solve(3,4,0,0 ) ;
  }

  @Test
  public void test5() {
    bound.unconstrained.solve(3,8,3,8 ) ;
  }

  @Test
  public void test6() {
    bound.unconstrained.solve(4,2,8,-885 ) ;
  }

  @Test
  public void test7() {
    bound.unconstrained.solve(6,10,633,0 ) ;
  }

  @Test
  public void test8() {
    bound.unconstrained.solve(6,-416,0,0 ) ;
  }

  @Test
  public void test9() {
    bound.unconstrained.solve(6,4,7,0 ) ;
  }

  @Test
  public void test10() {
    bound.unconstrained.solve(6,73,0,0 ) ;
  }

  @Test
  public void test11() {
    bound.unconstrained.solve(6,7,817,0 ) ;
  }

  @Test
  public void test12() {
    bound.unconstrained.solve(-688,0,0,0 ) ;
  }

  @Test
  public void test13() {
    bound.unconstrained.solve(7,3,2,8 ) ;
  }

  @Test
  public void test14() {
    bound.unconstrained.solve(7,7,7,7 ) ;
  }

  @Test
  public void test15() {
    bound.unconstrained.solve(7,8,9,2 ) ;
  }

  @Test
  public void test16() {
    bound.unconstrained.solve(8,10,-202,0 ) ;
  }

  @Test
  public void test17() {
    bound.unconstrained.solve(8,4,1,7 ) ;
  }

  @Test
  public void test18() {
    bound.unconstrained.solve(9,0,0,0 ) ;
  }

  @Test
  public void test19() {
    bound.unconstrained.solve(9,5,5,409 ) ;
  }

  @Test
  public void test20() {
    bound.unconstrained.solve(9,6,6,887 ) ;
  }
}
