import org.junit.Test;

public class JpfTargetallintervalTest {

  @Test
  public void test0() {
    bound.allinterval.solve(1,3,0,0 ) ;
  }

  @Test
  public void test1() {
    bound.allinterval.solve(1,4,1,94 ) ;
  }

  @Test
  public void test2() {
    bound.allinterval.solve(1,4,3,2 ) ;
  }

  @Test
  public void test3() {
    bound.allinterval.solve(1,4,475,0 ) ;
  }

  @Test
  public void test4() {
    bound.allinterval.solve(188,0,0,0 ) ;
  }

  @Test
  public void test5() {
    bound.allinterval.solve(2,1,1,4 ) ;
  }

  @Test
  public void test6() {
    bound.allinterval.solve(2,1,2,1 ) ;
  }

  @Test
  public void test7() {
    bound.allinterval.solve(2,2,-786,0 ) ;
  }

  @Test
  public void test8() {
    bound.allinterval.solve(2,482,0,0 ) ;
  }

  @Test
  public void test9() {
    bound.allinterval.solve(2,97,0,0 ) ;
  }

  @Test
  public void test10() {
    bound.allinterval.solve(3,1,4,4 ) ;
  }

  @Test
  public void test11() {
    bound.allinterval.solve(3,2,2,3 ) ;
  }

  @Test
  public void test12() {
    bound.allinterval.solve(3,2,4,-563 ) ;
  }

  @Test
  public void test13() {
    bound.allinterval.solve(4,0,0,0 ) ;
  }

  @Test
  public void test14() {
    bound.allinterval.solve(4,1,1,166 ) ;
  }

  @Test
  public void test15() {
    bound.allinterval.solve(4,2,1,4 ) ;
  }

  @Test
  public void test16() {
    bound.allinterval.solve(4,3,1,0 ) ;
  }

  @Test
  public void test17() {
    bound.allinterval.solve(4,3,382,0 ) ;
  }

  @Test
  public void test18() {
    bound.allinterval.solve(4,-744,0,0 ) ;
  }

  @Test
  public void test19() {
    bound.allinterval.solve(654,0,0,0 ) ;
  }

  @Test
  public void test20() {
    bound.allinterval.solve(-803,0,0,0 ) ;
  }
}
