import org.junit.Test;

public class JpfTargetgroceryTest {

  @Test
  public void test0() {
    bound.grocery.solve(103,0,0,0 ) ;
  }

  @Test
  public void test1() {
    bound.grocery.solve(137,2,498,74 ) ;
  }

  @Test
  public void test2() {
    bound.grocery.solve(17,87,123,650 ) ;
  }

  @Test
  public void test3() {
    bound.grocery.solve(188,774,0,0 ) ;
  }

  @Test
  public void test4() {
    bound.grocery.solve(190,0,0,0 ) ;
  }

  @Test
  public void test5() {
    bound.grocery.solve(191,466,605,-703 ) ;
  }

  @Test
  public void test6() {
    bound.grocery.solve(240,150,15,306 ) ;
  }

  @Test
  public void test7() {
    bound.grocery.solve(344,838,0,0 ) ;
  }

  @Test
  public void test8() {
    bound.grocery.solve(-395,0,0,0 ) ;
  }

  @Test
  public void test9() {
    bound.grocery.solve(400,638,626,0 ) ;
  }

  @Test
  public void test10() {
    bound.grocery.solve(467,441,-5,0 ) ;
  }

  @Test
  public void test11() {
    bound.grocery.solve(492,7,0,0 ) ;
  }

  @Test
  public void test12() {
    bound.grocery.solve(50,57,577,434 ) ;
  }

  @Test
  public void test13() {
    bound.grocery.solve(521,100,65,845 ) ;
  }

  @Test
  public void test14() {
    bound.grocery.solve(531,-625,0,0 ) ;
  }

  @Test
  public void test15() {
    bound.grocery.solve(5,432,13,261 ) ;
  }

  @Test
  public void test16() {
    bound.grocery.solve(556,8,144,3 ) ;
  }

  @Test
  public void test17() {
    bound.grocery.solve(616,26,68,1 ) ;
  }

  @Test
  public void test18() {
    bound.grocery.solve(618,32,50,11 ) ;
  }

  @Test
  public void test19() {
    bound.grocery.solve(682,294,412,0 ) ;
  }

  @Test
  public void test20() {
    bound.grocery.solve(682,508,629,432 ) ;
  }

  @Test
  public void test21() {
    bound.grocery.solve(79,22,383,227 ) ;
  }

  @Test
  public void test22() {
    bound.grocery.solve(83,114,232,282 ) ;
  }

  @Test
  public void test23() {
    bound.grocery.solve(88,134,27,462 ) ;
  }

  @Test
  public void test24() {
    bound.grocery.solve(9,169,1054,0 ) ;
  }

  @Test
  public void test25() {
    bound.grocery.solve(976,0,0,0 ) ;
  }
}
