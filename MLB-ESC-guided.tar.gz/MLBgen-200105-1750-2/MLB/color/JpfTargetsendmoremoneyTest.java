import org.junit.Test;

public class JpfTargetsendmoremoneyTest {

  @Test
  public void test0() {
    color.sendmoremoney.solve(0,0,5,4,4,1,0,0 ) ;
  }

  @Test
  public void test1() {
    color.sendmoremoney.solve(10,11,0,0,11,-9,-15,15 ) ;
  }

  @Test
  public void test2() {
    color.sendmoremoney.solve(1,0,1,792,0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    color.sendmoremoney.solve(10,-9,13,-9,7,10,-8,2 ) ;
  }

  @Test
  public void test4() {
    color.sendmoremoney.solve(12,0,-10,-18,22,12,11,7 ) ;
  }

  @Test
  public void test5() {
    color.sendmoremoney.solve(12,-11,2,12,4,-21,9,11 ) ;
  }

  @Test
  public void test6() {
    color.sendmoremoney.solve(13,8,3,0,-3,-2,-1564,0 ) ;
  }

  @Test
  public void test7() {
    color.sendmoremoney.solve(1,5,1,0,1,473,0,0 ) ;
  }

  @Test
  public void test8() {
    color.sendmoremoney.solve(1,5,4,-491,0,0,0,0 ) ;
  }

  @Test
  public void test9() {
    color.sendmoremoney.solve(1,5,8,1,6,9,6,0 ) ;
  }

  @Test
  public void test10() {
    color.sendmoremoney.solve(1,5,8,5,-755,0,0,0 ) ;
  }

  @Test
  public void test11() {
    color.sendmoremoney.solve(-16,4,15,18,4,-1,8,77 ) ;
  }

  @Test
  public void test12() {
    color.sendmoremoney.solve(1,6,5,7,6,860,0,0 ) ;
  }

  @Test
  public void test13() {
    color.sendmoremoney.solve(1,8,0,8,1,1,12,5 ) ;
  }

  @Test
  public void test14() {
    color.sendmoremoney.solve(1,8,3,4,1,8,7,0 ) ;
  }

  @Test
  public void test15() {
    color.sendmoremoney.solve(1,9,0,9,1,0,9,0 ) ;
  }

  @Test
  public void test16() {
    color.sendmoremoney.solve(1,9,0,9,1,4,3,3 ) ;
  }

  @Test
  public void test17() {
    color.sendmoremoney.solve(1,9,1,6,1,9,-645,0 ) ;
  }

  @Test
  public void test18() {
    color.sendmoremoney.solve(1,9,1,8,1,0,9,4 ) ;
  }

  @Test
  public void test19() {
    color.sendmoremoney.solve(2,4,4,1,2,1,-3,16 ) ;
  }

  @Test
  public void test20() {
    color.sendmoremoney.solve(2,570,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test21() {
    color.sendmoremoney.solve(26,3,8,9,-3,-15,-6,8 ) ;
  }

  @Test
  public void test22() {
    color.sendmoremoney.solve(2,733,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test23() {
    color.sendmoremoney.solve(28,6,26,1,-8,13,-22,10 ) ;
  }

  @Test
  public void test24() {
    color.sendmoremoney.solve(3,0,172,0,0,0,0,0 ) ;
  }

  @Test
  public void test25() {
    color.sendmoremoney.solve(3,-10,6,21,-21,-13,-22,-6 ) ;
  }

  @Test
  public void test26() {
    color.sendmoremoney.solve(3,3,9,5,1393,0,0,0 ) ;
  }

  @Test
  public void test27() {
    color.sendmoremoney.solve(3,4,1,5,0,0,0,0 ) ;
  }

  @Test
  public void test28() {
    color.sendmoremoney.solve(3,6,6,15,2,9,-3,35 ) ;
  }

  @Test
  public void test29() {
    color.sendmoremoney.solve(3,9,0,9,1,3,9,0 ) ;
  }

  @Test
  public void test30() {
    color.sendmoremoney.solve(3,9,1,11,-3,17,4,-5 ) ;
  }

  @Test
  public void test31() {
    color.sendmoremoney.solve(3,9,3,9,1,0,9,0 ) ;
  }

  @Test
  public void test32() {
    color.sendmoremoney.solve(4,0,4,3,5,6,4,0 ) ;
  }

  @Test
  public void test33() {
    color.sendmoremoney.solve(4,12,-15,8,5,10,-30,10 ) ;
  }

  @Test
  public void test34() {
    color.sendmoremoney.solve(4,5,-2,4,13,5,2,-1622 ) ;
  }

  @Test
  public void test35() {
    color.sendmoremoney.solve(4,7,1,766,0,0,0,0 ) ;
  }

  @Test
  public void test36() {
    color.sendmoremoney.solve(4,7,9,5,2,1,-1,1 ) ;
  }

  @Test
  public void test37() {
    color.sendmoremoney.solve(5,0,8,6,4,0,0,0 ) ;
  }

  @Test
  public void test38() {
    color.sendmoremoney.solve(5,0,9,5,4,1,0,0 ) ;
  }

  @Test
  public void test39() {
    color.sendmoremoney.solve(5,1,1,7,8,12,20,7 ) ;
  }

  @Test
  public void test40() {
    color.sendmoremoney.solve(5,9,0,5,1,1,8,0 ) ;
  }

  @Test
  public void test41() {
    color.sendmoremoney.solve(6,0,-10,-5,3,1,1091,0 ) ;
  }

  @Test
  public void test42() {
    color.sendmoremoney.solve(6,12,4,3,0,2,4,11 ) ;
  }

  @Test
  public void test43() {
    color.sendmoremoney.solve(6,1,2,7,8,9,7,-932 ) ;
  }

  @Test
  public void test44() {
    color.sendmoremoney.solve(6,1,5,6,2,3,16,16 ) ;
  }

  @Test
  public void test45() {
    color.sendmoremoney.solve(6,1,9,6,9,9,0,1058 ) ;
  }

  @Test
  public void test46() {
    color.sendmoremoney.solve(6,6,0,8,1,0,7,3 ) ;
  }

  @Test
  public void test47() {
    color.sendmoremoney.solve(6,6,0,9,1,0,9,0 ) ;
  }

  @Test
  public void test48() {
    color.sendmoremoney.solve(6,6,3,8,3,4,980,0 ) ;
  }

  @Test
  public void test49() {
    color.sendmoremoney.solve(7,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test50() {
    color.sendmoremoney.solve(7,0,-783,0,0,0,0,0 ) ;
  }

  @Test
  public void test51() {
    color.sendmoremoney.solve(7,1,4,9,6,-1099,0,0 ) ;
  }

  @Test
  public void test52() {
    color.sendmoremoney.solve(7,-19,-5,-17,1,-5,32,15 ) ;
  }

  @Test
  public void test53() {
    color.sendmoremoney.solve(74,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test54() {
    color.sendmoremoney.solve(7,4,2,6,1,6,3,7 ) ;
  }

  @Test
  public void test55() {
    color.sendmoremoney.solve(-749,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test56() {
    color.sendmoremoney.solve(7,5,-29,9,1,-12,1,19 ) ;
  }

  @Test
  public void test57() {
    color.sendmoremoney.solve(7,9,0,9,1,7,9,0 ) ;
  }

  @Test
  public void test58() {
    color.sendmoremoney.solve(7,-9,1,-4,1,1,11,5 ) ;
  }

  @Test
  public void test59() {
    color.sendmoremoney.solve(7,9,8,5,3,6,668,0 ) ;
  }

  @Test
  public void test60() {
    color.sendmoremoney.solve(8,1,10,6,4,3,12,0 ) ;
  }

  @Test
  public void test61() {
    color.sendmoremoney.solve(8,2,5,-4,4,8,10,244 ) ;
  }

  @Test
  public void test62() {
    color.sendmoremoney.solve(8,-5,-4,8,4,0,1,17 ) ;
  }

  @Test
  public void test63() {
    color.sendmoremoney.solve(8,9,0,8,1,0,9,0 ) ;
  }

  @Test
  public void test64() {
    color.sendmoremoney.solve(8,9,0,9,1,0,9,0 ) ;
  }

  @Test
  public void test65() {
    color.sendmoremoney.solve(8,9,8,9,1,0,9,0 ) ;
  }

  @Test
  public void test66() {
    color.sendmoremoney.solve(9,0,9,4,2,0,6,4 ) ;
  }

  @Test
  public void test67() {
    color.sendmoremoney.solve(-9,-11,-7,3,0,6,5,-5 ) ;
  }

  @Test
  public void test68() {
    color.sendmoremoney.solve(9,1,2,4,1,0,8,0 ) ;
  }

  @Test
  public void test69() {
    color.sendmoremoney.solve(9,1,2,9,1,0,8,0 ) ;
  }

  @Test
  public void test70() {
    color.sendmoremoney.solve(9,2,15,18,10,-39,4,517 ) ;
  }

  @Test
  public void test71() {
    color.sendmoremoney.solve(9,2,2,1,1,0,2,7 ) ;
  }

  @Test
  public void test72() {
    color.sendmoremoney.solve(9,-2,-3,14,5,-5,-10,2015 ) ;
  }

  @Test
  public void test73() {
    color.sendmoremoney.solve(9,2,3,5,1,0,9,7 ) ;
  }

  @Test
  public void test74() {
    color.sendmoremoney.solve(9,3,4,4,1,0,9,7 ) ;
  }

  @Test
  public void test75() {
    color.sendmoremoney.solve(9,3,5,4,1,9,8,-2 ) ;
  }

  @Test
  public void test76() {
    color.sendmoremoney.solve(9,4,5,4,1,0,9,8 ) ;
  }

  @Test
  public void test77() {
    color.sendmoremoney.solve(948,0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test78() {
    color.sendmoremoney.solve(9,6,3,17,2,3,2,5 ) ;
  }

  @Test
  public void test79() {
    color.sendmoremoney.solve(9,6,8,7,1,0,3,8 ) ;
  }

  @Test
  public void test80() {
    color.sendmoremoney.solve(9,7,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test81() {
    color.sendmoremoney.solve(9,-716,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test82() {
    color.sendmoremoney.solve(9,7,1,9,1,3,9,4 ) ;
  }

  @Test
  public void test83() {
    color.sendmoremoney.solve(9,7,404,0,0,0,0,0 ) ;
  }

  @Test
  public void test84() {
    color.sendmoremoney.solve(9,7,9,0,0,0,0,0 ) ;
  }

  @Test
  public void test85() {
    color.sendmoremoney.solve(9,8,0,3,1,9,8,4 ) ;
  }

  @Test
  public void test86() {
    color.sendmoremoney.solve(9,8,0,9,1,1,9,0 ) ;
  }

  @Test
  public void test87() {
    color.sendmoremoney.solve(9,8,1,9,2,4,8,2850 ) ;
  }

  @Test
  public void test88() {
    color.sendmoremoney.solve(9,8,4,8,1,1,8,5 ) ;
  }

  @Test
  public void test89() {
    color.sendmoremoney.solve(9,9,0,3,1,1,8,2 ) ;
  }

  @Test
  public void test90() {
    color.sendmoremoney.solve(9,9,0,4,1,1,8,3 ) ;
  }

  @Test
  public void test91() {
    color.sendmoremoney.solve(9,9,0,6,921,0,0,0 ) ;
  }
}
