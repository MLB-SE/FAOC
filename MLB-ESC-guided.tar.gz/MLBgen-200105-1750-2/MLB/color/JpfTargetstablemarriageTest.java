import org.junit.Test;

public class JpfTargetstablemarriageTest {

  @Test
  public void test0() {
    color.stablemarriage.solve(157,0 ) ;
  }

  @Test
  public void test1() {
    color.stablemarriage.solve(1,783 ) ;
  }

  @Test
  public void test2() {
    color.stablemarriage.solve(-297,0 ) ;
  }

  @Test
  public void test3() {
    color.stablemarriage.solve(406,0 ) ;
  }

  @Test
  public void test4() {
    color.stablemarriage.solve(4,3 ) ;
  }

  @Test
  public void test5() {
    color.stablemarriage.solve(4,-333 ) ;
  }

  @Test
  public void test6() {
    color.stablemarriage.solve(5,0 ) ;
  }

  @Test
  public void test7() {
    color.stablemarriage.solve(5,346 ) ;
  }
}
