import org.junit.Test;

public class JpfTargetlaplaceTest {

  @Test
  public void test0() {
    color.laplace.solve(-0.1292259f,-45.8328f,-63.48237f,-4.6276155f,-16.98129f,-16.492678f,-1.3999211f,-0.9720688f,14.492951f ) ;
  }

  @Test
  public void test1() {
    color.laplace.solve(-0.4251793f,-80.72929f,95.04896f,-20.97143f,-50.983406f,0f,-28.276316f,-92.133835f,0f ) ;
  }

  @Test
  public void test2() {
    color.laplace.solve(-0.9371136f,-93.67625f,-31.793985f,-10.07221f,-33.672913f,-18.300674f,-5.678692f,-12.642537f,-7.735796f ) ;
  }

  @Test
  public void test3() {
    color.laplace.solve(-100.0f,-5.7097297f,0f,-17.33906f,26.392511f,97.43027f,-1.0193856f,13.2615185f,27.672947f ) ;
  }

  @Test
  public void test4() {
    color.laplace.solve(-100.0f,-94.3878f,0f,1.1114032f,99.94605f,42.96457f,4.4995613f,16.886843f,-36.898247f ) ;
  }

  @Test
  public void test5() {
    color.laplace.solve(-100.0f,-99.959f,-26.340326f,-39.749718f,-44.759117f,-22.120243f,-14.238992f,-17.207512f,-9.831939f ) ;
  }

  @Test
  public void test6() {
    color.laplace.solve(-100.0f,-99.99938f,-88.49525f,-34.03981f,-20.434284f,81.16207f,-15.724956f,-28.860012f,-79.28081f ) ;
  }

  @Test
  public void test7() {
    color.laplace.solve(10.013501f,-45.934353f,-100.0f,-14.011643f,-58.43431f,16.868944f,-7.6257668f,-16.491425f,0.094380274f ) ;
  }

  @Test
  public void test8() {
    color.laplace.solve(10.123604f,14.65184f,-87.6689f,-74.157425f,36.152657f,79.18023f,16.446035f,80.046036f,0f ) ;
  }

  @Test
  public void test9() {
    color.laplace.solve(10.145758f,39.534626f,58.185795f,-98.9516f,-10.193043f,93.20856f,-21.874218f,11.454722f,77.74463f ) ;
  }

  @Test
  public void test10() {
    color.laplace.solve(10.168534f,-51.51277f,-60.074738f,-7.8130918f,-24.423372f,14.00876f,-16.997528f,-60.17702f,-47.46989f ) ;
  }

  @Test
  public void test11() {
    color.laplace.solve(10.206495f,57.24872f,0f,-24.149197f,57.942417f,0f,-3.9089696f,8.513319f,43.878326f ) ;
  }

  @Test
  public void test12() {
    color.laplace.solve(1.0684687f,-87.33967f,-50.74288f,-2.6090913f,-15.879043f,6.3266563f,4.3742094f,20.105928f,91.92855f ) ;
  }

  @Test
  public void test13() {
    color.laplace.solve(10.777876f,-29.892563f,-194.46252f,-12.326722f,-36.795414f,-89.80902f,-10.85035f,-15.590912f,-8.622263f ) ;
  }

  @Test
  public void test14() {
    color.laplace.solve(10.815987f,55.533215f,0f,60.21755f,52.402954f,0f,12.668191f,-9.544782f,22.226864f ) ;
  }

  @Test
  public void test15() {
    color.laplace.solve(10.82998f,-48.449482f,100.0f,-8.230599f,-38.331547f,-79.46827f,-6.3153667f,-17.186052f,-24.157547f ) ;
  }

  @Test
  public void test16() {
    color.laplace.solve(-10.934462f,62.25611f,0f,-19.425827f,-3.4673982f,54.940243f,-63.30145f,15.088804f,0f ) ;
  }

  @Test
  public void test17() {
    color.laplace.solve(10.94009f,-57.74681f,11.565406f,1.5071707f,-5.5152764f,33.270226f,0.6038693f,0.9083065f,8.544633f ) ;
  }

  @Test
  public void test18() {
    color.laplace.solve(1.1035386f,7.9245343f,44.94067f,-103.62554f,-114.80151f,71.81912f,-38.923405f,-52.2144f,-55.141506f ) ;
  }

  @Test
  public void test19() {
    color.laplace.solve(-11.199851f,84.131966f,0f,24.59884f,60.9358f,0f,17.124563f,0f,0f ) ;
  }

  @Test
  public void test20() {
    color.laplace.solve(11.219077f,-57.697956f,74.28967f,2.574267f,-3.2515197f,35.37468f,2.3293004f,6.7429347f,70.460556f ) ;
  }

  @Test
  public void test21() {
    color.laplace.solve(11.476225f,-53.982414f,-19.728424f,-0.112687156f,47.7214f,36.678604f,4.0334625f,16.246538f,13.231286f ) ;
  }

  @Test
  public void test22() {
    color.laplace.solve(11.564493f,-77.7414f,99.99997f,23.999378f,14.1904f,77.9524f,70.24262f,32.55123f,-71.42004f ) ;
  }

  @Test
  public void test23() {
    color.laplace.solve(11.584213f,59.58395f,0f,-75.41489f,-12.633311f,0f,41.825523f,0f,0f ) ;
  }

  @Test
  public void test24() {
    color.laplace.solve(12.13013f,-60.128197f,23.768553f,8.648715f,20.768553f,33.02266f,1.6961775f,-1.8640051f,-29.920752f ) ;
  }

  @Test
  public void test25() {
    color.laplace.solve(-12.173494f,35.52065f,-41.763306f,-1.4645663f,6.424461f,-9.385879f,-0.109231755f,1.0276396f,-2.2046704f ) ;
  }

  @Test
  public void test26() {
    color.laplace.solve(12.434966f,-72.31273f,-9.119395f,22.052597f,64.04962f,69.65709f,11.725796f,24.850582f,23.626911f ) ;
  }

  @Test
  public void test27() {
    color.laplace.solve(12.612147f,-66.02067f,43.78675f,16.469254f,46.898388f,-2.6264033f,6.3664813f,8.996671f,-20.768255f ) ;
  }

  @Test
  public void test28() {
    color.laplace.solve(12.678665f,-56.30468f,0f,13.314728f,33.797714f,-64.21832f,6.7825327f,13.815403f,14.681366f ) ;
  }

  @Test
  public void test29() {
    color.laplace.solve(12.708949f,-41.2387f,-61.215637f,-7.9255037f,-100.0f,0f,-4.6640816f,-10.730823f,36.089516f ) ;
  }

  @Test
  public void test30() {
    color.laplace.solve(12.788305f,73.42785f,0f,30.050209f,60.956596f,0f,15.000978f,29.953703f,-36.559002f ) ;
  }

  @Test
  public void test31() {
    color.laplace.solve(12.796344f,-40.823326f,-99.99773f,-7.9912963f,-28.370178f,-7.091976f,-16.391352f,-57.57411f,100.0f ) ;
  }

  @Test
  public void test32() {
    color.laplace.solve(1.2955105f,-82.75374f,-9.235079f,-12.064219f,-43.041615f,-63.36963f,-6.5107727f,-13.978872f,-6.363101f ) ;
  }

  @Test
  public void test33() {
    color.laplace.solve(13.139984f,21.248974f,0f,0.8134595f,-10.051856f,-45.14801f,0.16570964f,-0.15062094f,9.283662f ) ;
  }

  @Test
  public void test34() {
    color.laplace.solve(13.455665f,-47.424255f,92.08645f,1.2469164f,-8.444235f,13.742375f,-0.02376462f,-1.3419749f,3.1001f ) ;
  }

  @Test
  public void test35() {
    color.laplace.solve(13.4781275f,-46.9368f,-100.0f,0.85012907f,-9.769619f,9.090293f,-0.3079927f,-2.0814214f,1.7522517f ) ;
  }

  @Test
  public void test36() {
    color.laplace.solve(-1.3612553f,-100.0f,-100.0f,-5.445021f,-13.359728f,-98.30964f,-7.0591025f,-22.79139f,-70.74673f ) ;
  }

  @Test
  public void test37() {
    color.laplace.solve(13.769546f,-48.217457f,26.528196f,3.2956417f,-9.412815f,0f,6.8702836f,24.185493f,99.2845f ) ;
  }

  @Test
  public void test38() {
    color.laplace.solve(1.3886236f,-24.570219f,-99.998055f,-4.6998997f,-17.133833f,-31.750795f,-3.05439f,-7.514419f,-9.813853f ) ;
  }

  @Test
  public void test39() {
    color.laplace.solve(-13.90407f,-145.95468f,48.885468f,-9.598824f,-58.296513f,22.101994f,34.179714f,-100.0f,-76.631294f ) ;
  }

  @Test
  public void test40() {
    color.laplace.solve(14.110526f,8.319336f,107.08746f,-51.760117f,-188.01358f,137.45184f,-32.938126f,-79.88454f,-97.52182f ) ;
  }

  @Test
  public void test41() {
    color.laplace.solve(14.112269f,-43.85136f,8.002667f,0.30043945f,-12.102775f,-1.3287878f,-0.8077374f,-3.531389f,-1.2150441f ) ;
  }

  @Test
  public void test42() {
    color.laplace.solve(14.171065f,-45.756966f,-64.09546f,2.4412262f,-8.371898f,-3.593576f,3.9657373f,13.421723f,58.093052f ) ;
  }

  @Test
  public void test43() {
    color.laplace.solve(-14.212699f,-59.832508f,0f,-31.03046f,-13.4865465f,0f,-96.4226f,0f,0f ) ;
  }

  @Test
  public void test44() {
    color.laplace.solve(14.441902f,7.441076f,12.846672f,-49.67347f,-97.52427f,-56.05439f,-21.272383f,-35.416065f,-22.867615f ) ;
  }

  @Test
  public void test45() {
    color.laplace.solve(14.535119f,-42.94985f,-81.73067f,1.0903233f,-12.197446f,-13.934416f,2.0236201f,7.004157f,38.190453f ) ;
  }

  @Test
  public void test46() {
    color.laplace.solve(14.752799f,59.011196f,95.1255f,-100.0f,26.166487f,100.0f,97.15614f,-43.186363f,0f ) ;
  }

  @Test
  public void test47() {
    color.laplace.solve(14.832263f,-1.2499536f,-71.483444f,-39.420994f,-48.348633f,-67.48407f,-19.44446f,-38.356842f,-99.81962f ) ;
  }

  @Test
  public void test48() {
    color.laplace.solve(14.859743f,-40.85668f,-42.270287f,0.29565406f,-12.79739f,-6.813933f,-0.87973684f,-3.8146014f,-1.5812788f ) ;
  }

  @Test
  public void test49() {
    color.laplace.solve(14.909186f,-14.063031f,30.114532f,-26.300222f,86.78245f,7.511168f,-1.2230427f,21.40805f,0.072800666f ) ;
  }

  @Test
  public void test50() {
    color.laplace.solve(14.92203f,-15.095972f,-62.196f,-25.215906f,-99.50496f,5.9446235f,-16.280691f,-39.90686f,-43.84179f ) ;
  }

  @Test
  public void test51() {
    color.laplace.solve(-14.929676f,-59.718704f,8.209118f,-100.0f,34.95196f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test52() {
    color.laplace.solve(14.991371f,43.961452f,0f,36.419853f,74.13699f,100.0f,15.652346f,26.18953f,14.9687805f ) ;
  }

  @Test
  public void test53() {
    color.laplace.solve(15.073342f,52.742554f,91.93542f,-92.44918f,3.961456f,52.819866f,-48.112297f,-100.0f,0f ) ;
  }

  @Test
  public void test54() {
    color.laplace.solve(15.2526655f,-44.129158f,100.0f,5.1398206f,9.218281f,96.64894f,-3.9116652f,-20.786482f,-100.0f ) ;
  }

  @Test
  public void test55() {
    color.laplace.solve(15.495432f,-4.113938f,-12.227391f,-33.98642f,-119.63722f,-236.4042f,-31.434908f,-91.73032f,117.543884f ) ;
  }

  @Test
  public void test56() {
    color.laplace.solve(1.5528115f,-89.64918f,74.67836f,-4.1395783f,-9.31744f,15.8196335f,-8.793685f,40.69936f,30.120108f ) ;
  }

  @Test
  public void test57() {
    color.laplace.solve(15.632205f,24.389057f,24.882225f,-61.860237f,-42.958206f,-24.860159f,38.393024f,-100.0f,0f ) ;
  }

  @Test
  public void test58() {
    color.laplace.solve(15.663825f,-43.123554f,-90.03948f,5.7788544f,46.10425f,10.783834f,-38.65266f,-92.86126f,0f ) ;
  }

  @Test
  public void test59() {
    color.laplace.solve(15.685889f,-0.7802327f,-21.412046f,-22.52582f,-6.9012313f,-2.7482915f,-98.88794f,-1.5505816f,17.320112f ) ;
  }

  @Test
  public void test60() {
    color.laplace.solve(-15.749402f,-66.5333f,16.783033f,-96.4643f,-75.821f,0f,-23.651802f,1.857093f,60.541508f ) ;
  }

  @Test
  public void test61() {
    color.laplace.solve(16.048307f,-48.53361f,93.07945f,12.726843f,13.157571f,14.357927f,21.701492f,74.079124f,-48.805317f ) ;
  }

  @Test
  public void test62() {
    color.laplace.solve(16.143324f,-33.22237f,8.218205f,28.390127f,20.480818f,71.89386f,76.93636f,14.861652f,67.714836f ) ;
  }

  @Test
  public void test63() {
    color.laplace.solve(16.254663f,-35.155285f,-78.57251f,0.17393866f,-12.411547f,-1.9014541f,-3.1473618f,-12.763386f,-35.494633f ) ;
  }

  @Test
  public void test64() {
    color.laplace.solve(16.267235f,-32.392662f,-99.999825f,-2.5383987f,-9.478744f,78.35544f,-16.942085f,-65.22994f,-71.378845f ) ;
  }

  @Test
  public void test65() {
    color.laplace.solve(16.347778f,15.114193f,3.7785482f,-49.723083f,-59.66955f,-100.0f,-16.624231f,-16.773842f,15.721036f ) ;
  }

  @Test
  public void test66() {
    color.laplace.solve(-16.473997f,-150.17639f,44.61725f,-15.99433f,-41.700874f,6.557199f,-5.5946717f,-6.352216f,22.999514f ) ;
  }

  @Test
  public void test67() {
    color.laplace.solve(-168.6764f,182.72221f,-93.285034f,-41.00123f,14.887358f,-78.29487f,-10.708366f,-3.8635287f,-20.534449f ) ;
  }

  @Test
  public void test68() {
    color.laplace.solve(17.020794f,-23.781406f,-75.29645f,-8.135418f,-31.823284f,-32.554996f,-17.739183f,-62.821312f,87.75546f ) ;
  }

  @Test
  public void test69() {
    color.laplace.solve(17.141201f,-32.672287f,-41.47059f,1.2370957f,-14.686475f,-36.048233f,2.4936554f,8.737526f,47.14292f ) ;
  }

  @Test
  public void test70() {
    color.laplace.solve(17.220165f,-28.946716f,-67.6862f,-2.1726236f,-20.808784f,-33.88094f,-5.1018763f,-18.234861f,-47.02877f ) ;
  }

  @Test
  public void test71() {
    color.laplace.solve(17.38762f,-8.33154f,5.7790694f,-22.117973f,-98.67273f,-88.424126f,-14.551512f,-36.08807f,-31.128048f ) ;
  }

  @Test
  public void test72() {
    color.laplace.solve(17.401978f,1.3842851f,-66.69845f,-31.776379f,-45.16639f,-52.96621f,-99.3411f,-97.30726f,-100.0f ) ;
  }

  @Test
  public void test73() {
    color.laplace.solve(-17.46702f,-16.607931f,-18.945513f,-9.412604f,-15.976805f,-30.472916f,-4.206593f,-7.413767f,-9.47167f ) ;
  }

  @Test
  public void test74() {
    color.laplace.solve(17.525957f,-9.774918f,-56.62563f,-20.121254f,-100.0f,-100.0f,1.9890282f,28.077366f,25.113031f ) ;
  }

  @Test
  public void test75() {
    color.laplace.solve(17.696539f,-44.56675f,3.586058f,15.352903f,17.048164f,6.09176f,26.66691f,91.31474f,3.7328184f ) ;
  }

  @Test
  public void test76() {
    color.laplace.solve(1.7910222f,-11.595119f,0f,-24.175817f,-35.27471f,-41.919743f,-63.219578f,7.0290833f,0f ) ;
  }

  @Test
  public void test77() {
    color.laplace.solve(17.944395f,-31.093086f,16.944077f,2.8706677f,-6.792009f,2.603916f,0.33028385f,-1.5495322f,0.2635959f ) ;
  }

  @Test
  public void test78() {
    color.laplace.solve(18.000185f,-29.059076f,-17.38482f,1.0598164f,-12.804099f,-18.269234f,-0.95682067f,-4.8875275f,-5.7891903f ) ;
  }

  @Test
  public void test79() {
    color.laplace.solve(18.020138f,30.694153f,-19.954248f,-58.6136f,24.710726f,9.069543f,-19.220945f,-18.270176f,-78.57049f ) ;
  }

  @Test
  public void test80() {
    color.laplace.solve(-18.214964f,-100.0f,59.210857f,-72.859856f,100.0f,0f,-16.521898f,6.77226f,-56.38906f ) ;
  }

  @Test
  public void test81() {
    color.laplace.solve(18.243557f,-19.753534f,28.961481f,4.3537154f,-1.9820546f,7.211831f,1.153372f,0.2597698f,1.8678979f ) ;
  }

  @Test
  public void test82() {
    color.laplace.solve(18.47628f,-27.787258f,-41.492638f,1.6923827f,-11.114376f,-14.298286f,-0.59237444f,-4.074352f,-4.590657f ) ;
  }

  @Test
  public void test83() {
    color.laplace.solve(18.763983f,-28.638084f,-22.876118f,3.6940153f,-3.0198262f,-7.6418366f,-0.96809536f,20.506601f,71.071014f ) ;
  }

  @Test
  public void test84() {
    color.laplace.solve(1.8837018f,-17.336124f,18.262642f,3.592452f,12.303951f,65.8233f,0.18215582f,-2.863829f,-23.941423f ) ;
  }

  @Test
  public void test85() {
    color.laplace.solve(19.158838f,-10.8628235f,-98.95866f,-12.501824f,-63.65148f,-99.998116f,-5.5146546f,-9.556793f,48.575462f ) ;
  }

  @Test
  public void test86() {
    color.laplace.solve(19.171247f,-48.760307f,33.670242f,25.445301f,74.18978f,0f,0.99914247f,-21.44873f,0f ) ;
  }

  @Test
  public void test87() {
    color.laplace.solve(19.251081f,-24.774496f,94.04041f,1.7788372f,-15.985018f,-54.562782f,3.8493052f,13.618383f,66.60926f ) ;
  }

  @Test
  public void test88() {
    color.laplace.solve(1.9467372f,-79.91f,65.97605f,-12.30305f,-44.21634f,-69.184944f,-6.9426007f,-15.467353f,-10.710474f ) ;
  }

  @Test
  public void test89() {
    color.laplace.solve(-19.57602f,37.98712f,0f,-8.269964f,13.296003f,-52.78106f,-26.79984f,76.24792f,0f ) ;
  }

  @Test
  public void test90() {
    color.laplace.solve(20.075174f,88.22162f,-67.45139f,19.16656f,47.525475f,65.617935f,9.065588f,17.09579f,11.792101f ) ;
  }

  @Test
  public void test91() {
    color.laplace.solve(20.091522f,-37.7863f,-98.2917f,18.152391f,58.429398f,8.196107f,-5.911356f,-86.95078f,0f ) ;
  }

  @Test
  public void test92() {
    color.laplace.solve(20.150414f,-11.777307f,-138.53864f,-7.2804747f,-28.146456f,-38.19743f,-20.220026f,-54.747257f,-170.5165f ) ;
  }

  @Test
  public void test93() {
    color.laplace.solve(20.25041f,25.310589f,22.719025f,-44.308952f,-41.727077f,-34.43449f,-8.297039f,11.120794f,94.50729f ) ;
  }

  @Test
  public void test94() {
    color.laplace.solve(20.377764f,77.373024f,-46.8759f,17.308016f,36.337605f,17.910618f,12.516696f,32.758766f,82.18076f ) ;
  }

  @Test
  public void test95() {
    color.laplace.solve(20.398743f,4.5914474f,-48.58171f,-22.996477f,-14.83755f,52.940678f,-97.5471f,-93.67844f,0f ) ;
  }

  @Test
  public void test96() {
    color.laplace.solve(20.427462f,42.32045f,35.46764f,-60.610603f,13.386696f,-100.0f,-12.508823f,10.57531f,41.423367f ) ;
  }

  @Test
  public void test97() {
    color.laplace.solve(20.447912f,-28.172766f,-100.0f,9.964415f,7.5896897f,11.251304f,11.820055f,37.315807f,-100.0f ) ;
  }

  @Test
  public void test98() {
    color.laplace.solve(20.470627f,9.028471f,15.64324f,-27.145964f,-100.0f,-46.45553f,-29.054485f,-89.07202f,55.832485f ) ;
  }

  @Test
  public void test99() {
    color.laplace.solve(20.478931f,100.0f,0f,17.387003f,67.56629f,35.261696f,-18.497213f,-91.37586f,0f ) ;
  }

  @Test
  public void test100() {
    color.laplace.solve(20.515787f,-25.261753f,-100.0f,7.324901f,-0.430187f,-13.31501f,9.214004f,29.531115f,69.49995f ) ;
  }

  @Test
  public void test101() {
    color.laplace.solve(20.740505f,79.79704f,-29.265007f,11.040766f,20.678005f,-8.064749f,2.7445889f,-0.062407576f,-23.671991f ) ;
  }

  @Test
  public void test102() {
    color.laplace.solve(-2.0807502f,-100.0f,-99.99881f,-8.323006f,-27.35223f,6.0272546f,-3.859044f,-7.1131673f,2.758628f ) ;
  }

  @Test
  public void test103() {
    color.laplace.solve(20.965448f,-25.298298f,-34.094025f,9.1600895f,14.961426f,-39.017197f,0.7134846f,-6.306151f,-40.899513f ) ;
  }

  @Test
  public void test104() {
    color.laplace.solve(21.013882f,33.607258f,22.392168f,-49.551735f,-8.977021f,-45.30511f,-7.4081235f,19.919239f,96.0621f ) ;
  }

  @Test
  public void test105() {
    color.laplace.solve(21.040182f,-5.6555243f,-110.0292f,-8.828243f,-32.89139f,-33.896046f,-23.492691f,-83.67431f,-199.16188f ) ;
  }

  @Test
  public void test106() {
    color.laplace.solve(21.268454f,9.7294445f,17.648914f,-24.655628f,-99.99961f,-99.99894f,-19.891357f,-54.909805f,-99.87662f ) ;
  }

  @Test
  public void test107() {
    color.laplace.solve(21.384432f,8.772562f,13.699726f,-23.234833f,-99.99391f,-53.973656f,-14.329854f,-34.08458f,-22.014559f ) ;
  }

  @Test
  public void test108() {
    color.laplace.solve(-21.54903f,-86.19612f,22.007225f,-100.0f,82.28175f,100.0f,-19.10827f,23.566917f,31.094189f ) ;
  }

  @Test
  public void test109() {
    color.laplace.solve(21.677935f,-24.229916f,-26.963396f,10.941652f,40.474915f,81.036865f,-18.386236f,-84.4866f,0f ) ;
  }

  @Test
  public void test110() {
    color.laplace.solve(-21.720024f,-50.562572f,-24.23897f,-11.796888f,-20.612661f,-12.468607f,-4.8548675f,-7.622582f,-5.022797f ) ;
  }

  @Test
  public void test111() {
    color.laplace.solve(21.905424f,-15.516367f,63.465492f,3.13806f,-11.945867f,-42.637836f,2.592684f,7.232676f,20.148342f ) ;
  }

  @Test
  public void test112() {
    color.laplace.solve(22.205175f,9.731149f,12.435166f,-20.91045f,-95.715744f,-79.61581f,-10.13123f,69.72847f,0f ) ;
  }

  @Test
  public void test113() {
    color.laplace.solve(22.266891f,1.5549061f,-41.181572f,-12.487336f,-74.8657f,68.107605f,2.6494591f,58.374615f,0f ) ;
  }

  @Test
  public void test114() {
    color.laplace.solve(-22.317162f,42.712482f,58.620346f,3.0691986f,30.350767f,61.717834f,4.243189f,13.903556f,21.020267f ) ;
  }

  @Test
  public void test115() {
    color.laplace.solve(-22.48197f,69.31275f,0f,-12.345126f,-28.741028f,-61.30055f,1.8424932f,19.7151f,0f ) ;
  }

  @Test
  public void test116() {
    color.laplace.solve(22.504269f,55.783897f,13.992788f,-65.76682f,86.638535f,-17.331871f,-82.00349f,82.178375f,0f ) ;
  }

  @Test
  public void test117() {
    color.laplace.solve(22.599361f,-7.3116345f,-34.960327f,-2.2909217f,-28.141066f,-55.902897f,-3.6219819f,-12.197006f,-17.024977f ) ;
  }

  @Test
  public void test118() {
    color.laplace.solve(22.665482f,51.5544f,0.5688326f,-16.547745f,-19.875732f,-82.98535f,-68.98073f,-31.52424f,17.318531f ) ;
  }

  @Test
  public void test119() {
    color.laplace.solve(-2.2673159f,-52.467262f,13.688076f,-56.602f,-36.818237f,0f,39.81941f,0f,0f ) ;
  }

  @Test
  public void test120() {
    color.laplace.solve(-22.807415f,14.11672f,0f,-12.612855f,-19.657478f,0f,7.5846467f,42.951443f,51.740005f ) ;
  }

  @Test
  public void test121() {
    color.laplace.solve(22.901611f,13.322322f,26.442844f,-21.709457f,-96.056015f,-56.32961f,-13.682839f,-33.019424f,-22.337257f ) ;
  }

  @Test
  public void test122() {
    color.laplace.solve(22.902342f,11.317427f,19.478867f,-19.70806f,-97.1115f,-33.40196f,-4.6230764f,-100.0f,0f ) ;
  }

  @Test
  public void test123() {
    color.laplace.solve(22.976522f,-20.808327f,99.50884f,12.71442f,17.65391f,50.514973f,10.227249f,28.194574f,84.89714f ) ;
  }

  @Test
  public void test124() {
    color.laplace.solve(22.982763f,-1.7090526f,64.40343f,-6.3598933f,4.410156f,19.42394f,-52.832493f,6.285628f,2.6114862f ) ;
  }

  @Test
  public void test125() {
    color.laplace.solve(23.08181f,-33.154915f,100.0f,25.482155f,64.70995f,0f,14.136855f,0f,0f ) ;
  }

  @Test
  public void test126() {
    color.laplace.solve(23.097477f,-24.338774f,103.52526f,16.359167f,24.43187f,46.99168f,17.733376f,58.588776f,193.61763f ) ;
  }

  @Test
  public void test127() {
    color.laplace.solve(23.106634f,13.349847f,29.819992f,-20.923307f,-99.52724f,5.9301205f,-7.272627f,-8.1672f,74.131065f ) ;
  }

  @Test
  public void test128() {
    color.laplace.solve(23.204538f,55.60681f,30.835342f,-62.788662f,68.38737f,-32.26544f,-65.57256f,0f,0f ) ;
  }

  @Test
  public void test129() {
    color.laplace.solve(23.269138f,-2.3912024f,-50.511406f,-4.5322437f,-82.32254f,45.06869f,-88.378105f,0f,0f ) ;
  }

  @Test
  public void test130() {
    color.laplace.solve(23.293331f,-11.659756f,18.025963f,4.8330774f,-6.1874814f,-21.996014f,2.226461f,4.072766f,-22.10075f ) ;
  }

  @Test
  public void test131() {
    color.laplace.solve(2.3507805f,-90.63499f,86.10082f,0.038138263f,-12.8266735f,-3.1880932f,10.62909f,42.478252f,-86.02652f ) ;
  }

  @Test
  public void test132() {
    color.laplace.solve(23.529123f,-11.929488f,-96.390305f,6.04598f,-2.840891f,-13.416825f,3.4956875f,7.93677f,31.092283f ) ;
  }

  @Test
  public void test133() {
    color.laplace.solve(23.70904f,17.639032f,46.84709f,-22.802872f,-100.0f,-93.50656f,-14.920529f,-36.879246f,-32.59645f ) ;
  }

  @Test
  public void test134() {
    color.laplace.solve(23.712835f,-6.0808134f,-60.96067f,0.9321515f,-15.07497f,-34.582035f,-4.909258f,-20.569183f,-62.292507f ) ;
  }

  @Test
  public void test135() {
    color.laplace.solve(23.868906f,3.4361446f,-59.973633f,-7.960519f,-33.423344f,-47.978977f,-22.287638f,-81.190025f,-98.518936f ) ;
  }

  @Test
  public void test136() {
    color.laplace.solve(24.051369f,-9.1206255f,-31.579975f,18.694778f,36.633568f,99.278175f,14.094179f,37.68194f,100.0f ) ;
  }

  @Test
  public void test137() {
    color.laplace.solve(24.071281f,5.7600803f,-76.021935f,-9.624355f,-25.391088f,49.696926f,-35.342213f,-146.94606f,-168.85684f ) ;
  }

  @Test
  public void test138() {
    color.laplace.solve(24.10771f,28.953913f,124.425446f,-32.97174f,-132.88438f,59.42647f,-22.037313f,-54.84137f,-172.62337f ) ;
  }

  @Test
  public void test139() {
    color.laplace.solve(24.33395f,-5.8537936f,-137.09753f,3.1677525f,-10.62338f,-33.112312f,-0.9846873f,-6.5592422f,-14.579682f ) ;
  }

  @Test
  public void test140() {
    color.laplace.solve(2.4445426f,-86.07674f,33.62812f,-4.145092f,-18.8057f,11.730233f,-0.21907207f,3.2687917f,32.098415f ) ;
  }

  @Test
  public void test141() {
    color.laplace.solve(24.482338f,57.326153f,16.66173f,-59.396797f,88.16054f,-90.67923f,-11.231947f,14.469008f,-19.052555f ) ;
  }

  @Test
  public void test142() {
    color.laplace.solve(24.504942f,-0.49025145f,-100.0f,-1.4899786f,-25.759108f,-35.10717f,-3.1759574f,-11.140558f,-11.556577f ) ;
  }

  @Test
  public void test143() {
    color.laplace.solve(24.657387f,29.523335f,29.79496f,-30.891993f,-36.349136f,-10.343502f,-111.87943f,-133.70956f,-34.750687f ) ;
  }

  @Test
  public void test144() {
    color.laplace.solve(-2.4706154f,-99.993195f,-100.0f,-9.889264f,-26.047907f,39.955715f,-11.038536f,-34.26488f,-99.973076f ) ;
  }

  @Test
  public void test145() {
    color.laplace.solve(24.777166f,3.4459915f,-72.15393f,-4.3373284f,-38.839268f,-100.0f,-3.2872102f,-8.811512f,6.8804307f ) ;
  }

  @Test
  public void test146() {
    color.laplace.solve(24.921059f,-5.1115365f,99.91111f,4.7948003f,-4.103639f,-4.7501435f,-1.6382185f,-11.347677f,-39.64966f ) ;
  }

  @Test
  public void test147() {
    color.laplace.solve(24.993826f,18.139513f,-37.792873f,-18.164207f,-14.642896f,-97.11664f,-7.529771f,-11.954877f,-25.646841f ) ;
  }

  @Test
  public void test148() {
    color.laplace.solve(25.002546f,-14.14787f,-192.33853f,14.338473f,11.06968f,-77.16798f,21.166027f,69.74325f,-4.7363105f ) ;
  }

  @Test
  public void test149() {
    color.laplace.solve(2.504937f,-96.15495f,19.14906f,6.174698f,22.769161f,-20.191946f,-0.57530636f,-8.475924f,-56.097546f ) ;
  }

  @Test
  public void test150() {
    color.laplace.solve(-25.136024f,-10.234883f,43.707527f,-11.522098f,-12.7801485f,-8.196838f,-8.172218f,-21.166775f,-63.714733f ) ;
  }

  @Test
  public void test151() {
    color.laplace.solve(25.16109f,16.40476f,18.073122f,-15.744878f,-77.61517f,-44.08072f,-10.544438f,-26.432905f,-17.628407f ) ;
  }

  @Test
  public void test152() {
    color.laplace.solve(25.220795f,9.14553f,-56.861237f,-8.262353f,-31.777437f,-27.992937f,-26.492767f,-99.99999f,-23.333076f ) ;
  }

  @Test
  public void test153() {
    color.laplace.solve(25.281925f,14.6354885f,5.197947f,-13.50779f,-71.93792f,77.35911f,-7.375168f,-15.992882f,15.341557f ) ;
  }

  @Test
  public void test154() {
    color.laplace.solve(25.376295f,2.1731458f,-96.0809f,-0.7398525f,-20.602642f,-52.943016f,-7.9099836f,-30.900082f,-95.08836f ) ;
  }

  @Test
  public void test155() {
    color.laplace.solve(-25.417881f,-21.829855f,0f,68.30721f,3.3500516f,0f,19.974588f,11.591144f,23.039932f ) ;
  }

  @Test
  public void test156() {
    color.laplace.solve(-25.484093f,-39.763752f,100.0f,-16.156824f,-29.968534f,-43.411713f,-9.174669f,-20.541851f,-43.0242f ) ;
  }

  @Test
  public void test157() {
    color.laplace.solve(25.485706f,0.68044347f,-50.48161f,1.2623821f,-23.92645f,100.0f,3.4902728f,12.698709f,71.23101f ) ;
  }

  @Test
  public void test158() {
    color.laplace.solve(25.502972f,2.055003f,99.999985f,-0.04311568f,-15.790664f,-25.678577f,-9.88477f,-39.495968f,14.0656805f ) ;
  }

  @Test
  public void test159() {
    color.laplace.solve(25.533815f,-2.6773608f,7.833908f,4.8126197f,-5.153778f,-13.419516f,-1.1295589f,-9.330855f,-38.126274f ) ;
  }

  @Test
  public void test160() {
    color.laplace.solve(25.546806f,49.689445f,19.593773f,-47.50222f,53.617207f,-95.91051f,0f,0f,0f ) ;
  }

  @Test
  public void test161() {
    color.laplace.solve(25.63314f,7.763479f,-51.027935f,-5.230917f,-43.55129f,57.561714f,-3.0055213f,-6.7911677f,19.392138f ) ;
  }

  @Test
  public void test162() {
    color.laplace.solve(25.756056f,12.033738f,-37.55191f,-9.009518f,-40.06919f,99.84005f,-21.724932f,-77.890205f,25.675934f ) ;
  }

  @Test
  public void test163() {
    color.laplace.solve(25.813646f,-20.317162f,-2.2592907f,23.571747f,54.079617f,-34.051937f,14.393725f,34.003155f,67.53927f ) ;
  }

  @Test
  public void test164() {
    color.laplace.solve(25.821236f,21.283163f,13.157171f,-17.998219f,-53.845753f,-68.65448f,-43.96836f,-86.77251f,0f ) ;
  }

  @Test
  public void test165() {
    color.laplace.solve(25.850784f,74.293274f,90.217285f,-70.89014f,81.10503f,-16.12278f,6.1042f,95.30694f,31.40339f ) ;
  }

  @Test
  public void test166() {
    color.laplace.solve(25.855934f,-9.2522545f,100.0f,12.675991f,19.237366f,63.75906f,5.6106653f,9.766669f,14.218646f ) ;
  }

  @Test
  public void test167() {
    color.laplace.solve(25.875095f,19.046124f,37.476273f,-15.545738f,-87.16688f,83.961525f,-0.89117616f,11.981034f,0f ) ;
  }

  @Test
  public void test168() {
    color.laplace.solve(-2.5916731f,7.9340835f,-76.753784f,-118.301704f,11.081791f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test169() {
    color.laplace.solve(25.950254f,13.449869f,-17.776617f,-10.073735f,-54.73118f,-184.6008f,-11.505175f,-38.11159f,-86.415924f ) ;
  }

  @Test
  public void test170() {
    color.laplace.solve(25.99955f,-9.225501f,48.043953f,13.2248535f,20.682768f,67.0867f,6.217094f,11.64574f,19.683096f ) ;
  }

  @Test
  public void test171() {
    color.laplace.solve(26.04032f,-5.1542606f,100.0f,9.315538f,70.29756f,0f,9.13196f,27.2123f,43.246998f ) ;
  }

  @Test
  public void test172() {
    color.laplace.solve(26.174421f,9.459932f,-83.891846f,-4.762247f,-4.4428473f,20.123428f,-1.2336012f,-0.17215763f,4.987818f ) ;
  }

  @Test
  public void test173() {
    color.laplace.solve(26.209126f,-1.7829753f,49.370457f,6.619474f,-0.20641772f,-0.94345075f,0.4751888f,-4.718719f,-19.143646f ) ;
  }

  @Test
  public void test174() {
    color.laplace.solve(26.363981f,10.286595f,-52.468132f,-5.060785f,-24.593855f,-39.51683f,-21.88596f,-63.369427f,-206.2747f ) ;
  }

  @Test
  public void test175() {
    color.laplace.solve(26.514666f,1.024963f,-113.554184f,5.051488f,-8.809535f,-47.194973f,2.5702744f,5.896295f,14.330604f ) ;
  }

  @Test
  public void test176() {
    color.laplace.solve(26.552786f,-5.9155693f,-154.89862f,10.3511095f,4.512065f,-13.264159f,9.584385f,25.431181f,87.40688f ) ;
  }

  @Test
  public void test177() {
    color.laplace.solve(26.595028f,14.448301f,-20.159655f,-8.068189f,-48.64217f,-92.895966f,-10.480471f,-33.853695f,0f ) ;
  }

  @Test
  public void test178() {
    color.laplace.solve(26.605658f,4.797965f,-68.445465f,6.3637595f,-2.348465f,-18.983206f,1.1978452f,-1.572379f,-5.138896f ) ;
  }

  @Test
  public void test179() {
    color.laplace.solve(26.727455f,-5.4014325f,99.99361f,12.311253f,16.02617f,43.54059f,6.4913826f,13.654279f,32.76196f ) ;
  }

  @Test
  public void test180() {
    color.laplace.solve(26.784512f,3.6773775f,-100.0f,3.4606726f,-12.101532f,-49.510113f,-0.83146375f,-6.7865276f,-14.074361f ) ;
  }

  @Test
  public void test181() {
    color.laplace.solve(26.795767f,15.3033495f,-15.056728f,-8.112922f,-49.978832f,-175.43646f,-9.465034f,-31.363121f,-186.35358f ) ;
  }

  @Test
  public void test182() {
    color.laplace.solve(26.859015f,34.49339f,39.959538f,14.189187f,22.974695f,29.713234f,6.9230385f,13.502967f,55.91871f ) ;
  }

  @Test
  public void test183() {
    color.laplace.solve(26.86817f,14.152843f,-42.596493f,-6.679926f,-27.660198f,-21.082249f,-25.927782f,-97.031204f,-15.865813f ) ;
  }

  @Test
  public void test184() {
    color.laplace.solve(-27.017025f,-65.54799f,100.0f,-12.209952f,-17.910942f,9.551601f,-3.9118435f,-3.4374216f,8.073099f ) ;
  }

  @Test
  public void test185() {
    color.laplace.solve(27.021978f,3.075279f,-108.12666f,5.0636463f,-6.5933447f,-30.670862f,-0.15253025f,-3.7999413f,-8.455216f ) ;
  }

  @Test
  public void test186() {
    color.laplace.solve(27.035187f,3.1272995f,-105.38679f,5.144198f,-9.076823f,-48.929447f,2.2393553f,4.0821037f,-81.35033f ) ;
  }

  @Test
  public void test187() {
    color.laplace.solve(27.048603f,47.369926f,81.89734f,-39.17551f,-19.466242f,100.0f,-19.445152f,-38.605103f,-80.975975f ) ;
  }

  @Test
  public void test188() {
    color.laplace.solve(27.09047f,32.929646f,32.961704f,-24.567755f,-28.333591f,-21.696154f,-97.02788f,-100.0f,-91.41267f ) ;
  }

  @Test
  public void test189() {
    color.laplace.solve(27.118889f,17.427181f,-74.977936f,-8.951623f,17.567778f,61.44857f,-80.49316f,0.34697837f,-16.98315f ) ;
  }

  @Test
  public void test190() {
    color.laplace.solve(27.138376f,30.613884f,38.8688f,-22.060383f,-43.551636f,24.861315f,-15.727489f,-40.84958f,0f ) ;
  }

  @Test
  public void test191() {
    color.laplace.solve(27.15361f,28.693563f,17.207253f,-20.07912f,-29.586609f,-59.362053f,19.902044f,99.6873f,0f ) ;
  }

  @Test
  public void test192() {
    color.laplace.solve(27.218098f,4.654386f,-89.50568f,4.2180085f,-19.094881f,-30.809843f,8.7488165f,-54.442078f,-14.638819f ) ;
  }

  @Test
  public void test193() {
    color.laplace.solve(27.467573f,5.599937f,-15.691563f,4.2703576f,3.070707f,60.510292f,-13.45685f,-58.09776f,100.0f ) ;
  }

  @Test
  public void test194() {
    color.laplace.solve(27.483152f,7.433125f,45.68391f,2.499484f,-12.347506f,-36.27231f,-5.13771f,-23.050323f,-74.71608f ) ;
  }

  @Test
  public void test195() {
    color.laplace.solve(27.601778f,26.477737f,63.073692f,-16.070621f,-84.76453f,31.778664f,-7.1197453f,-12.40836f,42.25083f ) ;
  }

  @Test
  public void test196() {
    color.laplace.solve(-27.65694f,45.94851f,59.77639f,-3.730239f,12.736189f,4.9970646f,-2.044507E-4f,3.7294211f,2.1816216f ) ;
  }

  @Test
  public void test197() {
    color.laplace.solve(27.65777f,14.491859f,-62.738964f,-3.860781f,-6.9513664f,-90.53325f,-36.14953f,52.096703f,57.722137f ) ;
  }

  @Test
  public void test198() {
    color.laplace.solve(27.723024f,5.8834586f,76.98119f,5.008642f,-3.3587592f,-1.9997072f,-4.329697f,-22.32743f,-81.62126f ) ;
  }

  @Test
  public void test199() {
    color.laplace.solve(-2.7725406f,-99.341446f,-94.67567f,-11.748717f,-38.566193f,-32.257957f,-5.6663423f,-10.916653f,0.55197006f ) ;
  }

  @Test
  public void test200() {
    color.laplace.solve(27.821709f,5.048247f,-33.964237f,6.2385855f,-27.691471f,71.778656f,24.824104f,23.10027f,0f ) ;
  }

  @Test
  public void test201() {
    color.laplace.solve(27.84702f,2.2713268f,-99.99998f,9.116747f,-18.761734f,-100.0f,27.381702f,13.564992f,100.0f ) ;
  }

  @Test
  public void test202() {
    color.laplace.solve(27.939987f,33.481144f,21.431086f,-21.721197f,-15.446495f,-47.756798f,-99.37828f,-25.789127f,0f ) ;
  }

  @Test
  public void test203() {
    color.laplace.solve(27.947218f,19.418598f,20.376514f,-7.629722f,-70.649345f,-100.0f,12.183237f,56.36267f,0f ) ;
  }

  @Test
  public void test204() {
    color.laplace.solve(-2.7968433f,-99.99161f,99.99999f,-11.195765f,-29.850527f,29.132257f,-12.135689f,-37.346992f,46.379566f ) ;
  }

  @Test
  public void test205() {
    color.laplace.solve(28.00195f,0.8576857f,99.95839f,11.15012f,12.198789f,30.338503f,4.399741f,6.4488416f,9.196837f ) ;
  }

  @Test
  public void test206() {
    color.laplace.solve(28.151205f,2.0084424f,13.339823f,10.596376f,10.251777f,23.06857f,3.9825234f,5.333718f,7.100572f ) ;
  }

  @Test
  public void test207() {
    color.laplace.solve(28.198715f,8.672212f,100.0f,4.1228757f,-8.601466f,-30.655037f,-3.1057465f,-16.545862f,-54.475983f ) ;
  }

  @Test
  public void test208() {
    color.laplace.solve(28.37653f,21.001465f,7.7986636f,-7.4961367f,-52.169334f,-25.776312f,-6.194499f,-17.281858f,-10.764462f ) ;
  }

  @Test
  public void test209() {
    color.laplace.solve(28.386604f,31.999962f,26.283602f,-16.595818f,-22.476147f,-27.001776f,-72.31008f,-78.90664f,-111.61113f ) ;
  }

  @Test
  public void test210() {
    color.laplace.solve(28.503582f,72.09532f,41.75439f,-58.080986f,118.075714f,28.351494f,-3.7915733f,42.914692f,-24.127794f ) ;
  }

  @Test
  public void test211() {
    color.laplace.solve(28.546967f,26.9611f,48.516933f,-12.773232f,-69.2195f,-19.593063f,-10.420398f,-28.90836f,-4.4787307f ) ;
  }

  @Test
  public void test212() {
    color.laplace.solve(-28.547281f,-31.106766f,0f,-2.6179733f,10.056501f,-0.45856676f,8.018886f,-4.9919987f,0f ) ;
  }

  @Test
  public void test213() {
    color.laplace.solve(28.593409f,14.837444f,-42.697533f,-0.44985297f,-26.52674f,-105.782906f,-3.8057194f,-14.664051f,-28.310259f ) ;
  }

  @Test
  public void test214() {
    color.laplace.solve(28.629787f,10.993544f,-67.87494f,3.5256033f,-16.780678f,-45.81758f,2.2533047f,5.4876156f,36.477833f ) ;
  }

  @Test
  public void test215() {
    color.laplace.solve(28.63338f,14.7228775f,-44.710876f,-0.18949327f,-25.030575f,-97.40574f,-4.3605967f,-17.249949f,-39.608616f ) ;
  }

  @Test
  public void test216() {
    color.laplace.solve(28.653297f,24.41702f,-53.3192f,-9.803828f,22.333984f,23.708708f,-90.20259f,51.014038f,99.99964f ) ;
  }

  @Test
  public void test217() {
    color.laplace.solve(28.79642f,24.693913f,29.89074f,-9.508239f,-59.911507f,-5.130953f,-6.917867f,-18.163229f,-5.8235455f ) ;
  }

  @Test
  public void test218() {
    color.laplace.solve(28.83654f,6.9744315f,-100.0f,8.371742f,-0.9388149f,-33.086674f,5.5892467f,13.985245f,51.290546f ) ;
  }

  @Test
  public void test219() {
    color.laplace.solve(28.85376f,3.4083931f,99.9371f,12.006648f,14.040464f,32.224003f,5.132366f,8.522816f,14.918434f ) ;
  }

  @Test
  public void test220() {
    color.laplace.solve(29.009726f,26.531921f,46.19097f,-10.493019f,-69.07301f,58.231968f,-1.9087894f,2.8578615f,0f ) ;
  }

  @Test
  public void test221() {
    color.laplace.solve(29.175325f,12.457319f,-81.90393f,4.2439823f,2.557883f,56.80333f,-14.757279f,-63.2731f,-100.0f ) ;
  }

  @Test
  public void test222() {
    color.laplace.solve(29.187643f,13.162706f,-65.225494f,4.2192125f,-11.311327f,-53.884552f,-0.903941f,-6.9743476f,-15.2140255f ) ;
  }

  @Test
  public void test223() {
    color.laplace.solve(29.19459f,23.897768f,5.9746456f,-7.1194177f,-39.56931f,-99.99918f,-18.102922f,-75.0564f,-100.0f ) ;
  }

  @Test
  public void test224() {
    color.laplace.solve(29.255281f,25.00281f,54.58849f,-7.9816804f,-65.72322f,28.781555f,4.5412145f,26.146538f,12.4623f ) ;
  }

  @Test
  public void test225() {
    color.laplace.solve(29.305725f,0.1525536f,59.568962f,17.070347f,18.500006f,19.907082f,20.475655f,36.870037f,1.5593613f ) ;
  }

  @Test
  public void test226() {
    color.laplace.solve(29.343079f,10.516075f,-85.99228f,6.856242f,-1.286499f,-13.135623f,-0.63161194f,-9.382689f,34.73629f ) ;
  }

  @Test
  public void test227() {
    color.laplace.solve(29.402208f,36.78569f,36.75872f,-19.176853f,-19.01817f,6.318484f,-87.09145f,-100.0f,-98.07431f ) ;
  }

  @Test
  public void test228() {
    color.laplace.solve(29.443481f,24.145874f,44.165714f,-6.371947f,-77.025696f,92.39096f,22.09443f,94.74967f,-100.0f ) ;
  }

  @Test
  public void test229() {
    color.laplace.solve(29.528973f,-3.378625f,-157.79774f,21.47664f,14.748948f,99.21901f,41.636223f,-94.9059f,0f ) ;
  }

  @Test
  public void test230() {
    color.laplace.solve(29.55166f,17.050894f,-33.139656f,1.1557833f,-28.208445f,99.64796f,0.07412782f,-0.859272f,24.697191f ) ;
  }

  @Test
  public void test231() {
    color.laplace.solve(29.612684f,9.561533f,8.633042f,8.889203f,-99.999596f,-75.029366f,8.82214f,26.399355f,-21.193794f ) ;
  }

  @Test
  public void test232() {
    color.laplace.solve(29.678448f,19.249414f,-23.69669f,-0.42843658f,-28.966394f,-213.97324f,-2.3618035f,-9.003995f,-4.713194f ) ;
  }

  @Test
  public void test233() {
    color.laplace.solve(29.711456f,22.776634f,9.973787f,-3.9308062f,-48.57871f,-82.881485f,3.1440282f,16.506918f,-44.15575f ) ;
  }

  @Test
  public void test234() {
    color.laplace.solve(29.732271f,21.405853f,15.703064f,-2.476767f,-59.81192f,-58.593597f,17.386538f,72.02292f,-36.15251f ) ;
  }

  @Test
  public void test235() {
    color.laplace.solve(29.80746f,14.246912f,100.0f,4.98293f,-9.605059f,-51.481823f,-0.2706804f,-6.065652f,-14.3868685f ) ;
  }

  @Test
  public void test236() {
    color.laplace.solve(29.963322f,25.662441f,13.505166f,-5.8091483f,-40.818733f,-71.64183f,-5.750962f,-17.194708f,-22.209135f ) ;
  }

  @Test
  public void test237() {
    color.laplace.solve(30.049778f,21.085232f,47.39569f,-0.8861234f,-93.10454f,68.49753f,0.18520118f,49.31224f,0f ) ;
  }

  @Test
  public void test238() {
    color.laplace.solve(30.151382f,10.249942f,-96.963104f,10.355042f,7.8114433f,7.1647353f,3.4588127f,3.4830506f,2.6619465f ) ;
  }

  @Test
  public void test239() {
    color.laplace.solve(30.17467f,32.823578f,27.043797f,-12.124706f,-25.92416f,-24.72009f,-52.736492f,-99.675224f,-100.0f ) ;
  }

  @Test
  public void test240() {
    color.laplace.solve(30.183538f,39.53343f,33.328835f,-18.79878f,-5.3786626f,-6.218088f,-100.0f,-36.027832f,99.999985f ) ;
  }

  @Test
  public void test241() {
    color.laplace.solve(30.307238f,15.233526f,99.935074f,5.9954257f,-6.679852f,-43.370205f,0.35431743f,-4.578156f,-11.98709f ) ;
  }

  @Test
  public void test242() {
    color.laplace.solve(30.312925f,29.690582f,45.346626f,-8.438878f,-56.8972f,51.695942f,-7.171192f,-20.245892f,-16.9152f ) ;
  }

  @Test
  public void test243() {
    color.laplace.solve(30.331509f,26.031229f,28.669842f,-4.705192f,-54.876434f,-11.351862f,5.724219f,27.602068f,0f ) ;
  }

  @Test
  public void test244() {
    color.laplace.solve(-30.466257f,-71.47177f,99.96729f,-20.435942f,-47.072716f,-99.99992f,-4.2047915f,3.6167743f,65.744606f ) ;
  }

  @Test
  public void test245() {
    color.laplace.solve(30.507412f,16.91889f,-53.101135f,5.1107545f,-9.730718f,-57.170902f,-0.3336745f,-6.445454f,-15.717424f ) ;
  }

  @Test
  public void test246() {
    color.laplace.solve(30.51831f,20.83874f,-4.2879972f,1.2566751f,-42.795944f,-137.92412f,17.304192f,68.21607f,-48.934277f ) ;
  }

  @Test
  public void test247() {
    color.laplace.solve(30.624546f,22.838495f,-52.399223f,-0.34031233f,13.128659f,-13.088937f,-45.114456f,-43.71243f,0f ) ;
  }

  @Test
  public void test248() {
    color.laplace.solve(3.0645974f,-61.3684f,90.65617f,-26.373209f,24.081963f,0f,-40.130516f,69.72545f,0f ) ;
  }

  @Test
  public void test249() {
    color.laplace.solve(30.682165f,16.507086f,-58.78942f,6.2255945f,-5.864399f,-67.002625f,0.06020132f,-5.9847894f,-18.13496f ) ;
  }

  @Test
  public void test250() {
    color.laplace.solve(30.689411f,19.278234f,15.139825f,3.4794073f,-68.71629f,37.43488f,51.944515f,0f,0f ) ;
  }

  @Test
  public void test251() {
    color.laplace.solve(30.735626f,23.151207f,5.7927217f,-0.20870507f,-43.923515f,-99.98032f,12.35307f,-98.65625f,96.90015f ) ;
  }

  @Test
  public void test252() {
    color.laplace.solve(30.74835f,13.627907f,87.3497f,9.365494f,43.271812f,77.23723f,-36.55819f,72.85662f,46.757774f ) ;
  }

  @Test
  public void test253() {
    color.laplace.solve(30.8798f,24.519026f,-17.314936f,-0.9998241f,-15.488766f,-8.91276f,-19.390331f,-76.5615f,8.422054f ) ;
  }

  @Test
  public void test254() {
    color.laplace.solve(30.882378f,27.730843f,24.571665f,-4.2013288f,-44.53067f,-29.444181f,-3.157022f,-8.42676f,13.980657f ) ;
  }

  @Test
  public void test255() {
    color.laplace.solve(30.947123f,35.46015f,19.764795f,-11.671659f,-8.871309f,-56.400974f,-68.76245f,-2.872755f,18.423882f ) ;
  }

  @Test
  public void test256() {
    color.laplace.solve(3.0997202f,-8.055588f,0f,-19.773335f,-21.605543f,-75.183716f,-60.587513f,12.934552f,0f ) ;
  }

  @Test
  public void test257() {
    color.laplace.solve(31.099031f,18.38668f,-54.98229f,6.0094466f,-2.5700183f,-10.784197f,-4.491227f,-23.974356f,0f ) ;
  }

  @Test
  public void test258() {
    color.laplace.solve(31.198875f,22.83838f,-32.101128f,1.9571221f,-7.744223f,8.689385f,-15.626164f,-64.461784f,-99.99993f ) ;
  }

  @Test
  public void test259() {
    color.laplace.solve(31.201153f,13.176693f,44.372147f,11.727923f,11.319975f,15.196393f,4.284315f,5.1789656f,5.1115727f ) ;
  }

  @Test
  public void test260() {
    color.laplace.solve(31.238548f,24.160065f,-11.08731f,0.7941304f,-23.51098f,-99.999794f,-4.5510473f,-18.99832f,-47.931248f ) ;
  }

  @Test
  public void test261() {
    color.laplace.solve(31.239635f,42.263935f,38.2773f,-17.305391f,-0.4611987f,10.84527f,-100.0f,-37.64861f,19.424232f ) ;
  }

  @Test
  public void test262() {
    color.laplace.solve(31.353313f,11.112246f,-97.68007f,14.30101f,10.775737f,-28.309256f,15.074988f,45.998947f,99.99547f ) ;
  }

  @Test
  public void test263() {
    color.laplace.solve(31.386866f,46.743164f,71.755455f,-21.1957f,-16.16966f,3.410462f,-100.0f,-93.636566f,-26.309338f ) ;
  }

  @Test
  public void test264() {
    color.laplace.solve(31.454231f,23.019508f,-29.325455f,2.7974188f,-10.050741f,-22.367216f,-10.213815f,-43.65268f,13.148257f ) ;
  }

  @Test
  public void test265() {
    color.laplace.solve(31.633076f,15.374584f,-5.448271f,11.157716f,9.021975f,4.809574f,3.975778f,4.745397f,15.664428f ) ;
  }

  @Test
  public void test266() {
    color.laplace.solve(31.672081f,29.753342f,14.538242f,-3.0650182f,-27.196957f,-71.60037f,-16.735199f,-63.875774f,-44.428738f ) ;
  }

  @Test
  public void test267() {
    color.laplace.solve(31.689953f,38.274765f,31.280708f,-11.514952f,-9.8715925f,-13.151899f,-67.87817f,-53.094288f,-74.01671f ) ;
  }

  @Test
  public void test268() {
    color.laplace.solve(31.718172f,27.31567f,2.717312f,-0.44298068f,-25.172804f,-99.9872f,-8.31729f,-32.82618f,-97.81463f ) ;
  }

  @Test
  public void test269() {
    color.laplace.solve(31.755445f,12.747643f,-99.99888f,14.274137f,19.234007f,-59.425076f,6.1070952f,10.154244f,60.210957f ) ;
  }

  @Test
  public void test270() {
    color.laplace.solve(31.769348f,22.705027f,9.064088f,4.372363f,-50.013332f,-99.99458f,35.733437f,-26.194532f,0f ) ;
  }

  @Test
  public void test271() {
    color.laplace.solve(-31.80556f,17.131462f,23.833641f,-7.6419353f,23.095963f,59.890656f,-21.858147f,23.00367f,-28.25614f ) ;
  }

  @Test
  public void test272() {
    color.laplace.solve(31.841661f,17.307457f,83.2576f,10.059187f,3.2967584f,-24.51374f,5.0983295f,10.33413f,14.361586f ) ;
  }

  @Test
  public void test273() {
    color.laplace.solve(31.842007f,32.939663f,19.967281f,1.2131464f,-15.4702635f,-53.071594f,-10.184909f,-39.13914f,-129.31056f ) ;
  }

  @Test
  public void test274() {
    color.laplace.solve(31.845034f,28.997263f,17.279093f,-1.6171321f,-33.13507f,-59.88089f,-5.1784887f,-19.096823f,-38.07373f ) ;
  }

  @Test
  public void test275() {
    color.laplace.solve(31.877754f,34.592075f,74.350006f,-7.081063f,-59.665333f,31.78919f,-0.53667265f,4.9343724f,79.9395f ) ;
  }

  @Test
  public void test276() {
    color.laplace.solve(31.917526f,18.593979f,-59.64183f,9.07616f,2.100201f,-19.340923f,2.2869167f,0.07150571f,-19.822062f ) ;
  }

  @Test
  public void test277() {
    color.laplace.solve(31.924942f,10.325005f,-91.28771f,17.374762f,0.66279036f,-58.97331f,36.911316f,-91.29978f,0f ) ;
  }

  @Test
  public void test278() {
    color.laplace.solve(31.933132f,43.65234f,40.89762f,-15.919475f,1.7782794f,19.938465f,-97.389786f,-40.558212f,20.924646f ) ;
  }

  @Test
  public void test279() {
    color.laplace.solve(31.944504f,10.778164f,-37.952225f,16.99985f,30.158928f,86.27369f,5.8960238f,6.584014f,-9.718906f ) ;
  }

  @Test
  public void test280() {
    color.laplace.solve(31.948374f,25.904507f,0f,15.032257f,45.533367f,-18.127708f,1.6831169f,-8.29979f,-80.41564f ) ;
  }

  @Test
  public void test281() {
    color.laplace.solve(31.980988f,42.075752f,45.61633f,-14.1518f,-9.29431f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test282() {
    color.laplace.solve(31.992327f,14.949415f,76.40786f,13.019892f,3.818482f,-64.75053f,16.268759f,52.055145f,-99.99374f ) ;
  }

  @Test
  public void test283() {
    color.laplace.solve(32.198727f,25.491268f,-12.401756f,3.3036423f,-17.831896f,-92.20981f,-1.1522619f,-7.9126897f,-12.666601f ) ;
  }

  @Test
  public void test284() {
    color.laplace.solve(32.297424f,51.42028f,52.028034f,-22.230585f,21.35567f,56.691853f,-4.072409f,5.940948f,6.4805284f ) ;
  }

  @Test
  public void test285() {
    color.laplace.solve(32.31099f,28.874176f,7.219261f,0.36978206f,-24.033543f,-99.99713f,-6.798318f,-27.563047f,-79.42033f ) ;
  }

  @Test
  public void test286() {
    color.laplace.solve(32.394657f,30.028463f,23.407364f,-0.4498326f,-35.68817f,-72.65884f,1.494183f,-99.67248f,0f ) ;
  }

  @Test
  public void test287() {
    color.laplace.solve(32.413334f,30.014639f,7.391119f,3.11301f,-18.686678f,-100.0f,-1.2746141f,-8.073958f,-38.860672f ) ;
  }

  @Test
  public void test288() {
    color.laplace.solve(32.427235f,22.494858f,-38.21661f,7.2140846f,-4.2311916f,-54.309322f,0.66029495f,-4.5728445f,-14.720541f ) ;
  }

  @Test
  public void test289() {
    color.laplace.solve(32.473583f,32.769577f,17.822117f,-2.8751893f,-19.217388f,-10.611406f,-24.756935f,-96.15255f,5.631462f ) ;
  }

  @Test
  public void test290() {
    color.laplace.solve(32.508488f,43.18549f,1.4214399f,-13.096343f,38.84005f,-137.46213f,119.39034f,0f,0f ) ;
  }

  @Test
  public void test291() {
    color.laplace.solve(32.51132f,44.294273f,73.449356f,-14.249001f,-28.783573f,-35.97172f,-6.5150185f,-11.811072f,-11.945699f ) ;
  }

  @Test
  public void test292() {
    color.laplace.solve(32.515724f,61.539097f,65.16257f,-31.475903f,48.478237f,99.11117f,-3.198443f,18.68213f,29.448526f ) ;
  }

  @Test
  public void test293() {
    color.laplace.solve(32.51928f,16.554825f,-83.7105f,13.522286f,17.410519f,36.449863f,4.1593475f,3.1151037f,-9.109452f ) ;
  }

  @Test
  public void test294() {
    color.laplace.solve(32.549206f,33.6071f,22.220417f,-3.4070797f,-20.340517f,-11.620552f,-25.83708f,-99.941536f,-40.23193f ) ;
  }

  @Test
  public void test295() {
    color.laplace.solve(32.56516f,24.09006f,-26.979057f,6.170572f,-9.225847f,-66.36543f,1.342996f,-0.7985877f,-20.53299f ) ;
  }

  @Test
  public void test296() {
    color.laplace.solve(32.72759f,26.153341f,-14.938492f,4.75701f,-13.17573f,-47.986053f,-0.5238184f,-6.8522835f,-13.709584f ) ;
  }

  @Test
  public void test297() {
    color.laplace.solve(32.768353f,20.909224f,-55.58586f,10.164179f,6.453696f,-0.83967733f,1.4363093f,-4.418756f,-26.522406f ) ;
  }

  @Test
  public void test298() {
    color.laplace.solve(32.82915f,27.121954f,-40.419617f,4.1946516f,16.078287f,-14.843217f,-32.12883f,47.839756f,-35.031536f ) ;
  }

  @Test
  public void test299() {
    color.laplace.solve(32.861366f,21.372797f,-48.864872f,10.072676f,1.4946922f,99.83214f,5.9346414f,13.665891f,47.234226f ) ;
  }

  @Test
  public void test300() {
    color.laplace.solve(32.94974f,34.45744f,-10.818668f,-2.6584806f,15.698685f,9.453033f,-59.28235f,53.43877f,0f ) ;
  }

  @Test
  public void test301() {
    color.laplace.solve(32.966972f,20.79497f,-58.49357f,11.072922f,8.706477f,3.557987f,2.6182382f,-0.5999693f,-2.6352055f ) ;
  }

  @Test
  public void test302() {
    color.laplace.solve(33.04493f,35.057175f,27.979506f,-2.8774548f,-20.795734f,-23.204058f,-23.759014f,-92.1586f,-100.0f ) ;
  }

  @Test
  public void test303() {
    color.laplace.solve(33.080048f,31.807796f,14.777566f,0.5124069f,-20.626427f,-72.69753f,-10.403993f,-42.12838f,-99.999985f ) ;
  }

  @Test
  public void test304() {
    color.laplace.solve(33.112682f,21.718605f,-51.020847f,10.732124f,4.782585f,-36.553154f,5.0332317f,9.400802f,1.0622034f ) ;
  }

  @Test
  public void test305() {
    color.laplace.solve(33.12706f,17.24358f,-92.7718f,15.264655f,28.619053f,99.982605f,-0.6874924f,-18.014624f,-99.99992f ) ;
  }

  @Test
  public void test306() {
    color.laplace.solve(33.12909f,71.849464f,0f,2.6307452f,-25.835884f,-40.444626f,3.229777f,10.288363f,63.75956f ) ;
  }

  @Test
  public void test307() {
    color.laplace.solve(33.17017f,40.603424f,32.795616f,-7.922747f,-3.552087f,-9.420966f,-2.5441165f,-2.2537186f,-2.9186714f ) ;
  }

  @Test
  public void test308() {
    color.laplace.solve(33.225418f,30.208147f,7.554542f,2.6935213f,-19.945223f,-100.0f,-2.4911113f,-12.652758f,-28.1642f ) ;
  }

  @Test
  public void test309() {
    color.laplace.solve(33.225754f,27.167795f,-14.751819f,5.731705f,-9.802755f,-64.31608f,-0.514404f,-7.8060193f,-20.906918f ) ;
  }

  @Test
  public void test310() {
    color.laplace.solve(33.326183f,34.748714f,28.013884f,-1.436377f,-22.345211f,-22.68658f,-16.72667f,-100.0f,-99.972946f ) ;
  }

  @Test
  public void test311() {
    color.laplace.solve(33.346855f,8.85224f,-47.718483f,24.535175f,-50.219414f,-37.390133f,26.904022f,26.37665f,0f ) ;
  }

  @Test
  public void test312() {
    color.laplace.solve(33.358284f,30.628057f,8.478671f,2.8098714f,-19.31887f,-96.71337f,-2.7999284f,-14.004804f,94.07186f ) ;
  }

  @Test
  public void test313() {
    color.laplace.solve(33.36505f,17.401098f,-75.43013f,16.061932f,11.68406f,-47.459045f,19.198612f,60.73609f,10.277179f ) ;
  }

  @Test
  public void test314() {
    color.laplace.solve(33.397236f,22.835222f,18.559042f,10.753724f,-60.61539f,-48.599056f,1.5074346f,-4.723985f,40.212013f ) ;
  }

  @Test
  public void test315() {
    color.laplace.solve(33.436604f,15.382843f,-91.96518f,18.363577f,20.059944f,-14.974093f,19.957756f,61.46745f,12.008861f ) ;
  }

  @Test
  public void test316() {
    color.laplace.solve(33.443565f,20.984913f,-61.215527f,12.789391f,11.711615f,1.8511653f,6.002595f,11.22099f,27.169846f ) ;
  }

  @Test
  public void test317() {
    color.laplace.solve(33.49403f,36.70277f,32.02903f,-2.7248533f,-18.71198f,-8.8236065f,-25.681463f,-100.0f,-48.611477f ) ;
  }

  @Test
  public void test318() {
    color.laplace.solve(33.49878f,25.481441f,-32.690243f,8.513674f,1.117234f,-18.767242f,-0.561316f,-10.758938f,-43.59167f ) ;
  }

  @Test
  public void test319() {
    color.laplace.solve(33.537266f,26.628174f,-23.39208f,7.520892f,-3.6324925f,-41.873337f,0.1787978f,-6.8056993f,-23.769104f ) ;
  }

  @Test
  public void test320() {
    color.laplace.solve(33.619823f,22.484587f,-56.963f,11.99471f,13.281531f,26.331528f,1.0775023f,-7.6847014f,-45.09784f ) ;
  }

  @Test
  public void test321() {
    color.laplace.solve(33.65806f,25.118563f,55.36677f,9.513633f,2.1502876f,-25.502615f,2.2461824f,-0.52843046f,-6.5077615f ) ;
  }

  @Test
  public void test322() {
    color.laplace.solve(33.682835f,76.920074f,-56.761326f,15.498966f,22.693779f,-8.619632f,5.61918f,6.975706f,-0.41098142f ) ;
  }

  @Test
  public void test323() {
    color.laplace.solve(33.69947f,30.500631f,9.682321f,4.2972536f,-21.379265f,-91.771355f,4.8688087f,15.177977f,77.22237f ) ;
  }

  @Test
  public void test324() {
    color.laplace.solve(33.70956f,18.64335f,-83.25262f,16.194887f,24.11646f,50.00838f,6.9535275f,11.619222f,15.406901f ) ;
  }

  @Test
  public void test325() {
    color.laplace.solve(33.809963f,36.876953f,42.524216f,-1.6371071f,-28.826365f,33.219913f,1.6594775f,8.275017f,60.266956f ) ;
  }

  @Test
  public void test326() {
    color.laplace.solve(33.862885f,43.690098f,57.18913f,-8.108742f,-16.289045f,91.01851f,-49.951767f,-191.67581f,66.12189f ) ;
  }

  @Test
  public void test327() {
    color.laplace.solve(33.86482f,21.660437f,-70.76873f,13.798841f,23.545658f,6.1816053f,-2.21511f,-22.659283f,0f ) ;
  }

  @Test
  public void test328() {
    color.laplace.solve(33.86486f,30.302f,-0.552783f,5.1574345f,-12.1040745f,-74.194435f,-1.1309884f,-9.681319f,-25.490269f ) ;
  }

  @Test
  public void test329() {
    color.laplace.solve(33.916622f,35.417034f,36.932518f,0.24952994f,-29.181007f,-24.833572f,-3.7374637f,-15.199385f,-27.879044f ) ;
  }

  @Test
  public void test330() {
    color.laplace.solve(33.943985f,83.51637f,0f,-8.68189f,-5.7183323f,0f,-21.312832f,-76.569435f,0f ) ;
  }

  @Test
  public void test331() {
    color.laplace.solve(33.96481f,35.3302f,20.004192f,0.5290377f,-12.648198f,-55.313435f,-19.20046f,-31.138597f,-48.246685f ) ;
  }

  @Test
  public void test332() {
    color.laplace.solve(3.401697f,-80.93619f,-29.15971f,-5.4570217f,-23.61444f,-7.0602064f,-1.6153414f,-1.0043441f,21.212406f ) ;
  }

  @Test
  public void test333() {
    color.laplace.solve(34.03404f,47.460194f,38.996696f,-11.3240385f,16.810038f,8.526587f,0f,0f,0f ) ;
  }

  @Test
  public void test334() {
    color.laplace.solve(-34.067574f,47.16466f,0f,-13.488562f,-60.866634f,0f,-25.059353f,27.583475f,0f ) ;
  }

  @Test
  public void test335() {
    color.laplace.solve(34.080597f,23.775011f,-49.532906f,12.5473795f,10.552349f,-3.791896f,5.55657f,9.678902f,22.606688f ) ;
  }

  @Test
  public void test336() {
    color.laplace.solve(34.258797f,38.5522f,24.095901f,-1.5170069f,-4.1459f,-42.16859f,-36.180927f,-11.450201f,0f ) ;
  }

  @Test
  public void test337() {
    color.laplace.solve(34.33751f,23.815477f,-51.714195f,13.534562f,12.637964f,-1.9117348f,7.1620145f,15.113495f,40.654f ) ;
  }

  @Test
  public void test338() {
    color.laplace.solve(3.436045f,-83.97018f,21.048683f,-2.5688553f,-27.03213f,96.49718f,11.00687f,42.30607f,186.59457f ) ;
  }

  @Test
  public void test339() {
    color.laplace.solve(34.371796f,28.77823f,-18.171188f,8.709158f,-1.08771f,-39.339558f,1.5526143f,-2.4986467f,-10.459551f ) ;
  }

  @Test
  public void test340() {
    color.laplace.solve(34.375507f,11.323209f,-100.0f,26.178818f,10.917377f,-8.368044f,59.422363f,14.535526f,29.5152f ) ;
  }

  @Test
  public void test341() {
    color.laplace.solve(34.438007f,-43.983036f,46.222874f,81.73507f,-34.829845f,0f,8.775328f,-46.633755f,1.7543329f ) ;
  }

  @Test
  public void test342() {
    color.laplace.solve(34.44876f,32.496124f,10.600273f,5.2989125f,-15.06453f,-100.0f,1.8114381f,1.9468415f,21.04046f ) ;
  }

  @Test
  public void test343() {
    color.laplace.solve(34.454037f,35.618404f,30.92892f,2.1977437f,-22.909336f,-11.902722f,-1.0517781f,-6.4048557f,-1.6583103f ) ;
  }

  @Test
  public void test344() {
    color.laplace.solve(34.473957f,37.92769f,0f,9.668935f,0.6587188f,13.298936f,3.5430646f,4.503323f,35.7111f ) ;
  }

  @Test
  public void test345() {
    color.laplace.solve(34.516323f,44.961678f,38.31759f,-6.896384f,7.0127997f,8.308677f,-50.5747f,-12.50242f,0f ) ;
  }

  @Test
  public void test346() {
    color.laplace.solve(-34.55538f,-36.359447f,0f,-23.278267f,-50.027103f,71.570015f,-8.530579f,-10.844048f,15.181491f ) ;
  }

  @Test
  public void test347() {
    color.laplace.solve(-34.572296f,-58.415688f,-100.0f,-10.0398445f,-3.5741606f,52.17073f,-2.012921f,1.9881603f,13.539722f ) ;
  }

  @Test
  public void test348() {
    color.laplace.solve(34.592197f,34.63896f,99.52395f,3.729819f,-95.560295f,-14.877715f,75.887375f,-56.03548f,0f ) ;
  }

  @Test
  public void test349() {
    color.laplace.solve(34.593506f,30.815376f,20.97982f,7.558646f,-32.311825f,-46.89609f,-1.8557161f,-14.981511f,-25.758505f ) ;
  }

  @Test
  public void test350() {
    color.laplace.solve(34.599907f,38.235863f,26.540674f,3.801137f,-8.125282f,-32.29593f,-9.960957f,-41.31374f,-397.6714f ) ;
  }

  @Test
  public void test351() {
    color.laplace.solve(34.63847f,31.844969f,1.4740673f,6.708915f,-8.732663f,30.385437f,0.92985374f,-2.9895005f,-4.1551924f ) ;
  }

  @Test
  public void test352() {
    color.laplace.solve(34.66232f,27.740301f,-27.146114f,10.908982f,3.4449992f,-36.07496f,5.5286493f,11.20567f,35.849033f ) ;
  }

  @Test
  public void test353() {
    color.laplace.solve(34.811413f,32.613014f,8.149101f,6.6626177f,-12.508452f,-100.0f,4.347533f,10.753454f,51.174747f ) ;
  }

  @Test
  public void test354() {
    color.laplace.solve(34.841133f,23.379135f,-63.675533f,15.985405f,22.350939f,24.971083f,6.749547f,11.012782f,14.950645f ) ;
  }

  @Test
  public void test355() {
    color.laplace.solve(34.852146f,40.283176f,14.527807f,-0.8745937f,11.752747f,-82.17194f,-100.0f,0f,0f ) ;
  }

  @Test
  public void test356() {
    color.laplace.solve(34.88962f,45.033165f,77.62049f,-5.4746804f,-32.37745f,8.692409f,-3.6238856f,-9.020863f,-0.08211349f ) ;
  }

  @Test
  public void test357() {
    color.laplace.solve(34.957317f,27.85108f,-32.750626f,11.978014f,9.197729f,-6.08694f,3.7569704f,3.048762f,-0.759688f ) ;
  }

  @Test
  public void test358() {
    color.laplace.solve(34.959324f,33.266945f,6.5583715f,6.570358f,-8.449922f,-61.43298f,-0.22797245f,-12.20401f,16.47578f ) ;
  }

  @Test
  public void test359() {
    color.laplace.solve(34.968697f,-9.028439f,-5.873101f,48.90322f,-77.710815f,0f,23.701452f,0f,0f ) ;
  }

  @Test
  public void test360() {
    color.laplace.solve(34.98229f,27.169939f,14.9756975f,12.75922f,-41.27823f,2.2533236f,4.6337953f,5.7759604f,59.748276f ) ;
  }

  @Test
  public void test361() {
    color.laplace.solve(35.103436f,17.61791f,-57.550068f,22.79583f,-7.081724f,98.19195f,63.16161f,-45.951515f,0f ) ;
  }

  @Test
  public void test362() {
    color.laplace.solve(35.10466f,29.611502f,-22.629017f,10.807132f,5.970366f,-14.344052f,2.1535034f,-2.1931179f,61.11023f ) ;
  }

  @Test
  public void test363() {
    color.laplace.solve(35.14535f,5.162908f,-14.49372f,35.418503f,-100.0f,100.0f,-0.07597968f,-35.72242f,-42.813705f ) ;
  }

  @Test
  public void test364() {
    color.laplace.solve(35.186764f,37.665726f,38.1107f,3.0813336f,-22.634562f,14.77707f,-0.22686917f,-3.9888103f,6.9061894f ) ;
  }

  @Test
  public void test365() {
    color.laplace.solve(35.203102f,45.75206f,39.741272f,-4.9396563f,8.0638685f,10.149829f,-63.025597f,-18.706758f,0f ) ;
  }

  @Test
  public void test366() {
    color.laplace.solve(35.22363f,34.922157f,15.275632f,6.0296106f,-10.585556f,-75.2914f,-0.5196298f,-8.004854f,-20.786283f ) ;
  }

  @Test
  public void test367() {
    color.laplace.solve(35.265087f,34.24023f,12.103727f,6.820118f,-10.40789f,-85.825325f,2.423274f,2.8729787f,19.47653f ) ;
  }

  @Test
  public void test368() {
    color.laplace.solve(35.275417f,32.838776f,-0.6183205f,8.262892f,-3.3019927f,-50.359325f,1.0781444f,-3.9503145f,-13.57741f ) ;
  }

  @Test
  public void test369() {
    color.laplace.solve(35.292652f,39.616333f,33.47364f,1.5542724f,-10.300961f,-5.7217665f,-18.774601f,-76.65268f,-18.874662f ) ;
  }

  @Test
  public void test370() {
    color.laplace.solve(35.34347f,37.391117f,31.72757f,3.9829147f,-17.506578f,-96.41295f,-1.9052261f,-11.604012f,-27.00424f ) ;
  }

  @Test
  public void test371() {
    color.laplace.solve(35.365654f,29.061136f,-29.377806f,12.401484f,10.2567f,-3.9686525f,3.9835784f,3.5328307f,-0.10895547f ) ;
  }

  @Test
  public void test372() {
    color.laplace.solve(35.45179f,40.678555f,20.078558f,1.1286105f,7.1838694f,-4.439641f,-38.12122f,-8.632047f,-45.020992f ) ;
  }

  @Test
  public void test373() {
    color.laplace.solve(35.526215f,14.909659f,30.720652f,27.195198f,4.8910117f,-6.7769923f,68.36356f,-15.763819f,-7.848872f ) ;
  }

  @Test
  public void test374() {
    color.laplace.solve(35.674187f,36.34364f,26.727741f,6.353101f,-17.027369f,-29.432676f,6.7655864f,-81.373535f,-48.59446f ) ;
  }

  @Test
  public void test375() {
    color.laplace.solve(35.686657f,32.268425f,-13.607475f,10.479283f,6.9945207f,-1.2369229f,-0.76234096f,-13.528646f,-60.346767f ) ;
  }

  @Test
  public void test376() {
    color.laplace.solve(35.70892f,40.32138f,51.595932f,2.514305f,-26.019337f,12.047101f,0.36763647f,-1.0437592f,40.789577f ) ;
  }

  @Test
  public void test377() {
    color.laplace.solve(35.714775f,28.872255f,-35.149235f,13.986846f,14.92348f,31.217497f,5.309128f,7.249665f,8.766051f ) ;
  }

  @Test
  public void test378() {
    color.laplace.solve(35.767513f,38.183357f,33.882725f,4.8866935f,-16.916803f,32.2716f,0.69606334f,-2.10244f,7.81098f ) ;
  }

  @Test
  public void test379() {
    color.laplace.solve(35.79037f,93.96223f,0f,-50.800735f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test380() {
    color.laplace.solve(35.864708f,24.313366f,4.879244f,19.145464f,27.399645f,32.01521f,13.3175f,34.12454f,95.78195f ) ;
  }

  @Test
  public void test381() {
    color.laplace.solve(35.886803f,27.264647f,-49.441326f,16.282558f,22.61311f,36.607468f,6.6303267f,10.238748f,11.711555f ) ;
  }

  @Test
  public void test382() {
    color.laplace.solve(35.892593f,35.962044f,15.456681f,7.6083283f,-7.5009403f,-74.13532f,2.042377f,0.56126106f,-75.312584f ) ;
  }

  @Test
  public void test383() {
    color.laplace.solve(35.919098f,41.926014f,64.13356f,1.7503744f,-32.348606f,-70.97611f,10.207152f,0f,0f ) ;
  }

  @Test
  public void test384() {
    color.laplace.solve(36.009083f,42.196564f,25.499006f,1.8397657f,7.27816f,-40.20054f,-35.92818f,-0.7902678f,0f ) ;
  }

  @Test
  public void test385() {
    color.laplace.solve(36.04413f,42.877083f,59.501583f,1.2996333f,-24.037378f,17.69918f,-6.8051276f,-28.520144f,-83.23807f ) ;
  }

  @Test
  public void test386() {
    color.laplace.solve(36.047546f,45.387775f,41.60011f,-1.197573f,3.9034448f,21.012672f,-44.741287f,-49.589096f,-12.561486f ) ;
  }

  @Test
  public void test387() {
    color.laplace.solve(36.118675f,37.082123f,16.682716f,7.392576f,-4.4729033f,-46.671867f,-2.0754673f,-15.694445f,-56.22941f ) ;
  }

  @Test
  public void test388() {
    color.laplace.solve(-36.1751f,-214.2915f,229.68697f,-30.292713f,-63.07401f,47.643482f,-21.595346f,-55.169395f,-136.47377f ) ;
  }

  @Test
  public void test389() {
    color.laplace.solve(36.178818f,48.40767f,40.28011f,-3.6923933f,17.171741f,32.624733f,-68.12013f,-8.653038f,73.04708f ) ;
  }

  @Test
  public void test390() {
    color.laplace.solve(36.28129f,37.71756f,20.276087f,7.407589f,-5.687135f,-56.613213f,-0.9637964f,-11.262774f,-38.400166f ) ;
  }

  @Test
  public void test391() {
    color.laplace.solve(36.28959f,32.73176f,-11.461938f,12.426603f,6.099379f,-37.60402f,7.317445f,16.843176f,-40.606937f ) ;
  }

  @Test
  public void test392() {
    color.laplace.solve(36.314568f,42.069664f,37.49609f,3.1886165f,-5.5320063f,7.9146996f,-18.028097f,-75.301f,-100.0f ) ;
  }

  @Test
  public void test393() {
    color.laplace.solve(36.380577f,39.95028f,33.105675f,5.5720277f,-9.685139f,-61.06152f,-4.407328f,-23.20134f,-78.71289f ) ;
  }

  @Test
  public void test394() {
    color.laplace.solve(36.40508f,41.839867f,36.064022f,3.7804482f,-5.1096315f,2.4162228f,-16.173655f,-68.47507f,-3.4215362f ) ;
  }

  @Test
  public void test395() {
    color.laplace.solve(36.463047f,27.479744f,-26.91982f,18.372442f,0.37574887f,100.0f,5.5196056f,3.7059803f,8.928567f ) ;
  }

  @Test
  public void test396() {
    color.laplace.solve(36.470116f,37.941326f,22.607357f,7.9391313f,-7.3121696f,-77.584335f,2.598584f,2.4552042f,14.534403f ) ;
  }

  @Test
  public void test397() {
    color.laplace.solve(36.53523f,22.411783f,-89.4383f,23.729132f,42.55021f,-20.96429f,15.831086f,39.595215f,99.999565f ) ;
  }

  @Test
  public void test398() {
    color.laplace.solve(36.5547f,37.651226f,9.202772f,8.5675745f,4.847431f,10.265822f,-7.1318307f,-37.0949f,39.29746f ) ;
  }

  @Test
  public void test399() {
    color.laplace.solve(36.573975f,37.90542f,20.52919f,8.390133f,-5.4814863f,-55.789165f,2.4682925f,1.4830366f,8.945852f ) ;
  }

  @Test
  public void test400() {
    color.laplace.solve(36.60967f,37.243774f,16.517391f,9.19312f,-4.151955f,-71.17599f,4.315273f,8.06797f,41.100033f ) ;
  }

  @Test
  public void test401() {
    color.laplace.solve(36.67363f,33.628952f,-13.684876f,13.065573f,11.527059f,-3.7671242f,4.061601f,3.1808314f,-9.019405f ) ;
  }

  @Test
  public void test402() {
    color.laplace.solve(36.703625f,33.22588f,-11.300141f,13.588614f,13.065392f,0.69392437f,4.585441f,4.7531505f,1.3617687f ) ;
  }

  @Test
  public void test403() {
    color.laplace.solve(36.704144f,28.634892f,-53.071247f,18.18168f,30.906673f,-22.338293f,5.115924f,2.2819755f,-26.894728f ) ;
  }

  @Test
  public void test404() {
    color.laplace.solve(36.728176f,36.864372f,14.331148f,10.048338f,-3.601839f,-79.53978f,7.067013f,18.219713f,-100.0f ) ;
  }

  @Test
  public void test405() {
    color.laplace.solve(36.787037f,27.688015f,-54.296127f,19.460129f,28.261152f,34.187283f,12.792328f,31.709183f,18.26468f ) ;
  }

  @Test
  public void test406() {
    color.laplace.solve(36.884377f,45.019226f,46.08756f,2.5182803f,-2.8950365f,39.065502f,-23.916218f,-98.18315f,100.0f ) ;
  }

  @Test
  public void test407() {
    color.laplace.solve(36.927414f,33.689552f,-14.673526f,14.020104f,14.302472f,4.118216f,4.8505297f,5.3820148f,2.3750577f ) ;
  }

  @Test
  public void test408() {
    color.laplace.solve(36.939674f,43.06527f,43.151546f,4.693427f,-7.8301473f,29.540916f,-10.335819f,-46.036705f,96.36872f ) ;
  }

  @Test
  public void test409() {
    color.laplace.solve(36.95156f,44.461792f,45.60564f,3.344458f,-4.7100306f,12.152885f,-18.8637f,-78.799255f,7.715932f ) ;
  }

  @Test
  public void test410() {
    color.laplace.solve(36.994247f,13.17104f,0f,35.824158f,89.99793f,-79.5858f,16.304453f,29.393656f,11.272237f ) ;
  }

  @Test
  public void test411() {
    color.laplace.solve(37.00085f,36.319794f,12.995716f,11.683618f,-4.7173986f,-85.15909f,14.451017f,18.286085f,-24.334211f ) ;
  }

  @Test
  public void test412() {
    color.laplace.solve(37.061264f,30.58135f,-49.27476f,17.663713f,34.5389f,-82.89341f,-0.9453116f,-21.44496f,14.318648f ) ;
  }

  @Test
  public void test413() {
    color.laplace.solve(37.063572f,-13.160832f,90.31172f,61.41511f,30.669407f,0f,36.049557f,-5.5520234f,0f ) ;
  }

  @Test
  public void test414() {
    color.laplace.solve(37.080536f,41.522697f,30.969551f,6.805648f,-1.9556713f,-17.747755f,-7.8997693f,-38.40328f,-99.999985f ) ;
  }

  @Test
  public void test415() {
    color.laplace.solve(37.092617f,21.622814f,37.828323f,26.747656f,-88.42969f,29.690481f,-7.594356f,-57.12508f,100.0f ) ;
  }

  @Test
  public void test416() {
    color.laplace.solve(37.11771f,39.02904f,5.2956295f,9.441802f,13.702826f,14.664153f,-13.0533285f,-8.323694f,39.658157f ) ;
  }

  @Test
  public void test417() {
    color.laplace.solve(37.143024f,40.073193f,28.421701f,8.498908f,-5.27195f,-26.386389f,2.1245565f,-43.273514f,100.0f ) ;
  }

  @Test
  public void test418() {
    color.laplace.solve(37.192482f,43.131638f,34.14826f,5.6382957f,1.1858108f,-6.5386f,-15.825112f,-68.93874f,81.30494f ) ;
  }

  @Test
  public void test419() {
    color.laplace.solve(37.220287f,45.091076f,47.972965f,3.7914436f,-4.828955f,4.482727f,-17.221275f,-72.676544f,-25.213104f ) ;
  }

  @Test
  public void test420() {
    color.laplace.solve(37.226124f,44.52498f,57.10161f,4.3795137f,-16.227823f,-95.515305f,-3.480243f,-18.300486f,12.184651f ) ;
  }

  @Test
  public void test421() {
    color.laplace.solve(37.254158f,33.41302f,-24.538967f,15.603612f,20.936888f,-81.291176f,4.223403f,1.2899992f,-20.000294f ) ;
  }

  @Test
  public void test422() {
    color.laplace.solve(37.29632f,41.8199f,31.005152f,7.7972274f,-1.0537292f,-17.512144f,-4.506854f,-26.005577f,-100.0f ) ;
  }

  @Test
  public void test423() {
    color.laplace.solve(37.361633f,42.67585f,50.60903f,6.7706847f,-17.267263f,59.76027f,6.9883695f,21.182793f,-40.602486f ) ;
  }

  @Test
  public void test424() {
    color.laplace.solve(37.42284f,28.860727f,-26.558481f,20.830564f,4.578549f,10.932066f,41.32087f,-42.309162f,65.7082f ) ;
  }

  @Test
  public void test425() {
    color.laplace.solve(37.46167f,45.02896f,42.83261f,4.818287f,-0.1778229f,26.301601f,-18.010635f,-76.86014f,-99.82803f ) ;
  }

  @Test
  public void test426() {
    color.laplace.solve(37.51189f,36.750145f,-18.35551f,13.297416f,27.844202f,-18.759342f,-12.166431f,80.08859f,100.0f ) ;
  }

  @Test
  public void test427() {
    color.laplace.solve(37.52377f,36.731018f,-4.277247f,13.364063f,13.677546f,83.24219f,1.9559664f,-5.540198f,-37.794304f ) ;
  }

  @Test
  public void test428() {
    color.laplace.solve(37.53394f,43.246143f,35.305813f,6.889614f,0.16664144f,-2.022893f,-10.142094f,-47.45799f,-91.398285f ) ;
  }

  @Test
  public void test429() {
    color.laplace.solve(37.53996f,40.722195f,14.483672f,9.437646f,10.865145f,-82.787506f,5.662582f,13.212682f,36.323f ) ;
  }

  @Test
  public void test430() {
    color.laplace.solve(37.54736f,35.527637f,-11.8215275f,14.661802f,16.38472f,-98.82649f,4.7151284f,4.198712f,-4.305002f ) ;
  }

  @Test
  public void test431() {
    color.laplace.solve(37.600273f,49.200333f,86.50603f,1.200756f,-27.304974f,100.0f,-5.4922748f,-23.169855f,-59.88217f ) ;
  }

  @Test
  public void test432() {
    color.laplace.solve(37.61455f,38.981113f,10.82174f,11.4770975f,7.488155f,-12.2512245f,0.80568326f,-8.254365f,-41.3113f ) ;
  }

  @Test
  public void test433() {
    color.laplace.solve(37.648792f,43.989212f,37.613693f,6.6059575f,0.6943647f,6.4655533f,-11.919327f,-54.283264f,42.637524f ) ;
  }

  @Test
  public void test434() {
    color.laplace.solve(37.664036f,32.78049f,86.52581f,17.875645f,24.109262f,24.739481f,9.729269f,21.041426f,50.327152f ) ;
  }

  @Test
  public void test435() {
    color.laplace.solve(37.693424f,43.60584f,36.04233f,7.167829f,0.6875779f,-2.0167565f,-9.709688f,-46.00662f,-99.99964f ) ;
  }

  @Test
  public void test436() {
    color.laplace.solve(37.841183f,38.202366f,2.3866851f,13.162361f,12.581598f,3.2173758f,2.2266629f,-4.255709f,-72.56394f ) ;
  }

  @Test
  public void test437() {
    color.laplace.solve(37.879807f,43.348244f,33.740738f,8.170981f,1.772429f,-8.385288f,-6.96831f,-36.04422f,-99.32109f ) ;
  }

  @Test
  public void test438() {
    color.laplace.solve(37.88813f,44.92465f,56.26591f,6.6278725f,-12.09029f,70.84454f,0.71365094f,-3.773269f,-3.7164366f ) ;
  }

  @Test
  public void test439() {
    color.laplace.solve(37.89906f,45.448223f,43.898308f,6.148011f,-0.004468773f,7.744085f,-13.3025465f,-59.358196f,-12.917499f ) ;
  }

  @Test
  public void test440() {
    color.laplace.solve(37.91902f,41.709988f,27.408983f,9.966097f,1.5119438f,-37.3959f,0.4334222f,-8.232408f,-34.874996f ) ;
  }

  @Test
  public void test441() {
    color.laplace.solve(37.986206f,37.958267f,0.4333341f,13.986554f,13.413531f,-2.4900668f,4.546481f,4.1993704f,-1.1625309f ) ;
  }

  @Test
  public void test442() {
    color.laplace.solve(38.027138f,41.139824f,27.541151f,10.968724f,-1.0089892f,-70.76042f,6.8567486f,16.458271f,59.98532f ) ;
  }

  @Test
  public void test443() {
    color.laplace.solve(38.09645f,37.7301f,27.007933f,14.655606f,16.090223f,8.806273f,4.456106f,3.168818f,-7.873215f ) ;
  }

  @Test
  public void test444() {
    color.laplace.solve(38.112656f,42.520466f,29.110138f,9.930163f,2.8590677f,-26.079914f,-1.2510705f,-14.934445f,100.0f ) ;
  }

  @Test
  public void test445() {
    color.laplace.solve(38.181046f,40.860798f,22.083925f,11.863388f,3.1782162f,-52.525093f,6.0942903f,12.513773f,40.782585f ) ;
  }

  @Test
  public void test446() {
    color.laplace.solve(38.185352f,43.45126f,32.692696f,9.290156f,2.9269817f,-15.936496f,-3.951709f,-25.096992f,-99.36566f ) ;
  }

  @Test
  public void test447() {
    color.laplace.solve(38.227394f,37.972008f,10.650667f,14.943366f,3.0195026f,-100.0f,18.526567f,59.168705f,-99.779396f ) ;
  }

  @Test
  public void test448() {
    color.laplace.solve(38.24117f,43.620815f,32.7833f,9.343864f,3.4587922f,-12.487623f,-4.324506f,-26.641888f,-99.992065f ) ;
  }

  @Test
  public void test449() {
    color.laplace.solve(38.266594f,43.07999f,26.15485f,9.986385f,7.89852f,-38.460594f,-6.2195716f,-61.124744f,0f ) ;
  }

  @Test
  public void test450() {
    color.laplace.solve(38.28339f,43.69084f,35.04169f,9.63718f,1.6083848f,-5.6770096f,-1.3430558f,-14.814821f,-59.00509f ) ;
  }

  @Test
  public void test451() {
    color.laplace.solve(38.32151f,45.45353f,39.558636f,7.832515f,3.9339716f,15.764322f,-11.213267f,-52.68558f,-5.310788f ) ;
  }

  @Test
  public void test452() {
    color.laplace.solve(38.369663f,44.439903f,35.33153f,9.038743f,4.0584207f,-3.1137822f,-6.2731094f,-34.131184f,-100.0f ) ;
  }

  @Test
  public void test453() {
    color.laplace.solve(38.40469f,42.03484f,25.509031f,11.583921f,4.2181883f,-39.99871f,3.7091558f,3.25414f,21.789993f ) ;
  }

  @Test
  public void test454() {
    color.laplace.solve(38.408443f,43.52555f,43.282642f,10.108221f,-7.588879f,10.029621f,9.613305f,-94.01891f,4.424723f ) ;
  }

  @Test
  public void test455() {
    color.laplace.solve(38.440422f,34.64237f,-35.189808f,19.119328f,35.318855f,49.383495f,2.718029f,-8.2472105f,-71.02573f ) ;
  }

  @Test
  public void test456() {
    color.laplace.solve(38.453312f,44.963295f,36.78194f,8.849945f,4.61793f,-27.06726f,-7.6714597f,-8.2742605f,32.825676f ) ;
  }

  @Test
  public void test457() {
    color.laplace.solve(38.46663f,54.117123f,59.25991f,-0.25060824f,18.741959f,28.77386f,-58.21102f,-7.67254f,-66.041534f ) ;
  }

  @Test
  public void test458() {
    color.laplace.solve(38.526955f,42.421623f,26.367085f,11.686193f,4.792452f,-36.95328f,3.4253666f,2.0152733f,-0.15672489f ) ;
  }

  @Test
  public void test459() {
    color.laplace.solve(38.556286f,38.262833f,9.565708f,15.962309f,4.9293313f,-100.0f,20.36362f,65.49217f,-64.12595f ) ;
  }

  @Test
  public void test460() {
    color.laplace.solve(38.55707f,46.184135f,52.8237f,8.044153f,-6.6442347f,-73.81617f,0.26377463f,-6.989054f,-21.575758f ) ;
  }

  @Test
  public void test461() {
    color.laplace.solve(38.560104f,44.238213f,33.507008f,10.027156f,5.022466f,-10.210187f,-3.4739432f,-23.940289f,-97.30968f ) ;
  }

  @Test
  public void test462() {
    color.laplace.solve(38.562317f,49.782364f,49.60808f,4.4669f,10.959053f,48.64997f,-31.65377f,-59.06302f,-100.0f ) ;
  }

  @Test
  public void test463() {
    color.laplace.solve(38.570187f,32.46004f,-42.507618f,21.820707f,33.77759f,52.70437f,14.935048f,37.919487f,51.425735f ) ;
  }

  @Test
  public void test464() {
    color.laplace.solve(38.654083f,34.74591f,-32.0552f,19.870417f,32.384754f,61.021805f,8.442827f,13.900891f,14.775983f ) ;
  }

  @Test
  public void test465() {
    color.laplace.solve(38.76534f,49.35039f,75.388916f,5.710961f,-16.752693f,26.879654f,0.8311978f,-2.3861752f,6.3767943f ) ;
  }

  @Test
  public void test466() {
    color.laplace.solve(38.772038f,49.482693f,81.346794f,5.605451f,-22.18806f,-85.046036f,5.837828f,-58.794353f,17.586496f ) ;
  }

  @Test
  public void test467() {
    color.laplace.solve(38.9302f,36.933365f,-14.836456f,18.787432f,23.639715f,7.3062587f,12.57981f,31.531809f,100.0f ) ;
  }

  @Test
  public void test468() {
    color.laplace.solve(38.950752f,44.866287f,33.743244f,10.937457f,6.7721715f,-9.892961f,-1.9712703f,-18.822105f,-80.08932f ) ;
  }

  @Test
  public void test469() {
    color.laplace.solve(38.951473f,41.74421f,24.474573f,14.0616865f,3.5507898f,-43.845917f,13.744483f,-12.404687f,0f ) ;
  }

  @Test
  public void test470() {
    color.laplace.solve(38.962387f,46.50812f,37.88526f,9.341429f,9.18484f,4.168287f,-10.781514f,-23.278475f,-98.08326f ) ;
  }

  @Test
  public void test471() {
    color.laplace.solve(38.972675f,49.26843f,65.89217f,6.6222796f,-7.7911406f,-61.66332f,-4.6924176f,-25.39195f,-92.355736f ) ;
  }

  @Test
  public void test472() {
    color.laplace.solve(38.987305f,43.702305f,29.094585f,12.246913f,6.7273283f,-27.323965f,3.2730186f,0.8451615f,-6.619701f ) ;
  }

  @Test
  public void test473() {
    color.laplace.solve(39.01079f,48.254826f,40.27018f,7.788339f,13.738336f,12.399953f,-21.59577f,-13.489776f,-4.408703f ) ;
  }

  @Test
  public void test474() {
    color.laplace.solve(39.1616f,45.790756f,36.24427f,10.851828f,7.757153f,-0.813671f,-3.5131962f,-24.8003f,-59.05734f ) ;
  }

  @Test
  public void test475() {
    color.laplace.solve(39.19226f,48.63087f,57.448418f,8.13817f,-2.1171992f,-39.010147f,-4.5223804f,-26.227692f,-98.27119f ) ;
  }

  @Test
  public void test476() {
    color.laplace.solve(39.276966f,36.003536f,9.858844f,21.10433f,-5.1216617f,-96.56816f,50.262012f,18.97365f,98.20576f ) ;
  }

  @Test
  public void test477() {
    color.laplace.solve(39.28982f,44.519753f,30.98f,12.639529f,7.8091865f,-27.119452f,3.4591115f,1.196916f,-6.4806337f ) ;
  }

  @Test
  public void test478() {
    color.laplace.solve(39.392887f,45.417595f,35.008728f,12.154915f,7.2687626f,-24.173552f,1.9577135f,-4.3230987f,-26.518871f ) ;
  }

  @Test
  public void test479() {
    color.laplace.solve(39.479176f,41.001526f,3.9917376f,16.915337f,20.535158f,10.550922f,7.647043f,13.672836f,-100.0f ) ;
  }

  @Test
  public void test480() {
    color.laplace.solve(39.497795f,44.330112f,28.384132f,13.661063f,9.439031f,-30.793583f,5.707463f,9.1687565f,21.528534f ) ;
  }

  @Test
  public void test481() {
    color.laplace.solve(39.52327f,52.472046f,83.593025f,5.6210265f,-13.227887f,-90.13874f,-3.8110492f,-20.865728f,-62.434544f ) ;
  }

  @Test
  public void test482() {
    color.laplace.solve(39.561012f,47.14485f,39.602848f,11.099198f,9.4155445f,8.836381f,-4.5797634f,-29.418253f,-27.261297f ) ;
  }

  @Test
  public void test483() {
    color.laplace.solve(39.62727f,47.65134f,48.000595f,10.85774f,2.9774964f,8.751176f,0.826194f,-55.35027f,-15.97339f ) ;
  }

  @Test
  public void test484() {
    color.laplace.solve(39.69835f,41.55974f,15.645059f,17.23366f,10.895544f,-78.97951f,18.340742f,56.129314f,-74.43672f ) ;
  }

  @Test
  public void test485() {
    color.laplace.solve(39.75735f,46.863068f,37.18921f,12.166337f,10.505709f,1.8937749f,-1.5977123f,-18.557186f,-83.13674f ) ;
  }

  @Test
  public void test486() {
    color.laplace.solve(39.75769f,21.563244f,17.338219f,37.467514f,-70.84293f,-52.21037f,5.682727f,-14.736606f,6.2137837f ) ;
  }

  @Test
  public void test487() {
    color.laplace.solve(39.799263f,48.216225f,42.44163f,10.980823f,10.624008f,20.279724f,-6.4999795f,-36.98074f,28.053259f ) ;
  }

  @Test
  public void test488() {
    color.laplace.solve(39.826477f,45.58156f,34.772312f,13.724357f,7.727442f,-6.492313f,7.343508f,15.649674f,47.52775f ) ;
  }

  @Test
  public void test489() {
    color.laplace.solve(39.8347f,31.884966f,-15.039502f,27.453842f,2.7446606f,0.4381055f,67.23603f,-48.79831f,14.047302f ) ;
  }

  @Test
  public void test490() {
    color.laplace.solve(39.942978f,40.694748f,-3.6195695f,19.07716f,26.455578f,43.655304f,9.911431f,20.568567f,99.91664f ) ;
  }

  @Test
  public void test491() {
    color.laplace.solve(39.946297f,57.725857f,98.26787f,2.058799f,-7.310669f,10.638185f,-24.40168f,-99.66552f,-48.40457f ) ;
  }

  @Test
  public void test492() {
    color.laplace.solve(39.96499f,45.01862f,28.447159f,14.858408f,11.666401f,-31.222477f,8.216172f,18.011051f,52.161633f ) ;
  }

  @Test
  public void test493() {
    color.laplace.solve(40.005127f,41.57529f,35.508205f,18.445223f,-9.212177f,-0.104954414f,42.98794f,-96.76427f,-26.715847f ) ;
  }

  @Test
  public void test494() {
    color.laplace.solve(40.00759f,55.82602f,49.321827f,4.204352f,33.97466f,41.23809f,-57.164845f,34.630173f,0f ) ;
  }

  @Test
  public void test495() {
    color.laplace.solve(40.08346f,47.69492f,39.648907f,12.638927f,14.821025f,11.251551f,3.2708077f,1.5738255f,3.2132783f ) ;
  }

  @Test
  public void test496() {
    color.laplace.solve(40.109154f,47.1629f,39.964684f,13.273714f,8.596865f,13.224521f,4.4022856f,4.3354278f,4.3317127f ) ;
  }

  @Test
  public void test497() {
    color.laplace.solve(40.127888f,44.13359f,16.972631f,16.377958f,19.433838f,9.801329f,5.950108f,7.422474f,4.3059506f ) ;
  }

  @Test
  public void test498() {
    color.laplace.solve(40.142056f,51.28135f,55.601227f,9.286877f,9.382114f,64.67065f,-12.376663f,-87.71041f,98.88459f ) ;
  }

  @Test
  public void test499() {
    color.laplace.solve(4.014927f,-55.12157f,-29.16466f,-28.818722f,-35.01249f,-19.25827f,-84.27732f,-36.851402f,-12.855931f ) ;
  }

  @Test
  public void test500() {
    color.laplace.solve(40.16341f,50.57004f,60.253387f,10.083603f,1.8633702f,90.443504f,4.0049686f,5.9362707f,17.876745f ) ;
  }

  @Test
  public void test501() {
    color.laplace.solve(40.169453f,41.256157f,-4.5176463f,19.42166f,29.37282f,47.26812f,8.144362f,13.155789f,15.105977f ) ;
  }

  @Test
  public void test502() {
    color.laplace.solve(40.18055f,46.425003f,32.88125f,14.297193f,12.403327f,-14.900005f,4.5220776f,3.791117f,-2.777222f ) ;
  }

  @Test
  public void test503() {
    color.laplace.solve(40.216923f,44.387535f,17.635595f,16.480152f,19.697626f,10.378738f,6.0060573f,7.544078f,4.4726276f ) ;
  }

  @Test
  public void test504() {
    color.laplace.solve(40.24255f,55.654564f,99.6207f,5.3156414f,-9.38621f,76.5041f,-9.593777f,-43.690746f,0f ) ;
  }

  @Test
  public void test505() {
    color.laplace.solve(40.27132f,48.126522f,44.516758f,12.958754f,7.718005f,-32.637257f,3.8456893f,2.4240036f,-1.8676798f ) ;
  }

  @Test
  public void test506() {
    color.laplace.solve(40.29571f,49.22045f,41.82677f,11.962394f,14.759329f,18.086628f,-7.205465f,-20.23216f,-7.496526f ) ;
  }

  @Test
  public void test507() {
    color.laplace.solve(40.351406f,46.871662f,33.95981f,14.533967f,13.175439f,-12.605998f,4.6090226f,3.9021232f,-2.1759686f ) ;
  }

  @Test
  public void test508() {
    color.laplace.solve(40.35952f,49.379955f,43.815857f,12.058133f,13.344434f,25.88348f,-5.4714246f,-33.94383f,-100.0f ) ;
  }

  @Test
  public void test509() {
    color.laplace.solve(40.37288f,45.85355f,30.051407f,15.637962f,12.989917f,-25.647923f,9.1890545f,21.11825f,-99.996185f ) ;
  }

  @Test
  public void test510() {
    color.laplace.solve(40.376163f,46.718006f,33.073765f,14.78665f,13.4221f,-14.422948f,5.3483343f,6.6066923f,-98.91596f ) ;
  }

  @Test
  public void test511() {
    color.laplace.solve(40.38183f,43.812904f,10.967883f,17.714417f,23.893932f,-99.91997f,6.608471f,8.813582f,4.7519264f ) ;
  }

  @Test
  public void test512() {
    color.laplace.solve(40.400917f,56.833115f,95.06061f,4.770552f,-8.1290655f,-36.5908f,-13.189643f,-57.529125f,-100.0f ) ;
  }

  @Test
  public void test513() {
    color.laplace.solve(40.433186f,50.19221f,44.99109f,11.540535f,15.344576f,49.6486f,-9.615626f,-50.00304f,-29.918072f ) ;
  }

  @Test
  public void test514() {
    color.laplace.solve(40.478546f,53.332767f,49.72568f,8.581417f,23.126844f,45.569954f,-29.279722f,-14.97676f,-16.641174f ) ;
  }

  @Test
  public void test515() {
    color.laplace.solve(40.488045f,48.01524f,37.53359f,14.020963f,14.061791f,2.0931299f,1.5617065f,-7.7741365f,-46.699238f ) ;
  }

  @Test
  public void test516() {
    color.laplace.solve(40.522316f,51.18363f,58.265022f,10.905637f,5.94719f,-99.64262f,1.6818696f,-4.1781583f,-24.341692f ) ;
  }

  @Test
  public void test517() {
    color.laplace.solve(40.53767f,32.630604f,-38.37623f,29.520075f,28.360968f,58.941025f,49.18166f,-7.6478276f,100.0f ) ;
  }

  @Test
  public void test518() {
    color.laplace.solve(40.632908f,48.230164f,40.63285f,14.301565f,11.654898f,14.301268f,4.9185357f,5.3726835f,4.9172997f ) ;
  }

  @Test
  public void test519() {
    color.laplace.solve(40.788284f,18.831648f,34.508553f,44.321487f,-99.970245f,19.202555f,4.244623f,-27.342995f,-13.64636f ) ;
  }

  @Test
  public void test520() {
    color.laplace.solve(40.823483f,47.59045f,34.064514f,15.703472f,15.473911f,-11.761202f,6.516625f,10.363029f,19.461622f ) ;
  }

  @Test
  public void test521() {
    color.laplace.solve(40.828194f,45.792507f,17.65782f,17.520267f,24.684021f,-75.16123f,4.5688562f,0.7551572f,-26.232248f ) ;
  }

  @Test
  public void test522() {
    color.laplace.solve(40.836014f,46.353596f,53.8757f,16.990463f,16.136011f,-25.768715f,10.989792f,26.968914f,80.74985f ) ;
  }

  @Test
  public void test523() {
    color.laplace.solve(40.860283f,50.121452f,51.361122f,13.3199005f,8.263578f,-33.690105f,4.1557417f,3.3030655f,0.79426706f ) ;
  }

  @Test
  public void test524() {
    color.laplace.solve(40.90076f,49.64848f,53.818703f,13.954558f,3.874456f,65.626335f,11.043017f,83.86615f,0f ) ;
  }

  @Test
  public void test525() {
    color.laplace.solve(40.914253f,26.19067f,-51.19358f,37.466347f,15.042011f,-97.28064f,93.90913f,93.791664f,50.779644f ) ;
  }

  @Test
  public void test526() {
    color.laplace.solve(41.119396f,49.203083f,41.1194f,15.2745075f,14.573542f,15.274515f,5.405111f,6.345936f,5.4051127f ) ;
  }

  @Test
  public void test527() {
    color.laplace.solve(41.119587f,53.040825f,54.152306f,11.437526f,16.891409f,63.568394f,-12.260896f,-60.481106f,-99.9999f ) ;
  }

  @Test
  public void test528() {
    color.laplace.solve(41.127544f,52.5796f,52.16942f,11.930571f,17.02145f,56.098064f,-10.42671f,-53.63741f,0f ) ;
  }

  @Test
  public void test529() {
    color.laplace.solve(41.196342f,48.658268f,35.606697f,16.127108f,17.83003f,-6.2314863f,5.482058f,5.8011246f,-0.107590444f ) ;
  }

  @Test
  public void test530() {
    color.laplace.solve(41.20491f,55.5029f,63.517143f,9.31676f,17.289637f,98.565674f,-21.227505f,-94.226776f,-68.48514f ) ;
  }

  @Test
  public void test531() {
    color.laplace.solve(41.209415f,48.96826f,37.870377f,15.869845f,16.793367f,-3.7028177f,5.4770064f,6.0381794f,1.8833055f ) ;
  }

  @Test
  public void test532() {
    color.laplace.solve(41.216614f,50.1061f,31.561337f,14.760349f,27.646444f,-23.901642f,-9.821659f,69.62098f,22.201351f ) ;
  }

  @Test
  public void test533() {
    color.laplace.solve(41.226227f,56.420494f,92.75297f,8.484409f,-8.317945f,-28.999308f,1.0294412f,-4.366645f,-8.341427f ) ;
  }

  @Test
  public void test534() {
    color.laplace.solve(41.33342f,47.029034f,21.995443f,18.304499f,24.787277f,23.730892f,7.0973406f,10.084622f,8.453872f ) ;
  }

  @Test
  public void test535() {
    color.laplace.solve(41.357277f,49.73772f,39.59246f,15.691393f,18.001146f,8.632128f,3.4071462f,-2.0628083f,-29.659525f ) ;
  }

  @Test
  public void test536() {
    color.laplace.solve(41.40161f,37.51187f,-88.61881f,28.220465f,97.355675f,-126.11043f,-25.190292f,-128.82713f,59.910835f ) ;
  }

  @Test
  public void test537() {
    color.laplace.solve(41.421124f,42.33842f,35.599777f,23.346067f,-7.6672106f,0.0606822f,59.630356f,-96.41402f,-27.689837f ) ;
  }

  @Test
  public void test538() {
    color.laplace.solve(41.48053f,49.923744f,41.410805f,15.998377f,16.803637f,15.979783f,5.709339f,6.8389807f,5.704691f ) ;
  }

  @Test
  public void test539() {
    color.laplace.solve(41.50237f,26.628452f,25.726576f,39.381027f,-60.71514f,-23.722145f,5.7880845f,-16.228691f,-9.987709f ) ;
  }

  @Test
  public void test540() {
    color.laplace.solve(-41.56031f,-18.011766f,5.1870456f,-15.070863f,-12.489233f,-7.0095315f,-6.233908f,-9.86477f,-20.735939f ) ;
  }

  @Test
  public void test541() {
    color.laplace.solve(41.566673f,3.6227932f,31.501947f,62.6439f,68.14228f,54.664055f,24.992155f,37.324715f,56.16442f ) ;
  }

  @Test
  public void test542() {
    color.laplace.solve(41.584274f,50.459938f,41.31007f,15.812029f,18.945183f,14.780339f,2.6296782f,-5.291355f,-42.74051f ) ;
  }

  @Test
  public void test543() {
    color.laplace.solve(41.625828f,48.798443f,35.043587f,17.704863f,18.524355f,-17.3781f,10.669269f,24.972206f,70.62143f ) ;
  }

  @Test
  public void test544() {
    color.laplace.solve(41.6425f,49.704556f,38.195415f,16.865444f,18.984875f,-1.1360819f,6.8478465f,10.5261f,-61.724625f ) ;
  }

  @Test
  public void test545() {
    color.laplace.solve(41.671642f,48.867104f,34.329075f,17.81949f,19.467695f,-11.5507965f,10.13862f,22.734991f,-100.0f ) ;
  }

  @Test
  public void test546() {
    color.laplace.solve(41.698917f,46.38769f,14.722094f,20.407988f,29.129776f,26.918377f,10.803259f,22.805056f,63.821632f ) ;
  }

  @Test
  public void test547() {
    color.laplace.solve(41.715656f,6.7802343f,47.536053f,60.082386f,38.275833f,0f,-43.411194f,24.14648f,0f ) ;
  }

  @Test
  public void test548() {
    color.laplace.solve(41.82939f,50.537155f,40.115395f,16.780416f,20.203833f,9.924423f,5.088438f,3.5733356f,-100.0f ) ;
  }

  @Test
  public void test549() {
    color.laplace.solve(41.853317f,50.86053f,41.253876f,16.552734f,20.334932f,14.154967f,4.022685f,-0.46199372f,0f ) ;
  }

  @Test
  public void test550() {
    color.laplace.solve(41.865856f,50.757378f,41.789932f,16.706055f,20.77339f,17.078928f,6.0497026f,7.3921385f,6.3357177f ) ;
  }

  @Test
  public void test551() {
    color.laplace.solve(41.882587f,39.82769f,0f,47.269764f,-100.0f,0f,-5.103548f,-67.68396f,0f ) ;
  }

  @Test
  public void test552() {
    color.laplace.solve(-41.91083f,-40.8904f,0f,-10.210711f,-59.176895f,1.2276322f,60.24489f,43.77395f,0f ) ;
  }

  @Test
  public void test553() {
    color.laplace.solve(41.96935f,53.171112f,55.38479f,14.706287f,15.330314f,2.0482092f,1.5254834f,-8.604353f,99.99101f ) ;
  }

  @Test
  public void test554() {
    color.laplace.solve(41.99853f,50.961212f,41.998295f,17.034092f,19.852049f,17.035595f,6.285783f,8.107467f,6.292035f ) ;
  }

  @Test
  public void test555() {
    color.laplace.solve(42.146896f,54.77405f,68.01025f,13.722324f,8.978889f,-33.89239f,3.757722f,1.136937f,-8.188864f ) ;
  }

  @Test
  public void test556() {
    color.laplace.solve(42.148514f,52.353313f,49.9941f,16.240746f,17.27064f,4.724511f,5.543827f,5.934562f,0.92378265f ) ;
  }

  @Test
  public void test557() {
    color.laplace.solve(42.222668f,57.886147f,78.7823f,11.004532f,10.539605f,20.796995f,-8.744145f,-47.52925f,42.44403f ) ;
  }

  @Test
  public void test558() {
    color.laplace.solve(4.224984f,-72.34013f,0f,-1.4519467f,-19.825453f,-50.513954f,9.792682f,40.622673f,-11.897147f ) ;
  }

  @Test
  public void test559() {
    color.laplace.solve(42.25309f,52.80586f,45.98426f,16.206507f,22.98693f,31.133934f,-0.40568027f,-17.829227f,-93.8944f ) ;
  }

  @Test
  public void test560() {
    color.laplace.solve(42.358505f,48.77861f,34.30414f,20.65541f,18.4518f,-11.562056f,21.811337f,15.93523f,-99.00416f ) ;
  }

  @Test
  public void test561() {
    color.laplace.solve(42.485626f,51.903652f,42.31786f,18.038853f,23.006834f,17.95099f,6.769853f,9.04056f,6.475535f ) ;
  }

  @Test
  public void test562() {
    color.laplace.solve(42.618427f,55.31339f,65.28849f,15.140385f,13.343998f,-20.312788f,4.5964713f,3.2293682f,-5.0229974f ) ;
  }

  @Test
  public void test563() {
    color.laplace.solve(42.6696f,49.485752f,20.127724f,21.192661f,35.14571f,-68.97484f,6.955336f,6.6286273f,-15.586535f ) ;
  }

  @Test
  public void test564() {
    color.laplace.solve(42.75241f,52.482613f,42.69828f,18.527037f,24.47975f,17.932465f,6.8759813f,8.97689f,4.551828f ) ;
  }

  @Test
  public void test565() {
    color.laplace.solve(42.88972f,52.700657f,42.541718f,18.858217f,25.369825f,17.463005f,7.1728168f,9.842238f,6.826311f ) ;
  }

  @Test
  public void test566() {
    color.laplace.solve(42.99313f,52.944897f,43.24796f,19.082384f,25.795465f,20.037453f,7.5496073f,11.115832f,11.1182575f ) ;
  }

  @Test
  public void test567() {
    color.laplace.solve(42.99812f,54.043858f,44.41789f,17.948618f,28.759424f,60.846134f,0.036926337f,-17.800913f,-100.0f ) ;
  }

  @Test
  public void test568() {
    color.laplace.solve(43.060654f,32.87946f,-81.12052f,39.363155f,69.5777f,-27.017012f,15.031092f,20.76121f,-1.5639505f ) ;
  }

  @Test
  public void test569() {
    color.laplace.solve(43.066933f,52.58417f,41.127735f,19.815681f,26.14201f,11.574708f,10.158245f,20.779083f,-20.77156f ) ;
  }

  @Test
  public void test570() {
    color.laplace.solve(43.084602f,53.135494f,43.395893f,19.202917f,26.06148f,20.44808f,7.665585f,11.459424f,12.110633f ) ;
  }

  @Test
  public void test571() {
    color.laplace.solve(43.092613f,59.19598f,55.641056f,13.174473f,38.050247f,63.368244f,-28.444973f,16.46229f,0f ) ;
  }

  @Test
  public void test572() {
    color.laplace.solve(43.093853f,52.749f,39.783558f,19.66467f,27.993282f,28.173426f,7.768566f,11.423559f,9.932387f ) ;
  }

  @Test
  public void test573() {
    color.laplace.solve(43.12073f,56.74819f,99.65626f,15.7347355f,15.290607f,-13.696168f,4.5276012f,2.375669f,56.306957f ) ;
  }

  @Test
  public void test574() {
    color.laplace.solve(43.153656f,54.340134f,51.900875f,18.274492f,22.306002f,53.263363f,7.6383133f,12.278759f,19.170723f ) ;
  }

  @Test
  public void test575() {
    color.laplace.solve(43.16241f,53.88662f,53.436054f,18.763018f,18.944324f,-29.857439f,12.940331f,32.973324f,100.0f ) ;
  }

  @Test
  public void test576() {
    color.laplace.solve(43.192516f,55.804718f,65.98191f,16.965351f,14.044451f,-42.12465f,10.6244335f,25.532383f,77.46065f ) ;
  }

  @Test
  public void test577() {
    color.laplace.solve(43.245464f,29.329979f,23.572355f,43.651875f,-49.497902f,-35.040558f,10.2605715f,-2.6095884f,28.798977f ) ;
  }

  @Test
  public void test578() {
    color.laplace.solve(43.293354f,59.309856f,98.79842f,13.8635645f,-4.8523445f,44.12581f,17.013247f,54.189423f,25.6651f ) ;
  }

  @Test
  public void test579() {
    color.laplace.solve(43.324932f,30.029398f,12.63962f,43.21097f,-36.03653f,-79.70409f,163.08559f,10.630357f,0f ) ;
  }

  @Test
  public void test580() {
    color.laplace.solve(43.32684f,53.62682f,43.978374f,19.683176f,27.202065f,22.235233f,8.243459f,13.301504f,17.760492f ) ;
  }

  @Test
  public void test581() {
    color.laplace.solve(43.328598f,52.02015f,99.78156f,21.294237f,27.65927f,1.860604f,14.189081f,35.462086f,100.0f ) ;
  }

  @Test
  public void test582() {
    color.laplace.solve(-4.344893f,-125.49804f,-113.24293f,8.118469f,-2.342405f,0f,39.16175f,0f,0f ) ;
  }

  @Test
  public void test583() {
    color.laplace.solve(43.47002f,51.11927f,33.564137f,22.760815f,27.442928f,-21.868784f,20.130306f,57.760414f,22.669119f ) ;
  }

  @Test
  public void test584() {
    color.laplace.solve(43.548626f,-13.454174f,-100.0f,87.64868f,-97.365326f,-63.795303f,27.718166f,23.223984f,19.468756f ) ;
  }

  @Test
  public void test585() {
    color.laplace.solve(43.57286f,49.422363f,37.143867f,24.869085f,16.972723f,-0.84688944f,38.93075f,-5.55367f,83.20658f ) ;
  }

  @Test
  public void test586() {
    color.laplace.solve(43.595585f,54.309547f,45.19655f,20.072788f,28.446058f,26.476652f,8.249509f,12.925248f,25.1631f ) ;
  }

  @Test
  public void test587() {
    color.laplace.solve(43.650146f,59.25475f,53.468002f,15.3458395f,39.90085f,4.7568474f,-22.167639f,80.24596f,-74.34146f ) ;
  }

  @Test
  public void test588() {
    color.laplace.solve(43.70265f,51.389057f,32.718174f,23.545757f,29.100433f,-20.492283f,21.37995f,62.04144f,-0.48909345f ) ;
  }

  @Test
  public void test589() {
    color.laplace.solve(43.730877f,54.004173f,45.251106f,20.919338f,27.034712f,2.4876304f,12.91176f,30.727705f,-62.335293f ) ;
  }

  @Test
  public void test590() {
    color.laplace.solve(43.754154f,54.615166f,45.77643f,20.341211f,29.257318f,28.513128f,8.94751f,15.448826f,23.615158f ) ;
  }

  @Test
  public void test591() {
    color.laplace.solve(-43.84575f,-86.46327f,-38.3542f,-19.891802f,-36.57377f,-63.241043f,0.852309f,23.301039f,28.059166f ) ;
  }

  @Test
  public void test592() {
    color.laplace.solve(43.944904f,54.103012f,42.39543f,21.676607f,30.071714f,15.4246f,12.689811f,29.082634f,-44.614403f ) ;
  }

  @Test
  public void test593() {
    color.laplace.solve(43.99971f,55.78286f,31.946981f,20.215977f,47.184757f,-27.994938f,8.558458f,14.017856f,0.3282092f ) ;
  }

  @Test
  public void test594() {
    color.laplace.solve(44.113285f,50.454483f,56.97865f,25.99866f,0.7260031f,77.460106f,5.5653496f,-3.7372608f,-21.240396f ) ;
  }

  @Test
  public void test595() {
    color.laplace.solve(44.132973f,56.46007f,44.549084f,20.071825f,37.158234f,21.736256f,-1.0039078f,58.433468f,0f ) ;
  }

  @Test
  public void test596() {
    color.laplace.solve(44.210934f,54.996056f,16.286312f,21.847681f,59.48698f,39.282784f,0f,0f,0f ) ;
  }

  @Test
  public void test597() {
    color.laplace.solve(44.211693f,55.944553f,49.548042f,20.902212f,30.02505f,26.677538f,9.384268f,16.634857f,27.134642f ) ;
  }

  @Test
  public void test598() {
    color.laplace.solve(44.24823f,53.102913f,62.172455f,23.890001f,5.990974f,7.803409f,45.320805f,0f,0f ) ;
  }

  @Test
  public void test599() {
    color.laplace.solve(44.27486f,53.60039f,31.768246f,23.499048f,38.358467f,54.382004f,11.362867f,21.952421f,38.088352f ) ;
  }

  @Test
  public void test600() {
    color.laplace.solve(44.318768f,55.87555f,47.362522f,21.399517f,31.820913f,33.574535f,9.458391f,16.434048f,24.456886f ) ;
  }

  @Test
  public void test601() {
    color.laplace.solve(44.351826f,57.400513f,53.27504f,20.006788f,31.975183f,55.69964f,3.7001452f,-5.2062073f,-56.500156f ) ;
  }

  @Test
  public void test602() {
    color.laplace.solve(44.369835f,60.528423f,67.16824f,16.950922f,30.575607f,93.21402f,-7.141758f,-48.390926f,93.13756f ) ;
  }

  @Test
  public void test603() {
    color.laplace.solve(44.40952f,53.85042f,35.540565f,23.787651f,35.451607f,-11.688159f,15.2894745f,37.370247f,98.739914f ) ;
  }

  @Test
  public void test604() {
    color.laplace.solve(44.440605f,54.437008f,51.89115f,23.325405f,21.416285f,53.12759f,27.444735f,-45.22487f,0f ) ;
  }

  @Test
  public void test605() {
    color.laplace.solve(44.47472f,51.755455f,24.279121f,26.143417f,38.267982f,13.992606f,21.830969f,61.180458f,100.0f ) ;
  }

  @Test
  public void test606() {
    color.laplace.solve(44.49962f,55.221947f,43.712814f,22.77653f,32.675304f,19.629309f,13.931196f,32.948296f,85.18683f ) ;
  }

  @Test
  public void test607() {
    color.laplace.solve(44.539616f,56.164047f,47.243145f,21.994392f,32.833344f,32.808712f,10.590665f,20.368267f,38.049057f ) ;
  }

  @Test
  public void test608() {
    color.laplace.solve(44.700016f,36.543972f,-44.194138f,41.646694f,44.106625f,-123.63947f,77.15175f,221.69556f,-164.82486f ) ;
  }

  @Test
  public void test609() {
    color.laplace.solve(44.755695f,56.633892f,47.949722f,22.388895f,33.830154f,34.8078f,10.96973f,21.490025f,57.451324f ) ;
  }

  @Test
  public void test610() {
    color.laplace.solve(44.772926f,57.148727f,49.881622f,21.942982f,33.94036f,42.37777f,9.058642f,14.291585f,14.167338f ) ;
  }

  @Test
  public void test611() {
    color.laplace.solve(44.781612f,49.69852f,32.117477f,29.427925f,21.894999f,-21.228613f,51.03509f,0f,0f ) ;
  }

  @Test
  public void test612() {
    color.laplace.solve(44.797596f,60.737793f,42.202923f,18.452589f,55.950653f,92.28744f,-26.937897f,52.3248f,0f ) ;
  }

  @Test
  public void test613() {
    color.laplace.solve(44.8055f,60.88252f,74.68275f,18.339489f,24.04215f,17.244862f,4.510305f,-0.298252f,-29.745453f ) ;
  }

  @Test
  public void test614() {
    color.laplace.solve(44.817074f,57.70832f,52.36363f,21.554848f,33.65287f,51.746193f,7.7494497f,9.437831f,-3.650995f ) ;
  }

  @Test
  public void test615() {
    color.laplace.solve(44.8522f,59.64665f,67.64822f,19.762157f,26.086168f,53.397522f,8.11026f,12.678882f,16.5191f ) ;
  }

  @Test
  public void test616() {
    color.laplace.solve(44.90034f,89.24014f,-4.1247067f,-0.31165412f,24.18868f,6.3366485f,-70.33564f,1.4895811f,5.2826195f ) ;
  }

  @Test
  public void test617() {
    color.laplace.solve(44.9007f,57.190083f,49.323032f,22.412716f,34.5366f,40.102055f,10.213565f,18.441544f,11.794287f ) ;
  }

  @Test
  public void test618() {
    color.laplace.solve(44.91035f,59.891388f,55.895836f,19.750015f,38.75937f,63.69195f,-4.6696577f,11.7041235f,39.245472f ) ;
  }

  @Test
  public void test619() {
    color.laplace.solve(45.1964f,33.45652f,-16.05012f,46.953342f,16.67185f,-31.270002f,126.82871f,17.684666f,-20.78993f ) ;
  }

  @Test
  public void test620() {
    color.laplace.solve(45.31576f,65.73106f,99.99999f,15.531988f,17.60847f,53.641945f,-0.79627955f,-64.47111f,-100.0f ) ;
  }

  @Test
  public void test621() {
    color.laplace.solve(45.333084f,54.057278f,16.690714f,27.275064f,54.20531f,100.0f,9.561862f,10.972383f,-19.877642f ) ;
  }

  @Test
  public void test622() {
    color.laplace.solve(45.439907f,37.422157f,45.64836f,44.337475f,-41.399643f,33.310043f,1.8538383f,0f,0f ) ;
  }

  @Test
  public void test623() {
    color.laplace.solve(4.55346f,-58.583073f,40.47005f,-23.203087f,-86.14406f,23.191551f,-11.221747f,-21.683905f,10.630185f ) ;
  }

  @Test
  public void test624() {
    color.laplace.solve(45.55568f,55.78573f,40.39097f,26.436987f,37.19627f,1.0153446f,22.996f,65.54701f,48.405838f ) ;
  }

  @Test
  public void test625() {
    color.laplace.solve(45.581722f,29.987123f,51.449814f,52.33977f,-77.083046f,75.81214f,44.112617f,55.490456f,0f ) ;
  }

  @Test
  public void test626() {
    color.laplace.solve(-4.5745196f,-88.271416f,-79.42127f,-30.026665f,-19.764343f,-9.212881f,-95.7678f,81.26264f,0f ) ;
  }

  @Test
  public void test627() {
    color.laplace.solve(45.786476f,57.461536f,35.742443f,25.684374f,48.323467f,-14.46583f,8.633765f,8.850682f,-21.555246f ) ;
  }

  @Test
  public void test628() {
    color.laplace.solve(45.794464f,54.516357f,33.56347f,28.661497f,38.707497f,-20.262486f,30.144028f,91.91461f,20.27395f ) ;
  }

  @Test
  public void test629() {
    color.laplace.solve(45.796722f,54.570423f,45.093277f,28.616468f,27.391233f,25.802588f,5.5378084f,-6.465234f,-58.789978f ) ;
  }

  @Test
  public void test630() {
    color.laplace.solve(46.407925f,52.78904f,30.30526f,32.84265f,34.442974f,-31.567999f,50.519714f,83.708206f,-100.0f ) ;
  }

  @Test
  public void test631() {
    color.laplace.solve(46.46423f,61.088795f,56.057888f,24.76812f,41.83307f,63.14275f,10.775184f,18.332613f,20.722197f ) ;
  }

  @Test
  public void test632() {
    color.laplace.solve(46.59319f,66.36964f,92.394264f,20.003117f,26.491089f,17.08257f,6.9281907f,7.7096457f,-2.580696f ) ;
  }

  @Test
  public void test633() {
    color.laplace.solve(46.68784f,66.808914f,94.37173f,19.942442f,26.176083f,10.272019f,6.905849f,7.680953f,100.0f ) ;
  }

  @Test
  public void test634() {
    color.laplace.solve(46.701736f,58.193924f,43.132534f,28.613016f,42.941433f,14.336215f,24.808897f,70.622574f,100.0f ) ;
  }

  @Test
  public void test635() {
    color.laplace.solve(46.812874f,67.8277f,99.99971f,19.423794f,24.498213f,4.6288147f,6.3840847f,6.1125464f,-6.432112f ) ;
  }

  @Test
  public void test636() {
    color.laplace.solve(46.86397f,59.514217f,27.981256f,27.941675f,63.211643f,-47.58919f,1.6910857f,-21.177332f,0f ) ;
  }

  @Test
  public void test637() {
    color.laplace.solve(46.870346f,61.221695f,61.192387f,26.259687f,36.824047f,10.59108f,21.344355f,49.223732f,-55.65212f ) ;
  }

  @Test
  public void test638() {
    color.laplace.solve(-47.03679f,27.888922f,58.87461f,-4.7896576f,22.4096f,39.875248f,5.468558f,26.663889f,78.216774f ) ;
  }

  @Test
  public void test639() {
    color.laplace.solve(47.06976f,61.865383f,57.510628f,26.41365f,42.88114f,46.844357f,15.703706f,36.401173f,86.98566f ) ;
  }

  @Test
  public void test640() {
    color.laplace.solve(-47.090427f,13.512146f,0f,-12.235538f,1.1527435f,10.671971f,-3.0044665f,0.21767195f,2.722411f ) ;
  }

  @Test
  public void test641() {
    color.laplace.solve(47.105682f,62.530834f,58.27746f,25.876041f,44.66708f,70.563126f,11.381517f,19.650026f,22.553288f ) ;
  }

  @Test
  public void test642() {
    color.laplace.solve(47.17514f,63.34165f,61.040752f,25.358957f,45.150723f,80.82139f,9.109967f,11.0809555f,-9.936828f ) ;
  }

  @Test
  public void test643() {
    color.laplace.solve(47.18756f,62.815937f,58.867565f,25.934307f,45.20862f,72.65433f,11.341053f,19.429903f,21.169943f ) ;
  }

  @Test
  public void test644() {
    color.laplace.solve(47.656193f,62.3751f,54.50812f,28.24967f,47.336082f,54.94362f,18.006403f,43.775944f,34.349274f ) ;
  }

  @Test
  public void test645() {
    color.laplace.solve(48.075054f,27.002497f,25.894854f,65.297714f,-65.95992f,62.772938f,-85.124565f,39.339226f,0f ) ;
  }

  @Test
  public void test646() {
    color.laplace.solve(48.118725f,53.94451f,44.038277f,38.530388f,23.62104f,12.959079f,82.38179f,-10.949813f,-15.823005f ) ;
  }

  @Test
  public void test647() {
    color.laplace.solve(48.17077f,30.64283f,-125.602356f,62.04269f,100.0f,-49.806858f,100.0f,53.330265f,0f ) ;
  }

  @Test
  public void test648() {
    color.laplace.solve(48.459976f,64.54069f,58.550755f,29.299213f,51.15202f,69.66233f,17.584858f,41.040222f,95.424f ) ;
  }

  @Test
  public void test649() {
    color.laplace.solve(48.60696f,60.821682f,48.45434f,33.60615f,46.225426f,32.995686f,39.592228f,57.478184f,-21.946753f ) ;
  }

  @Test
  public void test650() {
    color.laplace.solve(48.65822f,56.21119f,38.02096f,38.421677f,38.165577f,100.0f,66.862915f,-41.97055f,-55.309925f ) ;
  }

  @Test
  public void test651() {
    color.laplace.solve(-48.69591f,50.811924f,38.54434f,-11.066861f,9.3340225f,-16.81833f,-4.9055586f,14.409361f,32.13676f ) ;
  }

  @Test
  public void test652() {
    color.laplace.solve(48.715378f,58.100258f,-2.3862956f,36.76125f,86.071945f,-89.49532f,12.2576685f,12.269425f,-49.251915f ) ;
  }

  @Test
  public void test653() {
    color.laplace.solve(48.816616f,38.63125f,-72.015854f,56.635212f,77.724236f,52.3944f,100.0f,-50.24797f,0f ) ;
  }

  @Test
  public void test654() {
    color.laplace.solve(48.881237f,64.11686f,54.274796f,31.560503f,53.31638f,52.982307f,24.044394f,64.64751f,-0.7050275f ) ;
  }

  @Test
  public void test655() {
    color.laplace.solve(49.041874f,67.410545f,67.311646f,28.756952f,53.28866f,98.89312f,12.697274f,22.032146f,22.14265f ) ;
  }

  @Test
  public void test656() {
    color.laplace.solve(49.087597f,57.070427f,14.615624f,37.931126f,65.84867f,166.92725f,28.728395f,70.30921f,184.87137f ) ;
  }

  @Test
  public void test657() {
    color.laplace.solve(49.41834f,51.632195f,57.7593f,46.041164f,-0.6488619f,79.40501f,8.9627495f,-10.190166f,0f ) ;
  }

  @Test
  public void test658() {
    color.laplace.solve(49.48374f,65.09339f,29.171991f,32.84157f,81.71785f,-48.40541f,9.79673f,6.345335f,-66.13325f ) ;
  }

  @Test
  public void test659() {
    color.laplace.solve(49.689697f,87.422424f,100.0f,11.33637f,100.0f,82.200226f,-100.0f,-87.38937f,0f ) ;
  }

  @Test
  public void test660() {
    color.laplace.solve(49.937294f,100.0f,0f,100.0f,-55.0502f,-100.0f,21.585821f,-13.656718f,-21.16249f ) ;
  }

  @Test
  public void test661() {
    color.laplace.solve(49.977142f,53.8564f,18.128975f,46.084007f,47.59037f,-81.29538f,-3.7939544f,-61.359062f,-289.38254f ) ;
  }

  @Test
  public void test662() {
    color.laplace.solve(50.244118f,51.590652f,-23.887955f,49.38582f,80.00645f,99.778015f,67.71839f,0f,0f ) ;
  }

  @Test
  public void test663() {
    color.laplace.solve(5.0958514f,-78.5139f,25.878183f,-1.1026947f,-12.846001f,13.772425f,3.33937f,14.46017f,14.9786415f ) ;
  }

  @Test
  public void test664() {
    color.laplace.solve(51.387505f,60.417885f,47.5275f,45.132137f,42.75653f,29.692112f,86.38451f,35.783985f,37.342976f ) ;
  }

  @Test
  public void test665() {
    color.laplace.solve(51.715508f,74.52984f,99.91031f,32.3322f,46.493534f,-13.034691f,31.11975f,92.1468f,49.38361f ) ;
  }

  @Test
  public void test666() {
    color.laplace.solve(51.81796f,69.561f,43.504307f,37.710835f,82.921715f,4.4562283f,16.103672f,26.70385f,7.7900195f ) ;
  }

  @Test
  public void test667() {
    color.laplace.solve(51.926918f,71.621895f,60.895485f,36.085773f,73.66518f,100.0f,20.564821f,46.173515f,90.46406f ) ;
  }

  @Test
  public void test668() {
    color.laplace.solve(51.998894f,48.957077f,64.3741f,59.038494f,70.23494f,82.31465f,20.797335f,24.150845f,5.5711026f ) ;
  }

  @Test
  public void test669() {
    color.laplace.solve(52.20209f,51.275066f,38.06049f,57.5333f,14.83772f,0.96688724f,22.99793f,34.458424f,99.99803f ) ;
  }

  @Test
  public void test670() {
    color.laplace.solve(52.27799f,70.90654f,37.23424f,38.20541f,94.11394f,-21.969572f,6.429707f,-12.149002f,0f ) ;
  }

  @Test
  public void test671() {
    color.laplace.solve(52.36888f,65.547806f,52.00595f,43.927715f,57.81639f,42.476006f,65.52559f,79.31404f,-89.82863f ) ;
  }

  @Test
  public void test672() {
    color.laplace.solve(52.724407f,67.10971f,38.470097f,43.78792f,77.245964f,-13.212864f,17.011505f,24.25752f,2.7613084f ) ;
  }

  @Test
  public void test673() {
    color.laplace.solve(52.865376f,47.38862f,16.233776f,64.0729f,20.455328f,-82.453545f,25.116476f,36.392952f,100.0f ) ;
  }

  @Test
  public void test674() {
    color.laplace.solve(53.1766f,63.666115f,50.358425f,49.040295f,51.129433f,37.76759f,91.85515f,54.04373f,-6.021074f ) ;
  }

  @Test
  public void test675() {
    color.laplace.solve(-53.19311f,37.34863f,0f,5.47322f,72.37315f,-64.868576f,5.4771843f,16.435518f,-12.108264f ) ;
  }

  @Test
  public void test676() {
    color.laplace.solve(53.4858f,80.170654f,100.0f,33.77256f,67.1968f,66.514656f,14.496666f,24.214102f,15.162941f ) ;
  }

  @Test
  public void test677() {
    color.laplace.solve(5.3909135f,-86.41892f,20.505985f,7.9825745f,-26.541176f,-15.857246f,53.08056f,-11.871108f,-57.393795f ) ;
  }

  @Test
  public void test678() {
    color.laplace.solve(-54.652985f,-22.375542f,0f,-18.987188f,2.2153723f,91.33074f,-23.51114f,-75.05737f,13.020174f ) ;
  }

  @Test
  public void test679() {
    color.laplace.solve(55.062138f,31.428314f,31.866425f,88.82023f,-61.2153f,-3.9626167f,19.34785f,-11.428827f,-3.847861f ) ;
  }

  @Test
  public void test680() {
    color.laplace.solve(-55.311775f,-1.8614126f,76.587814f,-15.459144f,-2.0969903f,11.184681f,-4.4278073f,-2.252086f,-69.80564f ) ;
  }

  @Test
  public void test681() {
    color.laplace.solve(-55.99743f,-74.67385f,0f,-33.3779f,-22.04493f,0f,-15.220408f,-27.503735f,-72.7496f ) ;
  }

  @Test
  public void test682() {
    color.laplace.solve(-56.412987f,-26.499395f,100.0f,-10.742814f,12.446173f,72.30186f,0.99555767f,14.725045f,45.45845f ) ;
  }

  @Test
  public void test683() {
    color.laplace.solve(56.640514f,94.959915f,-75.363625f,31.60214f,11.569815f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test684() {
    color.laplace.solve(56.77668f,71.14009f,60.69382f,55.966633f,67.08985f,9.381457f,100.0f,55.38888f,0f ) ;
  }

  @Test
  public void test685() {
    color.laplace.solve(5.789954f,-70.570305f,8.529094f,-6.2698755f,-26.679964f,-33.8435f,-4.189491f,-10.488088f,-11.082896f ) ;
  }

  @Test
  public void test686() {
    color.laplace.solve(-58.071945f,73.49853f,28.806982f,-6.9685893f,29.494856f,41.669968f,0.70273244f,9.779519f,8.920487f ) ;
  }

  @Test
  public void test687() {
    color.laplace.solve(-59.608147f,-13.79796f,0f,-12.235151f,12.84303f,10.32782f,-2.175488f,3.533199f,3.4652545f ) ;
  }

  @Test
  public void test688() {
    color.laplace.solve(-6.021062f,8.93941f,0f,9.244621f,43.342056f,-19.788248f,-0.34251264f,-76.08326f,0f ) ;
  }

  @Test
  public void test689() {
    color.laplace.solve(6.0480084f,-56.297844f,-45.22121f,-19.510124f,-3.207586f,83.829956f,-80.88091f,-20.852333f,0f ) ;
  }

  @Test
  public void test690() {
    color.laplace.solve(-61.836033f,67.654434f,0f,-18.892378f,-19.28729f,-22.572681f,5.5538125f,41.107628f,99.83697f ) ;
  }

  @Test
  public void test691() {
    color.laplace.solve(62.773537f,92.37342f,72.378876f,58.560715f,134.38135f,96.986275f,37.312813f,90.690544f,-2.2848716f ) ;
  }

  @Test
  public void test692() {
    color.laplace.solve(-62.826385f,4.847586f,1.2089071f,-18.04897f,-4.1919637f,-0.97995377f,-5.163808f,-2.5865176f,-0.89161783f ) ;
  }

  @Test
  public void test693() {
    color.laplace.solve(63.8224f,56.08673f,51.458485f,99.202866f,9.066037f,49.747204f,28.108112f,13.229587f,15.744198f ) ;
  }

  @Test
  public void test694() {
    color.laplace.solve(-64.79368f,63.87291f,0f,-5.423738f,34.624664f,14.930609f,8.836331f,42.35105f,125.29718f ) ;
  }

  @Test
  public void test695() {
    color.laplace.solve(-65.304596f,78.66757f,-99.999695f,-6.4325495f,37.49441f,62.990105f,2.079991f,14.752514f,19.435654f ) ;
  }

  @Test
  public void test696() {
    color.laplace.solve(-65.54362f,-18.133587f,-55.088367f,-22.22697f,-16.23419f,-18.282887f,-7.1300707f,-6.293313f,-1.8089918f ) ;
  }

  @Test
  public void test697() {
    color.laplace.solve(-65.93509f,20.975075f,24.48176f,6.2094812f,6.3587637f,13.599077f,84.41425f,-15.348579f,23.555784f ) ;
  }

  @Test
  public void test698() {
    color.laplace.solve(6.805306f,-53.96342f,100.0f,-18.815355f,-1.7162486f,-100.0f,-80.35048f,-35.438248f,0f ) ;
  }

  @Test
  public void test699() {
    color.laplace.solve(-68.77881f,-7.8643255f,0f,-65.50935f,-73.24153f,0f,-4.5075884f,3.657184f,0f ) ;
  }

  @Test
  public void test700() {
    color.laplace.solve(69.11232f,113.79111f,166.86398f,62.657f,205.53827f,0f,24.012806f,33.39422f,106.72432f ) ;
  }

  @Test
  public void test701() {
    color.laplace.solve(-69.65772f,-45.132263f,-72.77393f,-35.57775f,-53.1615f,-89.54661f,-19.49178f,-42.38937f,-100.0f ) ;
  }

  @Test
  public void test702() {
    color.laplace.solve(-7.0123487f,43.70891f,-64.99307f,-1.8902528f,5.163016f,-0.21013388f,-5.7116785f,-20.95646f,-83.27718f ) ;
  }

  @Test
  public void test703() {
    color.laplace.solve(7.0746675f,-71.76895f,100.0f,0.06761945f,-6.9616847f,43.29223f,0.15749535f,0.5623619f,9.0536375f ) ;
  }

  @Test
  public void test704() {
    color.laplace.solve(-73.713165f,-29.007145f,-233.21356f,-29.341595f,-32.28296f,-54.916973f,-11.332686f,-15.660856f,-17.686918f ) ;
  }

  @Test
  public void test705() {
    color.laplace.solve(-73.91725f,-71.940506f,0f,-48.054268f,42.42784f,0f,-73.72541f,55.11567f,0f ) ;
  }

  @Test
  public void test706() {
    color.laplace.solve(-74.25644f,15.358496f,63.753628f,-23.535563f,-18.509342f,-68.12914f,-1.376464f,2.268844f,-68.46039f ) ;
  }

  @Test
  public void test707() {
    color.laplace.solve(7.5499477f,-73.84075f,82.15504f,4.0405455f,0.7883018f,45.736275f,7.81965f,27.151987f,100.0f ) ;
  }

  @Test
  public void test708() {
    color.laplace.solve(-7.70716f,-90.28726f,25.832132f,-40.428886f,-24.734509f,15.137989f,-129.44283f,13.708859f,57.82988f ) ;
  }

  @Test
  public void test709() {
    color.laplace.solve(-79.35771f,32.12164f,25.766024f,-14.9168625f,18.18654f,34.609646f,1.5037199f,20.931742f,94.48601f ) ;
  }

  @Test
  public void test710() {
    color.laplace.solve(-81.091064f,-100.0f,0f,-10.286696f,40.579372f,-43.582314f,-0.6350942f,7.74632f,-8.958999f ) ;
  }

  @Test
  public void test711() {
    color.laplace.solve(8.25142f,-71.04073f,-46.22517f,4.046418f,-6.9241076f,-16.089134f,14.85836f,55.387024f,-11.207261f ) ;
  }

  @Test
  public void test712() {
    color.laplace.solve(-82.58723f,-20.719412f,0f,38.4237f,-90.69459f,0f,60.077103f,-56.53063f,0f ) ;
  }

  @Test
  public void test713() {
    color.laplace.solve(-82.78716f,-100.0f,-100.0f,-23.081053f,-4.7942176f,99.79443f,-4.7428255f,4.1097507f,25.976046f ) ;
  }

  @Test
  public void test714() {
    color.laplace.solve(8.319114f,54.801495f,66.27478f,-7.8525963f,-13.037116f,-0.18043041f,-26.692383f,-98.91693f,45.7756f ) ;
  }

  @Test
  public void test715() {
    color.laplace.solve(-83.509766f,99.97862f,-21.581749f,-13.8996f,29.060421f,20.859293f,-1.1490575f,9.3033695f,75.958496f ) ;
  }

  @Test
  public void test716() {
    color.laplace.solve(8.594437f,11.984223f,13.295737f,-77.606476f,-73.953285f,100.0f,-26.677183f,-29.10226f,-15.778579f ) ;
  }

  @Test
  public void test717() {
    color.laplace.solve(8.606186f,-47.22833f,42.57789f,8.063176f,9.917039f,31.978567f,13.72948f,46.85474f,0.17765512f ) ;
  }

  @Test
  public void test718() {
    color.laplace.solve(-86.571365f,2.2020173f,-54.16797f,-4.4367213f,10.149539f,4.017182f,58.67494f,38.815678f,-31.701662f ) ;
  }

  @Test
  public void test719() {
    color.laplace.solve(-87.548096f,-79.88375f,48.51554f,-29.570707f,-23.521563f,14.650194f,-7.2131734f,0.71801484f,33.606796f ) ;
  }

  @Test
  public void test720() {
    color.laplace.solve(8.758395f,-74.66579f,-100.0f,9.699369f,18.781496f,0f,22.702364f,-78.12795f,0f ) ;
  }

  @Test
  public void test721() {
    color.laplace.solve(8.780611f,-66.80764f,-35.016125f,1.9300815f,-9.94716f,-8.5285015f,8.886875f,33.617416f,10.8492775f ) ;
  }

  @Test
  public void test722() {
    color.laplace.solve(-8.955049f,24.960287f,-39.25589f,3.0862305f,18.480528f,37.683502f,2.8194342f,8.192096f,11.468421f ) ;
  }

  @Test
  public void test723() {
    color.laplace.solve(-8.974315f,39.170033f,99.99956f,3.3497572f,19.933071f,30.801157f,2.4402733f,6.411336f,3.272f ) ;
  }

  @Test
  public void test724() {
    color.laplace.solve(-89.99355f,-27.801712f,0f,-86.379486f,-85.61904f,-68.790855f,-22.774633f,-4.719053f,89.51746f ) ;
  }

  @Test
  public void test725() {
    color.laplace.solve(92.22249f,96.80571f,0f,72.17339f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test726() {
    color.laplace.solve(9.228621f,-63.742004f,71.237335f,0.65648764f,-1.7728462f,75.96929f,-4.829657f,-19.975117f,-73.29787f ) ;
  }

  @Test
  public void test727() {
    color.laplace.solve(-92.822876f,18.595886f,-17.96843f,-32.84075f,-18.598112f,-13.220272f,-19.942015f,-46.92731f,-16.567f ) ;
  }

  @Test
  public void test728() {
    color.laplace.solve(-94.97281f,9.087319f,0f,-33.116993f,-27.624264f,99.80558f,-9.870902f,-6.3666143f,12.028708f ) ;
  }

  @Test
  public void test729() {
    color.laplace.solve(-95.43331f,29.599508f,0f,-75.380455f,0f,0f,0f,0f,0f ) ;
  }
}
