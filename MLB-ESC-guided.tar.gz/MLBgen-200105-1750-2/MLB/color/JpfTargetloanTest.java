import org.junit.Test;

public class JpfTargetloanTest {

  @Test
  public void test0() {
    color.loan.solve(-42.39709f ) ;
  }

  @Test
  public void test1() {
    color.loan.solve(64.637955f ) ;
  }

  @Test
  public void test2() {
    color.loan.solve(87.24334f ) ;
  }
}
