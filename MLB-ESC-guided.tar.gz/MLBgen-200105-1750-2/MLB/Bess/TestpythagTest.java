import org.junit.Test;

public class TestpythagTest {

  @Test
  public void test0() {
    dawson.pythag(0.0022189058759088565,0.002177251655860071 ) ;
  }

  @Test
  public void test1() {
    dawson.pythag(-0.00855483649542238,0.008870957247773547 ) ;
  }

  @Test
  public void test2() {
    dawson.pythag(0.010925077932673399,-0.011194637780945505 ) ;
  }

  @Test
  public void test3() {
    dawson.pythag(-0.03335010031687951,0.03335010060484333 ) ;
  }

  @Test
  public void test4() {
    dawson.pythag(-0.08198116231329952,-0.23045288408614928 ) ;
  }

  @Test
  public void test5() {
    dawson.pythag(0.13020987436156334,0.13022903974527536 ) ;
  }

  @Test
  public void test6() {
    dawson.pythag(100.0,0.0 ) ;
  }

  @Test
  public void test7() {
    dawson.pythag(-100.0,-100.0 ) ;
  }

  @Test
  public void test8() {
    dawson.pythag(-1.03954097656449E-111,8.316327812515919E-112 ) ;
  }

  @Test
  public void test9() {
    dawson.pythag(-1.0795210693868056E-78,1.1548969437650775E-51 ) ;
  }

  @Test
  public void test10() {
    dawson.pythag(1.1830521861667747E-271,1.3134517764154804E-287 ) ;
  }

  @Test
  public void test11() {
    dawson.pythag(1.2015861389414441E-286,-2.3331590462580472E-302 ) ;
  }

  @Test
  public void test12() {
    dawson.pythag(-1.232595164407831E-32,-1.0904948420930742E-16 ) ;
  }

  @Test
  public void test13() {
    dawson.pythag(-12.70512747236701,81.5902806233955 ) ;
  }

  @Test
  public void test14() {
    dawson.pythag(1.2979284428305747E-17,1.297928442831043E-17 ) ;
  }

  @Test
  public void test15() {
    dawson.pythag(-1.396605566520059E-17,-1.3966052909577637E-17 ) ;
  }

  @Test
  public void test16() {
    dawson.pythag(1.4236008573962155E-33,1.3541402024885945E-33 ) ;
  }

  @Test
  public void test17() {
    dawson.pythag(1.4E-322,1.63E-322 ) ;
  }

  @Test
  public void test18() {
    dawson.pythag(1.5192908393215678E-64,1.5196617599366365E-64 ) ;
  }

  @Test
  public void test19() {
    dawson.pythag(-1.5793650827938261E-176,-1.5793650827938261E-176 ) ;
  }

  @Test
  public void test20() {
    dawson.pythag(-15.912051110422354,79.25293255788452 ) ;
  }

  @Test
  public void test21() {
    dawson.pythag(-16.283455412116354,0 ) ;
  }

  @Test
  public void test22() {
    dawson.pythag(-1.9721522630525295E-31,3.944304526105059E-31 ) ;
  }

  @Test
  public void test23() {
    dawson.pythag(2.148670725222346E-31,-3.944304526105059E-31 ) ;
  }

  @Test
  public void test24() {
    dawson.pythag(23.01931752615505,38.455472737594874 ) ;
  }

  @Test
  public void test25() {
    dawson.pythag(-2.53E-321,0.0 ) ;
  }

  @Test
  public void test26() {
    dawson.pythag(-2.6015592699123717E-259,2.8883110013837273E-275 ) ;
  }

  @Test
  public void test27() {
    dawson.pythag(2.6571967751066694,0 ) ;
  }

  @Test
  public void test28() {
    dawson.pythag(2.710505431213761E-20,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test29() {
    dawson.pythag(27.34880150098762,-69.39025146825097 ) ;
  }

  @Test
  public void test30() {
    dawson.pythag(-2.7755575615628914E-17,2.8189256484623115E-17 ) ;
  }

  @Test
  public void test31() {
    dawson.pythag(-2.804716212884099E-34,-2.811000330805694E-34 ) ;
  }

  @Test
  public void test32() {
    dawson.pythag(29.023359124944093,-29.023359124944093 ) ;
  }

  @Test
  public void test33() {
    dawson.pythag(29.3926726398534,-29.3926726398534 ) ;
  }

  @Test
  public void test34() {
    dawson.pythag(-3.009265538105056E-36,-3.162995024814823E-36 ) ;
  }

  @Test
  public void test35() {
    dawson.pythag(-3.071469493483562,-58.441197651610736 ) ;
  }

  @Test
  public void test36() {
    dawson.pythag(-3.0814879110195774E-33,3.4666738998970245E-33 ) ;
  }

  @Test
  public void test37() {
    dawson.pythag(3.130476935609555E-7,-3.130476935605103E-7 ) ;
  }

  @Test
  public void test38() {
    dawson.pythag(-33.28423622601278,-33.28423622601278 ) ;
  }

  @Test
  public void test39() {
    dawson.pythag(-35.382598649321224,-61.80062508609014 ) ;
  }

  @Test
  public void test40() {
    dawson.pythag(36.7382328421312,36.7382328421312 ) ;
  }

  @Test
  public void test41() {
    dawson.pythag(37.708027179135485,-37.708027179135485 ) ;
  }

  @Test
  public void test42() {
    dawson.pythag(-3.8316151715484804E-31,-2.913582577262668E-31 ) ;
  }

  @Test
  public void test43() {
    dawson.pythag(-38.85498211475873,0.0 ) ;
  }

  @Test
  public void test44() {
    dawson.pythag(-3.9484127069845653E-177,3.9484127069845653E-177 ) ;
  }

  @Test
  public void test45() {
    dawson.pythag(3.975085926685558E-49,3.9761181698707615E-49 ) ;
  }

  @Test
  public void test46() {
    dawson.pythag(40.801513638437655,-38.97660702626413 ) ;
  }

  @Test
  public void test47() {
    dawson.pythag(-4.0E-323,0.0 ) ;
  }

  @Test
  public void test48() {
    dawson.pythag(4.127969548720031,75.25946205312724 ) ;
  }

  @Test
  public void test49() {
    dawson.pythag(4.147419057575107E-36,-4.1474190575751077E-36 ) ;
  }

  @Test
  public void test50() {
    dawson.pythag(4.1581639062579597E-112,-1.8395063612549406E-96 ) ;
  }

  @Test
  public void test51() {
    dawson.pythag(-4.290974510121131,23.82603563307812 ) ;
  }

  @Test
  public void test52() {
    dawson.pythag(43.87641018217411,37.05149549661445 ) ;
  }

  @Test
  public void test53() {
    dawson.pythag(-44.01166419764506,-10.198760822241738 ) ;
  }

  @Test
  public void test54() {
    dawson.pythag(-4.445517498970155E-162,4.445517498970155E-162 ) ;
  }

  @Test
  public void test55() {
    dawson.pythag(-4.7068747365290705E-184,0.0 ) ;
  }

  @Test
  public void test56() {
    dawson.pythag(-4.892882010227016E-36,4.892932821616471E-36 ) ;
  }

  @Test
  public void test57() {
    dawson.pythag(53.43459325918528,0.0 ) ;
  }

  @Test
  public void test58() {
    dawson.pythag(5.513587979681816,5.513587979681816 ) ;
  }

  @Test
  public void test59() {
    dawson.pythag(5.551115123125783E-17,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test60() {
    dawson.pythag(-5.551115123125783E-17,5.551115123125783E-17 ) ;
  }

  @Test
  public void test61() {
    dawson.pythag(-55.876660522767935,55.876660522767935 ) ;
  }

  @Test
  public void test62() {
    dawson.pythag(5.7947269097469225E-49,5.7947269097884265E-49 ) ;
  }

  @Test
  public void test63() {
    dawson.pythag(-5.8327912261218006E-133,-7.820637090558988E-149 ) ;
  }

  @Test
  public void test64() {
    dawson.pythag(60.46503846516566,-66.2980498243609 ) ;
  }

  @Test
  public void test65() {
    dawson.pythag(-6.157883248595745E-257,-2.9576304654169368E-272 ) ;
  }

  @Test
  public void test66() {
    dawson.pythag(61.97987207103861,0 ) ;
  }

  @Test
  public void test67() {
    dawson.pythag(6.4114920888707445,-46.81094363970351 ) ;
  }

  @Test
  public void test68() {
    dawson.pythag(64.4730547912022,64.4730547912022 ) ;
  }

  @Test
  public void test69() {
    dawson.pythag(-64.66384832941772,21.234391623864028 ) ;
  }

  @Test
  public void test70() {
    dawson.pythag(6.776263578034403E-21,2.211906297239451E-5 ) ;
  }

  @Test
  public void test71() {
    dawson.pythag(-68.4086326800724,0.0 ) ;
  }

  @Test
  public void test72() {
    dawson.pythag(-69.387108305735,-34.538267519915536 ) ;
  }

  @Test
  public void test73() {
    dawson.pythag(6.938893903907228E-18,-1.0587911840678754E-22 ) ;
  }

  @Test
  public void test74() {
    dawson.pythag(-6.938893903907228E-18,2.0816681711721685E-17 ) ;
  }

  @Test
  public void test75() {
    dawson.pythag(-6.938893903907228E-18,6.938893903907228E-18 ) ;
  }

  @Test
  public void test76() {
    dawson.pythag(70.39205950312456,56.61195431868026 ) ;
  }

  @Test
  public void test77() {
    dawson.pythag(-70.60977646665447,70.60977646665447 ) ;
  }

  @Test
  public void test78() {
    dawson.pythag(-72.85312397871301,61.29925186348902 ) ;
  }

  @Test
  public void test79() {
    dawson.pythag(73.05202810877293,-72.32009216737328 ) ;
  }

  @Test
  public void test80() {
    dawson.pythag(7.4E-323,0.0 ) ;
  }

  @Test
  public void test81() {
    dawson.pythag(7.617612976769655E-36,7.738465865547045E-36 ) ;
  }

  @Test
  public void test82() {
    dawson.pythag(-76.40076547791296,-91.85747722190385 ) ;
  }

  @Test
  public void test83() {
    dawson.pythag(-7.703719777549561E-34,-7.703719777549563E-34 ) ;
  }

  @Test
  public void test84() {
    dawson.pythag(-78.17661496278726,0.0 ) ;
  }

  @Test
  public void test85() {
    dawson.pythag(-78.24663543280849,-96.30651745084302 ) ;
  }

  @Test
  public void test86() {
    dawson.pythag(7.896825413969131E-177,-7.896825413969131E-177 ) ;
  }

  @Test
  public void test87() {
    dawson.pythag(-7.966232147228992E-68,7.966974000872648E-68 ) ;
  }

  @Test
  public void test88() {
    dawson.pythag(81.05148507751178,-77.29374082128884 ) ;
  }

  @Test
  public void test89() {
    dawson.pythag(-8.2090736025967525E-289,5.957492604388426E-275 ) ;
  }

  @Test
  public void test90() {
    dawson.pythag(8.2090736025967525E-289,9.113902524445497E-305 ) ;
  }

  @Test
  public void test91() {
    dawson.pythag(-83.9585844629074,54.961632975436515 ) ;
  }

  @Test
  public void test92() {
    dawson.pythag(84.41621637920008,0.0 ) ;
  }

  @Test
  public void test93() {
    dawson.pythag(8.736455821191134E-4,-7.965111087030554E-4 ) ;
  }

  @Test
  public void test94() {
    dawson.pythag(8.767237396033612E-193,9.733588819431218E-209 ) ;
  }

  @Test
  public void test95() {
    dawson.pythag(8.89103499794031E-162,-8.89103499794031E-162 ) ;
  }

  @Test
  public void test96() {
    dawson.pythag(-89.88362280939202,-89.88362280939202 ) ;
  }

  @Test
  public void test97() {
    dawson.pythag(-9.232978617785736E-128,2.4276995863276106E-112 ) ;
  }

  @Test
  public void test98() {
    dawson.pythag(9.367723249499515E-31,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test99() {
    dawson.pythag(9.495567745759799E-66,-1.0682513713979774E-65 ) ;
  }

  @Test
  public void test100() {
    dawson.pythag(9.4E-323,0.0 ) ;
  }

  @Test
  public void test101() {
    dawson.pythag(-9.56998659123488,9.56998659123488 ) ;
  }

  @Test
  public void test102() {
    dawson.pythag(-9.687501971260539E-17,9.68750149292173E-17 ) ;
  }

  @Test
  public void test103() {
    dawson.pythag(97.43018981484968,40.61710061903224 ) ;
  }

  @Test
  public void test104() {
    dawson.pythag(-9.860761315262648E-32,-1.0722797820522201E-16 ) ;
  }

  @Test
  public void test105() {
    dawson.pythag(9.860761315262648E-32,1.0739231565290062E-17 ) ;
  }

  @Test
  public void test106() {
    dawson.pythag(9.871031767461413E-178,1.0959046745042015E-193 ) ;
  }

  @Test
  public void test107() {
    dawson.pythag(9.890020602492115,64.09352300023684 ) ;
  }
}
