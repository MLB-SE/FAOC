import org.junit.Test;

public class TestbessyTest {

  @Test
  public void test0() {
    bess.bessy(-178,-81.80056528744586 ) ;
  }

  @Test
  public void test1() {
    bess.bessy(-191,8.0 ) ;
  }

  @Test
  public void test2() {
    bess.bessy(324,94.96993167093484 ) ;
  }

  @Test
  public void test3() {
    bess.bessy(515,-87.33816631465706 ) ;
  }

  @Test
  public void test4() {
    bess.bessy(-521,16.221901675547002 ) ;
  }

  @Test
  public void test5() {
    bess.bessy(-552,0 ) ;
  }

  @Test
  public void test6() {
    bess.bessy(-585,91.19460340479125 ) ;
  }

  @Test
  public void test7() {
    bess.bessy(-663,0.0 ) ;
  }

  @Test
  public void test8() {
    bess.bessy(695,8.0 ) ;
  }

  @Test
  public void test9() {
    bess.bessy(749,0 ) ;
  }

  @Test
  public void test10() {
    bess.bessy(798,91.1518150943304 ) ;
  }

  @Test
  public void test11() {
    bess.bessy(918,0.0 ) ;
  }
}
