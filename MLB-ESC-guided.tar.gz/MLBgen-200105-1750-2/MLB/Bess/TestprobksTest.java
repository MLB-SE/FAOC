import org.junit.Test;

public class TestprobksTest {

  @Test
  public void test0() {
    dawson.probks(12.02925994220277 ) ;
  }

  @Test
  public void test1() {
    dawson.probks(12.59213037106575 ) ;
  }

  @Test
  public void test2() {
    dawson.probks(13.470324047826267 ) ;
  }

  @Test
  public void test3() {
    dawson.probks(-13.9188484454871 ) ;
  }

  @Test
  public void test4() {
    dawson.probks(-14.664452919281487 ) ;
  }

  @Test
  public void test5() {
    dawson.probks(17.689234400497227 ) ;
  }

  @Test
  public void test6() {
    dawson.probks(-19.288542948887255 ) ;
  }

  @Test
  public void test7() {
    dawson.probks(-19.293202044077876 ) ;
  }

  @Test
  public void test8() {
    dawson.probks(19.294471464174823 ) ;
  }

  @Test
  public void test9() {
    dawson.probks(-19.29476716260395 ) ;
  }

  @Test
  public void test10() {
    dawson.probks(29.580512478130856 ) ;
  }

  @Test
  public void test11() {
    dawson.probks(4.690787357457069 ) ;
  }

  @Test
  public void test12() {
    dawson.probks(50.33474206644331 ) ;
  }

  @Test
  public void test13() {
    dawson.probks(-77.05911155240477 ) ;
  }

  @Test
  public void test14() {
    dawson.probks(8.510974479089526 ) ;
  }
}
