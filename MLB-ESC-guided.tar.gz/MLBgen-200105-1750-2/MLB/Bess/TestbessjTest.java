import org.junit.Test;

public class TestbessjTest {

  @Test
  public void test0() {
    bess.bessj(0,1.0E-322 ) ;
  }

  @Test
  public void test1() {
    bess.bessj(0,-6.480399681681252E-162 ) ;
  }

  @Test
  public void test2() {
    bess.bessj(1,0.8910896212688252 ) ;
  }

  @Test
  public void test3() {
    bess.bessj(1,-1.0 ) ;
  }

  @Test
  public void test4() {
    bess.bessj(1,1.0 ) ;
  }

  @Test
  public void test5() {
    bess.bessj(-114,8.881784197001252E-16 ) ;
  }

  @Test
  public void test6() {
    bess.bessj(12,0.0 ) ;
  }

  @Test
  public void test7() {
    bess.bessj(145,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test8() {
    bess.bessj(-151,2.4307677947074054E-150 ) ;
  }

  @Test
  public void test9() {
    bess.bessj(-1533,-1.6940658945086007E-21 ) ;
  }

  @Test
  public void test10() {
    bess.bessj(1547,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test11() {
    bess.bessj(-1565,-6.500794657392833E-162 ) ;
  }

  @Test
  public void test12() {
    bess.bessj(159,1.0107936529880487E-174 ) ;
  }

  @Test
  public void test13() {
    bess.bessj(-1652,7.112827998352248E-161 ) ;
  }

  @Test
  public void test14() {
    bess.bessj(-165,-95.75458677236269 ) ;
  }

  @Test
  public void test15() {
    bess.bessj(17,-17.0 ) ;
  }

  @Test
  public void test16() {
    bess.bessj(1,-7.888609052210118E-31 ) ;
  }

  @Test
  public void test17() {
    bess.bessj(-232,0.0 ) ;
  }

  @Test
  public void test18() {
    bess.bessj(285,0.0 ) ;
  }

  @Test
  public void test19() {
    bess.bessj(-287,0.0 ) ;
  }

  @Test
  public void test20() {
    bess.bessj(-298,58.262768632176886 ) ;
  }

  @Test
  public void test21() {
    bess.bessj(337,72.66764609601589 ) ;
  }

  @Test
  public void test22() {
    bess.bessj(-348,-8.89103499794031E-162 ) ;
  }

  @Test
  public void test23() {
    bess.bessj(35,-26.27145615610864 ) ;
  }

  @Test
  public void test24() {
    bess.bessj(-358,0.0 ) ;
  }

  @Test
  public void test25() {
    bess.bessj(-365,-9.501739162292495 ) ;
  }

  @Test
  public void test26() {
    bess.bessj(-384,-3.0E-323 ) ;
  }

  @Test
  public void test27() {
    bess.bessj(39,-98.05530298335809 ) ;
  }

  @Test
  public void test28() {
    bess.bessj(-407,2.220446049250313E-16 ) ;
  }

  @Test
  public void test29() {
    bess.bessj(454,1.696432158322338 ) ;
  }

  @Test
  public void test30() {
    bess.bessj(456,-1.778206999588062E-161 ) ;
  }

  @Test
  public void test31() {
    bess.bessj(45,76.31125450318422 ) ;
  }

  @Test
  public void test32() {
    bess.bessj(490,0.0 ) ;
  }

  @Test
  public void test33() {
    bess.bessj(565,6.776263578034403E-21 ) ;
  }

  @Test
  public void test34() {
    bess.bessj(594,-2.5269841324701218E-175 ) ;
  }

  @Test
  public void test35() {
    bess.bessj(-599,0 ) ;
  }

  @Test
  public void test36() {
    bess.bessj(647,-68.6398081247227 ) ;
  }

  @Test
  public void test37() {
    bess.bessj(-649,38.89671716121981 ) ;
  }

  @Test
  public void test38() {
    bess.bessj(661,1.972429176212968E-160 ) ;
  }

  @Test
  public void test39() {
    bess.bessj(-697,45.985481364519444 ) ;
  }

  @Test
  public void test40() {
    bess.bessj(739,-6.480399694529157E-162 ) ;
  }

  @Test
  public void test41() {
    bess.bessj(76,76.0 ) ;
  }

  @Test
  public void test42() {
    bess.bessj(-772,-6.080015002328793 ) ;
  }

  @Test
  public void test43() {
    bess.bessj(794,70.77434868859049 ) ;
  }

  @Test
  public void test44() {
    bess.bessj(824,2.5269841324701218E-175 ) ;
  }

  @Test
  public void test45() {
    bess.bessj(-828,7.112827998352248E-161 ) ;
  }

  @Test
  public void test46() {
    bess.bessj(834,6.776263578034403E-21 ) ;
  }

  @Test
  public void test47() {
    bess.bessj(90,0 ) ;
  }

  @Test
  public void test48() {
    bess.bessj(-928,-1.2634920662350609E-175 ) ;
  }

  @Test
  public void test49() {
    bess.bessj(966,-94.51641653483797 ) ;
  }
}
