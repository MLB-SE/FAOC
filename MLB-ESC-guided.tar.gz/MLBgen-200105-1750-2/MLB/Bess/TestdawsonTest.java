import org.junit.Test;

public class TestdawsonTest {

  @Test
  public void test0() {
    dawson.dawson(0.019225728442736567 ) ;
  }

  @Test
  public void test1() {
    dawson.dawson(-0.19999999999999996 ) ;
  }

  @Test
  public void test2() {
    dawson.dawson(-0.20000000000000004 ) ;
  }

  @Test
  public void test3() {
    dawson.dawson(-0.20000000000000018 ) ;
  }

  @Test
  public void test4() {
    dawson.dawson(0.20000000000000018 ) ;
  }

  @Test
  public void test5() {
    dawson.dawson(0.20000000000000107 ) ;
  }

  @Test
  public void test6() {
    dawson.dawson(-0.33176920196605764 ) ;
  }

  @Test
  public void test7() {
    dawson.dawson(-0.39999999999999997 ) ;
  }

  @Test
  public void test8() {
    dawson.dawson(0.39999999999999997 ) ;
  }

  @Test
  public void test9() {
    dawson.dawson(0.4 ) ;
  }

  @Test
  public void test10() {
    dawson.dawson(-0.40014937820509666 ) ;
  }

  @Test
  public void test11() {
    dawson.dawson(0.43999150047267754 ) ;
  }

  @Test
  public void test12() {
    dawson.dawson(-0.555314135402974 ) ;
  }

  @Test
  public void test13() {
    dawson.dawson(0.5680856096468503 ) ;
  }

  @Test
  public void test14() {
    dawson.dawson(-0.5746368333973066 ) ;
  }

  @Test
  public void test15() {
    dawson.dawson(-0.6132747067506576 ) ;
  }

  @Test
  public void test16() {
    dawson.dawson(0.6293751568719371 ) ;
  }

  @Test
  public void test17() {
    dawson.dawson(-0.6648558572106893 ) ;
  }

  @Test
  public void test18() {
    dawson.dawson(0.7306766283918336 ) ;
  }

  @Test
  public void test19() {
    dawson.dawson(0.7757783743842737 ) ;
  }

  @Test
  public void test20() {
    dawson.dawson(0.7999999999999996 ) ;
  }

  @Test
  public void test21() {
    dawson.dawson(-0.7999999999999997 ) ;
  }

  @Test
  public void test22() {
    dawson.dawson(-0.7999999999999999 ) ;
  }

  @Test
  public void test23() {
    dawson.dawson(0.9857403669691231 ) ;
  }

  @Test
  public void test24() {
    dawson.dawson(-1.1830641534459612 ) ;
  }

  @Test
  public void test25() {
    dawson.dawson(-12.193129819615848 ) ;
  }

  @Test
  public void test26() {
    dawson.dawson(1.3944821791124156 ) ;
  }

  @Test
  public void test27() {
    dawson.dawson(14.114047714928518 ) ;
  }

  @Test
  public void test28() {
    dawson.dawson(1.5999999999999999 ) ;
  }

  @Test
  public void test29() {
    dawson.dawson(16.417755033330067 ) ;
  }

  @Test
  public void test30() {
    dawson.dawson(-1.7596497272185425 ) ;
  }

  @Test
  public void test31() {
    dawson.dawson(1.8679868213598927 ) ;
  }

  @Test
  public void test32() {
    dawson.dawson(-19.72943604438433 ) ;
  }

  @Test
  public void test33() {
    dawson.dawson(-20.472329534725247 ) ;
  }

  @Test
  public void test34() {
    dawson.dawson(2.563673504857471 ) ;
  }

  @Test
  public void test35() {
    dawson.dawson(-2.742431396231654 ) ;
  }

  @Test
  public void test36() {
    dawson.dawson(28.173590950400467 ) ;
  }

  @Test
  public void test37() {
    dawson.dawson(-28.473805627210197 ) ;
  }

  @Test
  public void test38() {
    dawson.dawson(-3.0229559229497625 ) ;
  }

  @Test
  public void test39() {
    dawson.dawson(-32.10436154002308 ) ;
  }

  @Test
  public void test40() {
    dawson.dawson(3.228375935230035 ) ;
  }

  @Test
  public void test41() {
    dawson.dawson(-34.93759174305964 ) ;
  }

  @Test
  public void test42() {
    dawson.dawson(-35.00878927762105 ) ;
  }

  @Test
  public void test43() {
    dawson.dawson(-3.598767169889688 ) ;
  }

  @Test
  public void test44() {
    dawson.dawson(-36.611575144595946 ) ;
  }

  @Test
  public void test45() {
    dawson.dawson(37.43085829556213 ) ;
  }

  @Test
  public void test46() {
    dawson.dawson(-3.7927801419366176 ) ;
  }

  @Test
  public void test47() {
    dawson.dawson(38.20135010784253 ) ;
  }

  @Test
  public void test48() {
    dawson.dawson(-3.837091120686111 ) ;
  }

  @Test
  public void test49() {
    dawson.dawson(4.1508320151560785 ) ;
  }

  @Test
  public void test50() {
    dawson.dawson(41.97600962847085 ) ;
  }

  @Test
  public void test51() {
    dawson.dawson(-4.395101541726392 ) ;
  }

  @Test
  public void test52() {
    dawson.dawson(-5.218595456471206 ) ;
  }

  @Test
  public void test53() {
    dawson.dawson(52.24907728118512 ) ;
  }

  @Test
  public void test54() {
    dawson.dawson(54.79340938406884 ) ;
  }

  @Test
  public void test55() {
    dawson.dawson(-59.04113998373723 ) ;
  }

  @Test
  public void test56() {
    dawson.dawson(-60.136493999403214 ) ;
  }

  @Test
  public void test57() {
    dawson.dawson(61.44613703033542 ) ;
  }

  @Test
  public void test58() {
    dawson.dawson(-65.44997456204354 ) ;
  }

  @Test
  public void test59() {
    dawson.dawson(-65.67039091027547 ) ;
  }

  @Test
  public void test60() {
    dawson.dawson(66.12100400934938 ) ;
  }

  @Test
  public void test61() {
    dawson.dawson(71.66160272290517 ) ;
  }

  @Test
  public void test62() {
    dawson.dawson(73.59589649815808 ) ;
  }

  @Test
  public void test63() {
    dawson.dawson(-7.459500551010763 ) ;
  }

  @Test
  public void test64() {
    dawson.dawson(75.92923588868877 ) ;
  }

  @Test
  public void test65() {
    dawson.dawson(-78.18851993717337 ) ;
  }

  @Test
  public void test66() {
    dawson.dawson(7.908434799868715 ) ;
  }

  @Test
  public void test67() {
    dawson.dawson(80.09375093422554 ) ;
  }

  @Test
  public void test68() {
    dawson.dawson(-81.5412010547711 ) ;
  }

  @Test
  public void test69() {
    dawson.dawson(82.47290695001334 ) ;
  }

  @Test
  public void test70() {
    dawson.dawson(8.363923197916861 ) ;
  }

  @Test
  public void test71() {
    dawson.dawson(8.542343354643123 ) ;
  }

  @Test
  public void test72() {
    dawson.dawson(-89.82494380194342 ) ;
  }

  @Test
  public void test73() {
    dawson.dawson(99.26907201618081 ) ;
  }
}
