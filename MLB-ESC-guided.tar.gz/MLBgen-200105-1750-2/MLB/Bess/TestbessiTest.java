import org.junit.Test;

public class TestbessiTest {

  @Test
  public void test0() {
    bess.bessi(154,-6.67772578843811E-9 ) ;
  }

  @Test
  public void test1() {
    bess.bessi(1692,1.0693186770593573E-53 ) ;
  }

  @Test
  public void test2() {
    bess.bessi(-177,-1.0262557702850359E-8 ) ;
  }

  @Test
  public void test3() {
    bess.bessi(-1936,-2.5924989234891473E-50 ) ;
  }

  @Test
  public void test4() {
    bess.bessi(19,97.88901907464154 ) ;
  }

  @Test
  public void test5() {
    bess.bessi(266,3.1190671940149315 ) ;
  }

  @Test
  public void test6() {
    bess.bessi(-272,0.0 ) ;
  }

  @Test
  public void test7() {
    bess.bessi(282,0 ) ;
  }

  @Test
  public void test8() {
    bess.bessi(-335,1.0068468440801119E-8 ) ;
  }

  @Test
  public void test9() {
    bess.bessi(-397,0 ) ;
  }

  @Test
  public void test10() {
    bess.bessi(491,0.0 ) ;
  }

  @Test
  public void test11() {
    bess.bessi(548,-2.1964864884813954E-32 ) ;
  }

  @Test
  public void test12() {
    bess.bessi(659,6.2070330830985225E-12 ) ;
  }

  @Test
  public void test13() {
    bess.bessi(-698,2.7744920045435606 ) ;
  }

  @Test
  public void test14() {
    bess.bessi(-700,1.9800519442591257E-35 ) ;
  }

  @Test
  public void test15() {
    bess.bessi(-871,-39.2112939313338 ) ;
  }

  @Test
  public void test16() {
    bess.bessi(975,-88.43687163419756 ) ;
  }

  @Test
  public void test17() {
    bess.bessi(-988,95.86681215923733 ) ;
  }
}
