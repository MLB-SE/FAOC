import org.junit.Test;

public class TestbesskTest {

  @Test
  public void test0() {
    bess.bessk(127,1.2E-322 ) ;
  }

  @Test
  public void test1() {
    bess.bessk(13,5.063604926164049E-16 ) ;
  }

  @Test
  public void test2() {
    bess.bessk(194,-98.54942980068888 ) ;
  }

  @Test
  public void test3() {
    bess.bessk(195,0 ) ;
  }

  @Test
  public void test4() {
    bess.bessk(-199,85.44399170697733 ) ;
  }

  @Test
  public void test5() {
    bess.bessk(-225,-10.753333000817975 ) ;
  }

  @Test
  public void test6() {
    bess.bessk(243,-98.67286011680842 ) ;
  }

  @Test
  public void test7() {
    bess.bessk(260,-6.9E-323 ) ;
  }

  @Test
  public void test8() {
    bess.bessk(-27,2.0 ) ;
  }

  @Test
  public void test9() {
    bess.bessk(27,2.0 ) ;
  }

  @Test
  public void test10() {
    bess.bessk(275,4.440892098500626E-16 ) ;
  }

  @Test
  public void test11() {
    bess.bessk(-303,-1.4E-322 ) ;
  }

  @Test
  public void test12() {
    bess.bessk(-309,0.0 ) ;
  }

  @Test
  public void test13() {
    bess.bessk(-342,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test14() {
    bess.bessk(-349,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test15() {
    bess.bessk(-35,2.0 ) ;
  }

  @Test
  public void test16() {
    bess.bessk(-352,1.0620759372577555 ) ;
  }

  @Test
  public void test17() {
    bess.bessk(-483,-70.768571203384 ) ;
  }

  @Test
  public void test18() {
    bess.bessk(-551,2.0237E-320 ) ;
  }

  @Test
  public void test19() {
    bess.bessk(568,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test20() {
    bess.bessk(6,2.465190328815662E-32 ) ;
  }

  @Test
  public void test21() {
    bess.bessk(704,23.08769298171724 ) ;
  }

  @Test
  public void test22() {
    bess.bessk(-75,0 ) ;
  }

  @Test
  public void test23() {
    bess.bessk(766,2.0 ) ;
  }

  @Test
  public void test24() {
    bess.bessk(770,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test25() {
    bess.bessk(-817,1.14742923039202E-16 ) ;
  }

  @Test
  public void test26() {
    bess.bessk(824,-47.093582713508276 ) ;
  }

  @Test
  public void test27() {
    bess.bessk(-843,96.63492566256505 ) ;
  }

  @Test
  public void test28() {
    bess.bessk(895,0.0 ) ;
  }

  @Test
  public void test29() {
    bess.bessk(-920,1.0339508265629052E-15 ) ;
  }
}
