import org.junit.Test;

public class TestpoidevTest {

  @Test
  public void test0() {
    dev.poidev(0.0,731 ) ;
  }

  @Test
  public void test1() {
    dev.poidev(-1.0,0 ) ;
  }

  @Test
  public void test2() {
    dev.poidev(-1.0000000000000009,0 ) ;
  }

  @Test
  public void test3() {
    dev.poidev(10.0,-1 ) ;
  }

  @Test
  public void test4() {
    dev.poidev(-1.0,-1 ) ;
  }

  @Test
  public void test5() {
    dev.poidev(1.0,-1 ) ;
  }

  @Test
  public void test6() {
    dev.poidev(1.0,328 ) ;
  }

  @Test
  public void test7() {
    dev.poidev(-1.0,-740 ) ;
  }

  @Test
  public void test8() {
    dev.poidev(-1.0,8 ) ;
  }

  @Test
  public void test9() {
    dev.poidev(-1.0,811 ) ;
  }

  @Test
  public void test10() {
    dev.poidev(-1.0,-948 ) ;
  }

  @Test
  public void test11() {
    dev.poidev(11.0,-2 ) ;
  }

  @Test
  public void test12() {
    dev.poidev(-167.0,-1 ) ;
  }

  @Test
  public void test13() {
    dev.poidev(-1.999999999999999,0 ) ;
  }

  @Test
  public void test14() {
    dev.poidev(3.0,0 ) ;
  }

  @Test
  public void test15() {
    dev.poidev(-322.0,0 ) ;
  }

  @Test
  public void test16() {
    dev.poidev(-33.0,976 ) ;
  }

  @Test
  public void test17() {
    dev.poidev(-372.0,90 ) ;
  }

  @Test
  public void test18() {
    dev.poidev(43.35981930086942,0 ) ;
  }

  @Test
  public void test19() {
    dev.poidev(44.566631818669634,0 ) ;
  }

  @Test
  public void test20() {
    dev.poidev(-530.0,-378 ) ;
  }

  @Test
  public void test21() {
    dev.poidev(-583.0,-716 ) ;
  }

  @Test
  public void test22() {
    dev.poidev(6.720458161045471,0 ) ;
  }

  @Test
  public void test23() {
    dev.poidev(7.0,-887 ) ;
  }

  @Test
  public void test24() {
    dev.poidev(74.24970956160877,0 ) ;
  }

  @Test
  public void test25() {
    dev.poidev(-84.11411811712554,0 ) ;
  }

  @Test
  public void test26() {
    dev.poidev(-89.10903146921838,0 ) ;
  }

  @Test
  public void test27() {
    dev.poidev(9.220530803262776,0 ) ;
  }
}
