import org.junit.Test;

public class Testran0Test {

  @Test
  public void test0() {
    ran.ran0(680 ) ;
  }

  @Test
  public void test1() {
    ran.ran0(-786 ) ;
  }
}
