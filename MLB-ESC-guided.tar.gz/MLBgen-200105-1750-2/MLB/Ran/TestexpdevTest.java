import org.junit.Test;

public class TestexpdevTest {

  @Test
  public void test0() {
    dev.expdev(0 ) ;
  }

  @Test
  public void test1() {
    dev.expdev(-1 ) ;
  }

  @Test
  public void test2() {
    dev.expdev(203 ) ;
  }

  @Test
  public void test3() {
    dev.expdev(31 ) ;
  }

  @Test
  public void test4() {
    dev.expdev(-593 ) ;
  }

  @Test
  public void test5() {
    dev.expdev(-607 ) ;
  }

  @Test
  public void test6() {
    dev.expdev(-710 ) ;
  }

  @Test
  public void test7() {
    dev.expdev(-781 ) ;
  }

  @Test
  public void test8() {
    dev.expdev(-822 ) ;
  }
}
