import org.junit.Test;

public class Testran2Test {

  @Test
  public void test0() {
    ran.ran2(0 ) ;
  }

  @Test
  public void test1() {
    ran.ran2(-1 ) ;
  }

  @Test
  public void test2() {
    ran.ran2(1 ) ;
  }

  @Test
  public void test3() {
    ran.ran2(-238 ) ;
  }

  @Test
  public void test4() {
    ran.ran2(320 ) ;
  }

  @Test
  public void test5() {
    ran.ran2(-556 ) ;
  }

  @Test
  public void test6() {
    ran.ran2(-706 ) ;
  }

  @Test
  public void test7() {
    ran.ran2(-924 ) ;
  }

  @Test
  public void test8() {
    ran.ran2(998 ) ;
  }
}
