import org.junit.Test;

public class Testran3Test {

  @Test
  public void test0() {
    ran.ran3(0 ) ;
  }

  @Test
  public void test1() {
    ran.ran3(-120 ) ;
  }

  @Test
  public void test2() {
    ran.ran3(244 ) ;
  }

  @Test
  public void test3() {
    ran.ran3(253 ) ;
  }

  @Test
  public void test4() {
    ran.ran3(26060 ) ;
  }

  @Test
  public void test5() {
    ran.ran3(-26326 ) ;
  }

  @Test
  public void test6() {
    ran.ran3(27310 ) ;
  }

  @Test
  public void test7() {
    ran.ran3(-27367 ) ;
  }

  @Test
  public void test8() {
    ran.ran3(566 ) ;
  }

  @Test
  public void test9() {
    ran.ran3(-729 ) ;
  }

  @Test
  public void test10() {
    ran.ran3(-802 ) ;
  }

  @Test
  public void test11() {
    ran.ran3(833 ) ;
  }

  @Test
  public void test12() {
    ran.ran3(-987 ) ;
  }
}
