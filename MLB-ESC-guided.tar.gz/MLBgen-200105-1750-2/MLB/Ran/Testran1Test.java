import org.junit.Test;

public class Testran1Test {

  @Test
  public void test0() {
    ran.ran1(0 ) ;
  }

  @Test
  public void test1() {
    ran.ran1(-1 ) ;
  }

  @Test
  public void test2() {
    ran.ran1(145 ) ;
  }

  @Test
  public void test3() {
    ran.ran1(185 ) ;
  }

  @Test
  public void test4() {
    ran.ran1(-209 ) ;
  }

  @Test
  public void test5() {
    ran.ran1(-378 ) ;
  }

  @Test
  public void test6() {
    ran.ran1(-457 ) ;
  }

  @Test
  public void test7() {
    ran.ran1(-698 ) ;
  }
}
