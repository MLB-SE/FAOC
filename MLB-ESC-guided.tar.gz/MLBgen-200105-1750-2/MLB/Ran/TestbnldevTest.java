import org.junit.Test;

public class TestbnldevTest {

  @Test
  public void test0() {
    dev.bnldev(0.0,53,0 ) ;
  }

  @Test
  public void test1() {
    dev.bnldev(0.0,765,0 ) ;
  }

  @Test
  public void test2() {
    dev.bnldev(0.0,782,0 ) ;
  }

  @Test
  public void test3() {
    dev.bnldev(0.0,87,0 ) ;
  }

  @Test
  public void test4() {
    dev.bnldev(1.0,133,0 ) ;
  }

  @Test
  public void test5() {
    dev.bnldev(1.0,443,0 ) ;
  }

  @Test
  public void test6() {
    dev.bnldev(1.0,571,0 ) ;
  }

  @Test
  public void test7() {
    dev.bnldev(1.0,-61,0 ) ;
  }

  @Test
  public void test8() {
    dev.bnldev(1.0,-614,0 ) ;
  }

  @Test
  public void test9() {
    dev.bnldev(1.0,-653,0 ) ;
  }

  @Test
  public void test10() {
    dev.bnldev(1.0,-685,0 ) ;
  }

  @Test
  public void test11() {
    dev.bnldev(1.0,693,0 ) ;
  }

  @Test
  public void test12() {
    dev.bnldev(-12.0,-152,0 ) ;
  }

  @Test
  public void test13() {
    dev.bnldev(-1.3632442954321107,0,0 ) ;
  }

  @Test
  public void test14() {
    dev.bnldev(-143.0,25,0 ) ;
  }

  @Test
  public void test15() {
    dev.bnldev(182.0,25,0 ) ;
  }

  @Test
  public void test16() {
    dev.bnldev(-236.0,-1,0 ) ;
  }

  @Test
  public void test17() {
    dev.bnldev(295.0,-541,0 ) ;
  }

  @Test
  public void test18() {
    dev.bnldev(318.0,-649,0 ) ;
  }

  @Test
  public void test19() {
    dev.bnldev(-343.0,988,0 ) ;
  }

  @Test
  public void test20() {
    dev.bnldev(36.0,23,-569 ) ;
  }

  @Test
  public void test21() {
    dev.bnldev(-431.0,599,0 ) ;
  }

  @Test
  public void test22() {
    dev.bnldev(-435.0,-240,0 ) ;
  }

  @Test
  public void test23() {
    dev.bnldev(455.0,25,0 ) ;
  }

  @Test
  public void test24() {
    dev.bnldev(464.0,82,0 ) ;
  }

  @Test
  public void test25() {
    dev.bnldev(-49.0,-654,0 ) ;
  }

  @Test
  public void test26() {
    dev.bnldev(505.0,14,246 ) ;
  }

  @Test
  public void test27() {
    dev.bnldev(-513.0,-676,0 ) ;
  }

  @Test
  public void test28() {
    dev.bnldev(-551.0,-530,0 ) ;
  }

  @Test
  public void test29() {
    dev.bnldev(-568.0,7,0 ) ;
  }

  @Test
  public void test30() {
    dev.bnldev(-608.0,2,-267 ) ;
  }

  @Test
  public void test31() {
    dev.bnldev(614.0,699,0 ) ;
  }

  @Test
  public void test32() {
    dev.bnldev(61.749599802308666,0,0 ) ;
  }

  @Test
  public void test33() {
    dev.bnldev(-644.0,911,0 ) ;
  }

  @Test
  public void test34() {
    dev.bnldev(-677.0,13,714 ) ;
  }

  @Test
  public void test35() {
    dev.bnldev(-71.74505323101523,0,0 ) ;
  }

  @Test
  public void test36() {
    dev.bnldev(725.0,-319,0 ) ;
  }

  @Test
  public void test37() {
    dev.bnldev(-850.0,-94,0 ) ;
  }

  @Test
  public void test38() {
    dev.bnldev(924.0,14,0 ) ;
  }

  @Test
  public void test39() {
    dev.bnldev(-932.0,-308,0 ) ;
  }

  @Test
  public void test40() {
    dev.bnldev(969.0,722,0 ) ;
  }
}
