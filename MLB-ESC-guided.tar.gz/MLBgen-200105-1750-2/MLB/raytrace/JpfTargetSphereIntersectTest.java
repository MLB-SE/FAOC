import org.junit.Test;

public class JpfTargetSphereIntersectTest {

  @Test
  public void test0() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.15849815f,99.90704f,99.98353f,99.96744f,99.80889f,100.0f,99.99792f,-0.7131055f,-0.34941947f,0.6077718f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0.10405641f,-0.12150018f,0.65476865f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.35475707f,-0.18415074f,0.721956f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-0.7414736f,0.020200156f,-0.6706779f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1.096387E-10f,1.3702467E-9f,4.8654806E-11f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,12.622552f,45.48105f,35.568966f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1.3080342E-12f,4.7501293E-13f,-2.9076896E-13f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1.3165752E-7f,2.6415358E-7f,-4.5497213E-6f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-1.615331E-12f,3.5338865E-13f,-6.630118E-13f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1.628608E-22f,-6.2675663E-22f,-2.2959265E-22f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2.1679183E-4f,-5.1643944E-4f,-0.001718764f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-4.4463272E-6f,-7.1360255E-6f,-3.2510833E-8f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,64.384834f,-56.845715f,-94.26252f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-6.899447E-4f,5.2174542E-5f,1.4338958E-5f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-8.6391583E-10f,-2.5779692E-9f,-2.0214442E-8f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,0.13522364f,99.99742f,-100.0f,-99.68185f,-99.86169f,-0.2024539f,0.8321246f,0.51631486f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-100.0f,100.0f,-100.0f,-59.253162f,34.824368f,-100.0f,-0.7999803f,-0.052035645f,-0.5977657f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,100.0f,46.21074f,-100.0f,53.74167f,19.466408f,-100.0f,0.18995866f,0.51859134f,-0.32912332f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-100.0f,-4.977126f,59.35912f,100.0f,-100.0f,54.381996f,0.015404615f,0.12473247f,-0.9920708f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,100.0f,-8.625398f,71.56711f,-99.789795f,87.09158f,61.767635f,-0.29498965f,-0.6020292f,-0.17356072f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-49.952827f,-42.14832f,93.15709f,-31.3222f,-1.8579295f,-1.5467874f,-0.4850679f,0.29561427f,0.34818828f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,5.4083176f,79.504524f,26.936062f,-92.43994f,-36.23503f,77.70522f,-0.3554644f,4.66723f,0.08135152f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,56.968372f,81.440384f,97.37443f,-64.09461f,30.724974f,100.0f,0.24619162f,0.23866795f,0.043036595f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-67.98166f,-7.3757124f,20.200674f,-100.0f,-14.86323f,-100.0f,0.3647419f,0.9304162f,-0.03590267f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-69.63859f,48.225513f,62.462887f,-62.597916f,-31.277617f,80.967636f,-1.4025477f,-3.5904174f,7.4468737f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,99.62077f,-29.85917f,88.98767f,95.67912f,39.898014f,35.968845f,0.24983981f,0.039553963f,-0.4906459f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,99.69989f,99.99985f,0.3001085f,100.0f,100.0f,99.99998f,0.75126606f,-0.47149873f,0.4618314f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,99.77218f,100.0f,49.7412f,-99.89807f,99.999985f,50.107372f,-1.2441629f,-6.0557137f,-0.5141496f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-10.246265f,77.67373f,33.428226f,38.912292f,-28.630426f,81.907005f,-0.6051176f,0.57073903f,-0.28416425f,-0.19136536f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-11.560574f,-60.490826f,-88.245926f,20.906403f,-19.372726f,-79.38649f,-83.88683f,-0.61501384f,0.37175867f,0.5092677f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,11.7059145f,24.966606f,72.15068f,-26.107904f,-69.80118f,-63.9918f,7.694465f,-0.43030086f,0.069012366f,0.085967235f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,15.263015f,-42.55311f,53.166786f,40.216564f,-6.7706866f,-23.531837f,12.089103f,-5.062218f,-3.251425f,9.50184f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-15.717987f,8.236601f,-41.997074f,-43.79572f,-22.679142f,-34.30063f,-73.97015f,1.9274713f,-2.8766458f,-2.2460258f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-16.791323f,100.0f,22.024477f,51.73087f,6.2868896f,84.45743f,-21.586386f,0.6293197f,-0.20701914f,0.501162f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,17.92422f,39.038498f,-62.154617f,-68.17144f,-25.719133f,100.0f,5.90519f,-0.91793394f,0.17175256f,0.35762876f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,19.209219f,68.98003f,-72.97385f,74.42974f,50.89897f,91.63007f,-9.550496f,0.47022644f,0.4420062f,-0.5888576f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,19.822441f,-43.542145f,72.13555f,80.05874f,45.720787f,27.059273f,99.670044f,-1.7558093f,1.1455053f,-1.4725198f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-2.131872f,36.904255f,-23.554062f,51.12606f,7.053409f,-9.114164f,-43.847168f,0.10932892f,0.5300332f,0.6258424f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,23.261223f,-67.39636f,67.06437f,-52.571175f,81.9142f,48.170883f,45.585793f,4.3189955f,12.254753f,2.9937568f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-24.828634f,-62.61576f,-99.20941f,93.02477f,56.37307f,-31.376614f,-40.38883f,-0.09190908f,0.39759398f,-0.91294676f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-25.000978f,-95.80048f,-21.683323f,72.65974f,-92.66552f,-70.71246f,-30.141912f,-0.02911945f,-0.70043457f,0.5156415f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-25.290222f,-86.503525f,-80.939026f,-99.99997f,87.05945f,36.70912f,-92.63621f,4.907784f,11.194299f,-9.041879f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,258.6197f,100.0f,-99.99999f,100.0f,169.04504f,56.953915f,-88.91094f,0.56972814f,0.8209348f,0.04100668f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,27.295475f,-100.0f,100.0f,100.0f,-13.359075f,-10.954361f,79.55295f,0.062574655f,-0.9974445f,0.03448067f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-29.92371f,91.21864f,90.31621f,-25.051254f,76.78535f,98.01292f,98.9527f,0.9569934f,-0.04278755f,0.28693712f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,34.462425f,51.802505f,64.93794f,60.32986f,-11.695335f,65.75242f,28.68118f,0.34952664f,-0.5513373f,-0.12157071f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,35.24022f,27.486565f,-18.332075f,71.52837f,-20.934023f,-16.006418f,-26.64609f,0.33877292f,-0.3222882f,0.63311195f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-37.57185f,-56.143578f,54.766373f,-100.0f,62.148823f,71.138504f,59.071365f,0.6267642f,0.4872032f,0.6081116f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-37.667572f,16.542255f,57.083176f,66.34734f,17.766134f,45.703094f,78.96284f,-0.41481447f,-0.6803144f,0.5977886f ) ;
  }

  @Test
  public void test49() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,38.117176f,100.0f,-99.99917f,99.95153f,-33.642597f,42.702343f,-60.529907f,0.84524184f,0.38638547f,0.36915106f ) ;
  }

  @Test
  public void test50() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,38.243755f,100.0f,-52.226254f,61.5228f,78.88188f,80.662735f,-10.277861f,-0.35039955f,-0.5381084f,-0.1567166f ) ;
  }

  @Test
  public void test51() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-39.702168f,10.204976f,56.914715f,84.369804f,29.085154f,58.48692f,64.35935f,0.0649298f,-0.20175809f,0.3503832f ) ;
  }

  @Test
  public void test52() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,40.893158f,2.0145597f,-2.039523f,62.105274f,62.90986f,-38.076622f,-44.051746f,-0.025824517f,-0.59736526f,0.68257564f ) ;
  }

  @Test
  public void test53() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,41.032696f,-83.00768f,7.148238f,-100.0f,-95.61317f,-57.93385f,-96.58744f,-0.33726242f,-0.06994888f,-0.9388084f ) ;
  }

  @Test
  public void test54() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,41.646317f,18.687407f,44.960938f,99.997894f,99.99991f,99.13654f,56.023224f,0.07713822f,-0.9624204f,0.26037788f ) ;
  }

  @Test
  public void test55() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-43.87843f,-49.050182f,60.474224f,-98.99935f,-99.728645f,100.0f,65.450424f,-0.85640126f,0.51624614f,-0.008173563f ) ;
  }

  @Test
  public void test56() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,46.78006f,-70.66331f,-100.0f,32.563282f,36.394127f,-34.000412f,-99.86884f,-0.14395463f,-0.5427073f,-0.5805102f ) ;
  }

  @Test
  public void test57() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,46.938255f,-4.284018f,99.99999f,-27.116386f,6.2470074f,5.5454297f,100.0f,-4.7556524f,-2.3866832f,-0.34589678f ) ;
  }

  @Test
  public void test58() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-47.320816f,-85.66249f,75.94027f,100.0f,17.6923f,-100.0f,1.304548f,-0.71305156f,0.17637898f,-0.67724526f ) ;
  }

  @Test
  public void test59() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-4.9404993f,30.222984f,-39.73347f,26.372976f,-21.226427f,43.42545f,-55.733387f,0.6691241f,-0.58363175f,0.35603613f ) ;
  }

  @Test
  public void test60() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-50.620945f,1.7536912f,1.9987236f,41.621f,-100.0f,7.0341988f,41.57742f,-0.5515838f,-0.6716356f,1.4493556f ) ;
  }

  @Test
  public void test61() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-51.508f,-62.993362f,-31.541784f,87.64728f,11.555699f,-14.329556f,5.021169f,0.4251295f,-0.19803177f,-0.8162353f ) ;
  }

  @Test
  public void test62() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,51.912502f,-64.80092f,-32.664867f,26.186893f,37.1058f,-43.303635f,-34.75815f,-5.5297704f,-4.119395f,-0.43397665f ) ;
  }

  @Test
  public void test63() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,54.1733f,62.57356f,82.35081f,25.132612f,55.59131f,69.207115f,57.46314f,-1.0110806f,-0.24764043f,-0.38254055f ) ;
  }

  @Test
  public void test64() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-55.79886f,-194.11641f,-96.606285f,-34.25901f,-88.224815f,-100.0f,40.76193f,-0.026528256f,0.48186126f,0.8756465f ) ;
  }

  @Test
  public void test65() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-56.46676f,-9.350227f,26.739645f,90.82105f,7.4427257f,32.810173f,-22.152666f,0.8811882f,-2.585811f,-1.1892251f ) ;
  }

  @Test
  public void test66() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-59.614902f,-34.01167f,83.56871f,26.22794f,-49.679783f,-51.905453f,99.97025f,-0.13145404f,0.735724f,-0.5115446f ) ;
  }

  @Test
  public void test67() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-61.396133f,80.64698f,-99.489174f,68.30515f,100.0f,-85.21953f,68.663734f,-0.7889614f,-0.6119978f,-0.054759458f ) ;
  }

  @Test
  public void test68() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-66.381325f,-22.838766f,-66.88047f,73.29493f,-68.03844f,-94.34066f,-85.87298f,0.94735235f,1.1244042f,-2.6770658f ) ;
  }

  @Test
  public void test69() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-66.8734f,22.696722f,42.709335f,100.0f,-100.0f,100.0f,-11.3908615f,0.88549775f,0.11278622f,0.4507472f ) ;
  }

  @Test
  public void test70() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-67.852135f,-4.912673f,-100.0f,99.36159f,-99.99999f,-100.0f,-99.00138f,-0.10383447f,0.19531801f,0.97522783f ) ;
  }

  @Test
  public void test71() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,68.93582f,-100.0f,-22.226053f,53.23144f,43.43794f,-100.0f,24.501291f,0.4004046f,0.7601867f,-0.51165646f ) ;
  }

  @Test
  public void test72() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-69.573524f,-100.0f,-77.45192f,37.870647f,-99.99999f,-100.0f,-100.0f,-0.02828341f,0.07266308f,0.99695545f ) ;
  }

  @Test
  public void test73() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-71.22599f,-99.50249f,-99.74054f,-29.212337f,-43.9887f,-5.500852f,24.822392f,-0.54668075f,-3.4224827f,3.931443f ) ;
  }

  @Test
  public void test74() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,71.24166f,-51.03182f,28.274248f,52.059277f,55.494236f,-87.84173f,-5.000627f,0.045343194f,-0.24719419f,0.9678645f ) ;
  }

  @Test
  public void test75() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-72.05746f,-95.28795f,-57.585205f,80.94887f,-81.07317f,-18.395046f,-81.22662f,0.23906736f,-0.90849733f,-0.34275267f ) ;
  }

  @Test
  public void test76() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,72.35374f,99.99966f,35.929974f,-46.50142f,7.6040125f,-100.0f,73.16216f,-0.10705835f,-0.01277136f,0.9941707f ) ;
  }

  @Test
  public void test77() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-72.57892f,82.46076f,-67.93521f,78.72977f,-83.0391f,47.91628f,-77.51852f,0.03567009f,0.29873216f,-0.11829454f ) ;
  }

  @Test
  public void test78() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,74.38407f,100.0f,100.0f,70.19755f,36.379105f,39.035664f,41.234615f,0.40762225f,0.89856213f,-0.16257353f ) ;
  }

  @Test
  public void test79() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-7.509489f,-100.0f,99.717636f,81.74863f,15.694185f,-17.643377f,100.0f,0.029575245f,-0.73454815f,0.67791176f ) ;
  }

  @Test
  public void test80() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-75.1741f,-88.58031f,-100.0f,100.0f,15.901518f,100.0f,31.008537f,0.08844385f,0.3329818f,0.7336748f ) ;
  }

  @Test
  public void test81() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-75.588165f,64.40717f,-99.12137f,-92.86295f,-42.48218f,0.9033482f,-1.3361536f,0.1384577f,-0.11061775f,0.76031f ) ;
  }

  @Test
  public void test82() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-76.4286f,-99.365425f,68.279175f,35.951813f,-45.43855f,-99.99969f,88.60292f,-4.311429f,-8.918086f,1.8268979f ) ;
  }

  @Test
  public void test83() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,79.057785f,65.69217f,23.909613f,31.9894f,100.0f,72.7038f,0.7673021f,-0.45637628f,3.1818318f,0.7306584f ) ;
  }

  @Test
  public void test84() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-79.61598f,72.1569f,44.695023f,30.842382f,-66.80914f,67.14307f,17.088882f,0.47269917f,0.32899705f,0.6695706f ) ;
  }

  @Test
  public void test85() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,81.44305f,25.141844f,95.077034f,-99.54306f,-59.897057f,72.02106f,75.15316f,-0.4834599f,0.84384334f,-0.23279798f ) ;
  }

  @Test
  public void test86() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-81.7532f,30.164867f,-26.005959f,46.958744f,-98.95229f,71.24878f,-40.88638f,-0.2743782f,-0.34647912f,0.44727507f ) ;
  }

  @Test
  public void test87() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-81.95802f,-100.0f,-95.95524f,18.48981f,-100.0f,-99.99999f,-100.0f,0.6628901f,0.05712036f,0.74653465f ) ;
  }

  @Test
  public void test88() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,83.26874f,19.016693f,-16.890015f,88.35333f,3.1089275f,-11.812897f,-37.63253f,0.1926868f,2.0029178f,-3.67919f ) ;
  }

  @Test
  public void test89() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,83.27237f,-83.25192f,-100.0f,38.203793f,100.0f,89.4407f,-100.0f,1.7725148f,-0.6143683f,-0.69631875f ) ;
  }

  @Test
  public void test90() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,84.14059f,28.193817f,-23.378185f,71.27323f,99.275795f,100.0f,-20.443027f,0.45962262f,-0.3108017f,-0.83195513f ) ;
  }

  @Test
  public void test91() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-85.97866f,99.18215f,-92.926346f,8.305763f,5.790694f,73.90215f,-98.93363f,-1.6794606f,-4.2144012f,-1.3689872f ) ;
  }

  @Test
  public void test92() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,86.15943f,-100.0f,-51.559124f,100.0f,72.39629f,-67.328705f,77.18939f,-0.81288916f,0.12376171f,0.5691171f ) ;
  }

  @Test
  public void test93() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-87.39052f,98.33557f,-95.2008f,13.613367f,-100.0f,99.99989f,-100.0f,0.7898042f,-0.19967413f,0.5799479f ) ;
  }

  @Test
  public void test94() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-96.74585f,-26.30875f,100.0f,99.77527f,-37.199894f,-99.99787f,68.70651f,-0.63530546f,0.43319476f,0.63931936f ) ;
  }

  @Test
  public void test95() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-9.757396f,3.05897f,46.260635f,59.508595f,-42.57067f,-39.401154f,20.537401f,0.43911788f,1.8985789f,0.38813308f ) ;
  }

  @Test
  public void test96() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.653336f,100.0f,56.852978f,99.849915f,-99.99999f,-4.616073f,98.691536f,-4.9091234f,1.5573348f,-6.2870884f ) ;
  }

  @Test
  public void test97() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.88282f,11.2368765f,55.459743f,53.698444f,23.56651f,52.947056f,67.780846f,0.05065234f,-0.72168684f,0.690364f ) ;
  }

  @Test
  public void test98() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.98653f,11.382703f,64.119675f,45.08583f,-74.436905f,31.123089f,32.651184f,-0.15285774f,-0.07020965f,-6.624391E-5f ) ;
  }

  @Test
  public void test99() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.99653f,100.0f,-16.82279f,98.12381f,-62.111637f,63.845955f,-99.80412f,-0.0904537f,0.5771095f,0.76697695f ) ;
  }

  @Test
  public void test100() {
    TestDrivers.sphereIntersect(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-99.99984f,-68.68096f,17.916203f,10.552534f,-99.99836f,-71.666885f,7.7949247f,0.6657225f,-0.646783f,0.19095011f ) ;
  }
}
