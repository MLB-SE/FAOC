import org.junit.Test;

public class JpfTargetSurfaceShadeTest {

  @Test
  public void test0() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,0f,0f,0f,70.38352f,-74.927505f,36.490906f,0f,0f,0f,1,-0.6147949f,0.33007914f,-0.01984762f,0f,0f,0f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,-28.393515f,-100.0f,-100.0f,0f,0f,0f,1,-0.16790104f,-0.4736514f,-0.505794f,0f,0f,0f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0.0f,0f,0f,0f,0f,0f,80.5695f,-100.0f,95.23985f,0f,0f,0f,3,0.45329896f,0.30738267f,-0.03290038f,0f,0f,0f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.0191772f,-0.87961704f,0.4752958f,0f,0f,0f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.09450219f,0.46467498f,0.8492744f,0f,0f,0f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.14469242f,0.32615414f,0.13018633f,0f,0f,0f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.17645864f,0.6678006f,0.65829444f,0f,0f,0f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.18152422f,0.7285122f,0.61041194f,0f,0f,0f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.21445414f,0.70925754f,-0.08782243f,0f,0f,0f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.28038698f,-0.09683861f,-0.32169002f,0f,0f,0f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.34633252f,0.17559978f,0.58758265f,0f,0f,0f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.34886736f,0.00829047f,-0.03510194f,0f,0f,0f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.35706234f,-0.277531f,0.16410232f,0f,0f,0f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.35908943f,-0.24851666f,-0.16276073f,0f,0f,0f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.3890103f,0.14965855f,-0.8178567f,0f,0f,0f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.42013144f,-0.5185004f,0.1794164f,0f,0f,0f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.42723066f,-0.15959096f,-0.1832368f,0f,0f,0f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.43570164f,0.488509f,-0.27857956f,0f,0f,0f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.46738502f,-0.13468821f,0.5196286f,0f,0f,0f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.47375107f,0.43612745f,0.43910527f,0f,0f,0f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.49775672f,-0.026984764f,0.7753426f,0f,0f,0f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.5209234f,-0.084447f,0.40451533f,0f,0f,0f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.52264893f,-0.36020035f,-0.21108314f,0f,0f,0f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.570429f,0.17817232f,-0.30974743f,0f,0f,0f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.77492535f,0.03208193f,0.6227767f,0f,0f,0f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.7943225f,0.075464465f,0.19456495f,0f,0f,0f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.827988f,0.14880212f,0.0115636f,0f,0f,0f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-0.8587053f,-0.30275714f,-0.27309424f,0f,0f,0f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0.87503564f,-0.22697818f,0.06399762f,0f,0f,0f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,1.1322732E-4f,0.001426237f,-0.0040471433f,0f,0f,0f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,1.3554663E-18f,-1.8318137E-16f,-1.840358E-12f,0f,0f,0f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,1.6167535E-8f,3.963129E-8f,1.6389593E-7f,0f,0f,0f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-26.47248f,-83.83168f,20.309967f,0f,0f,0f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-2.8786027E-9f,-8.647951E-9f,5.061573E-9f,0f,0f,0f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-3.9782724E-5f,-1.4861359E-4f,-8.930593E-5f,0f,0f,0f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-41.55481f,-43.565376f,-53.421825f,0f,0f,0f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-4.2788484E-9f,-4.3864434E-6f,3.2626997E-7f,0f,0f,0f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1,-7.65687E-9f,-2.663271E-9f,3.7134156E-9f,0f,0f,0f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,2,0.0043894774f,-0.0030453329f,-0.0016101237f,0f,0f,0f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,3,87.78421f,11.800298f,-52.96408f,0f,0f,0f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,545,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-931,0f,0f,0f,0f,0f,0f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-48.981197f,-69.07641f,0f,0f,0f,1,-19.703236f,-5.43601f,-24.669226f,0f,0f,0f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,16.90134f,-100.0f,-48.9899f,0f,0f,0f,1,-10.31366f,4.3742003f,-12.486956f,0f,0f,0f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-3.2082565f,-73.84529f,37.724663f,0f,0f,0f,1,7.6664066f,5.5052285f,11.428359f,0f,0f,0f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-36.528667f,17.375902f,-34.64393f,0f,0f,0f,1,-30.712421f,-25.28439f,19.701714f,0f,0f,0f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-43.437374f,14.644026f,3.827247f,0f,0f,0f,1,-0.050846275f,-0.33591193f,-0.014930345f,0f,0f,0f ) ;
  }

  @Test
  public void test49() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-86.09043f,-2.493658f,-18.80147f,0f,0f,0f,1,-0.05886529f,0.5197718f,-0.12628454f,0f,0f,0f ) ;
  }

  @Test
  public void test50() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,-87.97787f,62.007378f,24.65646f,0f,0f,0f,1,-4.930079f,-3.7870114f,-8.067467f,0f,0f,0f ) ;
  }

  @Test
  public void test51() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-100.0f,19.027609f,-80.89607f,592.0f,-1546.0f,983.0f,5,-0.29768488f,-1.509194f,-0.82271713f,0f,0f,0f ) ;
  }

  @Test
  public void test52() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-100.0f,-19.51224f,53.605503f,-1281.0f,-1016.0f,-928.0f,1,-0.435681f,0.70466655f,2.511796f,0f,0f,0f ) ;
  }

  @Test
  public void test53() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-100.0f,59.956837f,-100.0f,443.0f,909.0f,2528.0f,-3,-0.031617407f,0.99740297f,-0.0208529f,0f,0f,0f ) ;
  }

  @Test
  public void test54() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,11.502251f,-1.81141f,-36.60021f,390.0f,759.0f,85.0f,3,-0.9789523f,-2.6420915f,-0.27239466f,0f,0f,0f ) ;
  }

  @Test
  public void test55() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-12.073956f,-20.523777f,-48.20419f,1544.0f,-44.0f,-368.0f,1,-0.7603118f,-0.225278f,-0.584904f,0f,0f,0f ) ;
  }

  @Test
  public void test56() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,15.973601f,-85.06404f,-43.597305f,-737.0f,328.0f,-910.0f,1,-0.24457344f,-0.6682347f,0.2970914f,0f,0f,0f ) ;
  }

  @Test
  public void test57() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-23.000149f,-98.11071f,-5.0821366f,640.0f,-267.0f,2258.0f,1,-0.39585778f,0.06531488f,-0.1278398f,0f,0f,0f ) ;
  }

  @Test
  public void test58() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-44.318398f,-39.31473f,-6.370293f,-281.0f,431.0f,-744.0f,12,-1.0566511f,0.54663664f,2.0452332f,0f,0f,0f ) ;
  }

  @Test
  public void test59() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,47.07031f,9.800156f,15.300069f,216.0f,530.0f,-1004.0f,1,-0.0045493115f,-0.04576039f,0.06484263f,0f,0f,0f ) ;
  }

  @Test
  public void test60() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-47.952824f,68.2604f,64.634544f,-2174.0f,1085.0f,707.0f,1,0.045062535f,0.55053926f,-0.14424181f,0f,0f,0f ) ;
  }

  @Test
  public void test61() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-48.592148f,-100.0f,100.0f,-2844.0f,-7.0f,-783.0f,2,0.39174858f,-0.017794065f,0.7339116f,0f,0f,0f ) ;
  }

  @Test
  public void test62() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,7.675876f,100.0f,4.859463f,0f,0f,0f,1,-0.13430852f,0.021834666f,0.8357013f,0f,0f,0f ) ;
  }

  @Test
  public void test63() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-82.66976f,64.33037f,-65.09726f,-593.0f,1039.0f,-1197.0f,4,-2.5149395f,-0.6811225f,0.45571485f,0f,0f,0f ) ;
  }

  @Test
  public void test64() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,89.43905f,61.16078f,52.039738f,912.0f,1795.0f,918.0f,2,-0.13683304f,1.0819261f,-0.022088636f,0f,0f,0f ) ;
  }

  @Test
  public void test65() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.0f,0f,0f,0f,0f,0f,-97.94245f,99.53261f,2.8004806f,-182.0f,-177.0f,-64.0f,1,-0.22945601f,0.8942109f,0.08811721f,0f,0f,0f ) ;
  }

  @Test
  public void test66() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,100.22802f,0f,0f,0f,0f,0f,0.38790768f,-17.184586f,4.3377466f,-339.0f,-326.0f,-1261.0f,1,-0.7943538f,-0.042955607f,0.029329916f,0f,0f,0f ) ;
  }

  @Test
  public void test67() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,107.11124f,0f,0f,0f,0f,0f,-42.367657f,-4.434773f,31.042284f,-186.0f,489.0f,-184.0f,1,-0.7511455f,0.30825263f,-0.25285766f,0f,0f,0f ) ;
  }

  @Test
  public void test68() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,11.210879f,0f,0f,0f,0f,0f,22.57421f,-31.346571f,33.51376f,767.0f,-979.0f,-1432.0f,2,0.14555119f,-0.55366457f,1.5375416f,0f,0f,0f ) ;
  }

  @Test
  public void test69() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,11.798781f,0f,0f,0f,0f,0f,98.05242f,100.0f,-36.029488f,479.0f,226.0f,661.0f,2,0.35658255f,0.64229053f,0.4270963f,0f,0f,0f ) ;
  }

  @Test
  public void test70() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,129.05939f,0f,0f,0f,0f,0f,-29.070692f,-35.25043f,-68.15769f,800.0f,191.0f,-440.0f,1,-0.9382308f,-0.28783274f,0.074876785f,0f,0f,0f ) ;
  }

  @Test
  public void test71() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,136.86037f,0f,0f,0f,0f,0f,-51.950287f,-36.397045f,101.27727f,1706.0f,1021.0f,-2098.0f,1,-0.22129945f,0.2934828f,0.80446905f,0f,0f,0f ) ;
  }

  @Test
  public void test72() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,16.480675f,0f,0f,0f,0f,0f,25.13691f,-6.3082614f,-38.27812f,628.0f,-1466.0f,654.0f,-2,5.315362f,0.37711987f,-0.08816185f,0f,0f,0f ) ;
  }

  @Test
  public void test73() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,17.443073f,0f,0f,0f,0f,0f,70.22662f,80.19881f,-33.270153f,1129.0f,650.0f,-619.0f,1,-0.050534885f,0.8902825f,0.23211835f,0f,0f,0f ) ;
  }

  @Test
  public void test74() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,17.661148f,0f,0f,0f,0f,0f,76.226524f,100.0f,-80.32023f,668.0f,-356.0f,-355.0f,3,0.68716353f,0.48795393f,0.39183295f,0f,0f,0f ) ;
  }

  @Test
  public void test75() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,19.942621f,0f,0f,0f,0f,0f,-1.3587765f,35.27945f,53.691597f,592.0f,697.0f,-443.0f,1,1.7213184f,-3.120674f,2.927837f,0f,0f,0f ) ;
  }

  @Test
  public void test76() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,22.514223f,0f,0f,0f,0f,0f,-11.1478f,-26.691906f,-160.91342f,-492.0f,-1845.0f,-792.0f,1,0.24990346f,-0.84104526f,-0.09622315f,0f,0f,0f ) ;
  }

  @Test
  public void test77() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,24.062946f,0f,0f,0f,0f,0f,-45.336468f,4.660734f,18.794071f,-19.0f,812.0f,1514.0f,1,-0.1308932f,0.17653298f,0.9197224f,0f,0f,0f ) ;
  }

  @Test
  public void test78() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,248.8323f,0f,0f,0f,0f,0f,98.33119f,52.069042f,78.54806f,794.0f,-506.0f,-656.0f,1,19.974869f,6.4822154f,2.2606022f,0f,0f,0f ) ;
  }

  @Test
  public void test79() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.01076f,0f,0f,0f,0f,0f,-81.30108f,-159.60757f,-76.881386f,-1242.0f,-1567.0f,-724.0f,-1,-0.6952822f,-1.0618912f,1.7590173f,0f,0f,0f ) ;
  }

  @Test
  public void test80() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.0967f,0f,0f,0f,0f,0f,-58.74265f,-98.91656f,181.36195f,121.0f,-814.0f,1140.0f,1,-0.30542997f,-3.6874864f,0.5803868f,0f,0f,0f ) ;
  }

  @Test
  public void test81() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.16176f,0f,0f,0f,0f,0f,81.48263f,-95.875206f,201.45561f,767.0f,-1112.0f,1705.0f,-7,8.23564f,-2.5350182f,-4.0475416f,0f,0f,0f ) ;
  }

  @Test
  public void test82() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.90004f,0f,0f,0f,0f,0f,-37.115135f,-38.36425f,-195.91608f,-2317.0f,866.0f,236.0f,4,-0.011510325f,0.074270666f,-5.6975417f,0f,0f,0f ) ;
  }

  @Test
  public void test83() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,253.94147f,0f,0f,0f,0f,0f,77.60288f,-63.24946f,-63.114166f,441.0f,459.0f,-889.0f,1,-0.49506393f,1.0502397f,-4.3872166f,0f,0f,0f ) ;
  }

  @Test
  public void test84() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.00047f,0f,0f,0f,0f,0f,30.92496f,-130.31912f,-90.98353f,298.0f,-2016.0f,958.0f,2,0.36006287f,-1.8760157f,-0.73929226f,0f,0f,0f ) ;
  }

  @Test
  public void test85() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.14679f,0f,0f,0f,0f,0f,-90.74398f,-114.11441f,-72.972755f,-1577.0f,-1963.0f,390.0f,-1,-0.8458163f,-1.0706389f,0.9826442f,0f,0f,0f ) ;
  }

  @Test
  public void test86() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.15361f,0f,0f,0f,0f,0f,82.85381f,184.3213f,3.4283595f,-1419.0f,1818.0f,30.0f,1,-0.46943948f,0.51326025f,0.769075f,0f,0f,0f ) ;
  }

  @Test
  public void test87() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.31578f,0f,0f,0f,0f,0f,16.136879f,97.38693f,-53.173912f,-332.0f,508.0f,95.0f,1,0.015183092f,-0.14230263f,-0.6289339f,0f,0f,0f ) ;
  }

  @Test
  public void test88() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.38716f,0f,0f,0f,0f,0f,-38.91657f,59.947308f,-77.4715f,1306.0f,434.0f,-624.0f,-2,-0.48070726f,-3.5857618f,-3.9878387f,0f,0f,0f ) ;
  }

  @Test
  public void test89() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.56157f,0f,0f,0f,0f,0f,-195.21605f,-88.97164f,-33.057926f,-1432.0f,-229.0f,-1481.0f,-1,-2.3627074f,1.13529f,-0.12776315f,0f,0f,0f ) ;
  }

  @Test
  public void test90() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.5973f,0f,0f,0f,0f,0f,44.398163f,11.183464f,-58.12197f,536.0f,-22.0f,-1810.0f,-1,-2.3561082f,2.4876478f,-4.5140047f,0f,0f,0f ) ;
  }

  @Test
  public void test91() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.66309f,0f,0f,0f,0f,0f,-180.34999f,-173.96799f,127.22341f,-308.0f,-120.0f,-460.0f,1,0.33478814f,-0.7051655f,1.4418772f,0f,0f,0f ) ;
  }

  @Test
  public void test92() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.69157f,0f,0f,0f,0f,0f,36.76974f,99.23638f,28.997736f,13.0f,12.0f,169.0f,1,-0.24611443f,0.5328463f,-0.68091977f,0f,0f,0f ) ;
  }

  @Test
  public void test93() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.71638f,0f,0f,0f,0f,0f,-26.967138f,-88.19524f,-33.51848f,-339.0f,-690.0f,509.0f,1,0.61098176f,-0.68229204f,0.28908822f,0f,0f,0f ) ;
  }

  @Test
  public void test94() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.76431f,0f,0f,0f,0f,0f,56.109257f,-315.77173f,-47.501114f,12.0f,-771.0f,-1377.0f,1,0.14407673f,-1.2843273f,0.9730713f,0f,0f,0f ) ;
  }

  @Test
  public void test95() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.818f,0f,0f,0f,0f,0f,72.28691f,-80.82775f,-14.888124f,-257.0f,-1566.0f,348.0f,2,5.803435f,1.5514809f,-2.4868507f,0f,0f,0f ) ;
  }

  @Test
  public void test96() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.8577f,0f,0f,0f,0f,0f,-49.388195f,-64.49949f,-180.6948f,264.0f,-1086.0f,221.0f,1,-0.09073022f,0.4520311f,-0.19184074f,0f,0f,0f ) ;
  }

  @Test
  public void test97() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.86232f,0f,0f,0f,0f,0f,-25.749687f,47.74556f,96.71005f,-667.0f,-676.0f,350.0f,1,-0.15018782f,-0.63701f,0.6480717f,0f,0f,0f ) ;
  }

  @Test
  public void test98() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.86894f,0f,0f,0f,0f,0f,61.87054f,71.41673f,277.64233f,2523.0f,-873.0f,1368.0f,1,-0.1740243f,-0.056472797f,0.87618554f,0f,0f,0f ) ;
  }

  @Test
  public void test99() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.90887f,0f,0f,0f,0f,0f,53.434914f,146.31734f,-38.8529f,3302.0f,-662.0f,1051.0f,1,0.9393525f,-0.027564207f,-0.150205f,0f,0f,0f ) ;
  }

  @Test
  public void test100() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.93784f,0f,0f,0f,0f,0f,-51.688206f,-8.883442f,-182.93254f,-815.0f,856.0f,-723.0f,-3,1.2939576f,-0.56145984f,-3.7204282f,0f,0f,0f ) ;
  }

  @Test
  public void test101() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.94281f,0f,0f,0f,0f,0f,-169.84499f,-98.92302f,-9.288943f,-2634.0f,-1143.0f,-113.0f,1,-0.062468927f,-0.29349774f,-0.25815243f,0f,0f,0f ) ;
  }

  @Test
  public void test102() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.95343f,0f,0f,0f,0f,0f,-40.01516f,100.78289f,-7.8482046f,-915.0f,504.0f,-901.0f,1,-0.18791953f,0.40270016f,0.42829844f,0f,0f,0f ) ;
  }

  @Test
  public void test103() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.97743f,0f,0f,0f,0f,0f,-59.9327f,63.759827f,-98.93141f,6.0f,306.0f,-778.0f,1,-0.5397416f,0.8031049f,-0.20149094f,0f,0f,0f ) ;
  }

  @Test
  public void test104() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.98087f,0f,0f,0f,0f,0f,37.161354f,231.40887f,100.0f,1723.0f,609.0f,465.0f,1,-0.084683575f,4.4136863f,-0.09342569f,0f,0f,0f ) ;
  }

  @Test
  public void test105() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.98512f,0f,0f,0f,0f,0f,-128.61475f,-86.910675f,55.263557f,-243.0f,-930.0f,1373.0f,1,-0.9573616f,-0.26894423f,-0.04927404f,0f,0f,0f ) ;
  }

  @Test
  public void test106() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.99022f,0f,0f,0f,0f,0f,-55.858612f,18.317768f,-38.75869f,-589.0f,1246.0f,-47.0f,1,0.06726222f,0.014767805f,-0.7083654f,0f,0f,0f ) ;
  }

  @Test
  public void test107() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.99251f,0f,0f,0f,0f,0f,36.56446f,8.198243f,39.277893f,1550.0f,1375.0f,791.0f,1,0.10868017f,-0.21643314f,-0.007278924f,0f,0f,0f ) ;
  }

  @Test
  public void test108() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.9945f,0f,0f,0f,0f,0f,30.247793f,174.83208f,79.92196f,1728.0f,816.0f,411.0f,1,0.12196737f,0.2849007f,-0.35953376f,0f,0f,0f ) ;
  }

  @Test
  public void test109() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,254.99974f,0f,0f,0f,0f,0f,127.65274f,41.077625f,-27.518776f,1243.0f,1905.0f,207.0f,1,0.5033374f,-0.75273806f,0.41663864f,0f,0f,0f ) ;
  }

  @Test
  public void test110() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.00055f,0f,0f,0f,0f,0f,96.47013f,280.25708f,-21.633003f,210.0f,1055.0f,-630.0f,1,0.09516102f,0.6798892f,-0.2842519f,0f,0f,0f ) ;
  }

  @Test
  public void test111() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.00056f,0f,0f,0f,0f,0f,-63.069702f,-33.88134f,19.49141f,-819.0f,-1422.0f,-744.0f,1,-0.16757028f,-0.6787252f,0.057414874f,0f,0f,0f ) ;
  }

  @Test
  public void test112() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.0006f,0f,0f,0f,0f,0f,9.43789f,-161.43988f,20.16857f,1251.0f,-1805.0f,935.0f,1,0.49493003f,-0.7319564f,-0.2488952f,0f,0f,0f ) ;
  }

  @Test
  public void test113() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.0027f,0f,0f,0f,0f,0f,57.99041f,30.580103f,-131.56747f,90.0f,350.0f,-973.0f,1,-0.074062526f,-0.45694593f,-0.46302631f,0f,0f,0f ) ;
  }

  @Test
  public void test114() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.00304f,0f,0f,0f,0f,0f,-81.57915f,16.219728f,175.08267f,-293.0f,1242.0f,554.0f,1,0.31347966f,-0.2774598f,0.78971976f,0f,0f,0f ) ;
  }

  @Test
  public void test115() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.0289f,0f,0f,0f,0f,0f,13.168675f,-32.881275f,59.987057f,2634.0f,864.0f,821.0f,1,0.45612222f,-0.67442995f,-0.007634976f,0f,0f,0f ) ;
  }

  @Test
  public void test116() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.04918f,0f,0f,0f,0f,0f,157.89996f,-181.25456f,-93.19027f,1526.0f,1917.0f,-1583.0f,-3,-0.026966242f,0.16599175f,-2.71289f,0f,0f,0f ) ;
  }

  @Test
  public void test117() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.06812f,0f,0f,0f,0f,0f,-72.432884f,-62.60201f,22.603796f,-1052.0f,977.0f,1493.0f,1,-0.94607884f,-0.01641206f,-0.21213181f,0f,0f,0f ) ;
  }

  @Test
  public void test118() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.12082f,0f,0f,0f,0f,0f,82.7883f,-204.80309f,-38.784424f,1256.0f,-1655.0f,437.0f,1,0.3531186f,-0.7567229f,0.04467632f,0f,0f,0f ) ;
  }

  @Test
  public void test119() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,255.77942f,0f,0f,0f,0f,0f,37.449913f,143.67807f,-36.104946f,72.0f,1625.0f,892.0f,1,3.5675807f,3.7900908f,0.17697507f,0f,0f,0f ) ;
  }

  @Test
  public void test120() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,256.23395f,0f,0f,0f,0f,0f,83.90143f,-171.25903f,12.515693f,-1118.0f,-812.0f,-1698.0f,-1,-0.039833438f,-4.0402727f,-1.0895218f,0f,0f,0f ) ;
  }

  @Test
  public void test121() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,258.5636f,0f,0f,0f,0f,0f,-165.9837f,93.950035f,-103.933014f,640.0f,902.0f,-1538.0f,2,-7.619095f,-3.578227f,5.055247f,0f,0f,0f ) ;
  }

  @Test
  public void test122() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,261.48196f,0f,0f,0f,0f,0f,118.03365f,-8.820898f,29.350893f,615.0f,740.0f,334.0f,2,-0.6191742f,-11.765604f,-0.27395925f,0f,0f,0f ) ;
  }

  @Test
  public void test123() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,261.9254f,0f,0f,0f,0f,0f,-43.52035f,31.03761f,-230.14267f,-257.0f,1690.0f,72.0f,-1,-2.6802895f,-6.270948f,-0.49489483f,0f,0f,0f ) ;
  }

  @Test
  public void test124() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,264.8311f,0f,0f,0f,0f,0f,-119.437325f,-60.59451f,-44.902317f,800.0f,-1703.0f,-636.0f,1,-2.000964f,-0.01411411f,0.45107165f,0f,0f,0f ) ;
  }

  @Test
  public void test125() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,275.0929f,0f,0f,0f,0f,0f,32.168514f,-29.29539f,169.24815f,183.0f,-3164.0f,1380.0f,1,-0.07102701f,-0.148695f,0.5945511f,0f,0f,0f ) ;
  }

  @Test
  public void test126() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,275.74448f,0f,0f,0f,0f,0f,-62.00296f,-19.8989f,56.619484f,438.0f,2425.0f,2368.0f,1,-0.009771322f,-0.46994358f,-0.0043165833f,0f,0f,0f ) ;
  }

  @Test
  public void test127() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,280.71902f,0f,0f,0f,0f,0f,-35.789726f,-21.648664f,-14.615871f,-2989.0f,1057.0f,-576.0f,-8,7.8700085f,-19.129698f,-3.8169034f,0f,0f,0f ) ;
  }

  @Test
  public void test128() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,28.836935f,0f,0f,0f,0f,0f,-46.143112f,100.0f,52.123573f,-1137.0f,766.0f,1360.0f,1,0.1174058f,0.8284199f,0.38009384f,0f,0f,0f ) ;
  }

  @Test
  public void test129() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,299.1654f,0f,0f,0f,0f,0f,-83.50251f,-91.078674f,-317.3259f,-18.0f,344.0f,-2105.0f,1,-0.16325977f,-0.18011251f,-0.5968689f,0f,0f,0f ) ;
  }

  @Test
  public void test130() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,329.7475f,0f,0f,0f,0f,0f,2.9704666f,-88.623215f,66.130554f,-845.0f,-740.0f,1403.0f,-1,1.7572848f,-2.8354511f,-0.80024654f,0f,0f,0f ) ;
  }

  @Test
  public void test131() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,352.09943f,0f,0f,0f,0f,0f,-203.72542f,-18.352224f,-67.70987f,-1405.0f,-986.0f,-1781.0f,2,0.285347f,-1.9223201f,-1.3900312f,0f,0f,0f ) ;
  }

  @Test
  public void test132() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,369.16846f,0f,0f,0f,0f,0f,101.55705f,144.88368f,95.65357f,886.0f,3063.0f,770.0f,1,5.0202074f,-3.7421322f,0.8132062f,0f,0f,0f ) ;
  }

  @Test
  public void test133() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-38.61031f,0f,0f,0f,0f,0f,76.74742f,-148.454f,-40.04082f,0f,0f,0f,2,0.1297529f,-0.14241311f,-0.7752329f,0f,0f,0f ) ;
  }

  @Test
  public void test134() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,40.74961f,0f,0f,0f,0f,0f,41.388603f,19.259993f,57.149437f,-607.0f,435.0f,293.0f,1,0.30091184f,0.13271493f,0.8941665f,0f,0f,0f ) ;
  }

  @Test
  public void test135() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,48.26544f,0f,0f,0f,0f,0f,-39.000813f,-15.87792f,4.5677323f,164.0f,-553.0f,-522.0f,1,-0.3624774f,0.043928027f,-0.2305331f,0f,0f,0f ) ;
  }

  @Test
  public void test136() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,54.277966f,0f,0f,0f,0f,0f,-100.0f,72.634796f,-14.786073f,382.0f,1335.0f,-445.0f,2,-0.65637016f,0.9339995f,-0.1727688f,0f,0f,0f ) ;
  }

  @Test
  public void test137() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,58.555595f,0f,0f,0f,0f,0f,56.121864f,0.2117566f,-31.524954f,665.0f,789.0f,1189.0f,2,-0.15679592f,-0.12056638f,-1.0072504f,0f,0f,0f ) ;
  }

  @Test
  public void test138() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,6.3681684f,0f,0f,0f,0f,0f,-100.0f,-22.01645f,45.8527f,30.0f,853.0f,475.0f,1,-0.34579137f,1.5792238f,3.763472f,0f,0f,0f ) ;
  }

  @Test
  public void test139() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,-69.24024f,0f,0f,0f,0f,0f,-24.960943f,-100.0f,21.988272f,0f,0f,0f,1,0.73624736f,-0.23078884f,0.23553008f,0f,0f,0f ) ;
  }

  @Test
  public void test140() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,77.94136f,0f,0f,0f,0f,0f,-98.00747f,23.29009f,46.61983f,-269.0f,25.0f,-578.0f,1,-2.7391055f,-2.1965249f,-4.168819f,0f,0f,0f ) ;
  }

  @Test
  public void test141() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,81.33637f,0f,0f,0f,0f,0f,23.456123f,-10.205012f,40.569736f,110.0f,388.0f,34.0f,1,-0.12026574f,0.0289024f,0.2927225f,0f,0f,0f ) ;
  }

  @Test
  public void test142() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,81.92213f,0f,0f,0f,0f,0f,100.0f,-145.78534f,-100.0f,1219.0f,-1592.0f,-882.0f,1,-0.2858022f,-0.18498488f,-0.31199175f,0f,0f,0f ) ;
  }

  @Test
  public void test143() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,82.45552f,0f,0f,0f,0f,0f,4.187818f,5.444249f,-10.596595f,-1427.0f,-584.0f,-864.0f,1,-0.10260179f,0.47961286f,-0.40185377f,0f,0f,0f ) ;
  }

  @Test
  public void test144() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,83.21486f,0f,0f,0f,0f,0f,-29.186588f,-99.98103f,-80.8888f,599.0f,-581.0f,502.0f,-4,-0.953385f,0.7013371f,-1.3748988f,0f,0f,0f ) ;
  }

  @Test
  public void test145() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,83.47894f,0f,0f,0f,0f,0f,24.356728f,36.54632f,-43.48234f,-996.0f,48.0f,-519.0f,1,0.78066313f,-0.005596452f,0.004811143f,0f,0f,0f ) ;
  }

  @Test
  public void test146() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,84.641945f,0f,0f,0f,0f,0f,-99.99143f,-84.99153f,-40.884403f,-48.0f,5.0f,107.0f,1,-0.80889475f,-0.52917486f,-0.13368958f,0f,0f,0f ) ;
  }

  @Test
  public void test147() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,8.543629f,0f,0f,0f,0f,0f,-100.0f,100.0f,-68.06893f,-558.0f,125.0f,-789.0f,-1,-0.2251778f,0.7772909f,-0.02096721f,0f,0f,0f ) ;
  }

  @Test
  public void test148() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,85.94254f,0f,0f,0f,0f,0f,-63.538025f,7.608874f,1.7931439f,-100.0f,-877.0f,178.0f,1,0.093666494f,0.9823829f,-0.03133655f,0f,0f,0f ) ;
  }

  @Test
  public void test149() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,95.81277f,0f,0f,0f,0f,0f,11.716857f,23.215437f,-33.78832f,55.0f,559.0f,-942.0f,1,-0.2712863f,0.61723053f,0.21500936f,0f,0f,0f ) ;
  }

  @Test
  public void test150() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,97.51532f,0f,0f,0f,0f,0f,-41.711876f,-9.634972f,-93.39029f,-465.0f,1858.0f,16.0f,1,-0.75771856f,-0.29250577f,0.22911805f,0f,0f,0f ) ;
  }

  @Test
  public void test151() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,98.888214f,0f,0f,0f,0f,0f,-38.847183f,100.0f,-3.4692466f,-1076.0f,-420.0f,-72.0f,1,-0.65070903f,3.1279397f,1.4665318f,0f,0f,0f ) ;
  }

  @Test
  public void test152() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,99.04176f,0f,0f,0f,0f,0f,100.0f,-19.256826f,24.08885f,430.0f,-278.0f,248.0f,-4,5.0970144f,0.025527112f,-0.3960356f,0f,0f,0f ) ;
  }

  @Test
  public void test153() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,99.99575f,0f,0f,0f,0f,0f,25.51039f,-71.27225f,52.910145f,-135.0f,-663.0f,-828.0f,1,-0.50833106f,-0.7223867f,-0.33684587f,0f,0f,0f ) ;
  }

  @Test
  public void test154() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,0f,0f,0f,99.996544f,0f,0f,0f,0f,0f,29.732828f,-70.8854f,-29.496586f,1302.0f,450.0f,231.0f,1,0.17878081f,-0.7112476f,-0.39459926f,0f,0f,0f ) ;
  }

  @Test
  public void test155() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,0.0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,-17.599474f,-82.29139f,0f,0f,0f,2,0.80038494f,-0.043502133f,-0.40366635f,0f,0f,0f ) ;
  }

  @Test
  public void test156() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-100.0f,-7.6232514f,0f,0.0f,0f,0f,0f,0f,0f,100.0f,-100.0f,-100.0f,0f,0f,0f,2,-0.6439953f,0.36755642f,-0.6135514f,0f,0f,0f ) ;
  }

  @Test
  public void test157() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1168.0f,-1220.0f,0f,5494.0f,0f,0f,0f,0f,0f,102.0f,-616.0f,-333.0f,722.0f,-47.0f,308.0f,1,0.047687624f,0.53353494f,0.02193599f,0f,0f,0f ) ;
  }

  @Test
  public void test158() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1176.0f,-1281.0f,0f,2884.0f,0f,0f,0f,0f,0f,-392.0f,-671.0f,1145.0f,-217.0f,422.0f,173.0f,1,0.81292164f,-0.35110304f,-0.22964945f,0f,0f,0f ) ;
  }

  @Test
  public void test159() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1200.0f,-632.0f,0f,1420.0f,0f,0f,0f,0f,0f,-810.0f,9.0f,108.0f,-86.0f,-70.0f,-638.0f,2,0.22072674f,-0.67348737f,-0.06802326f,0f,0f,0f ) ;
  }

  @Test
  public void test160() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1382.0f,-18.0f,0f,2814.0f,0f,0f,0f,0f,0f,113.0f,-39.0f,209.0f,1038.0f,-58.0f,-500.0f,1,0.4789629f,-1.6856614f,-2.1963632f,0f,0f,0f ) ;
  }

  @Test
  public void test161() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1463.0f,-3989.0f,0f,935.0f,0f,0f,0f,0f,0f,181.0f,-156.0f,-212.0f,110.0f,-790.0f,616.0f,1,-0.22766306f,2.4284296f,1.1860138f,0f,0f,0f ) ;
  }

  @Test
  public void test162() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1570.0f,-1995.0f,0f,2189.0f,0f,0f,0f,0f,0f,155.0f,-322.0f,521.0f,-499.0f,317.0f,363.0f,-3,1.3799199f,-2.1165638f,-4.780991f,0f,0f,0f ) ;
  }

  @Test
  public void test163() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1649.0f,-1033.0f,0f,1092.0f,0f,0f,0f,0f,0f,257.0f,-777.0f,-1885.0f,1471.0f,-1715.0f,318.0f,1,-0.10016632f,0.06464606f,0.9792048f,0f,0f,0f ) ;
  }

  @Test
  public void test164() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1681.0f,-484.0f,0f,1435.0f,0f,0f,0f,0f,0f,291.0f,-174.0f,-194.0f,-58.0f,-526.0f,385.0f,3,0.21009599f,-1.6553816f,2.689129f,0f,0f,0f ) ;
  }

  @Test
  public void test165() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1722.0f,-755.0f,0f,2448.0f,0f,0f,0f,0f,0f,-10.0f,-147.0f,-171.0f,948.0f,-217.0f,131.0f,1,-0.4274467f,0.09370949f,0.14746128f,0f,0f,0f ) ;
  }

  @Test
  public void test166() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1726.0f,-2187.0f,0f,1041.0f,0f,0f,0f,0f,0f,-973.0f,-48.0f,-432.0f,-1.0f,560.0f,-60.0f,-8,-2.3129516f,-0.100750394f,8.347178f,0f,0f,0f ) ;
  }

  @Test
  public void test167() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1750.0f,-2394.0f,0f,100.0f,0f,0f,0f,0f,0f,-650.0f,664.0f,353.0f,-485.0f,-8.0f,-878.0f,1,0.4547659f,0.07841931f,-0.15716337f,0f,0f,0f ) ;
  }

  @Test
  public void test168() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1936.0f,-1808.0f,0f,3102.0f,0f,0f,0f,0f,0f,-165.0f,-387.0f,-213.0f,622.0f,-772.0f,921.0f,1,-0.035207685f,0.051980317f,0.3179255f,0f,0f,0f ) ;
  }

  @Test
  public void test169() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1960.0f,-1112.0f,0f,1015.0f,0f,0f,0f,0f,0f,-337.0f,274.0f,652.0f,1041.0f,-1001.0f,959.0f,-1,0.16133411f,0.4715597f,-0.19987202f,0f,0f,0f ) ;
  }

  @Test
  public void test170() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-19.708374f,-100.0f,0f,37.4562f,0f,0f,0f,0f,0f,-46.715546f,69.61283f,-88.86634f,0f,0f,0f,1,-0.0726571f,0.11917082f,0.51457506f,0f,0f,0f ) ;
  }

  @Test
  public void test171() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-1991.0f,-1698.0f,0f,1037.0f,0f,0f,0f,0f,0f,1285.0f,-1562.0f,-82.0f,133.0f,134.0f,-469.0f,1,-0.13600233f,0.163128f,-0.82126933f,0f,0f,0f ) ;
  }

  @Test
  public void test172() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-21.640366f,0f,0f,0f,0f,0f,0f,0f,0f,-100.0f,3.567152f,-100.0f,0f,0f,0f,1,-0.07536456f,0.47686753f,0.1377172f,0f,0f,0f ) ;
  }

  @Test
  public void test173() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2425.0f,-841.0f,0f,1736.0f,0f,0f,0f,0f,0f,-433.0f,572.0f,-9.0f,398.0f,324.0f,1183.0f,-1,3.2233615f,2.3212116f,2.2111893f,0f,0f,0f ) ;
  }

  @Test
  public void test174() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-24.550667f,-7.7524757f,0f,-75.74324f,0f,0f,0f,0f,0f,57.96216f,100.0f,-0.597656f,0f,0f,0f,1,-0.31809598f,-0.69726497f,-0.3271246f,0f,0f,0f ) ;
  }

  @Test
  public void test175() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-254.0f,-173.0f,0f,1476.0f,0f,0f,0f,0f,0f,613.0f,-15.0f,492.0f,-96.0f,-283.0f,111.0f,3,-0.18529706f,0.15808047f,-0.6685341f,0f,0f,0f ) ;
  }

  @Test
  public void test176() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-255.0f,-1681.0f,0f,2471.0f,0f,0f,0f,0f,0f,-698.0f,-371.0f,859.0f,327.0f,-129.0f,210.0f,1,-0.061090317f,0.24474727f,-0.96577257f,0f,0f,0f ) ;
  }

  @Test
  public void test177() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,26.568533f,0f,0f,0f,0f,0f,0f,0f,0f,100.0f,-100.0f,19.806623f,0f,0f,0f,1,-0.3327099f,0.034130685f,0.9223463f,0f,0f,0f ) ;
  }

  @Test
  public void test178() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-2977.0f,-1489.0f,0f,759.0f,0f,0f,0f,0f,0f,592.0f,451.0f,942.0f,-1080.0f,-1094.0f,1349.0f,4,0.0045018382f,-0.07318311f,-0.08147357f,0f,0f,0f ) ;
  }

  @Test
  public void test179() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-34.353783f,0.0f,0f,0f,0f,0f,0f,0f,0f,-6.885511f,23.009098f,97.09395f,0f,0f,0f,1,0.40378729f,-0.45567834f,-0.69542575f,0f,0f,0f ) ;
  }

  @Test
  public void test180() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-3764.0f,-305.0f,0f,854.0f,0f,0f,0f,0f,0f,37.0f,415.0f,-294.0f,-2528.0f,-252.0f,-938.0f,22,-4.7098093f,0.36452436f,8.407072f,0f,0f,0f ) ;
  }

  @Test
  public void test181() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-38.744175f,-100.0f,0f,-1.0379164E-31f,0f,0f,0f,0f,0f,-93.89911f,-13.462924f,-19.05571f,0f,0f,0f,-1,1.319098f,0.03086126f,1.5304525f,0f,0f,0f ) ;
  }

  @Test
  public void test182() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-433.0f,-585.0f,0f,1308.0f,0f,0f,0f,0f,0f,-1693.0f,-145.0f,-892.0f,-210.0f,-1619.0f,717.0f,1,-0.17229679f,0.32539317f,0.53652686f,0f,0f,0f ) ;
  }

  @Test
  public void test183() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-440.0f,-498.0f,0f,350.0f,0f,0f,0f,0f,0f,-2862.0f,-865.0f,-577.0f,2113.0f,318.0f,2477.0f,-9,7.3391504f,9.293769f,-0.034971572f,0f,0f,0f ) ;
  }

  @Test
  public void test184() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-46.64785f,77.08449f,0f,0f,0f,0f,0f,0f,0f,-100.0f,27.228685f,-82.58383f,0f,0f,0f,1,-0.016220735f,-0.17353402f,0.020552961f,0f,0f,0f ) ;
  }

  @Test
  public void test185() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-475.0f,-687.0f,0f,109.0f,0f,0f,0f,0f,0f,-122.0f,897.0f,-1836.0f,766.0f,922.0f,-1380.0f,1,-0.19927251f,0.3359505f,0.7396066f,0f,0f,0f ) ;
  }

  @Test
  public void test186() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-551.0f,-1118.0f,0f,426.0f,0f,0f,0f,0f,0f,-598.0f,1385.0f,-1403.0f,1134.0f,-149.0f,-2354.0f,4,-0.06975197f,-0.7377648f,0.23419324f,0f,0f,0f ) ;
  }

  @Test
  public void test187() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-65.94418f,0.0f,0f,0f,0f,0f,0f,0f,0f,77.51961f,-12.443742f,82.14625f,0f,0f,0f,-2,0.029023822f,0.07643626f,-0.82153934f,0f,0f,0f ) ;
  }

  @Test
  public void test188() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-662.0f,-1140.0f,0f,1887.0f,0f,0f,0f,0f,0f,94.0f,523.0f,-3.0f,-1480.0f,265.0f,-176.0f,1,-0.35091156f,-0.579085f,-0.26038417f,0f,0f,0f ) ;
  }

  @Test
  public void test189() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-701.0f,-1090.0f,0f,1142.0f,0f,0f,0f,0f,0f,-1152.0f,199.0f,704.0f,-395.0f,-288.0f,-565.0f,-3,5.664654f,1.9732506f,-0.19807626f,0f,0f,0f ) ;
  }

  @Test
  public void test190() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-712.0f,-1209.0f,0f,1899.0f,0f,0f,0f,0f,0f,-1243.0f,1282.0f,-704.0f,450.0f,-148.0f,-1144.0f,1,-0.7132322f,-6.777526f,-9.767407f,0f,0f,0f ) ;
  }

  @Test
  public void test191() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-759.0f,-1169.0f,0f,665.0f,0f,0f,0f,0f,0f,114.0f,801.0f,-904.0f,1243.0f,-994.0f,-724.0f,1,0.2450427f,-0.79973394f,-0.5478375f,0f,0f,0f ) ;
  }

  @Test
  public void test192() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-783.0f,-157.0f,0f,264.0f,0f,0f,0f,0f,0f,-535.0f,154.0f,-491.0f,149.0f,1474.0f,282.0f,-17,-2.1785514f,0.28729287f,5.5632973f,0f,0f,0f ) ;
  }

  @Test
  public void test193() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-816.0f,-727.0f,0f,2381.0f,0f,0f,0f,0f,0f,65.0f,564.0f,-773.0f,-1231.0f,919.0f,566.0f,2,0.15554067f,-0.16918601f,0.6503048f,0f,0f,0f ) ;
  }

  @Test
  public void test194() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-81.85845f,-65.57913f,0f,0f,0f,0f,0f,0f,0f,23.361593f,18.322443f,-43.910282f,0f,0f,0f,1,-0.035723288f,0.009839099f,0.604031f,0f,0f,0f ) ;
  }

  @Test
  public void test195() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-843.0f,-1995.0f,0f,451.0f,0f,0f,0f,0f,0f,-193.0f,-43.0f,-39.0f,-47.0f,327.0f,-128.0f,1,-0.059646882f,0.9168179f,-0.1851455f,0f,0f,0f ) ;
  }

  @Test
  public void test196() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-913.0f,-538.0f,0f,1287.0f,0f,0f,0f,0f,0f,87.0f,1704.0f,-113.0f,-1592.0f,1553.0f,840.0f,-2,-0.1614886f,-4.3220005f,-0.34951288f,0f,0f,0f ) ;
  }

  @Test
  public void test197() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-927.0f,-1597.0f,0f,1101.0f,0f,0f,0f,0f,0f,-399.0f,-505.0f,1372.0f,1364.0f,823.0f,700.0f,1,2.2177842f,0.41946796f,-1.2703685f,0f,0f,0f ) ;
  }

  @Test
  public void test198() {
    TestDrivers.surfaceShade(0f,0f,0f,0f,-94.33108f,-42.756844f,0f,0.0f,0f,0f,0f,0f,0f,-91.26003f,-100.0f,100.0f,0f,0f,0f,1,0.9020313f,-0.065569274f,0.33011293f,0f,0f,0f ) ;
  }
}
