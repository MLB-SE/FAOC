import org.junit.Test;

public class JpfTargetRayTraceTest {

  @Test
  public void test0() {
    TestDrivers.rayTrace(0.30032104f,41.313915f,-99.07221f,78.92644f,79.76905f,-47.9976f,8.236267f,-0.056447588f,0.40542635f,-0.11075364f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,0.062043536f,0.24527732f,-0.9674656f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,0.19815648f,0.15899235f,0.0088556595f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,0.5649922f,0.682093f,0.2859982f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-2.189131E-10f,-3.6756504E-11f,3.615133E-11f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,2.4681308f,34.288895f,47.072678f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-2.9500422E-6f,-7.2070156E-6f,-3.819347E-5f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-3.0367142E-9f,-4.736148E-10f,4.7954054E-9f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-3.452153E-7f,1.1539179E-6f,9.69921E-7f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-37.862514f,39.902367f,-80.74383f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,4.1110642E-22f,2.7882116E-22f,-2.0886488E-22f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-4.3787138E-4f,-4.603017E-4f,3.1217042E-4f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-5.22819E-7f,1.9775007E-6f,-6.148876E-7f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-7.035691E-9f,-1.1720138E-9f,5.558999E-9f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-89.277954f,49.376022f,27.445541f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-9.90247E-15f,-5.531898E-14f,5.4503223E-14f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.rayTrace(100.0f,0.91818446f,89.086334f,-85.131355f,27.378624f,-100.0f,-10.27461f,-0.25777656f,-0.41235718f,-0.8737922f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.rayTrace(-100.0f,-100.0f,100.0f,0.0f,-100.0f,-100.0f,100.0f,-29.061926f,-100.0f,100.0f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.rayTrace(100.0f,100.0f,100.0f,-100.0f,-100.0f,100.0f,-56.03768f,0.63204503f,-0.085862555f,0.7701602f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.rayTrace(-100.0f,100.0f,-100.0f,100.0f,-3.457621f,100.0f,-54.3978f,-0.68773067f,-0.39553314f,0.60875285f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.rayTrace(100.0f,100.0f,-100.0f,-100.0f,60.640392f,-77.83706f,-55.51711f,0.3953774f,0.726102f,-0.5371942f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.rayTrace(-100.0f,100.0f,-100.0f,91.83444f,24.023882f,20.45937f,27.871443f,0.78434336f,-0.028492806f,0.61967224f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.rayTrace(100.0f,-100.0f,-10.630329f,100.0f,-35.7439f,100.0f,-100.0f,0.65329134f,-0.7502405f,-0.10173299f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.rayTrace(100.0f,100.0f,20.539885f,100.0f,93.56818f,100.0f,57.35435f,0.9855821f,0.16797231f,0.020327026f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.rayTrace(100.0f,-100.0f,-6.788943f,99.99998f,100.0f,-99.99998f,100.0f,-0.22105582f,0.28763062f,-0.9318814f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.rayTrace(100.0f,-100.0f,-99.209366f,79.0316f,-100.0f,44.16087f,-59.324654f,-0.6939341f,0.55347013f,0.46057174f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.rayTrace(100.0f,20.995085f,-83.69999f,-63.575237f,98.97993f,72.683846f,28.812944f,-0.43539426f,0.7511322f,0.33749658f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.rayTrace(100.0f,25.035889f,-1.6593844f,100.0f,-99.49959f,86.635284f,100.0f,0.96516f,-0.11572401f,-0.23467876f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.rayTrace(100.0f,-25.892853f,100.0f,-53.71403f,-47.760216f,-51.85119f,-73.7391f,-0.05577827f,-0.99672556f,0.05853975f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.rayTrace(100.0f,-31.538227f,43.99137f,-94.65063f,89.04305f,-100.0f,-100.0f,6.6400814E-4f,-0.87926257f,-0.47633693f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.rayTrace(100.0f,41.602886f,-63.61096f,-76.0685f,-17.150225f,100.0f,-74.68072f,-0.051495448f,-0.7150403f,0.69718397f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.rayTrace(100.0f,4.943682f,-78.44217f,-100.0f,45.78541f,-100.0f,-65.43906f,-0.077489056f,0.9706358f,0.2277314f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.rayTrace(100.0f,-51.417072f,28.648355f,57.92297f,-6.9413824f,-3.005174f,35.755505f,-0.99525666f,-0.08962034f,0.037847344f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.rayTrace(100.0f,-72.41158f,100.0f,-70.56093f,31.84244f,-100.0f,99.92993f,-0.49645883f,0.4750102f,0.7265631f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.rayTrace(-100.0f,-76.86068f,-100.0f,100.0f,81.7108f,-13.384588f,-58.349293f,-0.6284086f,-0.22794119f,-0.10860468f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.rayTrace(100.0f,92.14387f,-33.399765f,-36.98923f,100.0f,55.97299f,-40.884846f,-0.8200366f,0.1293411f,-0.5575041f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.rayTrace(-100.0f,-9.220187f,4.8963513f,26.400614f,-94.505196f,-16.113037f,-14.364957f,-0.7852401f,0.24052045f,0.14399673f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.rayTrace(-100.0f,-99.97886f,100.0f,-100.0f,100.0f,-100.0f,99.99846f,-0.99208724f,-0.124798596f,0.013719406f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.rayTrace(-11.052122f,99.99999f,100.0f,-99.99835f,100.0f,100.0f,32.94337f,0.8288858f,0.54153603f,0.14031078f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.rayTrace(1.2232747f,26.085316f,28.157768f,-100.0f,-10.8731365f,-4.1493087f,81.396935f,0.36264527f,-0.30711928f,-0.24115598f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.rayTrace(-12.683905f,19.299368f,26.25515f,63.539215f,64.794685f,63.208073f,1.5436718f,15.76843f,-26.170023f,57.259815f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.rayTrace(13.906276f,-2.7664557f,99.99979f,49.210693f,60.86567f,-71.73051f,99.05935f,-7.484776f,4.0955253f,4.097745f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.rayTrace(-14.79229f,-35.57131f,0.57251716f,-88.96102f,29.864502f,-51.366974f,-50.895103f,-22.114788f,-89.80883f,75.78135f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.rayTrace(-15.084165f,89.709465f,-92.928406f,-65.86958f,70.39766f,-13.087572f,65.54868f,-82.5231f,-46.258884f,-62.130775f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.rayTrace(15.658721f,45.014244f,-68.99152f,-74.38554f,29.008158f,-25.222101f,-48.452393f,-35.852238f,22.437588f,100.0f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.rayTrace(15.675168f,-16.653755f,39.918694f,-100.0f,100.0f,-23.051458f,-58.809025f,0.76109743f,-0.06778878f,-0.6450856f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.rayTrace(-17.170729f,56.144653f,38.679935f,73.03463f,-100.0f,100.0f,93.34858f,0.99937135f,0.026673894f,0.023354653f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.rayTrace(17.278847f,-43.43239f,75.64598f,100.0f,24.605978f,-68.07841f,36.898777f,-0.09788248f,0.27879703f,-0.7364449f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.rayTrace(-1.7496551f,-21.903358f,-129.68958f,100.0f,-30.55054f,-100.0f,-75.96262f,0.96624327f,0.25761995f,-0.0063210283f ) ;
  }

  @Test
  public void test49() {
    TestDrivers.rayTrace(-18.276192f,100.0f,-10.049148f,-100.0f,25.414127f,100.0f,-100.0f,-0.99971455f,0.017410906f,-0.016360072f ) ;
  }

  @Test
  public void test50() {
    TestDrivers.rayTrace(-18.72556f,100.0f,-79.933655f,30.328157f,-22.953037f,-99.99928f,-91.66084f,-0.0729104f,0.9954945f,-0.060619775f ) ;
  }

  @Test
  public void test51() {
    TestDrivers.rayTrace(19.686275f,-19.495964f,99.26067f,-45.804626f,4.9952955f,-64.3471f,-30.456081f,3.8827271f,-5.4875636f,-15.527016f ) ;
  }

  @Test
  public void test52() {
    TestDrivers.rayTrace(-21.74343f,13.956256f,2.9582891f,87.91736f,-64.75536f,53.284756f,-46.83362f,0.9329721f,0.223979f,0.066671304f ) ;
  }

  @Test
  public void test53() {
    TestDrivers.rayTrace(22.09409f,46.50097f,88.385704f,100.0f,99.50781f,0.90178597f,44.47864f,-0.14203241f,0.98964584f,-0.020687072f ) ;
  }

  @Test
  public void test54() {
    TestDrivers.rayTrace(-23.35441f,23.547686f,-98.04184f,-96.65531f,-81.22695f,-77.87473f,-47.744263f,-1.6280977f,3.3220296f,-2.6131432f ) ;
  }

  @Test
  public void test55() {
    TestDrivers.rayTrace(24.328312f,43.701447f,37.901848f,-47.040215f,-27.063763f,-45.441982f,40.15356f,-16.561613f,-46.25521f,24.601406f ) ;
  }

  @Test
  public void test56() {
    TestDrivers.rayTrace(25.53335f,-68.0098f,-4.0630083f,40.314846f,-12.498975f,-46.466633f,-10.658489f,0.11516297f,-0.26860908f,0.79995346f ) ;
  }

  @Test
  public void test57() {
    TestDrivers.rayTrace(28.738636f,-25.007925f,94.45001f,43.82154f,41.596127f,-30.007738f,14.96802f,0.051870715f,0.56020385f,0.8267291f ) ;
  }

  @Test
  public void test58() {
    TestDrivers.rayTrace(29.578506f,48.779835f,-88.06539f,-67.656265f,76.267105f,11.604107f,-68.52869f,-94.14113f,-22.791275f,15.142949f ) ;
  }

  @Test
  public void test59() {
    TestDrivers.rayTrace(30.510569f,-93.8053f,12.59571f,-100.0f,-69.11847f,-100.0f,6.6223907f,0.4830007f,0.8314773f,-0.27451015f ) ;
  }

  @Test
  public void test60() {
    TestDrivers.rayTrace(-30.701933f,-100.0f,84.88009f,-55.55704f,-98.82733f,-100.0f,73.73613f,-0.5132473f,-0.6678592f,-0.5390188f ) ;
  }

  @Test
  public void test61() {
    TestDrivers.rayTrace(31.591413f,-100.0f,-23.228203f,100.0f,81.562744f,37.64223f,-4.123139f,-0.68718916f,-0.29153195f,0.6654173f ) ;
  }

  @Test
  public void test62() {
    TestDrivers.rayTrace(-31.97006f,-8.158229f,-31.094236f,100.0f,-43.00693f,-100.0f,-53.141716f,-0.82268304f,-0.09863429f,-0.55987847f ) ;
  }

  @Test
  public void test63() {
    TestDrivers.rayTrace(-33.73917f,32.946243f,8.436887f,63.258923f,-62.11258f,-21.298021f,-7.50679f,94.379616f,-63.600536f,48.93843f ) ;
  }

  @Test
  public void test64() {
    TestDrivers.rayTrace(34.465008f,77.647224f,31.615982f,11.266524f,5.251147f,28.628563f,26.09637f,2.7814493f,3.0936005f,0.57531035f ) ;
  }

  @Test
  public void test65() {
    TestDrivers.rayTrace(-3.494582f,100.0f,68.467964f,-42.416218f,-29.007288f,88.64482f,-0.72002083f,-0.18288077f,0.43024498f,0.88399315f ) ;
  }

  @Test
  public void test66() {
    TestDrivers.rayTrace(-36.49841f,100.0f,-94.89895f,57.902386f,18.280487f,23.276915f,-28.19839f,-0.20853211f,-0.01775396f,-0.9778544f ) ;
  }

  @Test
  public void test67() {
    TestDrivers.rayTrace(36.90573f,-40.04952f,-63.217655f,35.816605f,-40.309208f,-77.39492f,-65.931885f,5.3756266f,3.2988226f,3.056702f ) ;
  }

  @Test
  public void test68() {
    TestDrivers.rayTrace(37.149406f,74.32674f,-66.32432f,-75.55317f,67.75428f,-31.511604f,0.32064128f,55.224514f,-63.618984f,82.40758f ) ;
  }

  @Test
  public void test69() {
    TestDrivers.rayTrace(37.8265f,27.67546f,-9.358382f,49.38898f,-11.194874f,22.786512f,34.252033f,0.5464935f,0.21074335f,0.06919219f ) ;
  }

  @Test
  public void test70() {
    TestDrivers.rayTrace(38.08593f,-82.63932f,45.122757f,-76.72488f,-4.1794147f,-25.83277f,74.67597f,0.9768001f,-0.9609175f,0.012460321f ) ;
  }

  @Test
  public void test71() {
    TestDrivers.rayTrace(-3.9782643f,100.0f,99.70869f,-99.11609f,-95.542694f,99.9987f,-100.0f,-0.018911619f,-0.017576901f,-0.99966663f ) ;
  }

  @Test
  public void test72() {
    TestDrivers.rayTrace(-41.80301f,-100.0f,99.99942f,44.625587f,6.3004f,-87.70316f,99.999245f,0.46599787f,-0.052950475f,0.8832f ) ;
  }

  @Test
  public void test73() {
    TestDrivers.rayTrace(42.074726f,-95.185585f,-96.42843f,-70.64238f,13.704668f,-79.36755f,-28.832989f,0.39639735f,-0.9180733f,0.0032557063f ) ;
  }

  @Test
  public void test74() {
    TestDrivers.rayTrace(-42.13921f,-4.3871574f,27.355057f,33.23601f,-3.713729f,-22.415457f,-11.299533f,12.641715f,-48.77111f,-96.332405f ) ;
  }

  @Test
  public void test75() {
    TestDrivers.rayTrace(-42.325203f,-15.192047f,48.281868f,1.6429361f,-45.911263f,-51.08151f,-57.02169f,51.386086f,-53.907642f,-21.766075f ) ;
  }

  @Test
  public void test76() {
    TestDrivers.rayTrace(-42.845036f,-99.05753f,98.785706f,-56.57122f,14.365257f,-98.75236f,100.0f,-0.16822249f,0.8285891f,0.53398633f ) ;
  }

  @Test
  public void test77() {
    TestDrivers.rayTrace(44.474606f,-29.878967f,-36.492344f,-55.209766f,-63.82943f,-39.79181f,91.96952f,44.82399f,23.12584f,-8.173431f ) ;
  }

  @Test
  public void test78() {
    TestDrivers.rayTrace(-44.989433f,-70.27798f,99.527016f,-56.526783f,51.406303f,-16.75055f,59.99843f,-0.4042686f,0.5492462f,0.73136556f ) ;
  }

  @Test
  public void test79() {
    TestDrivers.rayTrace(-45.095627f,91.89946f,-69.6174f,98.89963f,-74.34069f,14.374033f,-99.99877f,0.17198105f,-0.11910879f,0.977873f ) ;
  }

  @Test
  public void test80() {
    TestDrivers.rayTrace(46.00824f,-13.888979f,-14.843495f,-25.5182f,24.416994f,-44.947342f,3.3089197f,-0.14628567f,1.1196806f,-0.83673733f ) ;
  }

  @Test
  public void test81() {
    TestDrivers.rayTrace(47.041332f,-43.324066f,-7.8572893f,-46.373547f,-21.216736f,-30.950735f,36.259678f,6.7253976f,-1.2018598f,0.22467685f ) ;
  }

  @Test
  public void test82() {
    TestDrivers.rayTrace(47.21567f,-16.695782f,63.09072f,-60.466297f,78.631134f,-94.71255f,-13.309592f,-0.4697906f,0.34136638f,-0.19312353f ) ;
  }

  @Test
  public void test83() {
    TestDrivers.rayTrace(-51.185776f,-37.44285f,-74.57308f,-46.066196f,-59.015774f,-69.68675f,-44.454975f,-52.119488f,96.17385f,-92.910225f ) ;
  }

  @Test
  public void test84() {
    TestDrivers.rayTrace(-52.39278f,78.11738f,71.78602f,-24.816643f,-53.77997f,80.573814f,29.007187f,-21.234415f,52.11432f,91.38369f ) ;
  }

  @Test
  public void test85() {
    TestDrivers.rayTrace(-52.440613f,60.132557f,-70.85894f,99.50285f,-1.5114465f,13.196839f,-18.307014f,81.55687f,2.0040722f,-67.00911f ) ;
  }

  @Test
  public void test86() {
    TestDrivers.rayTrace(52.586525f,13.000143f,12.36998f,88.057976f,54.949886f,83.500534f,19.687243f,-43.06376f,83.64267f,-93.570786f ) ;
  }

  @Test
  public void test87() {
    TestDrivers.rayTrace(54.30823f,45.22995f,99.167015f,48.991768f,100.0f,26.89134f,98.71676f,0.72267216f,1.3791591f,0.13819581f ) ;
  }

  @Test
  public void test88() {
    TestDrivers.rayTrace(54.594776f,-73.76137f,-12.520045f,-42.07605f,78.60175f,-42.039524f,-28.558977f,-54.541832f,71.46295f,12.534874f ) ;
  }

  @Test
  public void test89() {
    TestDrivers.rayTrace(-5.492112f,-52.375244f,1.3506882f,-61.892277f,-14.749266f,-79.85429f,-85.50624f,-61.357536f,62.83599f,77.84263f ) ;
  }

  @Test
  public void test90() {
    TestDrivers.rayTrace(-55.210693f,-84.61241f,24.22566f,-45.966873f,-75.234604f,-46.429222f,8.287008f,14.503604f,36.380054f,68.93792f ) ;
  }

  @Test
  public void test91() {
    TestDrivers.rayTrace(-55.695965f,10.697978f,-40.368717f,-71.87408f,-1.8274837f,11.866153f,7.199178f,-0.47965986f,-0.30112845f,-0.6472096f ) ;
  }

  @Test
  public void test92() {
    TestDrivers.rayTrace(-56.246025f,67.60114f,-73.7158f,-39.341393f,-76.285286f,78.39103f,-70.08292f,-0.35982242f,0.69959605f,-0.5432031f ) ;
  }

  @Test
  public void test93() {
    TestDrivers.rayTrace(-57.168884f,98.85664f,-99.885216f,-45.50562f,-93.05858f,70.82557f,-99.99998f,0.10332278f,-0.1907283f,-0.9761901f ) ;
  }

  @Test
  public void test94() {
    TestDrivers.rayTrace(-57.697018f,-45.05317f,-90.70215f,-16.275713f,27.029896f,26.462246f,61.167038f,-0.9007478f,-0.19808832f,0.32934713f ) ;
  }

  @Test
  public void test95() {
    TestDrivers.rayTrace(57.841328f,-65.01291f,13.9830265f,-61.91948f,-40.68044f,19.40757f,61.408157f,97.993164f,-39.798244f,-0.98841065f ) ;
  }

  @Test
  public void test96() {
    TestDrivers.rayTrace(-5.907412f,-13.645959f,-82.83996f,-81.58177f,-26.121439f,-65.01034f,-60.87627f,-54.083237f,48.02489f,9.341034f ) ;
  }

  @Test
  public void test97() {
    TestDrivers.rayTrace(59.190308f,-100.0f,24.797617f,100.0f,-61.927036f,100.0f,43.738754f,0.1196963f,0.80055815f,0.58717924f ) ;
  }

  @Test
  public void test98() {
    TestDrivers.rayTrace(-60.411007f,-31.900497f,-88.9571f,-10.521188f,-3.9332674f,69.19637f,-6.6381617f,92.73742f,-38.41894f,-28.927513f ) ;
  }

  @Test
  public void test99() {
    TestDrivers.rayTrace(60.571346f,-21.9907f,-42.910606f,36.50048f,54.822186f,-51.249733f,-11.8787365f,89.29304f,30.194317f,-39.60442f ) ;
  }

  @Test
  public void test100() {
    TestDrivers.rayTrace(60.76338f,70.98549f,54.25635f,-77.3119f,61.475433f,34.95971f,-5.396268f,33.26549f,24.383677f,-65.521355f ) ;
  }

  @Test
  public void test101() {
    TestDrivers.rayTrace(-62.334232f,73.667206f,96.84588f,33.06506f,-46.806362f,45.442917f,86.33558f,73.21424f,57.998646f,19.709791f ) ;
  }

  @Test
  public void test102() {
    TestDrivers.rayTrace(63.874565f,-53.28742f,-48.882397f,68.54893f,25.558521f,-4.0156007f,-31.70092f,-0.1834762f,-0.14973177f,0.35200298f ) ;
  }

  @Test
  public void test103() {
    TestDrivers.rayTrace(-63.874985f,-90.733345f,-25.836105f,18.226828f,14.126131f,-4.764065f,65.26831f,-71.28266f,-58.618565f,-80.601654f ) ;
  }

  @Test
  public void test104() {
    TestDrivers.rayTrace(63.889656f,21.717583f,-100.0f,-79.85475f,100.0f,100.0f,-100.0f,0.61555696f,0.10526563f,0.13452385f ) ;
  }

  @Test
  public void test105() {
    TestDrivers.rayTrace(65.183136f,23.049482f,13.97337f,-3.9876554f,46.65475f,78.947044f,-23.12295f,-0.55954933f,0.7273062f,-0.15648161f ) ;
  }

  @Test
  public void test106() {
    TestDrivers.rayTrace(66.08075f,-38.016193f,-37.28488f,82.54287f,15.295196f,-8.725495f,5.52539f,-0.2707674f,0.89783245f,0.33501953f ) ;
  }

  @Test
  public void test107() {
    TestDrivers.rayTrace(-66.29596f,-45.172604f,-85.58273f,99.974976f,28.605984f,-99.999954f,-78.95554f,3.2996642E-4f,-0.74718434f,0.6646168f ) ;
  }

  @Test
  public void test108() {
    TestDrivers.rayTrace(66.75572f,87.03222f,-100.0f,18.822094f,68.25562f,80.34911f,-82.38991f,-0.66734105f,1.5922744f,0.8422669f ) ;
  }

  @Test
  public void test109() {
    TestDrivers.rayTrace(67.84588f,-85.851395f,-28.851921f,-92.901566f,55.42919f,48.58138f,24.533278f,0.5686651f,-0.8122396f,-0.12994967f ) ;
  }

  @Test
  public void test110() {
    TestDrivers.rayTrace(-68.17323f,-13.579182f,-41.3979f,-34.75564f,-65.477684f,-83.49265f,52.97353f,-85.06816f,34.234837f,65.070946f ) ;
  }

  @Test
  public void test111() {
    TestDrivers.rayTrace(68.45019f,100.0f,22.560438f,100.0f,-25.427666f,18.830744f,73.0727f,-0.5330562f,-0.59337485f,-0.21874298f ) ;
  }

  @Test
  public void test112() {
    TestDrivers.rayTrace(68.79516f,63.48764f,-80.33248f,-45.76888f,40.529602f,69.15218f,-65.037926f,-0.17832495f,-0.13850676f,-0.68515575f ) ;
  }

  @Test
  public void test113() {
    TestDrivers.rayTrace(69.95521f,-21.868294f,-47.20442f,100.0f,24.780079f,22.924196f,17.64084f,-0.44669414f,-0.4454926f,-0.5853069f ) ;
  }

  @Test
  public void test114() {
    TestDrivers.rayTrace(70.222824f,61.340946f,-25.930765f,-67.09848f,26.50123f,44.7219f,30.820063f,0.012302119f,0.97077227f,-0.23968694f ) ;
  }

  @Test
  public void test115() {
    TestDrivers.rayTrace(-72.45694f,-41.840717f,76.92794f,-51.15151f,-72.44442f,46.998573f,-100.0f,0.09438324f,0.16099428f,0.029468311f ) ;
  }

  @Test
  public void test116() {
    TestDrivers.rayTrace(-7.275327f,54.039833f,-59.031483f,36.608208f,-77.43154f,9.760053f,0.43084276f,-0.21441492f,-0.58501995f,-0.39679387f ) ;
  }

  @Test
  public void test117() {
    TestDrivers.rayTrace(75.01337f,25.826233f,-14.6808605f,48.434654f,-73.46616f,24.134521f,45.655807f,-25.91643f,43.39929f,-72.513504f ) ;
  }

  @Test
  public void test118() {
    TestDrivers.rayTrace(-76.165115f,-61.565178f,45.487133f,41.667835f,-69.43943f,96.0002f,-53.99099f,7.8099823f,-98.48837f,95.21621f ) ;
  }

  @Test
  public void test119() {
    TestDrivers.rayTrace(-76.310905f,-100.0f,-100.0f,-99.53775f,100.0f,-99.64902f,-1.2912009f,-1.7211359f,-0.71075416f,-2.5541015f ) ;
  }

  @Test
  public void test120() {
    TestDrivers.rayTrace(76.366486f,-21.505316f,-26.976719f,71.759995f,100.0f,-90.776474f,-51.611675f,1.3003739f,-1.0596507f,1.5675342f ) ;
  }

  @Test
  public void test121() {
    TestDrivers.rayTrace(-76.723114f,-20.942621f,-57.57399f,-74.34875f,-77.824196f,78.49732f,-49.272934f,92.43463f,56.85998f,-2.2430303f ) ;
  }

  @Test
  public void test122() {
    TestDrivers.rayTrace(-76.73289f,-98.67994f,77.846436f,97.80703f,-98.756836f,-89.07014f,78.59784f,-0.9219988f,-0.32615557f,0.20866428f ) ;
  }

  @Test
  public void test123() {
    TestDrivers.rayTrace(77.51276f,90.515045f,61.746605f,-24.459633f,100.0f,100.0f,68.82055f,2.2483351f,-2.3135092f,-0.80813557f ) ;
  }

  @Test
  public void test124() {
    TestDrivers.rayTrace(77.618515f,55.461697f,-64.4825f,-43.54867f,80.14977f,30.086138f,-100.0f,0.9213738f,2.294922f,-1.9191276f ) ;
  }

  @Test
  public void test125() {
    TestDrivers.rayTrace(-7.8250327f,-91.368614f,-62.0112f,21.905138f,-64.222275f,-65.80495f,34.38889f,-27.089458f,26.235235f,71.588234f ) ;
  }

  @Test
  public void test126() {
    TestDrivers.rayTrace(7.860937f,-100.0f,-1.5967251f,100.0f,-16.261068f,55.19511f,48.932312f,0.6648418f,-0.21429402f,-0.7155861f ) ;
  }

  @Test
  public void test127() {
    TestDrivers.rayTrace(78.84063f,56.017353f,30.581919f,-96.69754f,99.03163f,72.32406f,89.23684f,0.6837391f,-0.4059727f,0.5816197f ) ;
  }

  @Test
  public void test128() {
    TestDrivers.rayTrace(79.26666f,43.06797f,-67.09935f,-98.41555f,100.0f,-6.922345f,45.149063f,-8.490877f,-4.7711525f,-10.122379f ) ;
  }

  @Test
  public void test129() {
    TestDrivers.rayTrace(79.56805f,99.99878f,20.602932f,72.62284f,96.11866f,81.31934f,88.80289f,-0.65159714f,0.46183088f,-0.6017752f ) ;
  }

  @Test
  public void test130() {
    TestDrivers.rayTrace(79.76551f,95.1505f,16.908363f,-66.54523f,91.77686f,47.888153f,-25.618374f,64.49794f,86.08921f,46.055325f ) ;
  }

  @Test
  public void test131() {
    TestDrivers.rayTrace(80.483734f,78.751526f,13.0355625f,-23.284952f,53.06136f,21.008163f,71.16383f,75.19716f,5.051514f,30.737574f ) ;
  }

  @Test
  public void test132() {
    TestDrivers.rayTrace(86.169586f,-58.56756f,-23.653202f,80.40809f,16.918797f,11.823453f,10.508089f,6.1511664f,0.97610205f,-3.4209547f ) ;
  }

  @Test
  public void test133() {
    TestDrivers.rayTrace(-86.626236f,-22.782015f,2.7849178f,-80.60687f,-46.89247f,8.463659f,-49.39892f,-0.14648876f,0.3343781f,0.017473515f ) ;
  }

  @Test
  public void test134() {
    TestDrivers.rayTrace(-89.19177f,9.358678f,6.92686f,33.842957f,17.116762f,-31.883533f,50.68913f,-0.15295699f,-0.05871891f,-0.0071781734f ) ;
  }

  @Test
  public void test135() {
    TestDrivers.rayTrace(-91.57909f,-20.557137f,7.78994f,57.528133f,22.450628f,-38.96358f,-10.09712f,0.94089335f,0.33672905f,-0.036514133f ) ;
  }

  @Test
  public void test136() {
    TestDrivers.rayTrace(92.79303f,-74.28971f,-7.538107f,99.36739f,29.210415f,56.625652f,-20.19454f,0.03742832f,-0.049560733f,-0.9099491f ) ;
  }

  @Test
  public void test137() {
    TestDrivers.rayTrace(9.541454f,7.9979253f,17.915556f,-45.014187f,-60.283672f,-81.00161f,-57.05164f,-0.2665838f,-0.2258769f,0.048419897f ) ;
  }

  @Test
  public void test138() {
    TestDrivers.rayTrace(9.626459f,-52.89347f,-41.087997f,-99.91238f,-100.0f,-46.977932f,-51.55098f,-0.5089614f,-0.01708894f,0.8606197f ) ;
  }

  @Test
  public void test139() {
    TestDrivers.rayTrace(-97.59167f,33.91218f,-121.74045f,100.0f,-182.18674f,154.49411f,-41.738544f,0.10944004f,0.83465385f,0.53979236f ) ;
  }

  @Test
  public void test140() {
    TestDrivers.rayTrace(97.83383f,18.758352f,-100.0f,-91.25213f,92.88162f,-39.914085f,-20.274082f,0.5406517f,-0.8357388f,-0.0961067f ) ;
  }

  @Test
  public void test141() {
    TestDrivers.rayTrace(98.21324f,-98.77668f,100.0f,99.98922f,100.0f,53.857388f,99.99779f,0.5459094f,-0.762026f,0.34828037f ) ;
  }

  @Test
  public void test142() {
    TestDrivers.rayTrace(-98.45618f,100.0f,-37.126564f,-16.46324f,-100.0f,100.0f,-3.016342f,0.29395238f,0.40945217f,-0.8636787f ) ;
  }

  @Test
  public void test143() {
    TestDrivers.rayTrace(-99.17642f,-100.0f,-100.0f,100.0f,98.5333f,-92.35306f,-34.585773f,-0.77582747f,0.16581203f,-0.6087677f ) ;
  }

  @Test
  public void test144() {
    TestDrivers.rayTrace(-99.46517f,-88.96678f,99.43359f,-43.92524f,100.0f,-30.73131f,-59.95213f,-0.75936925f,-0.059690468f,0.6479162f ) ;
  }

  @Test
  public void test145() {
    TestDrivers.rayTrace(99.68861f,-53.0547f,-40.03144f,-100.0f,30.692999f,-19.345245f,24.025404f,0.42202812f,0.2189414f,-0.8797482f ) ;
  }

  @Test
  public void test146() {
    TestDrivers.rayTrace(-99.88084f,26.550768f,88.37072f,99.88169f,12.330965f,7.9674087f,-99.72695f,0.60717344f,0.60419065f,-0.51603687f ) ;
  }

  @Test
  public void test147() {
    TestDrivers.rayTrace(99.882256f,-100.0f,30.861847f,-99.99671f,-41.085106f,85.33218f,-99.95643f,-7.1271844f,4.0550838f,-3.3298934f ) ;
  }

  @Test
  public void test148() {
    TestDrivers.rayTrace(-99.884026f,-2.0744128f,-10.593075f,-100.0f,-100.0f,-80.27151f,51.738304f,-0.69613343f,0.59334576f,-0.40415224f ) ;
  }

  @Test
  public void test149() {
    TestDrivers.rayTrace(-99.999504f,-79.657295f,100.0f,92.34251f,-100.0f,54.273952f,-100.0f,-0.9770588f,0.097192414f,0.18949863f ) ;
  }

  @Test
  public void test150() {
    TestDrivers.rayTrace(99.999916f,-16.139906f,-100.0f,-93.81188f,57.949333f,-99.99942f,-100.0f,0.7963685f,-0.06730032f,-0.6010557f ) ;
  }

  @Test
  public void test151() {
    TestDrivers.rayTrace(99.9999f,100.0f,-100.0f,-94.34456f,-56.928085f,99.98702f,12.84685f,0.70554996f,0.229872f,-0.6703418f ) ;
  }
}
