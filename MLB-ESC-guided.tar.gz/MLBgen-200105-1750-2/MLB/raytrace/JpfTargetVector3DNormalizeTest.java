import org.junit.Test;

public class JpfTargetVector3DNormalizeTest {

  @Test
  public void test0() {
    TestDrivers.vector3DNormalize(0.014201487f,-0.9105468f,0.41316205f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.vector3DNormalize(0.025320752f,-0.27146646f,0.96211475f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.vector3DNormalize(-0.3045263f,-0.92424583f,0.23028983f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.vector3DNormalize(-0.59635735f,-0.38038245f,0.6610097f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.vector3DNormalize(0.60776323f,0.3266363f,-0.32080594f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.vector3DNormalize(-12.128963f,96.49233f,-88.8156f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.vector3DNormalize(2.592702E-9f,1.8289132E-9f,-8.65712E-9f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.vector3DNormalize(2.7976313E-7f,1.5942278E-7f,3.8865264E-7f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.vector3DNormalize(-2.8715035E-9f,3.582626E-10f,5.070254E-9f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.vector3DNormalize(-2.9613577E-6f,-3.0805452E-7f,1.4083179E-6f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.vector3DNormalize(3.1279968E-11f,-2.8607154E-12f,2.34775E-10f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.vector3DNormalize(3.5181583E-4f,-0.0017153852f,0.0017668733f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.vector3DNormalize(-5.960682E-14f,-6.545007E-15f,2.7140575E-14f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.vector3DNormalize(-6.6975244E-23f,2.9063032E-22f,-3.854032E-23f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.vector3DNormalize(-68.68318f,-72.99416f,43.603798f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.vector3DNormalize(8.633198E-6f,-4.3975015E-5f,1.0180538E-4f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.vector3DNormalize(92.36889f,55.476723f,-10.186474f ) ;
  }
}
