import org.junit.Test;

public class JpfTargetCollision2Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision2(-473,-306,-420,376 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision2(-862,-633,166,460 ) ;
  }
}
