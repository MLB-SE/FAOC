import org.junit.Test;

public class JpfTargetCollision1Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision1(-267,737,-880,-143,388,-708 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision1(772,-1587,188,800,-722,95 ) ;
  }
}
