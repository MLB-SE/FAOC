import org.junit.Test;

public class JpfTargetCollision5Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision5(2,-24989 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision5(38,-36098 ) ;
  }

  @Test
  public void test2() {
    EffectiveJavaHashCode.testCollision5(-795,76 ) ;
  }
}
