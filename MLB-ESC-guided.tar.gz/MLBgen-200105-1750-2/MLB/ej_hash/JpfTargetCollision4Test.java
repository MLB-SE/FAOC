import org.junit.Test;

public class JpfTargetCollision4Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision4(-25645,130,628 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision4(-36283,14,-268 ) ;
  }

  @Test
  public void test2() {
    EffectiveJavaHashCode.testCollision4(535,845,-832 ) ;
  }

  @Test
  public void test3() {
    EffectiveJavaHashCode.testCollision4(-54311,377,758 ) ;
  }
}
