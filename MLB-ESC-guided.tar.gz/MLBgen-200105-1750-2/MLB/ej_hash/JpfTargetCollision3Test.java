import org.junit.Test;

public class JpfTargetCollision3Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision3(26164,358 ) ;
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision3(37345,198 ) ;
  }

  @Test
  public void test2() {
    EffectiveJavaHashCode.testCollision3(-531,-14 ) ;
  }
}
