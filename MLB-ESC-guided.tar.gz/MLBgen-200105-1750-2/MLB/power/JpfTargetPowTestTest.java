import org.junit.Test;

public class JpfTargetPowTestTest {

  @Test
  public void test0() {
    concolic.PowExample.test(1,1 ) ;
  }

  @Test
  public void test1() {
    concolic.PowExample.test(19,361 ) ;
  }

  @Test
  public void test2() {
    concolic.PowExample.test(211,121 ) ;
  }

  @Test
  public void test3() {
    concolic.PowExample.test(-310,0 ) ;
  }

  @Test
  public void test4() {
    concolic.PowExample.test(332,74 ) ;
  }

  @Test
  public void test5() {
    concolic.PowExample.test(34,1156 ) ;
  }

  @Test
  public void test6() {
    concolic.PowExample.test(500,0 ) ;
  }

  @Test
  public void test7() {
    concolic.PowExample.test(882,-127 ) ;
  }
}
