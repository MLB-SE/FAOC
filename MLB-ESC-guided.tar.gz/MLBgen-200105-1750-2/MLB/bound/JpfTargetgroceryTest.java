import org.junit.Test;

public class JpfTargetgroceryTest {

  @Test
  public void test0() {
    bound.grocery.solve(10,289,749,0 ) ;
  }

  @Test
  public void test1() {
    bound.grocery.solve(103,56,385,167 ) ;
  }

  @Test
  public void test2() {
    bound.grocery.solve(1,148,64,498 ) ;
  }

  @Test
  public void test3() {
    bound.grocery.solve(122,29,61,499 ) ;
  }

  @Test
  public void test4() {
    bound.grocery.solve(151,378,18,397 ) ;
  }

  @Test
  public void test5() {
    bound.grocery.solve(214,251,346,0 ) ;
  }

  @Test
  public void test6() {
    bound.grocery.solve(228,547,522,-766 ) ;
  }

  @Test
  public void test7() {
    bound.grocery.solve(275,184,41,211 ) ;
  }

  @Test
  public void test8() {
    bound.grocery.solve(-29,0,0,0 ) ;
  }

  @Test
  public void test9() {
    bound.grocery.solve(36,233,291,151 ) ;
  }

  @Test
  public void test10() {
    bound.grocery.solve(368,306,-630,0 ) ;
  }

  @Test
  public void test11() {
    bound.grocery.solve(47,43,126,495 ) ;
  }

  @Test
  public void test12() {
    bound.grocery.solve(48,315,0,0 ) ;
  }

  @Test
  public void test13() {
    bound.grocery.solve(496,172,40,3 ) ;
  }

  @Test
  public void test14() {
    bound.grocery.solve(507,137,629,938 ) ;
  }

  @Test
  public void test15() {
    bound.grocery.solve(526,-724,0,0 ) ;
  }

  @Test
  public void test16() {
    bound.grocery.solve(554,149,56,836 ) ;
  }

  @Test
  public void test17() {
    bound.grocery.solve(569,741,0,0 ) ;
  }

  @Test
  public void test18() {
    bound.grocery.solve(604,314,118,142 ) ;
  }

  @Test
  public void test19() {
    bound.grocery.solve(608,0,0,0 ) ;
  }

  @Test
  public void test20() {
    bound.grocery.solve(608,711,0,0 ) ;
  }

  @Test
  public void test21() {
    bound.grocery.solve(628,659,571,0 ) ;
  }

  @Test
  public void test22() {
    bound.grocery.solve(67,96,27,521 ) ;
  }

  @Test
  public void test23() {
    bound.grocery.solve(852,0,0,0 ) ;
  }

  @Test
  public void test24() {
    bound.grocery.solve(875,0,0,0 ) ;
  }

  @Test
  public void test25() {
    bound.grocery.solve(98,367,183,63 ) ;
  }
}
