import org.junit.Test;

public class TestbetacfTest {

  @Test
  public void test0() {
    beta.betacf(100.0,-18.78992321820921,1.2436880249649827 ) ;
  }

  @Test
  public void test1() {
    beta.betacf(-24.824204575640522,16.280427227158697,2.788486123163536 ) ;
  }

  @Test
  public void test2() {
    beta.betacf(-43.237178317158154,42.65240984212947,72.22889078465884 ) ;
  }

  @Test
  public void test3() {
    beta.betacf(-45.95865292257795,0,0 ) ;
  }

  @Test
  public void test4() {
    beta.betacf(-47.269846832197175,-2.2086249934436495,-99.54767982466737 ) ;
  }

  @Test
  public void test5() {
    beta.betacf(-51.85174983614505,51.047424427482845,63.22285643160776 ) ;
  }

  @Test
  public void test6() {
    beta.betacf(-53.272971936712,54.352430677510256,-48.42516898613112 ) ;
  }

  @Test
  public void test7() {
    beta.betacf(-5.7435530382741575,0,0 ) ;
  }

  @Test
  public void test8() {
    beta.betacf(-58.98639612960582,51.59748998574083,7.847764608263688 ) ;
  }

  @Test
  public void test9() {
    beta.betacf(-60.57762226404439,73.40410723570713,-11.621459635251568 ) ;
  }

  @Test
  public void test10() {
    beta.betacf(-63.23753302739892,69.29230979380142,-10.279079713186167 ) ;
  }

  @Test
  public void test11() {
    beta.betacf(64.05425135432702,-14.346579080477298,-8.273904875203186 ) ;
  }

  @Test
  public void test12() {
    beta.betacf(65.56891135529625,64.7551337155924,25.868759928586087 ) ;
  }

  @Test
  public void test13() {
    beta.betacf(-68.195021902336,73.69820104176421,-12.210218893459034 ) ;
  }

  @Test
  public void test14() {
    beta.betacf(-72.04846320964553,69.70536064845089,30.322387242588803 ) ;
  }

  @Test
  public void test15() {
    beta.betacf(79.8562323594785,-16.484793113124695,1.2759096735226936 ) ;
  }

  @Test
  public void test16() {
    beta.betacf(97.4320237713987,-94.39295369047132,32.3888627607303 ) ;
  }

  @Test
  public void test17() {
    beta.betacf(98.26409657457489,-96.92688794260812,74.2323181301759 ) ;
  }
}
