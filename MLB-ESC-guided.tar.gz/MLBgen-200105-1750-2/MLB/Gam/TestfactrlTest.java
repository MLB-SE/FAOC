import org.junit.Test;

public class TestfactrlTest {

  @Test
  public void test0() {
    gam.factrl(0 ) ;
  }

  @Test
  public void test1() {
    gam.factrl(-1 ) ;
  }

  @Test
  public void test2() {
    gam.factrl(11 ) ;
  }

  @Test
  public void test3() {
    gam.factrl(18 ) ;
  }

  @Test
  public void test4() {
    gam.factrl(377 ) ;
  }

  @Test
  public void test5() {
    gam.factrl(-417 ) ;
  }

  @Test
  public void test6() {
    gam.factrl(-466 ) ;
  }

  @Test
  public void test7() {
    gam.factrl(5 ) ;
  }

  @Test
  public void test8() {
    gam.factrl(789 ) ;
  }

  @Test
  public void test9() {
    gam.factrl(-888 ) ;
  }

  @Test
  public void test10() {
    gam.factrl(952 ) ;
  }
}
