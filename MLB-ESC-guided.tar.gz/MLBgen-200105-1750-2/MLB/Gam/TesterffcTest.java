import org.junit.Test;

public class TesterffcTest {

  @Test
  public void test0() {
    gam.erffc(0.7600207412857838 ) ;
  }

  @Test
  public void test1() {
    gam.erffc(0.7695065457348278 ) ;
  }

  @Test
  public void test2() {
    gam.erffc(0.9943635447670202 ) ;
  }

  @Test
  public void test3() {
    gam.erffc(-1.224744871391589 ) ;
  }

  @Test
  public void test4() {
    gam.erffc(1.224744871391589 ) ;
  }

  @Test
  public void test5() {
    gam.erffc(1.351743106633279 ) ;
  }

  @Test
  public void test6() {
    gam.erffc(-2.220446049250313E-16 ) ;
  }

  @Test
  public void test7() {
    gam.erffc(-25.113250957956552 ) ;
  }

  @Test
  public void test8() {
    gam.erffc(2.5269841324701218E-175 ) ;
  }

  @Test
  public void test9() {
    gam.erffc(-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test10() {
    gam.erffc(29.812249806619263 ) ;
  }

  @Test
  public void test11() {
    gam.erffc(31.97117562210252 ) ;
  }

  @Test
  public void test12() {
    gam.erffc(-3.944304526105059E-31 ) ;
  }

  @Test
  public void test13() {
    gam.erffc(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test14() {
    gam.erffc(4.440892098500626E-16 ) ;
  }

  @Test
  public void test15() {
    gam.erffc(-5.0539682649402436E-175 ) ;
  }

  @Test
  public void test16() {
    gam.erffc(-5.551115123125783E-17 ) ;
  }

  @Test
  public void test17() {
    gam.erffc(-63.86826676244035 ) ;
  }

  @Test
  public void test18() {
    gam.erffc(-69.88596736762338 ) ;
  }

  @Test
  public void test19() {
    gam.erffc(7.703719777548943E-34 ) ;
  }

  @Test
  public void test20() {
    gam.erffc(8.673617379884035E-19 ) ;
  }
}
