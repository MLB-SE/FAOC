import org.junit.Test;

public class TestbetaiTest {

  @Test
  public void test0() {
    beta.betai(0,0,0.04539887965971445 ) ;
  }

  @Test
  public void test1() {
    beta.betai(0,0,0.9988221822090643 ) ;
  }

  @Test
  public void test2() {
    beta.betai(0,0,0.9999999999999908 ) ;
  }

  @Test
  public void test3() {
    beta.betai(0,0,0.9999999999999996 ) ;
  }

  @Test
  public void test4() {
    beta.betai(0,0,1.0 ) ;
  }

  @Test
  public void test5() {
    beta.betai(0,0,1.0000000000000002 ) ;
  }

  @Test
  public void test6() {
    beta.betai(0,0,1.0002587831198084 ) ;
  }

  @Test
  public void test7() {
    beta.betai(0,0,1.000342462966116 ) ;
  }

  @Test
  public void test8() {
    beta.betai(0,0,1.000482286457485 ) ;
  }

  @Test
  public void test9() {
    beta.betai(0,0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test10() {
    beta.betai(0,0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test11() {
    beta.betai(0,0,-12.623641931068178 ) ;
  }

  @Test
  public void test12() {
    beta.betai(0,0,2.220446049250313E-16 ) ;
  }

  @Test
  public void test13() {
    beta.betai(0,0,28.598509893465717 ) ;
  }

  @Test
  public void test14() {
    beta.betai(0,0,30.24883181280876 ) ;
  }

  @Test
  public void test15() {
    beta.betai(0,0,3.0385816786431356E-64 ) ;
  }

  @Test
  public void test16() {
    beta.betai(0,0,3.469446951953614E-18 ) ;
  }

  @Test
  public void test17() {
    beta.betai(0,0,-4.146077058764803 ) ;
  }

  @Test
  public void test18() {
    beta.betai(0,0,5.716881082518327 ) ;
  }

  @Test
  public void test19() {
    beta.betai(0,0,-6.162975822039155E-33 ) ;
  }

  @Test
  public void test20() {
    beta.betai(0,0,6.805973127861819 ) ;
  }

  @Test
  public void test21() {
    beta.betai(0,0,-74.87422490294713 ) ;
  }

  @Test
  public void test22() {
    beta.betai(0,0,77.39342693576887 ) ;
  }

  @Test
  public void test23() {
    beta.betai(0,0,8.226127333267314 ) ;
  }

  @Test
  public void test24() {
    beta.betai(0,0,-85.88416438072322 ) ;
  }

  @Test
  public void test25() {
    beta.betai(0,0,8.673617379884035E-19 ) ;
  }
}
