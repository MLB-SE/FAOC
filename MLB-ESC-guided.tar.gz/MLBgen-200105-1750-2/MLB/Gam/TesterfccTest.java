import org.junit.Test;

public class TesterfccTest {

  @Test
  public void test0() {
    erf.erfcc(0.6550812164935991 ) ;
  }

  @Test
  public void test1() {
    erf.erfcc(1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2() {
    erf.erfcc(1.14E-322 ) ;
  }

  @Test
  public void test3() {
    erf.erfcc(1.301002908427762 ) ;
  }

  @Test
  public void test4() {
    erf.erfcc(1.6942847225509325 ) ;
  }

  @Test
  public void test5() {
    erf.erfcc(-2.220446049250313E-16 ) ;
  }

  @Test
  public void test6() {
    erf.erfcc(23.69048248360957 ) ;
  }

  @Test
  public void test7() {
    erf.erfcc(2.465190328815662E-32 ) ;
  }

  @Test
  public void test8() {
    erf.erfcc(-4.9E-324 ) ;
  }

  @Test
  public void test9() {
    erf.erfcc(-58.60171414125232 ) ;
  }

  @Test
  public void test10() {
    erf.erfcc(-7.09952704778938 ) ;
  }

  @Test
  public void test11() {
    erf.erfcc(-9.162991303358154 ) ;
  }

  @Test
  public void test12() {
    erf.erfcc(9.860761315262648E-32 ) ;
  }
}
