import org.junit.Test;

public class TestexpintTest {

  @Test
  public void test0() {
    expint.expint(0,0.0 ) ;
  }

  @Test
  public void test1() {
    expint.expint(0,44.56123703336834 ) ;
  }

  @Test
  public void test2() {
    expint.expint(165,1.9721522630525295E-31 ) ;
  }

  @Test
  public void test3() {
    expint.expint(195,0.0 ) ;
  }

  @Test
  public void test4() {
    expint.expint(235,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test5() {
    expint.expint(255,52.10730908135321 ) ;
  }

  @Test
  public void test6() {
    expint.expint(284,0.0 ) ;
  }

  @Test
  public void test7() {
    expint.expint(286,-2.03E-322 ) ;
  }

  @Test
  public void test8() {
    expint.expint(316,59.92582858534229 ) ;
  }

  @Test
  public void test9() {
    expint.expint(334,-2.1E-322 ) ;
  }

  @Test
  public void test10() {
    expint.expint(351,0 ) ;
  }

  @Test
  public void test11() {
    expint.expint(-377,0 ) ;
  }

  @Test
  public void test12() {
    expint.expint(431,1.58E-322 ) ;
  }

  @Test
  public void test13() {
    expint.expint(467,0.0 ) ;
  }

  @Test
  public void test14() {
    expint.expint(592,-63.815875797580325 ) ;
  }

  @Test
  public void test15() {
    expint.expint(64,94.63948742266402 ) ;
  }

  @Test
  public void test16() {
    expint.expint(715,6.4E-323 ) ;
  }

  @Test
  public void test17() {
    expint.expint(812,4.9E-324 ) ;
  }
}
