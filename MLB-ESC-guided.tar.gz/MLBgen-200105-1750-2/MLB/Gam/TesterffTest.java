import org.junit.Test;

public class TesterffTest {

  @Test
  public void test0() {
    gam.erff(-0.9145972230249844 ) ;
  }

  @Test
  public void test1() {
    gam.erff(1.0827468388607353 ) ;
  }

  @Test
  public void test2() {
    gam.erff(1.1520403074930354 ) ;
  }

  @Test
  public void test3() {
    gam.erff(-1.224744871391589 ) ;
  }

  @Test
  public void test4() {
    gam.erff(1.2247448713915892 ) ;
  }

  @Test
  public void test5() {
    gam.erff(-1.2634920662350609E-175 ) ;
  }

  @Test
  public void test6() {
    gam.erff(1.2634920662350609E-175 ) ;
  }

  @Test
  public void test7() {
    gam.erff(-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test8() {
    gam.erff(1.7763568394002505E-15 ) ;
  }

  @Test
  public void test9() {
    gam.erff(20.061670072648923 ) ;
  }

  @Test
  public void test10() {
    gam.erff(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test11() {
    gam.erff(-45.01559852562165 ) ;
  }

  @Test
  public void test12() {
    gam.erff(-64.09575213094323 ) ;
  }

  @Test
  public void test13() {
    gam.erff(74.89838603665768 ) ;
  }

  @Test
  public void test14() {
    gam.erff(7.703719777548943E-34 ) ;
  }

  @Test
  public void test15() {
    gam.erff(-7.804172013866321 ) ;
  }

  @Test
  public void test16() {
    gam.erff(88.50144837167949 ) ;
  }

  @Test
  public void test17() {
    gam.erff(8.881784197001252E-16 ) ;
  }

  @Test
  public void test18() {
    gam.erff(-96.34981225477188 ) ;
  }
}
