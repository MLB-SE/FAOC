import org.junit.Test;

public class TesteiTest {

  @Test
  public void test0() {
    expint.ei(1.0E-323 ) ;
  }

  @Test
  public void test1() {
    expint.ei(-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2() {
    expint.ei(-1.5448568520803718 ) ;
  }

  @Test
  public void test3() {
    expint.ei(-15.545980764067721 ) ;
  }

  @Test
  public void test4() {
    expint.ei(17.18817476928369 ) ;
  }

  @Test
  public void test5() {
    expint.ei(19.230861783601867 ) ;
  }

  @Test
  public void test6() {
    expint.ei(-2.051305091947313 ) ;
  }

  @Test
  public void test7() {
    expint.ei(23.181079507748507 ) ;
  }

  @Test
  public void test8() {
    expint.ei(-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test9() {
    expint.ei(-31.349070892612147 ) ;
  }

  @Test
  public void test10() {
    expint.ei(32.23619130191664 ) ;
  }

  @Test
  public void test11() {
    expint.ei(3.552713678800501E-15 ) ;
  }

  @Test
  public void test12() {
    expint.ei(4.930380657631324E-32 ) ;
  }

  @Test
  public void test13() {
    expint.ei(55.69485281281618 ) ;
  }

  @Test
  public void test14() {
    expint.ei(-68.71446725200332 ) ;
  }

  @Test
  public void test15() {
    expint.ei(74.98333538904092 ) ;
  }

  @Test
  public void test16() {
    expint.ei(9.860761315262648E-32 ) ;
  }
}
