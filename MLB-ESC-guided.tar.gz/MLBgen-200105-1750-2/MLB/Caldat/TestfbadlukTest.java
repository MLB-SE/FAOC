import org.junit.Test;

public class TestfbadlukTest {

  @Test
  public void test0() {
    caldat.badluk(0 ) ;
  }

  @Test
  public void test1() {
    caldat.badluk(-1 ) ;
  }

  @Test
  public void test2() {
    caldat.badluk(1 ) ;
  }

  @Test
  public void test3() {
    caldat.badluk(2 ) ;
  }

  @Test
  public void test4() {
    caldat.badluk(280 ) ;
  }

  @Test
  public void test5() {
    caldat.badluk(-29 ) ;
  }

  @Test
  public void test6() {
    caldat.badluk(356 ) ;
  }

  @Test
  public void test7() {
    caldat.badluk(37 ) ;
  }

  @Test
  public void test8() {
    caldat.badluk(-482 ) ;
  }

  @Test
  public void test9() {
    caldat.badluk(-540 ) ;
  }

  @Test
  public void test10() {
    caldat.badluk(-696 ) ;
  }

  @Test
  public void test11() {
    caldat.badluk(735 ) ;
  }

  @Test
  public void test12() {
    caldat.badluk(-834 ) ;
  }
}
