import org.junit.Test;

public class TestjuldayTest {

  @Test
  public void test0() {
    caldat.julday(0,0,0 ) ;
  }

  @Test
  public void test1() {
    caldat.julday(0,0,119 ) ;
  }

  @Test
  public void test2() {
    caldat.julday(0,0,-175 ) ;
  }

  @Test
  public void test3() {
    caldat.julday(0,0,-505 ) ;
  }

  @Test
  public void test4() {
    caldat.julday(0,0,677 ) ;
  }

  @Test
  public void test5() {
    caldat.julday(0,168,2344 ) ;
  }

  @Test
  public void test6() {
    caldat.julday(0,21512,0 ) ;
  }

  @Test
  public void test7() {
    caldat.julday(-1,0,0 ) ;
  }

  @Test
  public void test8() {
    caldat.julday(-101,0,1 ) ;
  }

  @Test
  public void test9() {
    caldat.julday(1,0,-552 ) ;
  }

  @Test
  public void test10() {
    caldat.julday(-1,0,-606 ) ;
  }

  @Test
  public void test11() {
    caldat.julday(1,0,785 ) ;
  }

  @Test
  public void test12() {
    caldat.julday(1,105,-442 ) ;
  }

  @Test
  public void test13() {
    caldat.julday(-11,22802,-7 ) ;
  }

  @Test
  public void test14() {
    caldat.julday(-12,-263,0 ) ;
  }

  @Test
  public void test15() {
    caldat.julday(-13,0,-1328 ) ;
  }

  @Test
  public void test16() {
    caldat.julday(-13,0,429 ) ;
  }

  @Test
  public void test17() {
    caldat.julday(-13,0,-433 ) ;
  }

  @Test
  public void test18() {
    caldat.julday(-13,0,560 ) ;
  }

  @Test
  public void test19() {
    caldat.julday(-13,1470,609 ) ;
  }

  @Test
  public void test20() {
    caldat.julday(-13,177,955 ) ;
  }

  @Test
  public void test21() {
    caldat.julday(-13,18309,4 ) ;
  }

  @Test
  public void test22() {
    caldat.julday(-13,203,-893 ) ;
  }

  @Test
  public void test23() {
    caldat.julday(-13,49458,-1 ) ;
  }

  @Test
  public void test24() {
    caldat.julday(-135,0,-869 ) ;
  }

  @Test
  public void test25() {
    caldat.julday(-13,528,-444 ) ;
  }

  @Test
  public void test26() {
    caldat.julday(-13,-530,1909 ) ;
  }

  @Test
  public void test27() {
    caldat.julday(-13,726,1740 ) ;
  }

  @Test
  public void test28() {
    caldat.julday(-1,39164,-2 ) ;
  }

  @Test
  public void test29() {
    caldat.julday(-140,877,0 ) ;
  }

  @Test
  public void test30() {
    caldat.julday(143,0,-918 ) ;
  }

  @Test
  public void test31() {
    caldat.julday(-14,48029,0 ) ;
  }

  @Test
  public void test32() {
    caldat.julday(1478,821,1904 ) ;
  }

  @Test
  public void test33() {
    caldat.julday(-1,49041,-4 ) ;
  }

  @Test
  public void test34() {
    caldat.julday(-15,48667,-1 ) ;
  }

  @Test
  public void test35() {
    caldat.julday(-167,0,-1 ) ;
  }

  @Test
  public void test36() {
    caldat.julday(-167,0,-636 ) ;
  }

  @Test
  public void test37() {
    caldat.julday(172,0,0 ) ;
  }

  @Test
  public void test38() {
    caldat.julday(-17,30078,0 ) ;
  }

  @Test
  public void test39() {
    caldat.julday(1,749,741 ) ;
  }

  @Test
  public void test40() {
    caldat.julday(-18,0,0 ) ;
  }

  @Test
  public void test41() {
    caldat.julday(182,0,0 ) ;
  }

  @Test
  public void test42() {
    caldat.julday(-18,28830,-4 ) ;
  }

  @Test
  public void test43() {
    caldat.julday(-18,31328,-1 ) ;
  }

  @Test
  public void test44() {
    caldat.julday(-184,0,-532 ) ;
  }

  @Test
  public void test45() {
    caldat.julday(190,0,-893 ) ;
  }

  @Test
  public void test46() {
    caldat.julday(19018,745,0 ) ;
  }

  @Test
  public void test47() {
    caldat.julday(19338,674,-17 ) ;
  }

  @Test
  public void test48() {
    caldat.julday(19468,1100,-16 ) ;
  }

  @Test
  public void test49() {
    caldat.julday(-2,0,0 ) ;
  }

  @Test
  public void test50() {
    caldat.julday(-2,0,-304 ) ;
  }

  @Test
  public void test51() {
    caldat.julday(-2,0,364 ) ;
  }

  @Test
  public void test52() {
    caldat.julday(-2,0,425 ) ;
  }

  @Test
  public void test53() {
    caldat.julday(-20,50025,-4 ) ;
  }

  @Test
  public void test54() {
    caldat.julday(-2,0,613 ) ;
  }

  @Test
  public void test55() {
    caldat.julday(-2,0,-733 ) ;
  }

  @Test
  public void test56() {
    caldat.julday(-2,0,-838 ) ;
  }

  @Test
  public void test57() {
    caldat.julday(-2,0,-953 ) ;
  }

  @Test
  public void test58() {
    caldat.julday(-2,0,972 ) ;
  }

  @Test
  public void test59() {
    caldat.julday(-21,15901,4 ) ;
  }

  @Test
  public void test60() {
    caldat.julday(-215,0,814 ) ;
  }

  @Test
  public void test61() {
    caldat.julday(2,18888,32 ) ;
  }

  @Test
  public void test62() {
    caldat.julday(2,29830,4 ) ;
  }

  @Test
  public void test63() {
    caldat.julday(2,35628,2 ) ;
  }

  @Test
  public void test64() {
    caldat.julday(2,46713,1 ) ;
  }

  @Test
  public void test65() {
    caldat.julday(249,0,1 ) ;
  }

  @Test
  public void test66() {
    caldat.julday(-270,-40,1892 ) ;
  }

  @Test
  public void test67() {
    caldat.julday(-29,19794,0 ) ;
  }

  @Test
  public void test68() {
    caldat.julday(-30,17984,-1 ) ;
  }

  @Test
  public void test69() {
    caldat.julday(-306,-226,-68 ) ;
  }

  @Test
  public void test70() {
    caldat.julday(-3,15694,-1 ) ;
  }

  @Test
  public void test71() {
    caldat.julday(-3,28663,-2 ) ;
  }

  @Test
  public void test72() {
    caldat.julday(344,0,1 ) ;
  }

  @Test
  public void test73() {
    caldat.julday(-3,50,-848 ) ;
  }

  @Test
  public void test74() {
    caldat.julday(357,0,1 ) ;
  }

  @Test
  public void test75() {
    caldat.julday(-36,189,1913 ) ;
  }

  @Test
  public void test76() {
    caldat.julday(383,0,92 ) ;
  }

  @Test
  public void test77() {
    caldat.julday(389,0,-1 ) ;
  }

  @Test
  public void test78() {
    caldat.julday(-399,-199,185 ) ;
  }

  @Test
  public void test79() {
    caldat.julday(4,0,0 ) ;
  }

  @Test
  public void test80() {
    caldat.julday(402,-347,-31 ) ;
  }

  @Test
  public void test81() {
    caldat.julday(4,0,2354 ) ;
  }

  @Test
  public void test82() {
    caldat.julday(4,0,292 ) ;
  }

  @Test
  public void test83() {
    caldat.julday(4,0,-331 ) ;
  }

  @Test
  public void test84() {
    caldat.julday(4,0,-337 ) ;
  }

  @Test
  public void test85() {
    caldat.julday(4,0,44 ) ;
  }

  @Test
  public void test86() {
    caldat.julday(4,0,-737 ) ;
  }

  @Test
  public void test87() {
    caldat.julday(419,0,1 ) ;
  }

  @Test
  public void test88() {
    caldat.julday(-4,29663,-2 ) ;
  }

  @Test
  public void test89() {
    caldat.julday(-445,0,2 ) ;
  }

  @Test
  public void test90() {
    caldat.julday(446,0,222 ) ;
  }

  @Test
  public void test91() {
    caldat.julday(-449,0,1 ) ;
  }

  @Test
  public void test92() {
    caldat.julday(-484,0,0 ) ;
  }

  @Test
  public void test93() {
    caldat.julday(485,0,-1 ) ;
  }

  @Test
  public void test94() {
    caldat.julday(502,153,-449 ) ;
  }

  @Test
  public void test95() {
    caldat.julday(-526,0,0 ) ;
  }

  @Test
  public void test96() {
    caldat.julday(-5,463,255 ) ;
  }

  @Test
  public void test97() {
    caldat.julday(556,-1716,0 ) ;
  }

  @Test
  public void test98() {
    caldat.julday(572,0,16 ) ;
  }

  @Test
  public void test99() {
    caldat.julday(60,-457,1794 ) ;
  }

  @Test
  public void test100() {
    caldat.julday(632,0,429 ) ;
  }

  @Test
  public void test101() {
    caldat.julday(-6,32880,-4 ) ;
  }

  @Test
  public void test102() {
    caldat.julday(-645,0,661 ) ;
  }

  @Test
  public void test103() {
    caldat.julday(650,-155,836 ) ;
  }

  @Test
  public void test104() {
    caldat.julday(-659,0,-280 ) ;
  }

  @Test
  public void test105() {
    caldat.julday(-673,0,232 ) ;
  }

  @Test
  public void test106() {
    caldat.julday(693,0,-1 ) ;
  }

  @Test
  public void test107() {
    caldat.julday(-707,0,-1 ) ;
  }

  @Test
  public void test108() {
    caldat.julday(-733,0,0 ) ;
  }

  @Test
  public void test109() {
    caldat.julday(733,0,-727 ) ;
  }

  @Test
  public void test110() {
    caldat.julday(759,0,800 ) ;
  }

  @Test
  public void test111() {
    caldat.julday(-7,879,1617 ) ;
  }

  @Test
  public void test112() {
    caldat.julday(-793,0,2 ) ;
  }

  @Test
  public void test113() {
    caldat.julday(-793,0,858 ) ;
  }

  @Test
  public void test114() {
    caldat.julday(-8,0,286 ) ;
  }

  @Test
  public void test115() {
    caldat.julday(803,0,-1 ) ;
  }

  @Test
  public void test116() {
    caldat.julday(-807,-570,-221 ) ;
  }

  @Test
  public void test117() {
    caldat.julday(81,0,-444 ) ;
  }

  @Test
  public void test118() {
    caldat.julday(-8,45973,4 ) ;
  }

  @Test
  public void test119() {
    caldat.julday(-853,820,251 ) ;
  }

  @Test
  public void test120() {
    caldat.julday(871,0,0 ) ;
  }

  @Test
  public void test121() {
    caldat.julday(-875,0,1 ) ;
  }

  @Test
  public void test122() {
    caldat.julday(-8,825,2065 ) ;
  }

  @Test
  public void test123() {
    caldat.julday(9,0,1075 ) ;
  }

  @Test
  public void test124() {
    caldat.julday(9,0,-308 ) ;
  }

  @Test
  public void test125() {
    caldat.julday(908,0,-761 ) ;
  }

  @Test
  public void test126() {
    caldat.julday(-954,0,1 ) ;
  }

  @Test
  public void test127() {
    caldat.julday(960,733,785 ) ;
  }

  @Test
  public void test128() {
    caldat.julday(-978,0,-883 ) ;
  }
}
