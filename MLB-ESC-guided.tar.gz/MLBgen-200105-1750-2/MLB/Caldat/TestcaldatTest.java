import org.junit.Test;

public class TestcaldatTest {

  @Test
  public void test0() {
    caldat.caldat(0 ) ;
  }

  @Test
  public void test1() {
    caldat.caldat(-1 ) ;
  }

  @Test
  public void test2() {
    caldat.caldat(-103 ) ;
  }

  @Test
  public void test3() {
    caldat.caldat(10560 ) ;
  }

  @Test
  public void test4() {
    caldat.caldat(-21 ) ;
  }

  @Test
  public void test5() {
    caldat.caldat(27223 ) ;
  }

  @Test
  public void test6() {
    caldat.caldat(-323 ) ;
  }

  @Test
  public void test7() {
    caldat.caldat(-325 ) ;
  }

  @Test
  public void test8() {
    caldat.caldat(-346 ) ;
  }

  @Test
  public void test9() {
    caldat.caldat(37 ) ;
  }

  @Test
  public void test10() {
    caldat.caldat(385 ) ;
  }

  @Test
  public void test11() {
    caldat.caldat(-4 ) ;
  }

  @Test
  public void test12() {
    caldat.caldat(495 ) ;
  }

  @Test
  public void test13() {
    caldat.caldat(-504 ) ;
  }

  @Test
  public void test14() {
    caldat.caldat(-562 ) ;
  }

  @Test
  public void test15() {
    caldat.caldat(568 ) ;
  }

  @Test
  public void test16() {
    caldat.caldat(6 ) ;
  }

  @Test
  public void test17() {
    caldat.caldat(-655 ) ;
  }

  @Test
  public void test18() {
    caldat.caldat(-695 ) ;
  }

  @Test
  public void test19() {
    caldat.caldat(-707 ) ;
  }

  @Test
  public void test20() {
    caldat.caldat(759 ) ;
  }

  @Test
  public void test21() {
    caldat.caldat(771 ) ;
  }

  @Test
  public void test22() {
    caldat.caldat(795 ) ;
  }

  @Test
  public void test23() {
    caldat.caldat(-9 ) ;
  }

  @Test
  public void test24() {
    caldat.caldat(-905 ) ;
  }

  @Test
  public void test25() {
    caldat.caldat(922 ) ;
  }

  @Test
  public void test26() {
    caldat.caldat(932 ) ;
  }

  @Test
  public void test27() {
    caldat.caldat(950 ) ;
  }
}
