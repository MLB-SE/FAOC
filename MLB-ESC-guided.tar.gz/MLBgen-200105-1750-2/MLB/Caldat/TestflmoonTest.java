import org.junit.Test;

public class TestflmoonTest {

  @Test
  public void test0() {
    caldat.flmoon(0,0 ) ;
  }

  @Test
  public void test1() {
    caldat.flmoon(0,1 ) ;
  }

  @Test
  public void test2() {
    caldat.flmoon(0,2 ) ;
  }

  @Test
  public void test3() {
    caldat.flmoon(0,3 ) ;
  }

  @Test
  public void test4() {
    caldat.flmoon(0,317 ) ;
  }

  @Test
  public void test5() {
    caldat.flmoon(0,322 ) ;
  }

  @Test
  public void test6() {
    caldat.flmoon(0,-518 ) ;
  }

  @Test
  public void test7() {
    caldat.flmoon(0,897 ) ;
  }

  @Test
  public void test8() {
    caldat.flmoon(-1,0 ) ;
  }

  @Test
  public void test9() {
    caldat.flmoon(104,2 ) ;
  }

  @Test
  public void test10() {
    caldat.flmoon(-1,1 ) ;
  }

  @Test
  public void test11() {
    caldat.flmoon(1,1 ) ;
  }

  @Test
  public void test12() {
    caldat.flmoon(-1,2 ) ;
  }

  @Test
  public void test13() {
    caldat.flmoon(-1,3 ) ;
  }

  @Test
  public void test14() {
    caldat.flmoon(1366,2 ) ;
  }

  @Test
  public void test15() {
    caldat.flmoon(-149,0 ) ;
  }

  @Test
  public void test16() {
    caldat.flmoon(157,876 ) ;
  }

  @Test
  public void test17() {
    caldat.flmoon(159,0 ) ;
  }

  @Test
  public void test18() {
    caldat.flmoon(16,-66 ) ;
  }

  @Test
  public void test19() {
    caldat.flmoon(173,-694 ) ;
  }

  @Test
  public void test20() {
    caldat.flmoon(-1939,-5 ) ;
  }

  @Test
  public void test21() {
    caldat.flmoon(-200,801 ) ;
  }

  @Test
  public void test22() {
    caldat.flmoon(-203,17 ) ;
  }

  @Test
  public void test23() {
    caldat.flmoon(-207,-305 ) ;
  }

  @Test
  public void test24() {
    caldat.flmoon(-2206,6 ) ;
  }

  @Test
  public void test25() {
    caldat.flmoon(-22,88 ) ;
  }

  @Test
  public void test26() {
    caldat.flmoon(-2,3 ) ;
  }

  @Test
  public void test27() {
    caldat.flmoon(2440,3 ) ;
  }

  @Test
  public void test28() {
    caldat.flmoon(-2468,-3 ) ;
  }

  @Test
  public void test29() {
    caldat.flmoon(256,-1026 ) ;
  }

  @Test
  public void test30() {
    caldat.flmoon(2699,-6 ) ;
  }

  @Test
  public void test31() {
    caldat.flmoon(-284,1134 ) ;
  }

  @Test
  public void test32() {
    caldat.flmoon(343,1 ) ;
  }

  @Test
  public void test33() {
    caldat.flmoon(358,3 ) ;
  }

  @Test
  public void test34() {
    caldat.flmoon(377,5 ) ;
  }

  @Test
  public void test35() {
    caldat.flmoon(-394,12 ) ;
  }

  @Test
  public void test36() {
    caldat.flmoon(428,-2 ) ;
  }

  @Test
  public void test37() {
    caldat.flmoon(-43,173 ) ;
  }

  @Test
  public void test38() {
    caldat.flmoon(445,4 ) ;
  }

  @Test
  public void test39() {
    caldat.flmoon(-470,-18 ) ;
  }

  @Test
  public void test40() {
    caldat.flmoon(-470,898 ) ;
  }

  @Test
  public void test41() {
    caldat.flmoon(-48,2 ) ;
  }

  @Test
  public void test42() {
    caldat.flmoon(492,18 ) ;
  }

  @Test
  public void test43() {
    caldat.flmoon(-495,1 ) ;
  }

  @Test
  public void test44() {
    caldat.flmoon(-550,8 ) ;
  }

  @Test
  public void test45() {
    caldat.flmoon(-562,2 ) ;
  }

  @Test
  public void test46() {
    caldat.flmoon(-563,0 ) ;
  }

  @Test
  public void test47() {
    caldat.flmoon(-624,713 ) ;
  }

  @Test
  public void test48() {
    caldat.flmoon(645,-14 ) ;
  }

  @Test
  public void test49() {
    caldat.flmoon(670,3 ) ;
  }

  @Test
  public void test50() {
    caldat.flmoon(712,629 ) ;
  }

  @Test
  public void test51() {
    caldat.flmoon(-761,3 ) ;
  }

  @Test
  public void test52() {
    caldat.flmoon(793,145 ) ;
  }

  @Test
  public void test53() {
    caldat.flmoon(820,2 ) ;
  }

  @Test
  public void test54() {
    caldat.flmoon(827,0 ) ;
  }

  @Test
  public void test55() {
    caldat.flmoon(841,-243 ) ;
  }

  @Test
  public void test56() {
    caldat.flmoon(-864,1 ) ;
  }

  @Test
  public void test57() {
    caldat.flmoon(-884,0 ) ;
  }

  @Test
  public void test58() {
    caldat.flmoon(906,1 ) ;
  }

  @Test
  public void test59() {
    caldat.flmoon(-921,3 ) ;
  }
}
