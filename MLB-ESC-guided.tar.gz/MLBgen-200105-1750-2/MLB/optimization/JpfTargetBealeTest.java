import org.junit.Test;

public class JpfTargetBealeTest {

  @Test
  public void test0() {
    Optimization.beale(16.024887617394043,-12.054481987211702 ) ;
  }

  @Test
  public void test1() {
    Optimization.beale(-1.8933278062508858,1.7922558339066796 ) ;
  }

  @Test
  public void test2() {
    Optimization.beale(-84.48194466697454,-8.865939473784024 ) ;
  }
}
