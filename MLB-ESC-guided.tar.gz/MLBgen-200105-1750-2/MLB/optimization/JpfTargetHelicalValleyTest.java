import org.junit.Test;

public class JpfTargetHelicalValleyTest {

  @Test
  public void test0() {
    Optimization.theta(-0.001401572509790761,946.0304214787908 ) ;
  }

  @Test
  public void test1() {
    Optimization.theta(-0.283799933537793,-35.23995384956649 ) ;
  }

  @Test
  public void test2() {
    Optimization.theta(0.37185403570920617,32.97240446257259 ) ;
  }

  @Test
  public void test3() {
    Optimization.theta(100.0,0.0 ) ;
  }

  @Test
  public void test4() {
    Optimization.theta(100.0,5.094887648617833 ) ;
  }

  @Test
  public void test5() {
    Optimization.theta(12.238201579032022,0 ) ;
  }

  @Test
  public void test6() {
    Optimization.theta(16.228188716162308,-1.6680140893918165 ) ;
  }

  @Test
  public void test7() {
    Optimization.theta(-2.1684043449710089E-19,99.99490202913576 ) ;
  }

  @Test
  public void test8() {
    Optimization.theta(-25.461608393039597,0 ) ;
  }

  @Test
  public void test9() {
    Optimization.theta(-2.7755575615628914E-17,99.75605134062947 ) ;
  }

  @Test
  public void test10() {
    Optimization.theta(3.352072837882062,0 ) ;
  }

  @Test
  public void test11() {
    Optimization.theta(3.384051290946161,0 ) ;
  }

  @Test
  public void test12() {
    Optimization.theta(-3.469446951953614E-18,100.0 ) ;
  }

  @Test
  public void test13() {
    Optimization.theta(39.82880883044126,39.17503735115574 ) ;
  }

  @Test
  public void test14() {
    Optimization.theta(-41.205639591584806,-37.45416188207638 ) ;
  }

  @Test
  public void test15() {
    Optimization.theta(-4.440892098500626E-16,82.27983212343753 ) ;
  }

  @Test
  public void test16() {
    Optimization.theta(45.01933794269772,82.19060112101232 ) ;
  }

  @Test
  public void test17() {
    Optimization.theta(-4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test18() {
    Optimization.theta(-5.551115123125783E-17,100.0 ) ;
  }

  @Test
  public void test19() {
    Optimization.theta(-59.19527544419345,-12.883655005889835 ) ;
  }

  @Test
  public void test20() {
    Optimization.theta(-60.799526153269476,-64.75908034848759 ) ;
  }

  @Test
  public void test21() {
    Optimization.theta(-6.162975822039155E-33,0 ) ;
  }

  @Test
  public void test22() {
    Optimization.theta(6.396549323037419,94.43788590167742 ) ;
  }

  @Test
  public void test23() {
    Optimization.theta(-66.1808930248942,-35.995559745183115 ) ;
  }

  @Test
  public void test24() {
    Optimization.theta(-6.875500128680947E-8,2757.155601362753 ) ;
  }

  @Test
  public void test25() {
    Optimization.theta(-69.79169895261954,0 ) ;
  }

  @Test
  public void test26() {
    Optimization.theta(-74.53670903920803,0 ) ;
  }

  @Test
  public void test27() {
    Optimization.theta(-77.17144499225594,-3.1022237520296585 ) ;
  }

  @Test
  public void test28() {
    Optimization.theta(79.88656096709784,-51.605509614159004 ) ;
  }

  @Test
  public void test29() {
    Optimization.theta(80.17704843351243,0 ) ;
  }

  @Test
  public void test30() {
    Optimization.theta(-8.881784197001252E-16,100.0 ) ;
  }

  @Test
  public void test31() {
    Optimization.theta(90.59468684129348,7.248651547601128 ) ;
  }

  @Test
  public void test32() {
    Optimization.theta(-94.54092845204912,-35.17938724252596 ) ;
  }

  @Test
  public void test33() {
    Optimization.theta(-9.860761315262648E-32,0 ) ;
  }
}
