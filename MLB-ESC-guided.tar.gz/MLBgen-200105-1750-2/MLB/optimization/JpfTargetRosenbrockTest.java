import org.junit.Test;

public class JpfTargetRosenbrockTest {

  @Test
  public void test0() {
    Optimization.rosenbrock(0.525678252494684,0.27220624973584395 ) ;
  }

  @Test
  public void test1() {
    Optimization.rosenbrock(0.709414163990174,0.501291968328524 ) ;
  }

  @Test
  public void test2() {
    Optimization.rosenbrock(2.073972635182968,4.301324278651981 ) ;
  }

  @Test
  public void test3() {
    Optimization.rosenbrock(7.738358256801415,59.88193911640422 ) ;
  }

  @Test
  public void test4() {
    Optimization.rosenbrock(-84.71232368990174,71.53805617435381 ) ;
  }
}
