import org.junit.Test;

public class JpfTargetWoodTest {

  @Test
  public void test0() {
    Optimization.wood(1.0,0.9999999999999998,1.0,1.0 ) ;
  }

  @Test
  public void test1() {
    Optimization.wood(1.0,0.9999999999999999,1.0,1.0 ) ;
  }

  @Test
  public void test2() {
    Optimization.wood(1.0,1.0,0,0 ) ;
  }

  @Test
  public void test3() {
    Optimization.wood(1.0,1.0000000000000004,1.0,1.0 ) ;
  }

  @Test
  public void test4() {
    Optimization.wood(1.0,1.0,100.0,19.908411061530757 ) ;
  }

  @Test
  public void test5() {
    Optimization.wood(1.0,1.0,1.0,0.9999999999999998 ) ;
  }

  @Test
  public void test6() {
    Optimization.wood(1.0,1.0,1.0,0.9999999999999999 ) ;
  }

  @Test
  public void test7() {
    Optimization.wood(1.0,1.0,1.0,1.0 ) ;
  }

  @Test
  public void test8() {
    Optimization.wood(1.0,1.0,1.0,1.0000000000000002 ) ;
  }

  @Test
  public void test9() {
    Optimization.wood(1.0,1.0,1.0,1.0000000000000004 ) ;
  }

  @Test
  public void test10() {
    Optimization.wood(1.0,1.0,5.481126773338616,30.04275070540939 ) ;
  }

  @Test
  public void test11() {
    Optimization.wood(1.0,1.0,-5.984596550310756,35.8153958699914 ) ;
  }

  @Test
  public void test12() {
    Optimization.wood(1.0,1.0,6.870663058940593,48.884560054042275 ) ;
  }

  @Test
  public void test13() {
    Optimization.wood(1.0,1.0,-9.710690459994714,94.29750920983234 ) ;
  }

  @Test
  public void test14() {
    Optimization.wood(1.0,-20.345230633807503,1.0,22.345230633807503 ) ;
  }

  @Test
  public void test15() {
    Optimization.wood(1.0,55.948782406649556,1.0,55.948782406649556 ) ;
  }

  @Test
  public void test16() {
    Optimization.wood(1.0,81.90831607468067,1.0,81.90831607468067 ) ;
  }

  @Test
  public void test17() {
    Optimization.wood(1.2420888404730899,1.5427846876277849,0,0 ) ;
  }

  @Test
  public void test18() {
    Optimization.wood(-60.30403807313425,62.321707552765844,0,0 ) ;
  }

  @Test
  public void test19() {
    Optimization.wood(-7.18505244821521,82.8163399165114,0,0 ) ;
  }

  @Test
  public void test20() {
    Optimization.wood(-8.139054022000195,66.24420037303756,0,0 ) ;
  }

  @Test
  public void test21() {
    Optimization.wood(9.671010411141282,93.52844237240306,0,0 ) ;
  }
}
