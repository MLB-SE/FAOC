import org.junit.Test;

public class JpfTargetFreudensteinRothTest {

  @Test
  public void test0() {
    Optimization.freudensteinRoth(-64.55733613784871,6.837594393977836 ) ;
  }

  @Test
  public void test1() {
    Optimization.freudensteinRoth(-69.30081230718497,-2.958796673884393 ) ;
  }

  @Test
  public void test2() {
    Optimization.freudensteinRoth(-92.08310211325596,70.60473420104822 ) ;
  }
}
