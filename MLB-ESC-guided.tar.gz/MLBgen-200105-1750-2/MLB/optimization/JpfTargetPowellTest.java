import org.junit.Test;

public class JpfTargetPowellTest {

  @Test
  public void test0() {
    Optimization.powell(1.1564469645077924E-5,8.647175622321951 ) ;
  }

  @Test
  public void test1() {
    Optimization.powell(1.5483708925373587E-6,64.58400922025032 ) ;
  }

  @Test
  public void test2() {
    Optimization.powell(-2.951903970060954E-5,-3.387644076983138 ) ;
  }

  @Test
  public void test3() {
    Optimization.powell(56.07094092141244,-57.26733685798378 ) ;
  }

  @Test
  public void test4() {
    Optimization.powell(-6.111383910199958E-6,-16.362905925955502 ) ;
  }

  @Test
  public void test5() {
    Optimization.powell(-71.91422752509871,-24.377342715935995 ) ;
  }
}
