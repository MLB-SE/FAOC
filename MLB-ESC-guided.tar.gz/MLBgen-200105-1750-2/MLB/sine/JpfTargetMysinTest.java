import org.junit.Test;

public class JpfTargetMysinTest {

  @Test
  public void test0() {
    JpfTargetMysin.static_mysin(-0.029565288472795714 ) ;
  }

  @Test
  public void test1() {
    JpfTargetMysin.static_mysin(0.1526416374119055 ) ;
  }

  @Test
  public void test2() {
    JpfTargetMysin.static_mysin(0.21161249757750866 ) ;
  }

  @Test
  public void test3() {
    JpfTargetMysin.static_mysin(-0.7741316019554416 ) ;
  }

  @Test
  public void test4() {
    JpfTargetMysin.static_mysin(-10.210176124166827 ) ;
  }

  @Test
  public void test5() {
    JpfTargetMysin.static_mysin(-146.1010296309293 ) ;
  }

  @Test
  public void test6() {
    JpfTargetMysin.static_mysin(-2.3434543880352342E-4 ) ;
  }

  @Test
  public void test7() {
    JpfTargetMysin.static_mysin(2.4414062499999306E-4 ) ;
  }

  @Test
  public void test8() {
    JpfTargetMysin.static_mysin(2.4414062500008544E-4 ) ;
  }

  @Test
  public void test9() {
    JpfTargetMysin.static_mysin(-2.4414235521573604E-4 ) ;
  }

  @Test
  public void test10() {
    JpfTargetMysin.static_mysin(-2.4715550216466574E-4 ) ;
  }

  @Test
  public void test11() {
    JpfTargetMysin.static_mysin(-25.04081726310349 ) ;
  }

  @Test
  public void test12() {
    JpfTargetMysin.static_mysin(25.26890133192792 ) ;
  }

  @Test
  public void test13() {
    JpfTargetMysin.static_mysin(276.48375175948973 ) ;
  }

  @Test
  public void test14() {
    JpfTargetMysin.static_mysin(27.85031263264719 ) ;
  }

  @Test
  public void test15() {
    JpfTargetMysin.static_mysin(-27.91624936331634 ) ;
  }

  @Test
  public void test16() {
    JpfTargetMysin.static_mysin(-29.059732045705587 ) ;
  }

  @Test
  public void test17() {
    JpfTargetMysin.static_mysin(40.6549595415095 ) ;
  }

  @Test
  public void test18() {
    JpfTargetMysin.static_mysin(-46.64786797187625 ) ;
  }

  @Test
  public void test19() {
    JpfTargetMysin.static_mysin(46.78888707481093 ) ;
  }

  @Test
  public void test20() {
    JpfTargetMysin.static_mysin(4.772276836531326E-37 ) ;
  }

  @Test
  public void test21() {
    JpfTargetMysin.static_mysin(58.90486225480862 ) ;
  }

  @Test
  public void test22() {
    JpfTargetMysin.static_mysin(64.95219299037726 ) ;
  }

  @Test
  public void test23() {
    JpfTargetMysin.static_mysin(7.0685834705770345 ) ;
  }

  @Test
  public void test24() {
    JpfTargetMysin.static_mysin(-71.71276243669493 ) ;
  }

  @Test
  public void test25() {
    JpfTargetMysin.static_mysin(-75.8841356041166 ) ;
  }

  @Test
  public void test26() {
    JpfTargetMysin.static_mysin(-77.94776466223149 ) ;
  }

  @Test
  public void test27() {
    JpfTargetMysin.static_mysin(-78.80541306274276 ) ;
  }

  @Test
  public void test28() {
    JpfTargetMysin.static_mysin(-8.093211652361969E-17 ) ;
  }

  @Test
  public void test29() {
    JpfTargetMysin.static_mysin(-92.25420367963362 ) ;
  }
}
