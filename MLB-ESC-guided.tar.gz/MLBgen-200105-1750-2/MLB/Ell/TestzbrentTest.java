import org.junit.Test;

public class TestzbrentTest {

  @Test
  public void test0() {
    ell.zbrent(0.5720573746902033,81.68140899333463,0 ) ;
  }

  @Test
  public void test1() {
    ell.zbrent(-100.0,53.40707511102648,0 ) ;
  }

  @Test
  public void test2() {
    ell.zbrent(-100.0,-69.11503837897544,0 ) ;
  }

  @Test
  public void test3() {
    ell.zbrent(100.0,-87.96459430051421,0 ) ;
  }

  @Test
  public void test4() {
    ell.zbrent(-11.465760118550989,37.69911184307752,0 ) ;
  }

  @Test
  public void test5() {
    ell.zbrent(12.566370614359172,0,0 ) ;
  }

  @Test
  public void test6() {
    ell.zbrent(-13.684618144745457,0,0 ) ;
  }

  @Test
  public void test7() {
    ell.zbrent(14.065533050786016,-12.566370614359174,0 ) ;
  }

  @Test
  public void test8() {
    ell.zbrent(14.200375048567153,-53.40707511102649,0 ) ;
  }

  @Test
  public void test9() {
    ell.zbrent(17.19935401744283,94.24777960769379,0 ) ;
  }

  @Test
  public void test10() {
    ell.zbrent(2.1758838006894337,-1.1906377376868846,0 ) ;
  }

  @Test
  public void test11() {
    ell.zbrent(21.991148575128555,0,0 ) ;
  }

  @Test
  public void test12() {
    ell.zbrent(-23.477916127677155,-84.82300164692442,0 ) ;
  }

  @Test
  public void test13() {
    ell.zbrent(25.13274122871835,80.36308844970085,0 ) ;
  }

  @Test
  public void test14() {
    ell.zbrent(2.6773514800704703,-18.84955592153876,0 ) ;
  }

  @Test
  public void test15() {
    ell.zbrent(28.417001216362934,-35.28883720985651,0 ) ;
  }

  @Test
  public void test16() {
    ell.zbrent(29.492082623605,91.106186954104,0 ) ;
  }

  @Test
  public void test17() {
    ell.zbrent(-29.57815101948185,7.362368443539651,0 ) ;
  }

  @Test
  public void test18() {
    ell.zbrent(35.61813556396676,15.707963267948966,0 ) ;
  }

  @Test
  public void test19() {
    ell.zbrent(35.6490064234078,75.2592693602023,0 ) ;
  }

  @Test
  public void test20() {
    ell.zbrent(40.95283319997434,150.79644769401764,0 ) ;
  }

  @Test
  public void test21() {
    ell.zbrent(-45.28107753803157,-82.5663516197174,0 ) ;
  }

  @Test
  public void test22() {
    ell.zbrent(-45.605549827985016,0,0 ) ;
  }

  @Test
  public void test23() {
    ell.zbrent(50.95680092604047,-4.153600693435735,0 ) ;
  }

  @Test
  public void test24() {
    ell.zbrent(-56.14910813104712,66.11348739103408,0 ) ;
  }

  @Test
  public void test25() {
    ell.zbrent(56.548667764616276,0,0 ) ;
  }

  @Test
  public void test26() {
    ell.zbrent(-56.548667764616276,-18.857072017870298,0 ) ;
  }

  @Test
  public void test27() {
    ell.zbrent(-56.548667764616276,-69.29934137659292,0 ) ;
  }

  @Test
  public void test28() {
    ell.zbrent(58.708417394780746,72.25663103256524,0 ) ;
  }

  @Test
  public void test29() {
    ell.zbrent(-65.52842504098753,-59.690260418206066,0 ) ;
  }

  @Test
  public void test30() {
    ell.zbrent(-6.930065905885643,18.84955592153876,0 ) ;
  }

  @Test
  public void test31() {
    ell.zbrent(78.35726534965454,95.17870631400916,0 ) ;
  }

  @Test
  public void test32() {
    ell.zbrent(81.72555784525207,9.424777960769381,0 ) ;
  }

  @Test
  public void test33() {
    ell.zbrent(8.263842562498695,43.62605316457916,0 ) ;
  }

  @Test
  public void test34() {
    ell.zbrent(8.327327356738017,-50.26548245743669,0 ) ;
  }

  @Test
  public void test35() {
    ell.zbrent(-83.64885537671375,8.138285693139153,0 ) ;
  }

  @Test
  public void test36() {
    ell.zbrent(-83.83428126500434,40.84070449666731,0 ) ;
  }

  @Test
  public void test37() {
    ell.zbrent(-87.0804299538017,9.424777960769381,0 ) ;
  }

  @Test
  public void test38() {
    ell.zbrent(87.96459430051422,-1.045068701624591,0 ) ;
  }

  @Test
  public void test39() {
    ell.zbrent(-91.62594128496775,56.548667764616276,0 ) ;
  }

  @Test
  public void test40() {
    ell.zbrent(-9.51784575106845,0,0 ) ;
  }

  @Test
  public void test41() {
    ell.zbrent(98.27609667818399,-56.548667764616276,0 ) ;
  }
}
