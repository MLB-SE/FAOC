import org.junit.Test;

public class TestbrentTest {

  @Test
  public void test0() {
    ell.brent(0.0,0.0,0.0,0 ) ;
  }

  @Test
  public void test1() {
    ell.brent(0.9975340112332987,-32.98294495204436,-61.165370268273314,0 ) ;
  }

  @Test
  public void test2() {
    ell.brent(-100.0,0.0,-100.0,0 ) ;
  }

  @Test
  public void test3() {
    ell.brent(100.0,100.0,100.0,0 ) ;
  }

  @Test
  public void test4() {
    ell.brent(1.1979029395041465,0,1.1979029395041465,0 ) ;
  }

  @Test
  public void test5() {
    ell.brent(13.123788277765557,0,13.123788277765557,0 ) ;
  }

  @Test
  public void test6() {
    ell.brent(1.3927926543692422,0,1.392792654369242,0 ) ;
  }

  @Test
  public void test7() {
    ell.brent(14.454644261816282,0,14.454644261816284,0 ) ;
  }

  @Test
  public void test8() {
    ell.brent(20.7882678001651,0,20.788267800165105,0 ) ;
  }

  @Test
  public void test9() {
    ell.brent(21.0636658565114,6.189352151814482,21.0636658565114,0 ) ;
  }

  @Test
  public void test10() {
    ell.brent(-21.891472140045252,-27.291884512098235,-59.005619898995555,0 ) ;
  }

  @Test
  public void test11() {
    ell.brent(-22.378114994076405,-22.369926935349714,-22.361738876623022,0 ) ;
  }

  @Test
  public void test12() {
    ell.brent(23.27398309957482,4.684932276725235,-13.904118546124351,0 ) ;
  }

  @Test
  public void test13() {
    ell.brent(27.40272969076001,87.70847875421629,27.40272969076001,0 ) ;
  }

  @Test
  public void test14() {
    ell.brent(27.52209215432562,0,27.522092154325616,0 ) ;
  }

  @Test
  public void test15() {
    ell.brent(29.78456606486435,0,55.311070745250476,0 ) ;
  }

  @Test
  public void test16() {
    ell.brent(35.239304283844305,0.0,-35.239304283844305,0 ) ;
  }

  @Test
  public void test17() {
    ell.brent(37.98884827813508,0.0,-85.47815193245945,0 ) ;
  }

  @Test
  public void test18() {
    ell.brent(40.04503476688333,30.606885001577382,73.06508093022555,0 ) ;
  }

  @Test
  public void test19() {
    ell.brent(-40.91272748343759,10.177626474085997,-83.53970816330843,0 ) ;
  }

  @Test
  public void test20() {
    ell.brent(42.17319185250571,-50.145604245685064,-65.92334467175152,0 ) ;
  }

  @Test
  public void test21() {
    ell.brent(42.568792755479066,-25.25985613986817,42.568792755479066,0 ) ;
  }

  @Test
  public void test22() {
    ell.brent(-42.74962681191484,0.0,-36.07030119216808,0 ) ;
  }

  @Test
  public void test23() {
    ell.brent(-43.90734280003734,82.36505406830122,17.148561872325047,0 ) ;
  }

  @Test
  public void test24() {
    ell.brent(-44.75843610433928,0.0,-17.647058222374596,0 ) ;
  }

  @Test
  public void test25() {
    ell.brent(-4.688010152658094,-4.688010152658094,-4.688010152658094,0 ) ;
  }

  @Test
  public void test26() {
    ell.brent(-49.58575105565572,0.0,49.58575105565572,0 ) ;
  }

  @Test
  public void test27() {
    ell.brent(-50.025563779839224,0,-28.536842603156188,0 ) ;
  }

  @Test
  public void test28() {
    ell.brent(6.074433363947532,0,6.074433363947531,0 ) ;
  }

  @Test
  public void test29() {
    ell.brent(62.062214186382285,0.0,-2.4558582446772554,0 ) ;
  }

  @Test
  public void test30() {
    ell.brent(63.27844217349238,0,-71.35160471797997,0 ) ;
  }

  @Test
  public void test31() {
    ell.brent(66.10326910560221,-1.3219118063426052,-68.74709271828742,0 ) ;
  }

  @Test
  public void test32() {
    ell.brent(73.19844044222731,95.55308229214486,73.19844044222731,0 ) ;
  }

  @Test
  public void test33() {
    ell.brent(-7.360361098726692,0.0,-7.360361098726692,0 ) ;
  }

  @Test
  public void test34() {
    ell.brent(74.40748817578421,0.0,-49.73764303962349,0 ) ;
  }

  @Test
  public void test35() {
    ell.brent(74.9921081461128,0,-64.56950212393741,0 ) ;
  }

  @Test
  public void test36() {
    ell.brent(-7.613629683361978,0.0,70.07175716472582,0 ) ;
  }

  @Test
  public void test37() {
    ell.brent(77.28077151949066,53.57657152921888,-2.5161118952555768,0 ) ;
  }

  @Test
  public void test38() {
    ell.brent(-77.69391989275482,-26.103947418097732,-77.69391989275482,0 ) ;
  }

  @Test
  public void test39() {
    ell.brent(80.9150024023926,-70.38989753549976,80.9150024023926,0 ) ;
  }

  @Test
  public void test40() {
    ell.brent(81.0714638963444,-34.011356096155936,82.2927522071767,0 ) ;
  }

  @Test
  public void test41() {
    ell.brent(81.22434658062231,0,81.2243465806223,0 ) ;
  }

  @Test
  public void test42() {
    ell.brent(-84.92274484708497,-36.89803258566995,-34.863722838587435,0 ) ;
  }

  @Test
  public void test43() {
    ell.brent(8.881784197001252E-16,0.0,8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test44() {
    ell.brent(-88.90765844216553,82.23561876414684,-27.227518106494756,0 ) ;
  }

  @Test
  public void test45() {
    ell.brent(94.07887672567611,5.816359067996174,-51.852372647928966,0 ) ;
  }

  @Test
  public void test46() {
    ell.brent(-9.958941402046534,-95.82887690701887,-8.94447604539046,0 ) ;
  }

  @Test
  public void test47() {
    ell.brent(99.99999999999996,99.99999999999997,100.0,0 ) ;
  }
}
