import org.junit.Test;

public class TestellpiTest {

  @Test
  public void test0() {
    ell.ellpi(0.042105261524414406,0,23.75701991670239 ) ;
  }

  @Test
  public void test1() {
    ell.ellpi(-147.9953840049847,0,-2.9941371874539593 ) ;
  }

  @Test
  public void test2() {
    ell.ellpi(-15.707963275981484,0,-1.2438709854295444 ) ;
  }

  @Test
  public void test3() {
    ell.ellpi(-15.707963818242273,0,0.9951374602589543 ) ;
  }

  @Test
  public void test4() {
    ell.ellpi(18.849556000636372,0,0.13389884014619396 ) ;
  }

  @Test
  public void test5() {
    ell.ellpi(-18.96325576765489,0,-8.814065255798221 ) ;
  }

  @Test
  public void test6() {
    ell.ellpi(20.420352248333657,0,-0.6887399404192669 ) ;
  }

  @Test
  public void test7() {
    ell.ellpi(21.99114857450944,0,-27.612261759639807 ) ;
  }

  @Test
  public void test8() {
    ell.ellpi(-22.251236298379325,0,0.5555986398167789 ) ;
  }

  @Test
  public void test9() {
    ell.ellpi(-23.561943860443954,0,-1.0 ) ;
  }

  @Test
  public void test10() {
    ell.ellpi(28.274333876596234,0,100.0 ) ;
  }

  @Test
  public void test11() {
    ell.ellpi(-28.45257438733158,0,-5.640214257787617 ) ;
  }

  @Test
  public void test12() {
    ell.ellpi(-30.48968391240632,0,-37.52325330669717 ) ;
  }

  @Test
  public void test13() {
    ell.ellpi(-31.415926551784793,0,-0.8742211890177458 ) ;
  }

  @Test
  public void test14() {
    ell.ellpi(3.146726872755508,0,0.9999999999990422 ) ;
  }

  @Test
  public void test15() {
    ell.ellpi(34.55751919009549,0,-3.1497454170530474 ) ;
  }

  @Test
  public void test16() {
    ell.ellpi(-36.12831551628262,0,0.06674553960242248 ) ;
  }

  @Test
  public void test17() {
    ell.ellpi(43.982297167441494,0,-0.37030139069239 ) ;
  }

  @Test
  public void test18() {
    ell.ellpi(46.83184778144363,0,-99.08932161621505 ) ;
  }

  @Test
  public void test19() {
    ell.ellpi(4.712388981358444,0,-1.6779867792138248E-5 ) ;
  }

  @Test
  public void test20() {
    ell.ellpi(49.44654989893215,0,-1.2524577437589954 ) ;
  }

  @Test
  public void test21() {
    ell.ellpi(53.40707508209755,0,-0.08261585681066153 ) ;
  }

  @Test
  public void test22() {
    ell.ellpi(56.54866775388037,0,0.8382697382895211 ) ;
  }

  @Test
  public void test23() {
    ell.ellpi(-56.5486677613023,0,-2.1151499453323055 ) ;
  }

  @Test
  public void test24() {
    ell.ellpi(-58.17742221734563,0,-0.017876144568883978 ) ;
  }

  @Test
  public void test25() {
    ell.ellpi(-59.73234173176204,0,-0.24776501514273264 ) ;
  }

  @Test
  public void test26() {
    ell.ellpi(-59.97452392074764,0,-3.5656905255014903 ) ;
  }

  @Test
  public void test27() {
    ell.ellpi(-69.11503836315516,0,13.831048601006287 ) ;
  }

  @Test
  public void test28() {
    ell.ellpi(-69.11503837874028,0,-29.43304858714808 ) ;
  }

  @Test
  public void test29() {
    ell.ellpi(75.39822367622627,0,45.215880737649066 ) ;
  }

  @Test
  public void test30() {
    ell.ellpi(75.39822369358176,0,-1.2474314294215803 ) ;
  }

  @Test
  public void test31() {
    ell.ellpi(7.853981633974483,0,-1.0 ) ;
  }

  @Test
  public void test32() {
    ell.ellpi(-81.68140902999149,0,-0.9642614441860706 ) ;
  }

  @Test
  public void test33() {
    ell.ellpi(81.68140951999447,0,1.0002192936071694 ) ;
  }

  @Test
  public void test34() {
    ell.ellpi(-82.37897199979231,0,-72.19525706513286 ) ;
  }

  @Test
  public void test35() {
    ell.ellpi(83.25220532422462,0,-0.3459147822830886 ) ;
  }

  @Test
  public void test36() {
    ell.ellpi(84.82300163838985,0,-1.400689122693078 ) ;
  }

  @Test
  public void test37() {
    ell.ellpi(-86.39379797375808,0,1.0 ) ;
  }

  @Test
  public void test38() {
    ell.ellpi(87.96459430064931,0,-30.881808581712164 ) ;
  }

  @Test
  public void test39() {
    ell.ellpi(88.09551135653092,0,-6.8812199296922785 ) ;
  }

  @Test
  public void test40() {
    ell.ellpi(89.53539062818636,0,1.0 ) ;
  }

  @Test
  public void test41() {
    ell.ellpi(89.53539063270831,0,1.0 ) ;
  }

  @Test
  public void test42() {
    ell.ellpi(91.10730674333976,0,1.0000000000250753 ) ;
  }

  @Test
  public void test43() {
    ell.ellpi(91.8884000084745,0,0.9315556054833559 ) ;
  }

  @Test
  public void test44() {
    ell.ellpi(-94.24777959779072,0,-1.088032150905167 ) ;
  }

  @Test
  public void test45() {
    ell.ellpi(94.24777960178795,0,1.430910494506378 ) ;
  }

  @Test
  public void test46() {
    ell.ellpi(9.424777968788623,0,-1.5102669681809662 ) ;
  }

  @Test
  public void test47() {
    ell.ellpi(97.38937142767782,0,-1.0000689446986537 ) ;
  }
}
