import org.junit.Test;

public class TestsncndnTest {

  @Test
  public void test0() {
    ell.sncndn(0,0.8380525595521737 ) ;
  }

  @Test
  public void test1() {
    ell.sncndn(0,0.9999999799999999 ) ;
  }

  @Test
  public void test2() {
    ell.sncndn(0,0.99999998 ) ;
  }

  @Test
  public void test3() {
    ell.sncndn(0,0.9999999802001769 ) ;
  }

  @Test
  public void test4() {
    ell.sncndn(0,1.0000000000000002 ) ;
  }

  @Test
  public void test5() {
    ell.sncndn(0,1.000000000060913 ) ;
  }

  @Test
  public void test6() {
    ell.sncndn(0,1.00000002 ) ;
  }

  @Test
  public void test7() {
    ell.sncndn(0,16.939330246351318 ) ;
  }

  @Test
  public void test8() {
    ell.sncndn(0,2.465190328815662E-32 ) ;
  }

  @Test
  public void test9() {
    ell.sncndn(0,25.363058936948946 ) ;
  }

  @Test
  public void test10() {
    ell.sncndn(0,-42.22627061304336 ) ;
  }

  @Test
  public void test11() {
    ell.sncndn(0,42.721702517887394 ) ;
  }

  @Test
  public void test12() {
    ell.sncndn(0,-4.840777949503533 ) ;
  }

  @Test
  public void test13() {
    ell.sncndn(0,4.930380657631324E-32 ) ;
  }

  @Test
  public void test14() {
    ell.sncndn(0,50.86623183545652 ) ;
  }

  @Test
  public void test15() {
    ell.sncndn(0,-5.879997777147494 ) ;
  }

  @Test
  public void test16() {
    ell.sncndn(0,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test17() {
    ell.sncndn(0,-78.1242771806458 ) ;
  }

  @Test
  public void test18() {
    ell.sncndn(0,-82.42961964444406 ) ;
  }

  @Test
  public void test19() {
    ell.sncndn(0,8.881784197001252E-16 ) ;
  }

  @Test
  public void test20() {
    ell.sncndn(0,9.691184041172747 ) ;
  }
}
