import org.junit.Test;

public class TestplgndrTest {

  @Test
  public void test0() {
    plgndr.plgndr(0,0,0 ) ;
  }

  @Test
  public void test1() {
    plgndr.plgndr(0,-1,0 ) ;
  }

  @Test
  public void test2() {
    plgndr.plgndr(0,102,0 ) ;
  }

  @Test
  public void test3() {
    plgndr.plgndr(0,-498,0 ) ;
  }

  @Test
  public void test4() {
    plgndr.plgndr(0,-823,0 ) ;
  }

  @Test
  public void test5() {
    plgndr.plgndr(-107,760,0 ) ;
  }

  @Test
  public void test6() {
    plgndr.plgndr(129,69,0.9999999999999858 ) ;
  }

  @Test
  public void test7() {
    plgndr.plgndr(2762,976,1.0000000000000002 ) ;
  }

  @Test
  public void test8() {
    plgndr.plgndr(3253,106,1.0000000000000002 ) ;
  }

  @Test
  public void test9() {
    plgndr.plgndr(39,587,0 ) ;
  }

  @Test
  public void test10() {
    plgndr.plgndr(-398,0,0 ) ;
  }

  @Test
  public void test11() {
    plgndr.plgndr(-409,0,0 ) ;
  }

  @Test
  public void test12() {
    plgndr.plgndr(531,398,4.009046441094412 ) ;
  }

  @Test
  public void test13() {
    plgndr.plgndr(-56,-57,0 ) ;
  }

  @Test
  public void test14() {
    plgndr.plgndr(588,98,0.0 ) ;
  }

  @Test
  public void test15() {
    plgndr.plgndr(599,445,-0.9393183355587897 ) ;
  }

  @Test
  public void test16() {
    plgndr.plgndr(-635,-635,0 ) ;
  }

  @Test
  public void test17() {
    plgndr.plgndr(647,150,1.0000000000000018 ) ;
  }

  @Test
  public void test18() {
    plgndr.plgndr(703,400,0.3852039226505869 ) ;
  }

  @Test
  public void test19() {
    plgndr.plgndr(705,401,-88.02155600073682 ) ;
  }

  @Test
  public void test20() {
    plgndr.plgndr(-708,0,0 ) ;
  }

  @Test
  public void test21() {
    plgndr.plgndr(726,608,-69.27371242052926 ) ;
  }

  @Test
  public void test22() {
    plgndr.plgndr(740,514,-1.0 ) ;
  }

  @Test
  public void test23() {
    plgndr.plgndr(754,13,0 ) ;
  }

  @Test
  public void test24() {
    plgndr.plgndr(-778,-617,0 ) ;
  }

  @Test
  public void test25() {
    plgndr.plgndr(784,141,1.0 ) ;
  }

  @Test
  public void test26() {
    plgndr.plgndr(815,383,64.31163621503123 ) ;
  }

  @Test
  public void test27() {
    plgndr.plgndr(817,399,0.0 ) ;
  }

  @Test
  public void test28() {
    plgndr.plgndr(-849,-508,0 ) ;
  }

  @Test
  public void test29() {
    plgndr.plgndr(-866,0,0 ) ;
  }

  @Test
  public void test30() {
    plgndr.plgndr(934,820,1.0 ) ;
  }

  @Test
  public void test31() {
    plgndr.plgndr(-985,157,0 ) ;
  }

  @Test
  public void test32() {
    plgndr.plgndr(990,309,0.0 ) ;
  }
}
