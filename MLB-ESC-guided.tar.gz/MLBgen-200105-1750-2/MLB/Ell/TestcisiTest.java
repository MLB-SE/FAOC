import org.junit.Test;

public class TestcisiTest {

  @Test
  public void test0() {
    frenel.cisi(-0.3929183036333228 ) ;
  }

  @Test
  public void test1() {
    frenel.cisi(-0.7681564031262695 ) ;
  }

  @Test
  public void test2() {
    frenel.cisi(-10.133461165153506 ) ;
  }

  @Test
  public void test3() {
    frenel.cisi(1.7736468838845099 ) ;
  }

  @Test
  public void test4() {
    frenel.cisi(1.9999999999999973 ) ;
  }

  @Test
  public void test5() {
    frenel.cisi(-2.0 ) ;
  }

  @Test
  public void test6() {
    frenel.cisi(2.0 ) ;
  }

  @Test
  public void test7() {
    frenel.cisi(2.220446049250313E-16 ) ;
  }

  @Test
  public void test8() {
    frenel.cisi(-2.710505431213761E-20 ) ;
  }

  @Test
  public void test9() {
    frenel.cisi(-2.996272867003007E-95 ) ;
  }

  @Test
  public void test10() {
    frenel.cisi(31.621433118062924 ) ;
  }

  @Test
  public void test11() {
    frenel.cisi(31.646933665733116 ) ;
  }

  @Test
  public void test12() {
    frenel.cisi(-36.754464654989285 ) ;
  }

  @Test
  public void test13() {
    frenel.cisi(4.256456080400568 ) ;
  }

  @Test
  public void test14() {
    frenel.cisi(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test15() {
    frenel.cisi(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test16() {
    frenel.cisi(6.732866961642728 ) ;
  }

  @Test
  public void test17() {
    frenel.cisi(7.490682167507517E-96 ) ;
  }

  @Test
  public void test18() {
    frenel.cisi(7.636047687024103 ) ;
  }

  @Test
  public void test19() {
    frenel.cisi(-83.82949194425657 ) ;
  }

  @Test
  public void test20() {
    frenel.cisi(83.92418688834854 ) ;
  }

  @Test
  public void test21() {
    frenel.cisi(-8.881784197001252E-16 ) ;
  }

  @Test
  public void test22() {
    frenel.cisi(-9.860761315262648E-32 ) ;
  }

  @Test
  public void test23() {
    frenel.cisi(9.860761315262648E-32 ) ;
  }
}
