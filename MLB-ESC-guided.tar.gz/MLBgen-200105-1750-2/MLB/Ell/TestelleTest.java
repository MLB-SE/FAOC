import org.junit.Test;

public class TestelleTest {

  @Test
  public void test0() {
    ell.elle(12.44070870855843,7.978843463515292 ) ;
  }

  @Test
  public void test1() {
    ell.elle(12.566370620154297,-1.0457546784813214 ) ;
  }

  @Test
  public void test2() {
    ell.elle(12.566406157748895,1.0773180398785284E-4 ) ;
  }

  @Test
  public void test3() {
    ell.elle(-131.94689143585967,0.9999985259893956 ) ;
  }

  @Test
  public void test4() {
    ell.elle(14.13716694496761,-1.0 ) ;
  }

  @Test
  public void test5() {
    ell.elle(15.707963260088583,-26.326506316301604 ) ;
  }

  @Test
  public void test6() {
    ell.elle(-1.5707963267948966,0.848428617653738 ) ;
  }

  @Test
  public void test7() {
    ell.elle(15.707963278863728,-0.46339710504243914 ) ;
  }

  @Test
  public void test8() {
    ell.elle(-18.849555911054043,14.62535525922954 ) ;
  }

  @Test
  public void test9() {
    ell.elle(28.27278667065758,0.5317605322552588 ) ;
  }

  @Test
  public void test10() {
    ell.elle(-28.27433388213709,-91.017806820621 ) ;
  }

  @Test
  public void test11() {
    ell.elle(3.1415525256904795,-1.000000028529116 ) ;
  }

  @Test
  public void test12() {
    ell.elle(31.415926543519134,-1.2053257220019518 ) ;
  }

  @Test
  public void test13() {
    ell.elle(34.16372326752361,-2.606226194577517 ) ;
  }

  @Test
  public void test14() {
    ell.elle(34.55751920538885,0.060066835614116965 ) ;
  }

  @Test
  public void test15() {
    ell.elle(-35.22860298236179,-63.95342830531652 ) ;
  }

  @Test
  public void test16() {
    ell.elle(37.69810533271564,-7.871806971179122E-6 ) ;
  }

  @Test
  public void test17() {
    ell.elle(-37.699111826808675,-0.5086021695486197 ) ;
  }

  @Test
  public void test18() {
    ell.elle(-37.69911187956031,0.9872071729180909 ) ;
  }

  @Test
  public void test19() {
    ell.elle(37.699111903923225,-1.765411023901322 ) ;
  }

  @Test
  public void test20() {
    ell.elle(43.98229714689161,-1.5719869966231244 ) ;
  }

  @Test
  public void test21() {
    ell.elle(-43.982297158510505,1.995026635576415 ) ;
  }

  @Test
  public void test22() {
    ell.elle(45.4893916540949,88.80089512335843 ) ;
  }

  @Test
  public void test23() {
    ell.elle(-45.553093477052,-1.0 ) ;
  }

  @Test
  public void test24() {
    ell.elle(45.553094192483606,1.0 ) ;
  }

  @Test
  public void test25() {
    ell.elle(47.123889809052166,-1.4976431816628435 ) ;
  }

  @Test
  public void test26() {
    ell.elle(-47.30941086960883,-5.421268242595757 ) ;
  }

  @Test
  public void test27() {
    ell.elle(-61.67058485817996,0.9383752648686254 ) ;
  }

  @Test
  public void test28() {
    ell.elle(-62.831853068220404,2.060908891989788 ) ;
  }

  @Test
  public void test29() {
    ell.elle(62.83185308104809,-2.0938506962266388 ) ;
  }

  @Test
  public void test30() {
    ell.elle(6.283185309369691,-0.4580429264131052 ) ;
  }

  @Test
  public void test31() {
    ell.elle(62.83799354120403,-0.3636262234608971 ) ;
  }

  @Test
  public void test32() {
    ell.elle(-62.989695447393586,-66.28500995065716 ) ;
  }

  @Test
  public void test33() {
    ell.elle(-64.40264939002829,-0.9251338725185148 ) ;
  }

  @Test
  public void test34() {
    ell.elle(-65.97344572527314,-19.24285012049181 ) ;
  }

  @Test
  public void test35() {
    ell.elle(-66.14516166656136,3.5698663549589753 ) ;
  }

  @Test
  public void test36() {
    ell.elle(-68.98857848320905,7.928761336249719 ) ;
  }

  @Test
  public void test37() {
    ell.elle(69.13497928917944,50.15148587305493 ) ;
  }

  @Test
  public void test38() {
    ell.elle(-73.82742736987885,-1.0 ) ;
  }

  @Test
  public void test39() {
    ell.elle(-75.39822365690205,-0.8197017782695835 ) ;
  }

  @Test
  public void test40() {
    ell.elle(75.39822376813949,1.768024918715989 ) ;
  }

  @Test
  public void test41() {
    ell.elle(-76.96902001294994,1.0 ) ;
  }

  @Test
  public void test42() {
    ell.elle(-78.53981633487771,1.7881277789261303 ) ;
  }

  @Test
  public void test43() {
    ell.elle(7.853981633974483,-0.9631334680618033 ) ;
  }

  @Test
  public void test44() {
    ell.elle(-78.53984592749848,-1.000000023188686 ) ;
  }

  @Test
  public void test45() {
    ell.elle(-80.11061266937885,0.58422258996666 ) ;
  }

  @Test
  public void test46() {
    ell.elle(81.68140908382782,-0.9573851656103133 ) ;
  }

  @Test
  public void test47() {
    ell.elle(81.86256631103609,-0.9448121293887075 ) ;
  }

  @Test
  public void test48() {
    ell.elle(87.96457978068399,0.001112350083059131 ) ;
  }

  @Test
  public void test49() {
    ell.elle(91.10618417026815,-1.000006749002343 ) ;
  }

  @Test
  public void test50() {
    ell.elle(91.1061869711645,0.8766940998882818 ) ;
  }

  @Test
  public void test51() {
    ell.elle(97.38937226946405,1.623658043605028 ) ;
  }

  @Test
  public void test52() {
    ell.elle(-97.3985130013026,-25.367094865397746 ) ;
  }
}
