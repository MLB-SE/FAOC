import org.junit.Test;

public class TestellfTest {

  @Test
  public void test0() {
    ell.ellf(-10.99557429553549,-1.0 ) ;
  }

  @Test
  public void test1() {
    ell.ellf(12.566370614497885,-6.824932824667561 ) ;
  }

  @Test
  public void test2() {
    ell.ellf(-15.7079632662457,-26.391213922754577 ) ;
  }

  @Test
  public void test3() {
    ell.ellf(-18.849555917308685,0.06776883215465546 ) ;
  }

  @Test
  public void test4() {
    ell.ellf(19.529665244996238,0.6730335708547273 ) ;
  }

  @Test
  public void test5() {
    ell.ellf(-21.912019176695537,-12.65072602109351 ) ;
  }

  @Test
  public void test6() {
    ell.ellf(-21.991148592499172,0.8503649539927953 ) ;
  }

  @Test
  public void test7() {
    ell.ellf(24.90952613515421,-1.2988132459087751 ) ;
  }

  @Test
  public void test8() {
    ell.ellf(25.132741222285183,1.5904453054614114 ) ;
  }

  @Test
  public void test9() {
    ell.ellf(29.845130201201165,1.0 ) ;
  }

  @Test
  public void test10() {
    ell.ellf(-29.845130219398417,-0.7115252195304066 ) ;
  }

  @Test
  public void test11() {
    ell.ellf(-31.400782655892257,-23.151678131935256 ) ;
  }

  @Test
  public void test12() {
    ell.ellf(-3.141592652971481,17.921682910459094 ) ;
  }

  @Test
  public void test13() {
    ell.ellf(-3.141597541078837,5.301762543210723E-4 ) ;
  }

  @Test
  public void test14() {
    ell.ellf(-34.5543093510009,-0.8842546904092595 ) ;
  }

  @Test
  public void test15() {
    ell.ellf(-34.55751918963649,-18.817492859450496 ) ;
  }

  @Test
  public void test16() {
    ell.ellf(34.55751921685013,0.28826350141671386 ) ;
  }

  @Test
  public void test17() {
    ell.ellf(-36.02776702761965,-79.08297627693042 ) ;
  }

  @Test
  public void test18() {
    ell.ellf(3.9273591580807974E-9,100.0 ) ;
  }

  @Test
  public void test19() {
    ell.ellf(-43.77958838444415,97.47947727441061 ) ;
  }

  @Test
  public void test20() {
    ell.ellf(43.969892387774806,5.773603067813739E-7 ) ;
  }

  @Test
  public void test21() {
    ell.ellf(-43.98229640923871,-1.0001041761854648 ) ;
  }

  @Test
  public void test22() {
    ell.ellf(-47.123890150469634,0.8802403855591782 ) ;
  }

  @Test
  public void test23() {
    ell.ellf(-50.26548246687904,-0.43072316048947246 ) ;
  }

  @Test
  public void test24() {
    ell.ellf(-53.40707510780401,3.2147037808813224 ) ;
  }

  @Test
  public void test25() {
    ell.ellf(58.119464091411174,1.0 ) ;
  }

  @Test
  public void test26() {
    ell.ellf(59.69026040981943,-18.8029743051173 ) ;
  }

  @Test
  public void test27() {
    ell.ellf(-59.69026041324452,-4.1238279036207075 ) ;
  }

  @Test
  public void test28() {
    ell.ellf(62.80600142415067,38.686562923406775 ) ;
  }

  @Test
  public void test29() {
    ell.ellf(-65.97344572534415,32.7383032031824 ) ;
  }

  @Test
  public void test30() {
    ell.ellf(-65.97344585312621,-0.9796204351481617 ) ;
  }

  @Test
  public void test31() {
    ell.ellf(69.11503836926094,0.3980598923318128 ) ;
  }

  @Test
  public void test32() {
    ell.ellf(71.00868080038873,30.502560835932826 ) ;
  }

  @Test
  public void test33() {
    ell.ellf(71.94704313413327,3.282281251606154 ) ;
  }

  @Test
  public void test34() {
    ell.ellf(72.25663101935332,-0.5100561578084779 ) ;
  }

  @Test
  public void test35() {
    ell.ellf(-75.39822361588584,-5.3788694558136925 ) ;
  }

  @Test
  public void test36() {
    ell.ellf(75.39822367427338,-1.6404563580827412 ) ;
  }

  @Test
  public void test37() {
    ell.ellf(-75.39822368842556,1.0003374555910403 ) ;
  }

  @Test
  public void test38() {
    ell.ellf(75.8007180284406,-2.5528792567070218 ) ;
  }

  @Test
  public void test39() {
    ell.ellf(-76.9690200121194,0.9568212558625976 ) ;
  }

  @Test
  public void test40() {
    ell.ellf(7.853981633974483,0.739462260402309 ) ;
  }

  @Test
  public void test41() {
    ell.ellf(-84.8230016462872,29.777726660703074 ) ;
  }

  @Test
  public void test42() {
    ell.ellf(87.96461567009003,0.9999999822087691 ) ;
  }

  @Test
  public void test43() {
    ell.ellf(-91.10636804554024,-5.2257723565619744E-5 ) ;
  }

  @Test
  public void test44() {
    ell.ellf(92.757608052193,0.41347932783633823 ) ;
  }

  @Test
  public void test45() {
    ell.ellf(97.38937226138661,-48.48729166030141 ) ;
  }

  @Test
  public void test46() {
    ell.ellf(-97.39871955185227,0.7269143143939436 ) ;
  }

  @Test
  public void test47() {
    ell.ellf(-97.40662738687335,-1.0000000000002323 ) ;
  }

  @Test
  public void test48() {
    ell.ellf(-98.96016858807849,-0.18584718589962787 ) ;
  }
}
