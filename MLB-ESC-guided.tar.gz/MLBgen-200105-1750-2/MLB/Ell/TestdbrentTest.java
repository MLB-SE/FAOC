import org.junit.Test;

public class TestdbrentTest {

  @Test
  public void test0() {
    ell.dbrent(0.0,0.0,0.0,0 ) ;
  }

  @Test
  public void test1() {
    ell.dbrent(-100.0,0.0,-100.0,0 ) ;
  }

  @Test
  public void test2() {
    ell.dbrent(-100.0,0.0,100.0,0 ) ;
  }

  @Test
  public void test3() {
    ell.dbrent(10.338501689046893,0,10.338501689046893,0 ) ;
  }

  @Test
  public void test4() {
    ell.dbrent(1.2378326320295083,1.2378326320295083,1.2378326320295083,0 ) ;
  }

  @Test
  public void test5() {
    ell.dbrent(128.4822710336384,79.04685918179183,61.18457374933297,0 ) ;
  }

  @Test
  public void test6() {
    ell.dbrent(12.961662028896878,0,12.961662028896876,0 ) ;
  }

  @Test
  public void test7() {
    ell.dbrent(13.092990977980328,0,13.09299097798033,0 ) ;
  }

  @Test
  public void test8() {
    ell.dbrent(-1.3355100193324994,0.0,12.280849657709394,0 ) ;
  }

  @Test
  public void test9() {
    ell.dbrent(-15.45072255695953,3.2433159868060866,21.937354530571703,0 ) ;
  }

  @Test
  public void test10() {
    ell.dbrent(-15.513491032986073,0,-15.513491032986071,0 ) ;
  }

  @Test
  public void test11() {
    ell.dbrent(-15.753375718692666,0,4.333690207615561,0 ) ;
  }

  @Test
  public void test12() {
    ell.dbrent(1.7824441328745E-16,0.0,1.7824441328745E-16,0 ) ;
  }

  @Test
  public void test13() {
    ell.dbrent(19.587294994902948,-40.03946311135596,-97.51913928567978,0 ) ;
  }

  @Test
  public void test14() {
    ell.dbrent(-20.517053438959323,0.0,-31.872284118482973,0 ) ;
  }

  @Test
  public void test15() {
    ell.dbrent(22.63443255350714,0,22.634432553507143,0 ) ;
  }

  @Test
  public void test16() {
    ell.dbrent(-25.48377979138082,0,-25.483779791380815,0 ) ;
  }

  @Test
  public void test17() {
    ell.dbrent(33.75927409433237,-13.166443953048686,33.75927409433237,0 ) ;
  }

  @Test
  public void test18() {
    ell.dbrent(-33.89521154039963,-40.29831618740556,-56.20857554385701,0 ) ;
  }

  @Test
  public void test19() {
    ell.dbrent(-38.23000995962158,0.0,-99.17598902936224,0 ) ;
  }

  @Test
  public void test20() {
    ell.dbrent(-39.85146024148672,-9.727970631120078,-39.85146024148672,0 ) ;
  }

  @Test
  public void test21() {
    ell.dbrent(-4.269069989267334,0,-4.269069989267335,0 ) ;
  }

  @Test
  public void test22() {
    ell.dbrent(-47.38192208013785,-47.38192208013785,-47.38192208013785,0 ) ;
  }

  @Test
  public void test23() {
    ell.dbrent(-48.14219030987567,59.787324429509056,-0.1602706135557952,0 ) ;
  }

  @Test
  public void test24() {
    ell.dbrent(-48.77417814083253,0.0,39.10178175530859,0 ) ;
  }

  @Test
  public void test25() {
    ell.dbrent(-49.87448394576286,0,-8.629000851420528,0 ) ;
  }

  @Test
  public void test26() {
    ell.dbrent(5.113395331141428,0.17421531058813855,5.113395331141428,0 ) ;
  }

  @Test
  public void test27() {
    ell.dbrent(51.46846652782324,-4.882471675175072,-61.23340987817338,0 ) ;
  }

  @Test
  public void test28() {
    ell.dbrent(5.239562839947752,0,5.239562839947752,0 ) ;
  }

  @Test
  public void test29() {
    ell.dbrent(-52.78682457933199,71.30350855588622,-78.1088823634477,0 ) ;
  }

  @Test
  public void test30() {
    ell.dbrent(53.74532129746166,30.077939731874636,6.410558166287615,0 ) ;
  }

  @Test
  public void test31() {
    ell.dbrent(-55.0816667192979,0.0,12.331224747574161,0 ) ;
  }

  @Test
  public void test32() {
    ell.dbrent(5.509214410811197,47.28562691974676,94.92694286049743,0 ) ;
  }

  @Test
  public void test33() {
    ell.dbrent(64.56118998155458,74.35611508681583,-36.634697710317624,0 ) ;
  }

  @Test
  public void test34() {
    ell.dbrent(-64.66999947560781,-58.56902729689908,-64.66999947560781,0 ) ;
  }

  @Test
  public void test35() {
    ell.dbrent(67.17957448634826,0,-46.42446292787908,0 ) ;
  }

  @Test
  public void test36() {
    ell.dbrent(-67.48921158638667,30.25072280393016,-67.48921158638667,0 ) ;
  }

  @Test
  public void test37() {
    ell.dbrent(70.94975555669978,-86.47523629575433,85.11383587471627,0 ) ;
  }

  @Test
  public void test38() {
    ell.dbrent(76.67942976920293,0.0,4.501499451901076,0 ) ;
  }

  @Test
  public void test39() {
    ell.dbrent(-78.83514706047913,-11.81635804881983,55.20243096283947,0 ) ;
  }

  @Test
  public void test40() {
    ell.dbrent(-85.14753859109048,-82.13015174625605,67.51932350377194,0 ) ;
  }

  @Test
  public void test41() {
    ell.dbrent(85.34940312669369,66.93614794864035,85.34940312669369,0 ) ;
  }

  @Test
  public void test42() {
    ell.dbrent(88.76544575420101,0,-95.67132229236417,0 ) ;
  }

  @Test
  public void test43() {
    ell.dbrent(-91.8989065494147,-4.433695094838711,3.1724019984970937,0 ) ;
  }

  @Test
  public void test44() {
    ell.dbrent(95.87971758636489,0.0,-95.87971758636489,0 ) ;
  }

  @Test
  public void test45() {
    ell.dbrent(-96.3394051799575,33.05206766034797,41.07697225476343,0 ) ;
  }

  @Test
  public void test46() {
    ell.dbrent(98.59091014619185,-34.14335281070397,-23.21106016002625,0 ) ;
  }
}
