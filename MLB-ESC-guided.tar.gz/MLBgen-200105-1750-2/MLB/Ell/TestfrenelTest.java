import org.junit.Test;

public class TestfrenelTest {

  @Test
  public void test0() {
    frenel.frenel(0.004260348341176723 ) ;
  }

  @Test
  public void test1() {
    frenel.frenel(-0.08736040818884838 ) ;
  }

  @Test
  public void test2() {
    frenel.frenel(0.3582239498058186 ) ;
  }

  @Test
  public void test3() {
    frenel.frenel(-0.5693119831642122 ) ;
  }

  @Test
  public void test4() {
    frenel.frenel(0.8278251780871817 ) ;
  }

  @Test
  public void test5() {
    frenel.frenel(-1.3573901577430263 ) ;
  }

  @Test
  public void test6() {
    frenel.frenel(-1.5 ) ;
  }

  @Test
  public void test7() {
    frenel.frenel(1.5 ) ;
  }

  @Test
  public void test8() {
    frenel.frenel(1.9721522630525295E-31 ) ;
  }

  @Test
  public void test9() {
    frenel.frenel(-2.220446049250313E-16 ) ;
  }

  @Test
  public void test10() {
    frenel.frenel(2.220446049250313E-16 ) ;
  }

  @Test
  public void test11() {
    frenel.frenel(30.047562977133254 ) ;
  }

  @Test
  public void test12() {
    frenel.frenel(3.1223475235751437 ) ;
  }

  @Test
  public void test13() {
    frenel.frenel(-3.944304526105059E-31 ) ;
  }

  @Test
  public void test14() {
    frenel.frenel(-45.123363799835325 ) ;
  }

  @Test
  public void test15() {
    frenel.frenel(4.930380657631324E-32 ) ;
  }

  @Test
  public void test16() {
    frenel.frenel(56.853009511418406 ) ;
  }

  @Test
  public void test17() {
    frenel.frenel(-61.52209687728782 ) ;
  }

  @Test
  public void test18() {
    frenel.frenel(-68.87089986701824 ) ;
  }

  @Test
  public void test19() {
    frenel.frenel(9.430991276115392 ) ;
  }
}
