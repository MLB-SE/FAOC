import org.junit.Test;

public class TestsphbesTest {

  @Test
  public void test0() {
    airy.sphbes(0,4.324102350069438 ) ;
  }

  @Test
  public void test1() {
    airy.sphbes(0,46.09809762904641 ) ;
  }

  @Test
  public void test2() {
    airy.sphbes(0,46.12725201696036 ) ;
  }

  @Test
  public void test3() {
    airy.sphbes(0,86.74718737459023 ) ;
  }

  @Test
  public void test4() {
    airy.sphbes(0,98.04896971790379 ) ;
  }

  @Test
  public void test5() {
    airy.sphbes(0,9.937704156974547 ) ;
  }

  @Test
  public void test6() {
    airy.sphbes(103,10.988508992584926 ) ;
  }

  @Test
  public void test7() {
    airy.sphbes(-107,-33.32902982948353 ) ;
  }

  @Test
  public void test8() {
    airy.sphbes(111,0 ) ;
  }

  @Test
  public void test9() {
    airy.sphbes(-122,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test10() {
    airy.sphbes(1242,0.0 ) ;
  }

  @Test
  public void test11() {
    airy.sphbes(1299,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test12() {
    airy.sphbes(-1,33.56322255377978 ) ;
  }

  @Test
  public void test13() {
    airy.sphbes(134,-4.9E-324 ) ;
  }

  @Test
  public void test14() {
    airy.sphbes(-14,2.0 ) ;
  }

  @Test
  public void test15() {
    airy.sphbes(152,0.0 ) ;
  }

  @Test
  public void test16() {
    airy.sphbes(-187,0 ) ;
  }

  @Test
  public void test17() {
    airy.sphbes(-190,0.0 ) ;
  }

  @Test
  public void test18() {
    airy.sphbes(-1,9.00279025708653 ) ;
  }

  @Test
  public void test19() {
    airy.sphbes(220,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test20() {
    airy.sphbes(255,1.9721522630525295E-31 ) ;
  }

  @Test
  public void test21() {
    airy.sphbes(-29,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test22() {
    airy.sphbes(3125,2.0000000000000004 ) ;
  }

  @Test
  public void test23() {
    airy.sphbes(324,1.33E-322 ) ;
  }

  @Test
  public void test24() {
    airy.sphbes(-327,-4.2351647362715017E-22 ) ;
  }

  @Test
  public void test25() {
    airy.sphbes(-348,0.0 ) ;
  }

  @Test
  public void test26() {
    airy.sphbes(-351,92.52798425866462 ) ;
  }

  @Test
  public void test27() {
    airy.sphbes(-372,2.0000000000000004 ) ;
  }

  @Test
  public void test28() {
    airy.sphbes(-381,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test29() {
    airy.sphbes(381,8.470329472543003E-22 ) ;
  }

  @Test
  public void test30() {
    airy.sphbes(393,8.4E-323 ) ;
  }

  @Test
  public void test31() {
    airy.sphbes(394,-1.265E-321 ) ;
  }

  @Test
  public void test32() {
    airy.sphbes(410,78.34468474735044 ) ;
  }

  @Test
  public void test33() {
    airy.sphbes(432,-4.9E-324 ) ;
  }

  @Test
  public void test34() {
    airy.sphbes(465,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test35() {
    airy.sphbes(501,2.000000000000001 ) ;
  }

  @Test
  public void test36() {
    airy.sphbes(550,2.0E-323 ) ;
  }

  @Test
  public void test37() {
    airy.sphbes(565,0.0 ) ;
  }

  @Test
  public void test38() {
    airy.sphbes(-572,-73.10027545955855 ) ;
  }

  @Test
  public void test39() {
    airy.sphbes(603,-79.04962682775998 ) ;
  }

  @Test
  public void test40() {
    airy.sphbes(67,0.0 ) ;
  }

  @Test
  public void test41() {
    airy.sphbes(698,-1.8E-322 ) ;
  }

  @Test
  public void test42() {
    airy.sphbes(-778,0.0 ) ;
  }

  @Test
  public void test43() {
    airy.sphbes(815,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test44() {
    airy.sphbes(-831,7.372880313518465 ) ;
  }

  @Test
  public void test45() {
    airy.sphbes(-864,1.9999999999999991 ) ;
  }

  @Test
  public void test46() {
    airy.sphbes(887,57.76107635855544 ) ;
  }

  @Test
  public void test47() {
    airy.sphbes(910,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test48() {
    airy.sphbes(921,4.9E-324 ) ;
  }

  @Test
  public void test49() {
    airy.sphbes(940,-55.25653528529373 ) ;
  }

  @Test
  public void test50() {
    airy.sphbes(-978,58.79826381623786 ) ;
  }

  @Test
  public void test51() {
    airy.sphbes(99,-28.390180110707448 ) ;
  }
}
