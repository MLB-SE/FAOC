import org.junit.Test;

public class TestAiryTest {

  @Test
  public void test0() {
    airy.main_airy(-10.047139761574854 ) ;
  }

  @Test
  public void test1() {
    airy.main_airy(1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2() {
    airy.main_airy(-1.7290327071306454E-223 ) ;
  }

  @Test
  public void test3() {
    airy.main_airy(2.1612908839133068E-224 ) ;
  }

  @Test
  public void test4() {
    airy.main_airy(-2.220446049250313E-16 ) ;
  }

  @Test
  public void test5() {
    airy.main_airy(-2.465190328815662E-32 ) ;
  }

  @Test
  public void test6() {
    airy.main_airy(2.465190328815662E-32 ) ;
  }

  @Test
  public void test7() {
    airy.main_airy(35.498717587982895 ) ;
  }

  @Test
  public void test8() {
    airy.main_airy(-3.944304526105059E-31 ) ;
  }

  @Test
  public void test9() {
    airy.main_airy(44.31238982125117 ) ;
  }

  @Test
  public void test10() {
    airy.main_airy(4.930380657631324E-32 ) ;
  }

  @Test
  public void test11() {
    airy.main_airy(-49.82864008718215 ) ;
  }

  @Test
  public void test12() {
    airy.main_airy(5.551115123125783E-17 ) ;
  }

  @Test
  public void test13() {
    airy.main_airy(61.200917765235346 ) ;
  }

  @Test
  public void test14() {
    airy.main_airy(-61.51840373834263 ) ;
  }

  @Test
  public void test15() {
    airy.main_airy(-64.50544114254737 ) ;
  }

  @Test
  public void test16() {
    airy.main_airy(-90.259141173725 ) ;
  }

  @Test
  public void test17() {
    airy.main_airy(-9.860761315262648E-32 ) ;
  }
}
