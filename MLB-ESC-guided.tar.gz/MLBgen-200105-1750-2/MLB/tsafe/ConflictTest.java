import org.junit.Test;

public class ConflictTest {

  @Test
  public void test0() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,0.0 ) ;
  }

  @Test
  public void test2() {
    tsafe.Conflict.snippet(0.0,0.0,0,0,0,0,-85.5503113879306 ) ;
  }

  @Test
  public void test3() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,-41.16507504288828 ) ;
  }

  @Test
  public void test4() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,4.1248662009693895 ) ;
  }

  @Test
  public void test5() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,-53.09509577992024 ) ;
  }

  @Test
  public void test6() {
    tsafe.Conflict.snippet(0.0,0,0,0,0,0,-8.289046E-317 ) ;
  }

  @Test
  public void test7() {
    tsafe.Conflict.snippet(0.0,100.0,-1.5641961280848023E-15,0,0,0,90.00000000000003 ) ;
  }

  @Test
  public void test8() {
    tsafe.Conflict.snippet(0.0,100.0,1.949403932622763E-52,0,0,0,90.0 ) ;
  }

  @Test
  public void test9() {
    tsafe.Conflict.snippet(0.0,-100.0,6.937261490223874E-32,0,0,0,90.0 ) ;
  }

  @Test
  public void test10() {
    tsafe.Conflict.snippet(0.0,-29.213912296866567,56.839905991270605,-71.74349458147282,37.393188078380525,31.585384763867758,43.17222476615221 ) ;
  }

  @Test
  public void test11() {
    tsafe.Conflict.snippet(0.0,-48.86036414924769,6.447861154712531E-59,0,0,0,90.0 ) ;
  }

  @Test
  public void test12() {
    tsafe.Conflict.snippet(0.0,5.367355144244897,-59.26260608704061,19.466724076613914,-25.263916735514854,-10.994772440534192,32.35629268976851 ) ;
  }

  @Test
  public void test13() {
    tsafe.Conflict.snippet(0.0,57.838098460831254,-2.987877617282084,978.9680330363391,-199.05423977893344,-188.01529793267417,-9.906585382987515 ) ;
  }

  @Test
  public void test14() {
    tsafe.Conflict.snippet(0.0,5.917766244837733,-47.12320444875494,0,0,0,54.97504236327022 ) ;
  }

  @Test
  public void test15() {
    tsafe.Conflict.snippet(0.0,-83.03288589345706,-51.57034051366589,0.8904299941814142,0.8197066282698593,-28.340089940450948,-37.35238952962544 ) ;
  }

  @Test
  public void test16() {
    tsafe.Conflict.snippet(0.0,93.80264424825032,-100.0,-0.7892934610644895,-1.8376658652543014,17.89448841933337,100.0 ) ;
  }

  @Test
  public void test17() {
    tsafe.Conflict.snippet(0.0,-9.9749272122517,0,0,0,0,67.21251277991794 ) ;
  }

  @Test
  public void test18() {
    tsafe.Conflict.snippet(100.0,0,0,0,0,0,-7.903E-320 ) ;
  }

  @Test
  public void test19() {
    tsafe.Conflict.snippet(100.0,34.923131537458346,8.402230721969234E-27,0,0,0,-90.0 ) ;
  }

  @Test
  public void test20() {
    tsafe.Conflict.snippet(100.0,77.23087690323098,61.06336871743008,-150.33029611724288,74.64262005336926,-31.626833810853697,0.0022418644167601087 ) ;
  }

  @Test
  public void test21() {
    tsafe.Conflict.snippet(-100.0,-82.23383637876549,3.110690125042439E-28,0,0,0,-90.0 ) ;
  }

  @Test
  public void test22() {
    tsafe.Conflict.snippet(-100.0,-94.15471057821081,-1.0451184772087712E-70,0,0,0,90.0 ) ;
  }

  @Test
  public void test23() {
    tsafe.Conflict.snippet(-103.185807462,-100.0,7.787517460121491E-12,0,0,0,-90.0 ) ;
  }

  @Test
  public void test24() {
    tsafe.Conflict.snippet(-103.27840563374029,94.66528002294818,127.48987050234916,-91.53846575503917,994.5237595182709,100.0,28.071382352378123 ) ;
  }

  @Test
  public void test25() {
    tsafe.Conflict.snippet(1.3322676295501878E-15,-13.917646558240165,26.754234218838434,982.0874284052248,-183.0554432939398,-162.63271562785224,26.524999347268775 ) ;
  }

  @Test
  public void test26() {
    tsafe.Conflict.snippet(13.359515528738399,59.11056002398118,0,0,0,0,-46.09067931675492 ) ;
  }

  @Test
  public void test27() {
    tsafe.Conflict.snippet(141.79122064688855,170.87799033521173,-6.089659032902843,-978.3083339373316,-200.1829075485042,26.375242128129276,62.23868994528419 ) ;
  }

  @Test
  public void test28() {
    tsafe.Conflict.snippet(1.5099049396727187,-99.22516392635843,56.181659489035425,-1.7087727898422624,1.0385438047159254,24.524249257490546,-84.43876009217219 ) ;
  }

  @Test
  public void test29() {
    tsafe.Conflict.snippet(1.53E-322,0,0,0,0,0,99.89284285618609 ) ;
  }

  @Test
  public void test30() {
    tsafe.Conflict.snippet(16.37372077691509,-100.0,-9.998678520860127E-97,0,0,0,-90.0 ) ;
  }

  @Test
  public void test31() {
    tsafe.Conflict.snippet(167.59418919543225,-65.8219268256237,-99.97175917779795,999.1686299495017,-2.3328133460735447,50.6733376417657,-32.639497531990116 ) ;
  }

  @Test
  public void test32() {
    tsafe.Conflict.snippet(-17.03458680872648,100.0,-55.366583549645306,-61.02404477003269,77.73085640541532,-50.17956832856089,0.004050663322473946 ) ;
  }

  @Test
  public void test33() {
    tsafe.Conflict.snippet(-1.7763568394002505E-15,0,0,0,0,0,100.0 ) ;
  }

  @Test
  public void test34() {
    tsafe.Conflict.snippet(18.006955643889967,20.598211378656856,-130.08979947459562,-1023.6146234330254,-7.991894201357894,100.0,100.0 ) ;
  }

  @Test
  public void test35() {
    tsafe.Conflict.snippet(-1.83E-322,0,0,0,0,0,39.413267586037065 ) ;
  }

  @Test
  public void test36() {
    tsafe.Conflict.snippet(-1.8481920688000717E-6,-55.744668437152725,48.43832438483891,-989.6163840171873,-161.81703888397706,-68.33245600297153,30.26417030396948 ) ;
  }

  @Test
  public void test37() {
    tsafe.Conflict.snippet(-194.87425037544853,-99.5628261360966,-2.738535577686676,76.22223202288676,996.0214437610339,84.5490476240756,41.6192389631471 ) ;
  }

  @Test
  public void test38() {
    tsafe.Conflict.snippet(1.9E-322,0,0,0,0,0,100.0 ) ;
  }

  @Test
  public void test39() {
    tsafe.Conflict.snippet(-2.0E-322,0,0,0,0,0,100.0 ) ;
  }

  @Test
  public void test40() {
    tsafe.Conflict.snippet(-21.07580646746929,88.99602579425377,0,0,0,0,-41.75562731411808 ) ;
  }

  @Test
  public void test41() {
    tsafe.Conflict.snippet(21.127919482705764,0.0,0,0,0,0,26.501925121500335 ) ;
  }

  @Test
  public void test42() {
    tsafe.Conflict.snippet(-22.05957696198643,0,0,0,0,0,2.8E-322 ) ;
  }

  @Test
  public void test43() {
    tsafe.Conflict.snippet(-22.09066621648607,42.809567472382525,-89.59403673543542,-78.59638582967672,-63.901828981256294,53.97601705908568,32.445339914771495 ) ;
  }

  @Test
  public void test44() {
    tsafe.Conflict.snippet(2.220446049250313E-16,0,0,0,0,0,-100.0 ) ;
  }

  @Test
  public void test45() {
    tsafe.Conflict.snippet(229.66600851354474,-96.9821586298291,-61.52734750840045,-212.71717330953416,-976.020457209729,-67.91336401319994,-38.95522314850653 ) ;
  }

  @Test
  public void test46() {
    tsafe.Conflict.snippet(2.636175600764181E-31,51.87968974661924,104.22857491582127,-455.84267719376857,959.6916233594652,-57.001987241676076,-117.68808045030565 ) ;
  }

  @Test
  public void test47() {
    tsafe.Conflict.snippet(27.154186622917507,-23.12691290957467,-51.471372489671,-37.99962724085098,67.06453707624334,-78.57937190266517,94.55675088768879 ) ;
  }

  @Test
  public void test48() {
    tsafe.Conflict.snippet(2.8E-322,0,0,0,0,0,76.66182022026916 ) ;
  }

  @Test
  public void test49() {
    tsafe.Conflict.snippet(31.46295654291623,0,0,0,0,0,27.772312123637732 ) ;
  }

  @Test
  public void test50() {
    tsafe.Conflict.snippet(-31.793935248885248,-80.05365488517123,-26.060800853145835,0,0,0,-94.13841368507477 ) ;
  }

  @Test
  public void test51() {
    tsafe.Conflict.snippet(-32.34781781040748,92.93181417055777,72.7261159834116,-147.147246808681,987.8806831428134,7.254594532293282,163.63906032532506 ) ;
  }

  @Test
  public void test52() {
    tsafe.Conflict.snippet(3.2379E-319,0,0,0,0,0,-95.83762883991021 ) ;
  }

  @Test
  public void test53() {
    tsafe.Conflict.snippet(-37.88013893790787,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test54() {
    tsafe.Conflict.snippet(-3.8E-322,0,0,0,0,0,-100.0 ) ;
  }

  @Test
  public void test55() {
    tsafe.Conflict.snippet(39.29247914318722,0,0,0,0,0,14.941564945251145 ) ;
  }

  @Test
  public void test56() {
    tsafe.Conflict.snippet(-39.63076004497341,100.0,67.08509915255738,1.8120424460188866,-1.3837187903472108,15.050295782397468,-20.19587196454387 ) ;
  }

  @Test
  public void test57() {
    tsafe.Conflict.snippet(-3.982226839363865E-7,-4923.176800845472,-2789.6722510398527,936.082665472001,348.92175606456794,136.2712927880683,0.12588737605383216 ) ;
  }

  @Test
  public void test58() {
    tsafe.Conflict.snippet(41.92077168845001,0,0,0,0,0,-3.16E-322 ) ;
  }

  @Test
  public void test59() {
    tsafe.Conflict.snippet(4.440892098500626E-16,0,0,0,0,0,62.228293851621714 ) ;
  }

  @Test
  public void test60() {
    tsafe.Conflict.snippet(-4.440892098500626E-16,0,0,0,0,0,-69.28336272830317 ) ;
  }

  @Test
  public void test61() {
    tsafe.Conflict.snippet(-4.440892098500626E-16,54.51758853693089,77.75760136229974,-234.8607634266795,-1028.3359632507058,-55.89401765348668,77.00122365080739 ) ;
  }

  @Test
  public void test62() {
    tsafe.Conflict.snippet(-4.524704977017984E-6,1226.9471059245388,-1360.2296562018234,995.7036931575052,81.10753963869257,60.92643308141692,0.0601857085854966 ) ;
  }

  @Test
  public void test63() {
    tsafe.Conflict.snippet(46.76448542523704,0,0,0,0,0,-73.98735314346708 ) ;
  }

  @Test
  public void test64() {
    tsafe.Conflict.snippet(47.16995543784938,123.10780955827524,71.61718426011987,988.9368136337187,145.5669373951755,-21.368862261437613,-162.16422269840308 ) ;
  }

  @Test
  public void test65() {
    tsafe.Conflict.snippet(-50.12466488330545,-82.83179794595236,-78.04550887907013,-29.334211565595766,-36.37328174928089,-35.48025771636705,17.286150005508432 ) ;
  }

  @Test
  public void test66() {
    tsafe.Conflict.snippet(51.30690337678996,0,0,0,0,0,0 ) ;
  }

  @Test
  public void test67() {
    tsafe.Conflict.snippet(-5.719042456052392,0.0,0,0,0,0,-12.038578379083447 ) ;
  }

  @Test
  public void test68() {
    tsafe.Conflict.snippet(62.89732926706415,0,0,0,0,0,0.0 ) ;
  }

  @Test
  public void test69() {
    tsafe.Conflict.snippet(6.329410983332835E-5,-173.36115173806638,38.56657097619947,-38.3719899180613,1033.5818153313407,6.301189260775871,17.321918557308848 ) ;
  }

  @Test
  public void test70() {
    tsafe.Conflict.snippet(-6.47582E-319,0,0,0,0,0,-6.730833718962301 ) ;
  }

  @Test
  public void test71() {
    tsafe.Conflict.snippet(-66.07070031220819,0,0,0,0,0,0.0 ) ;
  }

  @Test
  public void test72() {
    tsafe.Conflict.snippet(-66.16957046387911,-41.78286062363894,61.23962775273755,5.289963711394947,-8.703453890775226,-0.3341810959497167,-0.34206643895938393 ) ;
  }

  @Test
  public void test73() {
    tsafe.Conflict.snippet(6.653196604134932E-15,42.06155713054937,185.88100845767968,-48.79612244475168,-1017.2182106438547,-143.56388604588946,87.9763633115804 ) ;
  }

  @Test
  public void test74() {
    tsafe.Conflict.snippet(68.03871060046953,-44.25751049707733,-27.482985008053916,-0.42851251456762024,-1.9548711033020028,47.62910413149998,100.0 ) ;
  }

  @Test
  public void test75() {
    tsafe.Conflict.snippet(-69.57996725153721,0,0,0,0,0,-62.0657307973105 ) ;
  }

  @Test
  public void test76() {
    tsafe.Conflict.snippet(73.05472734785735,-84.56787221597406,-46.90076679488895,3.471972920807076,-60.53599440897464,-15.10024097684905,17.54145618434366 ) ;
  }

  @Test
  public void test77() {
    tsafe.Conflict.snippet(79.35524912739774,-100.0,2.502800345339047E-61,0,0,0,-90.0 ) ;
  }

  @Test
  public void test78() {
    tsafe.Conflict.snippet(-85.57405624208184,0,0,0,0,0,-71.02564935229458 ) ;
  }

  @Test
  public void test79() {
    tsafe.Conflict.snippet(-86.52559807556881,0,0,0,0,0,20.924340237733063 ) ;
  }

  @Test
  public void test80() {
    tsafe.Conflict.snippet(-86.72561024329833,108.38319700315593,111.40205398547111,-954.2064723895608,296.24334307685257,-37.54293191760665,68.45658891948489 ) ;
  }

  @Test
  public void test81() {
    tsafe.Conflict.snippet(-92.10936637010431,-0.44078194544801264,-1.1279809051166012E-60,0,0,0,-90.0 ) ;
  }

  @Test
  public void test82() {
    tsafe.Conflict.snippet(-94.97389609409379,91.36456636404476,40.501846532998606,100.0,-81.14259292353107,85.91623278307102,1.4234820883120627E-4 ) ;
  }

  @Test
  public void test83() {
    tsafe.Conflict.snippet(9.4E-323,0,0,0,0,0,-1.275E-321 ) ;
  }

  @Test
  public void test84() {
    tsafe.Conflict.snippet(-95.2109945712894,0,0,0,0,0,-3.5E-322 ) ;
  }

  @Test
  public void test85() {
    tsafe.Conflict.snippet(97.1149386429721,-44.02472306728556,1.0457509010005026,0,0,0,-44.23047067792854 ) ;
  }

  @Test
  public void test86() {
    tsafe.Conflict.snippet(97.98202561946195,-100.0,-1.7618330308518267E-16,0,0,0,90.00000000000001 ) ;
  }
}
