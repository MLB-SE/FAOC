import org.junit.Test;

public class JpfTargetCubedRootTest {

  @Test
  public void test0() {
    scic.CubedRoot.check(24.998540136119125 ) ;
  }

  @Test
  public void test1() {
    scic.CubedRoot.check(5.263789973714921 ) ;
  }

  @Test
  public void test2() {
    scic.CubedRoot.check(71.87730253672046 ) ;
  }
}
