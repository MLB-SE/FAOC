import org.junit.Test;

public class JpfTargetSimpsonSolverTest {

  @Test
  public void test0() {
    scic.SimpsonSolver.simpson(-34.30847492261218,52.76808658445634 ) ;
  }

  @Test
  public void test1() {
    scic.SimpsonSolver.simpson(-39.31636376362455,24.496638564677607 ) ;
  }

  @Test
  public void test2() {
    scic.SimpsonSolver.simpson(59.80799046358075,-1.460924904208369 ) ;
  }
}
