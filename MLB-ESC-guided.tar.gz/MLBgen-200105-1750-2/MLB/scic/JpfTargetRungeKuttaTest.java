import org.junit.Test;

public class JpfTargetRungeKuttaTest {

  @Test
  public void test0() {
    scic.RungeKutta.rungeKutta(-1.3400898161877421 ) ;
  }

  @Test
  public void test1() {
    scic.RungeKutta.rungeKutta(-21.48045254617601 ) ;
  }

  @Test
  public void test2() {
    scic.RungeKutta.rungeKutta(2687.0257453844383 ) ;
  }

  @Test
  public void test3() {
    scic.RungeKutta.rungeKutta(2706.3521896725356 ) ;
  }

  @Test
  public void test4() {
    scic.RungeKutta.rungeKutta(2725.9096377240394 ) ;
  }

  @Test
  public void test5() {
    scic.RungeKutta.rungeKutta(2733.660719394518 ) ;
  }

  @Test
  public void test6() {
    scic.RungeKutta.rungeKutta(2737.5756503235743 ) ;
  }

  @Test
  public void test7() {
    scic.RungeKutta.rungeKutta(2741.228007517008 ) ;
  }

  @Test
  public void test8() {
    scic.RungeKutta.rungeKutta(2745.90792916831 ) ;
  }

  @Test
  public void test9() {
    scic.RungeKutta.rungeKutta(34.33216847383221 ) ;
  }

  @Test
  public void test10() {
    scic.RungeKutta.rungeKutta(-62.45095880341722 ) ;
  }

  @Test
  public void test11() {
    scic.RungeKutta.rungeKutta(75.77577873717419 ) ;
  }

  @Test
  public void test12() {
    scic.RungeKutta.rungeKutta(78.58726180022089 ) ;
  }

  @Test
  public void test13() {
    scic.RungeKutta.rungeKutta(82.8746765111027 ) ;
  }

  @Test
  public void test14() {
    scic.RungeKutta.rungeKutta(86.82660114809158 ) ;
  }

  @Test
  public void test15() {
    scic.RungeKutta.rungeKutta(92.91967342567631 ) ;
  }

  @Test
  public void test16() {
    scic.RungeKutta.rungeKutta(95.42489116075842 ) ;
  }

  @Test
  public void test17() {
    scic.RungeKutta.rungeKutta(96.3304983144304 ) ;
  }
}
