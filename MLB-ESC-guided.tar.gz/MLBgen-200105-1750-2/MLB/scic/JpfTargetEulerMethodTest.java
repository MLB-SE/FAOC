import org.junit.Test;

public class JpfTargetEulerMethodTest {

  @Test
  public void test0() {
    scic.EulerMethod.euler(-18.24878174166011 ) ;
  }

  @Test
  public void test1() {
    scic.EulerMethod.euler(-1.9984834654862764 ) ;
  }

  @Test
  public void test2() {
    scic.EulerMethod.euler(24.67724597835506 ) ;
  }
}
