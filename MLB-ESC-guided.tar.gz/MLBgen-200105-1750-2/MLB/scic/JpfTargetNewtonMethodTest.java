import org.junit.Test;

public class JpfTargetNewtonMethodTest {

  @Test
  public void test0() {
    scic.NewtonMethod.newton(-19.223276882100393,0.027725054913965153 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonMethod.newton(-21.585769713221637,96.20362933318816 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonMethod.newton(-24.75000000000142,0 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonMethod.newton(-32.01312020708065,28.83954429944785 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonMethod.newton(-41.181228510766665,-47.62947744277823 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonMethod.newton(41.69778504444099,0 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonMethod.newton(644.9943431242524,0 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonMethod.newton(-70.81684885362098,-90.45202647078135 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonMethod.newton(72.14441008455623,0 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonMethod.newton(-77.58011838450133,0 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonMethod.newton(-78.51405886894946,2.25463906076412 ) ;
  }
}
