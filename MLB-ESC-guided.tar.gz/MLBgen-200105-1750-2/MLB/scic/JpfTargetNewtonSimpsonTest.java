import org.junit.Test;

public class JpfTargetNewtonSimpsonTest {

  @Test
  public void test0() {
    scic.NewtonSimpson.newton(-0.7459379599575228,0 ) ;
  }

  @Test
  public void test1() {
    scic.NewtonSimpson.newton(0.9801530993604288,0 ) ;
  }

  @Test
  public void test2() {
    scic.NewtonSimpson.newton(-10.79441134256814,0 ) ;
  }

  @Test
  public void test3() {
    scic.NewtonSimpson.newton(1.2665034983711791,0 ) ;
  }

  @Test
  public void test4() {
    scic.NewtonSimpson.newton(16.722071296505987,0 ) ;
  }

  @Test
  public void test5() {
    scic.NewtonSimpson.newton(-19.571819335476604,-48.158943984750735 ) ;
  }

  @Test
  public void test6() {
    scic.NewtonSimpson.newton(-19.647993484572737,-80.47726577679072 ) ;
  }

  @Test
  public void test7() {
    scic.NewtonSimpson.newton(-19.96690790998987,-12.191453323456187 ) ;
  }

  @Test
  public void test8() {
    scic.NewtonSimpson.newton(-22.28103711563068,-47.434993635842446 ) ;
  }

  @Test
  public void test9() {
    scic.NewtonSimpson.newton(-2.317217721035391,0 ) ;
  }

  @Test
  public void test10() {
    scic.NewtonSimpson.newton(-25.856657323505345,-70.99800711200581 ) ;
  }

  @Test
  public void test11() {
    scic.NewtonSimpson.newton(-26.57406225668521,-47.85813120354989 ) ;
  }

  @Test
  public void test12() {
    scic.NewtonSimpson.newton(-27.502305577892344,52.106725587916344 ) ;
  }

  @Test
  public void test13() {
    scic.NewtonSimpson.newton(-30.314436876867717,20.150164235746274 ) ;
  }

  @Test
  public void test14() {
    scic.NewtonSimpson.newton(-33.64815528413587,-87.56829520012055 ) ;
  }

  @Test
  public void test15() {
    scic.NewtonSimpson.newton(-35.11807006592598,0 ) ;
  }

  @Test
  public void test16() {
    scic.NewtonSimpson.newton(36.19776325871001,0 ) ;
  }

  @Test
  public void test17() {
    scic.NewtonSimpson.newton(-3.6951460286910702,33.01682882665895 ) ;
  }

  @Test
  public void test18() {
    scic.NewtonSimpson.newton(75.32170570929654,0 ) ;
  }

  @Test
  public void test19() {
    scic.NewtonSimpson.newton(9.321764995905085,53.848148440846785 ) ;
  }

  @Test
  public void test20() {
    scic.NewtonSimpson.newton(-9.650616940363093,0 ) ;
  }
}
