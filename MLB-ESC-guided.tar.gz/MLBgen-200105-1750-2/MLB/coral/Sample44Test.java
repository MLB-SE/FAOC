import org.junit.Test;

public class Sample44Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark44(-0.5384440548191901,100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark44(1.2040072489203943,1.2040072489203943 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark44(45.83921134492422,85.5934892897427 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark44(45.86073023541195,16.750533679691728 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark44(62.811769941881636,77.40717640117302 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark44(63.32926263733435,0.18921102511258425 ) ;
  }
}
