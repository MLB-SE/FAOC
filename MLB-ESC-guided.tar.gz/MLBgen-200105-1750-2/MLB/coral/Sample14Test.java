import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(-0.2624128627954718,85.2007366354124,-18.827864147411475,47.74543500655298 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(-0.5318371567077662,90.08558193992656,-11.957776688388464,-66.43618867572405 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(-0.8801003118562392,-2.133081770602118,-100.0,91.24250027977712 ) ;
  }
}
