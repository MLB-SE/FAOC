import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark53(10.4838592476936,54.11701928517661,7.553313274989251 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(13.214309081306325,28.656491248576202,50.46653175070534 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(13.613696594537458,89.57756952977664,80.23551328783353 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark53(30.311199584542376,2.761138742616879,31.268292937884723 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark53(31.81647883264168,-34.152786524032535,31.037913752633074 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark53(52.923758316401916,33.46502114992268,76.72368404870585 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark53(57.02518587202762,-0.37431445728798574,88.5671377275324 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark53(62.062117178534805,-86.69667764315801,-23.18143815126392 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark53(66.56960345300912,46.72993608809196,67.52484409189853 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark53(67.52546184087592,76.57272895726973,68.03544149975252 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark53(7.680740243320912,65.71410365076744,8.656171648116208 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark53(82.10108246067591,64.8656220983699,-34.74416592200225 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark53(91.48890916859423,-93.95028405005806,33.9468504243238 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark53(94.21535537780034,-29.746753788970295,-35.457718775643414 ) ;
  }
}
