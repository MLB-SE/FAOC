import org.junit.Test;

public class Sample81Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark81(-44.961133028935784,-3.541584319382082 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark81(-46.688021215740385,-3.3191976592395775 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark81(-64.73070463160175,62.13322364529225 ) ;
  }
}
