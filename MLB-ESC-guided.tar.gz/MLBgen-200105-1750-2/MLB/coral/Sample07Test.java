import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark07(0,-17.802358367621327,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(0,56.13212778697979,0,-17.855887769608916 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(0,61.68710268307203,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(0,94.72295730479075,0,-58.79009297796169 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(-40.984629984252386,81.92223846376177,-19.73285350678059,-61.30302930036717 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(-71.32868984360441,50.47895019157315,-12.211796009968467,4.199962019403429 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(83.1261361044331,-19.50467220416607,53.02089794530957,-34.34503056335469 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark07(85.33550620149589,-30.56630752024478,47.321915285789856,7.224021739678776 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark07(-99.22040548641029,-23.019861923232867,76.35918226453788,45.02031000832045 ) ;
  }
}
