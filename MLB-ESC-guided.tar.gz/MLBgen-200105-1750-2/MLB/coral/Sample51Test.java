import org.junit.Test;

public class Sample51Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark51(0.7934007371401015,19.251844593484634 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark51(1.3959434060199898,39.17798972767537 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark51(1.7503257117404587,71.69268777479144 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark51(2.0423154270185484E-13,4.5191977225038543E-7 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark51(23.247194330551935,47.26235684965954 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark51(24.602247406319805,25.397752593680195 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark51(3.7158367265536323,18.353238545923233 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark51(4.512135429179942E-9,4.1325493600048904E-5 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark51(50.030569825226365,93.61222064747787 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark51(5.3745437432888306,36.18029123447056 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark51(-82.56793887592981,77.64744844201357 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark51(8.331425669268725,9.437624723342648 ) ;
  }
}
