import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(-66.12458229982366,-98.4949549108604,-164.61953721068406 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(84.64422478454509,89.24739111313039,67.10444973124538 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(-98.38373930167647,-43.290189406806,-63.32709649877339 ) ;
  }
}
