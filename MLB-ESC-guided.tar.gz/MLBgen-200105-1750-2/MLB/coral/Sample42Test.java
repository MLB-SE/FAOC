import org.junit.Test;

public class Sample42Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark42(0.39950846608840607,0.1486235937953353 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark42(0.7811849522806398,0.7811849522806398 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark42(1.0,-24.353667022897312 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark42(2.117370695953947,3.7161170687971037 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark42(22.846799842924653,76.99637331046935 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark42(22.858970425859383,91.3029331751394 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark42(49.79416314696104,46.57044220039859 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark42(87.31066680909268,92.81150236645732 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark42(9.598356244128482,10.0 ) ;
  }
}
