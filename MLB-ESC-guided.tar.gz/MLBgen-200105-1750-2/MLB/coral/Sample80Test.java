import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(0.017241062021064568,-86.00160107117235 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(15.602756122465308,70.63308428521907 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(55.87192302965616,-88.15891079133036 ) ;
  }
}
