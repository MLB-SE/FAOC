import org.junit.Test;

public class Sample91Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark91(-38.68699051582443,-25.113394363198353 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark91(57.894672272458024,29.620338390149886 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark91(58.19839717202743,-22.341553313719388 ) ;
  }
}
