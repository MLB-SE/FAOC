import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(0.6114894170257859,0.6457149689806865 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(1.1964917200903754E-4,0.010708525666861249 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(12.864757259100116,69.40034221998312 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(23.303488334457526,23.933286642788875 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(3.1899275477659224,46.81007245223408 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(38.47538585765673,90.81459626005977 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(44.49547332560368,72.64732280081893 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(-51.569933760310406,34.874610920304946 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(7.85882683318637,23.122839921056386 ) ;
  }
}
