import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(1.6232599682412217E-7,100.0,100.0,-100.0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(-2.8531062693782244E-6,100.0,-100.0,100.0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(-5.7314596168791476E-9,-100.0,100.0,100.0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark79(-7.001072140142015E-29,81.07434164567117,-100.0,-93.50786931105635,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark79(79.51579713575441,34.681199731369816,1.8312880710499257,74.13414373873744,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark79(-8.277950468968611E-9,100.0,-100.0,-100.0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark79(8.655041105394813E-9,-100.0,-66.32350798533417,100.0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark79(8.973849655592046E-9,100.0,100.0,-100.0,0 ) ;
  }
}
