import org.junit.Test;

public class Sample28Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark28(7.382673981955349 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark28(7.3890560989306495 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark28(91.49295528416201 ) ;
  }
}
