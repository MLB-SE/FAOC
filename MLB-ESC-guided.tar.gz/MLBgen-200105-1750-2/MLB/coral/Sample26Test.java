import org.junit.Test;

public class Sample26Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark26(-100.0,-99.9914165850643,94.86964524476085,38.20266495452081,-55.984977663883704 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark26(-12.609518190027025,44.171629471028496,3.516986193968094,-44.4393491821222,-100.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark26(-21.80429115620582,-29.791461496418943,100.0,0,-18.956893346382817 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark26(-2.5425820624953985,22.99933448892667,71.43301522851283,-66.64460932189465,67.62839685759084 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark26(-29.03921292045609,42.02613255572498,100.0,0,44.753033647966326 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark26(-34.359342358569194,53.91784474020213,-2.03824231927247,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark26(-42.536886966956764,75.47939748170552,48.95203044582206,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark26(-59.66275303428383,-19.587975385190976,16.99765599411733,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark26(-62.5166801163745,79.20029388197906,17.32570063749324,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark26(74.1880160166582,84.95444846564453,17.499287508369463,-56.78132995094949,14.293740805324774 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark26(-7.419266879031312,89.4261396900817,-74.6975543487217,0,48.32082759987625 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark26(79.84815280447458,70.04417488197717,-94.0453193250076,-69.85648098500181,-13.54628882065947 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark26(-90.44560758467844,49.845262472030015,-55.28686097006438,100.0,100.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark26(-91.23074049465467,-67.85137796052037,20.065751939322425,-30.01700736907563,74.63423003255045 ) ;
  }
}
