import org.junit.Test;

public class Sample03Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark03(-49.57967925774407,-92.56437035467519 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark03(55.27783538866124,47.42385375468675 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark03(-63.651042964078556,-5.073399029441546 ) ;
  }
}
