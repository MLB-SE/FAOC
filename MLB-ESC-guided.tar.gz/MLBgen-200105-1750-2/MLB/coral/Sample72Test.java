import org.junit.Test;

public class Sample72Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark72(-100.0,-100.0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark72(-10.557140924497574,19.766041252623623,-99.70638769766428,-41.36657798260443,-34.563715902191845,-72.13494445745208,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark72(-23.149059320161754,82.83770617148808,-85.9752739249245,28.965371608172262,69.481545388948,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark72(-23.461639555357294,56.98612357021747,-12.381860282144665,-37.99652438000578,-76.50166417784075,73.10588227835996,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark72(-23.469903947692394,-36.385379007360456,-49.173419511307735,-24.04078844783881,-36.70141567141228,11.889967175605577,86.05904025196506 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark72(26.228286056559668,53.56771135537866,-1.8045292758737332,56.803715805150205,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark72(-29.41446060017499,31.924179078213086,12.554869435316178,91.49671229117828,-52.512077098063784,-89.4315045231323,95.00398451218467 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark72(-41.938751252511096,-89.7554524924774,-86.36501378445712,0,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark72(-41.984063678422025,-81.28602358826794,0,0,0,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark72(-48.960609295992256,-55.908546437753955,72.27869165781368,100.0,100.0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark72(-50.49237270180769,98.23213830926218,87.0866809470194,0,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark72(51.12624805828575,13.35947556493204,100.0,100.0,0,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark72(51.65965381914298,-17.016037747784473,-79.6566970714599,75.40988311921214,-81.96594229627914,18.0377862958171,35.36928881520939 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark72(-55.29896310558114,11.735499319455585,-64.68211399490076,-1.4783697026636844,0,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark72(57.96887240366431,-29.63941198901003,-100.0,65.94069689832494,100.0,100.0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark72(58.73218798437842,-100.0,100.0,-19.446983456033493,74.14333211874388,36.44422027566637,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark72(-64.27537975474236,36.494925831646356,0,0,0,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark72(8.091360066134907,-30.341812242703682,-41.866698502981656,-36.69198710989898,-100.0,100.0,100.0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark72(-91.85312781645486,-100.0,-100.0,0,0,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark72(-92.73094710913037,-93.01282028024092,-62.70571088553958,-81.78147972129096,4.8611690978037245,0,0 ) ;
  }
}
