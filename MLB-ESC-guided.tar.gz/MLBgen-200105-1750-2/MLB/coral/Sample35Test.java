import org.junit.Test;

public class Sample35Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark35(14.137166950745785,-93.84933774004655 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark35(3.14158389232835,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark35(44.424554779880026,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark35(-4.743059430459468,55.702977328581596 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark35(-61.26105673564095,-76.26492957165607 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark35(64.4026493950852,-22.599279802105855 ) ;
  }
}
