import org.junit.Test;

public class Sample54Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark54(13.431800822665261,-100.0,14.19403650298267 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark54(17.081512518597023,72.32235005081677,-96.81210824173738 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark54(17.556740492139586,-13.237074263505448,20.831290396932722 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark54(18.689447103183213,89.87178528757468,38.174882911209124 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark54(21.57936098226064,-58.79997466057467,44.45963747283674 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark54(23.93190818054127,28.591634817716965,58.63851066611366 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark54(24.959260644352387,2.7531446679085843,25.91524798038748 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark54(26.728807328683942,90.63278597841389,72.1711434916059 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark54(29.204458671144124,44.17949273021861,30.0292620138205 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark54(30.542623659976385,-4.909438993792705,29.30106340470374 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark54(30.812267508786825,77.80595025620256,31.787016703034766 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark54(34.968681465011656,-94.64259803069537,76.25410773210834 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark54(35.3688686243085,-75.17408778117492,52.6309412255756 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark54(37.09269405254344,28.863088871991014,37.81189883270852 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark54(39.96785758614437,2.770144249822977,40.92622514814251 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark54(4.211250602991033,-24.59297591281077,2.24063159705097 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark54(42.436209732420735,20.453418356523116,26.679360372860984 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark54(45.578999974770525,-9.42738598455508,46.57899658274805 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark54(54.79088582103279,-16.076920182912964,55.749610758331045 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark54(56.61872011564489,-32.099728322491174,57.29025688329526 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark54(58.54238805385899,2.779109860176676,59.50205064842963 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark54(64.71118821654647,-63.009714211483605,97.15150114834586 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark54(77.05666776594961,-62.390591303205014,98.08759080213733 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark54(87.18476819696681,-13.600570884859238,-29.410693938389556 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark54(87.61505440252645,-46.23614966067153,-30.90723832997773 ) ;
  }
}
