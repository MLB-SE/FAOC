import org.junit.Test;

public class Sample82Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark82(0.011151366647583781,0.008967510724048113 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark82(0.7662032964910361,1.3051366452998536E-4 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark82(-13.467531538830208,-7.425265700078398E-6 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark82(13.5967405619255,38.732545829422236 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark82(1.4739303303423767E-6,67.84581193655956 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark82(23.04638881022443,-37.8909165872312 ) ;
  }
}
