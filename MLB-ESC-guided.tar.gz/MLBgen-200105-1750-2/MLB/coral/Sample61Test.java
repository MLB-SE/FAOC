import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,-3.6318071395692044 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,6.682752804818065 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(0.6468709895090825,52.28859846728383,-19.04920754882913,71.98467700562205 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(0.6766901200076556,1.708629310636119,-12.944485152113076,15.344748052992246 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(0.7949829827752097,-54.73284657646636,-5.802463054959702,-11.516216460724252 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(100.0,0.0,100.0,-100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(12.912873031731493,-9.758877068934956,-35.06802340013972,89.68991715175031 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(2.1643739429850655,2.370571967726193,-14.091241517452683,35.38626144869344 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(25.032497195948693,66.0922713027908,52.43645416015275,32.990208621920914 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(29.827196348032516,18.836584171928905,56.256167575577024,20.413755761639237 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(33.123055839169794,-2.4368138609084653,66.34298764612217,-51.72262534062444 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(34.31182571962688,45.08416488213351,99.2267379917588,68.90603256821686 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(3.5845277623464376,-5.8774717541114375E-39,99.99998839283124,-75.03057825280527 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(38.74721062883853,1.9111941747572896,-68.68702547117913,20.566156100600153 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(40.180971511925975,5.505689116231281,38.53577275921904,19.61600155097385 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(43.45303209860981,-24.066817049730943,22.986518549259344,-1.8055163675703263 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(62.25016418839658,-28.516818344205163,45.04731461438348,-84.89625064161474 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(68.85428981108186,-31.806654900436236,79.00310677326668,-32.59400630542729 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(73.35497929503056,-74.44957900261049,-72.84687183678243,66.551152290951 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(73.85971339845858,3.9461336718071607,-58.0347264554683,33.45427995569318 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(75.64289732513862,-25.969670339425832,-51.08178178639153,-46.76423711436555 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark61(78.7499603553994,-43.90690249578542,36.75230337330504,65.10136906865779 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark61(8.272880679202558,95.42289006540409,74.40527025439533,98.45825950600627 ) ;
  }
}
