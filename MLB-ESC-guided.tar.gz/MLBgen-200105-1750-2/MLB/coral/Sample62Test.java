import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-3.250895643288459 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-94.10450249445267 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(0.6497974768455467,-1.0E-323,67.8563785681421,-46.75430668977621 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(1.0240826254235056,85.55641887279599,86.58050149822448,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(1.0651205302415234,35.18902707007017,36.299877305086156,-0.04276938491507565 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(1.0922346567785968,24.37867799286174,25.47099664949656,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(1.1303605530445118,35.25934379251174,36.392039537885886,-2.62758333309838E-6 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(18.176568863739107,18.80441959154186,118.00080628286284,78.18177454034887 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(19.58331148578702,-12.335403926327785,11.68464698443637,98.70506354107232 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(24.410458406015707,-21.361202056357413,48.672433795441606,68.88915869437932 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(2.5363608526539374,4.445562127084003,4.4445137595537805,2.53740922018416 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(25.694772691328986,-38.51844345893121,16.962872699145272,-0.6670771293945208 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(25.778735947429695,99.01260852787792,51.94622261378757,39.88874473633666 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(2.7801593793160597,0.3289891061918411,-68.5327661323683,-22.042294361883137 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(2.9963192388831943,-1.7064874114815514,6.926326322164154,-3.38042791722662 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(30.74065168477378,-19.214216929761378,65.82853410195025,-47.12638187966745 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(34.915587114078704,-21.41326819559073,78.57723865053293,-8.047240676585005 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(35.95503153054507,2.7052455479192474,-23.93446999801748,62.59476680237454 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(36.787380658904375,0.0,-36.94119404057788,-72.0838872823292 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(38.17003692169391,24.173957312844642,149.3513115930958,93.14357452418005 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(40.12618855768736,-27.68653371760577,-15.533134856189434,-75.42296746126904 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(4.2504713689448455,-8.4E-323,100.0,-89.23323630538782 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(45.80020230518332,40.70663906602715,33.544462803671564,78.24319039456881 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(61.06001306144012,-58.29262504021799,37.65723203411636,-30.865993295000226 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark62(62.11802586503953,-2.9800238067826372,13.331307380581507,79.62215833340304 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark62(6.899117727970898,2.0267096329430103,5.32339030900798,3.404097763108079 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark62(73.19675089074153,11.485604199266206,61.04584459380666,95.84113386925881 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark62(-76.19892812702946,2.4925173934512657,-57.98357818679345,32.861871185011466 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark62(83.50402502635984,-0.9863523182766718,60.39334861372262,50.78350438550311 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark62(92.25975560885504,75.82661269294115,69.63768585512304,98.44868244667316 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark62(-9.514820528485117,30.114231649176816,-60.71082186477648,-99.96246506851077 ) ;
  }
}
