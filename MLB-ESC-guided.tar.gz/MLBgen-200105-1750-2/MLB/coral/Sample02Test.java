import org.junit.Test;

public class Sample02Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark02(39.11161719135926,-56.70695874376383 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark02(40.711562045785115,-60.95255784093116 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark02(-44.13078080769899,-76.6931514348874 ) ;
  }
}
