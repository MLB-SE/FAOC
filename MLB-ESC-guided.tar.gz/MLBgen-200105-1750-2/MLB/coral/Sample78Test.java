import org.junit.Test;

public class Sample78Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,0.0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0.0,91.30435952692858,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-30.6283222090224,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,57.22097376609858,0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-90.0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,13.783221680308827,-67.92590603238389,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-17.453728738906882,90.0,0,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,46.65665984736503,3.56E-322,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,62.29485247735678,1.58E-322,0,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-65.43077069284324,94.2267484736366,0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,77.99032057108093,42.348509007171316,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark78(100.0,0,0,-90.37604916921443,6.5099109142986804E-298,0,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark78(100.0,0,0,96.9185415000294,-90.0,0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark78(-100.0,0,0,-99.9999999997988,1.813E-321,0,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark78(-100.0,-100.0,-100.0,-100.0,-100.0,0,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark78(100.0,-100.0,-100.0,100.0,100.0,0,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark78(100.0,-100.0,-100.0,100.0,12.715489144642017,0,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark78(-100.0,100.0,100.0,-100.0,-25.63262519081404,0,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark78(-100.0,100.0,100.0,-100.0,-92.44909542367556,0,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark78(-124.0,1352.0,92.0,124.0,1013.0,0,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark78(-124.0,999.0,279.0,-124.0,1454.0,0,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark78(1.4031848917396129E-42,0,0,38.14639394666031,-90.0,0,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark78(1.9165125107817633,0,0,32.16063236579128,3.16E-322,0,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark78(20.01808120509652,0,0,-7.5726016203064574,-97.36403063617432,0,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark78(-20.544059093313336,0,0,2.3763644578689498E-212,90.00004835744043,0,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark78(21.14874200723122,0,0,3.2033329522929615E-145,-29.74472157801935,0,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark78(-212.0,118.0,1018.0,212.0,-1295.0,0,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark78(23.419896218503794,60.40623511808863,74.19047961666666,45.684185425556024,-33.95998271875365,0,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark78(239.0,-858.0,-318.0,-239.0,322.0,784,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark78(244.0,-284.0,-1904.0,-244.0,-150.0,-941,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark78(-2.6437128266819627,0,0,75.05363295258854,-89.08670582888136,0,0,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark78(29.42919839184833,0,0,-85.64299518156847,84.14182047832384,0,0,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark78(-295.0,223.0,43.0,295.0,-87.0,0,0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark78(-323.0,1168.0,1168.0,-323.0,803.0,0,0,437 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark78(-34.62488105059597,0,0,16.494338579226024,2.298E-320,0,0,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark78(348.0,-327.0,-327.0,348.0,447.0,0,0,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark78(35.18534526900913,0,0,57.710343755338954,27.51061590380708,0,0,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark78(36.0,-160.0,-879.0,36.0,1532.0,0,0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark78(-38.82915005125047,0,0,50.49583707541029,90.0,0,0,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark78(39.0,596.0,-304.0,-39.0,-505.0,151,0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark78(-4.4175662149698594E-45,0,0,33.40866052215751,-90.0,0,0,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark78(-45.52395590000532,0,0,-6.9E-323,-72.03274402140804,0,0,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark78(4.683374586122618,0,0,-99.99999999999999,-2.0237E-320,0,0,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark78(-4.790787801021146E-27,0,0,53.247468301693544,-90.0,0,0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark78(-5.260163025907815,0,0,46.78687659101314,93.67578303913871,0,0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark78(-542.0,993.0,93.0,542.0,-692.0,-1281,0,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark78(5.474087253454503E-80,0,0,95.45953984804477,-90.0,0,0,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark78(5.842620705845015,0,0,-31.871376613354453,-90.0,0,0,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark78(-64.53185204868886,0,0,-27.006401136404406,-90.0,0,0,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark78(-667.0,-450.0,90.0,667.0,-572.0,0,0,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark78(-6.75726564661118,0,0,71.94071585236979,-90.0,0,0,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark78(703.0,-808.0,-448.0,703.0,495.0,0,0,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark78(-76.22776741906429,0,0,7.022315367021449,3.981561797733818,0,0,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark78(-808.0,-543.0,-363.0,808.0,-864.0,0,0,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark78(8.199300020423531E-73,0,0,100.0,90.0,0,0,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark78(8.559682991469494E-27,0,0,99.71743326062919,90.0,0,0,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark78(9.744535944919647,0,0,-80.05260188696326,-29.37188116213862,0,0,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark78(99.93875032437107,0,0,2.845908082673038,90.0,0,0,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark78(-99.999999999993,0,0,100.0,-4.892989160178156E-296,0,0,0 ) ;
  }
}
