import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(13.95958433026127,-6.025205734820407,-74.46955318294647 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(-33.97265846603203,12.938901499952621,-86.48687487361696 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(54.97079529317216,-66.80378251782422,20.697617972538552 ) ;
  }
}
