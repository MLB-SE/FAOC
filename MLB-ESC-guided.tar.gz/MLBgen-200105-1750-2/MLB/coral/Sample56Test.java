import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,0.38918852291014616,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0.17278347852387466,-48.49002283294972,-9.517052491107819,21.976432636883317,18.97732986056988 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(0,-63.77910228242361,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(53.171928448017525,-61.10333196116458,62.26256854026397,-69.24204971490404,76.14221459725911 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(90.97715889084634,51.78695427372827,64.86709369738654,-30.68189857453909,-21.137076409784967 ) ;
  }
}
