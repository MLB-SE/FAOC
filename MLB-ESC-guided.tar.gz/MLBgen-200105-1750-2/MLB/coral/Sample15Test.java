import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(0.18432903263763478,-46.52017844637226,-42.13585982885644,77.24981163664376 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(-0.6424188173285756,1.5739736714851063,60.54046280140628,76.8059641260451 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(0.9096027723460638,-34.31093818749733,53.074846188018945,-99.99999999998776 ) ;
  }
}
