import org.junit.Test;

public class Sample46Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark46(0.0,0,-23.04731808230943,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark46(100.0,1.0000000000000036,100.0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark46(100.0,1.0,-46.8638289211583,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark46(14.331117885229306,1.0000000000000002,93.90561560782947,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark46(16.114119879704063,32.89714316794476,11.501602713467747,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark46(1.6940658945086007E-21,96.65077996422795,1.0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark46(17.879646730663467,39.151661879557906,28.776565296020493,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark46(20.195995640743284,1.0000000000021974,95.31008630127117,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark46(2.465190328815662E-32,99.99998996596933,6.939808631247862E-17,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark46(44.94521569969035,0,93.79541698628643,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark46(4.930380657631324E-32,33.204185341678986,1.0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark46(51.18466281882189,0,0.9536755003400685,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark46(53.93876835942184,1.0000000000000002,93.25608116085783,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark46(-645.9533777606722,0,41.60937268993433,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark46(65.89438084201464,-86.42771325204296,55.90518657041383,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark46(-743.9546920281183,0,25.608855002522105,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark46(77.31413288118375,0.9999999999999999,69.80947299398701,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark46(81.27735051816104,0.9999999999999999,11.200302022410469,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark46(88.41631095545952,56.77790564789899,25.15160603727857,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark46(88.88057539913359,0,31.945310856249108,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark46(-90.92088763442038,0,0.7471587326723323,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark46(9.629649721936179E-35,100.0,1.1405137446501356E-16,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark46(9.860761315262648E-32,64.09991259312707,1.0,0 ) ;
  }
}
