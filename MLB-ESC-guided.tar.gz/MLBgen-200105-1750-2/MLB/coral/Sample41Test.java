import org.junit.Test;

public class Sample41Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark41(0.11004642391523589,-0.09793620849870409 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark41(0.38354806839947564,-0.2364389476265068 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,1.9999999999999998 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0000000000000004 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark41(-2.414493802849484,8.244274126848048 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark41(-3.1024956481118693,12.727974894664968 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark41(37.99125102461201,-60.28801165887678 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark41(4.184793989015897,13.327706741487685 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark41(5.792649134539502,27.762134861341742 ) ;
  }
}
