import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(0.7823572482484775,0.612034088022921 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(1.1998299271661903,1.4404415404821214 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(2.5633624406673228,6.572253631599119 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark83(-9.415925522790655,88.66008694117555 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark83(97.3192686356108,60.72970772913055 ) ;
  }
}
