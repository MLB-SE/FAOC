import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(12.478447411670118 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(-1.9967726803290304 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark31(2.4152394874410277 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark31(-36.078749927702944 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark31(5.200230202845399 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark31(-65.42207828290603 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark31(75.39678069748797 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark31(-8.881784197001252E-16 ) ;
  }
}
