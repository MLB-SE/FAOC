import org.junit.Test;

public class Sample37Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark37(26.467949913319124,23.347563507828696,-48.87444057342782 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark37(40.57139123661153,6.25457309008317,-73.8988761108623 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark37(81.68143298597829,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark37(83.13200660688258,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark37(9.385438644571906,89.94948633522577,-59.13979989618661 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark37(-9.6371801550561,-100.0,60.926677872682916 ) ;
  }
}
