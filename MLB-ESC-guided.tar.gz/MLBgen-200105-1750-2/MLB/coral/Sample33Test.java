import org.junit.Test;

public class Sample33Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark33(-30.630528372500486 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark33(69.49218892139038 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark33(76.30590935224043 ) ;
  }
}
