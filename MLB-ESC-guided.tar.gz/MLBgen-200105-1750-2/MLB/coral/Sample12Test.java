import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(0.27958278012241067,0.8624255369711165,-98.2699811586232,-11.668799769042735 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(0.6414133876746035,-0.1376582214472677,-0.7347808150471451,100.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(0.7219411383672707,-0.485946229736129,-58.1028261109098,14.233351437172146 ) ;
  }
}
