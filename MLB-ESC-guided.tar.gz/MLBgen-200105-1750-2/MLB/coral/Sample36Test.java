import org.junit.Test;

public class Sample36Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark36(63.93179936571542,-19.74905947804426,88.04133395890219 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark36(69.11506587998204,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark36(89.72895874564333,-19.04040472726389,9.786289223285841 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark36(95.4822787453036,-49.84065260571447,1.2328749825040575 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark36(97.18385660193181,0,0 ) ;
  }
}
