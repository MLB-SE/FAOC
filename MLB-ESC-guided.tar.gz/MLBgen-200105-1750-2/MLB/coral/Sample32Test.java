import org.junit.Test;

public class Sample32Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark32(16.855438119274794 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark32(25.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark32(71.63065766191187 ) ;
  }
}
