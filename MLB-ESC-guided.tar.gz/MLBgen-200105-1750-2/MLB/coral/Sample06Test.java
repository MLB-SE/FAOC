import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(-46.40253072144629,83.19011792615632,41.447672461625075 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(-57.425969920060126,93.45757784615729,-85.56952195154456 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(5.909490183282131,-77.38508830385804,85.56308428749358 ) ;
  }
}
