import org.junit.Test;

public class Sample43Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark43(-0.5912246023540277,100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark43(10.50474763658195,10.50474763658195 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark43(10.679234498194589,114.04604946742943 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark43(2.615971679515262,2.439006941174398 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark43(4.461960807983274,46.18538309350194 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark43(46.715773648267884,80.64542398499435 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark43(49.644386443125654,76.14021282575743 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark43(91.99015667772215,92.2930704759043 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark43(99.9858194184485,11.169162801034858 ) ;
  }
}
