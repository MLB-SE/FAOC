import org.junit.Test;

public class Sample01Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark01(1.5447074721405527,-58.11912379653787 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark01(-60.33198418785224,93.33600894885569 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark01(-75.90453243407836,67.9405043751791 ) ;
  }
}
