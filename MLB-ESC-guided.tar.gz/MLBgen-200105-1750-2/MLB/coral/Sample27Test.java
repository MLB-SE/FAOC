import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(-13.107382512062316,-42.71609685548466,-71.16725584800616 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(-15.125331559547163,20.882112992115793,80.79453508280099 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(29.39896858974288,-38.49339409357974,2.583666436100781 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(-69.4676624489907,-8.059810870102567,90.97859837561158 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(-74.12379176372943,69.60231988947929,25.272392537981666 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(-77.22173744023026,45.69929207272828,12.863922766143943 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark27(77.45695921357597,72.42979594986679,100.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark27(-89.25665574218749,10.7150351277636,-96.39381471260732 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark27(-95.06272658154809,89.81064345847741,-15.553688930782172 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark27(97.39436478029474,-55.73196548968087,97.73164003673247 ) ;
  }
}
