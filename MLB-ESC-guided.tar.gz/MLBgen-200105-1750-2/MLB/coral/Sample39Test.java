import org.junit.Test;

public class Sample39Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark39(59.154585056478616,-5.140703567253264E-18 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark39(81.46531998411658,30.58966125235557 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark39(97.95726141152295,-70.87503731971292 ) ;
  }
}
