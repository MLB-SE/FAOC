import org.junit.Test;

public class Sample16Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,13.643638199901247 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,3.846572943691754 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark16(-1.4349661326253909,15.622848001000373,-63.09750807973112,22.547621927231518,-59.06367316657915 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark16(-23.10099710797553,14.441112498663216,-41.58517020081749,49.455446963992586,40.731590150582065 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark16(-89.8735056037577,15.865813564472717,43.274052602261634,57.560610933278696,-25.57489259883741 ) ;
  }
}
