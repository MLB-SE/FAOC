import org.junit.Test;

public class Sample40Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark40(1.16920646425514,28.33515084015997 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark40(23.843341239328993,-67.07427363320899 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark40(9.26650630715812,76.6016328334431 ) ;
  }
}
