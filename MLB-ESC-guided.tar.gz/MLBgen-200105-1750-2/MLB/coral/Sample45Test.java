import org.junit.Test;

public class Sample45Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark45(0.0,-4.483830990945204,34.739798828552125 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark45(100.0,3.2406583181269326,-100.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark45(2.1175823681357508E-22,1.0000002931973517,1.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark45(22.737817379679086,6.936997597729032,11.013681568169531 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark45(23.0594771498329,84.37321521853465,39.59775582809709 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark45(27.556675602563658,56.382032795269936,20.32985301799475 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark45(-314.7914512245143,-404.9355732342755,19.91578141750594 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark45(-35.34479840365607,-163.60790187809513,16.088204169219495 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark45(38.20433451058139,10.421744236905312,89.88956458003085 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark45(-429.59919882094033,-156.75882124661,21.83188723440223 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark45(44.03848077969067,36.55740184238857,87.91756290497895 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark45(-457.3769953949678,-264.2176407271126,89.71759029664003 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark45(-52.44743408554169,-79.02160736184305,47.807179053475295 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark45(5.551115123125783E-17,1.0000000000000004,1.0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark45(59.523932584208694,1.0,20.861231147838478 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark45(64.24637372689975,66.24637372689975,98.36868053881089 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark45(80.7155146853884,-44.744698164327176,99.74358818418372 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark45(91.5753972263075,-17.96641174914953,5.274518792351657 ) ;
  }
}
