import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark05(-36.895004780422624,47.03910010921305,-3.8165382410929993 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(-75.91270970719397,70.49088595969434,-90.09536382012955 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(93.51677661219352,-72.81845625359473,17.78238446129052 ) ;
  }
}
