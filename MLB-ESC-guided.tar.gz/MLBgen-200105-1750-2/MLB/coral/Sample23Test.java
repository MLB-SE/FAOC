import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(100.0,-31.3366900034556,-100.0,100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(100.0,-51.570796331238334,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(-23.97587457715646,12.50976749243145,14.085622087197763,28.269677160634284 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(-24.285877389122966,-99.05596259498459,-32.464114142759264,59.289709823355864 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(32.69995432690135,71.55399101726286,0,-94.8871217837616 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(-40.75080847823382,56.546406306361206,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(-42.77273404293196,26.587039465594078,-77.31341647116261,-49.09959794571359 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark23(-47.711463812059684,50.74340996564595,39.461348784865635,66.46547254943496 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark23(-54.32400835285962,24.31084660208044,52.49168435718246,75.0092439768351 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark23(56.795861455882026,-65.83761305522414,0,-98.24268676424441 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark23(-60.651946480377376,58.404597840015185,-28.569428519108683,81.41509920625546 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark23(-6.952520807343674,54.637627312369375,8.260554721480519,60.425335715711206 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark23(-70.43444779654749,-20.78590712308834,-1.7603212957987324,1.3643471483411957 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark23(72.09154025928883,-42.984374116040456,-95.38034096930858,34.06810486434125 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark23(-84.98707169351691,11.222749885980587,-7.10473621817862,9.366247476631772 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark23(88.36774536665742,-75.80011891782937,95.34507543099201,81.45224315686075 ) ;
  }
}
