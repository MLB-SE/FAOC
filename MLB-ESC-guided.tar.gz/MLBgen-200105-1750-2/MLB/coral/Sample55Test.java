import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(0.2949609551844645,-73.44533952770192,-93.35655774958049 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(1.5193073684684606,-18.431728380752332,-52.13789487374216 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(15.523223919841527,2.7256213277293497,19.635326580213913 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark55(1.7817959187540708,-50.31917739754663,87.27269878329798 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark55(2.029804722567134,0.16696389694702238,3.5718887118129317 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark55(22.12387265079603,-68.34833127675397,19.746606539435884 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark55(28.118135865653723,-25.370188828701615,43.06913012548205 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark55(29.144411680900674,-9.059535033569375,67.46793689001171 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark55(31.77533507148675,-6.272929018522433,31.07786225198967 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark55(35.85713868002816,-38.32670694712459,68.2191959659086 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark55(3.592288086729962,-62.387395597390494,1.7991140700740595 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark55(37.10074834164331,-12.31316670895184,50.37410970334426 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark55(51.93577763982183,-32.27440255260998,63.540341349402 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark55(52.10300897093788,-14.30052197681242,66.72995985595384 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark55(54.17999600089027,-60.01779356041652,76.43484534899954 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark55(59.81599402877821,79.45225378386823,59.9259504078625 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark55(61.66284042474001,-21.848379693380018,87.17083184244024 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark55(63.58951006814337,-38.88158323759079,98.22703089312063 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark55(66.38420760306221,-55.80413587196578,71.35010529671044 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark55(72.75663670715845,3.112321821750413,100.0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark55(74.86867109318476,-79.29060306227225,90.18567664557577 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark55(80.2634947378026,-87.19265911788885,65.96809920610156 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark55(80.88362719189499,-56.33483009827234,79.47703400602991 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark55(83.04734511531427,-82.21725407559406,90.1962629962691 ) ;
  }
}
