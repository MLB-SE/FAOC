import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0,0.255342253171591,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(0,-63.89560825687961,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(-13.381061921895338,-88.77968756015753,-44.42189455997963,-51.04564691676825,-27.564993365086664 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(13.781188973622733,40.3889168379375,87.15200126787025,72.94002853473847,33.63833686916405 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(24.316711957160955,57.810345101200205,40.08671421950821,1.7043302919230463,28.09199930219262 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(-35.377852871307574,-0.6216538174759023,-33.923918787591305,-73.05093983920861,-67.83868944163909 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(78.79848288033944,58.30336675111727,50.08194659221169,49.14358952567619,-35.13276183646599 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(96.88071297016799,-81.54349524230608,6.241674796815516,68.04086603160263,-64.57074430829933 ) ;
  }
}
