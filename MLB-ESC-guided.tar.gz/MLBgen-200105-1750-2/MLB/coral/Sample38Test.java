import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(18.08852336307818,-72.50951267877653 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(24.982380460710345,41.53676837505236 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(64.57064660035493,41.460335388193094 ) ;
  }
}
