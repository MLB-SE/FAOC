import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(21.66311058644534,-56.00984623225777 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(23.752134743790393,10.816622244512093 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(2.3945377025109247,-100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark09(55.25471021985433,97.62898188516948 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark09(-86.63584992957294,-62.37870462559977 ) ;
  }
}
