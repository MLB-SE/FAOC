import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(-0.21816568147853843,79.89674570215621,-23.251793114498426,-18.549062837808663 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(0.598510003478566,71.90700311360882,92.49848587634892,27.168702956091238 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(0.9623624314904248,-70.47550112226494,38.02726607931805,9.386243770943533 ) ;
  }
}
