import org.junit.Test;

public class Sample84Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark84(1.0000000000000004,1.0000000000000009,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark84(1.0,0.9999999999999998,1.0,1.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark84(1.0,0.9999999999999999,1.0,1.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0000000000000002,1.0,1.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0000000000000004,1.0,1.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark84(1.0,100.0,1.0,100.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,-0.17406740798732123,3.5969270638697886 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,0.9999999999999998 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,0.9999999999999999 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,1.0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,1.0000000000000004 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,-2.7953142504711828,7.81378175888727 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,5.12480366617269,26.26361261681705 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,-7.2666193685859755,52.80375704790884 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,-84.16592397798456,-3.919796394892055 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark84(1.0,77.370325247246,1.0,-75.370325247246 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark84(2.985392293921876,54.31274371849099,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark84(-78.15902780265827,-0.5598655619376132,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark84(-8.28930736773458,68.71261663677879,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark84(-8.770943307427942,76.929446502115,0,0 ) ;
  }
}
