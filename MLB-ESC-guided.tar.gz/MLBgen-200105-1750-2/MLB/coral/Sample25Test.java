import org.junit.Test;

public class Sample25Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark25(-100.00021144828715,-35.35890747206834,-64.96073605949356,-100.0,-162.8507486263152 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark25(100.0,100.0,100.0,-34.17934371265009,-99.7165195990481 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark25(-100.0,-11.952364272104141,-34.368631657900025,0,-86.05101432646657 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark25(-10.871368631697825,22.025422287744444,-23.900435505651174,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark25(20.44943728488758,11.021821737117591,-92.0398730558986,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark25(-25.824549728018127,100.0,-99.99999999999963,-68.6577597563052,25.7889802858452 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark25(33.77401957860182,-75.97478723081103,1.6861665992880832,23.751495818420437,-53.73867526651189 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark25(-35.21767919771799,28.60962539852569,-34.63246065689336,12.396334488232853,-57.843016026385044 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark25(-45.07700983711101,77.19579191588929,-24.879333873236956,-47.74101552637484,19.10490469026371 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark25(-6.2422989676153815,-69.01039515546967,23.403158272896665,85.95560025716486,30.721525634851954 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark25(-64.29411526559127,-1.4394138400789984,31.87048542392884,-76.73493642950977,3.591836101669358 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark25(-69.10707023837168,22.905951373062322,85.06562742756242,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark25(-72.18590889535966,-73.79569872404099,66.82992248774323,-96.9968918138237,-26.52744033235477 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark25(-84.71134599102564,96.60800839939131,-36.18479113976871,0,-49.073820673918966 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark25(88.1810218969209,37.7744250837265,-75.17694640336987,59.199931719408,-64.4212332362426 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark25(-88.20859319901423,-82.70138120163664,91.56028712898033,0,0 ) ;
  }
}
