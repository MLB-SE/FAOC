import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(10.340188526596876,69.77573937231494 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(-54.06613314685289,64.84885362390449 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(-57.4078557830167,-56.76524868165838 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(57.74570558193365,-29.92215511199798 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(-63.25186539999452,31.209634771248517 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(-74.73916565032863,-85.2345284096087 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark20(-85.42400273107025,-74.15433987366136 ) ;
  }
}
