import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(0.2122378930920133,0.456811698817415 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(0.3068274623625739,96.21183130162994 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(11.470503043479937,24.470503043479937 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(13.524864019381482,23.857401307821164 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(15.789252999340457,34.210747000659545 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(15.99910792413521,28.999107924135213 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(16.186165617642317,88.07109537069272 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(17.415187465287943,75.43206670170167 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(19.302066167496235,27.29948178672707 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(3.7212039387390927E-9,6.094509692056717E-5 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(45.192125135445536,73.08345292435556 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(82.19030938953622,80.43627797547336 ) ;
  }
}
