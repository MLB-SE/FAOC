import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(22.107821008671554,-44.57159001815609,-63.62025046554363 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(40.69585406105887,-49.83395240504568,79.73472218333637 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(67.9532629289078,46.15043227497185,-18.358062477798384 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark08(-80.52553602957494,-35.28613773632519,86.23929029365823 ) ;
  }
}
