import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(0.45971971703531267,75.62900680198902,-0.9908742213534651 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(0.804447360097754,33.828425445934755,0.9632059171219112 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(0.9356716582173481,63.53654768748231,-0.45568601922701135 ) ;
  }
}
