import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(-22.339989874642924,-55.68203820795175,-29.489833884534562 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(46.66534173263847,21.426749664681438,-30.0866763509204 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(46.81020948300136,-67.21906783792932,-20.408858354927958 ) ;
  }
}
