import org.junit.Test;

public class Sample34Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark34(-43.74115060706565 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark34(-73.91599213743007 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark34(95.03317777109125 ) ;
  }
}
