import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(0.0296591455641817,-77.09750329812171,-83.79223895823813,13.09834907000078 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(-0.39007218404766775,76.00949695314151,-80.32682311058501,-43.24392469649501 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(-0.8650287181067039,-73.30542401870434,-47.319053998893445,27.432574725838194 ) ;
  }
}
