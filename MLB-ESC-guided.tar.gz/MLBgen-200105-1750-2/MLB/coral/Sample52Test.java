import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(10.642777497599965,-54.79266056398182,16.055618289671433 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(3.550629685064749,24.534651298236483,3.9686184657904384 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(41.155441104126226,24.85745899706137,6.476712257482205 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark52(52.1680064538925,-8.40202902428422,51.90436014276925 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark52(79.25823759950273,-63.05214128455903,96.882144669247 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark52(82.75246794578658,-67.26720873366436,-36.6302045779016 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark52(93.25192170044448,18.942634585010467,94.44795718966895 ) ;
  }
}
