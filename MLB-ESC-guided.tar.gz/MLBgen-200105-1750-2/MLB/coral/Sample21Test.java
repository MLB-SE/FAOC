import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(2.5012339704236837,-25.482580385341436 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(32.86038273512179,-37.59302881216152 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(-56.42232763704524,-2.623265130918735 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(63.43648620040801,-36.802659178848415 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(-6.487742745411239,-80.02650144583413 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(-75.31668205822923,3.691492272956793 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark21(83.4636609626184,-81.79267929524863 ) ;
  }
}
