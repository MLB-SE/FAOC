import org.junit.Test;

public class TestStatCalcTest {

  @Test
  public void test0() {
    concolic.TestStatCalc.run(177 ) ;
  }

  @Test
  public void test1() {
    concolic.TestStatCalc.run(251 ) ;
  }

  @Test
  public void test2() {
    concolic.TestStatCalc.run(284 ) ;
  }

  @Test
  public void test3() {
    concolic.TestStatCalc.run(3 ) ;
  }

  @Test
  public void test4() {
    concolic.TestStatCalc.run(-338 ) ;
  }

  @Test
  public void test5() {
    concolic.TestStatCalc.run(-362 ) ;
  }

  @Test
  public void test6() {
    concolic.TestStatCalc.run(388 ) ;
  }

  @Test
  public void test7() {
    concolic.TestStatCalc.run(-460 ) ;
  }

  @Test
  public void test8() {
    concolic.TestStatCalc.run(-465 ) ;
  }

  @Test
  public void test9() {
    concolic.TestStatCalc.run(591 ) ;
  }

  @Test
  public void test10() {
    concolic.TestStatCalc.run(668 ) ;
  }

  @Test
  public void test11() {
    concolic.TestStatCalc.run(718 ) ;
  }

  @Test
  public void test12() {
    concolic.TestStatCalc.run(783 ) ;
  }

  @Test
  public void test13() {
    concolic.TestStatCalc.run(-827 ) ;
  }

  @Test
  public void test14() {
    concolic.TestStatCalc.run(-919 ) ;
  }

  @Test
  public void test15() {
    concolic.TestStatCalc.run(-972 ) ;
  }

  @Test
  public void test16() {
    concolic.TestStatCalc.run(983 ) ;
  }
}
