import org.junit.Test;

public class Sample59Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark59(0,4.444326268395969,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark59(0,58.11569164405509,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,1.4210854715202004E-14,100.0,-7.080237115589718,-100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,7.105427357601002E-15,100.0,-100.0,19.337865746378057 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark59(-1.1205235707972152,39.121957144033225,-41.77403489683812,62.23783930629051,68.45817817686864 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark59(-26.58969059138309,-39.580340009427246,65.99594804986646,91.23874798403551,35.961782618319276 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark59(34.81708756895833,87.44064363664262,23.374201593478404,-42.33645638805332,24.46103687477796 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark59(-4.626928808974995,71.50453539798963,-5.786682967547534,26.303398407091578,24.93975322860365 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark59(46.87298551111499,51.105307800707095,95.82963167565231,88.69228739681995,-60.51752299102047 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark59(-4.982808865480621,-76.9346018551456,82.32600625566063,-0.16376592605320747,51.68139959885131 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark59(-53.333114607237285,-99.09817605061113,84.44930433703072,-72.69559942469601,-28.54526210477985 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark59(-6.289725449665386,-49.9796938253215,55.80640361082966,-39.22790722990171,81.58792726642177 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark59(-65.66452518297851,-29.196949576333303,94.08965083391242,-39.883183527183604,-87.37840235640685 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark59(91.20166130590331,54.2726092265491,0.5073475978535569,44.07891168692578,0.1689776025076668 ) ;
  }
}
