import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(26.577197427942203,92.7470480220767 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(27.66172247311718,-22.62992518135161 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(-50.88088482713733,-27.358265522475932 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(-67.29917076667505,-20.086793845028097 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(-7.514727118316827,34.07173636997171 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(-86.80242794643826,88.72461634752392 ) ;
  }
}
