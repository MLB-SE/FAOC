import org.junit.Test;

public class Sample58Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark58(0,11.197914165461611,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark58(0,-1.8050225642860767,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark58(-1.016567536283741,-35.967499808771635,37.03760285422463,85.47714556031876,100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark58(104.00916431808746,8.604263888632289,77.30257774704324,33.6305728856644,-7.263987438862742 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark58(-14.38704003791691,-5.61402480137447,78.58738964386984,-94.1351065754916,17.69850328753806 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark58(-18.629879041150275,-7.349072516693184,33.701801237294774,-22.45061590677247,-84.55557325683942 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark58(-19.086979039517857,99.11121874769873,-80.34521425428629,107.88419568683734,-31.053943179470295 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark58(21.70229477761778,74.26467433653272,10.503362819067746,-0.8657325234056543,46.506260944733015 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark58(-30.343662490943473,14.664740846491895,14.87853171755961,-6.711172033671772,5.141257706296723 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark58(36.86856163355041,9.199736685419069,-46.41877371308856,54.7027219960906,81.56148496685154 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark58(44.68353900550483,56.91075330622072,99.99999135524293,-18.749333207098147,90.93951361559577 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark58(63.89595945907652,-33.642965232394744,86.81980773547718,77.73393898624823,-14.934339716520668 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark58(72.35549854523495,36.411424274343204,60.48717695158689,36.227437686590235,91.16869212645761 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark58(9.35044771605121,89.91805015042881,-99.99999478990544,15.453411745437961,100.0 ) ;
  }
}
