import org.junit.Test;

public class Sample63Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,-1.0070538255618828,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,-42.55311654035134,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark63(100.0,-100.0,57.599166148144775,-39.5509551424069,-32.78687399246276 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark63(-100.0,99.97879462123528,100.0,-99.97879462123528,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark63(1.0460207508806434,59.870260143379454,61.23240188309481,94.10331948338563,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark63(10.606610190994786,41.783487090785414,52.87827823875955,-0.4881809569793395,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark63(-13.230833899231598,-11.397443816001356,-22.47518774237524,0.36363085259957995,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark63(25.366270328317164,-2.5136646024560783,-5.644740204929581,28.568544738678543,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark63(-31.863805926559195,-44.67001259795711,-90.45142393164174,-77.14676808395376,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark63(34.00455056463608,85.91804688506431,-46.13357076868256,45.35124790049721,1.4761216178559806 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark63(3.7307253341487274,-4.102673989589089,-3.8920678516873743,3.5201191962470126,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark63(38.2264110713449,64.80265270312813,33.25619355420483,83.25015498272336,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark63(40.90482956159072,0.0,-100.0,27.127529582617278,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark63(43.572931331185345,-24.4946845809513,67.13414731561579,-46.49317955523098,11.601519205056391 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark63(43.91800287563393,-18.720419420355114,89.12318002017923,5.04675772726624,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark63(46.14245187501956,46.47035634979375,76.7752793028769,70.50642070865399,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark63(49.48496830589903,88.30365117922028,79.78557951399523,22.59528018221033,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark63(52.2689127819998,-13.410063516911947,-30.644048335950558,100.0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark63(54.6933538557046,-46.746616301739465,67.06428337641032,-31.96229943386612,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark63(6.726980873513227,-0.24700698224592504,3.891210641671892,-18.290353425978907,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark63(-73.99211410706212,72.35523124995208,12.519061115504954,-1.0226228681580105,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark63(75.96337323116026,-5.282275659663128,-79.40203996988413,-1.9231057859225444,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark63(-76.92639677831835,89.51798671665011,-3.027715543062783,-18.10178289252326,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark63(81.16439598202018,-1.7013506987450029,-9.020925427327597,8.353078312173821,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark63(8.439724658099024,63.156669897424564,130.31597686925153,-45.078793380133604,39.84202736627077 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark63(84.77424128113469,94.53230514728423,-81.66790339059958,57.58102474776476,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark63(86.5633322094937,-62.25182753178176,-5.710467465384056,18.951768616047644,-75.28545357198595 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark63(90.6882084787465,-72.64285929325143,-44.10814623105206,84.31163598608492,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark63(-93.15267764136527,94.35485272367302,-79.07790118131366,-65.77902199529234,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark63(96.09333784370895,-92.30796533740356,4.94330877599279,65.23191736528295,-17.620857475616816 ) ;
  }
}
