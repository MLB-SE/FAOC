import org.junit.Test;

public class Sample32Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark32(11.096576539579758 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark32(25.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark32(38.090933036226915 ) ;
  }
}
