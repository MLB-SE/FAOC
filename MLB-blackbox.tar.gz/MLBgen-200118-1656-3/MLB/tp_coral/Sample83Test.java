import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(4.0304658058714145,16.24486369014009 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(-51.83461696445053,-13.04167647772772 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(5.806220882749566,33.71278311648424 ) ;
  }
}
