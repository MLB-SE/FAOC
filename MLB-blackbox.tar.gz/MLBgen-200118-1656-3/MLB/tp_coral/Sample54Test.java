import org.junit.Test;

public class Sample54Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-100.0,100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark54(11.7326126397558,37.253576084882894,71.15322945339852 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark54(14.683612074321587,-100.0,15.215652108070806 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark54(18.618464068203597,-5.333777483986957,59.38087604645776 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark54(18.72491210310578,46.64856765909414,-28.988707376408996 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark54(23.65424660831224,23.59117471665266,58.8264934312559 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark54(-41.923634359080886,-2.7714627067546003,46.15969235471724 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark54(45.55462258298955,-8.638202799785835,45.96647840012187 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark54(47.01826384876756,68.02883258241002,49.822456248170795 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark54(6.516949747725029,-37.86187345326968,5.856424398707176 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark54(92.90782608986976,-37.40258260890788,56.01149813483289 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark54(96.7366140745143,-28.988386729867344,25.897808806925255 ) ;
  }
}
