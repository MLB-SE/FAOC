import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(-3.411836324551018,44.07576971236679,63.858383014491295 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(-62.64659934188901,-78.36342700147638,-38.969854391598034 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(-80.87233793788353,-63.61491393150261,-66.27273113051037 ) ;
  }
}
