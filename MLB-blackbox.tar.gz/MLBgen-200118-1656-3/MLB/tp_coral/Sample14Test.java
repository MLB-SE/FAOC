import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(-0.3370975351684562,-9.611626407699902,2.662435369190817,3.4768308480524155 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(-1.4505952312212145,97.96403538116368,-84.09637529696876,69.01164688543247 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(-1.6600108273427736,-24.22930797608936,38.78436945874293,-62.843929069073745 ) ;
  }
}
