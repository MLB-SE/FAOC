import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(-16.004938844757504,-56.139770194874394 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(91.10780202568648,58.49964693470014 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(92.22324654661728,-70.42460188083686 ) ;
  }
}
