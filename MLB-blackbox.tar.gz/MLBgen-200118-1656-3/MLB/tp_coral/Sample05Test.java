import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark05(47.533932733403105,59.43883124591422,42.096539758764806 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(-72.67035480321539,-65.00543939360674,-91.8444164394522 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(-88.44474928874175,77.97628369614256,-2.4217835364536313 ) ;
  }
}
