import org.junit.Test;

public class Sample42Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark42(1.0,-10.45009771344516 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark42(26.38612008329457,85.2354828050423 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark42(30.32066814801462,66.46266637617768 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark42(-34.10308468239546,100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark42(54.02691900540134,68.79809580230804 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark42(64.55125677744559,38.86901158867593 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark42(68.70394004942389,-8.278972138182425 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark42(-87.70391333234271,34.848339358088396 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark42(9.10831000383277,10.0 ) ;
  }
}
