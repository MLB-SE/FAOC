import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,4.766792180110031 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,-73.11010647775247 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(18.44942475219638,56.49049341890304,78.75827604036635,35.29488130652845 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(1.883297176824783,72.01541545870676,98.82911314152165,-12.346589800483443 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(-21.87100521718139,42.35695144573745,68.90269249492854,-71.17255548480392 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(30.065576217770854,34.246152496225704,16.898977910555274,60.378104628955214 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(40.25182034071716,92.63043881567,43.48904422826044,-18.063450613349772 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(43.515131136487625,1.8250789338994622,-3.3062403775872866,-87.01233851615547 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(48.58227338223256,-38.15410954058014,4.531033588212139,-99.5789234371099 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(52.5840429564027,-97.86131800575978,61.77856143206006,33.855874553466094 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(56.39453538089282,-1.7763568394002505E-15,77.04956752408962,-57.43314692801209 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(-57.28466629444999,66.35031926005375,-77.74600083218053,-8.57588539150558 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(59.56508216549358,14.947430976732562,70.51317523322973,30.920176649725278 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(61.89368047370343,38.199796917822084,-74.14567085068774,-30.251894242042795 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(62.005589908704394,71.62849514771347,76.0910516509285,57.54303340548935 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(6.944418211829451,0.0,49.84984402507574,-0.04570406441217667 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(73.79397677445638,89.42278039314559,57.101861043262716,86.49497775568824 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(-7.60365578381252,-0.001525135798162542,-48.501228733790605,40.89604781417992 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(79.33346049682908,-62.86621696802459,80.89194503281811,-1.2619410602864836 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(8.447746643194836,-7.549625336137197,-64.75052555624393,-72.14292955287996 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(93.54030805944527,-95.06546872914038,59.542649407443974,-39.040247096947866 ) ;
  }
}
