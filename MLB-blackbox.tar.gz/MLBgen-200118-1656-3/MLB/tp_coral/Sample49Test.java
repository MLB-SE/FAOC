import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(0.13348860121166015,-0.3653609191082978 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(-17.884032679197134,-91.96888041313687 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(19.823301076487894,25.610604187549015 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(2.3020098960934092,70.93951208995321 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(55.342204003066996,65.60336098240174 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(6.573879646196801,93.35315885547172 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(-69.04777385067709,68.60013757268638 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(74.75741136449345,-24.75741136449345 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(74.79842087195944,-0.03349552745355311 ) ;
  }
}
