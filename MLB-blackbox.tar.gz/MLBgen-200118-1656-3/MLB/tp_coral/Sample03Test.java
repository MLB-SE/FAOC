import org.junit.Test;

public class Sample03Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark03(-1.9728878183919534,-42.76916889346856 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark03(-36.58467336129294,98.31815822108686 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark03(58.25740153867544,88.10253174777847 ) ;
  }
}
