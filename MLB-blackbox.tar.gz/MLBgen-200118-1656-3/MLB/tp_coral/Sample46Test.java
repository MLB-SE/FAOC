import org.junit.Test;

public class Sample46Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark46(0.0,0,-0.26766824620862195,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark46(100.0,0.9999999999999999,54.525874117006374,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark46(100.0,1.000000000000007,-100.0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark46(100.0,1.0000000206239372,10.433417404094415,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark46(1.734723475976807E-18,82.04934314956981,1.0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark46(19.27449614852081,77.57545689704051,7.113148121402418,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark46(53.46145996773416,61.33692306416438,28.880589934351008,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark46(55.56518589645813,0,4.775152654944421,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark46(-69.02382755611333,0,58.735209897901825,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark46(70.13981725653967,1.0,47.499384554672815,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark46(-728.3772433298672,0,46.73052502662651,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark46(79.12677347563269,-10.091216800600208,29.306146426924556,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark46(-81.08546074254362,0,0.4616907039608549,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark46(85.16467159798015,18.67958240318208,10.454138092780042,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark46(96.78970205981761,0,11.593829821035115,0 ) ;
  }
}
