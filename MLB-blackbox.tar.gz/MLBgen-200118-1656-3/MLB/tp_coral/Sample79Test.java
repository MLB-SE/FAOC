import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(-60.92154059860362,91.32499437524012,34.62901741559398,-6.401963100476721,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(-8.284123121770257E-9,-100.0,-100.0,-100.0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(9.16643527948436E-6,100.0,-100.0,100.0,0 ) ;
  }
}
