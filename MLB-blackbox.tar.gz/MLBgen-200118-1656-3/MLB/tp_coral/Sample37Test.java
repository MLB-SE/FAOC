import org.junit.Test;

public class Sample37Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark37(-22.944877307567893,77.21088313370544,67.51343642125269 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark37(-37.69910848361115,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark37(-47.1715590609119,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark37(-4.732950072266817,-10.468620828887637,-46.71115703575208 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark37(76.66407296453053,3.2221088543584533,-99.06545850688431 ) ;
  }
}
