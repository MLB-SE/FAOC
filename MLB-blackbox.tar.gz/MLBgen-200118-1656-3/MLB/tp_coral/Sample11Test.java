import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(0.531695352542414,-58.4722115297595,48.89889743132634,13.54826409076098 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(17.577021213419755,-28.848021009535714,42.29150390992692,-37.3700521566898 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(42.50450020544528,-32.46199809414858,60.965923457303035,40.06164107416555 ) ;
  }
}
