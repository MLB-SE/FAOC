import org.junit.Test;

public class Sample26Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark26(100.0,100.0,100.0,75.80228232010396,44.74497628628621 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark26(-100.0,35.806765147953314,30.191935297723425,0,19.49265664996978 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark26(-30.64282196890204,94.3809268003209,-39.475799792402235,0,43.787151814753514 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark26(3.4792871880646885,75.5848793345709,-25.651095375738702,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark26(4.791124252299014,-61.36471145509563,-7.494216468265975,0.6559984992064187,-79.3438120305654 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark26(63.15520691227633,-91.92199375522274,-57.458824912122374,-76.38909498345501,-1.6087279743043865 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark26(-64.49417490380327,79.51674964430222,16.71577939546644,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark26(80.61001174933125,83.25350965933501,97.25170436565699,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark26(-8.929356534318472,-59.3080434384196,95.64947287350245,-76.08547839239918,-17.77515186159266 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark26(91.95351147164382,18.220454820135057,36.18969849904306,64.4284156253515,13.175939316513816 ) ;
  }
}
