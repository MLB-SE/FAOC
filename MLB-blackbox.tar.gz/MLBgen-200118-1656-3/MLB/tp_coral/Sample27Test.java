import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(100.0,4.907811825214821,-42.925434442800054 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(-11.656484327772247,-15.880591297799214,-52.69829178525771 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(29.458966510905213,41.073496598470456,20.56027504625557 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(-6.264602015458229,-72.10300230378972,51.125693654734384 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(-67.32295863809246,45.08885079645674,-41.790202393203614 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(96.68044644285081,-22.723588743640335,67.66594410655168 ) ;
  }
}
