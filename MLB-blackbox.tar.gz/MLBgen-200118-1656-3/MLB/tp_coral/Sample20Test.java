import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(-2.4825346177633842,-83.30769745753665 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(-38.754713945306186,73.8877307242881 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(41.249764109579615,-94.49670728458463 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(5.508817575753948,-31.365641278072374 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(66.0097995030178,45.558672189387636 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(-80.67376536010961,-76.3122273739593 ) ;
  }
}
