import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-0.4781908271675519 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-85.57435863393832 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(0.7170639184228864,11.439170705841669,9.683746381564223,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(100.0,3.552713678800501E-15,-10.490035958383828,-40.62000653239342 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(1.6136699640008914,-1.517055823835321,13.3570885942287,-64.54689667251183 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(18.434079896204665,47.606871720662724,71.22615156861045,97.93248497564201 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(31.642621504387222,15.071300682010019,59.73404696751501,11.798458742417324 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(35.211499812539984,-31.65662321321743,34.758039199107344,-24.49901100538348 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(36.11313410977809,0.0,2.4138691021437104,94.08081336850705 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(4.948280241770858,37.88075668429772,84.26472143480449,-57.407531229576605 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(55.42256081834887,43.88217140240184,44.46014243650097,44.590765851524964 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(62.12895487936696,2.730162766085583,-36.28811980216249,17.266117724268767 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(64.04992243991109,-24.978476315182107,9.01701098786367,78.5434559479547 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(64.9776874178073,25.334294338677005,100.0,2.5648114192234703 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(66.40341707598975,-53.59353762399086,-38.95076543459397,31.529461584257348 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(68.65904517057399,-96.11382012544962,-38.08205649660628,32.91691707762402 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(69.0737914574305,-1.37247505008078,-26.26574090489757,71.09708911826809 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(71.37559249364948,62.83189490719717,56.938246066031,77.26924133481565 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(73.15554140308785,-18.4412579789591,80.8922671071278,-26.177983682998985 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(73.61927242883465,77.65407483532564,-92.19518402154638,39.42763502828868 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(-76.83441335904251,80.77650747005974,94.15181288805599,-63.45910794104626 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(-83.64464713168003,89.83179726080942,15.961659725600285,-61.274012912959705 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(9.081995427606298,2.3667871596965573,-75.93500427113337,87.38378685843622 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(92.66392284218357,-95.01610879984696,84.46716383969667,-35.91007061516699 ) ;
  }
}
