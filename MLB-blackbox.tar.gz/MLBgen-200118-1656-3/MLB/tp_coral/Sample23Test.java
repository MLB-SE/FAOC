import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(-100.0,54.71238898419465,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(-21.30770630773479,-99.94341534155565,0,-52.9154517293086 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(34.3360118602308,-88.51007192565564,-14.679436349349658,6.1467928738468345 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(68.35726058632332,-92.60150787205464,-29.670004651267547,-73.33768958408882 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(82.08090259964578,-86.39540925252689,0,-4.9285268087743646 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(-84.29450042226931,95.60706401506238,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(-96.73815109353512,-45.85012214762374,3.612428226520322,79.18852408055612 ) ;
  }
}
