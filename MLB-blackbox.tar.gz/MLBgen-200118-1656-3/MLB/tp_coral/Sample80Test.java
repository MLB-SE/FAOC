import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(0.29588986069169404,-4.069453872104603 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(35.053688225071966,-46.59384701276004 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(45.06789719820537,88.16352646542481 ) ;
  }
}
