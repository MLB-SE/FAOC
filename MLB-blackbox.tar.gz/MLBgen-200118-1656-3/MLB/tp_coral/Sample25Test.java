import org.junit.Test;

public class Sample25Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark25(-100.0,-100.0,-198.70159596605984,31.310015691619974,83.46402700624931 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark25(14.775453432164468,-18.363080831900547,-76.86213665627972,0,53.43142503451426 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark25(-18.93987863203293,-24.958839395612273,65.4797233464628,74.0293758376458,63.20081906240597 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark25(3.3020920351622323,95.29415699487268,-15.456476929537029,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark25(42.795345763110646,-40.05176814229816,-87.29776149343348,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark25(-43.84339211845446,-26.145947739671364,-59.97769652236059,-67.48245228531516,33.15585938994808 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark25(-44.281293593370805,-93.80186064413564,-72.96764855396901,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark25(93.5523717771257,9.58155064660842,88.30954602686646,-12.292067953679009,30.788269274957997 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark25(94.16052810868243,0.6615815558869826,-99.69625069514476,-44.91495158718539,81.80547409429138 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark25(99.97543982536816,-68.6377279239131,-100.0,0,-22.94576948158783 ) ;
  }
}
