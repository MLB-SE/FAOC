import org.junit.Test;

public class Sample39Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark39(18.103371558472386,2.523042522966634E-18 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark39(80.39797716705718,71.8932034477535 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark39(99.55885820472656,-99.34261342815527 ) ;
  }
}
