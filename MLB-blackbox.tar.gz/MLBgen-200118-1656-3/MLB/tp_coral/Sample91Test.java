import org.junit.Test;

public class Sample91Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark91(-17.01033914734198,42.7155858441385 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark91(22.191100867294473,-15.907915560114887 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark91(61.018686526125634,-96.56349581460266 ) ;
  }
}
