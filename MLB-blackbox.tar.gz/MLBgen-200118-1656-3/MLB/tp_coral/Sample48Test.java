import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(-18.37864894883718,85.69780198845615,-23.241954301502915 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(-36.40831790338175,49.16599666365951,12.757678760277763 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(-91.22277202905344,63.13609969039089,52.68062932696503 ) ;
  }
}
