import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(-14.736437255973286,1.658474992053378 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(40.39088633567122,-90.39720895694707 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(-9.35510241319615,-15.927437271335492 ) ;
  }
}
