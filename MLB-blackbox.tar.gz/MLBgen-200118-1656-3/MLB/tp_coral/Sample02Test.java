import org.junit.Test;

public class Sample02Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark02(27.738428499756523,-88.71601520867615 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark02(-30.80903463259051,-97.26236844054796 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark02(55.36784273821792,41.2306757968008 ) ;
  }
}
