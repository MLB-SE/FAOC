import org.junit.Test;

public class Sample72Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark72(-14.895109692046276,-14.895109692046276,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark72(-24.19527117582838,-90.19525372404816,60.75475927583465,-70.78264962124261,35.136754509348606,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark72(-28.17327506729268,92.24366348717476,42.31870641252377,67.46433005010311,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark72(30.349105124798072,-64.08126735421347,-20.432919466170194,48.68211891280526,0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark72(-30.97484981572434,-22.277825682524885,21.977509280623053,-6.297534975604689,41.01353922201203,12.170172304582877,79.696349604175 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark72(38.305540716243314,75.78250445705348,59.46628818519077,-50.342383002993174,66.36644645650503,54.8036386891143,-39.4441409185795 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark72(-4.938565085998661,-39.92892482624553,0,0,0,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark72(-61.24341300689109,-60.25254280590031,-39.059497136899694,0,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark72(63.12933259651459,12.266208928681294,35.822711197215284,80.34258823244971,-14.051824831723074,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark72(-67.48317984464889,-88.27014948166692,-38.097050127242525,41.77198101299097,-13.49764713068283,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark72(-68.16268241246799,61.98813051886739,-86.87303452692284,0,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark72(68.5204029535494,40.173814547248185,0,0,0,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark72(-74.57908684073952,-100.0,88.43821426557145,-75.17590107428633,-115.7849921636959,100.0770683683156,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark72(74.65127091302668,-1.7658859962857603,-89.34030095781824,0,0,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark72(-92.26808660576586,-54.45922582182823,-74.379027207371,80.46325722585959,-95.60635958678489,-39.71061448668443,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark72(-92.4017157957906,19.63709528092093,-47.81066302427626,65.43730808710794,-22.19895392956373,-9.541213878770634,-99.85505013926364 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark72(95.24787262657529,-16.251772631962453,-41.15006538947541,75.0178036090198,-32.8652377590185,29.96466691802863,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark72(96.82307738953017,94.62108392001309,43.49139000466357,97.49643678120998,0,0,0 ) ;
  }
}
