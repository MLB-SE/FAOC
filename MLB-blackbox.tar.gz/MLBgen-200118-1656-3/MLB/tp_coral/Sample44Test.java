import org.junit.Test;

public class Sample44Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark44(-100.0,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark44(-15.856610398317386,28.884777671240528 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark44(23.27511909142757,44.038172573634085 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark44(39.654931023927986,0.738449719444553 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark44(52.79011258647239,4.95119358188532 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark44(58.2196198251728,75.14634158086969 ) ;
  }
}
