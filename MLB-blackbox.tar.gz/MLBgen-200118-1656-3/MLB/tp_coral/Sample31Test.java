import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(-35.99372026151147 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(4.595385854116217 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(98.82946905031312 ) ;
  }
}
