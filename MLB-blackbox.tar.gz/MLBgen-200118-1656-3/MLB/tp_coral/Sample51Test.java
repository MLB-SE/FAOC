import org.junit.Test;

public class Sample51Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark51(0.7507282938535671,22.151305333678792 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark51(10.747932210842094,39.252067789157906 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark51(1.2600982114496824,7.989505377020228 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark51(13.381424452220287,31.791991223454232 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark51(1.4281169439186154,46.07784770800354 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark51(14.386327666759271,32.805978830218464 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark51(1.905413209570213,32.700131971323884 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark51(33.59922399350825,82.52505542579033 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark51(36.84667544893253,-6.07014624609099 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark51(58.44242754642309,-3.7846355405648495 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark51(68.80256208864938,92.08899959521048 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark51(97.02762930307898,22.156531935243677 ) ;
  }
}
