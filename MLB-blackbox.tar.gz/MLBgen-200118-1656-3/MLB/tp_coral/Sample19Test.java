import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(11.114968018336185,-45.56470083475088,-60.43332518472704 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(34.608619407192464,77.28495795149456,-95.28991849464322 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(53.04142197512738,-24.859617132973668,49.11856788665824 ) ;
  }
}
