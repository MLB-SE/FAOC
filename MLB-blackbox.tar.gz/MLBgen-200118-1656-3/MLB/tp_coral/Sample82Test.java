import org.junit.Test;

public class Sample82Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark82(-13.989589758814475,-96.82239358762106 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark82(14.716386633168725,-12.011006351747014 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark82(72.94886228386554,-60.562956217074195 ) ;
  }
}
