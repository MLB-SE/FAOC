import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(0.014693110799221643,57.4715870677818,8.192445077293954,-60.55802767775542 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(54.358300900142325,26.990664607602625,62.542814432758945,-98.18073288606666 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(57.91776083132416,60.53691764253142,90.34740191176931,79.93349987271031 ) ;
  }
}
