import org.junit.Test;

public class Sample36Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark36(-43.98226576353553,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark36(64.17034923273178,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark36(69.45411645942102,-3.8684251639991487,3.6857350241818523 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark36(-74.48637288566661,-14.769884348303535,81.93553571593725 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark36(-80.21688462016826,-17.827780788944086,9.93516844169778 ) ;
  }
}
