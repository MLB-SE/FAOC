import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark07(0,-20.56279945792889,0,-92.35992985804708 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(0,22.26944231768313,0,-60.61480545294991 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(0,-34.85235447644857,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(0,-95.29497715923426,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(-42.91583201416786,-2.447341947495673,36.376383863765454,-25.241937373479402 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(-74.77379821562678,-77.44509863338286,77.57367607002547,50.07123874081509 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(83.03957607872196,-25.812315398344545,66.00002144574776,-48.71098994859233 ) ;
  }
}
