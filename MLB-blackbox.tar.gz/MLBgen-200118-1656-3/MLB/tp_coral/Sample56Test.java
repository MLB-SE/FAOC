import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,-4.849871220872288,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0,-84.87869958796507,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(1.3463810413036992,-49.88666250138078,-67.62713050505018,71.28634501480244,67.83075077506604 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(1.951935485023796,-96.05809004601676,-97.06703894031907,-43.29040134623554,-89.87770777448394 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(56.512020597907,65.54405192856933,-28.097842182355066,-62.57987645215006,-7.457747984724833 ) ;
  }
}
