import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(1.9862152004095321,-26.389659542380855,89.17950192614174 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(-219.8038228964201,-126.7389830856286,-346.54280598205304 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(70.80751730492062,-91.50680959819088,-72.30989495611617 ) ;
  }
}
