import org.junit.Test;

public class Sample33Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark33(-31.11475231920818 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark33(70.37694485771786 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark33(-87.17919613711676 ) ;
  }
}
