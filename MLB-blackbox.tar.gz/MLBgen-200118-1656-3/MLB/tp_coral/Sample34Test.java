import org.junit.Test;

public class Sample34Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark34(0.7853981633974484 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark34(1.3159876113632407 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark34(63.614599274148844 ) ;
  }
}
