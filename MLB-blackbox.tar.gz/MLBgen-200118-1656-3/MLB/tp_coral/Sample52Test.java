import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(-14.797766892950525,-47.963185806647445,-13.75989967810456 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(3.756876312728423,-12.490095260328388,35.13298525924867 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(53.94261428902871,73.8332139771409,82.25399858520632 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark52(59.9095786059097,27.23747830555827,70.74243560249244 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark52(65.06806055056657,72.17773838838352,75.27716408003243 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark52(9.530928760646958,71.10314632914466,-40.59410596071014 ) ;
  }
}
