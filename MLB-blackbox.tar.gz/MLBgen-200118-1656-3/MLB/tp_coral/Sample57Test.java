import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0,-0.6251904879319738,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(0,66.74732030902334,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(11.390317207448746,75.98612777435378,75.61635444502858,21.51864684924736,24.578601165844688 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(-20.125654422048207,5.380411232422629,-87.17685478766053,18.8298086230712,-29.762582067567237 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(39.68440879805891,72.79745974758208,54.85089950711671,81.39513810631297,34.58712735903541 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(41.15832120665139,75.42079093317966,90.39083333285632,-86.9593938138768,22.276568129597948 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(-69.41885124161664,0.3239577580328614,-89.65286955479206,85.67648754736925,-89.20343537529925 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(-97.63701440743124,85.73373652686905,4.19305934131711,94.41813135022926,49.44636027031021 ) ;
  }
}
