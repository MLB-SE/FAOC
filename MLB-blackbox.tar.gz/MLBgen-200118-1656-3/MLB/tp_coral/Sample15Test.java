import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(-0.30214231185728124,-87.66396685409923,78.95811804196086,51.58711793729404 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(36.1198667842211,72.02431912751177,37.59626046308506,77.03354345814168 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(-54.245259954658366,-10.312150828365546,98.66947761086095,-53.38360782806626 ) ;
  }
}
