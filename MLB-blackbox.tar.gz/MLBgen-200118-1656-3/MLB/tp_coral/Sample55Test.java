import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(11.725433482918547,14.73374962618766,-91.95196745256615 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(14.948059661255073,-54.073120732647894,15.902287026442323 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(-31.38933414085139,-70.97082852456016,37.56359716802686 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark55(48.491629608308536,-79.53215826546531,74.08169467801261 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark55(5.137018395490088,-24.523306195092427,3.0921226725924877 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark55(55.81617464235657,-9.489105062662276,63.11222267673736 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark55(60.548264866683496,-39.86720568890662,-16.095834643952387 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark55(66.63867613347892,49.78079002914285,83.19085518254224 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark55(67.7807120016322,74.35181368491601,56.11821238411713 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark55(-74.81077376660267,-44.18780589188947,-75.37721423033439 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark55(82.16738566630636,-91.21742129449242,91.05149246442491 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark55(94.51414632859202,0.09509953856776932,98.49797480086082 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark55(95.99255888483341,-3.0721100096184415,100.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark55(97.23364734233652,0.6533907328152537,44.777427126980655 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark55(-97.79170043249799,-2.7868494081209763,100.0 ) ;
  }
}
