import org.junit.Test;

public class Sample16Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,-0.7314056037822638 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,-22.406789227352974 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark16(26.55997803538901,-54.22042026327114,54.37265748118671,-61.55150317481135,60.74121686387386 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark16(31.945831897827503,-58.49210033430643,-83.23033351313202,63.47477562951008,-4.202511166055473 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark16(55.423764751131614,15.727970904736054,-40.1046946455478,-50.75668760226271,31.706393871284092 ) ;
  }
}
