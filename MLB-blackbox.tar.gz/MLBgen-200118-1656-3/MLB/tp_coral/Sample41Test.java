import org.junit.Test;

public class Sample41Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark41(-0.2537911663014088,0.31820112239403814 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,1.9999999999999998 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0000000000000004 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark41(-3.655295537180365,17.016481001311057 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark41(5.289200470606097,22.686441147653664 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark41(-6.249576897372094,11.059442461564188 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark41(7.592247098922365,50.0499689121727 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark41(-8.635746073025174,95.56539610178768 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark41(-9.106506705433791,92.03497108154438 ) ;
  }
}
