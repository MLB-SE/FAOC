import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(21.010809611535166,32.90170962047807,-69.9223562256477 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(-43.11101368556805,82.20547191384205,32.01593590558639 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(81.69182280734395,-33.57785443311591,-96.2947007727232 ) ;
  }
}
