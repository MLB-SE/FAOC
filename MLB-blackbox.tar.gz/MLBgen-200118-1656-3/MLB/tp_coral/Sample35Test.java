import org.junit.Test;

public class Sample35Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark35(0.4254163000522908,59.49522733916319 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark35(-17.22514644068032,92.26468497218832 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark35(25.953327911535354,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark35(-61.261056751726606,-74.98983406388497 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark35(-91.10620337613234,0 ) ;
  }
}
