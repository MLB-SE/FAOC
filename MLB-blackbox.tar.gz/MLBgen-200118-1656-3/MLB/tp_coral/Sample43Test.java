import org.junit.Test;

public class Sample43Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark43(10.166667155946115,41.32407401434574 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark43(3.597483855881592,0.8341985138573307 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark43(-3.8806932253958593,15.059779909633317 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark43(6.2818843345726805,46.05309448740789 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark43(66.09089918660393,67.43618879023529 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark43(7.366355917334516,71.19000198708852 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark43(77.04523302911633,67.87086259022206 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark43(-83.6301243918591,-83.6301243918591 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark43(-95.36260616905348,-64.14190232242075 ) ;
  }
}
