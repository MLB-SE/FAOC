import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(-19.74893721236609,82.29705242193108,37.610286878185065 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(27.16559978180814,75.86464078723967,64.83989942083156 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(53.39145012441483,66.70044887044523,-35.4024260873897 ) ;
  }
}
