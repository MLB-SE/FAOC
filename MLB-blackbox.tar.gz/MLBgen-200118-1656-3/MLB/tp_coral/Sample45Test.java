import org.junit.Test;

public class Sample45Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark45(0.0,-88.2888134430882,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark45(100.0,84.31029230739912,-25.404701572429573 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark45(110.52394370403866,68.14047081831015,98.7039768272154 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark45(11.457561831921879,-40.25448888544905,40.472623331740266 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark45(-15.10365989354736,-88.28472917281869,7.404350145119906 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark45(2.7755575615628914E-17,1.0000000000000007,1.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark45(27.93151249668319,1.0,95.50014239129533 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark45(28.899627988153043,-32.25970713900428,92.8466725513614 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark45(36.718200263279186,-19.92009798803815,25.545894786954975 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark45(-432.64789350552786,-333.30520790236454,34.09516928283148 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark45(54.953252068908654,56.953252068908654,90.45654400849651 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark45(6.360188982071804,36.731388495601436,88.5802125128267 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark45(69.79363226855193,76.36661727190543,94.3955352981452 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark45(77.37972173314094,30.87771893885912,36.991636778883134 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark45(-78.08878563573643,67.43172955899291,5.962595985203748 ) ;
  }
}
