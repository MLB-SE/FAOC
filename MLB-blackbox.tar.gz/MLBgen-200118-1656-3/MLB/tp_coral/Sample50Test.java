import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(11.457259913447572,16.250868467138318 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(12.345555239047258,51.6453809703936 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(14.01131410702267,35.988685892977266 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(22.08556785065754,23.522251899852336 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(-38.14568351192056,82.22521467288988 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(43.73743201342231,-6.613428158937111 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(52.855681242383014,77.97321813174028 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(63.624499691590444,-7.025222857735699 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(66.14340366239236,-16.14340366239236 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(7.126368953682842,69.62370789014912 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(8.138407025104943,21.138407025104943 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(-98.50231424666664,-77.01618285475186 ) ;
  }
}
