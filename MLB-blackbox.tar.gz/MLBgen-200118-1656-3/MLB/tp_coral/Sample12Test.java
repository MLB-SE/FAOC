import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(-25.87246651150552,-68.64217738421038,66.39559339859696,58.88408993272026 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(45.50520922944378,-98.14885624683218,25.1852723511238,-93.43715682688757 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(47.797833882423106,-47.48303267707528,-73.2712579614088,83.09204035349686 ) ;
  }
}
