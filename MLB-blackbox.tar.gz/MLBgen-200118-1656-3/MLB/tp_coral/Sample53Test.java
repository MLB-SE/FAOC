import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark53(-1.2693332255604162,85.76727470169055,74.86149129280767 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(27.70773598757991,53.758952901857384,28.623966346085012 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(31.652760360374515,100.0,32.493055008498544 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark53(40.053209862670855,34.92149356241379,16.439810227593668 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark53(57.663424612987825,81.3298269398316,89.13398580133872 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark53(7.331126219823659,-77.26744293192853,32.55139986605556 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark53(8.745536709338907,84.3079369576563,-34.7488961270078 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark53(89.83820411533489,26.04951893215926,77.96105195982958 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark53(-90.90837619977029,-2.78597551235765,21.90232045073067 ) ;
  }
}
