import org.junit.Test;

public class Sample78Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,0.0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0.0,47.49246525343848,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-47.673612903737975,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-84.98851013568903,0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-90.0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-23.08780731029114,14.106730431203232,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,52.25374145978992,-97.66075374548511,0,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,56.34174382689967,90.0,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,75.72993352513322,-91.27054644753143,0,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-93.76149510684317,-1.58E-322,0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark78(-0.2181060458032107,0,0,23.518612503857767,-14.093467530706391,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark78(-100.0,0,0,-63.39706354107587,90.0,0,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark78(-100.0,100.0,100.0,-100.0,100.0,0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark78(100.0,100.0,100.0,100.0,100.0,0,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark78(-15.000103607768352,0,0,-100.0,-1.644186591773044E-265,0,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark78(-1.793082220064475E-27,0,0,-100.0,-90.0,0,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark78(243.0,140.0,500.0,243.0,-505.0,0,0,1 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark78(25.721029123468142,0,0,13.775501352905579,0.5765851099789501,0,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark78(-2.8646254165809646E-25,0,0,16.58732446827721,-90.0,0,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark78(-320.0,-901.0,359.0,320.0,110.0,0,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark78(395.0,335.0,-745.0,395.0,-646.0,0,0,-572 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark78(47.44265073035811,-24.41998907691807,82.38159544601515,-54.24960053413592,-45.060070471692114,0,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark78(-56.0,-729.0,-549.0,56.0,196.0,490,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark78(-61.275313372154926,0,0,60.00150552962896,88.61150631831617,0,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark78(61.62501879900097,0,0,61.75913748958086,-90.0,0,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark78(-62.36546298271668,0,0,-30.05125411998489,4.547163144692831,0,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark78(6.799470835080875,0,0,6.588873714519077E-83,89.43240977038916,0,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark78(-6.945272522465899,0,0,-75.9135931781911,87.1362350279492,0,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark78(74.54587979478299,0,0,71.98142727061202,-97.3242453011408,0,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark78(-93.300113727008,0,0,-35.99981925728588,-79.02301263934501,0,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark78(99.99999999999926,0,0,18.773839185674586,-6.1E-322,0,0,0 ) ;
  }
}
