import org.junit.Test;

public class Sample25Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark25(-100.0,37.95294254025414,-100.0,0,-3.6492539759958635 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark25(1.3111686781969638,-8.995218504861942,-41.51365304514147,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark25(32.110304526773035,-28.120867613717394,41.188405345356074,88.3266837682088,-87.62531796912265 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark25(52.35524987005812,-117.19103608163365,-34.08705618479468,99.03930259663926,76.64260424970004 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark25(-60.90481390053775,23.294611563749783,-23.509893053760962,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark25(62.11895536279104,-51.37217659241142,-96.36233296920554,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark25(67.5794180234918,-40.022072835431935,14.50339336445714,4.167481136124579,-30.994238680248316 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark25(69.51108021936003,81.47367985875348,-37.700493480232964,0,-61.86851533512243 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark25(-83.74697944899623,73.11501234382004,38.441371228321884,-94.80271722694344,-61.8495286253826 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark25(98.52010439380379,-100.0,-100.0,-25.449990301414935,58.753962242781675 ) ;
  }
}
