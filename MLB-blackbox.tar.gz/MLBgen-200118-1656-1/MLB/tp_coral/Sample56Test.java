import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,0.2680668028754525,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0,-40.96630992501933,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(18.671639158986302,2.276826663109647,33.649795548806175,-88.19017046771036,-16.158602778567428 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(59.233404135346916,-14.630516619986196,31.46076126918527,1.4121126656560676,-89.04979627192297 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(-71.18036863623216,-35.38143725692598,50.241322265162495,-29.07760296251125,-16.60885362503319 ) ;
  }
}
