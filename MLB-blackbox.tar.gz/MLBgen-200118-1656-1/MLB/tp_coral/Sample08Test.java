import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(38.257756045012826,22.058508184626106,4.116538371204754 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(-86.9080896331613,20.043451333743107,-18.94820140690676 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(88.06372485348015,-10.109249174756158,11.264544894529564 ) ;
  }
}
