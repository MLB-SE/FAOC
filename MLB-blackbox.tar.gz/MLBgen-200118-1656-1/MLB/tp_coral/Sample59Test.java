import org.junit.Test;

public class Sample59Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark59(0,0.012702772082946012,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark59(-0.4165519744994537,14.107149536318971,-3.579790199819911,-23.50277498535776,19.257773774150948 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark59(0,-93.76280195195064,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark59(100.0,100.0,100.0,28.974295601500906,93.82973931171422 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark59(10.620885755307015,100.0,-111.53804018726109,37.04124526471253,99.41067618947903 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark59(11.279450819108078,68.55319250963254,38.669867105182504,16.665798197461456,16.045994947407223 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark59(16.278316126195545,41.507599154121806,-57.77298893912719,75.59311196063658,63.09642995051408 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark59(18.53168962789084,5.214554895699706,8.796810701203157,18.78610427271387,72.55875801230181 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark59(25.48908965262907,100.0,48.022520165948116,9.87181635501174,13.16242180668232 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark59(-36.116815874953474,-4.048822218149285,39.78152014421127,-99.04067889813624,52.230342981820606 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark59(-48.564031374798674,40.06265905956559,31.33027300409404,59.90988545403434,-46.044743844440816 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark59(5.022173813988545,98.12325664435656,6.686633395501815,36.38616348104452,51.64554686347165 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark59(-50.2285472020647,-42.046495040200526,93.19825090163181,60.90183871080569,92.18987332599065 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark59(73.90992513807102,25.267787117203365,-100.0,53.38655033327757,100.0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark59(77.6804047704139,58.28613849616323,54.11199590756428,-47.82456167311055,93.18182361092812 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark59(78.15919830488356,3.446861316566115,67.91914607894012,-33.06501210955261,13.664241857720299 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark59(95.63152971988129,4.719085516843743,-100.0,59.10975902427011,72.08725090725821 ) ;
  }
}
