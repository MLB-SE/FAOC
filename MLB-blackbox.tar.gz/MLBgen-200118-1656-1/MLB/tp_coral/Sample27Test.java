import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(-0.5103105715091232,63.34120318350415,-74.32992838688166 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(-36.42545773607997,9.848883815079617,-20.000151466049985 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(50.46280266498094,54.17610978440227,15.454618159177457 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(-69.44919686580847,22.00103011850334,-61.83486338037476 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(-81.08698978416638,-43.363063983307185,9.605416042955866 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(-89.04021459933108,81.21334379689395,34.4924448638736 ) ;
  }
}
