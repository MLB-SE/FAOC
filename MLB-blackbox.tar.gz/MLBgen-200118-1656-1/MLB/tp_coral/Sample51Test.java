import org.junit.Test;

public class Sample51Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark51(11.900762006247078,29.55734405961391 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark51(1.1981726915442361,48.801827308455756 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark51(1.4159013585353795,43.27560003612318 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark51(19.45247496335017,85.0595829833126 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark51(21.709407053171972,55.42242378778943 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark51(44.004925772796724,79.68869225667697 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark51(-45.91903764918206,34.68163645169517 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark51(51.52737260576302,-6.686389009428126 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark51(79.50933407497836,-29.509334074978355 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark51(81.21999782560225,-9.012213813797487 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark51(89.94034077757323,-63.38857114405825 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark51(9.078484717615138,10.478567537309798 ) ;
  }
}
