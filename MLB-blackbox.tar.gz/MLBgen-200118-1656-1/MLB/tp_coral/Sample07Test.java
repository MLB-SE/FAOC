import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark07(0,14.172945864764714,0,5.08807880348003 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(0,15.707963270953764,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(0,-17.304183445369304,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(0,58.09734789523702,0,-91.09512885306115 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(-12.13378620326479,-63.244333856309545,-20.508716604720462,2.1269676668588886 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(83.60869483262859,29.73243015163053,2.1126025189750837,72.14983129172319 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(86.86420558222764,6.558863434958724,-37.58820890105099,77.84122692584171 ) ;
  }
}
