import org.junit.Test;

public class Sample44Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark44(-100.0,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark44(28.119397170641435,43.76899361984522 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark44(-44.5238340518318,-1.6570180502730523 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark44(69.62682746688893,41.830609520742 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark44(8.684104468779324,22.419932788909705 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark44(96.85286747862861,0.8312021793780104 ) ;
  }
}
