import org.junit.Test;

public class Sample42Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark42(1.0,-18.66605564057153 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark42(11.659537957834061,11.354270329336202 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark42(53.636176701821455,89.21612290334426 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark42(-57.02604143739545,-20.22161449262964 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark42(61.38138564008494,93.62226023404125 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark42(64.60185225294413,75.40237008616552 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark42(-83.1359617292375,20.682934310258915 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark42(9.087205595542578,10.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark42(9.231817217408803,0.8519395838267378 ) ;
  }
}
