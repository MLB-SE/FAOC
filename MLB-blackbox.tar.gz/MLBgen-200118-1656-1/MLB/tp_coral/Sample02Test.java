import org.junit.Test;

public class Sample02Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark02(14.980601072258565,18.583456247047295 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark02(1.9141176812464238,55.514744083726896 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark02(42.4422449791793,-47.154633956310825 ) ;
  }
}
