import org.junit.Test;

public class Sample18Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark18(-0.2639015058338572 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark18(-23.17962865899763 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark18(8.448405865900938 ) ;
  }
}
