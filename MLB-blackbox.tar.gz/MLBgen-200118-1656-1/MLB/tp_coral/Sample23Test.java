import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(0.6588008044042937,-46.92842963837128,0,-54.290203333153194 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(-15.604647111802564,-10.944703120968711,0,-62.38931169560238 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(2.823393288405512,-17.953551192767335,-100.0000007651797,-52.82270234663786 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(-35.85649964544875,-87.84266865572584,3.414799204826352,47.79153864478883 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(-62.38991854500567,46.21990327145777,43.65981329427649,96.16634931531836 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(-62.76896497860665,-10.214153100857885,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(64.34060711266979,-79.65874840988533,79.98389968142595,91.48464149000586 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark23(78.20708712247335,-63.44241600916012,77.817648488598,71.13027071766243 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark23(-95.05031461815942,-56.55856779094678,82.60086791739914,84.90010165277238 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark23(98.03048334358118,21.67059303666275,0,0 ) ;
  }
}
