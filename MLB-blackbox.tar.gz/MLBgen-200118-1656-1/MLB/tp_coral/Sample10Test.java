import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(19.48765665259502,-54.73851003202088,-83.49589756414548 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(-52.355912475367745,74.29231824666357,59.31829543790704 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(-83.65530194280058,92.69749074875278,-98.08428861804306 ) ;
  }
}
