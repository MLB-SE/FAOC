import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(5.302495416470938 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(64.9322673073276 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(-81.39985075519623 ) ;
  }
}
