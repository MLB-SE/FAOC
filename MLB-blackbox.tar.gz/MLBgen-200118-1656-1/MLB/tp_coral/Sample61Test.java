import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,-12.281292809260606 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,97.15349249039548 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(0.15311147851885046,-2.220446049250313E-16,109.26938844160834,-100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(111.99197808236309,1.8646070002503166,-77.62065365188433,-34.725763696127984 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(24.100445885051233,-23.715312950414514,-116.4237004214237,109.81033463251654 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(26.77048201260432,-12.296559901794438,32.519538913229184,60.815784970989085 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(36.33274209886679,-35.3785617301323,-35.72537866631299,-37.44090722982993 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(38.76123593262673,-10.510390433011878,94.16018899117506,75.4489876815874 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(41.480651202918125,63.72767959489414,19.371177940818683,-60.010169266740185 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(51.38962576595222,68.59633325701967,-5.837754105311376,87.0000024814251 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(5.551115123125783E-15,-100.0,100.0,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(58.35520000189854,-52.35578446597054,38.18233857525405,98.30609402169415 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(61.30755328314575,0.0,49.51983915140633,61.15661422780511 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(-65.55738349105582,94.28988022545798,51.66780737894291,80.7321597830294 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(67.1479668097339,-45.36341864673935,-39.40357325770593,61.18812142070048 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(74.40496684156238,59.84736283183395,86.10286523172806,60.2332652568233 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(75.39266071444985,13.148379235184748,-58.02480084832426,68.3699995159171 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(77.70056224098886,-75.20659810613625,-99.45955991618882,77.25973177879357 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(-87.9750143643007,-46.5936780013555,-57.54876949767063,31.08186402572946 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(93.64373900575376,3.110993305040683,10.890722880063308,76.42267012796522 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(95.18147795796605,-96.17168166058181,97.39405009409366,-97.55466093160435 ) ;
  }
}
