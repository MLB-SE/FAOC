import org.junit.Test;

public class Sample26Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark26(-0.4376697462387398,88.86814612954223,78.40610215979606,61.40436104718319,25.15979721775146 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark26(100.0,100.0,112.11616912902956,28.79424998881424,-100.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark26(-100.0,-38.903684951611,100.0,0,-88.69704064232954 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark26(-11.969815890983398,-49.43828131560024,-7.615924622716761,-21.12810193097654,39.682566520525455 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark26(-67.34259660261007,71.5619710868721,57.15638216675046,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark26(74.16420146768166,-48.2551299655551,-81.23641340480825,0,49.78322039591714 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark26(81.6110716306944,-3.2596384229408186,-51.72115087202933,43.53067962119039,36.78802775762103 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark26(87.49595508158902,86.52227498602554,-62.19137049875925,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark26(-87.50040054114017,0.41925131778404534,94.74722187623499,-73.5481619163808,-36.38362394815753 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark26(-95.37234702300792,40.51381622537352,91.13248554816192,0,0 ) ;
  }
}
