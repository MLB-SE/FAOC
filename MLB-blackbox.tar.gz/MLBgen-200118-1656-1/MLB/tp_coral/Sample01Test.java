import org.junit.Test;

public class Sample01Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark01(-34.58971416039471,25.387156638335615 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark01(-74.96696912068646,89.1350144784333 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark01(-92.42920590370427,61.76460833495028 ) ;
  }
}
