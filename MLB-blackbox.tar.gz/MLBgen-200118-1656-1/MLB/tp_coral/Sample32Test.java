import org.junit.Test;

public class Sample32Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark32(13.53315488501184 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark32(24.999999999999996 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark32(50.32216429688117 ) ;
  }
}
