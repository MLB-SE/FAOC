import org.junit.Test;

public class Sample34Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark34(-137.44467859455347 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark34(25.432289466881116 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark34(83.10463653761778 ) ;
  }
}
