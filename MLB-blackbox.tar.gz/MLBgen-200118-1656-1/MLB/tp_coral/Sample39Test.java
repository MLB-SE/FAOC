import org.junit.Test;

public class Sample39Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark39(1.108994782849365,-3.4664427643177196E-16 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark39(18.970355974809294,1.8946337492147194 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark39(53.64780234605888,-3.076365861169023 ) ;
  }
}
