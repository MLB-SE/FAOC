import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-100.0,100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(43.676312836282875,-28.29855016291924,-71.27323963150943 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(-64.91032543277095,26.00437567220449,40.782894080100505 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark52(-66.71135789693565,96.37569422325151,-65.42611277997221 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark52(73.1454759777962,-18.210933358912527,76.09562118986051 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark52(83.43026659159165,78.41879976558997,-0.7148342758159174 ) ;
  }
}
