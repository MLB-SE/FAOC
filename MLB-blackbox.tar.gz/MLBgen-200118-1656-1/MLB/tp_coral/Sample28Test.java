import org.junit.Test;

public class Sample28Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark28(0.9599399865939233 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark28(10.428504930415514 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark28(7.3890560989306495 ) ;
  }
}
