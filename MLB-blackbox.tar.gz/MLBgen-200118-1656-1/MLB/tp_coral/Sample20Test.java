import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(24.896189265947584,-37.125323804393815 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(29.647545857930197,95.99117636618422 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(-65.64879245412118,-88.2608048020262 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(-74.22044236859378,-85.92556017270354 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(88.62365233634063,-100.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(-90.20158445205749,30.11652267363823 ) ;
  }
}
