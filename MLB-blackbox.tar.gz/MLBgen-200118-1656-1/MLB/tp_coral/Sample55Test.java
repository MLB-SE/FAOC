import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(15.844850456702689,-43.79223591161705,22.483230627035383 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(17.869738682089704,2.7351803961518213,23.016783708141446 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(22.657496159367327,-81.2042576800769,20.793622621220635 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark55(23.646307115617077,-69.82653125795039,27.116342294482166 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark55(-31.226520102324116,-35.80578322358659,36.65071674044472 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark55(42.48884647795242,34.09697623040165,43.43634842652449 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark55(49.34947380964417,-1.0461110603269645,12.123711180422418 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark55(5.038718052821255,-168.97529786269453,2.8403928646812835 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark55(51.33603422672051,-49.41163625234187,91.66412701237913 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark55(59.7671217809218,47.11539669232218,60.771220446290954 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark55(68.27402058283855,-87.38800813793182,90.82472795558795 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark55(69.40622746510252,-53.10885523867634,70.34852076754416 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark55(69.89359798918005,-85.75368483982152,29.862685338003956 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark55(80.951771206905,99.98428553904915,81.22591481842153 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark55(95.30472848172931,81.70993291489225,-13.450145080051584 ) ;
  }
}
