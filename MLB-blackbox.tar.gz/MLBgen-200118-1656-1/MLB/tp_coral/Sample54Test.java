import org.junit.Test;

public class Sample54Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark54(23.634850310924847,-47.65769181525727,46.377538676193296 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark54(28.101649175668726,-100.0,29.227545284291626 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark54(38.55565204140402,11.914471255665163,53.611229647123054 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark54(4.604812467241348,-81.10995443875983,2.640555429096545 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark54(64.52043224657977,-50.02543230851095,97.9164871388471 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark54(73.49911963567082,-71.66282274716724,93.49534935992475 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark54(74.34383198988746,40.89387149775209,46.35469158820675 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark54(82.13052829369633,-85.65439640104893,85.59919486967138 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark54(-8.531984960525438,-2.666075364334404,99.9969731962968 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark54(-90.17457835143794,-70.01049841293619,-54.90339342155244 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark54(93.93623589788194,-31.707918330095765,1.6837160467775902 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark54(94.51660399473253,-42.52600905889774,84.71410123140089 ) ;
  }
}
