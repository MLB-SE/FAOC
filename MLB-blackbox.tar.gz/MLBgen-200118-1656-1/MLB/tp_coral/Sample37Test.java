import org.junit.Test;

public class Sample37Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark37(-34.557529025669,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark37(52.187039882122036,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark37(-66.75353918041552,-95.42390915840792,-58.13083102828884 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark37(78.20053447680208,26.821743013448,89.27635070202693 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark37(-98.98526414373234,-19.48603036921635,22.880223656387372 ) ;
  }
}
