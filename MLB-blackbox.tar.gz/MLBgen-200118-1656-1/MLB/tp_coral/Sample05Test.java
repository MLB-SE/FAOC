import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark05(10.121106638069534,-59.358488823221634,12.56404064907828 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(52.244321129711125,52.18416059642419,18.371706212180584 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(57.611517508592215,56.495354632380966,69.82554870942552 ) ;
  }
}
