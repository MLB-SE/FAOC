import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(-125.0426199089382,-492.9653313926763,-611.8231137672302 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(-32.50384074679589,61.87727083936417,-9.666714640185276 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(-8.812940768427893,-62.82021406613016,86.1152644248134 ) ;
  }
}
