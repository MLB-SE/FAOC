import org.junit.Test;

public class Sample63Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,-38.68483076857636,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,7.799887128031884,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark63(100.0,3.072411958637722,-65.58426231710092,100.0,100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark63(1.0870664439081072,30.63353719984122,31.876714036346087,-0.07727899554318277,-31.208195528202474 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark63(1.7607385537604188,11.152738767013972,14.798884021826629,78.36416351418282,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark63(21.42919203583689,66.19852255312713,6.963961788381951,-51.37956893156597,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark63(24.864317660323564,2.562976466181331,-6.503560139987237,39.14631711752416,26.650812889527952 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark63(2.954838993813793,48.99684997696788,45.958580173427,-0.08343080972708351,87.40718541225571 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark63(30.160269076772025,50.1427129305404,89.01580376342434,-1.0772002570773616,12.234367905853745 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark63(32.296339731325844,47.7834976695151,99.46259573328538,42.381049757685076,-80.11067766877213 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark63(35.690257642115824,54.898344868549,153.85460300838352,-21.429664918471175,-16.839568850841346 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark63(37.952277172603374,49.6833277156195,-35.66645347702662,-14.134177391476513,98.11059277613344 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark63(44.623227228751176,40.51123597508578,177.55414116624266,-30.674247880092224,82.424745590188 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark63(47.0554903979952,100.0,100.0,100.0,100.0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark63(4.807730697068233,49.47327122940393,100.0,100.0,37.85416477398786 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark63(50.79666128730264,52.85935245441215,99.99042696731212,8.25478317192632,88.34339173920955 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark63(5.245580510083315,68.59584579930278,91.54533838579209,-9.415718420682413,-17.4931989539108 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark63(-61.76684255769658,67.79400615062795,-62.00497678469068,65.59192842526664,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark63(63.055675587561836,-26.352899301418617,86.24016493333667,-96.36395735377106,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark63(71.44323425113066,42.15152604165895,131.77220725369085,1.6949145371515684,67.15298141837957 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark63(72.12385106386904,81.51891610385474,57.90081882410007,-17.533195039965392,87.9455436939289 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark63(72.95973654831658,2.755290389386638,21.22742767453026,-38.5488700394119,50.3929118270593 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark63(74.87082601549307,7.105427357601002E-15,63.01712097713218,-100.0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark63(76.02505651559676,0.0,-84.54952873590854,-100.0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark63(78.68815382056793,-78.91393199348816,16.741055311699544,-74.14824513445949,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark63(80.53179584429782,92.54478082140017,37.19929078884289,147.5999846675567,-35.31405369806551 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark63(82.76496312474744,7.105427357601002E-15,-26.096152758491048,58.169835094134314,-18.400293048903674 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark63(83.03390593788944,32.025669104337915,124.36049430877084,2.4311041032761906,65.65177549037445 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark63(94.86918502762532,13.566958513775603,46.42096227065119,62.015181270749736,61.0373588413193 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark63(9.72251701048765,-66.96580229176016,65.81841180408625,-69.00626558553718,0 ) ;
  }
}
