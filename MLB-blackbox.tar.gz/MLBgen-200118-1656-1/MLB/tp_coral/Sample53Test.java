import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark53(100.0,66.71737590688929,86.6395780572394 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(17.59053705995825,45.511665762229256,-7.574640119568016 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(3.167413509656626,11.712986936943821,-22.298000443710578 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark53(-4.122711575571335,-2.526783743539512,19.637085866394766 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark53(48.9135294810504,-51.13058332305946,-94.36054984919183 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark53(52.12755159328378,-76.31251492627744,64.13059691495224 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark53(54.31258966064249,43.32447009358103,76.39870674276341 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark53(72.48643927095398,48.23314427949799,-10.913257857329768 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark53(-93.83177574153699,6.026507210415801,-99.68282857554738 ) ;
  }
}
