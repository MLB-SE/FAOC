import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-1.5368789518105643 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-33.79342412250226 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(0.97589185809406,79.80922896740788,78.83333618189998,-4.013025748146848E-16 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(1.1027537112798347,17.80064817171381,18.688944400132517,-0.032983893668917436 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(16.80988793222426,-2.5587433015545393,-10.458889032177877,24.713635671527463 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(18.657918324381026,0.0,-27.22475601710241,26.53077309916233 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(2.146928028185343,86.5240407730802,-45.720287424055385,-32.80753833686923 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(-23.429162025173127,69.57151560345619,-82.79796379928479,-94.21542377540946 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(28.992452739741058,-29.66846268238406,50.53569827210774,-74.75585059374696 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(31.153929875427757,8.881784197001252E-16,-82.1845373674486,80.42181789033731 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(39.407092192914995,-19.69703514083755,49.08079417393477,-29.370737121857317 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(44.6536531375836,51.676840765066544,16.044859960084196,84.5268174352893 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(53.17211582900251,35.1546019279684,96.28792003310652,1.5125221994534854 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(59.587048055795975,33.77187138607365,34.28580115027231,59.07311829159731 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(59.79844732657375,-43.41876366484201,48.1313496694589,89.34531166932598 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(65.0366423853888,-55.75660716221955,52.29946979356663,-77.56504754040637 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(-72.05432429805057,76.39822601847774,7.181198924174396,75.87585239785872 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(7.24757134827189,-1.536311515182092,-4.135952434081723,-9.77086986405931 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(7.89869206881697,-2.684938739172331,71.53307877239065,-17.68087091604914 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(79.54131927721136,-70.06256963831967,82.79513133731189,-17.331980763254833 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(8.652934612322156,-2.845234037033279,-64.40297933522294,70.70788217483934 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(-88.74243771876984,-17.222461068479134,-80.69095533404604,-84.73852588494461 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(89.13093630866965,-41.81398979775588,-57.171698128977155,48.68681051953968 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(99.95747210960707,62.47329918596091,86.7013505762167,94.97102486288537 ) ;
  }
}
