import org.junit.Test;

public class Sample17Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark17(0.18046489751850459 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark17(0.7091520165996087 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark17(0.9163574239398002 ) ;
  }
}
