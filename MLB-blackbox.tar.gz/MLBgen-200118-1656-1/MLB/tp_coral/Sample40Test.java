import org.junit.Test;

public class Sample40Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark40(3.1349886326880636,6.693165094395312 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark40(-54.13154436413399,15.816549039727178 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark40(-8.681071187934862,96.29168511288134 ) ;
  }
}
