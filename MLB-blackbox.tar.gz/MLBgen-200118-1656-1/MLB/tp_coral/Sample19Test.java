import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(-22.844990747829044,-76.38148376037479,25.393767921037863 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(36.25371347659981,-28.487394912379614,-20.638847594440477 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(-52.92154445128627,39.754455060188036,-41.297165953589165 ) ;
  }
}
