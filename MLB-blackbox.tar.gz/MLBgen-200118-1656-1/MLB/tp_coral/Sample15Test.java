import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(0.4347138280144094,-98.5461240068908,-47.52544369608111,0.42356539322378417 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(23.544649620338447,79.9248380052556,78.29430945503961,-31.40398042677009 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(66.86040030093287,-37.43328778780863,43.69446067918685,16.6558008179873 ) ;
  }
}
