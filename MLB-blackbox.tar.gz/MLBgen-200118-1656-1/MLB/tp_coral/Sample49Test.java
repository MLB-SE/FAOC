import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(12.750771007072032,-3.5708221752240803 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(13.456679755265029,-63.225078926107805 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(-14.15831808191048,96.2594342898204 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(14.939574439911027,59.507509594492205 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(16.402165105187464,33.597834894812536 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(31.204041012107922,98.4092117052397 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(6.5628966193868905,20.430246334089304 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(6.68903134925505,43.31096865074494 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(83.14264558979735,-2.7078524869683633 ) ;
  }
}
