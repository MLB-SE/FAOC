import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(-19.55581561688511,82.58974949048442,84.1796398872439 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(31.631483686326163,-2.511795274715837,85.86520960982213 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(90.98411302235661,26.58331682761836,29.378169774763876 ) ;
  }
}
