import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(-12.8967930457583,48.40093861345176 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(44.491028137421836,-1.4868208179793925 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(95.80905632298077,61.518287604622344 ) ;
  }
}
