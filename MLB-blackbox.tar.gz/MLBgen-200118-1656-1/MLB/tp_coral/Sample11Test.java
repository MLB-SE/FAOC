import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(0.9416342221412816,73.16179141077349,-89.69822336116529,-2.1052047746052245 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(10.629631149164439,37.69878130567585,-16.883623369892646,11.532907380663502 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(-36.00392881161025,-44.27767969192749,82.58763732096804,24.633418169956528 ) ;
  }
}
