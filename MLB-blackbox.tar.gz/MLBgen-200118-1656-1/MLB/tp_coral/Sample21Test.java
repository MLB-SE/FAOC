import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(23.43560477435241,-96.62786988168313 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(35.15739521274469,-63.75633441465707 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(-35.8972997493085,97.01162708126449 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(-59.60845648316449,2.7611870145225907 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(-66.03187793292551,66.56303613591663 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(-94.39932642024567,92.93614579683847 ) ;
  }
}
