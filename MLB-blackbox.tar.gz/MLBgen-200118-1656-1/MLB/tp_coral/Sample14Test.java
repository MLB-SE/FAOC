import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(0.987796929963892,-75.41543454518356,67.27192907082039,-97.43312674481565 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(27.81141310284208,-6.5646250061498534,92.35986611836006,-44.14177085474456 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(48.65572872339595,58.722786190871034,86.1236360614487,61.97104781916235 ) ;
  }
}
