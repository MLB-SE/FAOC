import org.junit.Test;

public class Sample03Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark03(-24.72400052311118,76.56027930734277 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark03(81.36290664009215,-25.40252121341706 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark03(-86.51405099652871,53.73210433028646 ) ;
  }
}
