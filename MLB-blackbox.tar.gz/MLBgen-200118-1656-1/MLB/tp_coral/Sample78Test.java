import org.junit.Test;

public class Sample78Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,0.0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0.0,-61.20959727778281,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,28.13331212428821,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,56.82038793574708,0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-90.0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,100.0,-90.0,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-39.269709551659936,-80.15827191877844,0,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-42.46367783173124,-45.84893814799082,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,7.160510301575428,6.438433682035509,0,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-99.9652141668224,-1.63E-322,0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark78(100.0,0,0,8.89103499794031E-162,7.898241443906031,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark78(-100.0,100.0,100.0,-100.0,17.233758092088994,0,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark78(-17.00063995594448,0,0,34.53990479151352,32.61295829320508,0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark78(246.0,-48.0,132.0,-246.0,205.0,141,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark78(337.0,806.0,626.0,-337.0,233.0,0,0,-489 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark78(3.505240578718396E-24,0,0,34.960676246463436,-90.0,0,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark78(4.145723946952359,0,0,-10.609775025040975,-34.930068795187296,0,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark78(-45.90882035983978,0,0,-100.0,5.304989477E-315,0,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark78(-497.0,-305.0,595.0,497.0,139.0,1,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark78(59.88840723903192,69.68399655687,-74.22193613508495,-22.862834112629926,6.82663610922279,0,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark78(61.7600947020718,0,0,83.87831880709658,74.91572546338037,0,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark78(64.6343553145333,0,0,-100.0,1.3007796349561859E-259,0,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark78(6.901023827596849E-26,0,0,-100.0,-90.0,0,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark78(82.35533788780104,0,0,18.62531764528421,-90.0,0,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark78(82.70641958130281,0,0,-4.207760185971779,-59.63615714580648,0,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark78(-82.80666868687368,0,0,29.535357009642524,-29.30115744436354,0,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark78(-87.0,179.0,-1.0,88.0,-146.0,0,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark78(87.69651227484508,0,0,-26.29478366808955,76.35043934080085,0,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark78(-93.9721199999446,0,0,-71.24605674150082,-60.93261485378649,0,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark78(94.68247866162736,90.98286555394832,-89.01756265099931,-94.68248469455904,-90.00059362887168,0,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark78(99.99999881963504,0,0,4.580192685097262,-90.0,0,0,0 ) ;
  }
}
