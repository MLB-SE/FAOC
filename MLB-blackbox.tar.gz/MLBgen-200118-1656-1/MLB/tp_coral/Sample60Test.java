import org.junit.Test;

public class Sample60Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark60(0,1.2767530085714611,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark60(0,60.36807931765074,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark60(-1.038580898322881,-36.955009125841556,40.75290657935605,96.01809190413434,66.63039216553668 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark60(-2.106615310515677,89.6685243394393,-86.96235244125721,70.46540421187751,25.36101931337467 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark60(21.654014538748783,29.073367408772867,74.35997275342575,62.12088853576827,93.01723423109908 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark60(42.315411546343995,17.578703412294416,87.67797148721115,81.92893825449184,39.29338951570023 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark60(49.130104968277266,56.76689221120043,-72.70425523926183,34.70552984832361,80.81261622794523 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark60(49.939329816137004,9.559001820285786,-59.39432676602993,27.30490623274521,92.76392718499191 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark60(51.661961745010444,88.62702542027756,97.05070447674831,6.628939629353937,-65.7000614463217 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark60(54.989162119762796,-54.681249564423126,-26.736758894991368,60.789528235258416,-94.59436360775761 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark60(55.037930826735874,-41.37930973867485,-13.204043437866076,36.192661755304044,-87.30692284477061 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark60(55.583915589473804,53.37150438609521,-109.20026445506551,155.97902694141368,16.14114502529401 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark60(60.804946733753276,6.034264881211587,90.67612083493864,81.21449768717854,26.155605974853277 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark60(87.12155052171343,51.44555257824925,44.78574032256353,46.62624254661054,47.46725027466121 ) ;
  }
}
