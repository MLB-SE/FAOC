import org.junit.Test;

public class Sample72Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark72(100.0,100.0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark72(26.981346519113615,56.26726475095899,-31.72444632611125,0,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark72(27.322861165687584,-74.47199439091494,44.8895073099396,13.096170142778774,-34.822481099530506,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark72(-29.45702272601335,94.66352128526945,-18.8035997896375,72.34364734640597,87.35841725399484,67.7804579126382,-96.05479179494634 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark72(29.820625500774497,81.2912941050042,0,0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark72(30.49486930329409,17.407458616874848,55.106570459952366,0,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark72(37.92533045180241,56.308526862306906,0,0,0,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark72(40.07359594815637,-18.508474139777036,-94.20652626452356,-0.6073079398530865,10.06876563598707,-84.05745578797757,11.636615507747777 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark72(-42.906124905980974,-5.343398235669921,33.72150960343287,-84.23382862663811,-82.27058201362092,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark72(45.48972440230787,33.864800576627175,-93.83604691392593,-91.42706700644221,6.586620515523549,53.77558773235231,-31.06069839518635 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark72(-49.178325687871215,-59.896648033209686,-77.65528641422642,-14.040168278253034,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark72(52.60946981968809,27.906551804120298,-47.120350605765296,22.521663439077642,-2.5979346624215793,77.8022336905824,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark72(56.74264192562311,100.0,29.685981593211096,-58.255018928042304,80.15365833913378,11.019765078932648,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark72(59.286682747601134,84.45195328249076,77.25871349772206,0,0,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark72(-61.23557164139178,32.72267410723097,-100.0,-100.0,0,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark72(-72.68651384384899,50.58633768102115,-28.445854264025414,48.14534106096687,77.42845827961264,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark72(77.70008122093981,72.67119799757603,73.54513914915819,-9.519806463862096,0,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark72(8.303898748885686,-99.99980822340183,-24.80762831909722,-21.433029868587965,-69.75958504169724,-46.47934314112511,0 ) ;
  }
}
