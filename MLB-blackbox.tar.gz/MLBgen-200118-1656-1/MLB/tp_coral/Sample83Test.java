import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(0.6476711808787009,0.41712205950631603 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(3.4959688584308304,12.221774473432578 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(-36.234535253745356,43.58763934111042 ) ;
  }
}
