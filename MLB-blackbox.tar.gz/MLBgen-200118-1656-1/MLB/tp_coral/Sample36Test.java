import org.junit.Test;

public class Sample36Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark36(-30.600175084257202,-16.130225737606565,4.4709015377150365 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark36(69.67415385507172,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark36(70.20877863645993,22.48494836501547,66.87126596702649 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark36(91.10614693355977,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark36(-99.97149932804072,-39.206040739020494,5.351979894804152 ) ;
  }
}
