import org.junit.Test;

public class Sample41Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark41(0.006485128347629705,-0.006443071457944475 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,1.9999999999999998 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0000000000000004 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark41(-1.5825446896452888,4.086992384369792 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark41(1.741787673059754,1.292036624963158 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark41(-4.04793834018659,80.01008540753122 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark41(-6.904378477794497,54.574820642426346 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark41(74.26670101089184,65.77877630203929 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark41(9.550642813478177,81.66413533716417 ) ;
  }
}
