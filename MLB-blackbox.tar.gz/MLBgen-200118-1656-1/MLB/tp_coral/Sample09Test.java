import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(-15.49075568332043,74.6767200219037 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(28.359523741396245,9.99438742299796 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(-66.97361338933746,77.92437138267027 ) ;
  }
}
