import org.junit.Test;

public class Sample58Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark58(0,47.26197236700608,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark58(0,5.080019758733727,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark58(12.281972647560153,15.750542896667156,23.765943113746175,88.49795360014573,28.505064116808114 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark58(-13.601398274744355,3.565482165611485,11.032845076093764,59.628192925087006,-67.47543286232053 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark58(-17.838904267833982,-47.765957975800674,-39.74911510448016,71.14398282830007,-56.21351433710187 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark58(-26.675095777623053,-2.0671964802508747,28.665899493196953,98.72878177460795,-97.62189378122375 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark58(3.872670882277463,50.75868181483117,18.27641356481081,82.2397542955444,22.87126004346899 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark58(41.10819729008634,69.77189638653371,27.21198196506674,-21.72265125659392,58.95412965731518 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark58(5.160042952709887,1.1250547999364215,-6.6837592058351145,40.964156305259934,23.351164724986887 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark58(62.51572265503155,31.89578477875124,-93.91191463724125,92.65358054504952,47.650429406214684 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark58(6.37429137558068,-38.34466399134377,31.09351461294625,-25.18102907529324,-6.52335591020479 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark58(6.497505945376238,6.962211479852897,48.6906513764118,36.227562065547716,62.95791097041564 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark58(74.56808684240885,1.0714523497902206,-38.02311958941059,64.97377080973408,68.76687313747355 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark58(-75.93752706496008,23.3155721814788,-22.824720217259326,-95.43384238600218,54.38096913675551 ) ;
  }
}
