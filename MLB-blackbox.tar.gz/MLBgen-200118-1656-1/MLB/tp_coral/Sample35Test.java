import org.junit.Test;

public class Sample35Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark35(-23.561944911189727,-44.27230914416278 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark35(39.32656124033571,26.77821558306117 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark35(-5.816335034352221,-23.504288916467786 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark35(81.68146065896073,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark35(-85.74033436485342,0 ) ;
  }
}
