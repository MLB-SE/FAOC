import org.junit.Test;

public class Sample43Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark43(10.721230459246158,29.0964339330545 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark43(32.23200574360024,64.02978870477759 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark43(38.841936963204006,-97.70940197762536 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark43(48.99709173986068,-55.613652863073206 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark43(49.847413399305026,52.20455642400037 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark43(-64.64909966258799,-64.64909966258799 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark43(72.05551087014524,60.72577146995951 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark43(7.323968451943941,55.5789439245748 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark43(-9.169597841388594,84.08152457279836 ) ;
  }
}
