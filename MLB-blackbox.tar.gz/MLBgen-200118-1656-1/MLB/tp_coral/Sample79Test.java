import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(1.0776067480716476E-7,100.0,100.0,11.820905144276379,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(1.3866959484512695E-21,84.80980929021794,15.756715957860337,-36.82988874341694,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(-93.82728998305083,-94.74237382103057,61.57362919975347,14.289640911971091,0 ) ;
  }
}
