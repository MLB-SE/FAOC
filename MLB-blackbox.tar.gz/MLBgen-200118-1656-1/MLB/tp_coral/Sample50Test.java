import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(10.415105223569602,23.415105223569583 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(14.538955627010523,35.46104437298948 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(17.363261206578557,42.08278666495704 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(2.2754734501209555,8.144224783557192 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(29.076364985958463,75.70299055308658 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(-30.883021819362803,-17.883021819362803 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(32.173843502522026,-5.672199176908549 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(52.58897666338845,57.49750132707908 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(-6.381767782776706,38.35293884515329 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(70.76679072398315,-1.7663698638567809 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(7.776217752845582,33.837268247809504 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(78.8050560580428,-13.981562704496156 ) ;
  }
}
