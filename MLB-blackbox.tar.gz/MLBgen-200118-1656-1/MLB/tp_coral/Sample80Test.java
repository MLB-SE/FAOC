import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(29.183220556146303,0.9486006009133189 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(-45.97585558406816,-25.168427001883998 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(72.86852742129662,-41.3374230256978 ) ;
  }
}
