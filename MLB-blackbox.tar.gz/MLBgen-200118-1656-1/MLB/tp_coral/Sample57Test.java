import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0,-5.031206242670791,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(0,-89.45680669714284,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(13.257778810557141,53.472883246140015,89.69263137031146,16.190600898430404,-43.50969419928039 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(-30.363848062913917,45.34467877912323,-79.0428109638919,-85.43514680689464,63.5028437219421 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(79.15128174233567,9.318070115380664,72.11074671260965,75.25616258196578,-42.47844120364548 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(8.685541449773915,40.67810171494747,21.000940185846314,3.095189700986097,23.28199799086532 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(-90.45849465472502,1.2789257356390635,-57.841825340213646,9.040588192201298,-13.835897873002793 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(95.5531807702665,36.73979320627092,94.84293983483721,-73.03627912317828,14.666311571395596 ) ;
  }
}
