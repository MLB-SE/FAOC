import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(0.09532386524480785,52.09671940889672,51.85790818098488 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(-18.907186753254763,-33.66219386960955,-52.569380622864315 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(-58.71732570231478,-61.79192179313247,82.27856998917113 ) ;
  }
}
