import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(0.08438533290242844,38.48637639482058,-72.96985221016877,-76.58140543505785 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(-0.1927882221693695,-72.88075285570203,-28.41657048585418,1.304187412505911 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(67.65012863824248,-3.195391396866512,30.537352055462264,-93.88303780410259 ) ;
  }
}
