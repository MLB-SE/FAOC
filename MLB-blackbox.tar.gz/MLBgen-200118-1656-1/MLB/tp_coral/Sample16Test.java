import org.junit.Test;

public class Sample16Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,-2.7995958999357526 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,28.689793379408087 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark16(41.407971791593326,14.224350085957752,30.098813923992424,8.373137851962412,3.7882520665210535 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark16(50.94757644360769,15.471307995153136,-7.59761417084141,-9.992408574890538,-10.787398700221857 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark16(57.266081040510244,74.77645989959291,81.95035635077633,55.323868832150396,-58.90712044277877 ) ;
  }
}
