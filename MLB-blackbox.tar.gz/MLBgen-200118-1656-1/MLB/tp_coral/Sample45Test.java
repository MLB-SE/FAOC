import org.junit.Test;

public class Sample45Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark45(0.0,-86.16398651344807,65.21636059637044 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark45(100.0,93.67991413324754,-84.46519496261509 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark45(-154.56246941067684,-514.3089093194016,66.7813434276975 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark45(16.94232542126855,71.93809666711707,15.087871696279805 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark45(-1.9536419921279702,57.64526654895596,70.48918802501441 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark45(27.570269575092922,65.24248409282535,53.71851555807885 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark45(31.54121968583175,1.0,7.046859629890577 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark45(-3.71336647601413,-67.80515469802717,16.38811226448587 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark45(65.30550671986092,66.99029580142249,52.17937207455094 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark45(6.938893903907228E-18,1.0000000000000004,1.0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark45(70.65189343027859,19.304155282037243,98.0087677721371 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark45(74.58647463891333,61.57464000486914,10.504469258667726 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark45(7.899555139941114,42.904450464094545,27.70956400218543 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark45(89.43097217433277,-70.76910747852011,64.13038836515099 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark45(93.77427035476754,95.77427035476754,25.65196591126417 ) ;
  }
}
