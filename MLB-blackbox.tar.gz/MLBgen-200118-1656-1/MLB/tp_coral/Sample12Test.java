import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(52.047450010157746,-72.94959714829557,-39.20629456362157,51.02925066257421 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(-67.59563624616399,14.813978090441822,33.96347404024985,-25.40879198455687 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(89.55901034777821,30.994650330361594,35.07458965103595,95.8106377798272 ) ;
  }
}
