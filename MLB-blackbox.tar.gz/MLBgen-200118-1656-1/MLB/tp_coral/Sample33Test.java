import org.junit.Test;

public class Sample33Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark33(1.3711911960892422 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark33(-36.91371367968007 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark33(44.584672932525734 ) ;
  }
}
