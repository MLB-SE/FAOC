import org.junit.Test;

public class Sample59Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark59(0,-0.6259944525138508,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark59(0,-82.37641479314243,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark59(11.20033423409167,84.84635417484844,38.25820622854468,13.679619619603201,19.07228157554058 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark59(12.24656300161849,99.7404557850429,5.181037332829348,0.7400462225167388,72.51589227405715 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark59(18.125310422106452,12.448688353016507,10.90491023076656,30.251655701191538,8.536494472773455 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark59(2.2937176634433456,17.657119097174657,-19.054927009199247,129.8310027244853,-69.98869756105513 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark59(-24.624230604120317,10.422995725833223,-248.45523759478016,-48.46620752874286,87.87315184586771 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark59(-29.056164526726008,15.58434602122773,-74.48283915247416,43.32077815695584,-10.212983800544961 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark59(47.39544816945832,1.7180475355768294,32.98485825389997,-68.66195053169717,109.88280288843296 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark59(-61.51528002423397,-27.34751383120384,-81.2373818707195,33.981874005271806,27.092055894742444 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark59(62.279802291498555,46.50414382214828,68.40462533537192,11.094879323541846,86.63895186250167 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark59(-72.42887479537967,63.49003023951889,8.632812225183145,59.33246183438189,80.47064285295181 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark59(75.5213237859045,55.19053588103705,-130.89349443507533,98.87717983998797,70.42012309311983 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark59(8.421462783397999,42.2089891067848,33.916499426833354,96.21256082859082,-16.27788742851837 ) ;
  }
}
