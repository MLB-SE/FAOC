import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(3.246162860667048E-10,-100.0,-56.91000020163636,100.0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(3.7233247902965177E-9,-114.51070427215198,-92.79465112200818,-100.0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(-71.2727249478173,-57.18726426506389,51.99676208512017,-59.683320081640126,0 ) ;
  }
}
