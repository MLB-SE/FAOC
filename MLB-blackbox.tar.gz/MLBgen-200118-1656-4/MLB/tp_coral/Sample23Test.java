import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(100.0,-90.69193775858695,0,-0.992522757278828 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(11.968958839822477,34.74407462756727,52.797344230827775,-56.605306805598275 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(25.616832705606598,-42.513860984246406,-0.8265337339466754,-26.211898445589014 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(56.8958933210526,-26.097306735143306,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(-58.62674516996774,-97.02930738237478,89.20183947129756,-4.962230048279935 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(-65.58990722946434,-6.474954560209828,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(-6.57110047943128,-64.11110253214642,0,-41.54132825188886 ) ;
  }
}
