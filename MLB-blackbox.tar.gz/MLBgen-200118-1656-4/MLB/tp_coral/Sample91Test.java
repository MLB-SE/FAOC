import org.junit.Test;

public class Sample91Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark91(100.0,-100.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark91(54.659548348930684,56.60423690127445 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark91(76.45112233816133,96.56400007753325 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark91(9.42477796076938,-6.283185307179587 ) ;
  }
}
