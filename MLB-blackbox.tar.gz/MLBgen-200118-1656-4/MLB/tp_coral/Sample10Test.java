import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(68.29031270846521,77.22092549181002,32.89869920782681 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(85.30080242218415,94.0186284070235,87.95677440251711 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(-96.71281160929426,71.23001193137267,-52.739939840661876 ) ;
  }
}
