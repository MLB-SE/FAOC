import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,1.8414263568224953 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-58.07585769677874 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(0.6274096667925306,82.353903541417,93.32532876062135,51.13006901257947 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(0.9875942105003144,-13.55979041037265,-13.475417964275698,0.9032217644033635 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(10.649897839379662,21.840045782716857,71.27320119390495,54.005651375843 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(1.3656702775132845,-1.1869459682199748E-66,36.48801053325384,-32.13832396083067 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(15.869391200704698,87.35886790774362,19.82983147788302,81.75512311707271 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(22.461238628501818,34.95954566051833,30.713472558991725,42.26719004552996 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(23.38806003472275,-2.4699814742255772,82.97823262483806,-34.20054085708584 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(27.15889321937439,-38.90679378444071,62.68394058225272,-1.373198471070296 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(36.40504275716353,-16.005672745349358,55.773001912111596,99.2418901595031 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(-42.84487366410645,59.66303154020011,43.06848205334924,-21.944630303382894 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(45.569701090652785,0.0,27.64773247401085,7.925873815948105 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(45.61823263948088,-23.139291519644402,92.15994738303809,-40.63310060882645 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(54.58088055308629,-46.29036327249618,88.93454410911247,-1.179098125279047 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(64.91640015550425,-2.1634275776563343,92.24777529111924,12.433317672549776 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(66.90026971422238,-68.4841108000681,62.97232016886687,-39.75924146155213 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(-68.66308644325173,-95.87801479494185,-64.1713876899499,-55.695688984275705 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(76.64198276547089,-48.54136075583073,99.93820561336184,-13.697580063357378 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(-79.1079149166402,96.0198161350146,91.48737900098678,-30.416931914691986 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(80.76904745457742,-22.730508680321655,13.626821241603949,44.411717532651814 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(83.02998642396398,-30.870577888996536,-23.42569351113471,-65.5939547492931 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(83.7852114408027,-18.120535939957932,92.53762392016628,89.19928059977858 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(97.94603310990232,-59.39559115205424,-40.81004547150528,92.34326140034528 ) ;
  }
}
