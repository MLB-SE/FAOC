import org.junit.Test;

public class Sample16Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,20.90030111559622 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,3.8766291133036646 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark16(10.06910139784081,-39.47692669684595,61.215995531025925,-36.208443810245484,-27.59805729598301 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark16(13.088521758964205,15.225689593800867,-69.35673979678234,-50.47165851692756,-65.00731123326528 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark16(78.87727997671743,14.206460606573359,84.77854573165408,-93.3555796563964,62.254543013248366 ) ;
  }
}
