import org.junit.Test;

public class Sample60Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark60(0,44.30794927505474,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark60(0,5.046278890496552,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark60(1.3032177548151278,51.08831105508247,65.09034299304203,2.882926949017417,97.65415690028289 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark60(1.4005005954877987,-47.54337172158631,50.10957880606168,-46.263519106645454,-90.20602843147172 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark60(-1.5048424018602513,-23.628612602870536,24.507500901431225,-25.94557788804821,-25.55302007279162 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark60(16.03948913750739,26.786394890990877,32.873978327461685,64.10410110334595,-21.686017277600712 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark60(16.180728529158642,91.83579661108527,33.48138794785473,87.06506661587329,1.3471660578565263 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark60(-28.600572290810618,-83.34083626513309,-89.7643205292976,-16.544624626841298,6.477893077937807 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark60(4.015613238649224,51.302262940441835,-56.07625562210978,100.0,90.37510203406293 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark60(5.488032474136276,62.65059403456427,12.865956183419874,36.99993362758462,-0.2763189992795816 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark60(58.17550410220714,94.55362794582834,1.121515291048337,31.138227918410934,71.86747551847296 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark60(84.90143029069378,36.831849503797855,-54.61142586051806,78.37090743465248,0.12649406424453957 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark60(-86.09516340097048,-31.2411909186373,-95.8620013595963,-77.75370381600366,47.623973304356525 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark60(89.08929029801874,96.88431686604056,40.016793198931225,79.40261180748374,-64.91090426711787 ) ;
  }
}
