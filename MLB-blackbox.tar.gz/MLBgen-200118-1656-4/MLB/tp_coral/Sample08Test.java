import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(23.978489287318304,-65.25473304165962,30.478796344358784 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(-96.62257902331089,-33.68598638251996,41.781882545204155 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(98.5121686904391,-70.27082563659262,82.81754995793293 ) ;
  }
}
