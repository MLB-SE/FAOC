import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark05(44.87410120397266,43.54831296426963,13.6782098204703 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(72.3619943319728,-51.71811388481346,-93.00862015743485 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(7.7374830399868415,-56.55048371418459,98.9594143945329 ) ;
  }
}
