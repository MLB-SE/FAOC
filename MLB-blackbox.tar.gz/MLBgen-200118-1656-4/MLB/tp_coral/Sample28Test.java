import org.junit.Test;

public class Sample28Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark28(22.423145475384402 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark28(3.803605176504778 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark28(7.38905609893065 ) ;
  }
}
