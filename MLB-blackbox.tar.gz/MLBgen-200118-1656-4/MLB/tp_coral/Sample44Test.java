import org.junit.Test;

public class Sample44Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark44(-100.0,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark44(18.13862156988435,9.28737627405205 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark44(-19.04019796793743,74.99577507151378 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark44(27.594809872075828,57.781245051173016 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark44(64.22359768168599,74.8040364495792 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark44(84.92315372618717,0.13744198158814847 ) ;
  }
}
