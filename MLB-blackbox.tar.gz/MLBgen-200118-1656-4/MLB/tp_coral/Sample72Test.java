import org.junit.Test;

public class Sample72Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark72(10.679247324803782,-13.460198800141,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark72(-17.398290992433004,-74.38156740735506,-55.72189354446668,57.21607171700459,-100.0,-90.65583281162613,94.6497244614051 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark72(19.786475793443216,-87.70721207557158,0,0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark72(19.95744199676237,38.532274127034896,44.60366489819265,63.07932171269513,-47.10759151659627,-27.19952596407198,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark72(-23.5297845202265,-42.83181103993173,-22.17958696079076,24.84143200976972,73.29820377611458,-52.365502367477156,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark72(26.028638137514776,-89.40431071876438,2.156303411886924,0,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark72(-36.23658974075343,39.03325415364313,-43.1378991246111,-3.8911418410114322,-47.71703627805426,65.45882127383965,19.28837925926902 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark72(-36.311977586372144,14.32082901124359,0,0,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark72(-36.67063742153991,-99.89665694700889,-64.27786066807786,0,0,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark72(-42.60839982157134,-100.0,-100.0,0,0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark72(-54.46678610128976,-74.85028021723024,18.36742005117935,-77.65927215761769,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark72(-67.52737735807462,-23.631926256260417,45.274671756388436,-78.84265763383601,-63.17388782613815,100.0,100.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark72(7.736621105291918,57.98785518714843,-30.02691143282715,-100.0,-100.0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark72(-80.35135467696006,63.302083391418165,11.456525609002725,-24.561076928991127,0,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark72(-92.66421250590507,43.838705047899,-19.351516147180888,73.95657876261555,42.93517291601779,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark72(-96.97676481064995,100.0,-76.9399228821481,-70.71493183657219,0,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark72(-99.62511610455844,-34.68286529675457,25.12035706762991,-64.7974983547235,48.87404265964203,-68.12237705726216,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark72(-99.91676517876171,-16.10057324521719,-6.003183798553621,31.22457412634185,-32.62132506707236,0,0 ) ;
  }
}
