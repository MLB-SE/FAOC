import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(-0.3805525478829408,6.262127130381446,50.261392280631696,1.5288358947737313 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(34.621086522822395,47.60151847872868,37.726684596327374,39.9179517971578 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(60.990476478642904,73.91612335724716,45.21910201433272,99.73352445942126 ) ;
  }
}
