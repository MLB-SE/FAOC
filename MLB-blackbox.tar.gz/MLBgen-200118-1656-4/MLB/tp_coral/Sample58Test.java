import org.junit.Test;

public class Sample58Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark58(0,-26.165976245159285,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark58(0.6233856194034305,-98.17572583635284,-59.76236429713311,-9.261068218583858,81.60603796200454 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark58(-0.8660173587242133,52.052405927340544,-51.26624382167297,-84.19467163243043,80.75339111619556 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark58(0,9.158839646058851,0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark58(-11.29776415189258,-81.20072111988763,92.5526604665341,32.108093914531196,77.04105397855176 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark58(13.035579539596469,64.36830764958137,31.479067944280246,12.498915341316817,-28.04593940709441 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark58(13.95342433583231,96.70584378197259,96.43501316081895,77.61648548198022,-90.41801393261785 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark58(19.29870994422427,-67.27520369074485,47.613003433907984,155.83601187644922,-61.79868647786623 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark58(-1.9360213134274575,-65.34452915368976,67.3787269830179,-7.706705057682556,84.71550678748045 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark58(22.780904879282886,43.709860870234905,81.03215598909867,-50.27010897994617,-8.394852704108601 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark58(41.379495512209644,-42.57391230783681,-71.11890520873018,-80.88551673924174,-87.93014155723877 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark58(42.72698793000163,11.959939168239941,-66.08375261453247,-28.98311747933245,50.36628523751469 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark58(7.533437268599698,38.07344211259348,59.78981744940427,7.726679608263524,93.36006877741428 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark58(99.44752330512536,22.385999644061343,19.647387752524136,86.64108555269655,29.45326353685735 ) ;
  }
}
