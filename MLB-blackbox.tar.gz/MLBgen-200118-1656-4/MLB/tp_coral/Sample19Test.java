import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(33.78994496262561,-94.98569904927967,-3.5201733938138347 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(-60.30336429023724,43.28727197946455,46.686888183649955 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(-68.44623479393832,35.293029251617526,92.25204627580968 ) ;
  }
}
