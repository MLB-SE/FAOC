import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(-44.494387490380575 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(50.46736507652008 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(5.418114534410101 ) ;
  }
}
