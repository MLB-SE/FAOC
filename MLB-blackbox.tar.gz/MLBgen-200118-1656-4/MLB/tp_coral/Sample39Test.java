import org.junit.Test;

public class Sample39Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark39(0.9946730394892948,3.813837842813004E-15 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark39(28.67978332188639,74.30673806097414 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark39(87.17838001631577,-82.92376206548843 ) ;
  }
}
