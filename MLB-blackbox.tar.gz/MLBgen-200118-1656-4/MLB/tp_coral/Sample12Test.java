import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(52.473707650801,-7.142507175268477,86.38501301963507,28.93800980415986 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(64.16352142439999,6.424651902622358,73.99422390530776,63.80930039503215 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(-80.75238627375273,85.23364324625584,67.30601335179207,-79.06127367289908 ) ;
  }
}
