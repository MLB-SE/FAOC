import org.junit.Test;

public class Sample25Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark25(100.0,-100.0,-0.9013058923199928,-35.08239232976311,-79.06086643914317 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark25(-100.0,44.2793708455437,-100.0,0,65.37929849189563 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark25(-14.594577515134858,-27.12750001671295,44.81541579550178,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark25(147.2958078683668,70.14220400766337,55.05754392933875,87.8902605421635,-64.38229598698184 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark25(-19.837706186180696,56.408151905390184,-94.16008128591609,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark25(-4.400307613509511,-36.37743544815939,-64.95220683981466,0,36.39547471608731 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark25(-44.59570195138984,29.500063837553938,4.685014328346199,86.01830107182715,90.90821149889916 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark25(-77.4026155657274,30.99644149228604,-75.71983208766272,57.92251561858538,93.44902555412159 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark25(81.92632147724959,69.05087181498456,90.52076380478624,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark25(96.56662014409397,-95.42540120487519,47.4704735751188,31.426892165097456,11.138186111781806 ) ;
  }
}
