import org.junit.Test;

public class Sample36Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark36(-10.031605598608422,-90.05352296354992,5.690605783199794 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark36(15.586570394887474,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark36(44.0518682957329,-57.07062208224685,93.53967812858144 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark36(-67.44826896033862,31.338806727010535,2.3956387940930597 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark36(94.2478327014845,0,0 ) ;
  }
}
