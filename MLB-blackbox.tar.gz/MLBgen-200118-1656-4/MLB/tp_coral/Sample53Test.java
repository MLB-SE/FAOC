import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark53(100.0,0.4899796606162994,100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(-20.591714361340603,-3.2301753706499556,-19.59528701143259 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(36.594792608363676,-44.548743272050494,56.73671397422308 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark53(42.63024377307719,2.771909291226224,52.13634081104645 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark53(43.498008167285576,3.0977872249354306,55.850049083805736 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark53(50.31169783406884,-76.68136321438408,72.18009457066648 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark53(51.07163322462597,31.30473458814288,46.04092129134156 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark53(60.46042603969923,-95.36453713453959,-63.90143679889275 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark53(70.70019909733071,67.88259826553457,71.00210041531975 ) ;
  }
}
