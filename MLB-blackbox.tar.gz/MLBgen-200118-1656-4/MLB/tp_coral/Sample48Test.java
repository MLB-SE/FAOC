import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(14.412948618070203,-81.5414788672166,-67.1285302491464 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(46.81978095240834,-86.64413137356435,-90.14167934848538 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(-78.75087176904671,18.966857106046504,6.225756140321522 ) ;
  }
}
