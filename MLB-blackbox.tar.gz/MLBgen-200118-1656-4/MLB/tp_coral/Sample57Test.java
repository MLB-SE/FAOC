import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0,2.349472000195135,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(0,46.07979168076409,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(100.0,100.0,100.0,100.0,32.55976226269505 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(18.303292625948814,14.507505562803374,-71.27028802800052,76.81668734717246,85.26667679013164 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(31.087143336803905,73.32895992025615,-4.508872535448987,75.96920853740949,-50.860085881094605 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(-31.093280615016283,23.302147893428057,76.9027281521422,-41.696724458485356,57.74791628401209 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(78.1793946317054,15.010163104017835,32.818275811889606,-31.08342395510053,61.21906427234978 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(-8.909334868653382,-8.682165824815272,76.36047813362552,14.31311125522123,-93.67170379507198 ) ;
  }
}
