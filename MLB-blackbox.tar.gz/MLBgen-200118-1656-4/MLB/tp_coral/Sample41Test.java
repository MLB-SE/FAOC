import org.junit.Test;

public class Sample41Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark41(-0.045361539782945215,95.219952667527 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark41(-0.6050345849475889,-46.301468905580975 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999996,1.9999999999999987 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark41(-1.0000000000000036,2.0000000000000107 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,1.9999999999999998 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0000000000000178 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark41(1.639149568018098,1.0476617383158193 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark41(7.967348277230002,55.511290293449875 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark41(8.827830160201074,69.10275517715465 ) ;
  }
}
