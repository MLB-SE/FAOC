import org.junit.Test;

public class Sample37Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark37(15.707956862042243,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark37(-34.62517118599516,-18.857396557989148,-77.46542199748092 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark37(-53.67142393716677,-3.716098420260863,-43.0745009354341 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark37(-68.20401146996592,-17.00525350790788,73.69898510101663 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark37(-92.28967569473885,0,0 ) ;
  }
}
