import org.junit.Test;

public class Sample02Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark02(-13.978997310122189,-97.23120263088659 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark02(30.375208173502614,-52.31805699750929 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark02(97.13693670535639,34.28910171336713 ) ;
  }
}
