import org.junit.Test;

public class Sample54Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark54(0.051396590278622735,0.56762710956219,-1.9670411529416327 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark54(11.084026701678681,-106.07547146629204,8.940758346493153 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark54(19.603237001502578,77.7835890415694,16.189869139556976 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark54(-24.142200337773147,-89.300262982082,99.86155648773723 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark54(31.92304988507115,23.934733566127946,35.0472066066383 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark54(36.48221724476017,-225.38747870265905,34.02382393641994 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark54(49.8326385624175,6.263433410335978,58.07489713092292 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark54(50.049830538034776,-72.7523033752825,-78.09780625145916 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark54(64.43869909888397,-63.425465379484926,69.08153962560269 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark54(79.90447132661956,-67.29213125165282,-94.91082486943931 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark54(80.01181344314814,-96.74639516581684,80.66252689751354 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark54(81.63892996660604,37.11913659414921,83.73764764880406 ) ;
  }
}
