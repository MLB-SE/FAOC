import org.junit.Test;

public class Sample82Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark82(37.44086306844463,64.44764751593931 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark82(64.05863045877567,16.23743319872743 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark82(-97.8839302331375,71.51598378820364 ) ;
  }
}
