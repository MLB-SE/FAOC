import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,-19.95074034954594,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0,2.4821088750110363,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(0.5937042524595593,-85.27063370150422,-32.07587513546501,14.702189225284584,-82.18810760686273 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(-55.881277826381634,-76.66569627364228,-85.039009512427,-30.693826007994033,-71.27919381458906 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(80.82760428761961,-97.08486066896005,-99.63489739865882,84.74181065435698,60.21104310222802 ) ;
  }
}
