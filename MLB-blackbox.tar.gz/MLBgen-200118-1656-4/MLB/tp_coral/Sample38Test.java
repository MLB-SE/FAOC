import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(30.72753354065827,19.729922392331158 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(76.4788629678064,-61.735627784918854 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(-83.43512266272133,30.710266845622584 ) ;
  }
}
