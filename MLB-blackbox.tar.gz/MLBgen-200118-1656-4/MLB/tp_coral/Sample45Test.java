import org.junit.Test;

public class Sample45Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark45(0.0,-9.118145208266805,-86.54050271312103 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark45(100.0,26.582877152455552,-48.84051260549016 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark45(1.3552527156068805E-20,1.0000017040600542,1.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark45(-1.4210854715202004E-14,-51.10633696871756,91.16641765847254 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark45(-147.10834377042937,-479.59078156067324,59.46160619373751 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark45(1.6516458078765996,1.0,11.289423084674954 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark45(18.043067367648092,82.11464739531024,74.58903285446021 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark45(2.100698747557985,7.1255300058534345,60.835976943414835 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark45(28.862776869024373,3.3926848147923607,44.0315283533788 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark45(-42.81386310645168,94.0676992001764,4.495865308030702 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark45(43.003785275044066,45.003785275044066,43.687278796270846 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark45(48.20061510327463,-73.42315846878532,72.2026050910707 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark45(55.485612746088066,6.234168032605297,79.15945588307352 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark45(72.58379351391628,9.031610516079482,24.570999005204456 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark45(93.53073293975856,95.38224104894252,72.58120735121375 ) ;
  }
}
