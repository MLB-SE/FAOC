import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(26.496834437336744,18.913636904924672,34.68214253436622 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(-36.7105320218232,6.62062800636876,-38.336073704523145 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(38.44725421018552,-33.2256164797857,5.973733161746097 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark52(4.78115321288772,-64.88208535566122,-27.616782208247464 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark52(67.54053491540537,-16.27016004482134,97.1640906652593 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark52(89.23972121139886,-3.0963950705688035,72.77997626854372 ) ;
  }
}
