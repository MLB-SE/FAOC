import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(-36.25844972864822,24.741174785978075,-54.965806235688895 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(-37.84530704342457,-47.52857922254825,36.24834715794426 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(-83.37527337452686,26.07889185131735,-84.55133719360532 ) ;
  }
}
