import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(0.37113492075910415,-23.633530167605898,-72.64850374410806,92.11434293658903 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(-13.762339733357607,60.84820597862998,-15.58518773460733,-67.42300858116542 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(-21.744944032078777,78.91992747646844,-4.061432816500911,35.08243806166209 ) ;
  }
}
