import org.junit.Test;

public class Sample51Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark51(0.5363979220147748,43.35063922689719 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark51(0.9150415405884758,12.511985601246794 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark51(1.3267629368498328,28.522204782418697 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark51(1.6552224763461936,-1.2865544980086128 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark51(18.68745246638673,31.31254753361327 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark51(19.767177689970353,25.210336603478737 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark51(25.7881495303169,46.079352394830636 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark51(26.159544455407286,40.541912111232506 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark51(4.037947705998931,45.962052294001055 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark51(53.06509651187142,70.95244756833216 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark51(-88.96757744047348,32.22421432223621 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark51(95.32877840295944,-9.101743579089216 ) ;
  }
}
