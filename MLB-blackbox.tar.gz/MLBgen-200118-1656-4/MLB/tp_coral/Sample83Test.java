import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(32.45738476791348,-27.223706360449796 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(4.679698286537568,21.899982431853413 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(-5.669794710139149,32.1473130251645 ) ;
  }
}
