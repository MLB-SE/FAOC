import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark07(0,-13.913692469053814,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(0,33.77111231405868,0,76.70059840814295 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(0,-86.91739675262697,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(0,90.88027308648917,0,68.44259715449125 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(58.570477729114856,-20.273918567658058,0.9605988849825877,-49.120533012368604 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(-76.8191701496701,-64.60392188067064,3.7712662139843034,-75.64812577421922 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(84.39294085439352,-68.39523332631492,58.600255865073905,-27.67232284098951 ) ;
  }
}
