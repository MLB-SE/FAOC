import org.junit.Test;

public class Sample35Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark35(-10.995574296274604,-69.67819535789901 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark35(53.407017874597905,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark35(-54.40141573637931,-32.71185042556468 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark35(69.4328913624214,40.66149607910893 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark35(-86.17384530563241,0 ) ;
  }
}
