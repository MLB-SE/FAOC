import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(1.0251483245253064,-0.567600289559776 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(1.266490628510718,-1.1253846580217441 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(13.336359146235338,26.336359146235345 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(15.901241145516607,21.650654358087323 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(18.495487312250617,31.495487312250617 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(38.27887650563676,42.09061707563487 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(44.443478370389926,60.22894893873948 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(52.600838889596844,-56.519854721280296 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(5.927791900627398,29.859770559122666 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(62.22455013403487,10.386917154593363 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(9.169485966812815,15.40805696941014 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(94.15926266215345,-44.15926266215345 ) ;
  }
}
