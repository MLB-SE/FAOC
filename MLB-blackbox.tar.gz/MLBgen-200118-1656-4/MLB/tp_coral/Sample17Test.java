import org.junit.Test;

public class Sample17Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark17(0.6911928197883128 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark17(0.7091520165996087 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark17(0.7651888075909561 ) ;
  }
}
