import org.junit.Test;

public class Sample84Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark84(0.9999999999999983,1.000000000000007,1.0,77.07730551003863 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark84(1.0,0.9999999999998543,0.9999999999999996,13.079140236591025 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark84(1.0,0.9999999999999716,13.615163325565831,-100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark84(1.0,0.9999999999999982,-100.0,-48.20355795861894 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0000000000000009,2.2838736448684216 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,45.600163421342316 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,-5.876726353074744 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,1.0,70.1133199079058 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,-45.875016224176264,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,5.191094523530346,-20.04582654806216 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark84(1.0,1.0,64.25026941877857,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark84(-1.8813664998142803,3.5395399066234363,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark84(-3.6064196664333537,23.18265831964095,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark84(5.829158881043668,33.97909326045026,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark84(-72.27266195992779,45.918358332184596,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark84(8.751501245736492,76.58877405412737,0,0 ) ;
  }
}
