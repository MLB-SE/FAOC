import org.junit.Test;

public class Sample40Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark40(2.518740917838386,50.370452852355925 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark40(48.60875730491739,5.250642472947646 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark40(7.521375268918604,49.049710666981795 ) ;
  }
}
