import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(10.520939182812876,-3.2435997260471083 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(22.178958224246983,27.82104177575302 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(-22.807504235957182,62.730843082866215 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(31.723786685097338,61.7571226931847 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(32.41228140014621,-3.4288897861722774 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(3.6530533943510903,20.52340056035611 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(61.45551216027576,73.77443232157529 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(73.79667388963321,84.12938060676828 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(92.3557188618733,-1.4609718330140566 ) ;
  }
}
