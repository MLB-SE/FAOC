import org.junit.Test;

public class Sample43Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark43(-100.0,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark43(1.4781773227349646,1.4781773227349646 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark43(30.57401926380348,94.69868412966596 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark43(43.32527488020031,83.06559315970412 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark43(5.015445249837612,30.011601501179257 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark43(80.12841516082932,0.42362202078625444 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark43(80.7024331032992,88.56148717605765 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark43(-8.724372425257195,76.11467421458812 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark43(91.55152529176823,7.599458057606796 ) ;
  }
}
