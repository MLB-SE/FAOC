import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(-21.864808447557515,17.141077223506482 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(-22.498297535449694,89.53197155411038 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(-38.09156765322466,-30.556896181102246 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(-52.05352547459352,-34.68437283576978 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(-97.52781419440535,66.37759365014901 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(-99.36374657626273,-39.52375817034033 ) ;
  }
}
