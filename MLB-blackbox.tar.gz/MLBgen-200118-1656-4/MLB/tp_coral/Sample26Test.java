import org.junit.Test;

public class Sample26Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark26(100.0,67.23303232030204,-100.0,0,82.30382847856067 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark26(-22.777961722707502,-35.596049971126305,-10.158474492517385,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark26(30.754542324495883,-66.72466189764226,55.518306658827136,-29.573099436899444,-36.21677571252874 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark26(-31.074658730062183,56.60083790355416,-82.87708035667869,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark26(-33.9206286751386,43.22344178368439,72.69004057574645,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark26(40.52866934407996,2.2805966168573093,-35.11125775909885,0,22.60219466718945 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark26(-50.48777869841483,-97.59549238709968,-87.30542630923854,-72.94371725469645,41.06726227795963 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark26(-54.67498060927633,16.465560378126938,-33.73885754656473,76.0824084047837,11.500804555571904 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark26(66.4459112223343,-52.415781927421754,-50.83648636072277,27.38613283520128,-45.45759872495796 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark26(-99.89322698547224,-2.030906568165448,98.54206038987573,-40.36151108377547,32.028336200377424 ) ;
  }
}
