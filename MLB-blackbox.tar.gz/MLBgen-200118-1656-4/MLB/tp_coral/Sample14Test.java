import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(-0.3599360934534488,86.32284089443729,7.0102818200011825,17.44137263921253 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(48.92726043728172,12.274949197817023,-72.16905024839681,-27.195558699378736 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(-69.23679335442183,-41.103953834211815,89.52197034691068,3.597888591101267 ) ;
  }
}
