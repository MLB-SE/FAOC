import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(19.61724232438735,2.7408142025938282,22.08619059259068 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(-41.99241099448602,-2.7715068349053062,-41.08638113793811 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(-46.70904641849681,-75.34858169656536,-47.80711891889338 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark55(51.21523140925592,-27.915832874614097,-84.21072269659092 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark55(59.88238167982672,6.679234005124528,58.15586989984186 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark55(6.437536578779685,-56.7057676323999,5.76471103794457 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark55(67.55239188262209,42.72423917994644,71.28885006107996 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark55(-73.84353402562823,-38.056552716746815,-46.469972763387915 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark55(75.28722043007468,-94.67455817571535,25.966885064238653 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark55(76.82489698262606,38.70958284284757,56.72256026328046 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark55(8.488758650357738,77.35987027362756,-32.58997708039561 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark55(86.752756815997,7.340620690334831,83.61680734676496 ) ;
  }
}
