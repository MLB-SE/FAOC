import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(-20.159295700047384,-9.31594205644079 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(-23.36446667646569,89.7898160091724 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(62.85731950739381,65.34281218069069 ) ;
  }
}
