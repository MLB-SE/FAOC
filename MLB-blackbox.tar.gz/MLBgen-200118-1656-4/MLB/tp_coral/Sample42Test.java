import org.junit.Test;

public class Sample42Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark42(1.0,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark42(1.5418269615195612,42.589325677911575 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark42(19.013023738207295,7.144615372358331 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark42(-5.7539647611839655,-62.2750750655773 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark42(66.79196499051108,94.71215382498985 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark42(71.64044159184607,-16.470918187892366 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark42(7.861417790225261,9.999999999999986 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark42(79.28107783524621,86.60690332485649 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark42(8.997299687571015,10.0 ) ;
  }
}
