import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(-414.7931056745765,-167.956274253098,-586.130492900678 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(44.30919812647181,-46.54654942754255,-25.207591765100872 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(-90.60900130056122,76.43968809885672,14.874848462528647 ) ;
  }
}
