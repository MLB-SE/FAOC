import org.junit.Test;

public class Sample63Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,-1.3497895354231275,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,-85.6180362934782,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark63(0.9273057670803159,26.417993435001478,25.43966032830405,-0.032809933012708486,-7.20860474585475 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark63(100.00044214336393,34.24253406300588,192.00032836782748,2.920357528342357,42.03852361032907 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark63(100.0,3.1512416172535693,30.25272129684287,72.91232717635307,100.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark63(13.673591312068538,41.59395338283244,94.86662434325285,77.96693087685975,29.57039067831687 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark63(165.29692636007366,1.4601023810366343,-79.45715936103974,132.5580574664155,100.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark63(18.887625709851164,91.10865732934158,75.08669743636239,13.394906924995922,11.095814750619894 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark63(19.325544503446302,52.53949718920008,100.0,-11.166032622348302,0.135437437681027 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark63(19.665615869090963,10.306264677987292,45.62334398456673,-11.06390969562618,61.29336432840706 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark63(20.247651582673235,7.308204130142812,27.03733719479873,84.4324468623781,36.504186865008386 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark63(20.766020147072098,1.824489019085684,-100.0,30.50755554338838,100.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark63(22.325242940956727,67.03874180352943,161.3233352581742,-34.935657000205694,56.62099062264531 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark63(23.64526909095818,22.465859654420072,-77.11607994808318,-83.18879283896268,51.863911387011285 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark63(25.774032187422762,-11.816173956470877,-59.9885078222925,44.34128573807084,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark63(28.246762752339095,66.10075954448828,52.634579151129714,98.78897315723842,79.53532162231923 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark63(3.453416505058442,70.93958127063296,70.93958127063297,3.453416505058449,100.0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark63(37.3368328643719,91.79010007323046,147.57942253141664,-0.4596273157247168,42.71681332049707 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark63(-53.3229886451325,61.798566300011714,11.885810445936215,15.46818246423625,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark63(54.974979971961254,85.87976128682908,66.8713251257716,73.98341613301874,94.63221989449477 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark63(-60.529122963568625,-61.9736061769615,23.690180578351388,-78.57676185282887,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark63(62.820098636718214,0.0,-84.78811107310932,41.03609388157982,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark63(-63.01201265305316,92.58147173428642,5.135724199207175,2.867335333191704,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark63(79.7707696202369,93.54135783577377,40.3263699404049,-30.74470298622161,93.30306009982675 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark63(80.63881862792992,19.195684709138998,100.0,2.3054497946643835,100.0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark63(90.81238134903663,26.691701778697976,42.111711846823596,-5.865398004396383,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark63(91.89867758914016,15.053309230360924,39.923306902343256,80.02575728424304,-50.011410215417065 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark63(92.89523121779294,23.004922286112546,42.14720415066705,87.38781634030656,-2.7444058758668177 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark63(95.02480182425577,2.556632823781399,56.442128893912496,74.99847090858893,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark63(-96.62627648579816,90.58932111291011,58.28566945720077,-9.654812046310894,0 ) ;
  }
}
