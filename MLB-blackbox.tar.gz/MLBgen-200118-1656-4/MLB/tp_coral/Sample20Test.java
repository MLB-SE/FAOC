import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(-23.93692478529887,-88.59012008407552 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(-27.61527584648173,-87.72311657806151 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(-48.68374209022204,93.73325123705007 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(-59.09740462190791,-84.03277982913377 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(-63.00446079688984,13.40446085795486 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(71.24823214087272,-4.872004787946963 ) ;
  }
}
