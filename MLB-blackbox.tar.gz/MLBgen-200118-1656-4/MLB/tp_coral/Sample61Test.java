import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,-0.9858150375595613 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,16.68053919419421 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(0.6043382248261767,0.0,-80.33176365466964,16.40326285404079 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(0.6545140589470506,76.3094937188481,61.735939553070054,-62.72052586098884 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(0.6717640829035618,2.045988427987524,-37.760927823596965,44.28486232788163 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(100.0,7.105427357601002E-15,100.0,-100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(35.776679776183386,-19.73993988815765,-76.58630126544097,93.43492033585855 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(40.08111469705357,-40.47171580931218,52.899001257488074,-2.4482675099614113 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(-42.18217952483645,20.660191332253248,78.41174417961577,79.57374695952325 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(46.72222647323372,9.944484890688045,83.64142781301729,-82.97024472607055 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(51.4687138441684,83.92525673341572,74.91326527637494,60.480705301209184 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(58.04780969103521,69.97415969382052,99.69401536318301,46.50410759235817 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(59.84344734102967,16.164332599833358,26.84130851528468,-97.12277013667507 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(64.10913472361986,0.5657854275926457,-57.62753578264179,-85.46867445333288 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(65.23269775592824,-49.09609214692017,78.26475966172899,-1.3286739311291669 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(65.2691115322674,-31.38860614178371,-58.21858085051359,-43.21867413836023 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(66.39322599720578,-28.648278546026134,93.26179666152419,-89.49211109824422 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(-71.94180377597486,74.25142038348625,-66.08313782230928,-28.612167754333 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(72.53474647583437,17.834930746896887,83.47047097253244,-2.051752015020412 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(88.88215079742184,-55.30472258416279,95.95786929640738,66.1092380619641 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(89.96553914277807,-2.9928708229438508,99.99999999999983,-37.03051896243247 ) ;
  }
}
