import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(-11.247865603758655,25.216776744328342,-98.55661376139106 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(-32.07643504029444,-0.9578121116339176,-90.08449762911388 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(-41.49563095097432,-47.41052695519245,-19.284823131870517 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(-58.2628613771165,-58.590488697279206,38.42924568313035 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(-62.50197512484554,-10.818120945119375,13.411968770584153 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(95.41674949512796,-34.388872860887545,-85.6888826714875 ) ;
  }
}
