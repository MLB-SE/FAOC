import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(0.2987392779526772,-90.51640410815473,-37.528328809804435,25.07010883143495 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(23.18626077121057,-20.593412934037374,-60.17298264110919,1.5195412949597653 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(25.548093064918078,37.581471917504615,-68.30533770602443,81.85015164202918 ) ;
  }
}
