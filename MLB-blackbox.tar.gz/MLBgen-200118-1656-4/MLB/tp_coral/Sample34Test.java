import org.junit.Test;

public class Sample34Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark34(57.33406592801373 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark34(-6.152840096683249 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark34(76.51269288772986 ) ;
  }
}
