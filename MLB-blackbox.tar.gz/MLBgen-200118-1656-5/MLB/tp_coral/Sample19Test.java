import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(12.246348080766992,28.831966859598026,-34.70863804544244 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(-49.75632656294717,-20.65654113669946,-24.60522758472841 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(-84.9029393811133,58.0283681710894,97.77572494755213 ) ;
  }
}
