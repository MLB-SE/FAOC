import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(57.05651778002536,85.75656480154294,49.957265144241404,92.6257256344407 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(58.46672062635213,5.365426715770212,-11.141649478477419,-80.82998805312403 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(-61.2346182888563,36.54508961285481,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(-71.25470586272009,80.13887251805414,-4.6414145938237485,-78.06986967404443 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(-80.64899349739044,28.036318997383944,0,-88.63098502536823 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(89.62586478131288,81.7029895380594,0,30.945727880748052 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(-92.22116752803855,-90.54869666618954,0,0 ) ;
  }
}
