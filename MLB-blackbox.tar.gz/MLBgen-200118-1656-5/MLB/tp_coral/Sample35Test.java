import org.junit.Test;

public class Sample35Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark35(20.42035225420119,-31.447918703133723 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark35(-22.189725399650072,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark35(26.23327842553691,94.90966939195076 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark35(-94.24776136132242,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark35(-9.753398665412888,-64.88434568702854 ) ;
  }
}
