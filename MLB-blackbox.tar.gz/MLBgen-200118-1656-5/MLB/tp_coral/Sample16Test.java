import org.junit.Test;

public class Sample16Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,-7.262259799641839 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,-7.461855205421415 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark16(56.5388291475122,15.127791959256129,41.48782046660853,53.87062060854589,98.10791449560966 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark16(71.03682730566105,14.266274937521317,-33.66311024423422,-38.99346994001252,-4.390116578779526 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark16(87.3129896299188,15.165362791312404,-88.16525382143507,79.48182825547349,-76.8379594499094 ) ;
  }
}
