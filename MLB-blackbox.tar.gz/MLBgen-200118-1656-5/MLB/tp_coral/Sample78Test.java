import org.junit.Test;

public class Sample78Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,0.0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0.0,93.12643081322705,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,48.81471956262084,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-74.20988962031403,0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-90.0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,46.57531569418929,90.0,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,62.91448925523489,-5.29E-321,0,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,75.88327993294081,26.083137284698736,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,78.12562384456757,67.61739112703478,0,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,80.70645105382019,-77.0259424641287,0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark78(-100.0,0,0,1.557374211108995E-207,100.0,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark78(100.0,100.0,100.0,100.0,100.0,0,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark78(100.0,-100.0,-100.0,100.0,-93.88973089137826,0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark78(-11.048244399368912,0,0,49.969791495934516,39.218443368106904,0,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark78(-15.393417142224067,0,0,-85.44280715461716,8.71357793686866,0,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark78(20.260115942269362,0,0,-44.739821181147406,1.550650161452515E-266,0,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark78(-22.197458591571014,0,0,71.48956468908891,90.0,0,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark78(2.6240785978442636E-26,0,0,42.66889555712287,90.0,0,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark78(33.761818911849986,0,0,33.62362470526604,-90.0,0,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark78(-48.50509379669463,0,0,-74.89666335971052,96.9579070242325,0,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark78(-572.0,-476.0,964.0,-572.0,-628.0,108,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark78(-5.8309412573402,0,0,60.24446002614815,-55.21024015663709,0,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark78(6.11900619844611E-24,0,0,-105.09813606482618,90.0,0,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark78(-65.97835087301414,0,0,11.61753718725717,-1.7671319659017684,0,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark78(692.0,-1682.0,-782.0,-692.0,577.0,0,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark78(6.963161133719524,0,0,-41.30430673810246,46.53952611186932,0,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark78(-779.0,732.0,-888.0,779.0,-1260.0,0,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark78(-79.40377791827449,0,0,90.34406565416765,-72.61365054730274,0,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark78(-871.0,38.0,-142.0,871.0,-564.0,0,0,1293 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark78(-95.71085638947623,93.24615381401799,37.481975134961885,12.272649070057724,53.72377247472727,0,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark78(-99.982070094349,0,0,-50.27409562282392,5.1529190156777066E-231,0,0,0 ) ;
  }
}
