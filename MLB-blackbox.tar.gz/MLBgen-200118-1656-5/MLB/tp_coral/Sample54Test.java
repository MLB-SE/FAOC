import org.junit.Test;

public class Sample54Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark54(-2.1625344875541135,-2.2980149220273702,48.34043908745773 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark54(27.663131575988416,0.7741957283001542,25.271164328991258 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark54(28.87816527931645,61.45577419316098,41.66931198159614 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark54(29.89775710431269,9.94448942340847,30.803064028590427 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark54(-32.04529271848371,29.777692163367306,-6.173098410391958 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark54(3.878561778098733,-80.51120389690615,24.549649817318667 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark54(62.66815774507596,-44.34425534477733,83.35176170720993 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark54(66.10168219052764,-57.02123389897535,86.18278823455199 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark54(70.73898236898114,42.44994085417349,16.635193111145114 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark54(76.20669589740942,5.159779328143443,-44.312581890208946 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark54(78.97528579613666,29.979429980245328,71.08043626369471 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark54(-88.90020074108988,42.248368340021266,-93.82658023876895 ) ;
  }
}
