import org.junit.Test;

public class Sample59Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark59(0,0.015013137163208512,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark59(0,25.515002537955112,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark59(-13.300313661162422,-85.03311979518602,97.86410309711212,18.081150694678392,100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark59(-17.530356439269255,-56.01922814276023,72.95800682559187,-36.57289910180911,-100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark59(1.788913623321804,14.965942615656843,-2.654863501664124,-42.63509441651405,55.889318568017785 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark59(-2.680935450343597,-2.780127275037401,-17.20135932040276,68.09241215312596,37.701022634410094 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark59(30.494120060647532,44.88692511381146,74.2348402494408,-49.24451693557073,11.2960868656575 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark59(-31.823614701375377,-1.6716363058880206,32.40023509616491,-51.41177960839706,20.451820832864687 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark59(-32.74052942713412,16.944481288934483,52.75900742775693,93.9004407128383,83.5020444579066 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark59(35.11963618935664,80.6610479253759,33.817803655315146,15.981003323652644,55.53267668518586 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark59(-49.64113281099361,-24.31217261072534,74.27330957244757,60.9367799655386,50.59518073054758 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark59(-66.15508396068856,-33.13962327390268,100.0,30.82931071563391,-54.34363585401854 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark59(7.15270160783183,94.22894004063605,84.64022442176163,-92.67009134468513,93.29983152597235 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark59(84.64080906348576,67.9876466967495,76.00602276084402,35.87229965212683,72.90133422430799 ) ;
  }
}
