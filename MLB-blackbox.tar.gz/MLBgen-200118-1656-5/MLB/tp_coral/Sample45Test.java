import org.junit.Test;

public class Sample45Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark45(0.0,-1.5045000568717732,74.55326152722421 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark45(0.8119089537082402,-77.96560588970286,11.811164478102128 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark45(100.0,23.23137686694328,-91.30613741629763 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark45(1.3877787807814457E-17,1.0000000000558356,1.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark45(-247.54885296836625,-376.2866615026838,15.933937427824901 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark45(34.94906123069259,9.513085658281085,24.78333393651546 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark45(44.592147093138095,50.014750533468515,97.14998192657393 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark45(47.12359261309294,1.0,38.571461293352996 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark45(5.747632727757301,7.747632727757301,21.842220415280174 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark45(62.858123417666235,62.28138400148478,15.100859845708285 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark45(75.025662696996,64.88795064247623,84.74141836485322 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark45(-80.3357673556315,-83.53795792590928,0.8596934394893196 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark45(85.20445265536841,-42.34637397912855,84.36396805646157 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark45(-85.49706914781252,-14.84617131949932,23.999470617074508 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark45(86.55085652317243,19.308798929036385,2.4742497709738416 ) ;
  }
}
