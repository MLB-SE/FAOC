import org.junit.Test;

public class Sample63Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,-1.1786518480585215,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,-63.83291396644226,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark63(0.24913334934662146,64.21619940485148,24.006238305054197,-108.00784146591293,100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark63(0.959614239985604,48.30188624461268,47.31648042938993,-2.4137098634675876E-16,-28.428650025928334 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark63(100.0,2.47154607824832,-3.9383007244899204,65.13924661276081,31.425481712353758 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark63(1.1402354971491668,332.72983121514875,333.9089859831728,-0.01980560344972082,34.78188975286229 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark63(1.2058900437990019,-34.28204662013694,99.24533026002663,45.90725873794662,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark63(17.169060148575227,13.147357822800306,38.63812879481976,-4.440892098500626E-16,-8.575004635166763 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark63(1.8701662537975814,67.20919628677123,76.08384738976858,-10.522599427066353,66.17375200943619 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark63(-24.948126074842303,-8.507244951439393,16.103037740214916,-0.33784338318799545,-7.116429348316821 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark63(2.5435210731507034,1.4210854715202004E-14,5.080158461413383,-21.30161297491283,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark63(30.29864404883996,22.218555700266208,99.39432652045406,-25.14004449164075,79.16094755636811 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark63(32.54623100861588,49.98172938747413,-30.273790196696822,89.47296842054172,-48.86018865365216 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark63(34.67921341799959,6.915128750700262,40.1583957254899,2.0126799622750573,-41.95422194012451 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark63(4.26107202710655,61.904921556104625,85.86085681024679,-28.95986159750727,23.662981599029266 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark63(44.06639248349654,84.64158430001737,-65.91313840638912,-14.159163564823345,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark63(46.31169748308073,16.607647543015272,63.08595880479217,-0.166613778696167,-55.28223226658747 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark63(4.883637751262128,76.88349458830965,27.531279554449654,54.23585278512212,75.86728159273216 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark63(5.056379955534808,28.72627491802862,64.5950387333759,-13.207322439362798,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark63(56.97677558832397,0.0,-34.200441792669494,12.44522956862584,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark63(5.738738933790671,27.371964271200014,50.93317232912412,6.184042829078635,-16.96177500025486 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark63(66.78102940351519,2.668824766002124,-61.39368478855917,5.554584494983186,78.35936759008723 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark63(70.37127862502703,3.134925697221474,11.875267885428416,100.0,100.0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark63(-7.451263665088206,-90.63692145928145,100.0,-0.9031685852017333,-32.74862507747619 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark63(85.47528584326741,82.98565710164894,-82.15824817149162,-26.57630581330457,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark63(85.66975544214489,83.6079592756169,60.16940380958053,-35.9339548368409,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark63(88.40586396742788,99.54104546385508,14.41079238494072,81.76051695629053,25.037366466975342 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark63(9.280299857849968,38.62344910403769,52.35257329216208,75.93278197409728,23.309349790777773 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark63(94.61627900864062,14.595832697711202,79.97863805414698,57.12187644726319,-93.03494586291406 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark63(95.9072223458179,-97.09926833385735,93.91097081364994,-78.78133205926429,0 ) ;
  }
}
