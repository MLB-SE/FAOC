import org.junit.Test;

public class Sample60Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark60(0,-0.9892405447810262,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark60(0.5019007624205576,78.09206826102903,39.068121176901826,20.12024071490204,-13.89093696273575 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark60(0,77.12286353078369,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark60(-1.1705208873819304,-32.49899065395919,33.5442488252566,79.7225319203055,46.59087482984549 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark60(11.935066734983888,2.0006109238541256,-14.63479863085397,76.70117370849691,22.13414079411858 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark60(12.760239221551558,44.85794550399538,67.64323462252219,41.02198091838878,-74.30806450507781 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark60(26.584885049637137,69.34012776474349,97.78180426080996,35.264611787239716,15.07540283741487 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark60(-26.991728574773287,52.05367186471091,-24.728075590075616,35.04000488149612,-30.327450417226927 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark60(37.02145794504307,8.845133108187042,19.94470346755,17.49174763411372,27.05004706326197 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark60(4.078579330255039,54.81277924320068,18.49230712711629,70.39748791448389,-84.78592214149481 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark60(44.66033215385557,-61.91345251303115,17.342983951122495,83.87556141869362,-47.664342434642755 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark60(4.620528411882307,99.34254132313058,87.96685979989078,4.08794620508381,15.160670731829299 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark60(-4.64012279246333,0.20856035249136595,3.4722979645011094,17.554558744857857,-56.291570804139084 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark60(-73.56216116482715,54.716396246701976,76.51902777271974,-39.08761533459846,-20.6721059933451 ) ;
  }
}
