import org.junit.Test;

public class Sample44Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark44(-100.0,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark44(12.379801606140632,59.3640374898535 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark44(21.31423667026813,-37.6554503058397 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark44(-40.02559247505803,-99.00409397701996 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark44(40.764204882923366,89.86198783314134 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark44(80.62386372721261,49.66084573614435 ) ;
  }
}
