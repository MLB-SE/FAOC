import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(16.355916382906855,-6.188625124373658,10.167291258533197 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(-34.02595428218969,28.986668024891372,-43.91897790370691 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(-76.84246413240983,-64.68342067004662,47.79604083394315 ) ;
  }
}
