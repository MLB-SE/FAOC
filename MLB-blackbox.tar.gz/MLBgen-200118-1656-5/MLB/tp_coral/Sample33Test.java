import org.junit.Test;

public class Sample33Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark33(20.11047261802888 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark33(56.755171606464444 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark33(7.0685834705770345 ) ;
  }
}
