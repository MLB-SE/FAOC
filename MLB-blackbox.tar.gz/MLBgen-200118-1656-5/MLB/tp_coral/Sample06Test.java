import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(61.38681404046946,2.6410247320876437,22.595434076769223 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(7.584757356794161,-53.45826971819568,-81.88533501803306 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(97.66224491146755,33.67841070466696,-93.52769442227576 ) ;
  }
}
