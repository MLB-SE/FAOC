import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(-10.928811225038187,-63.70245981166638,-5.7195548668389335 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(-1.2517274565135637,64.81738115260057,2.1255916642241885 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(-50.94753882602079,96.4506208537696,26.064593161806854 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(53.26325284447685,-34.95673184715467,-37.46430159841807 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(85.42763401784669,97.00407586926106,18.281567131631714 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(-97.66181018646303,41.74707112234853,100.0 ) ;
  }
}
