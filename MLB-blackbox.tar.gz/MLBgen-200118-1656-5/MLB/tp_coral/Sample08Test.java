import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(13.546784951748213,22.030658579440512,25.51459216320484 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(37.98227037375841,77.95219908250348,-53.50639276799678 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(55.945700537311296,-96.46952652835378,92.31288373945324 ) ;
  }
}
