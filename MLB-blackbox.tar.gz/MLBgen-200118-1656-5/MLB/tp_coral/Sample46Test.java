import org.junit.Test;

public class Sample46Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark46(0.0,0,-68.00889942911431,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark46(100.0,62.04006291926024,-13.730866975049167,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark46(12.466433952433292,54.723664280877216,16.398777360845074,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark46(14.716313383614832,0,8.424162373107464,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark46(19.883556687064427,69.30377470701606,62.58289713019582,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark46(30.995455012319468,1.0000000000000009,42.440076829311835,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark46(-34.17600963369382,0,68.3206795445887,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark46(46.61495084344634,0,30.820663459290643,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark46(4.930380657631324E-32,7.987819685447221,1.0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark46(53.50714694610417,57.39736347207847,30.58385931305378,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark46(-671.4996361495306,0,19.84187474823176,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark46(73.9726916743532,0.9999999999999999,46.492471917872905,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark46(81.91382156147034,-79.52456361542815,5.775979948542158,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark46(82.00388322524613,1.0,33.39854535731561,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark46(-88.36674571353886,0,0.9982382367693958,0 ) ;
  }
}
