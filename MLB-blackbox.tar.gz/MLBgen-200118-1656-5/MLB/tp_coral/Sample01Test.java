import org.junit.Test;

public class Sample01Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark01(-65.9738891373456,-50.235701768448465 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark01(-82.68632138458622,4.708152658548002 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark01(-85.03735220289401,6.3163744003689 ) ;
  }
}
