import org.junit.Test;

public class Sample18Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark18(-0.5958742889782513 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark18(66.42382635720173 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark18(88.7495156305545 ) ;
  }
}
