import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(14.553219259609435,23.689012461954036 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(19.47932643827955,30.52067356172045 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(29.002393326946788,-2.261936635100099 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(43.49602502430625,50.72829200624872 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(63.38380708695837,99.55763584765137 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(86.98574834437568,97.32106732243568 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(90.6788083023954,-8.380768128450839 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(94.73749750260916,61.55658146943955 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(97.57364957456892,-9.877937516231256 ) ;
  }
}
