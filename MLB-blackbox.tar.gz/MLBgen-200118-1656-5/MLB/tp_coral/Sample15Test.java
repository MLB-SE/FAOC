import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(0.12928131560627776,85.92238562426994,-98.29213155553991,49.247604689339255 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(0.7950231400763528,58.382397492918955,69.22424982073989,72.53112751106957 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(-17.671686085159607,44.33693679814695,33.25967126907031,-55.9838400289963 ) ;
  }
}
