import org.junit.Test;

public class Sample42Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark42(1.0,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark42(10.126892264266303,66.52882350327164 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark42(13.563759177562247,87.44223024265415 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark42(-22.914272009622678,-62.71062501138298 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark42(39.91545773343509,3.762404351748799 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark42(-45.85293992477142,-37.14833984890766 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark42(49.50637467901814,-75.60284433460902 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark42(52.472448194435515,68.32045348548041 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark42(5.2509017286357675,10.0 ) ;
  }
}
