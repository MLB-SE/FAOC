import org.junit.Test;

public class Sample26Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark26(0.0,-28.562728336989423,54.5907464905558,42.771149816171146,-82.06225481230108 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark26(11.969279306287586,49.98463434744065,87.62319927907339,-69.1151484000684,100.01641943017451 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark26(-24.12525366400751,4.855984875641628,85.04212108470934,-77.6192440502988,7.809852187732144 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark26(-24.215868059275095,-35.643314843108854,-53.52181532625251,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark26(-27.279787984489985,-100.0,6.025731862967007,82.93524104310623,-32.35279431603528 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark26(-36.590413696670495,12.995786073540925,18.20124866471352,56.11401431330259,100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark26(5.3334316220299485,-37.79822600058114,-31.044326554844858,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark26(67.36324890648926,80.32012351688223,-40.138278810338974,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark26(-74.76119585670705,-100.0,62.14351077405854,50.05603391557692,-100.0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark26(79.19626531990141,-96.81108147781477,4.317988224569703,-91.42495137695741,25.710043946523058 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark26(80.08702347594888,16.792088792979367,-58.52138528962598,29.331371662986673,91.51162301024138 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark26(86.48282273872934,-91.41728711774282,-5.677540129662546,91.41249775214317,90.89148023230155 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark26(88.45559359666976,38.60297670366188,90.43476586147986,46.64447195155185,74.76684241593213 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark26(-9.611535496025112,-58.12818103332485,56.17534828762465,11.885151800444078,24.009824357610167 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark26(96.4207092260589,26.58596212639752,27.535036201301295,0,19.664525206311367 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark26(99.98453953371018,-92.06679659998852,34.62326204926069,0,80.46103553376021 ) ;
  }
}
