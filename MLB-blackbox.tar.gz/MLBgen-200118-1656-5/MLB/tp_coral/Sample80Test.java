import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(-0.015305677682861712,99.00284777194813 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(21.038674883057595,-26.24922281945902 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(77.1059653393612,1.6717293924362764 ) ;
  }
}
