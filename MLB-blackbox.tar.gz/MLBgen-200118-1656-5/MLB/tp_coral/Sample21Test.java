import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(34.60672386508975,-66.04007868969603 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(34.984603721877505,99.26499162467542 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(-71.20594270253909,-59.6507423177931 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(-76.64097994519537,-26.690301921235886 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(-94.12143948012276,-68.05138123728445 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(95.36779802830704,60.49772593685285 ) ;
  }
}
