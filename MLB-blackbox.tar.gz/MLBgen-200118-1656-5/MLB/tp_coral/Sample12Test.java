import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(18.67049840049218,63.119236366690615,46.16569955159909,32.44382820848875 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(-67.87010778456897,52.34991292021718,99.7973152659363,-49.47237371434567 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(-95.28288540655375,-6.033155994855278,8.969450901727384,-1.3152561086644994 ) ;
  }
}
