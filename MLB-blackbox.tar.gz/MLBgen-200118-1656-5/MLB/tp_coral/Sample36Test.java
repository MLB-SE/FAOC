import org.junit.Test;

public class Sample36Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark36(-41.01251653166291,54.812505471815655,48.19296830728021 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark36(-50.05555355945115,87.29425842133628,4.292256538858766 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark36(-55.076306758346895,-58.515584849358106,9.94435548746883 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark36(-75.3982145586625,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark36(-86.18415144725083,0,0 ) ;
  }
}
