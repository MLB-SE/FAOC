import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,0.17048162615861884,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0,42.222959734481236,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(-44.66069956598464,-7.34733944839185,-30.76187410318593,99.12830504152916,-78.84772081583205 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(49.58747747983216,-30.949192111852724,4.1888195179502645,94.08722190231714,-86.58689415214758 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(94.46315069978331,-1.5055437126585218,-79.35984099261744,-52.653805641645654,77.97844278458967 ) ;
  }
}
