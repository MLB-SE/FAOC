import org.junit.Test;

public class Sample32Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark32(19.549175274559147 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark32(25.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark32(80.57782319114958 ) ;
  }
}
