import org.junit.Test;

public class Sample43Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark43(-100.0,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark43(25.32777948261962,25.385101030799788 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark43(25.543621335844563,-5.101367061157731 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark43(28.26484583086588,67.71134149548575 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark43(-2.910820119843166,8.472873770083782 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark43(3.7886120682079962,33.44417617308659 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark43(49.846441522141106,87.87558570321917 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark43(69.10709912282039,35.821121042071724 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark43(81.2335880922621,0.3717430957249661 ) ;
  }
}
