import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(14.390071847415484,35.60992815258443 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(-14.436135437295576,23.247500134048835 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(18.499029149721274,31.499029149721274 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(20.316867904665468,29.683132095334532 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(20.623086386572716,29.376913613427277 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(22.759137551607633,-4.770653786600704 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(36.969386036631676,99.33271916209782 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(43.00465219221107,67.1502776914148 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(4.434890141350607,17.434890141350593 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(46.30226696238773,-52.921783028746596 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(84.28714663361237,86.31528731560846 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(87.9171958922366,-9.376417007164122 ) ;
  }
}
