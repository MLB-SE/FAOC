import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(21.880507615414487,85.83007835636516,73.1737373108599 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(-41.11613201789277,97.96966073530214,37.814391314965235 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(52.962191336725766,-76.90535747460432,17.77300556862555 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark55(-54.30672968477588,28.14510501665319,67.00198877925405 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark55(-73.52251231043469,49.15098849108384,-71.02818168863074 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark55(88.78074262306995,-18.173875286646222,77.08778304141637 ) ;
  }
}
