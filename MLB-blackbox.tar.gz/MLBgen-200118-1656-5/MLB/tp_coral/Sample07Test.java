import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark07(0,-11.519172840299687,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(0,58.01020771537264,0,84.87762983533122 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(0,-64.43499551225466,0,-93.6356397459298 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(0,92.49005477695565,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(-2.605137349203403,19.8626202431673,-98.49576881764501,-85.30664964995869 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(45.48745178670933,17.917557246099335,-72.01419352096781,90.28157160018381 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(98.48950526983349,12.769386974001918,-47.69370280879664,52.554167420667966 ) ;
  }
}
