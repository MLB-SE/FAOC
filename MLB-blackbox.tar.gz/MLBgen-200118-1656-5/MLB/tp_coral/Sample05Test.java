import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark05(26.46442659715812,74.64931207037823,-77.69204174494257 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(-6.962196681605761,-4.530690142227201,-14.172223294543201 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(94.61039841754689,50.543563478122735,-52.48947309451311 ) ;
  }
}
