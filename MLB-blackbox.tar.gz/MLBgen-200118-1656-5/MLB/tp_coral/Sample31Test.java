import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(-43.62759044806668 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(4.6827133823258364 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(84.62850409498762 ) ;
  }
}
