import org.junit.Test;

public class Sample34Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark34(19.634954084936208 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark34(57.18434850561215 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark34(70.5927537314167 ) ;
  }
}
