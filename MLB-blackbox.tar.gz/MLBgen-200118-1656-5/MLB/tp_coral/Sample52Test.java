import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(25.02873301219932,-82.92518500443754,28.6026360738758 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(55.3923302723654,52.92529538294383,70.75966551427746 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(59.963346564493236,25.474799799691937,-99.1011549334876 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark52(-83.15462362112515,48.33082609866719,1.8355873281813615 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark52(86.91320140949136,49.7760475631471,93.37452966171452 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark52(90.47415484024586,34.3543325802392,-77.38595164394178 ) ;
  }
}
