import org.junit.Test;

public class Sample51Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark51(0.009238044425993408,-0.09611474614227207 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark51(13.492976867430102,24.041645928199614 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark51(20.63791576810694,27.769482539636577 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark51(2.1193247748604307,36.12081306440837 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark51(31.09251723471698,-40.72206638975384 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark51(3.862840875843432,68.06106471438488 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark51(40.88642875823584,83.81712872811343 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark51(-74.23170693521007,-32.434821732591274 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark51(80.52552575523572,-1.1636815034078154 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark51(84.81000404423847,90.47889659197406 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark51(-96.56249023970808,4.780696817460722 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark51(99.84444794733417,-49.844447947334174 ) ;
  }
}
