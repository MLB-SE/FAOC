import org.junit.Test;

public class Sample41Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,1.9999999999999998 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0000000000000004 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark41(1.3863388836920532,0.535596616744475 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark41(-1.7983832591505973,20.20608796183825 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark41(1.861618175764491,1.60400405657222 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark41(6.979420275361051,41.732887104759875 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark41(-7.620304052775879,65.68933790952836 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark41(-93.47169130141306,33.87224548346438 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark41(9.891218388454234,87.94498281964094 ) ;
  }
}
