import org.junit.Test;

public class Sample39Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark39(17.680448903850206,2.433798112014569E-17 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark39(56.06865523814528,33.67089100866468 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark39(70.75237305523311,-54.57418231017264 ) ;
  }
}
