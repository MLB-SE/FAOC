import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(-18.52241221001252,71.48834638073103 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(-2.3621965797324265,0.5340092274846171 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(24.473683192891936,100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(-29.735332170576417,-26.941220029756536 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(-45.980655644676126,-76.91205593320687 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(-69.39587138379176,-9.122664098830512 ) ;
  }
}
