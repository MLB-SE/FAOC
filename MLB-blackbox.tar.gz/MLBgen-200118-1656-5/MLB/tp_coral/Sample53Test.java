import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark53(-1.4794334872008203E-6,-0.016434721833388604,81.11872061155557 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(3.377929353589721,39.6159365457965,35.35974320329865 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(3.900329387967098,-87.09618680042055,1.3094832644468264 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark53(45.27238645447158,90.73672020388294,70.17095755608992 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark53(-55.13974229067651,-84.35701793203884,29.10810088236414 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark53(58.64008920547923,-7.541781336161591,62.27950630461007 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark53(63.327855083182754,46.67668322878217,83.84305597848419 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark53(66.45287391840144,-3.0173080455823396,100.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark53(88.47253193572749,-62.43349871388033,0.7339666406348755 ) ;
  }
}
