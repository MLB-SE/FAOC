import org.junit.Test;

public class Sample25Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark25(100.0,100.0,-63.642226397794936,31.85902337665585,-43.297694559419995 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark25(13.872105292822951,-8.981451558155374,93.09673459481344,28.649203366126727,-27.47989727555535 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark25(15.94981159335309,15.413625946728303,18.415226868591915,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark25(16.964891066044757,-13.906215860350898,-23.85462214389817,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark25(197.36728376574501,-95.16563849734436,73.43322994550755,0,-57.85454264502523 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark25(-27.189561802371415,39.22884946878554,47.29231387321752,-72.49234826553233,43.46394898003092 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark25(-31.981328448528103,91.86977415184671,-88.66386482665635,68.72671516423671,-43.33812723892927 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark25(-34.8217475232852,-89.85854759214759,49.69337216681125,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark25(5.024884238353096,-13.978860822633948,-45.60197652092066,0,-50.09532690667706 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark25(-84.45739694519892,84.47727379257947,-98.04999630117983,-41.99050053778848,90.33633719710855 ) ;
  }
}
