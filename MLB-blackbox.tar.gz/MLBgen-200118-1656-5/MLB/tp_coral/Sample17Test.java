import org.junit.Test;

public class Sample17Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark17(0.06685842092213079 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark17(-0.12165927317890635 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark17(0.7091520165996258 ) ;
  }
}
