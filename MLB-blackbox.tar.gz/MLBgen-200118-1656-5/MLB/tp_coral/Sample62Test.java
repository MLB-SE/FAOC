import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,0.43000919141069005 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-6.067678735635582 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(0.545823800751279,37.26948434253862,61.725342388252926,-14.982210782018825 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(0.5508567210839597,1.936200092787455,-41.36958059325952,43.856637407131046 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(100.0,-100.0,100.0,-17.35369008316428 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(-100.0,99.97478099538768,100.0,-99.97478099538768 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(1.0489250635261245,54.07713788608352,55.34981079216603,-0.2184706120203984 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(11.437943810710244,-2.327197090324968,94.91457131937665,-37.013481116966865 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(1.2529390841146721,-47.20335538848646,91.17640597256283,-0.02654343263954242 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(20.940534293707543,-3.1822380246954793,80.95172860797831,-12.09377123426205 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(-33.1126894647024,83.4588142366415,-47.96523208855985,54.14192877607687 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(33.518748219620875,-6.586894767497142,-44.461415984215336,-58.775053938243694 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(38.11603905879571,-34.04470168468683,44.08341390417681,-99.97836384737597 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(49.43070597475281,77.71572228435656,97.14405988847474,58.54836039000429 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(52.73659913366956,-53.612665148598936,79.2681876345553,-90.48197999205036 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(53.095304250405206,-10.839172926800728,81.37906158473126,-38.639912577212726 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(53.890256025552276,0.0,35.71276831647863,-26.690398108089422 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(-66.99171721152746,-97.04178035043662,-86.66788444498985,-15.028223225229425 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(69.39417416590172,18.24914000591049,2.0759794987510674,57.79792729233597 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(75.26026071459299,-74.83350451883396,-91.92698617303144,92.35374236879046 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(90.59471104894698,-58.52419103679256,7.842331375697583,27.234392721792176 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(-9.488538070277656,69.7320408569102,23.27406454041396,54.82817947245937 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(98.77422745114684,0.4993402108112708,-49.35232566646269,-84.25957159743234 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(99.5004976837943,-36.24248549071587,-14.863961892193728,-66.70020023996088 ) ;
  }
}
