import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(-128.37379683991406,-324.21424870436437,-452.5880455439405 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(17.228582301515118,21.60279215703045,23.60603424844838 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(-39.510493170625026,85.79924913614863,98.02986904289276 ) ;
  }
}
