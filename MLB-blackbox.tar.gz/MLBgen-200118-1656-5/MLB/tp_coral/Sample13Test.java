import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(0.9373325370008072,-1.2032692768605384,100.0,7.819464088054119 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(48.237293285122036,-5.762704561171091,-46.764413717550134,-40.707492517455 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(-97.65926568995059,91.69377013010163,72.75608576844292,-64.67283297244052 ) ;
  }
}
