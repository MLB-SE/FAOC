import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(-10.840062606441842,-29.552979330423128,69.32964521703411 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(46.009581279998315,18.663955354495258,-87.04785890768123 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(77.13807842524244,-61.27867781391074,94.13156140375526 ) ;
  }
}
