import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(49.47422768221813,22.49285294760766 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(-50.35776802912742,42.06155792799106 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(89.33117129778086,29.201000006709478 ) ;
  }
}
