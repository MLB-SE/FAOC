import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(-14.48430274209376,86.37401011060047,9.094560672466628,47.53949337388511 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(27.352696586276977,-27.35070360263741,21.597147536403938,-55.8437129127699 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(-95.28264499537731,-31.934370927232195,65.04660859501485,48.605807937529875 ) ;
  }
}
