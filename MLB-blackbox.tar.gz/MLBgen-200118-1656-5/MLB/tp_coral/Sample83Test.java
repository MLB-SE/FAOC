import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(-27.23793626027617,-68.29803970146746 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(3.192764837075865,10.193852573811709 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(5.9300531576399615,35.16040834045983 ) ;
  }
}
