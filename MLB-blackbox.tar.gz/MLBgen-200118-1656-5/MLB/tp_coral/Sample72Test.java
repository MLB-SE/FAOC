import org.junit.Test;

public class Sample72Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark72(-17.273443608923714,-78.60088555066507,22.361211623352986,74.92583846304507,47.80303189595489,-64.77575073369204,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark72(28.48767577100476,-53.09773606059888,-46.72000687166741,-82.36918904285095,17.95591780209425,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark72(-30.937522959163,65.49504214865073,0,0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark72(34.33713316996094,-72.43835997626925,-59.86537983484818,-70.51739177012853,-39.13285938517901,-58.25651287610458,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark72(-43.8613959564927,50.42223831200013,0,0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark72(46.34049020432249,100.0,100.0,0,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark72(51.26282974119914,58.92794386284436,-43.431381041533584,9.024975005667812,11.487898780129946,-45.984341810348624,66.05169520970917 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark72(55.841894921005235,-52.43478094416769,0,0,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark72(-60.309298344558584,-100.0,10.392204229141685,54.970067002424585,-14.129362505757276,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark72(65.5013629680293,87.46547519760426,78.59179154908855,0,0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark72(-68.40476098972601,-80.98287286644037,-69.09061107850037,94.2046951538293,-39.977535879532255,112.25367136492846,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark72(7.605705491927843,-41.895584929023045,-97.10311135411764,-59.365730229870294,31.052494617188902,-7.076395766792672,16.839101696502112 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark72(77.29942882175084,-50.333515211345556,-31.96811307631097,22.97271410749717,0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark72(82.98745794042915,-92.07689179993072,-38.86740872597196,-13.80652130342655,-74.6578786597492,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark72(83.97635539471244,-100.0,-3.5375942022508866,-31.845698395853784,100.0,35.41651027554436,162.5027145563776 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark72(-85.10840811086833,-72.20082024018419,66.53973220092234,65.17744022080655,0,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark72(-93.41089609948028,27.604235425588982,-84.74243356379382,0,0,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark72(-94.28634528391558,-75.86783500071002,43.04124753731455,16.649012880891526,0,0,0 ) ;
  }
}
