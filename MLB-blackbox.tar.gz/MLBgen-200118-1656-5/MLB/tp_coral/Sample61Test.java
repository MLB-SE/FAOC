import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,-0.21221770595869316 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,23.77028864618009 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(0.10637442664502039,-2047.47903213226,-128.0814185542536,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(12.848148259304239,-7.105427357601002E-15,-100.0,-85.16912999109752 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(18.558437113051543,0.0,37.81601106235634,-59.2453965206677 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(1.8937133958557428,-1.9872977318705918,-2.7347639777403447,17.640957540857976 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(20.99268383563993,0.6841497074202662,-52.664688934533274,-13.838955259559484 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(21.768452421712354,15.155037813534406,52.43729566651302,-19.680280154999295 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(22.52702546010344,0.9980417525334246,-1.5122819794717939,29.262314798872808 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(28.347306854250434,-15.222821235090464,70.47609440186463,93.79389166035347 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(32.04688861319612,-16.594313241525228,94.33926870596554,-1.9311970400202227 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(43.008019477631564,19.902664542498144,96.58871908663741,15.719898599438608 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(58.86100702714114,-33.79121471490227,74.67623226546326,77.63139785644586 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(59.77527453888655,-38.95105296201524,-42.397823200251764,7.029926804687349 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(67.0245934208391,32.34232549192416,7.154263950317677,92.21265496244558 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(-69.13954168158097,47.00268148677779,-95.12749993844008,40.826749008341636 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(-70.5882662557178,91.83178955977061,-59.45252620692241,-2.798618918151874 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(70.82521911317366,-23.789660283498847,24.202701684072323,62.120038087847576 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(88.04623580350108,91.60869384033262,80.52190037022356,58.78813907102841 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(98.65192685411358,-6.644704940759723,-65.99765230351933,-85.77093484715384 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(99.8289351484853,-83.52216169285076,-77.33443059455468,63.51076824589981 ) ;
  }
}
