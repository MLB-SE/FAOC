import org.junit.Test;

public class Sample58Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark58(0,6.069362166614226,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark58(0,-6.813534648845135,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark58(-0.95464743482327,-11.952623975024537,12.046194240172705,-35.52764361173871,10.90721987323981 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark58(12.82937431030659,33.29777888885536,24.08552371327002,26.57248528043317,65.40220716797592 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark58(-20.024783536562452,56.18364578838998,74.38843081592208,78.23426356370447,-16.143806399504967 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark58(23.681984766614207,32.367285778731684,-56.588319432984704,75.31427219477243,-6.695026585272927 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark58(2.7872480397801627,50.42529738831124,99.99941219684659,-15.812563351869358,100.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark58(3.0858819771085564,74.64406152249964,31.730805992953208,-64.23460402611936,98.73156003398282 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark58(31.78657745055358,8.258394687401498,32.292298674236484,8.438189008097623,4.915234999368991 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark58(32.84370701660855,65.0084275545555,-97.24274784211211,115.58847911787028,21.973043702666757 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark58(43.28883721809555,57.022789218013116,18.54502110117066,67.70736707653518,-65.89981741455767 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark58(5.367724429273939,38.003729399974105,-43.97318892546676,19.93159818880403,48.33921880121452 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark58(-62.63113454764824,-2.098209981867143,99.05809729467889,1.419422927267405,65.31129000640954 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark58(95.52417062253838,31.88156993442584,-96.11500073182084,-25.302806799726184,10.966654361929713 ) ;
  }
}
