import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0,-11.051198829454293,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(0.13365101562843323,86.99625547048518,25.633180808138484,29.077909003074666,-24.296861959122552 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(0,3.6260967675698623,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(-30.544358692688874,-60.51414500851584,55.00593928069321,-69.09980973144451,67.38623990158493 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(35.95053774328983,50.687740233220836,96.59389305165726,47.8983816597831,94.9372434560442 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(37.22252577853942,41.718694982503806,-13.918494052148704,-95.9282838209009,157.58010625128946 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(58.441205004645354,92.60904543532408,46.521786867852455,14.815964987591897,-46.85949827232099 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(-73.385033387306,7.808997365828915,-38.67642259280268,97.75071638536369,-95.79664506375289 ) ;
  }
}
