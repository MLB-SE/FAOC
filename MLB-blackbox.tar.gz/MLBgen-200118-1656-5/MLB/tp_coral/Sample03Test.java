import org.junit.Test;

public class Sample03Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark03(-29.856472586694583,-6.294527684771133 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark03(-77.01466194799791,34.81578843740408 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark03(-79.36544767235927,-24.226252254371957 ) ;
  }
}
