import org.junit.Test;

public class Sample02Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark02(17.856863170823956,27.69623030641105 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark02(69.94074910250205,-89.17941421791922 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark02(-71.5501516407889,-87.26475832800426 ) ;
  }
}
