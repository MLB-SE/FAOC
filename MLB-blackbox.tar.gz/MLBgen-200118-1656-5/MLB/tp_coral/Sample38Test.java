import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(54.91364552373767,35.259646304827264 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(-65.93013883837986,98.71086934997604 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(89.87586664377,49.45268555751966 ) ;
  }
}
