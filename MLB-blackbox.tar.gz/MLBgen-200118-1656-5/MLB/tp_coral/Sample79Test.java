import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(1.343967799270904E-6,-99.99993283406792,100.0,100.0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(2.0150464306445934E-16,-15.705596007905296,-100.0,100.0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(-22.24991097526909,36.003834599008,-95.07078254906811,96.18219728922966,0 ) ;
  }
}
