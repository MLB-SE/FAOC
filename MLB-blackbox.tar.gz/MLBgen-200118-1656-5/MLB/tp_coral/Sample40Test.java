import org.junit.Test;

public class Sample40Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark40(2.1312048478523877,22.86366135089007 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark40(-69.74539488269457,71.94600836534738 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark40(-9.416721748547644,98.09137023811785 ) ;
  }
}
