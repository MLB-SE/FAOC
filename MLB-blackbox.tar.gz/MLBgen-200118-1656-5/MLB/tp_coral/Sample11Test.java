import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(-0.5394666687492744,-44.14221345978755,56.51716821567866,70.2107130223867 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(42.78634737657839,-9.564103984431569,83.0685964172994,17.271268522908414 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(84.711094742565,-70.16552931170318,25.865651594134448,64.72867303158779 ) ;
  }
}
