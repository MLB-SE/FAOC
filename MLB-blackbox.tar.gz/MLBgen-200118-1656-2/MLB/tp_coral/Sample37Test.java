import org.junit.Test;

public class Sample37Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark37(160.22122533307945,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark37(-43.553455208702594,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark37(-5.214934725420733,-93.34555204884569,-2.7931611644715417 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark37(53.39437689100984,-36.52386864660044,73.17033080291212 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark37(77.81548810983193,-50.06217768294701,48.64066833120472 ) ;
  }
}
