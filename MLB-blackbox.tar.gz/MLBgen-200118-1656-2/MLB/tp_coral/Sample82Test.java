import org.junit.Test;

public class Sample82Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark82(-35.02570104999366,15.440407225893367 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark82(7.465368170914658,-30.730309573247496 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark82(86.17960399922512,-3.544861983428092 ) ;
  }
}
