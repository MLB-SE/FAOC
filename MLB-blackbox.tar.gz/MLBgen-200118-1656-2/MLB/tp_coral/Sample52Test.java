import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-100.0,100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(21.75760159512521,58.80270353344005,36.136511422832996 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(30.933188772469315,0.8058158444866456,9.730389662462912 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark52(-46.2409749592938,-30.36552275700153,-49.3507671647477 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark52(88.50007254251199,-26.165965665809196,1.607844626104992 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark52(89.19841447534913,-60.55487022075206,39.2388237057817 ) ;
  }
}
