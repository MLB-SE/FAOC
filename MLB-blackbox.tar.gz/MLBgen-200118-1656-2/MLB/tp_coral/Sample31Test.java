import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(-13.536057420304743 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(4.582184071593943 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(84.57727499433844 ) ;
  }
}
