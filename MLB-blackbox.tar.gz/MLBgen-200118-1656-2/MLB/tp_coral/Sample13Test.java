import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(-0.04935692956816173,-62.64967714187082,-31.234170603757818,1.4787730591309156 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(-0.8026531763629308,-18.825427397140487,77.44921997354402,-29.787205390108312 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(0.974752874551001,30.981891976248363,89.7124888944758,39.376739623288415 ) ;
  }
}
