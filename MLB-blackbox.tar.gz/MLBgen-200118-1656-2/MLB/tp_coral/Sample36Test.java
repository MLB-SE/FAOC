import org.junit.Test;

public class Sample36Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark36(-24.94745271804257,20.8465284410579,98.43311673625067 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark36(-35.6638199375287,-50.319089560953046,8.821469312269915 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark36(53.40706552226348,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark36(6.886823525340887,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark36(8.92654519717739,-87.29018957921457,0.8514578965533133 ) ;
  }
}
