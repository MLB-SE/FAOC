import org.junit.Test;

public class Sample66Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark66(0,0,0,24.197640438935196,15.793515307122362 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark66(0,0,0,47.75952466611804,-47.75952466611804 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark66(0.9718059312719906,-30.08001969837602,-29.07551208952571,-0.032348609003103705,0.03234860900310371 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark66(100.0,-100.0,-100.0,100.0,100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark66(100.0,-100.0,131.3670126214318,-100.0,-49.19209164868745 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark66(100.0,-50.63929707071166,100.0,-10.514704010377223,100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark66(100.0,-7.105427357601002E-15,-12.691180999679858,66.37246551475044,17.702479787549123 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark66(-14.702016914596399,75.40377408142422,89.8939193599719,-0.21187163604871648,12.767089956287732 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark66(23.85670994296774,11.138820264297465,6.866580792627275,49.761479487262136,90.50085421803169 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark66(2.829260235021387,94.4895996732024,158.93533323603455,4.498729434678367,31.97194776607617 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark66(30.42177469682821,83.60859291076594,55.84015490437474,81.42191984729342,59.00447154263614 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark66(-4.114238162699181,7.243528688763538,4.75929516104263,-1.6300046349782704,38.07568698102219 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark66(41.59955280716316,-48.27561735848397,-5.81378026552754,-0.8617093904414346,100.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark66(4.349712616507216,10.714498409380155,21.56634857535397,-0.2254733204358601,71.15141640744918 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark66(43.959126524736746,-20.544421057456887,-60.97468255478242,95.7937283724147,16.965616703568287 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark66(47.37521225430233,-47.5701075305963,76.58535404983787,-53.98337649169332,-54.889202993202616 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark66(57.19958241380866,0.0,76.65606030095599,18.035461024194596,40.15589704174405 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark66(59.9589445982659,12.608155591025877,48.01186391518496,78.65794358273146,40.52533803203991 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark66(60.87695300141487,-58.842912354157875,53.82149917471645,-20.92215499076479,100.0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark66(68.01423121679741,-10.304026035487297,-3.1819110924198952,32.3724476646897,74.45327815235581 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark66(70.11052356019619,-1.066439846087755,98.5983937580531,-29.554310043944675,100.0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark66(71.83068418533844,-38.08207062380631,-98.43955578788777,-87.54123585163907,-34.39855953522388 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark66(74.22355407152082,30.057461148555717,39.61024921358509,64.67076600649145,28.857854394504614 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark66(78.39871487139547,31.1154885414216,-90.85068526971759,-60.05676261758415,49.68300205143311 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark66(78.91530990962227,-25.97466248311872,-13.872714500126364,-69.74229134879708,-7.623718325529595 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark66(79.93455792195289,39.59774665766511,22.65110728725604,-12.524474871376,9.239882999110208 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark66(80.18308833866024,-13.534026942069616,5.42574347789548,27.718781730148834,47.38672991242288 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark66(87.0470281917359,-74.08883265973853,-81.14929696910059,88.12314557780505,-73.8305879929517 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark66(88.04214911369765,-82.41190216534503,94.2163302824353,-13.324557820814032,100.0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark66(-88.43678796030738,-25.39151078457735,-75.0477854145992,-91.67888468041234,20.866296132080336 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark66(90.55691038744925,35.177876628989395,-81.18722316794745,52.67861137417583,-37.60007980902298 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark66(92.7380891172637,-90.25719675884947,89.61730066312302,-1.0274869201294021,100.0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark66(97.2124463136779,-70.85095575029536,43.576232453687965,18.674268476895023,100.0 ) ;
  }
}
