import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(1.885016988287708,76.29667764189617 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(-36.22274632911528,-90.21340670132108 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(99.99998217974331,80.35502711252016 ) ;
  }
}
