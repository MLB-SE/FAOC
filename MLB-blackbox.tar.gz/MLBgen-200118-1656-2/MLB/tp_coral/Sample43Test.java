import org.junit.Test;

public class Sample43Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark43(-100.0,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark43(-14.323128629980758,-32.825786700399135 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark43(20.357019514439173,60.47855632164308 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark43(-22.979898737627224,78.22573343638925 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark43(4.771279554847595,22.765108590506667 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark43(5.155596084030577,98.64731609708065 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark43(6.16618859213709,119.58577640049108 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark43(69.05366725651845,90.00323606453594 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark43(96.19466349096592,73.89134381985707 ) ;
  }
}
