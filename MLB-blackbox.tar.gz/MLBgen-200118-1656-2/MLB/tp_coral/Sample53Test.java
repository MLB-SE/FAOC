import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark53(-0.717140491097723,-67.68417035963492,-8.94665164496124 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(-12.28975262805622,-2.7064769126170827,-8.419270141031316 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(-32.81583807361778,-88.1818001776737,51.980277061071575 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark53(-33.69917838406873,27.761769888680263,88.0738556941242 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark53(54.048091063728265,-34.42547425659379,66.12167130896026 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark53(5.644587688458174,-86.79761288587218,18.621982713367302 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark53(6.357256877358637,6.145335489982443,-48.65993623411369 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark53(-63.91061251413752,29.616127364072753,26.703992472118856 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark53(84.22471145720255,-38.668422582089626,39.9641382646935 ) ;
  }
}
