import org.junit.Test;

public class Sample39Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark39(1.388438768463939,-1.0981900861569905E-16 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark39(63.654989940528,-51.24720565318028 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark39(70.68165035827502,28.877437953486435 ) ;
  }
}
