import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(-239.30236725305477,-384.0526133301504,-617.3309622925326 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(-38.339062175657965,-58.029534770090166,-82.15909385196507 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(67.57579723551927,87.42132392104307,92.26915179297583 ) ;
  }
}
