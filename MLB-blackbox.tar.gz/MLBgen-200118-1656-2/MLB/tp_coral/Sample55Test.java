import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(-20.67660394529402,0.7608825069243466,29.775714465046747 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(44.460404541868826,-38.48479866947561,-58.99875604331659 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(-68.98925799101218,24.899967196807765,9.425583766204255 ) ;
  }
}
