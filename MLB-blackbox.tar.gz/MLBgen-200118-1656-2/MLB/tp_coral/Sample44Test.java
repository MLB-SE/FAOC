import org.junit.Test;

public class Sample44Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark44(-13.067480460461866,-61.9924620891777 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark44(28.581941254373163,32.706359633690255 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark44(30.885496130245343,0.5316233493780729 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark44(43.74138475646356,41.31671688609015 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark44(53.05190453981959,88.85836465432806 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark44(-81.2515302104013,-81.2515302104013 ) ;
  }
}
