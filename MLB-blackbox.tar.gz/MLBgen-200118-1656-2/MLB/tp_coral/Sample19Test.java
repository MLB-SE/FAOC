import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(15.475457012393079,-59.67923467611824,71.22910652652385 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(17.321095095509165,9.188509952211561,-2.6485485875750356 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(-48.617617793331405,3.7290092884541366,-71.19454687880615 ) ;
  }
}
