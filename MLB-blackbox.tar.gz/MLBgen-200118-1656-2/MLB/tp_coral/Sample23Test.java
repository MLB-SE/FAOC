import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(-114.4928854318029,41.866347692689786,0,-64.13007283788518 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(13.371175728061534,-39.67231072914574,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(-40.4078325939637,43.13165159419387,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(-49.400446041727086,34.27059547799778,96.66255969306084,48.370162082009045 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(-52.05964240893481,63.944020657617216,50.5612959747167,6.502751756813964 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(83.31325603727936,66.11463303895437,0,-85.5672532171952 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(-84.19133549937658,72.40571803699169,-86.7900131022153,-59.0920540488425 ) ;
  }
}
