import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0,-0.39305147785289307,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(0,-71.60007109440562,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(48.76152320601625,55.80285142277063,38.11734982941991,-0.1428290153782541,-48.762973974885604 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(7.029016630062571,3.2540277399335054,18.191924026456846,89.36862448698409,54.47267142918571 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(-79.06444148673005,-1.709473292712559,89.57131811703435,-89.53849632636837,87.07111445200746 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(8.127266130040526,97.8484641820651,100.0,-6.865548968587618,-60.79687956675575 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(93.31695845786268,55.6917322725113,78.90946601073219,71.02264754331472,25.494834943446847 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(93.93148476737105,-31.484880431770335,69.43894762339752,81.40400941495068,-34.32218504569373 ) ;
  }
}
