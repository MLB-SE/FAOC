import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(37.781895773568266,-92.38882085818344 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(46.49754671819136,29.85573140681224 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(-61.13850847938498,-89.32267388560355 ) ;
  }
}
