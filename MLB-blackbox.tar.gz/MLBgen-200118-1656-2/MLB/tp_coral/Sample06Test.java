import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(-76.91872788831644,31.683810040352057,-3.651964333348019 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(79.20427193702685,-43.9098444547801,42.084245913637155 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(97.05479102420941,24.507777768949552,17.96375473834877 ) ;
  }
}
