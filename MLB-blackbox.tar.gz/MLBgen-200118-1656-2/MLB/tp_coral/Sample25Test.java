import org.junit.Test;

public class Sample25Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark25(-100.0,-100.0,88.74314278544423,-83.89700565371571,-0.2811956671839162 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark25(15.25340311061818,11.75749340713061,22.066902273477382,20.79564125974575,-98.61557512260659 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark25(15.552047945635024,44.860770752436395,15.00055832766914,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark25(-28.985977519213506,67.37373669047025,65.35347637565692,-92.10358117076112,-53.12760863761103 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark25(-33.776206763943975,51.981439494303345,-5.102848575860321,0,53.19932707904255 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark25(-39.159981916625135,-93.1158372220186,-16.071450300449428,96.07402706450075,81.07685614334898 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark25(58.10957574374615,63.832691905712664,40.24060527742813,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark25(78.67743008434277,-90.43369238048294,83.34724751697763,69.10044528346737,-88.89162461846121 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark25(98.6829502644004,7.889517294434429,34.80403857546948,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark25(-99.0712725334737,-62.892429405917916,90.02670077479183,0,78.66096900205264 ) ;
  }
}
