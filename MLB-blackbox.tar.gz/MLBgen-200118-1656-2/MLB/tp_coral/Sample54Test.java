import org.junit.Test;

public class Sample54Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark54(22.64465785018632,-70.39091451577113,-51.04300971299387 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark54(32.24386202067927,-64.3265116436023,-5.837604775206273 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark54(-32.70182768989747,94.37278701328694,-7.749087231555123 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark54(42.91034475201462,-34.12788444345259,29.034062735627742 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark54(43.43940620055555,2.772402835888129,4.085135783013392 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark54(47.76703896310221,-4.636508816298118,-53.12188247123291 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark54(50.160670505857325,-10.414736505402715,-22.056689797509122 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark54(54.36149827688948,-56.6042174053258,60.56944191116261 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark54(-54.73471171828673,84.10091797484785,-53.76447013000607 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark54(6.329848437204014,83.77449710217536,9.21839602701638 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark54(73.1077842645098,-8.610157221792065,4.170082863660568 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark54(81.43812597457466,-47.97046972683137,97.58016629954784 ) ;
  }
}
