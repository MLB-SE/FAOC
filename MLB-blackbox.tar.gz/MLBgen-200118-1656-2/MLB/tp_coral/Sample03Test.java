import org.junit.Test;

public class Sample03Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark03(21.288777762946268,55.680242250003666 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark03(3.0075910867306987,28.30187293687362 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark03(50.94487255899509,30.54572613061916 ) ;
  }
}
