import org.junit.Test;

public class Sample58Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark58(0,48.99779772518218,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark58(0,8.587666683773378,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark58(12.392302129048431,64.53595727772148,16.155714244583493,95.53273579105445,55.68224725949091 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark58(-38.355913948175434,1.9725664783225332,-56.581689602487,-9.503223670511327,88.8749458156106 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark58(3.9070155526941215,-49.60926140060607,46.28754885838329,-13.978447324431157,-80.35454103945791 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark58(40.018888616761416,68.59625243853375,28.04145690851979,-24.393239283303586,49.363633202473665 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark58(-4.081341287496684,41.841407163142776,-38.034455448904914,-99.41441822012752,43.370469820266564 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark58(4.585522373597514,-3.0441238353025426,-1.571801164565585,80.46205972012268,-53.72284587218244 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark58(48.176147613740284,44.85148325939045,-44.70189360583059,93.63865554022601,35.37601146483334 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark58(51.193279171143374,96.61589359722888,63.065452484071216,-13.572287992258865,-19.301833490186258 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark58(59.671714483148975,4.146650053565537,-63.45054903116352,116.30014902061438,23.29341576528938 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark58(72.19581454332803,-50.498568243284645,82.78984093500935,-87.64765709477716,-57.1211271726644 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark58(94.63333372713592,5.48971461219971,-100.83396168097586,65.95773522602835,120.46715335890008 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark58(97.93638268095754,88.5888398704241,95.6495550622322,-78.0893430042915,82.1758502180243 ) ;
  }
}
