import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(2.7701624998051244,-2.4495170578833694,48.15122991289442 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(-51.194726968854056,81.38384369977638,-78.20632662538114 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(94.90517203486178,3.1961578589157944,82.43532494639032 ) ;
  }
}
