import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(10.271230574001692,39.72876942599831 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(10.53278225427168,47.17889625859334 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(15.328363214509473,34.67163678549051 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(172.71155597626367,-3.755620850055763 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(18.294258732243108,28.84415911313104 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(4.452113729323344,67.54221472521905 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(5.959349965636292,31.083681957228805 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(62.307157028038546,-65.80569117424446 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(-80.28746409830624,31.20434128592302 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(81.52333059319267,-9.029027112219381 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(8.277283957174802,21.277283957174802 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(9.448453192133897,57.243901196506926 ) ;
  }
}
