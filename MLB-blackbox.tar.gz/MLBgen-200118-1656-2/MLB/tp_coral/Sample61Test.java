import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,0.33360828520554264 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,20.897751542125434 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(0.4491180158787955,21.143991841606606,14.169914210294795,-53.852832298270734 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(100.0,0.0,100.0,100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(16.19259984242403,18.94327333742467,-51.05070911593841,-23.687578760674555 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(1.7173330303122434,-1.7346242105329281,-4.490569511280448,99.23988013211819 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(20.310869253729763,57.66980460852972,73.52174196551024,11.970378241520478 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(2.58123544439718,2.4308653429145085E-63,-24.529206693703685,10.329921758875704 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(3.456705503439078,-9.871031767461413E-178,55.99726500315629,-49.30223475871715 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(35.46523633773276,72.29365752750911,41.39426037159859,-62.19132559595755 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(36.15983857065109,70.9618839187497,25.08568614617799,82.0360363432228 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(37.21711001636291,65.92830137922431,59.100185270281145,-48.793231509355174 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(41.14472848222721,71.75207874919516,85.75368092339403,77.41022416361437 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(4.364351446233423,-88.89912377107491,36.92922678575312,-0.04909330104841203 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(45.13128616081433,1.8048674221129604,-12.943339758902836,-85.15483867352785 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(62.9677239816896,-52.2157305024012,92.36021258748173,62.57244453453188 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(-65.48371301994429,0.8508673962762003,3.510656819970805,-8.213489595962258 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(69.75033266768045,-40.69000823833066,94.6515831695265,75.22918407577984 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(73.26056503529793,53.742141983167585,-75.46535061309609,-24.392174620828058 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(82.24594185561006,-63.178084022554025,75.70150614555519,-2.5929336888515593 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(87.8140705061933,-88.05057542297038,-11.751891121668192,49.68983851082086 ) ;
  }
}
