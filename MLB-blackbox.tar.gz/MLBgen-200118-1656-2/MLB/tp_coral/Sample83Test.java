import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(-19.373666418251474,-86.7238607197486 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(-4.617320906219962,21.321639847329116 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(5.240401925341001,27.46238777580062 ) ;
  }
}
