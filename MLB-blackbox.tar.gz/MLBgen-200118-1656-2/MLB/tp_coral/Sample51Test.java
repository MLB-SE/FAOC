import org.junit.Test;

public class Sample51Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark51(1.1605839645320528,31.1078643799121 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark51(12.649688074239847,80.96886580727661 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark51(1.3096553287315453,26.53109351315488 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark51(17.148264104233263,32.85173589576674 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark51(19.750004127942873,26.696672365774205 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark51(2.0090569861958727,13.984496362160797 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark51(23.120234948874977,-4.80835054346862 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark51(48.02367128085811,60.180160683956984 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark51(5.2104541011637195,44.78954589883627 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark51(-5.427651339328349,76.84615056245184 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark51(-61.536120078696,-58.68155568610829 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark51(74.05287707347264,-0.12374028999967646 ) ;
  }
}
