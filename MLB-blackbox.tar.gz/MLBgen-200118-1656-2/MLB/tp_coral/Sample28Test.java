import org.junit.Test;

public class Sample28Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark28(0.6887007232462707 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark28(7.389056098930651 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark28(81.26094826435747 ) ;
  }
}
