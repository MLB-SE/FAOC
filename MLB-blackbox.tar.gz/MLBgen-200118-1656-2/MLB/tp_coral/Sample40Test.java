import org.junit.Test;

public class Sample40Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark40(3.436843972582608,13.342840428592964 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark40(-4.296215682998323,22.75368487783907 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark40(-53.5052454434082,1.0421599939748347 ) ;
  }
}
