import org.junit.Test;

public class Sample34Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark34(32.28213695871585 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark34(-6.034280721518968 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark34(76.18362184955248 ) ;
  }
}
