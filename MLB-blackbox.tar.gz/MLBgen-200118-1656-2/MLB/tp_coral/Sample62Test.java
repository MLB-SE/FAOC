import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,14.72473296411789 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-76.5458491601683 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(100.0,-100.0,-100.0,100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(-11.616543155090568,31.0223783209687,84.57868859027812,79.7491709093454 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(12.309307240015869,-11.239028879414617,35.03772245956807,32.73701847048918 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(1.3698267151463033,4.2256411103723375,4.2258241122040845,1.3702639692048113 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(23.11201931384801,11.398664511261103,11.776749247642584,66.07928816642905 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(2.3781306419584034,0.0,-88.53266100080752,-50.89194458585747 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(23.97577834374951,-2.02431476897741,26.386408588643725,-50.596872978217554 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(27.384310774951004,63.714986185300006,79.17017884060039,87.35487427088614 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(30.030991804747117,-35.8174875170932,62.93417756002509,-9.669315727740965 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(40.25757626640708,19.2495208769514,66.71215100866237,2.0913547159820416 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(46.46739829148356,-35.72539180583003,88.01662955250313,93.40364344696681 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(-50.734750830677335,60.667035990305266,64.53141705444433,-46.87036976653827 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(65.21375540697703,-45.5199599230589,76.31321702676306,-56.61942154284492 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(-67.30986938160765,28.964330351571732,-88.81841809988443,-70.66576296265569 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(-71.22536654946077,-2.465190328815662E-32,99.28640197997247,-1.352491897019125 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(72.97399185999646,-2.649798764745597,97.29246479661168,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(7.316233054428949,-2.0697998176044337,-61.027173447516645,-100.0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(74.56847545186824,86.25409757343078,10.635806813074879,43.050927589599866 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(86.71457733306573,-72.93770269837088,21.761440869754026,66.24251790619516 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(86.96850194183489,-36.93126765262846,30.148663271922658,-28.220960489061085 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(88.63710222714641,4.039507189949148,38.03086121425491,-95.65707815961979 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(97.33178774090516,57.97441925906543,-43.794866722213484,60.14985451760165 ) ;
  }
}
