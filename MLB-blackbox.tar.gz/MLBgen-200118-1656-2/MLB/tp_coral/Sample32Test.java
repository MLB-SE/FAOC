import org.junit.Test;

public class Sample32Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark32(22.93413809266498 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark32(24.999999999999996 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark32(51.7590258711497 ) ;
  }
}
