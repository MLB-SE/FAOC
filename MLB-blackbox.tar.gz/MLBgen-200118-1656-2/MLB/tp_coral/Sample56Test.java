import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,-1.2719845203578615,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0,-81.55234391627799,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(-1.8333764421721357,-44.64610843788064,82.47338284445149,79.95590903650478,14.625253195364763 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(5.039194931816397,62.46410059515972,-81.8006525180287,-35.56936729806479,9.992158143664255 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(-90.56449902732766,57.57096948034547,51.10073275890829,-43.180027917131206,-68.37623499254526 ) ;
  }
}
