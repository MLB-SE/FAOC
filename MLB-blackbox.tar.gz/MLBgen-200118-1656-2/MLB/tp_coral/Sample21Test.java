import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(-17.89286997639934,68.73875043537923 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(25.330372221978223,3.8618994359919583 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(37.263237778022415,78.64981772841949 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(-81.32054908032802,7.273099079588661 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(88.09093442808525,28.645182472306864 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(9.114138786132386,63.748303782554814 ) ;
  }
}
