import org.junit.Test;

public class Sample17Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark17(0.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark17(-0.37521491790147365 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark17(-44.62391453442018 ) ;
  }
}
