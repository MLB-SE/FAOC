import org.junit.Test;

public class Sample41Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999998,1.9999999999999993 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,1.9999999999999998 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0000000000000004 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark41(2.115557912997005,2.3600273702472387 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark41(31.47784785019661,12.303580984493692 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark41(6.0772107364592785,55.192140625823384 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark41(8.501797879976294,63.778769311993116 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark41(9.260598883820961,76.49809280320507 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark41(-9.51249219443929,99.99999994370769 ) ;
  }
}
