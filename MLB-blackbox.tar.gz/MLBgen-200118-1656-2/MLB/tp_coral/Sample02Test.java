import org.junit.Test;

public class Sample02Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark02(32.37553407892506,55.314820307736284 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark02(51.89674118852816,94.3082420136453 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark02(95.00012897539202,-43.183388847744574 ) ;
  }
}
