import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark05(10.458662273699474,-60.72962185016877,-77.7616222540399 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(39.53320917598938,55.0068443008594,-18.845670214444368 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(-58.304221937764076,79.55421519102265,31.672096525900855 ) ;
  }
}
