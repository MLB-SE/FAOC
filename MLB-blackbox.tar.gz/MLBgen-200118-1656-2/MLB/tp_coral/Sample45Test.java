import org.junit.Test;

public class Sample45Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark45(0.0,-18.837285496920657,-32.7902510337035 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark45(100.0,24.45056944646187,-63.69894779214806 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark45(-148.25273487410837,-608.6298679169779,79.1561929764824 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark45(26.5838944742856,-73.91646160616092,8.245623240943871 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark45(-27.057369901158523,-72.15727060020416,10.201924090936771 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark45(2.710505431213761E-20,1.0000000000000004,1.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark45(30.243604848414407,70.7692540347704,7.709574846506499 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark45(48.6339475055863,1.0,26.825967926186465 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark45(49.32393253454012,72.95074027788289,40.057569490315416 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark45(50.72802478209047,28.849218202044256,52.08999541347799 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark45(57.461920172190226,59.461920172190226,78.12061537355966 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark45(65.19411048776317,36.47564867293579,8.438208776102968 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark45(69.24230145369069,-91.43215785934562,51.36024896009482 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark45(8.232221353637243,12.830049644920521,10.372573921064983 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark45(-85.71156590653482,11.210239905658653,1.2319531581809997 ) ;
  }
}
