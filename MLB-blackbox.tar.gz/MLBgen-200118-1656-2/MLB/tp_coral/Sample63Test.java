import org.junit.Test;

public class Sample63Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,-4.003121106393294,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark63(0,0,0,-7.751910522145849,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark63(13.607566178288195,12.548401250092382,21.40791123521663,34.94529825653106,-30.129880507459305 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark63(1.7941807324758372,43.25591838625144,19.45160409873172,48.89496064245844,54.72587238251353 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark63(180.48471296389178,2.791818549269774,21.49353506239298,-66.32223062013843,100.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark63(20.450878908750454,98.38073938625388,58.69885119097006,36.34566040192328,95.74818103586466 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark63(-20.708471668371175,19.12009942084478,28.679528895267623,-73.34695895899142,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark63(-20.844862327142067,-21.88353956912846,-30.51259454206779,0.19314037696009556,98.42514202715535 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark63(25.95754110712793,1.1036866870164213,-98.87582717711314,5.952117370891955,100.0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark63(34.1608490271714,6.206659797075125,6.213870612858432,34.172691828567686,100.0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark63(-34.353643213006364,-68.98398615780344,-34.33267594429866,0.29766700049842143,82.63282209239148 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark63(34.69242013147863,18.01908271335064,87.6789164146343,-30.38276452186078,-31.532106991770178 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark63(41.615411994341564,9.383784884724054,51.72352203179355,-0.3747509838898253,100.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark63(-4.482643889985097,-72.53910635995683,95.04973833239224,-0.08620992150204643,11.969232542523486 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark63(49.140625364768425,35.78389632983638,-10.185115043138879,-99.75741772585683,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark63(50.85746062649224,-20.815980038265053,12.754702829437463,18.368141624027828,-76.61875038431174 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark63(59.243893400354665,-24.175505575883463,-57.339378255000014,0.9628893670194287,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark63(71.25535751817957,0.0,-20.10935093824504,-38.390203079576224,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark63(74.74046271358304,39.32603377467129,24.564747137829187,93.00161109905513,-19.529411087059614 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark63(75.12852296303463,24.724203080463667,100.0,2.7604026712732272,97.81006446802314 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark63(78.87276281871875,4.269998208118924,37.91360788349996,45.22915314333773,-61.342602717139826 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark63(79.83470586296775,23.051394225230524,65.8120429994434,94.88844898130304,91.96558997003814 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark63(81.01429149771076,67.02683662225346,63.73641782527565,-2.8230122586017075,91.70296035699764 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark63(8.262811987069085,66.84115751538786,7.205696482234458,-25.65851298178579,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark63(85.72347753221987,13.65271435997113,65.10479743034162,34.27139446184939,30.644843720976034 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark63(-86.96640294501003,86.69287668759108,-18.313234810830096,66.95238323237231,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark63(9.017230139232797,2.3511065031242624,-39.77490256515229,61.77457650099524,-21.64323227876134 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark63(9.811070514984111,23.02463911588868,72.11922156642675,-50.379609385656835,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark63(98.23163106954601,4.464457996002807,75.5107713804027,39.6139311327309,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark63(98.30985711909517,43.58705232916074,-11.967634788720986,90.23403507155749,28.15103551508318 ) ;
  }
}
