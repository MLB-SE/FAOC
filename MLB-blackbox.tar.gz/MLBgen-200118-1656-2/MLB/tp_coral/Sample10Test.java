import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(25.79962398846256,30.614062440461367,37.72020165737489 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(35.817074880271264,59.33856606300654,-27.245324815744382 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(88.56141388682846,44.93424961283051,14.712690261831511 ) ;
  }
}
