import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(20.034746356230215,-52.37360771341595 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(-54.03389544144777,69.30754743640543 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(-56.10496531050264,83.58980324745306 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(-72.91568906839166,-6.538093008801546 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(74.01655253534912,-99.5862480407397 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(-96.81694729514803,1.4216317194224217 ) ;
  }
}
