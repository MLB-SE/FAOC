import org.junit.Test;

public class Sample16Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,-1.1578858989768008 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,-1.4526746083335098 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark16(-100.0,15.078618304127772,-56.55015434651165,-57.30206086886787,32.38908434968252 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark16(65.99999139018676,15.540848792812723,-21.064742604973866,-84.50697591106552,84.64252395397207 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark16(67.16899566590806,15.319539347931482,33.00674674587128,-99.89835127994264,-87.69290278672139 ) ;
  }
}
