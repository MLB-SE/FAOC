import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(-14.895657400440808,-65.54736963512003,-80.44302703556085 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(-26.49873102793508,0.44752429525638604,75.17783074513781 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(67.11871963646658,-20.86883295985531,-34.282690263949874 ) ;
  }
}
