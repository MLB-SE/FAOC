import org.junit.Test;

public class Sample78Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,0.0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0.0,-2.4914528097036426,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-13.665460088311846,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,55.758262443126256,0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,90.0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,15.503973070958597,-3.85E-322,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,32.829207711561914,90.0,0,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,40.29826580297109,13.748347609290775,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-62.94173148371305,82.16141510885166,0,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-80.700881035552,97.96152319403822,0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark78(0.8468929882237328,80.00442837010333,-99.9955739644211,-0.8468929852078076,-53.86351293312484,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark78(-100.0,0,0,-100.0,90.0,0,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark78(100.0,-100.0,-100.0,100.0,-100.0,0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark78(10.489123986476333,0,0,-95.27761020829278,-90.0,0,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark78(-121.0,-1006.0,-106.0,121.0,-1471.0,0,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark78(1.361304844713352E-25,0,0,-45.73849994536316,-90.0,0,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark78(1.4841677015943162,0,0,9.421157281782655,99.93733471542114,0,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark78(-237.0,-589.0,-229.0,-237.0,-700.0,0,0,-424 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark78(-24.575481147322748,0,0,4.901584508751512,-88.37692259040301,0,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark78(2.6937116879563406E-25,0,0,-26.488044583900844,90.0,0,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark78(33.571118886724406,0,0,-99.82696224438445,95.01540803361985,0,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark78(-35.05257922533853,99.3112980403908,23.037615745502222,-53.864667288480874,6.759684276332578,0,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark78(-4.789894424148292,0,0,-1.6472184286297693E-83,-17.03667956630916,0,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark78(51.43604838217735,0,0,5.973828283743686,-98.98384445323583,0,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark78(-52.0,822.0,-258.0,-52.0,373.0,-662,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark78(59.24237822316559,0,0,-60.93071833468911,3.8226477813891845E-298,0,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark78(66.17539236376405,0,0,46.26240806879275,-41.66639166157373,0,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark78(73.0,599.0,419.0,-73.0,112.0,0,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark78(86.98578049864773,0,0,21.766919458229623,14.376660971528892,0,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark78(-92.72440059989613,0,0,-78.4737877146154,-14.142662582737287,0,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark78(-99.7570756377635,0,0,-99.99999999999908,-3.103785169134463E-274,0,0,0 ) ;
  }
}
