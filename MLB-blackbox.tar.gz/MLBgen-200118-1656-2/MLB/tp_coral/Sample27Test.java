import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(-26.037435658937397,-67.04689521870807,93.72725439141783 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(45.62453370824677,-77.79382453954481,83.02175909561909 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(-61.94344747777907,-19.971358187458705,54.0460779696262 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(-75.27582773010953,57.354257918762215,-14.114486206888273 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(-76.44273582741602,-26.82370280398949,-26.586329581746355 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(-93.789571040109,84.9436366514596,73.05495307899635 ) ;
  }
}
