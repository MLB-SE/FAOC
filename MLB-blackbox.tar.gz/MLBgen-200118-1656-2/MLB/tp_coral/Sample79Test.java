import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(-4.502161857125884E-13,100.0,143.6947147444,100.0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(82.077353812826,-64.92502906589402,-74.10830748793116,67.05737102307307,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(8.583532978375285E-9,-83.91708265041967,-100.0,-100.0,0 ) ;
  }
}
