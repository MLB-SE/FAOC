import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(-10.826186084007048,69.2914304139579 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(125.66623177620512,-7.865692585313084 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(17.242643633693547,32.0415707529998 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(18.439251786290924,31.560748213709076 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(37.235156000198,79.58404346962845 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(39.989686815772984,84.37207049223844 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(40.98848457520401,84.02010939805473 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(68.57642868759731,-0.14926019448395778 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(87.3261810986942,-9.34484783710758 ) ;
  }
}
