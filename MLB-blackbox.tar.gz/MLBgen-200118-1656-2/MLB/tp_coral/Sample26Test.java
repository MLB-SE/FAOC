import org.junit.Test;

public class Sample26Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark26(100.0,-95.33824499261794,-63.60216269480686,0,68.1543765041508 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark26(-18.164325201172705,20.36259309432522,26.400347175282707,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark26(31.922304751220906,-85.75275334806184,-3.3384258708256453,0,-50.42246092747038 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark26(-32.073024216146514,44.447892233136045,-28.502970590514693,2.1019514268145514,100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark26(-33.79477575283238,65.22498602617978,96.20546303583961,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark26(37.03669791446245,-84.91346794137594,-1.1237865385252235,-35.94546171182658,-85.9880441294183 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark26(-37.41566563856404,33.36854799983985,18.469103305634334,78.9309265301213,60.95566839622788 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark26(40.715101783915365,-7.042522633512178,37.653537900814555,82.6211954570334,-28.292389699575768 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark26(-46.30372379328309,-81.51059091851913,87.52784342650415,-81.95723995965449,31.94218562964963 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark26(-62.57810167826861,30.291620750611763,54.68798321803035,44.261739480396244,-21.97799293992399 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark26(65.09707310560097,-31.94154715050317,51.51963861883567,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark26(-79.10797592770062,-58.636957748051955,24.370412751707832,-50.20462953479914,-64.42715864592945 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark26(91.9389279067096,99.99995390090501,-100.0,-100.0,-37.19022876783383 ) ;
  }
}
