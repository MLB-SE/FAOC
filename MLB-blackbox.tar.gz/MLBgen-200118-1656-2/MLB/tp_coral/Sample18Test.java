import org.junit.Test;

public class Sample18Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark18(0.7484830490517567 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark18(49.7720357552563 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark18(-62.33482926459519 ) ;
  }
}
