import org.junit.Test;

public class Sample35Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark35(47.12385300637361,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark35(-49.36181014833474,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark35(58.11946409752602,-68.71473311392174 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark35(-87.24017842668148,12.035559099211497 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark35(90.86527535580362,66.36360708494124 ) ;
  }
}
