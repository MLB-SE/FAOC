import org.junit.Test;

public class Sample29Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark29(1.6094379124341005 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark29(-51.23550150915739 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark29(53.7525754095916 ) ;
  }
}
