import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(-0.3283122697846501,-5.693653262962144,36.497019815665396,-93.26563918713862 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(0.9737631631200996,-84.7083705927693,-28.798022161256554,63.97105779115583 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(-57.03467887328364,25.802267953178344,-79.20658672826433,91.01735061766888 ) ;
  }
}
