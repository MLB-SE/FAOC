import org.junit.Test;

public class Sample72Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark72(-100.0,-100.0,0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark72(-106.0213504829618,65.52589453493016,37.80624550828418,-2.632178857189828,60.26538952593504,-20.960357764679998,218.88018070293194 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark72(1.3467595264294887,-93.09339422117371,-83.28448493871184,-1.603075945377216,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark72(19.590801750451433,38.1372141509093,-37.508379915428385,-78.374330649417,100.0,-71.51783952872023,74.55162115686119 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark72(-29.68360476600664,84.72632566218084,-52.20447725737174,0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark72(31.271027810813422,-49.46166903999112,0,0,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark72(-36.18243906562615,-11.267279161093668,45.849834239007706,-37.840448393416224,0,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark72(-36.45634382571077,84.41139895059248,72.26257253713985,-70.96126758015598,-7.814606883776705,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark72(-37.840520356708545,-82.07625567710106,60.47157759640305,124.1962690432535,-64.29934417267212,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark72(-38.10604801452146,41.371897807842856,62.99010347940734,0,0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark72(46.79709511014235,-78.8375373853349,-44.2586251003559,-24.541735045318973,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark72(-4.944392854456112,-55.3071345077429,-61.59031981492249,0,0,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark72(-6.039784059447937,69.09406029136821,86.50995398307663,86.44109874714327,-45.548986411797266,-89.53859567193055,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark72(-67.75129873904041,8.882622508466056,-34.73109391383527,-68.99912381882251,-56.54018731935179,18.78301411392141,46.91624613623512 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark72(71.03254115207585,-22.92996429867938,-15.547643015820057,-52.566583815441305,-85.07017651140836,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark72(-73.71021795047227,77.66091315633338,95.02233248907623,-69.26706878809816,61.551764066266706,-90.06283196877605,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark72(-93.09427686327733,-16.46313862131418,5.194973392852078,23.099807715005134,49.07199223798491,-45.17578736970889,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark72(-9.348823480027662,-58.91813663118515,0,0,0,0,0 ) ;
  }
}
