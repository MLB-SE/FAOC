import org.junit.Test;

public class Sample91Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark91(100.0,-100.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark91(14.047074814016204,-51.74618665709372 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark91(-15.707963267948966,-56.548667764616276 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark91(16.2253691037687,-94.87447266296462 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark91(25.83617090412544,-25.510444831197063 ) ;
  }
}
