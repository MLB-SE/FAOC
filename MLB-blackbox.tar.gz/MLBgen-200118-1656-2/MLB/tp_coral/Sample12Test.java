import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(-38.6623339663567,58.48823084206845,-98.88024419712158,-4.26572146392121 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(-81.43259907501945,-66.66696942734802,42.734815534624204,-94.844200847558 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(-94.21231635672027,-71.68603112987235,68.90055922839798,89.84721629326233 ) ;
  }
}
