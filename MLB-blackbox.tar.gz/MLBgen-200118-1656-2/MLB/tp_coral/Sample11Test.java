import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(-0.01835105218526678,18.99872977942927,-56.23602433291024,5.451328769774165 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(-0.6365351367141159,-20.352432342134307,55.5709637594139,-1.4438680222485658 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(-0.8320464016186243,85.65468873735126,53.94956368261714,90.12593429770175 ) ;
  }
}
