import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(0.02706663799001774,-54.418777927026056 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(24.85842726075053,28.03099299083877 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(-99.89605591368044,89.48337428878165 ) ;
  }
}
