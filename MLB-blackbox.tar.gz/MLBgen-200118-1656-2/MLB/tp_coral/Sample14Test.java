import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(-0.7486983782044911,-42.68880195053282,-49.931653120315204,60.38773149036268 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(62.1210318203112,-69.49868563472323,4.859929534217031,-25.398194270774695 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(-97.45478833324965,-53.02211885070691,-7.570204126183498,32.97346995721165 ) ;
  }
}
