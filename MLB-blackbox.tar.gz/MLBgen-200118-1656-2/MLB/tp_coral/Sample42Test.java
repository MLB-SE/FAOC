import org.junit.Test;

public class Sample42Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark42(1.0,-21.64632661510386 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark42(11.80126926037947,77.92488789299904 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark42(2.516344706614227,10.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark42(32.76343508826511,46.000541535587104 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark42(36.109862360650794,0.12258180393142837 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark42(-49.93383812965302,-99.00683716340224 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark42(60.8137754346464,71.58802562597856 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark42(70.73791210048202,43.063666015911934 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark42(97.66928745005526,-88.0021871998494 ) ;
  }
}
