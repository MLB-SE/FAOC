import org.junit.Test;

public class Sample59Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark59(0,1.9936222210649674,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark59(0,43.285401526326126,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark59(-13.209998973659426,-0.768293727551538,12.982711001154357,-99.99999999999999,92.18707656147711 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark59(-17.054241107400216,-34.737306930314915,-23.08519947178725,-15.584444028383231,91.69105076501296 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark59(17.41282375632423,19.379597630144247,83.38733118781093,10.511375757163833,-60.5660227268429 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark59(28.900655801718443,12.86002583914862,48.62774894087828,29.361675751159723,96.52707744483979 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark59(-31.663397242099208,57.199530302439285,-25.48098957419819,-24.187088029163604,-175.2851782164772 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark59(40.010453081225315,-71.1683678141837,30.161088531595922,64.59346227223932,-66.15472332361885 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark59(4.0204051919769,2.2177787896193446,-29.951907321673314,24.658515450514273,86.8420362345792 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark59(41.99151869631131,66.15820742092382,96.70873323970481,-5.719430790787889,-21.59085019408633 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark59(47.87418811734847,6.631386936586409,75.10060234647008,49.65114775452989,-6.023730838607705 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark59(53.332209020122434,4.252818617816672,-10.681914719192552,57.199025287616934,-44.66866732638588 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark59(54.21956895080737,5.620511678341302,-59.66927749352196,-4.038198702190982,103.24418719320414 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark59(69.51904978985809,-70.16745331499621,69.70713759162484,75.81545855640178,-34.97993174938681 ) ;
  }
}
